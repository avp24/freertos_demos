README_server.txt

Echo POSIX Server App Demo (Ubuntu)
------------------------------------

This guide explains how to run the Echo POSIX server demo using FreeRTOS on an Ubuntu system.

Steps to Run:

1. Simply build the binary using the make command:
   make

2. Run the server binary.

3. To test the server, open a separate terminal and run the following command:
   echo "Hello server" | nc 127.0.0.1 5050

The server should receive and process the message sent from the client.
