README_gui_demo.txt

GUI-Based Echo Demo: FreeRTOS Server + Ubuntu Client
-----------------------------------------------------

This demo includes two applications:

1. A **FreeRTOS-based server** application.
2. A **GUI-based client** application built and run on a standard Ubuntu system.

The client sends user input to the server, which processes the request and returns a response.

-----------------------------------------------------
How to Run the Demo:

1. Build and Run the Server App:
   ------------------------------
   - In the server/ directory, run:
     make
   - Then start the server by running the generated binary.

2. Build and Run the GUI Client App (Ubuntu):
   -------------------------------------------
   - In the client/ directory, run:
     make
   - Then start the client:
     ./client_app

3. Interact via the GUI:
   -----------------------
   - When the client app runs, a simple GUI will appear in the terminal.
   - Input a number between **1 to 5**.
   - The client sends this input to the FreeRTOS server.
   - The server responds, and the output appears in the GUI.

-----------------------------------------------------
Notes:

- Ensure the server is running before starting the client.
- The client and server must use the same IP address and port (e.g., localhost and port 5050).
- Make sure no firewall or service is blocking the communication port.
- This demo demonstrates basic client-server interaction with a text-based GUI frontend and a FreeRTOS backend.

Enjoy experimenting!
