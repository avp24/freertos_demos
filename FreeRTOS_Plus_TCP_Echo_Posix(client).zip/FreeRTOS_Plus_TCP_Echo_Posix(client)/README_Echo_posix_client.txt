README.txt

Echo POSIX Client App Demo (Ubuntu)
------------------------------------

This guide explains how to run the Echo POSIX client demo using FreeRTOS on an Ubuntu system.

Steps to Run:

1. Modify the configECHO_SERVER_ADDR and configIP_ADDR macros in the FreeRTOSConfig.h file.
   Set both addresses to match your system’s default network interface (e.g., enp0s3).

2. Build the binary using the make command:
   make

3. To test the client, open a separate terminal and run the following command to start a TCP echo server:
   sudo nc -l 7

The client will connect to the echo server, and you should see data echoed back.

