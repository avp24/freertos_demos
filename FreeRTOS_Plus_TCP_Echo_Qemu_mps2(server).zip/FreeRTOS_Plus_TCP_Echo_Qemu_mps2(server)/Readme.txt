###########################################################################

###to run the Server####
folder path/home/ubuntu/Latest_working_FreeRTOS/FreeRTOS/FreeRTOS-Plus/Demo
//change it according to your Folder structure

make clean

make

to build the .axf file
sudo qemu-system-arm   -machine mps2-an385   -cpu cortex-m3   -kernel ./build/freertos_tcp_mps2_demo.axf   -net nic,model=lan9118   -net tap,ifname=tap0,script=no,downscript=no   -serial stdio   -nographic   -monitor null   -semihosting   -semihosting-config enable=on,target=native   -m 16M

########in Echo Client Side#########

(1)ip addr show tap0
o/p:-Device "tap0" does not exist.

(2)sudo ip addr add 172.20.10.2/28 dev tap0
sudo ip link set tap0 up

-[sudo] password for ubuntu
o/p: 
Cannot find device "tap0"
Cannot find device "tap0

(3)ubuntu@ubuntu-VirtualBox:~$ sudo ip tuntap add dev tap0 mode tap
ubuntu@ubuntu-VirtualBox:~$ sudo ip addr add 172.20.10.2/28 dev tap0

(4)ubuntu@ubuntu-VirtualBox:~$ sudo ip link set tap0 up
ubuntu@ubuntu-VirtualBox:~$ ip addr show tap0

o/p:-23: tap0: <NO-CARRIER,BROADCAST,MULTICAST,UP> mtu 1500 qdisc fq_codel state DOWN group default qlen 1000
    link/ether c6:14:cb:49:d0:14 brd ff:ff:ff:ff:ff:ff
    inet 172.20.10.2/28 scope global tap0
       valid_lft forever preferred_lft forever

######Tap interface is completed#####

give command 

{echo "Hello" | nc 172.20.10.1 7}

and the server will share this statement to client to bring up the stable connection

###########################################################################

####Folder structure Architecture####

.
├── build
│   ├── freertos_tcp_mps2_demo.axf
│   ├── home
│   │   └── ubuntu
│   │       └── Latest_working_FreeRTOS
│   │           └── FreeRTOS
│   │               ├── FreeRTOS
│   │               │   └── Source
│   │               │       ├── event_groups.d
│   │               │       ├── event_groups.o
│   │               │       ├── list.d
│   │               │       ├── list.o
│   │               │       ├── portable
│   │               │       │   ├── GCC
│   │               │       │   │   └── ARM_CM3
│   │               │       │   │       ├── port.d
│   │               │       │   │       └── port.o
│   │               │       │   └── MemMang
│   │               │       │       ├── heap_3.d
│   │               │       │       └── heap_3.o
│   │               │       ├── queue.d
│   │               │       ├── queue.o
│   │               │       ├── tasks.d
│   │               │       └── tasks.o
│   │               └── FreeRTOS-Plus
│   │                   └── Source
│   │                       └── FreeRTOS-Plus-TCP
│   │                           └── source
│   │                               ├── FreeRTOS_ARP.d
│   │                               ├── FreeRTOS_ARP.o
│   │                               ├── FreeRTOS_BitConfig.d
│   │                               ├── FreeRTOS_BitConfig.o
│   │                               ├── FreeRTOS_DHCP.d
│   │                               ├── FreeRTOS_DHCP.o
│   │                               ├── FreeRTOS_DHCPv6.d
│   │                               ├── FreeRTOS_DHCPv6.o
│   │                               ├── FreeRTOS_DNS_Cache.d
│   │                               ├── FreeRTOS_DNS_Cache.o
│   │                               ├── FreeRTOS_DNS_Callback.d
│   │                               ├── FreeRTOS_DNS_Callback.o
│   │                               ├── FreeRTOS_DNS.d
│   │                               ├── FreeRTOS_DNS_Networking.d
│   │                               ├── FreeRTOS_DNS_Networking.o
│   │                               ├── FreeRTOS_DNS.o
│   │                               ├── FreeRTOS_DNS_Parser.d
│   │                               ├── FreeRTOS_DNS_Parser.o
│   │                               ├── FreeRTOS_ICMP.d
│   │                               ├── FreeRTOS_ICMP.o
│   │                               ├── FreeRTOS_IP.d
│   │                               ├── FreeRTOS_IP.o
│   │                               ├── FreeRTOS_IP_Timers.d
│   │                               ├── FreeRTOS_IP_Timers.o
│   │                               ├── FreeRTOS_IP_Utils.d
│   │                               ├── FreeRTOS_IP_Utils.o
│   │                               ├── FreeRTOS_IPv4.d
│   │                               ├── FreeRTOS_IPv4.o
│   │                               ├── FreeRTOS_IPv4_Sockets.d
│   │                               ├── FreeRTOS_IPv4_Sockets.o
│   │                               ├── FreeRTOS_IPv4_Utils.d
│   │                               ├── FreeRTOS_IPv4_Utils.o
│   │                               ├── FreeRTOS_IPv6.d
│   │                               ├── FreeRTOS_IPv6.o
│   │                               ├── FreeRTOS_IPv6_Sockets.d
│   │                               ├── FreeRTOS_IPv6_Sockets.o
│   │                               ├── FreeRTOS_IPv6_Utils.d
│   │                               ├── FreeRTOS_IPv6_Utils.o
│   │                               ├── FreeRTOS_ND.d
│   │                               ├── FreeRTOS_ND.o
│   │                               ├── FreeRTOS_RA.d
│   │                               ├── FreeRTOS_RA.o
│   │                               ├── FreeRTOS_Routing.d
│   │                               ├── FreeRTOS_Routing.o
│   │                               ├── FreeRTOS_Sockets.d
│   │                               ├── FreeRTOS_Sockets.o
│   │                               ├── FreeRTOS_Stream_Buffer.d
│   │                               ├── FreeRTOS_Stream_Buffer.o
│   │                               ├── FreeRTOS_TCP_IP.d
│   │                               ├── FreeRTOS_TCP_IP_IPv4.d
│   │                               ├── FreeRTOS_TCP_IP_IPv4.o
│   │                               ├── FreeRTOS_TCP_IP_IPv6.d
│   │                               ├── FreeRTOS_TCP_IP_IPv6.o
│   │                               ├── FreeRTOS_TCP_IP.o
│   │                               ├── FreeRTOS_TCP_Reception.d
│   │                               ├── FreeRTOS_TCP_Reception.o
│   │                               ├── FreeRTOS_TCP_State_Handling.d
│   │                               ├── FreeRTOS_TCP_State_Handling_IPv4.d
│   │                               ├── FreeRTOS_TCP_State_Handling_IPv4.o
│   │                               ├── FreeRTOS_TCP_State_Handling_IPv6.d
│   │                               ├── FreeRTOS_TCP_State_Handling_IPv6.o
│   │                               ├── FreeRTOS_TCP_State_Handling.o
│   │                               ├── FreeRTOS_TCP_Transmission.d
│   │                               ├── FreeRTOS_TCP_Transmission_IPv4.d
│   │                               ├── FreeRTOS_TCP_Transmission_IPv4.o
│   │                               ├── FreeRTOS_TCP_Transmission_IPv6.d
│   │                               ├── FreeRTOS_TCP_Transmission_IPv6.o
│   │                               ├── FreeRTOS_TCP_Transmission.o
│   │                               ├── FreeRTOS_TCP_Utils.d
│   │                               ├── FreeRTOS_TCP_Utils_IPv4.d
│   │                               ├── FreeRTOS_TCP_Utils_IPv4.o
│   │                               ├── FreeRTOS_TCP_Utils_IPv6.d
│   │                               ├── FreeRTOS_TCP_Utils_IPv6.o
│   │                               ├── FreeRTOS_TCP_Utils.o
│   │                               ├── FreeRTOS_TCP_WIN.d
│   │                               ├── FreeRTOS_TCP_WIN.o
│   │                               ├── FreeRTOS_Tiny_TCP.d
│   │                               ├── FreeRTOS_Tiny_TCP.o
│   │                               ├── FreeRTOS_UDP_IP.d
│   │                               ├── FreeRTOS_UDP_IP.o
│   │                               ├── FreeRTOS_UDP_IPv4.d
│   │                               ├── FreeRTOS_UDP_IPv4.o
│   │                               ├── FreeRTOS_UDP_IPv6.d
│   │                               ├── FreeRTOS_UDP_IPv6.o
│   │                               └── portable
│   │                                   ├── BufferManagement
│   │                                   │   ├── BufferAllocation_2.d
│   │                                   │   └── BufferAllocation_2.o
│   │                                   └── NetworkInterface
│   │                                       └── MPS2_AN385
│   │                                           ├── ether_lan9118
│   │                                           │   ├── smsc9220_eth_drv.d
│   │                                           │   └── smsc9220_eth_drv.o
│   │                                           ├── NetworkInterface.d
│   │                                           └── NetworkInterface.o
│   ├── main.d
│   ├── main_networking.d
│   ├── main_networking.o
│   ├── main.o
│   ├── output.map
│   ├── startup.d
│   ├── startup.o
│   ├── syscalls.d
│   ├── syscalls.o
│   ├── TCPEchoServer_SingleTask.d
│   └── TCPEchoServer_SingleTask.o
├── CMSIS
│   ├── CMSDK_CM3.h
│   ├── cmsis_compiler.h
│   ├── cmsis_gcc.h
│   ├── cmsis.h
│   ├── cmsis_version.h
│   ├── core_cm3.h
│   ├── mpu_armv7.h
│   └── SMM_MPS2.h
├── FreeRTOSConfig.h
├── FreeRTOSIPConfig.h
├── main.c
├── main_networking.c
├── main_networking.h
├── Makefile
├── mps2_m3.ld
├── Readme.md
├── Readme_TapNetworking.md
├── Readme_UserNetworking.md
├── startup.c
├── syscalls.c
├── TCPEchoServer_SingleTask.c
└── TCPEchoServer_SingleTask.h

