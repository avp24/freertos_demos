#include "getParamFromSpecInfo2.h"

extern uint8 getParamFromSpecInfo2(FUNC_SWITCH_ID id, uint8* specInfo2Val);
uint8 testSpecInfo2[16] = {0};
uint8 testSpecInfo2Result[FUNC_SWITCH_ID_MAX] = {0};

void testFunc(void)
{
	for(int k = 0; k < FUNC_SWITCH_ID_MAX; k++){
		 testSpecInfo2Result[k] = GET_PARAM_FROM_SPECINFO2(k, testSpecInfo2);
	}
}

