/*******************************************************************************
 *
 *     Copyright (c) 2019 Nissan, Japan
 *
 *******************************************************************************
 *
 * Project: P33A
 * Module: Library for neural network
 * Version: 0.1
 * Author:
 * Date: 2019.06.10
 *
*******************************************************************************/

#include "spec.h"
#include "n_apl_common.h"
#include "tjp_common.h"
#include "neuro.h"

/* ################################################ */
/* macro                                           */
/* ################################################ */
#define EMB_ONLY                (1)   /* �w�K�p�֐����R���p�C�����Ȃ��Ƃ� 1 (��{ 1)  */
#define COMPILE_ON_ADAS			(1)

#if !EMB_ONLY
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <math.h>
#endif

//#define DEF_SIGMOID_ALPHA   (1.f)       /* �V�O���C�h�֐��̃� */
#define NEU_NORMAL_FUNC  (0u)
#define NEU_DELTA_FUNC   (1u)
#define NEU_FUNC_CHECK   (2u)

#define NEU_CHECK_SIGMOID   (0.f)
#define NEU_CHECK_RAMP      (1.f)
#define NEU_CHECK_LINER     (2.f)
#define NEU_CHECK_TANH      (3.f)
#define NEU_CHECK_SOFTMAX   (4.f)

#define NEU_FILE_MIN_ERROR_UPDATA   (0u)
#define NEU_FILE_END_OF_LEARN       (1u)

#if COMPILE_ON_ADAS 
#define STATIC
#elif EMB_ONLY
#define STATIC static
#else
#define STATIC
#endif

/* ######################################################################### */
/*  Prototype Function                                                       */
/* ######################################################################### */
#if !EMB_ONLY
static void vNEU_ShufflInput(T_NEU_TEACH_DATA_IO *teacher);
static void vNEU_UpdateW(T_NEURON_LAYER *layer,FLOAT eps_rate);
static void vNEU_Right2Left(T_NEURON_LAYER *layer,FLOAT *t_out);
static void vNEU_Left2Right(T_NEURON_LAYER *layer,FLOAT *t_in);
static void vNEU_MakeInitWeight(T_NEURON_LAYER *layers);
static void vNEU_CopyWeight(T_NEURON_LAYER *src,T_NEURON_LAYER *dst);
static void vNEU_PrintLearnResult(T_NEURON_LAYER *layer,uint32 epoch, FLOAT mean_error,FLOAT ok_rate,uint32 file_type);
static FLOAT fl_NEU_UpdateEps(FLOAT eps_rate, FLOAT error, FLOAT error_old,T_NEU_EPS_SETTING *eps);
static T_NEURON_LAYER  *pNEU_SearchOutputLayer(T_NEURON_LAYER *layer);
static FLOAT fl_ErrorLikeLihood(FLOAT y, FLOAT d);
static FLOAT fl_ErrorZizyouGosa(FLOAT y, FLOAT d);
#endif

static FLOAT fl_CalcSoftMaxCheck(FLOAT y);
static FLOAT fl_CalcDSoftMax(FLOAT y);
static FLOAT fl_CalcSoftMax(FLOAT y);
static FLOAT fl_CalcRamp(FLOAT y);
static FLOAT fl_CalcDRamp(FLOAT y);
static FLOAT fl_CalcRampCheck(FLOAT y);
static FLOAT fl_CalcSigmoid(FLOAT y);
static FLOAT fl_CalcDSigmoid(FLOAT y);
static FLOAT fl_CalcSigmoidCheck(FLOAT y);
static FLOAT fl_CalcLiner(FLOAT y);
static FLOAT fl_CalcDLiner(FLOAT y);
static FLOAT fl_CalcLinerCheck(FLOAT y);
static FLOAT fl_CalcTanh(FLOAT y);
static FLOAT fl_CalcDTanh(FLOAT y);
static FLOAT fl_CalcTanhCheck(FLOAT y);

/* ######################################################################### */
/*  Variable                                                                 */
/* ######################################################################### */
STATIC FLOAT (* const pfl_NEU_Sigmoids[3])(FLOAT) ={fl_CalcSigmoid,   fl_CalcDSigmoid,    fl_CalcSigmoidCheck};
STATIC FLOAT (* const pfl_NEU_Ramps[3])(FLOAT)    ={fl_CalcRamp,      fl_CalcDRamp,       fl_CalcRampCheck};
STATIC FLOAT (* const pfl_NEU_Liners[3])(FLOAT)   ={fl_CalcLiner,     fl_CalcDLiner,      fl_CalcLinerCheck};
STATIC FLOAT (* const pfl_NEU_Tanhs[3])(FLOAT)   ={fl_CalcTanh,     fl_CalcDTanh,         fl_CalcTanhCheck};
STATIC FLOAT (* const pfl_NEU_SoftMaxs[3])(FLOAT)   ={fl_CalcSoftMax,     fl_CalcDSoftMax, fl_CalcSoftMaxCheck};

/* ######################################################################### */
/*  Public Function                                                          */
/* ######################################################################### */
#if !EMB_ONLY
static T_NEU_LEARN_SETTING org_setting;
static uint32 restart_req= 0;
/* #######################################################################################################
++module
++outline
++arguments
++supp
++ end_module
############################################################################################################# */
void vNEU_Learn(T_NEURON_LAYER *layers, T_NEU_TEACH_DATA_IO *teacher, T_NEU_LEARN_SETTING *setting){
    uint32 i,j;
    FLOAT mean_error,mean_error_old;
    FLOAT error,error_old;
    FLOAT eps_rate;
    uint32 num_of_teach,epoch;
    FLOAT *t_in,*t_out;
    T_NEURON_LAYER *l_in,*l_out;
    static  FLOAT mean_error_save;
    FLOAT   (*error_func)(FLOAT,FLOAT);
    FLOAT   check,tmp2,add;
    FLOAT   judge,ok_rate;
    uint32  ok_cnt,e_req;
    sint32  a,b;
    
    /* ---------------------------- */
    /* �??[�J����?�?�����           */
    /* ---------------------------- */
    mean_error_old = 1.f;
    error_old = 1.f;
    l_in    = layers;    /* ���͑w */
    l_out   = pNEU_SearchOutputLayer(layers);
    check = l_out->function[NEU_FUNC_CHECK](0.f);
    if( check == NEU_CHECK_SIGMOID){
        error_func = fl_ErrorLikeLihood;
    }
    else{
        error_func = fl_ErrorZizyouGosa;
    }
    num_of_teach = teacher->total;
    org_setting = *setting;
    
    /* ---------------------------- */
    /* ?����l����                   */    
    /* ---------------------------- */
    vNEU_ShufflInput(teacher);
    mean_error_save = 1.f;
RE_LOOP:      
    epoch           = 0;
    vNEU_MakeInitWeight(layers);

    /* ---------------------------- */
    /* �{��                         */
    /* ---------------------------- */
    error_old       = 1.f;
    eps_rate = setting->eps.init;
    do{
        mean_error = 0.f;
        ok_cnt = 0;
        for(i=0;i<num_of_teach;i++){
            t_in    = &teacher->in.data[i*teacher->in.attr];       /* ���t�f?[�^(����)�ւ̃|�C���^ */
            vNEU_Left2Right(l_in,t_in);  /* ?�����E�� *//* ?o�͌v�Z */
            /* +++ ��?��v�Z +++ */
            t_out   = &teacher->out.data[i*teacher->out.attr];    /* ���t�f?[�^(?o��)�ւ̃|�C���^ */
            vNEU_Right2Left(l_out,t_out);   /* �E����?��� */
            vNEU_UpdateW(l_in,eps_rate);    /* ?�����E */ /* w ��?�   *//* �v 1�?���� */
        }
        for(i=0;i<num_of_teach;i++){
            t_in    = &teacher->in.data[i*teacher->in.attr];       /* ���t�f?[�^(����)�ւ̃|�C���^ */
            vNEU_Left2Right(l_in,t_in);  /* ?�����E�� *//* ?o�͌v�Z */
            /* +++ ��?��v�Z +++ */
            t_out   = &teacher->out.data[i*teacher->out.attr];    /* ���t�f?[�^(?o��)�ւ̃|�C���^ */
            error = error_func(l_out->neuron[0].y,t_out[0]);
            mean_error += error;

            a = (sint32)l_out->neuron[0].y;
            tmp2 = l_out->neuron[0].y - (FLOAT)a;
            tmp2 = fabsf(tmp2);
            if( tmp2 >= 0.5f){
                if( l_out->neuron[0].y < 0.f ){
                    add = -1.f;
                }
                else{
                    add = 1.f;
                }
                tmp2 = l_out->neuron[0].y  + add;
            }
            else{
                tmp2 = l_out->neuron[0].y ;
            }
            a = (sint32)tmp2;
            b = (sint32)t_out[0];

            if( a == b ){
                ok_cnt++;
            }
        }
        mean_error /= (FLOAT)num_of_teach;
        ok_rate   = (FLOAT)ok_cnt / (FLOAT)num_of_teach;
        eps_rate = fl_NEU_UpdateEps(eps_rate,mean_error,error_old,&setting->eps);
        error_old = mean_error;
        printf("%d ,mean_error = %.10f, rate = %.6f, eps = %.10f\n",epoch,mean_error,ok_rate,eps_rate);
        if( mean_error_save > mean_error ){
            mean_error_save = mean_error;
            vNEU_PrintLearnResult(layers,epoch,mean_error,ok_rate,NEU_FILE_MIN_ERROR_UPDATA);
            e_req = NAP_ON;
        }
        vNEU_ShufflInput(teacher);
        epoch++;
        if(epoch % 1000 == 3 ){
            volatile uint32 T;
            T = time(NULL);
            srand(T);
        }
    }while( (mean_error > 0.0001f) && (restart_req == 0) && (epoch < setting->max_epoch) );
    if(e_req == NAP_ON){
        e_req = NAP_OFF;
        vNEU_PrintLearnResult(layers,epoch,mean_error,ok_rate,NEU_FILE_END_OF_LEARN);
    }
    if( restart_req == 0){
        ;
    }
    else{
        restart_req = 0;
        *setting = org_setting;
        goto RE_LOOP;
    }
}
#endif
/* #######################################################################################################
++module
++outline
++arguments
++supp
++ end_module
############################################################################################################# */
STATIC void vNEU_WorkSpaceInit(FLOAT *workspace, uint32 num,FLOAT **y_ptr,T_NEURON_LAYER_FF const * const filt){
    const T_NEURON_LAYER_FF *p;
    uint32 i,j;
    uint32 layer_num;

    layer_num = 0;
    for(j=0;j<num;j++){
        workspace[j]=1.f;               /* 1��?���������(��?d�v) : ��?��̈�̓��͂�1�ɕK��?ݒ肳��邽�� */
    }
    p = filt;
    i=0;
    while(p != NULL){
        y_ptr[layer_num] = &workspace[i];
        i += p->num_of_neuron;
        layer_num++;
        p = p->right;
    }
}

/* #######################################################################################################
++module
++outline
++arguments
++supp
++ end_module
############################################################################################################# */
STATIC void vNEU_Left2Right_FF(T_NEURON_LAYER_FF const * const filt,FLOAT **y_ptr){
    const T_NEURON_LAYER_FF *now,*left;
    uint32 num,num_left;
    uint32 i,j;
    FLOAT s;

    now = filt;
    /* +++ ���̓f?[�^���j��?[�?���� +++ */
    if( now->left == NULL){                     /* ���̓��C��?[ */

      now = (T_NEURON_LAYER_FF*)now->right;
      /* +++ ����?��? +++ */
      while( now != NULL){
          num      = now->num_of_neuron;
          left     = now->left;
          num_left = left->num_of_neuron;
          for(i=0;i<num-1;i++){
              s = 0.f;
              /* �e���͂ɑ΂���?d�݂��|���Ęa����� */
              for(j=0;j<num_left;j++){
                  s += y_ptr[left->layer_num][j] * now->neuron[i].weight[j].f;
              } 
              /* ��?���ʂ� */
              y_ptr[now->layer_num][i] = now->function[NEU_NORMAL_FUNC](s);
          }
          y_ptr[now->layer_num][i] = 1.f;
          now = now->right;
      } 
    }
    else{;}
}

/* ######################################################################### */
/*  Private Function                                                         */
/* ######################################################################### */
#if !EMB_ONLY
/* #######################################################################################################
++module
++outline
++arguments
++supp
++ end_module
############################################################################################################# */
static void vNEU_MakeInitWeight(T_NEURON_LAYER *layers){
  T_NEURON_LAYER *p;
  uint32 x;
  FLOAT z;
  uint32 i,j;
  uint32 num_of_input,num_of_neuron;
  volatile uint32 T;

  T = time(NULL);
  srand(T);

  p = layers;
  if( p->left == NULL){
      p = p->right;
      while(p != NULL){
          num_of_neuron = p->num_of_neuron;
          num_of_input  = p->left->num_of_neuron;
          for(i=0;i<num_of_neuron-1;i++){
              for(j=0;j<num_of_input-1;j++){
                  z = (FLOAT)(rand()%200000);
                  z -= 100000.f;
                  z /= 100000.f;
                  p->neuron[i].weight[j].f = z;
              }
              p->neuron[i].weight[j].f = 0.f;   /* �o�C�A�X��?����l0 */
          }
          for(j=0;j<num_of_input;j++){
              p->neuron[i].weight[j].f = 0.f;   /* �_�~?[�Ȃ̂�?A0�ɓ?�� */
          }
          p = p->right;
      }
  }
  else{;}
}
/* #######################################################################################################
++module
++outline
++arguments
++supp
++ end_module
############################################################################################################# */
static void vNEU_CopyWeight(T_NEURON_LAYER *src,T_NEURON_LAYER *dst){

    uint32 i,j;
    
    src = src->right;
    dst = dst->right;

    while(src != NULL){
        for(i=0;i<src->num_of_neuron;i++){
            for(j=0;j<src->left->num_of_neuron;j++){
                dst->neuron[i].weight[j] = src->neuron[i].weight[j];
            }
        }
        src = src->right;
        dst = dst->right;
    }
}
/* #######################################################################################################
++module
++outline
++arguments
++supp
++ end_module
############################################################################################################# */
static FLOAT fl_NEU_UpdateEps(FLOAT eps_rate, FLOAT error, FLOAT error_old,T_NEU_EPS_SETTING *eps){
    if( error < error_old ){
        eps_rate += eps->add;
        if( eps_rate > eps->max){
            eps->max *= 10.f;
            eps->min *= 10.f;
            eps->add *= 10.f;
            eps->sub *= 10.f;
            eps_rate = eps->min;
        }
        if( eps_rate > org_setting.eps.max ){
            *eps = org_setting.eps;
            eps_rate = eps->max;
        }
    }
    else{
        eps_rate -= eps->sub;
        if( eps_rate < eps->min){
            eps->max *= 0.1f;
            eps->min *= 0.1f;
            eps->add *= 0.1f;
            eps->sub *= 0.1f;
            eps_rate = eps->max;
        }
        if( eps_rate < (org_setting.eps.min / 10000.f) ){
            restart_req = 1;
        }
    }
    
    return(eps_rate);
}
/* #######################################################################################################
++module
++outline
++arguments
++supp
++ end_module
############################################################################################################# */
static void vNEU_PrintLearnResult(T_NEURON_LAYER *layer,uint32 epoch, FLOAT mean_error,FLOAT ok_rate,uint32 file_type){
    FILE *fp;
    T_NEURON_LAYER *now;
    uint32 cnt;
    uint32 i,j;
    uint32 total_neurons,total_layers;
    uint32 input_num,output_num;

    now = layer;

    if( layer->left == NULL){
        cnt = 0;
        input_num = now->num_of_neuron;
        if( file_type == NEU_FILE_MIN_ERROR_UPDATA ){
            fp = fopen("learn_result.c","w");
        }
        else{
            fp = fopen("learn_result_e.c","w");
        }
        /* ---------------------------- */
        /* ���͑w                       */
        /* ---------------------------- */
        fprintf(fp,"/* epoch = %d,\t mean_error = %f rate = %.6f*/\n",epoch,mean_error,ok_rate);
        fprintf(fp,"static const U_IEEE_754_32BIT layer_00_weight[%d]={\n",now->num_of_neuron);
        fprintf(fp,"\t");
        for(i=0;i<now->num_of_neuron;i++){
            fprintf(fp,"0x00000001");
            if( i != now->num_of_neuron-1){
                fprintf(fp,",");
            }
        }
        fprintf(fp,"\n};\n");
        fprintf(fp,"static const T_NEURON_FF layer_00[%d]={\n",now->num_of_neuron);
        for(i=0;i<now->num_of_neuron;i++){
            fprintf(fp,"\t{&layer_00_weight[0]}");
            if( i != now->num_of_neuron-1){
                fprintf(fp,",");
            }
            fprintf(fp,"\n");
        }
        fprintf(fp,"};\n");
        total_neurons = now->num_of_neuron;
        now = now->right;
        total_layers = 1;
        
        /* ---------------------------- */
        /* ���ԑw��?o�͑w               */
        /* ---------------------------- */
        cnt++;
        while(now != NULL){
            total_layers += 1;
            total_neurons += now->num_of_neuron;
            output_num = now->num_of_neuron;
            fprintf(fp,"static const U_IEEE_754_32BIT layer_%02d_weight[%d][%d]={\n",cnt,now->num_of_neuron,now->left->num_of_neuron);
            for(i=0;i<now->num_of_neuron;i++){
                fprintf(fp,"\t{");
                for(j=0;j<now->left->num_of_neuron;j++){
                    fprintf(fp,"0x%08x",now->neuron[i].weight[j].l);
                    if( j != now->left->num_of_neuron-1){
                        fprintf(fp,",");
                    }
                }
                fprintf(fp,"}");
                if( i != now->num_of_neuron-1){
                    fprintf(fp,",");
                }
                fprintf(fp,"\n");
            }
            fprintf(fp,"};\n");
            fprintf(fp,"static const T_NEURON_FF layer_%02d[%d]={\n",cnt,now->num_of_neuron);
            for(i=0;i<now->num_of_neuron;i++){
                fprintf(fp,"\t{&layer_%02d_weight[%d][0]}",cnt,i);
                if( i != now->num_of_neuron-1){
                    fprintf(fp,",");
                }
                fprintf(fp,"\n");
            }
            fprintf(fp,"};\n");
            cnt++;
            now = now->right;
        }
        /* ---------------------------- */
        /* �܂Ƃ߂�                     */
        /* ---------------------------- */
        fprintf(fp,"\n");
        fprintf(fp,"static const T_NEURON_LAYER_FF  tNEU_Neurons_FF[%d]={\n",total_layers);
        now = layer;
        for(i=0;i<total_layers;i++){
            FLOAT check;
            fprintf(fp,"\t{ %d, ",i);
            check = now->function[NEU_FUNC_CHECK](0.f);
            if( check == NEU_CHECK_SIGMOID){
                fprintf(fp,"&pfl_NEU_Sigmoids[0]  ,");
            }
            else if( check == NEU_CHECK_RAMP){
                fprintf(fp,"&pfl_NEU_Ramps[0]  ,");
            }
            else if( check == NEU_CHECK_TANH){
                fprintf(fp,"&pfl_NEU_Tanhs[0]  ,");
            }
            else if( check == NEU_CHECK_SOFTMAX){
                fprintf(fp,"&pfl_NEU_SoftMaxs[0]  ,");
            }
            else{
                fprintf(fp,"&pfl_NEU_Liners[0]  ,");
            }
            fprintf(fp,"ARRAY_NUM(layer_%02d), &layer_%02d[0], ",i,i);
            if( i == 0){
                fprintf(fp,"NULL,\t\t\t\t");
            }
            else{
                fprintf(fp,"&tNEU_Neurons_FF[%d],\t",i-1);
            }
            if(i != total_layers-1){
                fprintf(fp,"&tNEU_Neurons_FF[%d]\t",i+1);
            }
            else{
                fprintf(fp,"NULL\t\t\t\t");
            }
            fprintf(fp,"}");
            if( i != total_layers-1){
                fprintf(fp,",");
            }
            fprintf(fp,"\n");
            now = now->right;
        }
        fprintf(fp,"};\n");

        fprintf(fp,"#define DEF_TOTAL_LAYERS     (%d)\n",total_layers);
        fprintf(fp,"#define DEF_TOTAL_NEURONS    (%d)\n",total_neurons);
        fprintf(fp,"#define DEF_ATTR_IN          (%d)\n",input_num-1);
        fprintf(fp,"#define DEF_ATTR_OUT         (%d)\n",output_num-1);
        fclose(fp);
    }
    else{
        exit(-1);
    }
}
/* #######################################################################################################
++module
++outline
++arguments
++supp
++ end_module
############################################################################################################# */
static void vNEU_ShufflInput(T_NEU_TEACH_DATA_IO *teacher){
    uint32  i,j;
    uint32  rnd;
    FLOAT   i_tmp;
    FLOAT   o_tmp;
    uint32 total,attr_in_num,attr_out_num;

    total = teacher->total;
    attr_in_num = teacher->in.attr;
    attr_out_num = teacher->out.attr;
    
    for(i=total-1;i>0;i--){
        rnd = rand();
        rnd %= (i+1);
        for(j=0;j<attr_in_num;j++){
            i_tmp = teacher->in.data[i*attr_in_num+j];
            teacher->in.data[i*attr_in_num+j] = teacher->in.data[rnd*attr_in_num+j];
            teacher->in.data[rnd*attr_in_num+j] = i_tmp;
        }
        for(j=0;j<attr_out_num;j++){
            o_tmp = teacher->out.data[i*attr_out_num+j];
            teacher->out.data[i*attr_out_num+j] = teacher->out.data[rnd*attr_out_num+j];
            teacher->out.data[rnd*attr_out_num+j] = o_tmp;
        }
    }
}
/* #######################################################################################################
++module
++outline
++arguments
++supp
++ end_module
############################################################################################################# */
static T_NEURON_LAYER  *pNEU_SearchOutputLayer(T_NEURON_LAYER *layer){
    while(layer->right != NULL){
        layer = layer->right;
    }
    return(layer);
}
/* #######################################################################################################
++module
++outline
++arguments
++supp
++ end_module
############################################################################################################# */
static void vNEU_UpdateW(T_NEURON_LAYER *layer,FLOAT eps_rate){
    T_NEURON_LAYER *now,*left;
    uint32 num,num_left;
    uint32 i,j;
    FLOAT g,a;

    now = layer;
    if( now->left == NULL){     
        now = now->right;   /* ���̓��C��?[�͔�΂� */
        while( now != NULL){
            num      = now->num_of_neuron;
            left     = now->left;
            num_left = left->num_of_neuron;
            /* ?d��?C?� */
            for(i=0;i<num-1;i++){
                    for(j=0;j<num_left;j++){
                            g = (left->neuron[j].y * now->neuron[i].z);
                            now->neuron[i].weight[j].f -= ( eps_rate * g);
                        }
            }
            now = now->right;
        }
    }
    else{;}
}

/* #######################################################################################################
++module
++outline
++arguments
++supp
++ end_module
############################################################################################################# */
static void vNEU_Right2Left(T_NEURON_LAYER *layer,FLOAT *t_out){
    T_NEURON_LAYER *now,*right;
    uint32 num,num_right;
    uint32 i,j;
    FLOAT u,delta,y;
    FLOAT val;

    now = layer;
    if( now->right == NULL){
        for(i=0;i<now->num_of_neuron-1;i++){
            now->neuron[i].z = (now->neuron[i].y - t_out[i]);
        }
        now = now->left;
        while(now->left != NULL){
            num         = now->num_of_neuron;
            right       = now->right;
            num_right   = right->num_of_neuron;
            for(i=0;i<num-1;i++){
                    /* ?����� */
                    u = 0.f;
                    y = now->neuron[i].y;
                    /* �e���͂ɑ΂���?d�݂��|���Ęa����� */
                    for(j=0;j<num_right-1;j++){
                            u += right->neuron[j].weight[i].f * right->neuron[j].z;
                        }
                    /* Z�Z?o */
                    delta = now->function[NEU_DELTA_FUNC](y);
                    now->neuron[i].z = delta * u;
                }
            now = now->left;
        }
    }
    else{;}
}

/* #######################################################################################################
++module
++outline
++arguments
++supp
++ end_module
############################################################################################################# */
static void vNEU_Left2Right(T_NEURON_LAYER *layer, FLOAT *t_in){

    T_NEURON_LAYER *now,*left;
    uint32 num,num_left;
    uint32 i,j;
    FLOAT s;

    now = layer;
    /* +++ ���̓f?[�^���j��?[�?���� +++ */
    if( now->left == NULL){                     /* ���̓��C��?[ */
        for(i=0;i<now->num_of_neuron-1;i++){
            now->neuron[i].y = t_in[i];
        }
        now->neuron[i].y = 1.f;
        now = now->right;
        /* +++ ����?��? +++ */
        while( now != NULL){
            num      = now->num_of_neuron;
            left     = now->left;
            num_left = left->num_of_neuron;
            for(i=0;i<num-1;i++){
                    s = 0.f;
                    /* �e���͂ɑ΂���?d�݂��|���Ęa����� */
                    for(j=0;j<num_left;j++){
                            s += left->neuron[j].y * now->neuron[i].weight[j].f;
                        }
                    /* ��?���ʂ� */
                    now->neuron[i].y = now->function[NEU_NORMAL_FUNC](s);
            }
            now->neuron[i].y = 1.f;
            now = now->right;
        }
    }
    else{;}
}
/* #######################################################################################################
++module
++outline
++arguments
++supp
++ end_module
############################################################################################################# */
static FLOAT fl_ErrorLikeLihood(FLOAT y, FLOAT d){
    FLOAT out;

    if( y == 0.f){
        out = -( (1.f-d) * logf(1.f - y) );
    }
    else if( y == 1.f ){
        out = -(d * logf(y));
    }
    else{
        out = -( (d * logf(y)) + ( (1.f-d) * logf(1.f - y) ) );
    }

    return(out);
}

/* #######################################################################################################
++module
++outline
++arguments
++supp
++ end_module
############################################################################################################# */
static FLOAT fl_ErrorZizyouGosa(FLOAT y, FLOAT d){
    FLOAT out;

    out = (y - d) * (y - d);
    out /= 2.f;

    return(out);
}


#endif
/* #######################################################################################################
++module    
++outline
++arguments
++supp
++ end_module
############################################################################################################# */
static FLOAT fl_CalcLiner(FLOAT y){
    return(y);
}
/* #######################################################################################################
++module    
++outline
++arguments
++supp
++ end_module
############################################################################################################# */
static FLOAT fl_CalcDLiner(FLOAT y){
    return(1.f);
}
/* #######################################################################################################
++module
++outline
++arguments
++supp
++ end_module
############################################################################################################# */
static FLOAT fl_CalcLinerCheck(FLOAT y){
    return(NEU_CHECK_LINER);
}
/* #######################################################################################################
++module    
++outline
++arguments
++supp
++ end_module
############################################################################################################# */
static FLOAT fl_CalcRamp(FLOAT y){
    FLOAT out;
    if( y >  0.f ){
        out = y;
    }
    else{
        out = 0.f;
    }
    return(out);
}
/* #######################################################################################################
++module
++outline
++arguments
++supp
++ end_module
############################################################################################################# */
static FLOAT fl_CalcDRamp(FLOAT y){
    FLOAT out;
    if( y >= 0.f){
        out = 1.f;
    }
    else{
        out = 0.f;
    }
    return(out);
}
/* #######################################################################################################
++module
++outline
++arguments
++supp
++ end_module
############################################################################################################# */
static FLOAT fl_CalcRampCheck(FLOAT y){
    return(NEU_CHECK_RAMP);
}
/* #######################################################################################################
++module
++outline
++arguments
++supp
++ end_module
############################################################################################################# */
static FLOAT fl_CalcSigmoid(FLOAT y){
    FLOAT tmp;
    FLOAT out;
    //    tmp = 1.f + ExpCalc(-DEF_SIGMOID_ALPHA*y);
    tmp = 1.f + ExpCalc(-y);
    out = 1.f/tmp;
    return(out);
}
/* #######################################################################################################
++module
++outline
++arguments
++supp
++ end_module
############################################################################################################# */
static FLOAT fl_CalcDSigmoid(FLOAT y){
    FLOAT out;
    out = y * (1.f-y);
    //out *= DEF_SIGMOID_ALPHA;

    return(out);
}

/* #######################################################################################################
++module
++outline
++arguments
++supp
++ end_module
############################################################################################################# */
static FLOAT fl_CalcSigmoidCheck(FLOAT y){
    return(NEU_CHECK_SIGMOID);
}
/* #######################################################################################################
++module
++outline
++arguments
++supp
++ end_module
############################################################################################################# */
static FLOAT fl_CalcTanh(FLOAT y){
    FLOAT a,b;
    FLOAT out;

    a = ExpCalc(y);
    b = ExpCalc(-y);
    out = (a-b)/(a+b);
    
    return(out);
}
/* #######################################################################################################
++module
++outline
++arguments
++supp
++ end_module
############################################################################################################# */
static FLOAT fl_CalcDTanh(FLOAT y){
    FLOAT out;
    out = 1.f -(y*y);

    return(out);
}

/* #######################################################################################################
++module
++outline
++arguments
++supp
++ end_module
############################################################################################################# */
static FLOAT fl_CalcTanhCheck(FLOAT y){
    return(NEU_CHECK_TANH);
}
/* #######################################################################################################
++module
++outline
++arguments
++supp
++ end_module
############################################################################################################# */
static FLOAT fl_CalcSoftMax(FLOAT y){
    FLOAT out;
    out = ExpCalc(y);
    return(out);
}
/* #######################################################################################################
++module
++outline
++arguments
++supp
++ end_module
############################################################################################################# */
static FLOAT fl_CalcDSoftMax(FLOAT y){
    FLOAT out;
    out = y;
    return(out);
}

/* #######################################################################################################
++module
++outline
++arguments
++supp
++ end_module
############################################################################################################# */
static FLOAT fl_CalcSoftMaxCheck(FLOAT y){
    return(NEU_CHECK_SOFTMAX);
}


#undef STATIC
//$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$                                end

