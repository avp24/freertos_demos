/******************************************************************************
 *
 *     Copyright (c) 2007 Nissan, Japan
 *
 ******************************************************************************
 *
 * Project:     
 * Module:      ���Y�����\�t�g���ʊ֐����C�u����
 * Version      1.0
 * Author:      
 * Date:        
 * Description: 
 * Revision History:
 *              No          Name    Note
 *                          �F��    n_CalcSint32Mul FPU��O������ǉ�
 *                                  n_CalcSint32Div FPU��O������ǉ�
 *                                  fl_Fix2Float    ��O������ǉ�
 *                                  db_Fix2Double   ��O������ǉ�
 *                                  si32_Float2Fix  ���~�b�g������臒l�A�������C��
 *                                  si32_Read2DMap  ���Z�lr(y��hi)����l(y��lo)�ɏC��
 *                          �F��    fl_Read2DMap    �V�K�쐬
 *                                  fl_Read3DMap    �V�K�쐬
 *                                  v_SeachFlArrayPosition          �V�K�쐬
 *                                  fl_CalcLinearComplementarity    �V�K�쐬
 *                                  db_FpscrCauseCheck              �V�K�쐬
 *                          �F��    FPU�G���[�Ή� double�̎g�p���֎~
 *
******************************************************************************/
#define __N_APL_COMMON_C__
#include "utypedef.h"
#include "spec.h" /* ���g���G���f�B�A���Ή� Task #8628 */
#include "n_apl_common.h"

volatile static const uint8 version_n_common_lib[] __attribute__((used,protect)) = "SW400_Common011";
volatile static const uint8 version_spec_h[] __attribute__((used,protect)) = "SW400_Spec_h002";

//#include "Diag_FPU.h"
uint8 ui8_GetFPSCR_Cause(void){
    return(0);
}

#define NAP_SINT32MIN	(-2147483647L)  /* C90 �� C99�̈Ⴂ�z���̂���   */
#define NAP_SINT32MAX	(2147483647L)   /* ��̂���                   */

#define NAP_FL2FIX_MIN_LIM	(-2147483648.f)    /* SINT32MIN��Float�^�ɃL���X�g����Ɖ����������������邽�� */
#define NAP_FL2FIX_MAX_LIM	(2147483648.f)     /* SINT32MAX��Float�^�ɃL���X�g����Ɖ����������������邽�� */

/* FPU��O�v�� *//*[ADAS01]*/
#define mCause_FPUERROR     0x20            /* 0x20 : FPU�G���[                     */
#define mCause_INVALIDCALC  0x10            /* 0x10 : �������Z                      */
#define mCause_ZERODIV      0x08            /* 0x08 : 0���Z                         */
#define mCause_OVERFLOW     0x04            /* 0x04 : �I�[�o�[�t���[                */
#define mCause_UNDERFLOW    0x02            /* 0x02 : �A���_�[�t���[                */
#define mCause_INACCURACY   0x01            /* 0x01 : �s���m                        */

/* ---------------------------- */
/*  �v���g�^�C�v�錾            */
/* ---------------------------- */
void v_SeachFlArrayPosition(FLOAT in_data, const FLOAT * array, uint32 size, uint32 * lo_pos, uint32 * hi_pos);
FLOAT fl_CalcLinearComplementarity(FLOAT dy, FLOAT dx, FLOAT base, FLOAT dt);
FLOAT fl_FpscrCauseCheck(FLOAT val, FLOAT init_val, uint8 cause);
DOUBLE db_FpscrCauseCheck(DOUBLE val, DOUBLE init_val, uint8 cause);

/* ######################################################################### */
/*  Variable                                                                 */
/* ######################################################################### */
static const uint32 * lkup_ptr_out;
static const FLOAT * lkup_ptr_inp;
static uint32 numofentires;

/* ######################################################################### */
/*  Prototype Function                                                       */
/* ######################################################################### */
static FLOAT fl_tan_calc_lkup(FLOAT tan_val);
static FLOAT fl_atan_calc_lkup(FLOAT atan_val);
static FLOAT LKtbl_interpolation(const FLOAT invalues[], const uint32 outvalues[], uint32 num_points, FLOAT x);

/******************************************************************************
++module
++outline
  ���[�p�X�t�B���^���v�Z����
++arguments
  <sint32> <>       [���[�p�X�t�B���^�l]
  <sint32> <x>      [����]
  <sint32> <x_pos>  [x��2^0�̃r�b�g�ʒu]
  <sint32> <y_z>    [�o�͂̑O��]
  <sint32> <y_z_pos>  [y_z��2^0�̃r�b�g�ʒu]
  <T_SCP_LOW_PASS_PARAM*> <param> [���[�p�X�t�B���^�p�����[�^�ւ̃|�C���^]
  <sint32> <z_pos>  [�o�͂�2^0�̃r�b�g�ʒu]
++supp
  [Traceability]
    ����
++end_module
******************************************************************************/
sint32 si32_LowPassFilter( sint32 x, sint32 x_pos, sint32 y_z, sint32 y_z_pos,const T_LPF_PARAM *param, sint32 out_pos){
    sint32 m,n;

    (void) n_CalcSint32Mul(x,x_pos,param->A.val,param->A.pos,&m,out_pos);
    (void) n_CalcSint32Mul(y_z,y_z_pos,param->B.val,param->B.pos,&n,out_pos);
    m += n;

    return(m);
}

/******************************************************************************
++module
++outline
  uint32 �^�̃J�E���^���C���N�������g����
++arguments
  <uint16> <>       [�J�E���^�l]
  <uint16> <count>  [����]
  <uint16> <max>    [�J�E���^�̍ő�l]
++supp
  [Traceability]
    ����
++end_module
******************************************************************************/
uint32 ui32_IncCount(uint32 count,uint32 max){
    if( count < max){
        count++;
    }
    else{
        ;
    }
    return(count);
}

/******************************************************************************
++module
++outline
  uint32 �^�̃J�E���^���C���N�������g����.
  MAX���z�����ꍇ�́Ainit ��Ԃ�.
++arguments
  <uint16> <>       [�J�E���^�l]
  <uint16> <count>  [����]
  <uint16> <max>    [�J�E���^�̍ő�l]
  <uint16> <init>    [�J�E���^�̏����l]
++supp
  [Traceability]
    ����
++end_module
******************************************************************************/
uint32 ui32_IncCount2(uint32 count,uint32 max, uint32 init){
    if( count < max){
        count++;
    }
    else{
        count = init;
    }
    return(count);
}

/******************************************************************************
++module
++outline
  uint32 �^�̃J�E���^���f�N�������g����B
  �f�N�������g�̌��ʂ� 0�����ɂȂ�ꍇ�́A�o�͂� 0 �ɂ���
++arguments
  <uint16> <>       [�J�E���^�l]
  <uint16> <count>  [����]
++supp
  [Traceability]
    ����
++end_module
******************************************************************************/
uint32 ui32_DecCount(uint32 count){
    if( count != 0){
        count--;
    }
    else{
        ;
    }
    return(count);
}

/******************************************************************************
++module
++outline
++arguments
  <void> <> [�߂�l�Ȃ�]
  <void> <> [�����Ȃ�]
++supp
  [Traceability]
++end_module
******************************************************************************/
uint8 ui8_DecCount2(uint16 *cnt, uint8 reset_req, uint16 reset_val){
    uint8 out;
    if( reset_req == NAP_ON){
        *cnt = reset_val;
        out = NAP_ON;
        if( *cnt == 0){
            out = NAP_OFF;
        }
    }
    else if( *cnt > 1){
        *cnt -= 1;
        out = NAP_ON;
    }
    else{
        *cnt = 0;
        out = NAP_OFF;
    }
    return(out);
}

/******************************************************************************
++module
++outline
++arguments
  <void> <> [�߂�l�Ȃ�]
  <void> <> [�����Ȃ�]
++supp
  [Traceability]
++end_module
******************************************************************************/
uint8 ui8_DelChatter(uint8 now, uint8 old, uint16 *cnt, uint16 on_thresh, uint16 off_thresh){
    uint8 out;

    if( now == old ){
        *cnt = 0;
        out = now;
    }
    else if( *cnt == 0){
        /* --- �J�E���^�ݒ�   --- */
        *cnt = off_thresh;
        if( now == NAP_ON ){
            *cnt = on_thresh;
        }
        /* --- �o�͐ݒ� --- */
        out = old;
        if( *cnt == 0){     /* �`���^�����O���Ԗ����̏ꍇ */
            out= now;
        }
    }
    else{
        out = old;
        if( ui8_DecCount2(cnt,NAP_OFF,0) == NAP_OFF){
            out = now;
        }
    }
    return(out);
}


/******************************************************************************
++module
++outline
  uint16 �^�̃J�E���^���C���N�������g����
++arguments
  <uint16> <>       [�J�E���^�l]
  <uint16> <count>  [����]
  <uint16> <max>    [�J�E���^�̍ő�l]
++supp
  [Traceability]
    ����
++end_module
******************************************************************************/
uint16 ui16_IncCount(uint16 count,uint16 max){
    if( count < max){
        count++;
    }
    else{
        ;
    }
    return(count);
}
/******************************************************************************
++module
++outline
  uint16 �^�̃J�E���^���f�N�������g����B
  �f�N�������g�̌��ʂ� 0�����ɂȂ�ꍇ�́A�o�͂� 0 �ɂ���
++arguments
  <uint16> <>       [�J�E���^�l]
  <uint16> <count>  [����]
++supp
  [Traceability]
    ����
++end_module
******************************************************************************/
uint16 ui16_DecCount(uint16 count){
    if( count != 0){
        count--;
    }
    else{
        ;
    }
    return(count);
}

/******************************************************************************
++module
++outline
++arguments
  <void> <> [�߂�l�Ȃ�]
  <void> <> [�����Ȃ�]
++supp
  [Traceability]
++end_module
******************************************************************************/
sint32 si32_SelectMinN(sint32 *in, sint32 num){
    sint32 out = NAP_SINT32MAX;
    sint32 i;
    for(i=0;i<num;i++){
        if(in[i] < out){
            out = in[i];
        }
        else{
            ;
        }
    }
    return(out);
}
/******************************************************************************
++module
++outline
++arguments
  <void> <> [�߂�l�Ȃ�]
  <void> <> [�����Ȃ�]
++supp
  [Traceability]
++end_module
******************************************************************************/
sint32 si32_SelectMaxN(sint32 *in, sint32 num){
    sint32 out = NAP_SINT32MIN;
    sint32 i;
    for(i=0;i<num;i++){
        if(in[i] > out){
            out = in[i];
        }
        else{
            ;
        }
    }
    return(out);
}

/******************************************************************************
++module
++outline
  ���� data �������O�o�b�t�@ ring �ɒǉ�����
++arguments
  <void> <>       [�߂�l����]
  <sint32> <data> [���̓f�[�^]
  <T_RING_BUFF*> <ring> [�����O�o�b�t�@�ւ̃|�C���^]
++supp
  [Traceability]
    ����
++end_module
******************************************************************************/
void v_PushRingBuffS16(sint16 data,  T_RING_BUFF_S16 *ring){
    uint16 pos;
    sint16 *buff;
    buff = ring->Buff;
    pos = ring->Pos + 1;
    if(pos >= ring->Size ){
        pos = 0;
    }
    else{
        ;
    }
    ring->Pos = pos;
    buff[pos] = data;
}

/******************************************************************************
++module
++outline
  �����O�o�b�t�@ ring ���� �Apos �O�̃f�[�^�����o��
++arguments
  <sint32> <>    [���o�����l]
  <sint32> <pos> [���o���ʒu]
  <T_RING_BUFF*> <ring> [�����O�o�b�t�@�ւ̃|�C���^]
++supp
  [Traceability]
    ����
++end_module
******************************************************************************/
sint16 si16_GetRingBuffS16(uint16 pos,  T_RING_BUFF_S16 *ring){
    sint16 out;
    uint16 target;
    sint16 *buff;
    buff = ring->Buff;
    if( pos >= ring->Size){
        target = ring->Pos;
    }
    else{
        if( ring->Pos >= pos){
            target = (uint16)(ring->Pos - pos);
        }
        else{
            target = (uint16)(ring->Size - ( pos - ring->Pos ));
        }
    }
    out = buff[target];
    return(out);
}

/******************************************************************************
++module
++outline
  ���� data �������O�o�b�t�@ ring �ɒǉ�����
++arguments
  <void> <>       [�߂�l����]
  <sint32> <data> [���̓f�[�^]
  <T_RING_BUFF*> <ring> [�����O�o�b�t�@�ւ̃|�C���^]
++supp
  [Traceability]
    ����
++end_module
******************************************************************************/
void v_PushRingBuffU16(uint16 data,  T_RING_BUFF_U16 *ring){
    uint16 pos;
    uint16 *buff;
    buff = ring->Buff;
    pos = ring->Pos + 1;
    if(pos >= ring->Size ){
        pos = 0;
    }
    else{
        ;
    }
    ring->Pos = pos;
    buff[pos] = data;
}

/******************************************************************************
++module
++outline
  �����O�o�b�t�@ ring ���� �Apos �O�̃f�[�^�����o��
++arguments
  <sint32> <>    [���o�����l]
  <sint32> <pos> [���o���ʒu]
  <T_RING_BUFF*> <ring> [�����O�o�b�t�@�ւ̃|�C���^]
++supp
  [Traceability]
    ����
++end_module
******************************************************************************/
uint16 ui16_GetRingBuffU16(uint16 pos,  T_RING_BUFF_U16 *ring){
    uint16 out;
    uint16 target;
    uint16 *buff;
    buff = ring->Buff;
    if( pos >= ring->Size){
        target = ring->Pos;
    }
    else{
        if( ring->Pos >= (uint32)pos){
            target = (uint16)(ring->Pos - pos);
        }
        else{
            target = (uint16)(ring->Size - ( pos - ring->Pos ));
        }
    }
    out = buff[target];
    return(out);
}

/******************************************************************************
++module
++outline
  ���� in ���ő� max, �ŏ� min �Ńt�B���^�����O�����l��Ԃ�
++arguments
  <sint32> <> [�t�B���^��̒l]
  <sint32> <max> [�ő�l]
  <sint32> <min> [�ŏ��l]
++supp
  [Traceability]
    ����
++end_module
******************************************************************************/
sint32 si32_FiltMaxMin( sint32 in, sint32 max, sint32 min){
    sint32 out,tmp;
    tmp = si32_SelectMin(in,max);
    out = si32_SelectMax(tmp,min);
    return(out);
}

/******************************************************************************
++module
++outline
  a,b�̑傫���ق���Ԃ�
++arguments
  <sint32> <> [�o��]
  <sint32> <a> [����1]
  <sint32> <b> [����2]
++supp
  [Traceability]
    ����
++end_module
******************************************************************************/
sint32 si32_SelectMax( sint32 a, sint32 b ){
    sint32 out;
    if( a > b ){
        out = a;
    }
    else{
        out = b;
    }
    return(out);
}

/******************************************************************************
++module
++outline
  a,b�̏������ق���Ԃ�
++arguments
  <sint32> <> [�o��]
  <sint32> <a> [����1]
  <sint32> <b> [����2]
++supp
  [Traceability]
    ����
++end_module
******************************************************************************/
sint32 si32_SelectMin( sint32 a, sint32 b ){
    sint32 out;
    if( a < b ){
        out = a;
    }
    else{
        out = b;
    }
    return(out);
}

/******************************************************************************
++module
++outline
  ���� in �̐�Βl��Ԃ�
++arguments
  <sint32> <> [��Βl]
  <sint32> <in> [����]
++supp
  [Traceability]
    ����
++end_module
******************************************************************************/
sint32 si32_CalcAbs(sint32 in){
    sint32 out;
    if( in < 0){
        if( in == 0x80000000){
            in = 0x80000001;
        }
        else{
            ;
        }
        out = -1*in;
    }
    else{
        out = in;
    }
    return(out);
}

/******************************************************************************
++module
++outline
  ���͔z�� buff ���� num ���̕��ϒl��Ԃ�
++arguments
  <sint32> <> [���ϒl]
  <sint32> <num> [�v�f��]
  <T_RING_BUFF*> <buff> [�����O�o�b�t�@�ւ̃|�C���^]
++supp
  [Traceability]
    ����
++end_module
******************************************************************************/
sint32 si32_CalcAverage(sint32 num, T_RING_BUFF *buff){
    sint32 out=0;
    if( (num == 0) || (num >= (sint32)buff->Size) ){
        out = si32_GetRingBuff(0,buff);
    }
    else{
        sint32 i;
        for(i=0;i<=num;i++){
            out += si32_GetRingBuff(i,buff);
        }
        out /= (num+1);
    }
    return(out);
}

/******************************************************************************
++module
++outline
++arguments
++supp
  [Traceability]
    ����
++end_module
******************************************************************************/
#if (DYNAMIC_EMULATOR || LITTLE_ENDIAN_SW) /*** little endian ***//* ���g���G���f�B�A���Ή� Task #8556 */
typedef struct{
    uint32 fraction :23;
    uint32 exponent :8;
    uint32 sign     :1;
}T_IEE754_FLOAT;
typedef struct{
    uint32 fraction2 :32;
    uint32 fraction1 :20;
    uint32 exponent  :11;
    uint32 sign      :1;
}T_IEE754_DOUBLE;
#else /* DYNAMIC_EMULATOR */
#if 1 /* �ǂ����� */
typedef struct{
    uint32 sign     :1;
    uint32 exponent :8;
    uint32 fraction :23;
}T_IEE754_FLOAT;
typedef struct{
    uint32 sign      :1;
    uint32 exponent  :11;
    uint32 fraction1 :20;
    uint32 fraction2 :32;
}T_IEE754_DOUBLE;
#else
typedef struct{
    uint32 fraction :23;
    uint32 exponent :8;
    uint32 sign     :1;
}T_IEE754_FLOAT;
typedef struct{
    uint32 fraction2 :32;
    uint32 fraction1 :20;
    uint32 exponent  :11;
    uint32 sign      :1;
}T_IEE754_DOUBLE;
#endif
#endif /* DYNAMIC_EMULATOR */

FLOAT fl_Fix2Float(sint32 in, sint32 in_pos ){
    volatile	FLOAT out;
    volatile	T_IEE754_FLOAT  *p;

    if(in == 0){
        out = 0;                                        /* 0�͗�O�l�̂��� */
    }
    else{
        out = (FLOAT)in;
        p = (T_IEE754_FLOAT*)&out;
        if(p->exponent != 255){
            p->exponent -= in_pos;
        }
        else{
            ;                                           /* �w����255�̎�(������NaN�l)�͉������Ȃ� */
        }
    }

    return(out);
}
sint32 si32_Float2Fix( FLOAT in, sint32 out_pos){
    volatile	sint32          out;
    volatile	FLOAT           buff;
    volatile	T_IEE754_FLOAT  *p;

    buff = in;
    p = (T_IEE754_FLOAT*)&buff;

    if(in == 0){
        out = 0;
    }
    else if(p->exponent == 255){
        if(p->sign == 0){
            out = NAP_SINT32MAX;
        }
        else{
            out = NAP_SINT32MIN;
        }
    }
    else{
        p->exponent += out_pos;

        if( buff >= NAP_FL2FIX_MAX_LIM){                /* SINT32MIN��Float�^�ɃL���X�g����Ɖ����������������邽�� */
            out = NAP_SINT32MAX;
        }
        else if( buff <= NAP_FL2FIX_MIN_LIM ){           /* SINT32MIN��Float�^�ɃL���X�g����Ɖ����������������邽�� */
            out = NAP_SINT32MIN;
        }
        else{
            out = (sint32)buff;
        }
    }
    return(out);
}

DOUBLE db_Fix2Double(sint32 in, sint32 in_pos ){
    volatile	DOUBLE out;
    volatile	T_IEE754_DOUBLE  *p;

    if(in == 0){
        out = 0;                                    /* 0�͗�O�l�̂��� */
    }
    else{
        out = (DOUBLE)in;
        p = (T_IEE754_DOUBLE*)&out;
        if(p->exponent != 2047){
            p->exponent -= in_pos;
        }
        else{
            ;                                       /* �w����255�̎�(������NaN�l)�͉������Ȃ� */
        }
    }
    return(out);
}
sint32 si32_Double2Fix( DOUBLE in, sint32 out_pos){
    volatile	sint32          out;
    volatile	DOUBLE          buff;
    volatile	T_IEE754_DOUBLE *p;

    buff = in;
    p = (T_IEE754_DOUBLE*)&buff;
    if(in == 0){
        out = 0;
    }
    else if(p->exponent == 255){
        if(p->sign  == 0){
            out = NAP_SINT32MAX;
        }
        else{
            out = NAP_SINT32MIN;
        }
    }
    else{
        p->exponent += out_pos;

        if( buff > (DOUBLE)NAP_SINT32MAX){
            out = NAP_SINT32MAX;
        }
        else if( buff < (DOUBLE)NAP_SINT32MIN){
            out = NAP_SINT32MIN;
        }
        else{
            out = (sint32)buff;
        }
    }
    return(out);
}

/******************************************************************************
++module
++outline
  ����Z���v�Z����(x/y)
++arguments
  <sint32> <>       [���Z����]
  <sint32> <x>      [x]
  <sint32> <x_pos>  [x��2^0�̃r�b�g�ʒu]
  <sint32> <y>      [y]
  <sint32> <y_pos>  [y��2^0�̃r�b�g�ʒu]
  <sint32*> <z>     [z(�o�͌���)]
  <sint32> <z_pos>  [�o�͂�2^0�̃r�b�g�ʒu]
++supp
  [Traceability]
    ����
++end_module
******************************************************************************/
sint32 n_CalcSint32Div(sint32 x, sint32 x_pos, sint32 y, sint32 y_pos, sint32 *z, sint32 z_pos){

    if(y == 0){     /* 0���� */
        *z = x;
    }
    else{
        volatile FLOAT tmp1, tmp2;
        uint8 judgment;

        tmp1 = fl_Fix2Float(x,x_pos);
        tmp2 = tmp1 / fl_Fix2Float(y,y_pos);
        judgment = ui8_GetFPSCR_Cause() & 0x3E;
        tmp2 = fl_FpscrCauseCheck(tmp2, tmp1, judgment);
        *z = si32_Float2Fix(tmp2,z_pos);
    }
    return(0);
}

/******************************************************************************
++module
++outline
  �����Z���v�Z����(x*y)
++arguments
  <sint32> <>       [���Z����]
  <sint32> <x>      [x]
  <sint32> <x_pos>  [x��2^0�̃r�b�g�ʒu]
  <sint32> <y>      [y]
  <sint32> <y_pos>  [y��2^0�̃r�b�g�ʒu]
  <sint32*> <z>     [z(�o�͌���)]
  <sint32> <z_pos>  [�o�͂�2^0�̃r�b�g�ʒu]
++supp
  [Traceability]
    ����
++end_module
******************************************************************************/
sint32 n_CalcSint32Mul(sint32 x, sint32 x_pos, sint32 y,sint32 y_pos, sint32 *z, sint32 z_pos){
    volatile FLOAT tmp1, tmp2;
    uint8 judgment;

    tmp1 = fl_Fix2Float(x,x_pos);
    tmp2 = tmp1 * fl_Fix2Float(y,y_pos);
    judgment = ui8_GetFPSCR_Cause() & 0x3E;
    tmp2 = fl_FpscrCauseCheck(tmp2, tmp1, judgment);
    *z = si32_Float2Fix(tmp2,z_pos);

    return(0);
}
/******************************************************************************
++module
++outline
  ���� data �������O�o�b�t�@ ring �ɒǉ�����
++arguments
  <void> <>       [�߂�l����]
  <sint32> <data> [���̓f�[�^]
  <T_RING_BUFF*> <ring> [�����O�o�b�t�@�ւ̃|�C���^]
++supp
  [Traceability]
    ����
++end_module
******************************************************************************/
void v_PushRingBuff(sint32 data,  T_RING_BUFF *ring){
    uint16 pos;
    sint32 *buff;
    buff = ring->Buff;
    pos = ring->Pos + 1;
    if(pos >= ring->Size ){
        pos = 0;
    }
    else{
        ;
    }
    ring->Pos = pos;
    buff[pos] = data;
}

/******************************************************************************
++module
++outline
  �����O�o�b�t�@ ring ���� �Apos �O�̃f�[�^�����o��
++arguments
  <sint32> <>    [���o�����l]
  <sint32> <pos> [���o���ʒu]
  <T_RING_BUFF*> <ring> [�����O�o�b�t�@�ւ̃|�C���^]
++supp
  [Traceability]
    ����
++end_module
******************************************************************************/
sint32 si32_GetRingBuff(uint16 pos,  T_RING_BUFF *ring){
    sint32 out;
    uint16 target;
    sint32 *buff;
    buff = ring->Buff;
    if( (uint32)pos >= ring->Size){
        target = ring->Pos;
    }
    else{
        if( ring->Pos >= (uint32)pos){
            target = (uint16)(ring->Pos - pos);
        }
        else{
            target = (uint16)(ring->Size - ( pos - ring->Pos ));
        }
    }
    out = buff[target];
    return(out);
}

/******************************************************************************
++module
++outline
  2�����}�b�v����
++arguments
  <sint32> <>       [�߂�l����]
  <sint32> <x>      [����]
  <T_2D_MAP*> <map> [MAP�ւ̃|�C���^]
++supp
  [Traceability]
    ����
++end_module
******************************************************************************/
sint32 si32_Read2DMap(sint32 x, const T_2D_MAP *map){
    sint32 out;
    
    if( x <= map->body[0].x ){
        out = map->body[0].y;
    }
    else if( x >= map->body[map->x_size-1].x ){
        out = map->body[map->x_size-1].y;
    }
    else{
        UINT l,r,idx;
        sint32 dx,dy,dt;
        l = 0;
        r = map->x_size - 1;
        while( l < (r-1) ){
            idx = (l+r) >> 1;
            if( x < map->body[idx].x ){
                r = idx;
            }
            else{
                l = idx;
            }
        }
        dx = map->body[r].x - map->body[l].x;
        dy = map->body[r].y - map->body[l].y;
        dt = x - map->body[l].x;
        (void)n_CalcSint32Mul(dy,0,dt,0,&out,0);
        (void)n_CalcSint32Div(out,0,dx,0,&out,0);
        out += map->body[l].y;
    }
    return(out);
}

/******************************************************************************
++module
++outline
  2�����}�b�v����
++arguments
  <FLOAT> <>           [�߂�l����]
  <FLOAT> <x>          [����]
  <T_FL_2D_MAP*> <map> [MAP�ւ̃|�C���^]
++supp
  [Traceability]
    ����
++end_module
******************************************************************************/
FLOAT fl_Read2DMap(FLOAT x, const T_FL_2D_MAP *map){
    FLOAT out;

    if( x <= map->body[0].x ){
        out = map->body[0].y;
    }
    else if( x >= map->body[map->x_size-1].x ){
        out = map->body[map->x_size-1].y;
    }
    else{
        UINT l,r,idx;
        FLOAT dx,dy,dt;
        l = 0;
        r = map->x_size - 1;
        while( l < (r-1) ){
            idx = (l+r) >> 1;
            if( x < map->body[idx].x ){
                r = idx;
            }
            else{
                l = idx;
            }
        }

        dx = map->body[r].x - map->body[l].x;
        dy = map->body[r].y - map->body[l].y;
        dt = x - map->body[l].x;

        out = fl_CalcLinearComplementarity(dy, dx, map->body[l].y, dt);
    }
    return(out);
}

sint32 si32_ReadHi2DMap(sint32 *output_table, sint32 *input_table, sint32 x, uint32 x_size){
    sint32 out;

    if( x <= input_table[0] ){
        out = output_table[0];
    }
    else if( x >= input_table[x_size-1] ){
        out = output_table[x_size-1];
    }
    else{
        UINT l,r,idx;
        sint32 dx,dy,dt;
        l = 0;
        r = x_size - 1;
        while( l < (r-1) ){
            idx = (l+r) >> 1;
            if( x < input_table[idx] ){
                r = idx;
            }
            else{
                l = idx;
            }
        }
        dx = input_table[r] - input_table[l];
        dy = output_table[r] - output_table[l];
        dt = x - input_table[l];
        (void)n_CalcSint32Mul(dy,0,dt,0,&out,0);
        (void)n_CalcSint32Div(out,0,dx,0,&out,0);
        out += output_table[l];
    }
    return(out);
}

FLOAT fl_ReadHi2DMap(FLOAT *output_table, FLOAT *input_table, FLOAT x, uint32 x_size){
    FLOAT out;

    if( x <= input_table[0] ){
        out = output_table[0];
    }
    else if( x >= input_table[x_size-1] ){
        out = output_table[x_size-1];
    }
    else{
        UINT l,r,idx;
        FLOAT dx,dy,dt;
        l = 0;
        r = x_size - 1;
        while( l < (r-1) ){
            idx = (l+r) >> 1;
            if( x < input_table[idx] ){
                r = idx;
            }
            else{
                l = idx;
            }
        }
        dx = (sint32)(input_table[r] - input_table[l]);
        dy = (sint32)(output_table[r] - output_table[l]);
        dt = (sint32)(x - input_table[l]);

        out = fl_CalcLinearComplementarity(dy, dx, output_table[l], dt);
    }
    return(out);
}
/******************************************************************************
++module
++outline
  3�����}�b�v����
++arguments
  <FLOAT> <>           [�߂�l����]
  <FLOAT> <x>          [����]
  <FLOAT> <y>          [����]
  <T_FL_3D_MAP*> <map> [MAP�ւ̃|�C���^]
++supp
  [Traceability]
    ����
++end_module
******************************************************************************/
FLOAT fl_Read3DMap(FLOAT x, FLOAT y, const T_FL_3D_MAP *map){
    FLOAT out;
    FLOAT z1, z2, z3, z4;
    FLOAT dx, dy, dtx, dty;
    uint32 x_pos_lo, x_pos_hi, y_pos_lo, y_pos_hi;

    /* x��lo_position��hi_position��T�� */
    v_SeachFlArrayPosition(x, &map->x[0], map->x_size, &x_pos_lo, &x_pos_hi);

    /* y��lo_position��hi_position��T�� */
    v_SeachFlArrayPosition(y, &map->y[0], map->y_size, &y_pos_lo, &y_pos_hi);

    /* 4�_��Z�l���擾 */
    z1  = *(&map->z[0] + (y_pos_lo * map->x_size) + x_pos_lo);  /* Y:����, X:���� */
    z2  = *(&map->z[0] + (y_pos_hi * map->x_size) + x_pos_lo);  /* Y:���, X:���� */
    z3  = *(&map->z[0] + (y_pos_lo * map->x_size) + x_pos_hi);  /* Y:����, X:��� */
    z4  = *(&map->z[0] + (y_pos_hi * map->x_size) + x_pos_hi);  /* Y:���, X:��� */

    dx  = map->x[x_pos_hi] - map->x[x_pos_lo];
    dy  = map->y[y_pos_hi] - map->y[y_pos_lo];
    dtx = x - map->x[x_pos_lo];
    dty = y - map->y[y_pos_lo];

    if((x_pos_lo == x_pos_hi) && (y_pos_lo == y_pos_hi)){
        out = z1;
    }
    else if(x_pos_lo == x_pos_hi){
        out = fl_CalcLinearComplementarity((z2 - z1), dy, z1, dty);
    }
    else if(y_pos_lo == y_pos_hi){
        out = fl_CalcLinearComplementarity((z3 - z1), dx, z1, dtx);
    }
    else{
        FLOAT Za, Zb;
        Za  = fl_CalcLinearComplementarity((z2 - z1), dy, z1, dty);
        Zb  = fl_CalcLinearComplementarity((z4 - z3), dy, z3, dty);
        out = fl_CalcLinearComplementarity((Zb - Za), dx, Za, dtx);
    }
    return(out);
}

/******************************************************************************
++module
++outline
  ���͔z��ɑ΂����̓f�[�^�̃o�C�i���T�[�`���s��
++arguments
  <void> <>            [�߂�l����]
  <FLOAT> <in_data>    [���̓f�[�^]
  <FLOAT> <array>      [���͔z��]
  <uint32> <size>      [�z��T�C�Y]
  <uint32*> <lo_pos>   [�o��LowPosition]
  <uint32*> <hi_pos>   [�o��Hi Position]
++supp
  [Traceability]
    ����
++end_module
******************************************************************************/
void v_SeachFlArrayPosition(FLOAT in_data, const FLOAT * array, uint32 size, uint32 * lo_pos, uint32 * hi_pos){
    if(in_data <= array[0]){
        *lo_pos = *hi_pos = 0;
    }
    else if(in_data >= array[size - 1]){
        *lo_pos = *hi_pos = size - 1;
    }
    else{
        uint32 id;

        *lo_pos = 0;
        *hi_pos = size - 1;
        while(*lo_pos < (*hi_pos -1)){
            id = (*lo_pos + *hi_pos) >> 1;
            if(in_data < array[id]){
                *hi_pos = id;
            }
            else if(in_data > array[id]){
                *lo_pos = id;
            }
            else{
                *hi_pos = *lo_pos = id;
            }
        }
    }
}

/******************************************************************************
++module
++outline
  ���`��Ԃ��s��
++arguments
  <FLOAT> <>        [�߂�l����]
  <FLOAT> <dy>      [Y���̍�]
  <FLOAT> <dx>      [X���̍�]
  <FLOAT> <base>    [Y0�̒l]
  <FLOAT> <dt>      [X-X0�̒l]
++supp
  [Traceability]
    ����
++end_module
******************************************************************************/
FLOAT fl_CalcLinearComplementarity(FLOAT dy, FLOAT dx, FLOAT base, FLOAT dt){
    volatile FLOAT out,temp;
    uint8 cause1, cause2, cause3, cause4;

    if(dx == 0){
        out = base;
    }
    else{
        out = dy * dt;
        cause2 = ui8_GetFPSCR_Cause() & 0x3E;
        out = fl_FpscrCauseCheck(out, dy, cause2);

        temp = out / dx;
        cause3 = ui8_GetFPSCR_Cause() & 0x3E;
        out = fl_FpscrCauseCheck(temp, out, cause3);

        temp = base + out;
        cause4 = ui8_GetFPSCR_Cause() & 0x3E;
        out = fl_FpscrCauseCheck(temp, base, cause4);
    }
    return(out);
}

/******************************************************************************
++module
++outline
  FPU��O�`�F�b�N
++arguments
  <double> <>         [�o�͒l]
  <uint8> <cause>     [FPSCR_cause]
  <double> <val>      [���͒l]
  <double> <init_val> [�G���[��init�l]
++supp
  [Traceability]
    ����
++end_module
******************************************************************************/
FLOAT fl_FpscrCauseCheck(FLOAT val, FLOAT init_val, uint8 cause){
    FLOAT out;

    if( cause != 0){
        cause &= mCause_UNDERFLOW;
        if( cause != 0 ){
            out = 0;
        }
        else{
            out = init_val;
        }
    }
    else{
        out = val;
    }
    return(out);
}
DOUBLE db_FpscrCauseCheck(DOUBLE val, DOUBLE init_val, uint8 cause){
    DOUBLE out;

    if( cause != 0){
        cause &= mCause_UNDERFLOW;
        if( cause != 0 ){
            out = 0;
        }
        else{
            out = init_val;
        }
    }
    else{
        out = val;
    }
    return(out);
}

/* ##########################################################################################################
++module
++outline
++arguments
   <void> <> [�߂�l����]
   <void> <void> [��������]
++supp
   [Traceability]
   �Ȃ�
++end_module
############################################################################################################## */
void v_SetAllRingBuff(sint32 val, T_RING_BUFF *in){
    sint32 *buff;
    uint32 i;
    buff = in->Buff;
    for(i=0;i<in->Size;i++){
        buff[i]=val;
    }
    in->Pos = 0;
}

/* ##########################################################################################################
++module
++outline
++arguments
   <void> <> [�߂�l����]
   <void> <void> [��������]
++supp
   [Traceability]
   �Ȃ�
++end_module
############################################################################################################## */
void v_ClearRingBuff( T_RING_BUFF *ring ){
    v_SetAllRingBuff(0,ring);
}

/* ##########################################################################################################
++module
++outline
++arguments
   <void> <> [�߂�l����]
   <void> <void> [��������]
++supp
   [Traceability]
   �Ȃ�
++end_module
############################################################################################################## */
void v_SetAllRingBuffS16(sint16 val, T_RING_BUFF_S16 *in){
    sint16 *buff;
    uint32 i;
    buff = in->Buff;
    for(i=0;i<in->Size;i++){
        buff[i]=val;
    }
    in->Pos = 0;
}

/* ##########################################################################################################
++module
++outline
++arguments
   <void> <> [�߂�l����]
   <void> <void> [��������]
++supp
   [Traceability]
   �Ȃ�
++end_module
############################################################################################################## */
void v_ClearRingBuffS16( T_RING_BUFF_S16 *ring ){
    v_SetAllRingBuffS16((sint16)0,ring);
}
/* ##########################################################################################################
++module
++outline
++arguments
   <void> <> [�߂�l����]
   <void> <void> [��������]
++supp
   [Traceability]
   �Ȃ�
++end_module
############################################################################################################## */
void v_SetAllRingBuffU16(uint16 val, T_RING_BUFF_U16 *in){
    uint16 *buff;
    uint32 i;
    buff = in->Buff;
    for(i=0;i<in->Size;i++){
        buff[i]=val;
    }
    in->Pos = 0;
}

/* ##########################################################################################################
++module
++outline
++arguments
   <void> <> [�߂�l����]
   <void> <void> [��������]
++supp
   [Traceability]
   �Ȃ�
++end_module
############################################################################################################## */
void v_ClearRingBuffU16( T_RING_BUFF_U16 *ring ){
    v_SetAllRingBuffU16((uint16)0,ring);
}
/* ##########################################################################################################
++module
++outline
++arguments
   <void> <> [�߂�l����]
   <void> <void> [��������]
++supp
   [Traceability]
   �Ȃ�
++end_module
############################################################################################################## */
uint8 ui8_ActOnOff(uint8 *out,uint8 *mode, const T_ON_OFF_PATTERN * const pat, uint16 *cnt){
    uint8 stat = NAP_IDLE;

    if( *mode == NO_NEXT_WITH_OFF){
        *out = NAP_OFF;
    }
    else if( *mode == NO_NEXT_WITH_ON){
        *out = NAP_ON;
    }
    else{
        const T_ON_OFF_PATTERN *p;
        
        p = &pat[*mode];
        *out = p->Out;
        *cnt += 1;
        stat = NAP_BUSY;
        if( *cnt >= *(p->Time)){
            *cnt    = 0;
            *mode   = p->Next;
            if( (p->Chara &  CHAR_END) != 0x00){
                stat = NAP_IDLE;
            }
        }
    }
    return(stat);
}

/* ##########################################################################################################
++module
++outline
++arguments
   <void> <> [�߂�l����]
   <void> <void> [��������]
++supp
   [Traceability]
   �Ȃ�
++end_module
############################################################################################################## */
uint16 ui16_AddCnt(uint16 count, sint16 addval, uint16 max){
    sint32 tmp;
    tmp = (sint32)count;
    tmp += (sint32)addval;
    if( tmp < 0 ){
        tmp = 0;
    }
    else if( tmp > (sint32)max){
        tmp = (sint32)max;
    }
    return((uint16)tmp);
}

/* ##########################################################################################################
++module
++outline
++arguments
   <void> <> [�߂�l����]
   <void> <void> [��������]
++supp
   [Traceability]
   �Ȃ�
++end_module
############################################################################################################## */
uint8  ui8_CheckFlagEdge(uint8 now, uint8 old, uint8 edge_type){
    uint8 out = NAP_OFF;
    switch( edge_type ){
    case CHECK_UP_EDGE:
        if( (now == NAP_ON) && (old == NAP_OFF) ){
            out = NAP_ON;
        }
        break;
    case CHECK_DOWN_EDGE:
        if( (now == NAP_OFF) && (old == NAP_ON) ){
            out = NAP_ON;
        }
        break;
    case CHECK_UPDOWN_EDGE:
        if( (now == NAP_ON) && (old == NAP_OFF) ){
            out = NAP_ON;
        }
        else if( (now == NAP_OFF) && (old == NAP_ON) ){
            out = NAP_ON;
        }
        break;
    default:
        break;
    }
    return(out);
}

/* ##########################################################################################################
++module
++outline
++arguments
   <void> <> [�߂�l����]
   <void> <void> [��������]
++supp
   [Traceability]
   �Ȃ�
++end_module
############################################################################################################## */
const uint8 CRC_8_SAE_1850_TABLE[256] ={
    0x00, 0x1D, 0x3A, 0x27, 0x74, 0x69, 0x4E, 0x53,
    0xE8, 0xF5, 0xD2, 0xCF, 0x9C, 0x81, 0xA6, 0xBB,
    0xCD, 0xD0, 0xF7, 0xEA, 0xB9, 0xA4, 0x83, 0x9E,
    0x25, 0x38, 0x1F, 0x02, 0x51, 0x4C, 0x6B, 0x76,
    0x87, 0x9A, 0xBD, 0xA0, 0xF3, 0xEE, 0xC9, 0xD4,
    0x6F, 0x72, 0x55, 0x48, 0x1B, 0x06, 0x21, 0x3C,
    0x4A, 0x57, 0x70, 0x6D, 0x3E, 0x23, 0x04, 0x19,
    0xA2, 0xBF, 0x98, 0x85, 0xD6, 0xCB, 0xEC, 0xF1,
    0x13, 0x0E, 0x29, 0x34, 0x67, 0x7A, 0x5D, 0x40,
    0xFB, 0xE6, 0xC1, 0xDC, 0x8F, 0x92, 0xB5, 0xA8,
    0xDE, 0xC3, 0xE4, 0xF9, 0xAA, 0xB7, 0x90, 0x8D,
    0x36, 0x2B, 0x0C, 0x11, 0x42, 0x5F, 0x78, 0x65,
    0x94, 0x89, 0xAE, 0xB3, 0xE0, 0xFD, 0xDA, 0xC7,
    0x7C, 0x61, 0x46, 0x5B, 0x08, 0x15, 0x32, 0x2F,
    0x59, 0x44, 0x63, 0x7E, 0x2D, 0x30, 0x17, 0x0A,
    0xB1, 0xAC, 0x8B, 0x96, 0xC5, 0xD8, 0xFF, 0xE2,
    0x26, 0x3B, 0x1C, 0x01, 0x52, 0x4F, 0x68, 0x75,
    0xCE, 0xD3, 0xF4, 0xE9, 0xBA, 0xA7, 0x80, 0x9D,
    0xEB, 0xF6, 0xD1, 0xCC, 0x9F, 0x82, 0xA5, 0xB8,
    0x03, 0x1E, 0x39, 0x24, 0x77, 0x6A, 0x4D, 0x50,
    0xA1, 0xBC, 0x9B, 0x86, 0xD5, 0xC8, 0xEF, 0xF2,
    0x49, 0x54, 0x73, 0x6E, 0x3D, 0x20, 0x07, 0x1A,
    0x6C, 0x71, 0x56, 0x4B, 0x18, 0x05, 0x22, 0x3F,
    0x84, 0x99, 0xBE, 0xA3, 0xF0, 0xED, 0xCA, 0xD7,
    0x35, 0x28, 0x0F, 0x12, 0x41, 0x5C, 0x7B, 0x66,
    0xDD, 0xC0, 0xE7, 0xFA, 0xA9, 0xB4, 0x93, 0x8E,
    0xF8, 0xE5, 0xC2, 0xDF, 0x8C, 0x91, 0xB6, 0xAB,
    0x10, 0x0D, 0x2A, 0x37, 0x64, 0x79, 0x5E, 0x43,
    0xB2, 0xAF, 0x88, 0x95, 0xC6, 0xDB, 0xFC, 0xE1,
    0x5A, 0x47, 0x60, 0x7D, 0x2E, 0x33, 0x14, 0x09,
    0x7F, 0x62, 0x45, 0x58, 0x0B, 0x16, 0x31, 0x2C,
    0x97, 0x8A, 0xAD, 0xB0, 0xE3, 0xFE, 0xD9, 0xC4
};

uint8 ui8_NIF_Make_CRC_8_SAE_1850(uint8 *in, uint32 size){
    uint32 i;
    uint8 crc = 0xff;
    uint8 tmp;
    
    for(i=0;i<size;i++){
        tmp = crc ^ in[i];
        crc = CRC_8_SAE_1850_TABLE[tmp];
    }
    crc ^= 0xff;
    
    return(crc);
}

uint32 unNIF_Check_CRC_8_SAE_1850(uint8 orig_crc, uint8 *in, uint32 size){
    uint8 crc = 0xff;
    uint32 out = 0;

    crc = ui8_NIF_Make_CRC_8_SAE_1850(in,size);
    if( orig_crc != crc ){
        out = 1;
    }	
#if 1	
    return(out);
#else /* �b�� */
	return(0);
#endif	
}

FLOAT fl_CalcFlAdd(FLOAT a, FLOAT b){
    volatile FLOAT out;
    uint8 judgment;

    out = a + b;
    judgment = ui8_GetFPSCR_Cause() & 0x3E;
    out = fl_FpscrCauseCheck(out, a, judgment);

    return(out);
}

FLOAT fl_CalcFlSub(FLOAT a, FLOAT b){
    volatile FLOAT out;
    uint8 judgment;

    out = a - b;
    judgment = ui8_GetFPSCR_Cause() & 0x3E;
    out = fl_FpscrCauseCheck(out, a, judgment);

    return(out);
}

FLOAT fl_CalcFlMul(FLOAT a, FLOAT b){
    volatile FLOAT out;
    uint8 judgment;

    out = a * b;
    judgment = ui8_GetFPSCR_Cause() & 0x3E;
    out = fl_FpscrCauseCheck(out, a, judgment);

    return(out);
}

FLOAT fl_CalcFlDiv(FLOAT a, FLOAT b){
    volatile FLOAT out;
    uint8 judgment;

    if(b == 0){
        out = a;
    }
    else{
        out = a / b;
        judgment = ui8_GetFPSCR_Cause() & 0x3E;
        out = fl_FpscrCauseCheck(out, a, judgment);
    }
    return(out);
}
DOUBLE db_CalcDbAdd(DOUBLE a, DOUBLE b){
    volatile DOUBLE out;
    uint8 judgment;

    out = a + b;
    judgment = ui8_GetFPSCR_Cause() & 0x3E;
    out = db_FpscrCauseCheck(out, a, judgment);
    return(out);
}

DOUBLE db_CalcDbSub(DOUBLE a, DOUBLE b){
    volatile DOUBLE out;
    uint8 judgment;

    out = a - b;
    judgment = ui8_GetFPSCR_Cause() & 0x3E;
    out = db_FpscrCauseCheck(out, a, judgment);
    return(out);
}

DOUBLE db_CalcDbMul(DOUBLE a, DOUBLE b){
    volatile DOUBLE out;
    uint8 judgment;

    out = a * b;
    judgment = ui8_GetFPSCR_Cause() & 0x3E;
    out = db_FpscrCauseCheck(out, a, judgment);
    return(out);
}

DOUBLE db_CalcDbDiv(DOUBLE a, DOUBLE b){
    volatile DOUBLE out;
    uint8 judgment;

    if(b == 0){
        out = a;
    }
    else{
        out = a / b;
        judgment = ui8_GetFPSCR_Cause() & 0x3E;
        out = db_FpscrCauseCheck(out, a, judgment);
    }
    return(out);
}
/*----------------------------------------------------------------------------*/
/* function name -  fl_abs			                          				  */
/*----------------------------------------------------------------------------*/
FLOAT fl_abs(FLOAT abs_val)
{
	FLOAT abs_calc_val = 0.0f;

	if(abs_val < 0.0f)
	{
		abs_calc_val = -abs_val;
	}
	else
	{
		abs_calc_val = abs_val;
	}

	return abs_calc_val;
}
FLOAT fl_FiltMaxMin( FLOAT in, FLOAT max, FLOAT min ){
    FLOAT out;
    if( max < min ){		/* 臒l�ُ� */
        out = in;
    }
    else if( in > max ){	/* �ő�l */
        out = max;
    }
    else if( in < min ){	/* �ŏ��l */
        out = min;
    }
    else{					/* 臒l�� */
        out = in;
    }
    return(out);
}
/* #######################################################################################################
++module    FLOAT   fl_SelectMax(FLOAT a, FLOAT b);
++outline
++arguments
++supp
++ end_module
############################################################################################################# */
FLOAT	Select_Hi_fl(FLOAT in1,	FLOAT in2)
{
	FLOAT out;
	if(in1 > in2){
		out = in1;
	}
	else{
		out = in2;
	}
	return(out);
}
/* #######################################################################################################
++module    FLOAT   Select_Lo_fl(FLOAT in1,	FLOAT in2);
++outline
++arguments
++supp
++ end_module
############################################################################################################# */
FLOAT	Select_Lo_fl(FLOAT in1,	FLOAT in2)
{
	FLOAT out;
	if(in1 < in2){
		out = in1;
	}
	else{
		out = in2;
	}
	return(out);
}
/* #######################################################################################################
++module    FLOAT   fl_sin_calc(FLOAT s_val);
++outline
++arguments
++supp
++ end_module
############################################################################################################# */
FLOAT fl_sin_calc(FLOAT s_val){
	/* 
	 * sin x = x - x^3/3! + x^5/5! - X^7/7! + X^9/9! - X^11/11! + X^13/13! \
	 * - X^15/15! + X^17/17! - X^19/19! + X^21/21! - X^23/23!;
	 */
 	/* + X^25/25! - X^27/27! + X^29/29! - X^31/31! + X^33/33! - X^35/35! \
	 *	+ X^37/37! - X^39/39! + X^41/41! - X^43/43!
	 */

	FLOAT sinvalue = NAP_FLOAT_ZERO;
	FLOAT sinval_sqare = NAP_FLOAT_ZERO;
	FLOAT sinval_cube = NAP_FLOAT_ZERO;

	FLOAT temp_val1 = NAP_FLOAT_ZERO;
	FLOAT temp_val2 = NAP_FLOAT_ZERO;
	FLOAT temp_val3 = NAP_FLOAT_ZERO;
	FLOAT temp_val4 = NAP_FLOAT_ZERO;
	FLOAT temp_val5 = NAP_FLOAT_ZERO;
	FLOAT temp_val6 = NAP_FLOAT_ZERO;
	FLOAT temp_val7 = NAP_FLOAT_ZERO;
	FLOAT temp_val8 = NAP_FLOAT_ZERO;
	FLOAT temp_val9 = NAP_FLOAT_ZERO;
	FLOAT temp_val10 = NAP_FLOAT_ZERO;
	FLOAT temp_val11 = NAP_FLOAT_ZERO;

	/* get the absolute value */
	/*s_val = fl_abs(s_val);*/

	sinvalue = s_val;
	sinval_sqare = sinvalue * sinvalue;
	sinval_cube = sinval_sqare * sinvalue;

	temp_val1 = (sinval_cube)/6.f;
	temp_val2 = (temp_val1 * sinval_sqare)/20.f;
	temp_val3 = (temp_val2*sinval_sqare)/42.f;
	temp_val4 = (temp_val3 * sinval_sqare)/72.f;
	temp_val5 = (temp_val4 * sinval_sqare)/110.f;
	temp_val6 = (temp_val5 * sinval_sqare)/156.f;
	temp_val7 = (temp_val6 * sinval_sqare)/210.f;
	temp_val8 = (temp_val7 * sinval_sqare)/272.f;
	temp_val9 = (temp_val8 * sinval_sqare)/342.f;
	temp_val10 = (temp_val9 * sinval_sqare)/420.f;
	temp_val11 = (temp_val10 * sinval_sqare)/506.f;

	sinvalue -= temp_val1;
	sinvalue += temp_val2;
	sinvalue -= temp_val3;
	sinvalue += temp_val4;
	sinvalue -= temp_val5;
	sinvalue += temp_val6;
	sinvalue -= temp_val7;
	sinvalue += temp_val8;
	sinvalue -= temp_val9;
	sinvalue += temp_val10;
	sinvalue -= temp_val11;
	return sinvalue;
}


/* #######################################################################################################
++module    FLOAT   fl_cos_calc(FLOAT s_cos_val);
++outline
++arguments
++supp
++ end_module
############################################################################################################# */
FLOAT fl_cos_calc(FLOAT s_cos_val){
	/*
	 * cos(x) = 1 - x^2/2! + x^4/4! - x^6/6! + x^8/8! - x^10/10! + x^12/12! - x^14/14! + x^16/16!
	 * - x^18/18! + x^20/20! - x^22/22! ...	
	 *
	 * x^2/2! = A
	 * x^4/4! = x^2/2! * x^2/2! * 1/6 = A * A * 1/6 = B
	 * x^6/6! = x^4/4! * x^2/(6*5) = x^4/4! * x^2/2 * 1/(3*5) = B * A * 1/15 = C
	 * x^8/8! = x^6/6! * x^2/(8*7) = x^6/6! * x^2/2 * 1/(4*7) = C * A * 1/28 = D
	 * x^10/10! = x^8/8! * x^2/(10*9) =  x^8/8! * x^2/2 * 1/(5*9) = D * A * 1/45 = E
	 * x^12/12! = x^10/10! * x^2/(12*11) = x^10/10! * x^2/2  * 1/(6*11) = E * A * 1/66 = F
	 * x^14/14! = x^12/12! * x^2/(14*13) = x^12/12! * x^2/2 * 1/(7*13) = F * A * 1/91 = G
	 * x^16/16! = x^14/14! * x^2/(16*15) = x^14/14! * x^2/2 * 1/(8*15) = G * A * 1/120 = H
	 * x^18/18! = x^16/16! * x^2/(18*17) = x^16/16! * x^2/2 * 1/(9*17) = H * A * 1/133 = I
	 * x^20/20! = x^18/18! * x^2/(20*19) = x^18/18! * x^2/2 * 1/(10*19) = I * A * 1/190 = J
	 * x^22/22! = x^20/20! * x^2/(22*21) = x^20/20! * x^2/2 * 1/(11*21) = J * A * 1/232 = K
	 * ...
	*/
	
	/*
	next factors
	 * cos(x) = 1 - x^2/2! + x^4/4! - x^6/6! + x^8/8! - x^10/10! + x^12/12! - x^14/14! + x^16/16!
	 * - x^18/18! + x^20/20! - x^22/22! 
	 * + x^24/24! - x^26/26!	
	 * x^24/24! = x^22/22! * x^2/(24*23) =x^22/22! * x^2/2! * 1/(12*23) = K * A * 1/276 = L
	 * x^26/26! = x^24/24! * x^2/(26*25) = x^24/24! * x^2/2 * 1/(13*25) = L * A * 1/325 = M
	*/

	FLOAT  cosvalue = NAP_FLOAT_ZERO;
	FLOAT  cosval_sqare = NAP_FLOAT_ZERO;
	
	FLOAT  tmpCval1 = NAP_FLOAT_ZERO; /* A */
	FLOAT  tmpCval2 = NAP_FLOAT_ZERO; /* B */
	FLOAT  tmpCval3 = NAP_FLOAT_ZERO; /* C */
	FLOAT  tmpCval4 = NAP_FLOAT_ZERO; /* D */
	FLOAT  tmpCval5 = NAP_FLOAT_ZERO; /* E */
	FLOAT  tmpCval6 = NAP_FLOAT_ZERO; /* F */
	FLOAT  tmpCval7 = NAP_FLOAT_ZERO; /* G */
	FLOAT  tmpCval8 = NAP_FLOAT_ZERO; /* H */
	FLOAT  tmpCval9 = NAP_FLOAT_ZERO; /* I */
	FLOAT  tmpCval10 = NAP_FLOAT_ZERO; /* J */
	FLOAT  tmpCval11 = NAP_FLOAT_ZERO; /* K */
	/* next factors calculation */
	FLOAT  tmpCval12 = NAP_FLOAT_ZERO; /* L */
	FLOAT  tmpCval13 = NAP_FLOAT_ZERO; /* M */

	/* get the absolute value */
	/*s_cos_val = fl_abs(s_cos_val);*/
	
	cosvalue = s_cos_val;
	cosval_sqare = cosvalue * cosvalue;
	tmpCval1 = cosval_sqare / 2.f;
	tmpCval2 = (tmpCval1 * tmpCval1) / 6.f;
	tmpCval3 = (tmpCval2 * tmpCval1) / 15.f;
	tmpCval4 = (tmpCval3 * tmpCval1) / 28.f;
	tmpCval5 = (tmpCval4 * tmpCval1) / 45.f;
	tmpCval6 = (tmpCval5 * tmpCval1) / 66.f;
	tmpCval7 = (tmpCval6 * tmpCval1) / 91.f;
	tmpCval8 = (tmpCval7 * tmpCval1) / 120.f;
	tmpCval9 = (tmpCval8 * tmpCval1) / 133.f;
	tmpCval10 = (tmpCval9 * tmpCval1) / 190.f;
	tmpCval11 = (tmpCval10 * tmpCval1) / 232.f;

	/* next factors */
	/* next factors calculation */
	tmpCval12 = (tmpCval11 * tmpCval1) / 276.f;
	tmpCval13 = (tmpCval12 * tmpCval1) / 325.f;
	
	cosvalue = 1 - tmpCval1;
	cosvalue += tmpCval2;
	cosvalue -= tmpCval3;
	cosvalue += tmpCval4;
	cosvalue -= tmpCval5;
	cosvalue += tmpCval6;
	cosvalue -= tmpCval7;
	cosvalue += tmpCval8;
	cosvalue -= tmpCval9;
	cosvalue += tmpCval10;
	cosvalue -= tmpCval11;

	/*cosvalue += tmpCval12;
	cosvalue -= tmpCval13;*/
	
	return cosvalue;
}

/* #######################################################################################################
++module    FLOAT fl_tan(FLOAT tan_value);
++outline
++arguments
++supp
++ end_module
############################################################################################################# */
#include "math_tan_tbl.c"
FLOAT fl_tan(FLOAT tan_value){
	FLOAT fl_tan_ret_val;
	uint32 fSign = NAP_OFF;
	/* get the absolute value but preserve the sign */
	if(tan_value < 0.f){
		tan_value *= -1.f;
		fSign = NAP_ON;
    }
	else{}

	if(tan_value<TAN_SERIES_EXPANSION_MAX_INP){
		 fl_tan_ret_val = fl_tan_calc(tan_value);
	}
	else{
		if((tan_value>=STRT_TAN_INP_0_8_to_0_9) && (tan_value<END_TAN_INP_0_8_to_0_9)){
			lkup_ptr_out = tan_outval_0_8_to_0_9;
			lkup_ptr_inp = tan_inpval_0_8_to_0_9;
			numofentires = SIZE_TAN_INP_0_8_to_0_9; /* 101 */
		}
		else if((tan_value>=STRT_TAN_INP_0_9_to_0_92) && (tan_value<END_TAN_INP_0_9_to_0_92)){
			lkup_ptr_out = tan_outval_0_9_to_0_92;
			lkup_ptr_inp = tan_inpval_0_9_to_0_92;
			numofentires = SIZE_TAN_INP_0_9_to_0_92; /* 21 */
		}
		else if((tan_value>=STRT_TAN_INP_0_92_to_0_98) && (tan_value<END_TAN_INP_0_92_to_0_98)){
			lkup_ptr_out = tan_outval_0_92_to_0_98;
			lkup_ptr_inp = tan_inpval_0_92_to_0_98;
			numofentires = SIZE_TAN_INP_0_92_to_0_98; /* 121 */
		}
		else if((tan_value>=STRT_TAN_INP_0_98_to_1_02) && (tan_value<END_TAN_INP_0_98_to_1_02)){
			lkup_ptr_out = tan_outval_0_98_to_1_02;
			lkup_ptr_inp = tan_inpval_0_98_to_1_02;
			numofentires = SIZE_TAN_INP_0_98_to_1_02; /* 81 */
		}
		else if((tan_value>=STRT_TAN_INP_1_02_to_1_07) && (tan_value<END_TAN_INP_1_02_to_1_07)){
			lkup_ptr_out =tan_outval_1_02_to_1_07;
			lkup_ptr_inp =tan_inpval_1_02_to_1_07;
			numofentires =SIZE_TAN_INP_1_02_to_1_07; /* 101 */
		}
		else if((tan_value>=STRT_TAN_INP_1_07_to_1_12) && (tan_value<END_TAN_INP_1_07_to_1_12)){
			lkup_ptr_out = tan_outval_1_07_to_1_12;
			lkup_ptr_inp = tan_inpval_1_07_to_1_12;
			numofentires = SIZE_TAN_INP_1_07_to_1_12; /* 101; */
		}
		else if((tan_value>=STRT_TAN_INP_1_12_to_1_17) && (tan_value<END_TAN_INP_1_12_to_1_17)){
			lkup_ptr_out = tan_outval_1_12_to_1_17;
			lkup_ptr_inp = tan_inpval_1_12_to_1_17;
			numofentires = SIZE_TAN_INP_1_12_to_1_17; /* 101 */ 
		}
		else if((tan_value>=STRT_TAN_INP_1_17_to_1_22) && (tan_value<END_TAN_INP_1_17_to_1_22)){
			lkup_ptr_out = tan_outval_1_17_to_1_22;
			lkup_ptr_inp = tan_inpval_1_17_to_1_22;
			numofentires = SIZE_TAN_INP_1_17_to_1_22; /* 101 */
		}
		else if((tan_value>=STRT_TAN_INP_1_22_to_1_27) && (tan_value<END_TAN_INP_1_22_to_1_27)){
			lkup_ptr_out = tan_outval_1_22_to_1_27;
			lkup_ptr_inp = tan_inpval_1_22_to_1_27;
			numofentires = SIZE_TAN_INP_1_22_to_1_27; /* 101 */
		}
		else if((tan_value>=STRT_TAN_INP_1_27_to_1_32) && (tan_value<END_TAN_INP_1_27_to_1_32)){
			lkup_ptr_out = tan_outval_1_27_to_1_32;
			lkup_ptr_inp = tan_inpval_1_27_to_1_32;
			numofentires = SIZE_TAN_INP_1_27_to_1_32; /* 101 */
		}
		else if((tan_value>=STRT_TAN_INP_1_32_to_1_37) && (tan_value<END_TAN_INP_1_32_to_1_37)){
			lkup_ptr_out = tan_outval_1_32_to_1_37;
			lkup_ptr_inp = tan_inpval_1_32_to_1_37;
			numofentires = SIZE_TAN_INP_1_32_to_1_37; /* 101 */
		}
		else if((tan_value>=STRT_TAN_INP_1_37_to_1_42) && (tan_value<END_TAN_INP_1_37_to_1_42)){
			lkup_ptr_out = tan_outval_1_37_to_1_42;
			lkup_ptr_inp = tan_inpval_1_37_to_1_42;
			numofentires = SIZE_TAN_INP_1_37_to_1_42; /* 101 */
		}
		else if((tan_value>=STRT_TAN_INP_1_42_to_1_47) && (tan_value<END_TAN_INP_1_42_to_1_47)){
			lkup_ptr_out = tan_outval_1_42_to_1_47;
			lkup_ptr_inp = tan_inpval_1_42_to_1_47;
			numofentires = SIZE_TAN_INP_1_42_to_1_47; /* 101 */
		}
		else if((tan_value>=STRT_TAN_INP_1_47_to_1_52) && (tan_value<END_TAN_INP_1_47_to_1_52)){
			lkup_ptr_out = tan_outval_1_47_to_1_52;
			lkup_ptr_inp = tan_inpval_1_47_to_1_52;
			numofentires = SIZE_TAN_INP_1_47_to_1_52; /* 101 */
		}
		else if((tan_value>=STRT_TAN_INP_1_52_to_1_57) && (tan_value<=END_TAN_INP_1_52_to_1_57)){
			/* getting error; more entires in lookup table can improve the accuracy */
			lkup_ptr_out = tan_outval_1_52_to_1_57;
			lkup_ptr_inp = tan_inpval_1_52_to_1_57;
			numofentires = SIZE_TAN_INP_1_52_to_1_57; /* 101 */
		}
		else{
			//fValBeyondTANLkup = NAP_ON;/* never expect such big input value */
			tan_value = END_TAN_INP_1_52_to_1_57; /* return max value */
			lkup_ptr_out = tan_outval_1_52_to_1_57;
			lkup_ptr_inp = tan_inpval_1_52_to_1_57;
			numofentires = SIZE_TAN_INP_1_52_to_1_57; /* 101 */
		}
        fl_tan_ret_val = fl_tan_calc_lkup(tan_value);
		}
		
	if(fSign == NAP_ON){
		fl_tan_ret_val *= -1.f;
	}
	else{}

	return fl_tan_ret_val;
}
/* #######################################################################################################
++module    FLOAT fl_tan_calc(FLOAT tan_val_rad)
++outline
++arguments
++supp
++ end_module
############################################################################################################# */
/* expanded upto X^39
------------------------------------------------------------------------------------------------------
Minimum difference Value	0.0000000000
File number - 	21
Angle in Degree - 	61.1798095703
array_tan_calc[i] = 	1.8174756765		array_tan_lib[i] = 	1.8174756765
------------------------------------------------------------------------------------------------------
Maximum difference Value	1096224669696.0000000000
File number - 	64
Angle in Degree - 	180.7570800781
array_tan_calc[i] = 	1096224669696.0000000000		array_tan_lib[i] = 	0.0132142529
------------------------------------------------------------------------------------------------------
*/

FLOAT fl_tan_calc(FLOAT tan_val_rad){
	/* tan x = x + 1/3 X^3 + 2/15 X^5 + 17/315 * X^7 + 62/2835 * X^9 .....  X^2 < 1*/
	FLOAT tan_value;
	register FLOAT tanval_sqare;
	FLOAT tanval_cube;
	FLOAT tanval_five;
	FLOAT tanval_seven;
	FLOAT tanval_nine;
	FLOAT tanval_eleven;
	FLOAT tanval_thirteen;
	FLOAT tanval_fifteen;
	FLOAT tanval_seventeen;
	FLOAT tanval_nineteen;
	FLOAT tanval_Twenty_one;

	FLOAT tanval_Twenty_Three;
	FLOAT tanval_Twenty_Five;
	FLOAT tanval_Twenty_Seven;
	FLOAT tanval_Twenty_Nine;
	FLOAT tanval_Thirty_One;

	FLOAT tanval_Thirty_Three;
	FLOAT tanval_Thirty_Five;
	FLOAT tanval_Thirty_Seven;
	FLOAT tanval_Thirty_Nine;
	FLOAT tanval_Forty_One;

	FLOAT temp_val1;
	FLOAT temp_val2;
	FLOAT temp_val3;
	FLOAT temp_val4;
	FLOAT temp_val5;

	tan_value = tan_val_rad;
	tanval_sqare = tan_value * tan_value;
	tanval_cube = tanval_sqare * tan_value;
	tanval_five = tanval_cube * tanval_sqare;
	tanval_seven = tanval_five * tanval_sqare;
	tanval_nine = tanval_seven * tanval_sqare;
	tanval_eleven = tanval_nine * tanval_sqare;
	tanval_thirteen = tanval_eleven * tanval_sqare;
	tanval_fifteen = tanval_thirteen * tanval_sqare;
	tanval_seventeen = tanval_fifteen * tanval_sqare;
	tanval_nineteen = tanval_seventeen * tanval_sqare;
	tanval_Twenty_one = tanval_nineteen * tanval_sqare;

	tanval_Twenty_Three = tanval_Twenty_one * tanval_sqare;
	tanval_Twenty_Five = tanval_Twenty_Three * tanval_sqare;
	tanval_Twenty_Seven = tanval_Twenty_Five * tanval_sqare;
	tanval_Twenty_Nine = tanval_Twenty_Seven * tanval_sqare;
	tanval_Thirty_One = tanval_Twenty_Nine * tanval_sqare;

	tanval_Thirty_Three = tanval_Thirty_One * tanval_sqare;
	tanval_Thirty_Five = tanval_Thirty_Three * tanval_sqare;
	tanval_Thirty_Seven = tanval_Thirty_Five * tanval_sqare;
	tanval_Thirty_Nine = tanval_Thirty_Seven * tanval_sqare;
	tanval_Forty_One = tanval_Thirty_Nine * tanval_sqare;

	temp_val1 = 0.333333333f * tanval_cube;
	temp_val2 = 0.133333333f * tanval_five;
	temp_val3 = 0.053968253f * tanval_seven;
	temp_val4 = 0.021869488f * tanval_nine;
	temp_val5 = 0.008863235f * tanval_eleven;

	tan_value = tan_val_rad
			+ temp_val1
			+ temp_val2
			+ temp_val3
			+ temp_val4
			+ temp_val5;

	temp_val1 = 0.0035921280f * tanval_thirteen;
	temp_val2 = 0.0014558343f * tanval_fifteen;
	temp_val3 =	0.0005900274f * tanval_seventeen;
	temp_val4 = 0.0002391291f * tanval_nineteen;
	temp_val5 =	0.0000969153f * tanval_Twenty_one;

	tan_value = tan_value + temp_val1 + temp_val2 + temp_val3 \
		+ temp_val4 + temp_val5;


	temp_val1 = 0.0000392783238f  * tanval_Twenty_Three;
	temp_val2 = 0.0000159189050f  * tanval_Twenty_Five;
	temp_val3 =	0.0000064516892f  * tanval_Twenty_Seven;
	temp_val4 = 0.0000026147711f  * tanval_Twenty_Nine;
	temp_val5 =	0.0000010597268f  * tanval_Thirty_One;

	tan_value += temp_val1;
	tan_value += temp_val2;
	tan_value += temp_val3;
	tan_value += temp_val4;
	tan_value += temp_val5;

	return tan_value;
}
/* #######################################################################################################
++module    FLOAT fl_tan_calc_lkup(FLOAT tan_val){
++outline
++arguments
++supp
++ end_module
############################################################################################################# */
static FLOAT fl_tan_calc_lkup(FLOAT tan_val){
	FLOAT tan_calc_val;
	tan_calc_val = LKtbl_interpolation(lkup_ptr_inp,lkup_ptr_out,numofentires, tan_val);
	return tan_calc_val;
}
/* #######################################################################################################
++module    FLOAT LKtbl_interpolation(const FLOAT invalues[], const uint32 outvalues[],uint32 num_points, FLOAT x);
++outline
++arguments
++supp
++ end_module
############################################################################################################# */
static FLOAT LKtbl_interpolation(const FLOAT invalues[], const uint32 outvalues[],
                      uint32 num_points, FLOAT x){
	FLOAT ret = 0.f;
	uint32 l;     /* index of left-hand element  */
	uint32 r;     /* index of right-hand element */
	uint32 idx;
	FLOAT outVal1;
	FLOAT outVal2;
	if (x <= invalues[0]){
		r = 1;
		l = 0;
	}
	else if (x >= invalues[num_points-1]){
		r = num_points - 1;
		l = r - 1;
	}
	else{
		r = num_points - 1;
		l = 0;
		while (l < (r-1)){
		  idx = (l+r) >> 1;
		  if (x < invalues[idx]){
			r = idx;
		  }
		  else{
			l = idx;
		}
	}
	}

	outVal1 = *((FLOAT*)(&outvalues[l]));
	outVal2 = *((FLOAT*)(&outvalues[r]));

	if((invalues[r] - invalues[l]) != 0.f){
		ret = outVal1 + ( ((outVal2 - outVal1) * (x - invalues[l])) / (invalues[r] - invalues[l]) );
	}
	else{
		/* divide by zero error */
	}

	if (x <= invalues[0]){
		ret = *((FLOAT*)(&outvalues[0]));
	}
	else if (x >= invalues[num_points-1]){
		ret = *((FLOAT*)(&outvalues[num_points-1]));
	}
	else{}
	return (ret);
}
/*----------------------------------------------------------------------------*/
/* function name -  fl_atan			                           				  */
/*----------------------------------------------------------------------------*/
#include "math_atan_tbl.c"
FLOAT fl_atan(FLOAT atan_value){
	FLOAT fl_atan_ret_val = 0.f;
	uint32 fSign = NAP_OFF;

	/* get the absolute value but preserve the sign */
	if(atan_value < 0.f){
		atan_value *= -1.f;
		fSign = NAP_ON;
	}
	else{}

	if(atan_value<ATAN_SERIES_EXPANSION_MAX_INP){
		 fl_atan_ret_val = fl_atan_calc(atan_value);
	}
	else{
		if((atan_value>= STRT_ATAN_INP_0_7_to_1_5) && (atan_value<END_ATAN_INP_0_7_to_1_5)){
			lkup_ptr_out = Atan_outval_0_7_to_1_5;
			lkup_ptr_inp = Atan_inpval_0_7_to_1_5;
			numofentires = SIZE_ATAN_INP_0_7_to_1_5;
		}
		else if((atan_value>= STRT_ATAN_INP_1_5_to_3_0) && (atan_value<END_ATAN_INP_1_5_to_3_0)){
			lkup_ptr_out = Atan_outval_1_5_to_3_0;
			lkup_ptr_inp = Atan_inpval_1_5_to_3_0;
			numofentires = SIZE_ATAN_INP_1_5_to_3_0;
		}
		else if((atan_value>= STRT_ATAN_INP_3_0_to_5_0) && (atan_value<END_ATAN_INP_3_0_to_5_0)){
			lkup_ptr_out = Atan_outval_3_to_5;
			lkup_ptr_inp = Atan_inpval_3_to_5;
			numofentires = SIZE_ATAN_INP_3_0_to_5_0;
		}
		else if((atan_value>= STRT_ATAN_INP_5_0_to_9_0) && (atan_value<END_ATAN_INP_5_0_to_9_0)){
			lkup_ptr_out =Atan_outval_5_to_9 ;
			lkup_ptr_inp =Atan_inpval_5_to_9 ;
			numofentires = SIZE_ATAN_INP_5_0_to_9_0;
		}
		else if((atan_value>= STRT_ATAN_INP_9_0_to_14_0) && (atan_value<END_ATAN_INP_9_0_to_14_0)){
			lkup_ptr_out = Atan_outval_9_to_14;
			lkup_ptr_inp = Atan_inpval_9_to_14;
			numofentires = SIZE_ATAN_INP_9_0_to_14_0;
		}
		else if((atan_value>= STRT_ATAN_INP_14_0_to_23_0) && (atan_value<END_ATAN_INP_14_0_to_23_0)){
			lkup_ptr_out = Atan_outval_14_to_23;
			lkup_ptr_inp = Atan_inpval_14_to_23;
			numofentires = SIZE_ATAN_INP_14_0_to_23_0;
		}
		else if((atan_value>= STRT_ATAN_INP_23_0_to_47_0) && (atan_value<END_ATAN_INP_23_0_to_47_0)){
			lkup_ptr_out = Atan_outval_23_to_47;
			lkup_ptr_inp = Atan_inpval_23_to_47;
			numofentires = SIZE_ATAN_INP_23_0_to_47_0;
		}
		else if((atan_value>= STRT_ATAN_INP_47_0_to_190_0) && (atan_value<END_ATAN_INP_47_0_to_190_0)){
			lkup_ptr_out = Atan_outval_47_to_190;
			lkup_ptr_inp = Atan_inpval_47_to_190;
			numofentires = SIZE_ATAN_INP_47_0_to_190_0;
		}
		else if((atan_value>= STRT_ATAN_INP_190_0_to_8L) && (atan_value<=END_ATAN_INP_190_0_to_8L)){
			lkup_ptr_out = Atan_outval_190_to_800000;
			lkup_ptr_inp = Atan_inpval_190_to_800000;
			numofentires = SIZE_ATAN_INP_190_0_to_8L;
		}
		else{
			/* fValBeyondATANLkup = NAP_ON;	*//* never expect such big input value */	
			lkup_ptr_out = Atan_outval_190_to_800000;
			lkup_ptr_inp = Atan_inpval_190_to_800000;
			numofentires = SIZE_ATAN_INP_190_0_to_8L;
			atan_value = END_ATAN_INP_190_0_to_8L;
		}
			fl_atan_ret_val = fl_atan_calc_lkup(atan_value);
		}
	
	if(fSign == NAP_ON){
		fl_atan_ret_val *= -1.f;
	}
	else{}
	return fl_atan_ret_val;
}
/*----------------------------------------------------------------------------*/
/* function name -  fl_atan_calc	                           				  */
/*----------------------------------------------------------------------------*/
FLOAT fl_atan_calc(FLOAT a_val){
	FLOAT atan_value = 0.f;
	register FLOAT atanval_sqare = 0.f;

	FLOAT temp_val1 = 0.f;
	FLOAT temp_val2 = 0.f;
	FLOAT temp_val3 = 0.f;
	FLOAT temp_val4 = 0.f;
	FLOAT temp_val5 = 0.f;
	FLOAT temp_val6 = 0.f;
	FLOAT temp_val7 = 0.f;
	FLOAT temp_val8 = 0.f;
	FLOAT temp_val9 = 0.f;
	FLOAT temp_val10 = 0.f;
	FLOAT temp_val11 = 0.f;

	FLOAT temp_val12 = 0.f;
	FLOAT temp_val13 = 0.f;
	FLOAT temp_val14 = 0.f;
	FLOAT temp_val15 = 0.f;

	FLOAT temp_val16 = 0.f;
	FLOAT temp_val17 = 0.f;
	FLOAT temp_val18 = 0.f;
	FLOAT temp_val19 = 0.f;

	FLOAT temp_val20 = 0.f;
	FLOAT temp_val21 = 0.f;
	FLOAT temp_val22 = 0.f;
	FLOAT temp_val23 = 0.f;
	FLOAT temp_val24 = 0.f;
	FLOAT temp_val25 = 0.f;
	FLOAT temp_val26 = 0.f;
	FLOAT temp_val27 = 0.f;

	/* 
	 * arctan(x) = x- (X^3/3) + (X^5/5) - (X^7/7) + (X^9/9) - (X^11/11) \
	 *	+ (X^13/13) - (X^15/15) + (X^17/17) - (X^19/19) + (X^21/21) - (X^23/23) \
	 *	+ (X^25/25) - (X^27/27) + (X^29/29) - (X^31/31) \
	 *	+ (X^33/33) - (X^35/35) + (X^37/37) - (X^39/39) \
	 *	+ (X^41/41) - (X^43/43) + (X^45/45) - (X^47/47) + (X^49/49) - (X^51/51) \
	 *	+ (X^53/53) - (X^55/55);
	 */

	atan_value = a_val;
	atanval_sqare = atan_value * atan_value;

	temp_val1 = (atanval_sqare * atan_value)/3.f;
	temp_val2 = (temp_val1 * atanval_sqare) * 0.6f;
	temp_val3 = (0.71428571f * temp_val2) * atanval_sqare;
	temp_val4 = (0.777777777f * temp_val3) * atanval_sqare;
	temp_val5 = (0.818181818f * temp_val4) * atanval_sqare;
	temp_val6 = (0.846153846f * temp_val5) * atanval_sqare;
	temp_val7 = (0.866666666f * temp_val6) * atanval_sqare;
	temp_val8 = (0.882352941f * temp_val7) * atanval_sqare;
	temp_val9 = (0.894736842f * temp_val8) * atanval_sqare;
	temp_val10 = (0.90476190f * temp_val9) * atanval_sqare;
	temp_val11 = (0.91304347f * temp_val10) * atanval_sqare;
	temp_val12 =  (0.92f * temp_val11) * atanval_sqare;
	temp_val13 =  (0.9259259f * temp_val12) * atanval_sqare;
	temp_val14 =  (0.9310344f  * temp_val13) * atanval_sqare;
	temp_val15 =  (0.9354838f * temp_val14) * atanval_sqare;

	temp_val16 = (0.93939393f * temp_val15) * atanval_sqare;
	temp_val17 = (0.94285714f * temp_val16) * atanval_sqare;
	temp_val18 = (0.94594594f * temp_val17) * atanval_sqare;
	temp_val19 = (0.94871794f * temp_val18) * atanval_sqare;

	temp_val20 = (0.95121951f * temp_val19) * atanval_sqare;
	temp_val21 = (0.95348837f * temp_val20) * atanval_sqare;
	temp_val22 = (0.95555555f * temp_val21) * atanval_sqare;
	temp_val23 = (0.95744680f * temp_val22) * atanval_sqare;
	temp_val24 = (0.95918367f * temp_val23) * atanval_sqare;
	temp_val25 = (0.96078431f * temp_val24) * atanval_sqare;
	temp_val26 = (0.96226415f * temp_val25) * atanval_sqare;
	temp_val27 = (0.96363636f * temp_val26) * atanval_sqare;

	atan_value -= temp_val1;
	atan_value += temp_val2;
	atan_value -= temp_val3;
	atan_value += temp_val4;
	atan_value -= temp_val5;
	atan_value += temp_val6;
	atan_value -= temp_val7;
	atan_value += temp_val8;
	atan_value -= temp_val9;
	atan_value += temp_val10;
	atan_value -= temp_val11;
	atan_value += temp_val12;
	atan_value -= temp_val13;
	atan_value += temp_val14;
	atan_value -= temp_val15;
	atan_value += temp_val16;
	atan_value -= temp_val17;
	atan_value += temp_val18;
	atan_value -= temp_val19;
	atan_value += temp_val20;
	atan_value -= temp_val21;
	atan_value += temp_val22;
	atan_value -= temp_val23;
	atan_value += temp_val24;
	atan_value -= temp_val25;
	atan_value += temp_val26;
	atan_value -= temp_val27;
	return atan_value;
}
/*----------------------------------------------------------------------------*/
/* function name -  fl_atan_calc_lkup                          				  */
/*----------------------------------------------------------------------------*/
static FLOAT fl_atan_calc_lkup(FLOAT atan_val){
	FLOAT atan_calc_val = 0.f;
	atan_calc_val = LKtbl_interpolation(lkup_ptr_inp, lkup_ptr_out,numofentires, atan_val);

	return atan_calc_val;

}

/* #######################################################################################################
++module    FLOAT fl_sin(FLOAT in);
++outline
++arguments
++supp
++ end_module
############################################################################################################# */
FLOAT fl_sin(FLOAT in){
    FLOAT out;
#if 1
    out = fl_sin_calc(in);
#else    
    FLOAT tan_val;
    FLOAT div_val;

    tan_val = fl_tan(in/2.f);
    div_val = 1.f + (tan_val * tan_val);

    out     = 2.f * tan_val;
    out     /= div_val;
#endif    
    return(out);
}

/* #######################################################################################################
++module    FLOAT fl_cos(FLOAT in);
++outline
++arguments
++supp
++ end_module
############################################################################################################# */
FLOAT fl_cos(FLOAT in){
#if 1
    return( fl_cos_calc(in) );
#else    
    return( fl_sin( in + NAP_HALF_PI) );
#endif    
}

/* #######################################################################################################
++module    FLOAT fl_sqrt(FLOAT number);
++outline
++arguments
++supp
++ end_module
############################################################################################################# */
#define		MAGIC_CONST_FOR_INITIAL_GUESS		(0x5f3759df)
FLOAT fl_sqrt(FLOAT number){
	sint32 tmp = 0;
	sint32 i_sqrt;
	FLOAT x, y;
	const FLOAT f = 1.5F;
	uint32 cnt;
	FLOAT sq_val;

	/* get the absolute value */
	number = fl_abs(number);
	
	x = number /2.f;
	y  = number;

	i_sqrt  = * ( sint32 * ) &y;

	i_sqrt  = MAGIC_CONST_FOR_INITIAL_GUESS - ( i_sqrt >> 1u );

	for(cnt=0u;cnt<4u;cnt++){
		*((uint8*)&tmp + cnt) = *((uint8*)&i_sqrt + cnt);
		}
	sq_val = *(FLOAT*)&tmp;

	for(cnt=0u;cnt<4u;cnt++){
		/* incresing the number of iterations will increse accuracy */
		sq_val  = sq_val * ( f - ( x * sq_val * sq_val ) );
	}
	return number * sq_val;
}
/* ################################################################ */
/* ### exp()�̍����v�Z                                          ### */
/* ###     http://www.chokkan.org/blog/archives/320             ### */
/* ################################################################ */
static const U_IEEE_754_32BIT cu_loge_2     = {0x3f317218};
static const U_IEEE_754_32BIT cu_loge_2_inv = {0x3fb8aa3b};
#define DEF_LOGE2                   (cu_loge_2.f)               /* log_{e}2     */
#define DEF_LOGE2_INV               (cu_loge_2_inv.f)           /* 1/log_{e}2   */
#define DEF_FLOAT_MAX               (3.4028234663852885e+38f)

/* e^b ���`��(0 \le b < log2)�ōŗǑ����������߂�(5��) */
static const U_IEEE_754_32BIT ArrayForCalcExp[6] = {
    0x3c4231c1,
    0x3d1eaf18,
    0x3e2bc7ba,
    0x3effe852,
    0x3f80005c,
    0x3f7ffffe
};
FLOAT ExpCalc(FLOAT x){
    sint32  n;
    FLOAT   out,f_n;
    U_IEEE_754_32BIT ans;

    /* n = |_x/loge2_| *//* |_A_| �� A ���z���Ȃ��ő�̐����ƌ����Ӗ� */
    f_n = x * DEF_LOGE2_INV;
    if( f_n < 0.f){         /* floor(f_n)�Ɠ����Ӗ� */
        f_n -= 1.f;
    }
    n = (int)f_n;
    f_n = (FLOAT)n;     /* f_n = floor(f_n) , n �͌�Ŏg���̂łƂ��Ă��� */
    
    /* ------------------ */
    /* �P���x�炢�B�B   */
    /* ------------------ */
    if( n > 127 ){
        out = DEF_FLOAT_MAX;
    }
    else if( n < -126){
        out = 0.f;
    }
    else{
        /* b = x -nlog2 *//* �����ł́Ax �𒼐ژM���Ă��� */
        x -=  f_n * DEF_LOGE2;

        /* e^b ���`��(0 \le b < log2)�ōŗǑ����������߂�(5��) */
        out = ArrayForCalcExp[0].f;
        out *= x;
        out += ArrayForCalcExp[1].f;
        out *= x;
        out += ArrayForCalcExp[2].f;
        out *= x;
        out += ArrayForCalcExp[3].f;
        out *= x;
        out += ArrayForCalcExp[4].f;
        out *= x;
        out += ArrayForCalcExp[5].f;
        
        /* e^x = 2^ne^b */
        ans.l = n+127;
        ans.l &= 0xff;
        ans.l <<= 23;
        out *= ans.f;
    }
    return(out);
}

/* #######################################################################################################
++module
++outline
++arguments
++supp
++ end_module
############################################################################################################# */
void calc_AVG_WithDist(FLOAT *avg, uint32 *cnt, FLOAT in, uint32 max_cnt,FLOAT vsp, FLOAT time_step, FLOAT thr_dist){
    FLOAT i;
    FLOAT tmp;

    *cnt = *cnt + 1;
    if( *cnt > max_cnt){
        *cnt = max_cnt;
    }
    else{;}
    
    if( *cnt == 1){
        *avg = in;
    }
    else{
        if( (vsp > 0.f) && (time_step > 0.f) ){
            i = thr_dist / (vsp * time_step);
            if( i < 1.f){
                i = 1.f;
            }
            if( (uint32)i > *cnt ){
                i = (FLOAT)*cnt;
            }
            else{;}
        }
        else{
            i = (FLOAT)*cnt;
        }

		i = (uint32)(i + 0.5f);
        tmp = (i-1) * (*avg);
        tmp += in;
        *avg = tmp / i;
    }
}
/* #######################################################################################################
++module
++outline
++arguments
++supp
++ end_module
############################################################################################################# */
void calc_AVG(FLOAT *avg, uint32 *cnt, FLOAT in, uint32 max_cnt){
    calc_AVG_WithDist(avg,cnt,in,max_cnt,0.f,0.f,0.f);
}

/* #######################################################################################################
++module
++outline
++arguments
++supp
++ end_module
############################################################################################################# */
FLOAT fl_FiFoRingBuffFloat(FLOAT data,  T_RING_BUFF_FL *ring){
    uint16 pos;
    FLOAT *buff;
    FLOAT out;

    buff = ring->Buff;
    pos = ring->Pos + 1;
    if(pos >= ring->Size ){
        pos = 0;
    }
    else{;}
    out = buff[pos];

    ring->Pos = pos;
    buff[pos] = data;

    return(out);
}

/* #######################################################################################################
++module
++outline
++arguments
++supp
++ end_module
############################################################################################################# */
/* func_pythagoras */
FLOAT	fl_pythagorean_theorem(	FLOAT	v_line1, FLOAT	v_line2	){    
	FLOAT	temp_line1, temp_line2, temp, out;
	/* ++[(����1)^2] */
	temp_line1	= v_line1 * v_line1;
	/* ++[(����2)^2] */
	temp_line2	= v_line2 * v_line2;
	/* ++[(����1)^2+(����2)^2] */
	temp		= temp_line1 + temp_line2;
	/* ++[��((����1)^2+(����2)^2)] */
	out			= fl_sqrt( temp );
	/* ++[�o��] */
	return( out );
}

/* #######################################################################################################
++module
++outline
++arguments
++supp
++ end_module
############################################################################################################# */
/* func_approx_pythagoras */
FLOAT	fl_pythagorean_theorem_ax(	FLOAT	v_line1, FLOAT	v_line2	){
	FLOAT	temp_line1, temp_line2, temp, out;
	/* ++[|����1|] */
	temp_line1	= fl_abs( v_line1 );
	/* ++[(����2)^2] */
	temp_line2	= v_line2 * v_line2;
	/* ++[((����2)^2)/(����1)] */
	temp		= temp_line2 / temp_line1;
	/* ++[(����1)+(((����2)^2)/(����1)/2)] */
	out			= temp_line1 + ( temp / 2 );
	/* ++[�o��] */
	return( out );
}

/* #######################################################################################################
++module
++outline
++arguments
++supp
++ end_module
############################################################################################################# */
/* r_obj_dist_ICC_update */
FLOAT	fl_trajectory_calc(	FLOAT	v_radius,			/* [m] */
                            FLOAT	v_lateral_dist,		/* [m] */
                            FLOAT	v_distance,			/* [m] */
                            FLOAT	v_approx_th		){	/* [m] */
	FLOAT	lat_dist_temp, r_obj, out;
	
/* r_obj1_ICC_update */
	/* ++[���񒆐S����F�����̂܂ł̉�����] */
	lat_dist_temp	= v_radius - v_lateral_dist;
	if(
		( lat_dist_temp == NAP_FLOAT_ZERO )		/* ���񒆐S����F�����̂܂ł̉�������0 */
		&&
		( v_distance == NAP_FLOAT_ZERO )			/* ���񒆐S����F�����̂܂ł̏c������0 */
	){
		r_obj	= NAP_FLOAT_ZERO;					/* ���񒆐S����F�����̂܂ł̋�����0 */
	}
	else if(
		( lat_dist_temp == NAP_FLOAT_ZERO )		/* ���񒆐S����F�����̂܂ł̉������̂�0 */
	){
		r_obj	= fl_abs( v_distance );			/* ���񒆐S����F�����̂܂ł̋����͏c�����Ɠ��� */
	}
	else if(
		( v_distance == NAP_FLOAT_ZERO )			/* ���񒆐S����F�����̂܂ł̏c�����̂�0 */
	){
		r_obj	= fl_abs( lat_dist_temp );		/* ���񒆐S����F�����̂܂ł̋����͐��񒆐S����F�����̂܂ł̉������Ɠ��� */
	}
	else{
		/* ++[�ߎ����Z����] */
		if(
			( fl_abs( v_radius ) < v_approx_th )
		){
			/* ++[�O�����̒藝] */
			r_obj	= fl_pythagorean_theorem(		lat_dist_temp,
														v_distance	);
		}
		else{
			/* ++[�ߎ������O�����̒藝] */
			r_obj	= fl_pythagorean_theorem_ax(	lat_dist_temp,
														v_distance	);
		}
	}
/* signed_r_obj_dist_icc_buf_update */
	/* ++[�E����] */
	if(
		( NAP_FLOAT_ZERO < v_radius )
	){
		out	= v_radius - r_obj;
	}
	/* ++[������] */
	else if(
		( v_radius < NAP_FLOAT_ZERO )
	){
		out	= v_radius + r_obj;
	}
	/* ++[���i��] */
	else{
		out	= v_lateral_dist;
	}
	/* ++[�o��] */
	return( out );	/* ���Ԃ̋O�����E�́{�A���́| */
}

/* #######################################################################################################
++module
++outline
++arguments
++supp
++ end_module
############################################################################################################# */
/* lpf */
FLOAT	fl_lpf(	FLOAT	in,
					FLOAT	out_z,
					FLOAT	m0,
					FLOAT	m1		){
	/* ++[�Z�o] */
	FLOAT	v_temp1	= in    * m0;
	FLOAT	v_temp2	= out_z * m1;
	FLOAT	out		= v_temp1 + v_temp2;
	/* ++[�o��] */
	return( out );
}

/* #######################################################################################################
++module
++outline
++arguments
++supp
++ end_module
############################################################################################################# */
/* func_2nd_lpf */
FLOAT	fl_2nd_lpf(	FLOAT	a_in[],
						FLOAT	a_out[],
						FLOAT	m0,
						FLOAT	m1,
						FLOAT	m2	){

	FLOAT	v_temp1, v_temp2, v_temp3, v_temp4, out;
	
	/* ++[�Z�o] */
	v_temp1	= a_in[0] + ( a_in[1] * 2 ) + a_in[2];
	v_temp2	= v_temp1  * m0;
	v_temp3	= a_out[1] * m1;
	v_temp4	= a_out[2] * m2;
	out		= v_temp2 + v_temp3 - v_temp4;
	/* ++[�o��] */
	return( out );
}

/* #######################################################################################################
++module
++outline
++arguments
++supp
++ end_module
############################################################################################################# */
/* bpf */
FLOAT 	fl_bpf(	uint8	reset,		/* �������t���O */
					FLOAT	in,			/* �t�B���^���� */
					FLOAT	*in_z1,		/* �t�B���^���́i�O��l�j*/
					FLOAT	*in_z2,		/* �t�B���^���́i�O�X��l�j*/
					FLOAT	*out_z1,	/* �t�B���^�o�́i�O��l�j*/
					FLOAT	*out_z2,	/* �t�B���^�o�́i�O�X��l�j*/
					FLOAT	mdvsp0,		/* �t�B���^�萔�P */
					FLOAT	mdvsp1,		/* �t�B���^�萔�Q */
					FLOAT	mdvsp2	)	/* �t�B���^�萔�R */
{
	FLOAT	vdev, vbpf1, vbpf2, vbpf3, out;
	
	if( reset == NAP_ON ){
		/* ++[������] */
		*in_z1	= *in_z2	= in;
		*out_z1	= *out_z2	= NAP_FLOAT_ZERO;
	}else{
		/* ++[�ێ�] */
	}
	
	/* ++[BPF���Z] */
	/* ++[bpf1=mdvsp0*(in0-in2)] */
	vdev	= in - *in_z2;
	vbpf1	= vdev * mdvsp0;
	/* ++[bpf2=mdvsp2*out2] */
	vbpf2	= *out_z2 * mdvsp2;
	/* ++[bpf3=mdvsp1*out1] */
	vbpf3	= *out_z1 * mdvsp1;
	/* ++[bpf1-bpf2=mdvsp0*(in0-in2)-mdvsp2*out2] */
	vbpf1	= vbpf1 - vbpf2;
	/* ++[bpf1+bpf3=mdvsp0*(in0-in2)-mdvsp2*out2+mdvsp1*out1] */
	out		= vbpf1 + vbpf3;
	
	/* ++[�ߋ��l�X�V] */
	*in_z2	= *in_z1;
	*in_z1	= in;
	*out_z2	= *out_z1;
	*out_z1	= out;

	/* ++[�o��] */
	return( out );
}
/* #######################################################################################################
++module
++outline
++arguments
++supp
++ end_module
############################################################################################################# */
void	vSetAllRingBuffFL(	FLOAT			data,
							T_RING_BUFF_FL*	ring	){
	uint16	pos;
	FLOAT	*buff	= ring->Buff;
	for( pos = 0 ; pos < ring->Size ; pos++ ){
		buff[pos]	= data;
	}
	ring->Pos	= 0;
}

/* #######################################################################################################
++module
++outline
++arguments
++supp
++ end_module
############################################################################################################# */
void	vPushRingBuffFL(	FLOAT			data,
							T_RING_BUFF_FL*	ring	){
	uint16	pos		= ring->Pos + 1;
	FLOAT	*buff	= ring->Buff;
	if(
		( pos >= ring->Size )
	){
		pos	= 0;
	}
	else{
		;
	}
	ring->Pos	= pos;
	buff[pos]	= data;
}

/* #######################################################################################################
++module
++outline
++arguments
++supp
++ end_module
############################################################################################################# */
FLOAT	fl_GetRingBuffFL(	uint16			pos,
							T_RING_BUFF_FL*	ring	){
	FLOAT	out;
    FLOAT*	buff	= ring->Buff;
	uint16	target;
	if(
		( pos >= ring->Size )
	){
		target	= ring->Pos;
	}
	else{
		if(
			( ring->Pos >= (uint32)pos )
		){
			target	= (uint16)( ring->Pos - pos );
		}
		else{
			target	= (uint16)( ring->Size - ( pos - ring->Pos ) );
		}
	}
	out	= buff[target];
	return( out );
}

/* #######################################################################################################
++module
++outline
++arguments
++supp
++ end_module
############################################################################################################# */
static	sint32	si32_map_output_calc(	sint32	output_hi,
										sint32	output_low,
										sint32	input_hi,
										sint32	input_low,
										sint32	input		){
	sint32	out;
	if(
		( output_hi == output_low )
	){
		out	= output_low;
	}
	else if(
		( input_hi == input_low )
	){
		out	= output_low;
	}
	else{
		out	= output_low
			+ (( output_hi - output_low ) / ( input_hi - input_low )	/* Add a parenthesis to do an operator precedence explicitly(QAC) 20191029 */
			* ( input - input_low ));
	}
	return( out );
}

/* #######################################################################################################
++module
++outline
++arguments
++supp
++ end_module
############################################################################################################# */
sint32	si32_Read3DMap(	sint32	x,
						sint32	y,
						const	T_3D_MAP	*map	){
	sint32	out;
	sint32	z_low_low, z_low_hi, z_hi_low, z_hi_hi, zy_low, zy_hi;
	uint32	x_low_pos, x_hi_pos;
	uint32	y_low_pos, y_hi_pos;
	
	/* ++[X�ʒu(X���͏������d�����������̂Ƃ���)] */
	if( x <= map->x_table[0] ){
		/* ++[X��X���ŏ��l�ȉ�] */
		x_low_pos	= x_hi_pos	= 0;
	}
	else if( map->x_table[map->x_size-1] <= x ){
		/* ++[X��X���ő�l�ȏ�] */
		x_low_pos	= x_hi_pos	= map->x_size-1;
	}
	else{
		/* ++[X��X���ŏ��l���傫�����ő�l��菬����] */
		x_low_pos	= x_hi_pos	= map->x_size-1;
		while( ( x < map->x_table[x_low_pos] ) && ( x_low_pos != 0 ) ){
			x_hi_pos	= x_low_pos;
			x_low_pos	= x_low_pos - 1;
		}
	}
	/* ++[Y�ʒu(Y���͏������d�����������̂Ƃ���)] */
	if( y <= map->y_table[0] ){
		/* ++[Y��Y���ŏ��l�ȉ�] */
		y_low_pos	= y_hi_pos	= 0;
	}
	else if( map->y_table[map->y_size-1] <= y ){
		/* ++[Y��Y���ő�l�ȏ�] */
		y_low_pos	= y_hi_pos	= map->y_size-1;
	}
	else{
		/* ++[Y��Y���ŏ��l���傫�����ő�l��菬����] */
		y_low_pos	= y_hi_pos	= map->y_size-1;
		while( ( y < map->y_table[y_low_pos] ) && ( y_low_pos != 0 ) ){
			y_hi_pos	= y_low_pos;
			y_low_pos	= y_low_pos - 1;
		}
	}
	/* ++[4�_��Z�l] */
	z_low_low	= *(&(map->z_table[y_low_pos]) + x_low_pos);	/* Y:����, X:���� */
	z_low_hi	= *(&(map->z_table[y_low_pos]) + x_hi_pos );	/* Y:����, X:��� */
	z_hi_low	= *(&(map->z_table[y_hi_pos] ) + x_low_pos);	/* Y:���, X:���� */
	z_hi_hi		= *(&(map->z_table[y_hi_pos] ) + x_hi_pos );	/* Y:���, X:��� */
	/* ++[Y:���,X:���ʂ�Y:����,X:���ʂ����Ԓ����ɑ΂���Y�̎���Z:����] */
	zy_low	= si32_map_output_calc(	z_hi_low,
									z_low_low,
									map->y_table[y_hi_pos],
									map->y_table[y_low_pos],
									y	);
	/* ++[Y:���,X:��ʂ�Y:����,X:��ʂ����Ԓ����ɑ΂���Y�̎���Z:���] */
	zy_hi	= si32_map_output_calc(	z_hi_hi,
									z_low_hi,
									map->y_table[y_hi_pos],
									map->y_table[y_low_pos],
									y	);
	/* ++[Z:��ʂ�Z:���ʂ����Ԓ����ɑ΂���X�̎��̒l] */
	out		= si32_map_output_calc(	zy_hi,
									zy_low,
									map->x_table[x_hi_pos],
									map->x_table[x_low_pos],
									x	);
	/* ++[�o��] */
	return( out );
}


/* #######################################################################################################
++module
++outline
++arguments
++supp
++ end_module
############################################################################################################# */
FLOAT	fl_add_max_min(	FLOAT	v_base,
							FLOAT	v_add,
							FLOAT	v_max,
							FLOAT	v_min	){
	FLOAT	temp, out;
	/* ++[�㉺���l�ُ픻��] */
	if(
		( v_max < v_min )
	){
		out	= v_base;	/* ��l */
	}
	/* ++[��L�ȊO] */
	else{
		/* ++[���Z�l����] */
		if(
			( NAP_FLOAT_ZERO <= v_add )
		){
			/* ++[�������] */
			if(
				( v_max <= v_base )						/* ��l������l�ȏ� */
			){
				temp	= v_base;						/* ��l */
			}
			else{
				/* ++[���Z�۔���] */
				if(
					( v_base <= NAP_FLOAT_ZERO )		/* ��l���� */
				){
					temp	= v_base + v_add;			/* ���Z(���Z�l:��) */
				}
				else if(
					( v_add <= ( v_max - v_base ) )		/* ���Z�l����l�Ə���l�̊Ԃɔ[�܂� */
				){
					temp	= v_base + v_add;			/* ���Z(���Z�l:��) */
				}
				else{
					temp	= v_max;					/* ����l */
				}
			}
		}
		/* ++[���Z�l����] */
		else{
			/* ++[��������] */
			if(
				( v_base <= v_min )						/* ��l�������l�ȉ� */
			){
				temp	= v_base;						/* ��l */
			}
			else{
				/* ++[���Z�۔���] */
				if(
					( NAP_FLOAT_ZERO <= v_base )		/* ��l���� */
				){
					temp	= v_base + v_add;			/* ���Z(���Z�l:��) */
				}
				else if(
					( ( v_min - v_base ) <= v_add )		/* ���Z�l����l�Ɖ����l�̊Ԃɔ[�܂� */
				){
					temp	= v_base + v_add;			/* ���Z(���Z�l:��) */
				}
				else{
					temp	= v_min;					/* �����l */
				}
			}
		}
		/* ++[�㉺������] */
		out	= fl_FiltMaxMin(	temp,
								v_max,
								v_min	);
	}
	/* ++[�o��] */
	return( out );
}
/* #######################################################################################################
++module
++outline
++arguments
++supp
++ end_module
############################################################################################################# */
sint32	si32_add_max_min(	sint32	base,
								sint32	add,
								sint32	max,
								sint32	min		){
	sint32	out;
	/* ++[���Z�l����] */
	if( 0 <= add ){
		if( add <= ( max - base ) ){
			out	= base + add;
		}
		/* ++[�ő�l] */
		else{
			out	= max;
		}
	}
	/* ++[���Z�l����] */
	else{
		if( ( min - base ) <= add ){
			out	= base + add;
		}
		/* ++[�ŏ��l] */
		else{
			out	= min;
		}
	}
	return( out );
}
/* #######################################################################################################
++module
++outline
++arguments
++supp
++ end_module
############################################################################################################# */
uint16	ui16_add_max_min(	uint16	base,
								uint16	add,
								uint16	max,
								uint16	min		){
	uint16	out;
	/* ++[�㉺���l�ُ픻��] */
	if(
		( max < min )
	){
		out	= base;						/* ��l */
	}
	else{
		/* ++[�������] */
		if(
			( max <= base )				/* ��l������l�ȏ� */
		){
			out	= max;					/* ����l */
		}
		/* ++[���Z�۔���] */
		else if(
			( ( max - base ) < add )	/* ���Z����Ə���l������ */
		){
			out	= max;					/* ����l */
		}
		else{
			/* ++[���Z] */
			out	= base + add;
			/* ++[��������] */
			if(
				( out < min )
			){
				out	= min;				/* �����l */
			}
		}
	}
	/* ++[�o��] */
	return( out );
}
/* #######################################################################################################
++module
++outline
++arguments
++supp
++ end_module
############################################################################################################# */
uint16	ui16_sub_max_min(	uint16	base,
								uint16	sub,
								uint16	max,
								uint16	min		){
	uint16	out;
	/* ++[�㉺���l�ُ픻��] */
	if(
		( max < min )
	){
		out	= base;						/* ��l */
	}
	else{
		/* ++[��������] */
		if(
			( base <= min )				/* ��l�������l�ȉ� */
		){
			out	= min;					/* �����l */
		}
		/* ++[���Z�۔���] */
		else if(
			( ( base - min ) < sub )	/* ���Z����Ɖ����l������� */
		){
			out	= min;
		}
		else{
			/* ++[���Z] */
			out	= base - sub;
			/* ++[�������] */
			if(
				( max < out )			/* ����l */
			){
				out	= max;
			}
		}
	}
	/* ++[�o��] */
	return( out );
}
/* #######################################################################################################
++module
++outline
++arguments
++supp
++ end_module
############################################################################################################# */
/* 2�i�J���Z�ŕ������̉��Z */
#define	DEF_SQRT_START_BIT	( 30 )
#define	DEF_SQRT_START_MASK	( 0xC0000000 )
uint32	ui32_sqrt(	uint32	 in 	){
	sint16	i;
	uint32	out		= 0;	/* �o�� */
	uint32	sub		= 0;	/* ���^�Z�l */
	uint32	main	= 0;	/* ��^�Z�l */
	uint32	mask	= 0;	/* ���͒l�؏o���p�r�b�g�}�X�N */
	mask	= DEF_SQRT_START_MASK;									/* 11000000 00000000 00000000 00000000 */
	for( i = DEF_SQRT_START_BIT ; 0 <= i ; i -= 2, mask >>= 2 ){	/* 2bit���ɐi�߂� */
		out		<<= 1;							/* �o�͒l�X�V���� */
		
		main	<<= 2;							/* ��^�Z�l�� 2 bit���t�������鏀�� */
		main	|=  ( ( in & mask ) >> i );		/* ��^�Z�l�֓��͂�����o���� 2 bit��t�������� */
		
		sub		<<= 1;							/* ���^�Z�l�X�V���� */
		if( sub < main ){						/* �X�V�O���^�Z�l < �X�V�O��^�Z�l */
			/* �X�V�O���^�Z�l�ɑ����̂� 1 */
			main	-= ++sub;					/* ��^�Z�l = �X�V�O��^�Z�l - ( �X�V�O���^�Z�l + 1 ) * 1 */
			++sub;								/* ���^�Z�l = ( �X�V�O���^�Z�l + 1 ) + 1 */
			++out;								/* �o�͒l�� 1 */
		}else{
			/* �X�V�O���^�Z�l�ɑ����̂� 0 �䂦�ɏ������� */
		}
	}
	/* ++[�]��΍�] */
	if( main != 0 ){
		/* ++[�J�グ] */
		out++;
	}
	/* ++[�o��] */
	return( out );
}
