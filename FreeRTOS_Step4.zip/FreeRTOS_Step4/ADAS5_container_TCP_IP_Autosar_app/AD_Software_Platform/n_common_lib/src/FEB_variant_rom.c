/*********************************************************************************
 *
 *     Copyright (c) 2014 Nissan, Japan
 *
 *********************************************************************************
 *
 * Project:     
 * Author:      
 * Description: 
 * Macro Ver.:  
 * Making of:   
 * Date:        
 * Revision History:
 *
*********************************************************************************/
#define __FEB_VARIANT_ROM_C__

/* ################################################ */
/*  �C���N���[�h                                    */
/* ################################################ */
#include "data_types.h"
#include "spec.h"
#include "n_common.h"
/*#include	"sysinfo.h"*//* ADAS3.1 20151111 S.Hiko �g���Ă��Ȃ��̂ō폜 */
#include "FEB_CommonFunc.h"
#include "FEB_Const.h"
#include "FEB_variant_rom.h"
