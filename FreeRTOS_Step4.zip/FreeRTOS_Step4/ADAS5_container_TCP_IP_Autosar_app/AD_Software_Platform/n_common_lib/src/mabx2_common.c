/** *********************************************************
 * @brief The common functions implementation for C-language.
 *
 * @author N. Hodohara
 ***********************************************************/
#include "mabx2_common.h"
#include <math.h>

 /*-------------------*
 * global constant value
 *-------------------*/
#if 0
static const uint8_t LANE_TYPE_CONVERSION_TO_EQ3[FRONT_CAM_LANE_TYPES_NUM] = { 2u, 1u, 0u, 4u, 4u, 6u, 6u, 5u, 6u, 6u, 3u, 6u, 6u };
#endif


/*-------------------*
* common function implementation
*-------------------*/
/**
 * @brief Returns the integer value that is nearest to x, with halfway cases rounded away from zero.
 * Implementation of round() function.
 * www.cplusplus.com/reference/cmath/round/
 *
 * @param x |Def:input value. |Unit:- |Range:- |Resol:- |
 * @return int32_t |Def:integer value which is nearest to x. |Unit:- |Range:- |Resol:- |
 */
int32_t iRound(double x)
{
    if (x > 0.0) {
        return (int32_t)floor(x + 0.5);
    } else {
        return -(int32_t)floor(-x + 0.5);
    }
}

/**
 * @brief The function shall sort an array.
 * @note The comb sort is not a stable sort.
 *
 * @param size |Def:the number of an array elements. |Unit:- |Range:[0,-] |Resol:- |
 * @param dist |Def:array of values to be sorted. |Unit:- |Range:- |Resol:- |
 * @param index |Def:array of indices to be sorted. |Unit:- |Range:[0,size of array) for each element. |Resol:- |
 * @return NAP_RET |Def:The resultant error code of this function. |Unit:- |Range:{-1:error, 1:ok} |Resol:- |Init:- |
 */
NAP_RET comb_sort(int32_t size, double dist[], int32_t index[])
{	
	int32_t i;
	int32_t h = size;
	BOOL_t is_swapped = FALSE;

	NULL_CHECK(dist);
	NULL_CHECK(index);

	while (h > 1 || is_swapped) {
		if (h == 9 || h == 10) {
			h = 11; /* combsort 11 */
		}
        else if (h > 1) {
			h = (h * 10) / 13;
		}
		else {
			/* do nothing */
		}

		is_swapped = FALSE;
		for (i = 0; i < size - h; ++i) {
			if (dist[i] > dist[i + h]) {
				/* swap */
				double temp = dist[i];
				int32_t temp_i = index[i];
				dist[i] = dist[i + h];
				dist[i + h] = temp;
				index[i] = index[i + h];
				index[i + h] = temp_i;
				is_swapped = TRUE;
			}
		}
	}

    return NAP_OK;
}

/**
 * @brief The function shall search a 1-D lookup table for the nearest index and output the linear interporated value.
 * 1-D Look-up table.
 *
 * @param invalues |Def:X axis of 1-D look-up table. |Unit:- |Range:- |Resol:- |
 * @param outvalues |Def:Y axis of 1-D look-up table. |Unit:- |Range:- |Resol:- |
 * @param num_points |Def:size of the X&Y table arrays. |Unit:- |Range:[1,-] |Resol:- |
 * @param x |Def:input X value. |Unit:- |Range:- |Resol:- |
 * @return double |Def:output Y value. |Unit:- |Range:- |Resol:- |
 * 
 * @attension X table should be monotonically increasing.
 * @note Return 0 when NULL input or num_points < 1.
 */
#if 0 /* avoid multiple definition */
double lookup1dtbl(const double invalues[], const double outvalues[], uint32_t num_points, double x)
#else
double MABX2_lookup1dtbl(const double invalues[], const double outvalues[], uint32_t num_points, double x)
#endif
{
    uint32_t l; /* index of left-hand element  */
    uint32_t r; /* index of right-hand element */
    uint32_t idx;
    double   ret;

    if (invalues == NULL || outvalues == NULL || num_points < 1u) {
        return 0.0;
    }

    if (x <= invalues[0]) {
        r = 1u;
        l = 0u;
    } else if (x >= invalues[num_points - 1u]) {
        r = num_points - 1u;
        l = r - 1u;
    } else {
        r = num_points - 1u;
        l = 0u;
        while (l < r - 1u) {
            idx = (l + r) >> 1u;
            if (x < invalues[idx]) {
                r = idx;
            } else {
                l = idx;
            }
        }
    }

    ret = outvalues[l] + ((outvalues[r] - outvalues[l]) * (x - invalues[l]) / (invalues[r] - invalues[l]));

    if (x <= invalues[0]) {
        ret = outvalues[0];
    } else if (x >= invalues[num_points - 1u]) {
        ret = outvalues[num_points - 1u];
    } else {
		/* do nothing. */
	}

    return ret;
}

/**
 * @brief The function shall apply 1-dimension low pass filter to its arguments.
 *
 * @param init |Def:flag whether it should be initialized. |Unit:- |Range:- |Resol:- |
 * @param u_z0 |Def:current input value. |Unit:- |Range:- |Resol:- |
 * @param u_z1_in |Def:previous cycle input value. |Unit:- |Range:- |Resol:- |
 * @param y_z1_in |Def:previous cycle output value. |Unit:- |Range:- |Resol:- |
 * @param sample_time |Def:sampling time |Unit:sec |Range:(0.0, 1.0] |Resol:- |
 * @param fc
 * @return double |Def:filtered value. |Unit:- |Range:- |Resol:- |
 */
double LPF(BOOL_t init, double u_z0, double u_z1_in, double y_z1_in, double sample_time, double fc)
{
    double y;
    double tmp;
    double omega;

    double u_z1;
    double y_z1;

    omega = 2.0 * M_PI * fc;
    tmp   = 0.5 * sample_time * omega;

    if (init == TRUE) {
        u_z1 = u_z0;
        y_z1 = u_z0;
    } else {
        u_z1 = u_z1_in;
        y_z1 = y_z1_in;
    }

    y = (((1.0 - tmp) * y_z1) + (tmp * (u_z0 + u_z1))) / (1.0 + tmp);

    return y;
}

/**
 * @brief The function shall filter input value like backlash.
 * jp.mathworks.com/help/simulink/slref/backlash.html
 * 
 * @param init |Def:flag to initialize the internal state. |Unit:boolean |Range:- |Resol:- |
 * @param u_z0 |Def:current input |Unit:- |Range:- |Resol:- |
 * @param y_z1_in |Def:previous output |Unit:- |Range:- |Resol:- |
 * @param deadband_width |Def:backlash band width. |Unit:- |Range:[0,-] |Resol:- |
 * @return double |Def:backlash-filtered output. |Unit:- |Range:- |Resol:- |
 */
double Backlash(BOOL_t init, double u_z0, double y_z1_in, double deadband_width)
{
    double half_deadband_width;
    double y_z0;
    double y_z1;

    half_deadband_width = deadband_width / 2.0;

    if (init == TRUE) {
        y_z1 = u_z0;
    } else {
        y_z1 = y_z1_in;
    }

    if (u_z0 < y_z1 - half_deadband_width) {
        y_z0 = u_z0 + half_deadband_width;
    } else if (u_z0 <= (y_z1 + half_deadband_width)) {
        y_z0 = y_z1;
    } else {
        y_z0 = u_z0 - half_deadband_width;
    }

    return y_z0;
}

/**
* @brief The function shall preprocess the lane information from front camera.
*
* Original Lane Type:
* 0=Undecided
* 1=Solid
* 2=Dashed
* 3=Double Line Crossable
* 4=Double Line Uncrossable
* 5=Multiple Lines Crossable
* 6=Multiple Lines Uncrossable
* 7=Botts Dots
* 8=Curb
* 9=Snow Edge
* 10=Road Edge
* 11=Virtual
* 12=Barrier
*
* Converted Lane Type:
* 0: EQ3Dashded
* 1: EQ3Solid
* 2: EQ3Undecided
* 3: EQ3RoadEdge
* 4: EQ3DoubleLane
* 5: EQ3BottsDots
* 6: EQ3Invalid
*
* This conversion shall be applied for input of TrafficAware and RCarHMIManagement as per mABX2 model.
* (Not for SurroundFusion.)
*
* @param lane_type  |Def:lane type of front camera detection. |Unit:- |Range:[0,12] |
* @return void
*/
uint8_t convert_fcam_lane_type_to_EQ3(uint8_t lane_type)
{
#if 0 // F/B �F�Ӑ}�s���Ȃ̂ň�U�}�X�N(�]���Ɠ���)
	uint8_t converted;

	if (0 <= lane_type && lane_type < FRONT_CAM_LANE_TYPES_NUM) {
		converted = LANE_TYPE_CONVERSION_TO_EQ3[lane_type];
	}
	else {
		converted = LANE_TYPE_CONVERSION_TO_EQ3[FRONT_CAM_LANE_TYPES_NUM - 1];
	}

	return converted;
#else
	return lane_type;
#endif // if 0
}
