/**
 * @file
 * @brief �x�N�g����������
 *
 * @author morimoto
 */

#define UTIL_VECTOR_C_

/*---------------*
 * include files *
 *---------------*/
#include <math.h>
#include "util_vector.h"

/*------------------*
 * macro definition *
 *------------------*/

/*----------------------*
 * function definition *
 *----------------------*/

/**
 * @brief ���͂̓��a�̕�������Ԃ�
 */
static double RootSumSquare(double x, double y)
{
	return sqrt(x * x + y * y);
}

static FLOAT RootSumSquare_fl(FLOAT x, FLOAT y)
{
	return sqrtf(x * x + y * y);
}

/**
 * @brief �x�N�g���̓��ς�Ԃ�
 */
double InnerProduct(const Vector_t vec_src1, const Vector_t vec_src2)
{
	double dst;

	dst = vec_src1.x * vec_src2.x + vec_src1.y * vec_src2.y;

	return dst;
}

FLOAT InnerProduct_fl(const Vector_fl_t vec_src1, const Vector_fl_t vec_src2)
{
	FLOAT dst;

	dst = vec_src1.x * vec_src2.x + vec_src1.y * vec_src2.y;

	return dst;
}

/**
 * @brief �x�N�g���̊O�ς�Ԃ�
 */
double OuterProduct(const Vector_t vec_src1, const Vector_t vec_src2)
{
	double dst;

	dst = vec_src1.x * vec_src2.y - vec_src1.y * vec_src2.x;

	return dst;
}

FLOAT OuterProduct_fl(const Vector_fl_t vec_src1, const Vector_fl_t vec_src2)
{
	FLOAT dst;

	dst = vec_src1.x * vec_src2.y - vec_src1.y * vec_src2.x;

	return dst;
}

/**
 * @brief �x�N�g���̐����p��Ԃ�
 */
double VectorAngle(const Vector_t vec_src1, const Vector_t vec_src2)
{
	double dst;
	double inner;
	double outer;

	inner = InnerProduct(vec_src1, vec_src2);
	outer = OuterProduct(vec_src1, vec_src2);

	dst = atan2(outer, inner);

	return dst;
}

FLOAT VectorAngle_fl(const Vector_fl_t vec_src1, const Vector_fl_t vec_src2)
{
	FLOAT dst;
	FLOAT inner;
	FLOAT outer;

	inner = InnerProduct_fl(vec_src1, vec_src2);
	outer = OuterProduct_fl(vec_src1, vec_src2);

	dst = atan2f(outer, inner);

	return dst;
}

/**
 * @brief �x�N�g���̃m������Ԃ�
 */
double VectorNorm(const Vector_t vec_src)
{
	double rss;

	rss = RootSumSquare(vec_src.x, vec_src.y);
	return rss;
}

FLOAT VectorNorm_fl(const Vector_fl_t vec_src)
{
	FLOAT rss;

	rss = RootSumSquare_fl(vec_src.x, vec_src.y);
	return rss;
}

/**
 * @brief �x�N�g���̘a��Ԃ�
 */
Vector_t VectorAdd(const Vector_t vec_src1,
				   const Vector_t vec_src2)
{
	Vector_t vec_dst;

	vec_dst.x = vec_src1.x + vec_src2.x;
	vec_dst.y = vec_src1.y + vec_src2.y;

	return vec_dst;
}

Vector_fl_t VectorAdd_fl(const Vector_fl_t vec_src1,
				         const Vector_fl_t vec_src2)
{
	Vector_fl_t vec_dst;

	vec_dst.x = vec_src1.x + vec_src2.x;
	vec_dst.y = vec_src1.y + vec_src2.y;

	return vec_dst;
}

/**
 * @brief �x�N�g���̍���Ԃ�
 */
Vector_t VectorDiff(const Vector_t vec_src1,
					const Vector_t vec_src2)
{
	Vector_t vec_dst;

	vec_dst.x = vec_src1.x - vec_src2.x;
	vec_dst.y = vec_src1.y - vec_src2.y;

	return vec_dst;
}

Vector_fl_t VectorDiff_fl(const Vector_fl_t vec_src1,
				          const Vector_fl_t vec_src2)
{
	Vector_fl_t vec_dst;

	vec_dst.x = vec_src1.x - vec_src2.x;
	vec_dst.y = vec_src1.y - vec_src2.y;

	return vec_dst;
}

/**
 * �x�N�g�����X�J���[�{�ɂ���
 */
Vector_t VectorScalarMultiple(const Vector_t vec_src,
							  const double mag)
{
	Vector_t vec_dst;

	vec_dst.x = vec_src.x * mag;
	vec_dst.y = vec_src.y * mag;

	return vec_dst;
}

Vector_fl_t VectorScalarMultiple_fl(const Vector_fl_t vec_src,
							        const FLOAT mag)
{
	Vector_fl_t vec_dst;

	vec_dst.x = vec_src.x * mag;
	vec_dst.y = vec_src.y * mag;

	return vec_dst;
}

/**
 * �x�N�g������]����
 */
Vector_t VectorRotate(const Vector_t vec_src,
					  const double rot_rad)
{
	Vector_t vec_dst;

	vec_dst.x = vec_src.x * cos(rot_rad) - vec_src.y * sin(rot_rad);
	vec_dst.y = vec_src.x * sin(rot_rad) + vec_src.y * cos(rot_rad);

	return vec_dst;
}

Vector_fl_t VectorRotate_fl(const Vector_fl_t vec_src,
					        const FLOAT rot_rad)
{
	Vector_fl_t vec_dst;

	vec_dst.x = vec_src.x * cosf(rot_rad) - vec_src.y * sinf(rot_rad);
	vec_dst.y = vec_src.x * sinf(rot_rad) + vec_src.y * cosf(rot_rad);

	return vec_dst;
}

/**
 * @brief �x�N�g���̍��W�ϊ����s��
 *
 * vec_ref �𒆐S�Ƃ�, ang_rod [rad] ��]�������x�N�g����Ԃ�
 */
Vector_t CoordTrans(const Vector_t vec_src,
					const Vector_t vec_ref,
					const double ang_rot)
{
	Vector_t vec_dst;
	Vector_t vec_temp;

	vec_temp = VectorDiff(vec_src, vec_ref);

	vec_dst = VectorRotate(vec_temp, -ang_rot);

	return vec_dst;
}

Vector_fl_t CoordTrans_fl(const Vector_fl_t vec_src,
					      const Vector_fl_t vec_ref,
					      const FLOAT ang_rot)
{
	Vector_fl_t vec_dst;
	Vector_fl_t vec_temp;

	vec_temp = VectorDiff_fl(vec_src, vec_ref);

	vec_dst = VectorRotate_fl(vec_temp, -ang_rot);

	return vec_dst;
}