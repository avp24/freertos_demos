/****************************************************************************** */
/*                                                                              */
/*     Copyright (c) 2012 Nissan, Japan                                         */
/*                                                                              */
/* **************************************************************************** */
/*                                                                              */
/* Project:     Preceding Vehicle Recognize                                     */
/* Module:      Common Function Module                                          */
/* Version      1.0                                                             */
/* Author:                                                                      */
/* Date:                                                                        */
/* Description:                                                                 */
/* Revision History:                                                            */
/*                                                                              */
/********************************************************************************/
#include	"utypedef.h"
#include	"n_apl_common.h"
#include	"rir_common.h"	/* �b�� */
#if	1
#include	<float.h>	/* C:\Program Files\Renesas\Hew_001\Tools\Renesas\Sh\9_4_1\include */
//#include	<math.h>	/* C:\Program Files\Renesas\Hew_001\Tools\Renesas\Sh\9_4_1\include */
//#include	<mathf.h>	/* C:\Program Files\Renesas\Hew_001\Tools\Renesas\Sh\9_4_1\include */
#endif

FLOAT	fl_CalcAbs(	FLOAT	in	){
    return( fl_abs(in) );
}
FLOAT	fl_rir_add_max_min(	FLOAT	v_base,
							FLOAT	v_add,
							FLOAT	v_max,
							FLOAT	v_min	){
    return( fl_add_max_min(v_base,v_add,v_max,v_min) );
}
sint32	si32_rir_add_max_min(	sint32	base,
								sint32	add,
								sint32	max,
								sint32	min		){
    return( si32_add_max_min(base,add,max,min) );
}
uint16	ui16_rir_add_max_min(	uint16	base,
								uint16	add,
								uint16	max,
								uint16	min		){
    return(ui16_add_max_min(base,add,max,min) );
}
uint16	ui16_rir_sub_max_min(	uint16	base,
								uint16	sub,
								uint16	max,
								uint16	min		){
    return(ui16_sub_max_min(base,sub,max,min) );
}
/* 2�i�J���Z�ŕ������̉��Z */
uint32	ui32_rir_sqrt(	uint32	 in 	){
    return( ui32_sqrt(in) );
}
#if	0
FLOAT	fl_rir_sqrt(	FLOAT	v_in,
						uint8	v_bitrate	){
	FLOAT	out;
	sint32	fix_in		= si32_Float2Fix( v_in, v_bitrate );
	sint32	fix_out		= (sint32)ui32_rir_sqrt( (uint32)fix_in );
	FLOAT	float_out	= fl_Fix2Float( fix_out, v_bitrate );
	return( float_out );
}
#else
FLOAT	fl_rir_sqrt( FLOAT v_in ){
	return( fl_sqrt( v_in ) );
}
#endif
/* func_pythagoras */
FLOAT	fl_rir_pythagorean_theorem(	FLOAT	v_line1,
									FLOAT	v_line2	){    
	return( fl_pythagorean_theorem(v_line1,v_line2) );
}
/* func_approx_pythagoras */
FLOAT	fl_rir_pythagorean_theorem_ax(	FLOAT	v_line1,
										FLOAT	v_line2	){
    return( fl_pythagorean_theorem_ax(v_line1, v_line2) );
}
/* r_obj_dist_ICC_update */
FLOAT	fl_rir_trajectory_calc(	FLOAT	v_radius,			/* [m] */
								FLOAT	v_lateral_dist,		/* [m] */
								FLOAT	v_distance,			/* [m] */
								FLOAT	v_approx_th		){	/* [m] */
    return( fl_trajectory_calc(v_radius, v_lateral_dist, v_distance, v_approx_th ) );
}

/* fSTR_ON_judge */
uint8	ui8_rir_str_on_judge(	FLOAT	v_str_angle,
								FLOAT	m_mask_on_th,
								FLOAT	m_mask_off_th,
								uint8	out_z	){
	uint8	out;
	if(
		( v_str_angle <= -m_mask_on_th ) || ( m_mask_on_th <= v_str_angle )
	){
		out	= NAP_OFF;
	}
	else if(
		( -m_mask_off_th < v_str_angle ) && ( v_str_angle < m_mask_off_th )
	){
		out	= NAP_ON;
	}
	else{
		out	= out_z;
	}
	return( out );
}
/* lpf */
FLOAT	fl_rir_lpf(	FLOAT	in,
					FLOAT	out_z,
					FLOAT	m0,
					FLOAT	m1		){
    return( fl_lpf(in,out_z,m0,m1) );
}
/* func_2nd_lpf */
FLOAT	fl_rir_2nd_lpf(	FLOAT	a_in[],
						FLOAT	a_out[],
						FLOAT	m0,
						FLOAT	m1,
						FLOAT	m2	){
    return(fl_2nd_lpf(a_in,a_out,m0,m1,m2) );
}

/* bpf */
FLOAT 	fl_rir_bpf(	uint8	reset,		/* �������t���O */
					FLOAT	in,			/* �t�B���^���� */
					FLOAT	*in_z1,		/* �t�B���^���́i�O��l�j*/
					FLOAT	*in_z2,		/* �t�B���^���́i�O�X��l�j*/
					FLOAT	*out_z1,	/* �t�B���^�o�́i�O��l�j*/
					FLOAT	*out_z2,	/* �t�B���^�o�́i�O�X��l�j*/
					FLOAT	mdvsp0,		/* �t�B���^�萔�P */
					FLOAT	mdvsp1,		/* �t�B���^�萔�Q */
					FLOAT	mdvsp2	)	/* �t�B���^�萔�R */
{
    return( fl_bpf(reset,in,in_z1,in_z2,out_z1,out_z2,mdvsp0,mdvsp1,mdvsp2 ) );
}
#if	1	/* 2013.03.08 */
void	v_SetAllRingBuffFL(	FLOAT			data,
							T_RING_BUFF_FL*	ring	){
    vSetAllRingBuffFL(data,ring);
}
#endif
void	v_PushRingBuffFL(	FLOAT			data,
							T_RING_BUFF_FL*	ring	){
    vPushRingBuffFL(data,ring);
}
FLOAT	FL_GetRingBuffFL(	uint16			pos,
							T_RING_BUFF_FL*	ring	){
    return( fl_GetRingBuffFL(pos,ring) );
}
static	uint16	NI_OFFSET_CALC(	const	sint16*	Table_in,
								const	sint16	Table_size,
								const	sint16	in			){
	uint16	offset;
	
	/* ++[�e�[�u���T�C�Y��1����] */
	if(
		( Table_size <= 1 )
	){
		offset	= 0;
	}
	else{
		/* ++[X��������] */
		if(
			( (sint16)*( Table_in ) <= (sint16)*( Table_in + 1 ) )
		){
			for( offset = 1 ; ( ( (sint16)*( Table_in + offset ) <= in ) && ( offset < Table_size ) ) ; offset++ ){
				;
			}
		}
		/* ++[X�����~��] */
		else{
			for( offset = 1 ; ( ( in <= (sint16)*( Table_in + offset ) ) && ( offset < Table_size ) ) ; offset++ ){
				;
			}
		}
		/* ++[����] */
		offset	= offset - 1;
	}
	/* ++[�o��] */
	return( offset );
}
sint16	NI_TBLWS(	const	sint16*	Table_y,
					const	sint16*	Table_x,
					const	sint16	Table_size,
					const	sint16	in			){
	sint32	out;
	uint16	offset;
	
	/* ++[X����ʒu�Z�o] */
	offset	= NI_OFFSET_CALC(	Table_x,
								Table_size,
								in	);
	/* ++[�Z�o] */
	if(
		( offset == 0 )													/* �I�t�Z�b�g 0 */
		&&
		(
			(
				( (sint16)*( Table_x ) <= (sint16)*( Table_x + 1 ) )	/* X�������� */
				&&
				( in <= (sint16)*( Table_x ) )							/* ���͂�X���ŏ��l�ȉ� */
			)
			||
			(
				( (sint16)*( Table_x + 1 ) < (sint16)*( Table_x ) )		/* X�����~�� */
				&&
				( (sint16)*( Table_x ) <= in )							/* ���͂�X���ő�l�ȏ� */
			)
		)
	){
		out	= (sint32)*( Table_y );
	}
	else{
		/* ++[���͂�����X���ő�l�ȏ�or�~��X���ŏ��l�ȉ�] */
		if(
			( ( Table_size - 1 ) <= (sint32)offset )
		){
			out	= (sint32)*( Table_y + offset );
		}
		else{
			out	= (sint32)*( Table_y + offset )												/* ��l */
				+ (( (sint32)*( Table_y + offset + 1 ) - (sint32)*( Table_y + offset ) )	/* Y����  */	/* Add a parenthesis to do an operator precedence explicitly(QAC) 20191029 */
				/ ( (sint32)*( Table_x + offset + 1 ) - (sint32)*( Table_x + offset ) )		/* X����  *//* -> �X�� */
				* ( in - (sint32)*( Table_x + offset ) ));									/* ����   */
		}
	}
	/* ++[�o��] */
	return( (sint16)out );
}
sint16	NI_MAPWS(	const	sint16*	Table_z,
					const	sint16*	Table_x,
					const	sint16	Table_x_size,
					const	sint16*	Table_y,
					const	sint16	Table_y_size,
					const	sint16	in_x,
					const	sint16	in_y			){
	uint16	offset_x, offset_y, offset_z;
	sint32	y0, y1, out;
	
	/* ++[X����ʒu�Z�o] */
	offset_x	= NI_OFFSET_CALC(	Table_x,
									Table_x_size,
									in_x	);
	/* ++[Y����ʒu�Z�o] */
	offset_y	= NI_OFFSET_CALC(	Table_y,
									Table_y_size,
									in_y	);
	/* ++[Z�z���ʒu�Z�o] */
	offset_z	= offset_y * Table_x_size + offset_x;
	/* ++[Y�l�Z�o] */
	if(
		( offset_y == 0 )
		||
		( ( Table_y_size - 1 ) <= offset_y )
	){
		y0	= (sint32)*( Table_z + offset_z );
		y1	= (sint32)*( Table_z + offset_z + 1 );
	}
	else{
		y0	= ( (sint32)*( Table_z + offset_z ) )															/* ��l */
			+ (( (sint32)*( Table_z + offset_z + Table_x_size ) - (sint32)*( Table_z + offset_z ) )			/* Z����  */	/* Add a parenthesis to do an operator precedence explicitly(QAC) 20191029 */
			/ ( (sint32)*( Table_y + offset_y + 1 ) - (sint32)*( Table_y + offset_y ) )						/* Y����  *//* -> �X�� */
			* ( in_y - (sint32)*( Table_y + offset_y ) ));													/* ����Y  */
		y1	= ( (sint32)*( Table_z + offset_z + 1 ) )														/* ��l */
			+ (( (sint32)*( Table_z + offset_z + Table_x_size + 1 ) - (sint32)*( Table_z + offset_z + 1 ) )	/* Z����  */	/* Add a parenthesis to do an operator precedence explicitly(QAC) 20191029 */
			/ ( (sint32)*( Table_y + offset_y + 1 ) - (sint32)*( Table_y + offset_y ) )						/* Y����  *//* -> �X�� */
			* ( in_y - (sint32)*( Table_y + offset_y ) ));													/* ����Y  */
	}
	/* ++[�o�͒l�Z�o] */
	if(
		( offset_x == 0 )
		||
		( ( Table_x_size - 1 ) <= offset_x )
	){
		out	= y0;
	}
	else{
		out	= y0																							/* ��l */
			+ (( y1 - y0 )																					/* Y�l��  */	/* Add a parenthesis to do an operator precedence explicitly(QAC) 20191029 */
			/ ( (sint32)*( Table_x + offset_x + 1 ) - (sint32)*( Table_x + offset_x ) )						/* X����  *//* -> �X�� */
			* ( in_x - (sint32)*( Table_x + offset_x ) ));													/* ����X  */
	}
	/* ++[�o��] */
	return( (sint16)out );
}

FLOAT fl_PFCW_ConvDistSisya(FLOAT in){
	/* ADAS5 PFCW pfcw_input.c ��蕪�� 20190308 XW1
	SWC�Ԃ̈ˑ��֌W���������邽�߁APFCW��trajectory�v�Z��CAM_RAD�Ɉڊ�
	�v�Z�O�̏����ɗp����֐��͗��҂���Ăяo���K�v������̂Œ��o */
	
    FLOAT out;
    sint32 tmp;
	
    in *= 10000.f;
    tmp = (sint32)in;
    tmp += 5;
    tmp /= 10;
    out = (FLOAT)tmp;
    out /= 1000.f;
    return(out);
}
