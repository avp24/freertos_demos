/******************************************************************************
 *
 *     Copyright (c) 2013 Nissan, Japan
 *
 ******************************************************************************
 *
 * Project:
 * Module:      Forward Emergency Braking
 * Version      0.1
 * Author:
 * Date:
 *
******************************************************************************/
#define 	__FEB_CONST_C__

/*****************************************************************************/
/* INCLUDE FILES								                             */
/*****************************************************************************/
#if	1	/* ADAS2->3 add */
#include	"data_types.h"
#include	"spec.h"
#include	"n_common.h"
/*#include	"sysinfo.h"*//* ADAS3.1 20151111 S.Hiko �g���Ă��Ȃ��̂ō폜 */
#endif
#include	"FEB_CommonFunc.h"
#include 	"FEB_Const.h"
