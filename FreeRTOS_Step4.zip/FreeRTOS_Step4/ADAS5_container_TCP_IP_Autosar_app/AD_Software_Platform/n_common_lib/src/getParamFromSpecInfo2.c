/*
	Copyright (c) 2021 Nissan, Japan
*/

#include "getParamFromSpecInfo2.h"

typedef struct {
     FUNC_SWITCH_ID id;
     uint8 bytePos;
     uint8 bitPos;
     uint8 bitSize;
}SPECINFO2_DATA;

typedef enum{
	BYTE_POS_0 = 0,
	BYTE_POS_1,
	BYTE_POS_2,
	BYTE_POS_3,
	BYTE_POS_4,
	BYTE_POS_5,
	BYTE_POS_6,
	BYTE_POS_7,
	BYTE_POS_8,
	BYTE_POS_9,
	BYTE_POS_10,
	BYTE_POS_11,
	BYTE_POS_12,
	BYTE_POS_13,
	BYTE_POS_14,
	BYTE_POS_15,
	BYTE_POS_16,
	BYTE_POS_17,
	BYTE_POS_18,
	BYTE_POS_19,
	BYTE_POS_20,
	BYTE_POS_21,
	BYTE_POS_22,
	BYTE_POS_23,
	BYTE_POS_24,
	BYTE_POS_25,
	BYTE_POS_26,
	BYTE_POS_27,
	BYTE_POS_28,
	BYTE_POS_29,
	BYTE_POS_30,
	BYTE_POS_31
}BYTE_POS;

typedef enum{
	BIT_POS_0 = 0,
	BIT_POS_1,
	BIT_POS_2,
	BIT_POS_3,
	BIT_POS_4,
	BIT_POS_5,
	BIT_POS_6,
	BIT_POS_7
}BIT_POS;

static const SPECINFO2_DATA specInfo2AssignTbl[FUNC_SWITCH_ID_MAX] = {
	// FUNC_SWITCH_ID			// bytePos	// bitPos	// bit size
	// Byte 0
	{ N_ENCAP_FEB, 				BYTE_POS_0, BIT_POS_0, 	1 },
	{ N_ENCAP_FEB_2ND, 			BYTE_POS_0, BIT_POS_1, 	1 },
	{ N_BIR_ENABLE, 			BYTE_POS_0, BIT_POS_2, 	1 },
	{ N_BIR_ENABLE_V2, 			BYTE_POS_0, BIT_POS_3, 	1 },
	{ N_JNCAP_NIGHT_WITH_LIGHT, BYTE_POS_0, BIT_POS_4, 	1 },
	{ N_JNCAP_NIGHT_NO_LIGHT, 	BYTE_POS_0, BIT_POS_5, 	1 },
	{ N_RIR_ADB_PEDESTRIAN, 	BYTE_POS_0, BIT_POS_6, 	1 },
	{ PED_FCW_WARN, 			BYTE_POS_0, BIT_POS_7, 	1 },
	// Byte 1
	{ WITH_R_AEB,				BYTE_POS_1, BIT_POS_0, 	1 },
	{ WITH_EAP, 				BYTE_POS_1, BIT_POS_1, 	1 },
	{ WITH_EAP2,				BYTE_POS_1, BIT_POS_2, 	1 },
	{ N_EAP2, 					BYTE_POS_1, BIT_POS_3, 	1 },
	{ OFFLAMP_COMMON, 			BYTE_POS_1, BIT_POS_4, 	1 },
	{ CS_ENABLE, 				BYTE_POS_1, BIT_POS_5, 	1 },
	{ EAP_BOSCH_SONAR, 			BYTE_POS_1, BIT_POS_6, 	1 },
	// Byte 2
	{ ENGINE_TYPE, 				BYTE_POS_2, BIT_POS_0, 	3 },
	{ N_EAP_TYPE_CONV, 			BYTE_POS_2, BIT_POS_3, 	1 },
	{ N_EAP_TYPE_FFHEV, 		BYTE_POS_2, BIT_POS_4, 	1 },
	{ N_EAP_TYPE_EV, 			BYTE_POS_2, BIT_POS_5, 	1 },
	{ N_EAP_TYPE_SEHEV, 		BYTE_POS_2, BIT_POS_6, 	1 },
	// Byte 3
	{ TJP, 						BYTE_POS_3, BIT_POS_0, 	1 },
	{ N_ENCAP_LDP, 				BYTE_POS_3, BIT_POS_1, 	1 },
	{ N_CNCAP_LDP, 				BYTE_POS_3, BIT_POS_2, 	1 },
	{ DEF_JAA_ENABLE, 			BYTE_POS_3, BIT_POS_3, 	1 },
	{ DEF_TA_ENABLE, 			BYTE_POS_3, BIT_POS_4, 	1 },
	{ DEF_AHB_ENABLE, 			BYTE_POS_3, BIT_POS_5, 	1 },
	{ DEF_FDT_ONCOMINGCARSIDE, 	BYTE_POS_3, BIT_POS_6, 	1 },
	{ N_PFEB_LIMIT_65KPH, 		BYTE_POS_3, BIT_POS_7, 	1 },
	// Byte 4
	{ USV_SONAR_VER, 			BYTE_POS_4, BIT_POS_0, 	4 },
	{ ELKA_ONCOMING_PTW, 		BYTE_POS_4, BIT_POS_4, 	1 },
	// Byte 5
	{ BIR_BRK_LATE_LIMIT_CAMWIDTH_ADJUST, BYTE_POS_5, BIT_POS_0, 1 },
	{ RIR_USE_CIR_DRIVER_TARGET_YAWRATE,  BYTE_POS_5, BIT_POS_1, 1 },
	{ RIRFAEB_PED_CHANGE_RADLATENCY,	  BYTE_POS_5, BIT_POS_2, 1 },
	{ DEF_AEB_PTW_ENABLE,  				  BYTE_POS_5, BIT_POS_3, 1 },
	// Byte 6
	{ LSS_ONOFF_WITHOUT_SSSW, 	BYTE_POS_6, BIT_POS_1, 	1 },
	// Byte 7
	{ DEF_AEB_CROSSING_ENABLE,	BYTE_POS_7, BIT_POS_0, 	1 },
	{ DEF_FCTA_ENABLE,			BYTE_POS_7, BIT_POS_1, 	1 },
	{ APTIVE_FRS_RADAR,			BYTE_POS_7, BIT_POS_2, 	1 },
};

static sint32 power(sint32 num, sint32 exp);

/*************************************************************
* @brief SPECINFO2�������id�̒l���擾����
* @param (id) �擾�������p�����[�^��FUNC_SWITCH_ID
* @param (specInfo2Val) V_x_SPECINFO2�̒l
* @return id�̒l
**************************************************************/
uint8 getParamFromSpecInfo2(FUNC_SWITCH_ID id, uint8* specInfo2Val){
	uint8 retVal = 0;
	for(uint32 i = 0; i < FUNC_SWITCH_ID_MAX; i++){
		if( specInfo2AssignTbl[i].id == id){
			for(uint8 offset = 0; offset < specInfo2AssignTbl[i].bitSize; offset++){
				retVal += power(2, offset) * ( (specInfo2Val[specInfo2AssignTbl[i].bytePos] >> (specInfo2AssignTbl[i].bitPos+offset) ) & 0x1);
			}
			return retVal;
		}
	}
	return 0;
}

/*************************************************************
* @brief num��exp�悵���l���v�Z����
* @param (num) ��
* @param (exp) �w��
* @return num��exp�悵���l
**************************************************************/
static sint32 power(sint32 num, sint32 exp){
	sint32 result = 1;
    if(exp < 0){
		 return 0;
	}
	while(exp-- > 0){
		result *= num;
	}
    return result;
}
