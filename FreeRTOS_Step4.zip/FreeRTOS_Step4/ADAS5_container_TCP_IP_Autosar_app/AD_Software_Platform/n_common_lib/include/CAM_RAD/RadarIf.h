/******************************************************************************
 *
 *     Copyright (c) 2012 Nissan, Japan
 *
 ******************************************************************************
 *
 * Project:     Radar Body If function.
 * Module:      Main Body Module
 * Version      1.0
 * Author:      
 * Date:        
 * Description: 
 * Revision History:
 *
******************************************************************************/
#ifndef __RADAR_IF_H__
#define __RADAR_IF_H__

/* ################################################ */
/*	�C���N���[�h                                    */
/* ################################################ */
#include	"spec.h"
#include	"utypedef.h"
#include    "n_apl_common.h"
#if	1	/* 2012.12.19 */
#include	"RadarIfFix.h"
#endif	/* 2012.12.19 */

/* ############################################ */
/*	�{�̂��邢��extern�錾���̐؂蕪��          */
/* ############################################ */
#ifdef __RADAR_IF_C__
#define EXTERN
#else
#define EXTERN  extern
#endif

/* ################################################ */
/*              �}�N����`                          */
/* ################################################ */

/* ################################################ */
/*	�\���̐錾                                    */
/* ################################################ */
typedef struct{
    FLOAT   YawRate;        /* [deg/s] (+,-) = (Right,Left) */
#if	1	/* 2013.01.23 */
    FLOAT   RawLength;      /* [m] */
    FLOAT   RawWidth;       /* [m] */
#else
    FLOAT   LaneRadius;     /* [m] (+,-) = (RightTurn,LeftTurn) */
    FLOAT   LatencyTime;    /* [s] */
#endif
    FLOAT   AlignMoniQuality;
    uint8   fWarn               :1;
    uint8   fWarnBrake          :1;
    uint8   fActBrake           :1;
    uint8   fObjMeasured        :1;
    uint8   fSensExtErr         :1;
    uint8   fSensHighTempErr    :1;
    uint8   fSensMisaligned     :1;
    uint8   fSensDefective      :1;
    uint8   fSupplyVoltageLow   :1;
    uint8   fCanRxInvalid       :1;
    uint8   fSensBlockage       :1;
    uint8   padding             :5;
}T_RAD_STATUS;

typedef struct{
    /*FLOAT   Curve;*/              /* [1/m]   */	/* 2015.05.21 K.N ���g�p */
    /*FLOAT   CurveVariation;*/     /* [1/m]   */	/* 2015.05.21 K.N ���g�p */
    /*FLOAT   YawAngle;*/           /* [rad]   */	/* 2015.05.21 K.N ���g�p */
    /*FLOAT   Confidence;*/         /* [m]     */	/* 2015.05.21 K.N ���g�p */
    FLOAT   Y_Left;            /* [m]     */		/* 2015.05.21 K.N �Q�ƗL�� */
    FLOAT   Y_Right;            /* [m]     */		/* 2015.05.21 K.N �Q�ƗL�� */
    /*uint8   TrackingStat;*/						/* 2015.05.21 K.N ���g�p */
    /*uint8   LeftTrackStat;*/						/* 2015.05.21 K.N ���g�p */
    /*uint8   RightTrackStat;*/						/* 2015.05.21 K.N ���g�p */
    /*uint8   pad;*/								/* 2015.05.21 K.N �s�v */
}T_RAD_ROAD_ESTIMATION;

typedef struct{
    uint8   ID;
    uint8   Type;
    uint8   Dynamic;
    /*uint8   LostReason;*/					/* 2015.11.05 K.N ���g�p */
    uint8   Status;
    /*uint8   ObjectProbabilityofExist;*/	/* 2015.11.05 K.N ���g�p */
    /*uint8	Valid;*/						/* 2015.11.05 K.N ���g�p */
    /*uint8	pad;*/
    FLOAT   RCS;                        /* [-]                      */
    FLOAT   Distance;                   /* [m]                      */            
    FLOAT   LateralDistance;            /* [m] (+,-) = (Right,Left) *//* �� CAN�ƕ��������]���Ă��� */
    FLOAT   RelativeSpeed;              /* [m/s]                    */
    FLOAT   RelativeAcceleration;       /* [m/s^2] (+,-) = (Acceleration,DeAcceleration)    */
    FLOAT   Trajectory;                 /* [m] (+,-) = (�s���C�s��) */
    FLOAT   Width;                      /* [m]                      */
    FLOAT   Length;                     /* [m]                      */
	FLOAT	TimeToCollision;
	FLOAT	ElevDistance;
	uint32	Age;
	uint8	Classification;
	uint8   ObstacleProbability;        /* [%]                      */
	uint8	ProbaMovable;
	uint8	Proba4Wheeler;
	uint8	ProbaTruck;
	uint8	ProbaCar;
	uint8	Proba2Wheeler;
	uint8	ProbaNonObstacle;
	uint8	ProbaPedestrian;
	uint8	CutInOut;
	uint8	LaneAssignment;
	uint8	ExistenceProb;
	uint16  ObjectProbabilityofExist;
#if CAM_RAD_AD2_ADD_DATA
	uint8   LostReason;
#endif
}T_RAD_RADAR_COMMON_DATA_BODY;
typedef struct{
    uint32  TotalArray;
    T_RAD_RADAR_COMMON_DATA_BODY Target[DEF_RADAR_DATA_NUM];
}T_RAD_RADAR_COMMON_DATA;

#if	DEF_TRANSFER_OBJ0
typedef struct {
	T_RAD_RADAR_COMMON_DATA_BODY_FIX	Data;
	T_RAD_RADAR_COMMON_DATA_BODY		FloatData;
	uint8								Compl_flag;
}T_RAD_COMPL_DATA;
#endif

typedef struct{
#if( N_RAD_TYPE == N_RAD_TYPE_BOSCH_FR5 )
    uint8   ID;																							/* 2015.05.21 K.N �Q�ƗL�� */
    uint8   HypoType;																					/* 2015.05.21 K.N �Q�ƗL�� */
    uint16  pad;
    FLOAT   RCS;                    /* [-]      */													/* 2015.05.21 K.N ���g�p */
    FLOAT   Distance;               /* [m]      */													/* 2015.05.21 K.N ���g�p */
    FLOAT   LateralDistance;        /* [m] (+,-) = (Right,Left)*//* �� CAN�ƕ��������]���Ă��� */	/* 2015.05.21 K.N ���g�p */
    FLOAT   RelativeSpeed;          /* [m/s]    */													/* 2015.05.21 K.N ���g�p */
    FLOAT   RelativeAcceleration;   /* [m/s^2] (+,-) = (Acceleration,DeAcceleration)*/				/* 2015.05.21 K.N ���g�p */
    FLOAT   Trajectory;             /* [m] (+,-) = (�s���C�s��)   */								/* 2015.05.21 K.N ���g�p */
    FLOAT   Width;                  /* [m]      */													/* 2015.05.21 K.N ���g�p */
    FLOAT   Length;                 /* [m]      */													/* 2015.05.21 K.N ���g�p */
    FLOAT   QualityGeneral;         /* [%]      */														/* 2015.05.21 K.N �Q�ƗL�� */
    /*FLOAT   QualityStationary;*/      /* [%]      */													/* 2015.05.21 K.N ���g�p */
    FLOAT   HypoProb;               /* [%]      */														/* 2015.05.21 K.N �Q�ƗL�� */
	uint8	ProbObstacle;		//ETH
	uint8	ExistenceProb;		//ETH
	uint16	pad1;
	FLOAT	DistanceVAR;		//ETH
	FLOAT	LateralDistanceVAR;	//ETH
	FLOAT	TimeToCollision;
	FLOAT	ElevDistance;
	uint8	Classification;
	uint32	Age;
	uint8	ProbaMovable;
	uint8	Proba4Wheeler;
	uint8	ProbaTruck;
	uint8	ProbaCar;
	uint8	Proba2Wheeler;
	uint8	ProbaNonObstacle;
	uint8	ProbaPedestrian;
	uint8	CutInOut;
	uint8	LaneAssignment;
	uint8	AebCdl;
    uint8   Status;
    uint8   Type;
    uint8   DynProp;
#else
    uint8   ID;																							/* 2015.05.21 K.N �Q�ƗL�� */
    uint8   HypoType;																					/* 2015.05.21 K.N �Q�ƗL�� */
    uint16  pad;
    /*FLOAT   RCS;*/                    /* [-]      */													/* 2015.05.21 K.N ���g�p */
    FLOAT   Distance;               /* [m]      */													/* 2015.05.21 K.N ���g�p */
    FLOAT   LateralDistance;        /* [m] (+,-) = (Right,Left)*//* �� CAN�ƕ��������]���Ă��� */	/* 2015.05.21 K.N ���g�p */
    FLOAT   RelativeSpeed;          /* [m/s]    */													/* 2015.05.21 K.N ���g�p */
    FLOAT   RelativeAcceleration;   /* [m/s^2] (+,-) = (Acceleration,DeAcceleration)*/				/* 2015.05.21 K.N ���g�p */
    FLOAT   Trajectory;             /* [m] (+,-) = (�s���C�s��)   */								/* 2015.05.21 K.N ���g�p */
    /*FLOAT   Width;*/                  /* [m]      */													/* 2015.05.21 K.N ���g�p */
    /*FLOAT   Length;*/                 /* [m]      */													/* 2015.05.21 K.N ���g�p */
    FLOAT   QualityGeneral;         /* [%]      */														/* 2015.05.21 K.N �Q�ƗL�� */
    /*FLOAT   QualityStationary;*/      /* [%]      */													/* 2015.05.21 K.N ���g�p */
    FLOAT   HypoProb;               /* [%]      */														/* 2015.05.21 K.N �Q�ƗL�� */
	uint8	ProbObstacle;		//ETH
	uint8	ExistenceProb;		//ETH
	uint16  pad1;
	FLOAT	DistanceVAR;		//ETH
	FLOAT	LateralDistanceVAR;	//ETH
	FLOAT	TimeToCollision;
	FLOAT	ElevDistance;
	uint8	Classification;
	uint32	Age;
	uint8	ProbaMovable;
	uint8	Proba4Wheeler;
	uint8	ProbaTruck;
	uint8	ProbaCar;
	uint8	Proba2Wheeler;
	uint8	ProbaNonObstacle;
	uint8	ProbaPedestrian;
	uint8	CutInOut;
	uint8	LaneAssignment;
	uint8	AebCdl;
#endif
#if	1	/* 2020.01.19 JA�ȊO�ł��g�p���郁���o������̂ŏ펞�L���� */	/*( DEF_JAA_ENABLE )*/	/* 2020.03.31 JAA���� */
	FLOAT	LatRelativeSpeed;
	FLOAT	LonAbsoluteSpeed;	/* 2020.07.02 �ǉ� */
	FLOAT	LatAbsoluteSpeed;	/* 2020.07.02 �ǉ� */
	FLOAT	HeadingAngle;		/* 2020.12.03 �ǉ� */
	FLOAT	Azimuth;			/* 2020.12.04 �ǉ� */
	FLOAT	LonRelativeAcceleration;	/* CTA�����ɒǉ� */
	FLOAT	LatRelativeAcceleration;	/* CTA�����ɒǉ� */
	FLOAT	LonAbsoluteAcceleration;	/* CTA�����ɒǉ� */
	FLOAT	LatAbsoluteAcceleration;	/* CTA�����ɒǉ� */
#endif
}T_RAD_FCW_FCA_SP_DATA_BODY;
typedef struct{
    uint32  TotalArray;
    T_RAD_FCW_FCA_SP_DATA_BODY Target[DEF_SP_FCW_FCA_DATA_NUM];
}T_RAD_FCW_FCA_SP_DATA;

typedef struct{
    uint8   ID;
    uint8   DynProp;
    uint8   Measured;
	uint8	WidthType;
	uint8	LengthType;
	uint8	Valid;
	uint16	pad;
    FLOAT   RCS;                    /* [-]      */
    FLOAT   Distance;               /* [m]      */
    FLOAT   LateralDistance;        /* [m] (+,-) = (Right,Left)*//* �� CAN�ƕ��������]���Ă��� */
    FLOAT   RelativeSpeed;          /* [m/s]    */
    FLOAT   Width;                  /* [m]      */
    FLOAT   Length;                 /* [m]      */
	FLOAT	ElevDistance;
	uint32	Age;
	uint8	ExistenceProb;
	uint8	Classification;
	uint8	ProbaMovable;
	uint8	Proba4Wheeler;
	uint8	ProbaTruck;
	uint8	ProbaCar;
	uint8	Proba2Wheeler;
	uint8	ProbaPedestrian;
	uint8	ProbaNonObstacle;
#if( N_RAD_TYPE == N_RAD_TYPE_BOSCH_FR5 )
	uint8	Status;
	uint8	Type;
	uint8	ObstacleProbability;
	uint8   pad1;
	uint16  pad2;
	FLOAT	RelativeAcceleration;
#endif
#if	1	/* 2020.01.19 JA�ȊO�ł��g�p���郁���o������̂ŏ펞�L���� */	/*( DEF_JAA_ENABLE )*/	/* 2020.03.31 JAA���� */
	FLOAT	LatRelativeSpeed;
	FLOAT	LonAbsoluteSpeed;	/* 2020.07.02 �ǉ� */
	FLOAT	LatAbsoluteSpeed;	/* 2020.07.02 �ǉ� */
	FLOAT	HeadingAngle;		/* 2020.12.03 �ǉ� */
	FLOAT	Azimuth;			/* 2020.12.04 �ǉ� */
#endif
}T_RAD_OBJ_DATA_BODY;
typedef struct{
    uint32  TotalArray;
    T_RAD_OBJ_DATA_BODY Target[DEF_OBJ_NUM];
}T_RAD_OBJ_DATA;

typedef struct{
    T_RAD_STATUS                Status;
    T_RAD_ROAD_ESTIMATION       RoadEst;
    T_RAD_RADAR_COMMON_DATA     RadarOriginal;
    T_RAD_RADAR_COMMON_DATA     AccDcaGstMasked;
    T_RAD_RADAR_COMMON_DATA     FcwFcaGstMasked;
    T_RAD_FCW_FCA_SP_DATA       FcwFcaSp;
    T_RAD_OBJ_DATA              Obj;
}T_RAD_INFO;

extern T_RAD_OBJ_DATA_BODY Sel20ObjInfo;					//20171208 Takei add for Fusion(Object recognition process for ICC)
extern T_RAD_OBJ_DATA_BODY Sel64ObjInfoLeft;
extern T_RAD_OBJ_DATA_BODY Sel64ObjInfoRight;


/* ################################################ */
/*	�ϐ��錾                                        */
/* ################################################ */

/* ################################################ */
/*	�v���g�^�C�v�錾                                */
/* ################################################ */
EXTERN T_RAD_INFO              const * const ptRAD_GetAllRadInfo(void);
EXTERN T_RAD_STATUS            const * const ptRAD_GetStatus(void);
EXTERN T_RAD_ROAD_ESTIMATION   const * const ptRAD_GetRoadEstimation(void);
EXTERN T_RAD_RADAR_COMMON_DATA const * const ptRAD_GetRadarCommonData(void);
EXTERN T_RAD_FCW_FCA_SP_DATA   const * const ptRAD_GetFcwFcaSpData(void);
EXTERN T_RAD_OBJ_DATA          *ptRAD_GetObjData(void);
EXTERN T_RAD_RADAR_COMMON_DATA const * const ptRAD_GetAccDcaGstMasked(void);
EXTERN T_RAD_RADAR_COMMON_DATA const * const ptRAD_GetFcwFcaGstMasked(void);
EXTERN void vRAD_ConvFix2Float(void);
#if	DEF_TRANSFER_OBJ0
EXTERN T_RAD_COMPL_DATA	const * const ptRAD_GetComplData(void);
#endif
#undef EXTERN
#endif
