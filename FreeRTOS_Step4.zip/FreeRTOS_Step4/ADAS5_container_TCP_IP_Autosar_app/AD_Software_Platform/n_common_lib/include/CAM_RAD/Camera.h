/******************************************************************************
 *
 *     Copyright (c) 2015 Nissan, Japan
 *
 ******************************************************************************
 *
 * Project:     
 * Module:      ���z�ԗ� Camera
 * Version      
 * Author:      
 * Date:        
 * Description: 
 * Revision History:
 *
******************************************************************************/
#ifndef __CAMERA_H__
#define __CAMERA_H__
#include	"spec.h"	/* B12P,LDP EUR-NCAP�Ή� */

#if CAM_RAD_AD2_ADD_DATA
#define	DEF_CAMERA_DATA_NUM		(20)
/* �W���F���� */
#define	DEF_CAM_SIGN_DETECT_NUM	(7)
#else
/* �F�����̐� */
#if		( DEF_CAM_USE_OBJ_NUM == DEF_CAM_USE_OBJ_NUM_20 )
#define	DEF_CAMERA_DATA_NUM_MAX	(20)	/* �Q�Ɖ\�ő�J�������̐� */
#define	DEF_CAMERA_DATA_NUM		(12)
#elif	( DEF_CAM_USE_OBJ_NUM == DEF_CAM_USE_OBJ_NUM_12 )
#define	DEF_CAMERA_DATA_NUM_MAX	(12)	/* �Q�Ɖ\�ő�J�������̐� */
#define	DEF_CAMERA_DATA_NUM		(12)
#else
	#error
#endif
/* �W���F���� */
#define	DEF_CAM_SIGN_DETECT_NUM	(2)
#endif

/* ID */
#define dCAM_ID_NO_OBJ_AVAILABLE			(0u)

/* Lane Assignment */
#define dCAM_LANE_ASSIGN_NOT_ASSIGNED		(0u)
#define dCAM_LANE_ASSIGN_EGO_LANE			(1u)
#define dCAM_LANE_ASSIGN_NEXT_LANE_LEFT 	(2u)
#define dCAM_LANE_ASSIGN_NEXT_LANE_RIGHT	(3u)
#define dCAM_LANE_ASSIGN_NEXTNEXT_LEFT		(4u)
#define dCAM_LANE_ASSIGN_NEXTNEXT_RIGHT		(5u)

/* Lane Movement Type */
#define dCAM_LANE_MOV_TYPE_UNKVOWN			(0u)
#define dCAM_LANE_MOV_TYPE_LEFT				(1u)
#define dCAM_LANE_MOV_TYPE_RIGHT			(2u)

/* Object Class */
#define dCAM_OBJ_CLASS_UNDECIDED			(0u)
#define dCAM_OBJ_CLASS_TRUCK				(1u)
#define dCAM_OBJ_CLASS_CAR					(2u)
#define dCAM_OBJ_CLASS_MOTOR_BIKE			(3u)
#define dCAM_OBJ_CLASS_BICYCLE				(4u)
#define dCAM_OBJ_CLASS_PEDESTRIAN			(5u)/*���s��*/

/* Motion Status */
#define dCAM_MO_STS_NOT_DEFINE				(0u)
#define dCAM_MO_STS_STANDING				(1u)
#define dCAM_MO_STS_PARKED					(2u)
#define dCAM_MO_STS_STOPPED_MOVABLE			(3u)
#define dCAM_MO_STS_UNKNOWN_MOVABLE			(4u)
#define dCAM_MO_STS_MOVING_MOVABLE			(5u)
#define dCAM_MO_STS_STOPPED_ONCOMING		(6u)
#define dCAM_MO_STS_UNKNOWN_ONCOMING		(7u)
#define dCAM_MO_STS_MOVING_ONCOMING			(8u)

/* Turn Indicator */
#define dCAM_TURN_IND_NOT_AVAILABLE			(0u)
#define dCAM_TURN_IND_OFF					(1u)
#define dCAM_TURN_IND_LEFT					(2u)
#define dCAM_TURN_IND_RIGHT					(3u)
#define dCAM_TURN_IND_BOTH					(4u)

/* Brake Light */
#define dCAM_BRK_LIGHT_NOT_AVAILABLE		(0u)
#define dCAM_BRK_LIGHT_ON					(1u)
#define dCAM_BRK_LIGHT_OFF					(2u)

/* LDW NRTA Reasons */
#define dCAM_LDW_NRTA_REASON_NO_VALID		(0u)
#define dCAM_LDW_NRTA_REASON_VALID			(1u)

/* LDW Warning */
#define dCAM_LDW_WARNING_OFF				(0u)
#define dCAM_LDW_WARNING_ACTIVE				(1u)

/* Line Confidence */
#define dCAM_LINE_CONFIDENCE_NO				(0u)
#define dCAM_LINE_CONFIDENCE_LOW			(1u)
#define dCAM_LINE_CONFIDENCE_MEDIUM			(2u)
#define dCAM_LINE_CONFIDENCE_HIGH			(3u)

/* -------------------- */
/* BOUNDARY TYPE        */
/* -------------------- */
#define BOUNDARY_TYPE_UNDECIDED      (0x0)
#define BOUNDARY_TYPE_SOLID          (0x1)
#define BOUNDARY_TYPE_ROAD_EDGE      (0x2)
#define BOUNDARY_TYPE_DASHED         (0x3)
#define BOUNDARY_TYPE_DOUBLE_LANE    (0x4)
#define BOUNDARY_TYPE_BOTTS_DOTS     (0x5)
#define BOUNDARY_TYPE_BARREL         (0x6)
/* Boundary Type */
#define dCAM_BOUNDARY_TYPE_UNDECIDED		(0u)
#define dCAM_BOUNDARY_TYPE_SOLID			(1u)
#define dCAM_BOUNDARY_TYPE_ROAD_EDGE		(2u)
#define dCAM_BOUNDARY_TYPE_DASHED			(3u)

/* LDW Inhibit Reasons */
#define dCAM_LDW_INH_REASONS_UNACTIVE		(0u)
#define dCAM_LDW_INH_REASONS_ACTIVE			(1u)

/* LDW RTA */
#define dCAM_LDW_RTA_NO_VALID				(0u)
#define dCAM_LDW_RTA_VALID					(1u)

/* LDW NRTA Reasons Speed */
#define dCAM_LDW_NRTA_SPD_NO_THRESHOLD		(0u)
#define dCAM_LDW_NRTA_SPD_THRESHOLD			(1u)

/* LDW NRTA Reasons Single */
#define dCAM_LDW_NRTA_SINGLE_NO_PERFORMANCE	(0u)
#define dCAM_LDW_NRTA_SINGLE_PERFORMANCE	(1u)

/* Lane Crossing */
#define dCAM_LANE_CROSSING_NOT_CROSS		(0u)
#define dCAM_LANE_CROSSING_CROSS			(1u)

/* Road Type*/
#define dCAM_ROAD_TYPE_UNKNOWN				(0u)
#define dCAM_ROAD_TYPE_HIGH_WAY				(1u)
#define dCAM_ROAD_TYPE_INNER_CITY			(2u)

/* Camera Initialised */
#define dCAM_CAMERA_INIT_NOT_INIT			(0u)
#define dCAM_CAMERA_INIT_COMPLETE			(1u)

/* LDW Failure */
#define dCAM_LDW_SUCCESS					(0u)
#define dCAM_LDW_FAIL						(1u)

/* Camera Caribration */
#define dCAM_CARIBRATION_NOT_COMP			(0u)
#define dCAM_CARIBRATION_COMP				(1u)

/* Camera High Temperature */
#define dCAM_TEMPERATURE_OK					(0u)
#define dCAM_HIGH_TEMPERATURE				(1u)

/* Construction Area */
#define dCAM_CONST_AREA_NOT_DETECTED		(0u)
#define dCAM_CONST_AREA_DETECTED_LEFT		(1u)
#define dCAM_CONST_AREA_DETECTED_RIGHT		(2u)
#define dCAM_CONST_AREA_DETECTED_BOTH		(3u)

/* Object No. */
#define dCAM_SIGN_DETECT_1ST				(0u)
#define dCAM_SIGN_DETECT_2ND				(1u)
#define dCAM_SIGN_DETECT_TOTAL				(2u)

/* Camera Failsafe Status */
#define dCAM_FS_FULL_BLOCKAGE				(0x8000)				/* Camera Failsafe Status		Bit15 : Full Blockage		*/
#define dCAM_FS_SMEARED_SPOTS				(0x4000)				/*								Bit14 : Smeared Spots		*/
#define dCAM_FS_PARTIAL_BLOCKAGE			(0x2000)				/*								Bit13 : Partial Blockage	*/
#define dCAM_FS_LOW_SUN						(0x1000)				/*								Bit12 : Low Sun				*/
#define dCAM_FS_SPLASHES					(0x0800)				/*								Bit11 : Splashes			*/
#define dCAM_FS_BLUR_IMAGE					(0x0400)				/*								Bit10 : Blur Image			*/
#define dCAM_FS_FOGGY_LIGHTS				(0x0200)				/*								Bit9  : Foggy Lights		*/
#define dCAM_FS_SMEAR_IMAGE					(0x0100)				/*								Bit8  : Smear Image			*/
#define dCAM_FS_CONSTRUCTION_AREA			(0x0080)				/*								Bit7  : Construction Area	*/
#define dCAM_FS_SUN_RAY						(0x0040)				/*								Bit6  : Sun Ray				*/
#define dCAM_FS_SPOT_HALOS					(0x0020)				/*								Bit5  : Spot Halos Frozen Windshield */

/* Alert Warning Indication Request A-C */
#define dCAM_WARN_IND_REQ_OFF				(0u)
#define dCAM_WARN_IND_REQ_ON				(1u)

/* PEDS CMB TTC Warning L1-L3 */
#define dCAM_WARNL_OFF						(0u)
#define dCAM_WARNL_ON						(1u)

/* Request A-C Suppression Reason */
#define dCAM_SUPP_VEHICLE_ACCEL				(0x0001)				/* �}�����R		Bit0  : Vehicle Acceleration																*/
#define dCAM_SUPP_LESS_KFCA_ACCEL			(0x0002)				/*				Bit1  : Less than K_FCA Accel Halo Time														*/
#define dCAM_SUPP_BRK_PDL					(0x0004)				/*				Bit2  : Brake Pedal																			*/
#define dCAM_SUPP_LESS_KFCA_BRK				(0x0008)				/*				Bit3  : Less than K_FCA Break Apply Halo Time												*/
#define dCAM_SUPP_FCA_ALERT					(0x0010)				/*				Bit4  : K_Suppress FCA Headway Alerts Requirement											*/
#define dCAM_SUPP_FSR_ACC_ENGAGED			(0x0020)				/*				Bit5  : FSR ACC is engaged																	*/
#define dCAM_SUPP_HITAOBJ_RELLANE_EQUAL		(0x0040)				/*				Bit6  : Highest Threat Object Relative Lane is Not Equal to 1 then Suppress Alerts			*/
#define dCAM_SUPP_HITAANA_RELLANE_GREAT		(0x0080)				/*				Bit7  : Highest Threat Analog Relative Lane is Greater than K_HiThreat Ritv Lane Value then Suppress Alerts */
#define dCAM_SUPP_TA_REL_SPD_GREAT			(0x0100)				/*				Bit8  : Target Relative Speed is Greater than Vehicle Speed									*/
#define dCAM_SUPP_VFP_LESS_VLP				(0x0200)				/*				Bit9  : VFp < VLp																			*/
#define dCAM_SUPP_OBJ_SATIONARY				(0x0400)				/*				Bit10 : The Object is a stationary, and the Vehicle is Maneuvering at Low Speed 40km/h		*/
#define dCAM_SUPP_CLU_SUPP_IMM_ALERT		(0x0800)				/*				Bit11 : Clutch Suppression of Imminent Alert												*/
#define dCAM_SUPP_CALIB_KFCA_LIA_TIME		(0x1000)				/*				Bit12 : Meeting Calibraiton K_FCA LIA Time Requirement										*/
#define dCAM_SUPP_TELLTALE_IND_FALSE		(0x2000)				/*				Bit13 : If Vehicle Aahead Telltale Indication Request is False								*/
#define dCAM_SUPP_CIPV_CRITERIA_REQ			(0x4000)				/*				Bit14 : Meeting CIPV Turning Criteria Requirement											*/
#define dCAM_SUPP_NRTA_CRITERIA_REQ			(0x8000)				/*				Bit15 : Meeting NRTA Criteria Requirements													*/

#define	dCAM_TSR_STATUS_NOTHING	(0U)	/* 00 : Nothing    */
#define	dCAM_TSR_STATUS_OFF		(1U)	/* 01 : Status OFF */
#define	dCAM_TSR_STATUS_ON		(2U)	/* 10 : Status ON  */

#define dCAM_LINETYPE_HOST		(0x0)	/* �擾vCAM_��CAN��� */
#define dCAM_LINETYPE_NEXT		(0x1)	/* �擾vCAM_��CAN��� */
/* 2017.12.11 ENCAP WARN TIMING �ϐ���*/
#define dCAM_LINETYPE_NOLDP				(0U)	/* LDW WARN�^�C�~���O�ݒ� ��쓮                 */
#define dCAM_LINETYPE_SOLID_ORG			(1U)	/* LDW WARN�^�C�~���O�ݒ� �����FORIGINAL����     */
#define dCAM_LINETYPE_SOLID_ENCAP		(2U)	/* LDW WARN�^�C�~���O�ݒ� �����FENCAP����        */
#define dCAM_LINETYPE_ROADEDGE_ORG		(3U)	/* LDW WARN�^�C�~���O�ݒ� RoadEdge�FORIGINAL���� */
#define dCAM_LINETYPE_ROADEDGE_ENCAP	(4U)	/* LDW WARN�^�C�~���O�ݒ� RoadEdge�FENCAP����    */

/* ################################################ */
/*	�C���N���[�h                                    */
/* ################################################ */
#include	"CameraIfFix.h"
#include	"CameraIf.h"
#include	"IfConvert_Camera.h"

#endif	/* __CAMERA_H__ */
