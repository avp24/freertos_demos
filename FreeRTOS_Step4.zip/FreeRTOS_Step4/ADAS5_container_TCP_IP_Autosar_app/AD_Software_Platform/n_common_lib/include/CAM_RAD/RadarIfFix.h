/******************************************************************************
 *
 *     Copyright (c) 2012 Nissan, Japan
 *
 ******************************************************************************
 *
 * Project:     Radar Body If function.
 * Module:      Main Body Module
 * Version      1.0
 * Author:      
 * Date:        
 * Description: 
 * Revision History:
 *
******************************************************************************/
#ifndef __RADAR_IF_FIX_H__
#define __RADAR_IF_FIX_H__

/* ################################################ */
/*	�C���N���[�h                                    */
/* ################################################ */
#include	"spec.h"
#include	"utypedef.h"

/* ############################################ */
/*	�{�̂��邢��extern�錾���̐؂蕪��          */
/* ############################################ */
#ifdef __RADAR_IF_FIX_C__
#define EXTERN
#else
#define EXTERN  extern
#endif

/* ################################################ */
/*              �}�N����`                          */
/* ################################################ */
#define DEF_RADAR_DATA_NUM      (6)
#define DEF_SP_FCW_FCA_DATA_NUM (4)
#if( ( N_RAD_TYPE == N_RAD_TYPE_CONTI_ARS410 ) || ( N_RAD_TYPE == N_RAD_TYPE_BOSCH_FR5 ) )
#define DEF_OBJ_NUM             (19)
#else
#define DEF_OBJ_NUM             (20)
#endif

/* -------------------------------- */
/* ���̈ʒu��`                     */
/* -------------------------------- */
#define RAD_TGT_CENTER          (0)     /* ��s��(����)     */
#define RAD_TGT_UPPER_CENTER    (1)     /* ���s��(����)   */
#define RAD_TGT_LEFT            (2)     /* ��s��(��)       */
#define RAD_TGT_RIGHT           (3)     /* ��s��(�E)       */
#define RAD_TGT_UPPER_LEFT      (4)     /* ���s��(��)     */
#define RAD_TGT_UPPER_RIGHT     (5)     /* ���s��(�E)     */

/* -------------------------------- */
/* �S�[�X�g�}�X�N��̃f�[�^�^�C�v   */
/* -------------------------------- */
#define RAD_TYPE_ACC_DCA    (0)
#define RAD_TYPE_FCW_FCA    (1)

/* -------------------------------------- */
/* P32R Obj0���ڂ�΍�(2017.06.28)      */
/* -------------------------------------- */
#define DEF_TRANSFER_OBJ0	(1)
#if DEF_TRANSFER_OBJ0
#define DEF_TRANSFER_OBJ0_WIDTH_TH				(0.1F/RAD_WIDTH_BITRATE)		/*���Ȃ����̂̑傫��[m]*/
#define DEF_TRANSFER_OBJ0_LENGTH_TH				(0.1F/RAD_LENGTH_BITRATE)		/*���Ȃ����̂̑傫��[m]*/
#define DEF_TRANSFER_OBJ0_RCS_TH				(0.F/RAD_RCS_BITRATE)			/*���Ȃ����̂�RCS[m]*/
#define DEF_TRANSFER_OBJ0_DISTANCE_TH			(50.F/RAD_DISTANCE_BITRATE)		/*������߂������͌��Ȃ�[m]*/
#define DEF_TRANSFER_OBJ0_DIFF_DISTANCE			(0.5F/RAD_DISTANCE_BITRATE)		/*�O��l�Ƃ̍���[m]*/
#define DEF_TRANSFER_OBJ0_DIFF_LATERAL_DISTANCE	(0.5F/RAD_LAT_DISTANCE_BITRATE)	/*�O��l�Ƃ̍���[m]*/
#define DEF_TRANSFER_OBJ0_DIFF_WIDTH			(0.2F/RAD_WIDTH_BITRATE)		/*�O��l�Ƃ̍���[m]*/
#define DEF_TRANSFER_OBJ0_DIFF_LENGTH			(0.2F/RAD_LENGTH_BITRATE)		/*�O��l�Ƃ̍���[m]*/
#define DEF_TRANSFER_OBJ0_DIFF_RCS				(4.F/RAD_RCS_BITRATE)		/*�O��l�Ƃ̍���[db]*/
#endif

/* ################################################ */
/*	�\���̐錾                                    */
/* ################################################ */
typedef struct{
    sint16  YawRate;        /* BR 0.05[deg/s] (+,-) = (Right,Left) */
#if	1	/* 2013.01.23 */
    uint16  RawLength;
    uint16  RawWidth;
#else
    uint8   LatencyTime;    /* BR 1[ms] */
    sint32  LaneRadius;     /* BR 1[m] (+,-) = (RightTurn,LeftTurn) */
#endif
    uint8   AlignMoniQuality;  /* BR (ARS301)0.2[-], (ARS410)5[-] */	
    uint8   fWarn               :1;
    uint8   fWarnBrake          :1;
    uint8   fActBrake           :1;
    uint8   fObjMeasured        :1;
    uint8   fSensExtErr         :1;
    uint8   fSensHighTempErr    :1;
    uint8   fSensMisaligned     :1;

    uint8   fSensDefective      :1;
    uint8   fSupplyVoltageLow   :1;
    uint8   fCanRxInvalid       :1;
    uint8   fSensBlockage       :1;
    uint8   padding             :5;
	uint8	pad1;
	uint16	pad2;
}T_RAD_STATUS_FIX;
#define RAD_YAWRATE_BITRATE         (0.05f)     /* BR 0.05[deg/s] (+,-) = (Right,Left)      */
#if	1	/* 2013.01.23 */
#define RAD_RAW_LENGTH_BITRATE      (0.01f)     /* BR 0.01[m] */
#define RAD_RAW_WIDTH_BITRATE       (0.01f)     /* BR 0.01[m] */
#else
// #define RAD_LANE_RADIUS_BITRATE (1.f)        /* BR 1 [m] (+,-) = (RightTurn,LeftTurn)    */
#define RAD_LATENCY_TIME_BITRATE    (0.001f)    /* BR 0.001[s]         */
#endif
#if( ( N_RAD_TYPE == N_RAD_TYPE_CONTI_ARS410 ) || ( N_RAD_TYPE == N_RAD_TYPE_BOSCH_FR5 ) )
#define RAD_ALIGN_QUALITY_BITRATE   (5.f)       /* BR 5[-] */
#else
#define RAD_ALIGN_QUALITY_BITRATE   (0.2f)      /* BR 0.2[-] */
#endif

/* +++ WarnFlg +++ */
#define RAD_WARNING_OFF (0)
#define RAD_WARNING_ON  (1)

/* +++ WarnBrakeFlg +++ */
#define RAD_WARN_BRAKE_OFF   (0)
#define RAD_WARN_BRAKE_ON    (1)

/* +++ ActBrakeFlg +++ */
#define RAD_FCW_FCA_ACT_BRAKE_OFF   (0)
#define RAD_FCW_FCA_ACT_BRAKE_ON    (1)

/* +++ OBJ MEASURED +++ */
#define RAD_SENS_NOT_MEAS        (0)
#define RAD_SENS_MEAS_OK         (1)

/* +++ SENE EXT ERROR +++ */
#define RAD_SENS_AVAILABLE      (0)
#define RAD_SENS_EXT_DISTURBED  (1)

/* +++ SENE HIGH TEMP +++ */
#define RAD_SENS_NOT_HIGH_TEMP  (0)
#define RAD_SENS_HIGH_TEMP      (1)

/* +++ SENE MISS ALIGNED +++ */
#define RAD_SENS_ALIGNED        (0)
#define RAD_SENS_MISS_SLIGNED   (1)

/* +++ SENE DEFECTIVE +++ */
#define RAD_SENS_NOT_DEFECTIVE  (0)
#define RAD_SENS_DEFECTIVE      (1)

/* +++ SENE VOLTAGE +++ */
#define RAD_SENS_VOLTAGE_OK     (0)
#define RAD_SENS_VOLTAGE_LOW    (1)

/* +++ SENE CAN RX +++ */
#define RAD_SENS_CAN_RX_OK          (0)
#define RAD_SENS_CAN_RX_UNVALID     (1)

/* +++ SENE BLOCAGE +++ */
#define RAD_SENS_NOT_BLOCKAGE       (0)
#define RAD_SENS_BLOCKAGE           (1)

typedef struct{
    /*sint32  Curve;*/              /* BR 1.E-06[1/m]   */								/* 2015.05.26 K.N ���g�p */
    /*sint32  CurveVariation;*/     /* BR 1.E-06[1/m]   */								/* 2015.05.26 K.N ���g�p */
    /*sint16  YawAngle;*/           /* BR 0.0001[rad]   */								/* 2015.05.26 K.N ���g�p */
    /*uint8   Confidence;*/         /* BR 0.1[m]        */								/* 2015.05.26 K.N ���g�p */
#if	1	/* 2013.03.14 */
    sint8   Y_Left;             /* BR 0.1[m]        */	/* 2013.03.14 uint8 �� sint8 */	/* 2015.05.26 K.N �Q�ƗL�� */
    sint8   Y_Right;            /* BR 0.1[m]        */	/* 2013.03.14 uint8 �� sint8 */	/* 2015.05.26 K.N �Q�ƗL�� */
#else
    uint8   Y_Left;             /* BR 0.1[m]        */
    uint8   Y_Right;            /* BR 0.1[m]        */
#endif
    /*uint8   TrackingStat;*/															/* 2015.05.26 K.N ���g�p */
    /*uint8   LeftTrackStat;*/															/* 2015.05.26 K.N ���g�p */
    /*uint8   RightTrackStat;*/															/* 2015.05.26 K.N ���g�p */
	uint16	pad1;																		/* 2015.05.26 K.N padding */
}T_RAD_ROAD_ESTIMATION_FIX;
#define RAD_CURVE_BITRATE           (0.000001f) /* BR 1.E-06[1/m]   */
#define RAD_CURVE_VARIATION_BITRATE (0.000001f) /* BR 1.E-06[1/m]   */
#define RAD_YAWANGLE_BITRATE        (0.0001f)   /* BR 0.0001[rad]   */
/*#define RAD_CONFIDENCE_BITRATE    (0.1f)    *//* BR 0.1[m]        */
#define RAD_Y_LEFT_BITRATE          (0.1f)      /* BR 0.1[m]        */
#define RAD_Y_RIGHT_BITRATE         (0.1f)      /* BR 0.1[m]        */

typedef struct{
    uint8   ID;
    sint8   RCS;                        /* BR 0.5[-]    */
    uint16  Distance;                   /* BR 0.1[m]    */            
    sint16  LateralDistance;            /* BR 0.1[m] (+,-) = (Right,Left)*//* �� CAN�ƕ��������]���Ă��� */
    sint16  RelativeSpeed;              /* BR 0.025[m/s] */
    sint16  RelativeAcceleration;       /* BR BR 0.0625[m/s^2] (+,-) = (Acceleration,DeAcceleration)*/
    sint16  Trajectory;                 /* BR 0.1[m] (+,-) = (�s���C�s��)   */
    uint8   ObstacleProbability;        /* BR 1[%]  */
    uint8   ObjectProbabilityofExist;
    uint8   pad1;
    uint16  Width;                      /* BR 0.01[m]   */
    uint8   Length;                     /* BR 0.1[m]    */
    uint8   Status;
    uint8   Type;
    uint8   Dynamic;
	uint8	ProbObstacle;		//ETH
	uint8	ExistenceProb;		//ETH
	uint16  pad2;
	FLOAT	DistanceVAR;		//ETH...�Œ菬���_�ł͂Ȃ�
	FLOAT	LateralDistanceVAR;	//ETH...�Œ菬���_�ł͂Ȃ�
	FLOAT	TimeToCollision;
	FLOAT	ElevDistance;
	uint32	Age;
	uint8	Classification;
	uint8	ProbaMovable;
	uint8	Proba4Wheeler;
	uint8	ProbaTruck;
	uint8	ProbaCar;
	uint8	Proba2Wheeler;
	uint8	ProbaPedestrian;
	uint8	ProbaNonObstacle;
	uint8	CutInOut;
	uint8	LaneAssignment;
	uint8   pad3;
#if CAM_RAD_AD2_ADD_DATA
	uint8   LostReason;
#else
    /*uint8   LostReason;*/					/* 2015.11.05 K.N ���g�p */
#endif
#if	1	/* 2012.12.19 */
	/*uint8	Valid;*/						/* 2015.11.05 K.N ���g�p */
#else
    uint8   pad1;
#endif	/* 2012.12.19 */
    /*uint16  pad2;*/
}T_RAD_RADAR_COMMON_DATA_BODY_FIX;
#define RAD_RCS_BITRATE             (0.5f)      /* BR 0.5[-]        */
#define RAD_DISTANCE_BITRATE        (0.1f)      /* BR 0.1[m]        */
#define RAD_LAT_DISTANCE_BITRATE    (0.1f)      /* BR 0.1[m] (+,-) = (Right,Left)*/
#define RAD_RELATIVE_SPEED_BITRATE  (0.025f)    /* BR 0.025[m/s]    */
#define RAD_RELATIVE_ACC_BITRATE    (0.0625f)   /* BR BR 0.0625[m/s^2] (+,-) = (Acceleration,DeAcceleration)*/
#define RAD_TRAJECTORY_BITRATE      (0.1f)      /* BR 0.1[m] (+,-) = (�s���C�s��)   */
//#define RAD_OBSTACLE_PROBABLITY   (1.f)       /* BR 1[%] */
#define RAD_WIDTH_BITRATE           (0.01f)     /* BR 0.01[m]       */
#define RAD_LENGTH_BITRATE      (0.1f)          /* BR 0.1[m]        */

/* +++ OBJECT TYPE +++ */
#define RAD_OBJ_TYPE_POINT          (0)
#define RAD_OBJ_TYPE_CAR            (1)
#define RAD_OBJ_TYPE_TRUCK          (2)
#define RAD_OBJ_TYPE_PEDESTRIAN     (3)
#define RAD_OBJ_TYPE_MOTORCYCLE     (4)
#define RAD_OBJ_TYPE_BICYCLE        (5)
#define RAD_OBJ_TYPE_WIDE           (6)
#define RAD_OBJ_TYPE_UNCLASSIFIED   (7)

/* +++ OBJECT DYNAMIC  +++ */
#define RAD_DYNAMIC_NONE        (0)
#define RAD_DYNAMIC_STANDING    (1)
#define RAD_DYNAMIC_STOPPED     (2)
#define RAD_DYNAMIC_MOVING      (3)
#define RAD_DYNAMIC_ONCOME      (4)
#define RAD_DYNAMIC_CROSS       (5)
#define RAD_DYNAMIC_FALSE       (6)	/* TPD 2018/7/11 slope */ /* FEB���S�őΉ� 20180907 TPD */

/* +++ OBJECT STATUS  +++ */
#define RAD_STATUS_NO_OBJ           (0)
#define RAD_STATUS_VALID_NEW        (1)
#define RAD_STATUS_OBJ_VALID        (2)
#define RAD_STATUS_INVALIT_VALUE    (3)

/* +++ LOST REASON  +++ */
#define RAD_REASON_NO_INFO          (0)
#define RAD_REASON_AZIMUTH_LEFT     (1)
#define RAD_REASON_AZIMUTH_RIGHT    (2)
#define RAD_REASON_ELEVATION        (3)

/* +++ OBJECT EXISTANCE RATE (%) +++ */
#define RAD_OBJ_EXISTANCE_INVALID       (0)
#define RAD_OBJ_EXISTANCE_UNDER_25_00   (1)
#define RAD_OBJ_EXISTANCE_UNDER_50_00   (2)
#define RAD_OBJ_EXISTANCE_UNDER_75_00   (3)
#define RAD_OBJ_EXISTANCE_UNDER_90_00   (4)
#define RAD_OBJ_EXISTANCE_UNDER_99_00   (5)
#define RAD_OBJ_EXISTANCE_UNDER_99_90   (6)
#define RAD_OBJ_EXISTANCE_UNDER_99_99   (7)

typedef struct{
    uint32  TotalArray;
    T_RAD_RADAR_COMMON_DATA_BODY_FIX Target[DEF_RADAR_DATA_NUM];
}T_RAD_RADAR_COMMON_DATA_FIX;

typedef struct{
#if( N_RAD_TYPE == N_RAD_TYPE_BOSCH_FR5 )
	sint8   RCS;                    /* BR 0.5[-]    */															/* 2015.05.26 K.N ���g�p */
    uint16  Distance;               /* BR 0.1[m]    */															/* 20170823 Kudo for Fusion */
    sint16  LateralDistance;        /* BR 0.1[m] (+,-) = (Right,Left)*//* �� CAN�ƕ��������]���Ă��� */			/* 20170823 Kudo for Fusion */
    sint16  RelLngtdnlSpd;          /* BR 0.025[m/s] */															/* 20170823 Kudo for Fusion */
    sint16  RelLngtdnlAcc;          /* BR BR 0.0625[m/s^2] (+,-) = (Acceleration,DeAcceleration)*/				/* 20170823 Kudo for Fusion */
    sint16  Trajectory;             /* BR 0.1[m] (+,-) = (�s���C�s��)   */										/* 20170823 Kudo for Fusion */
    uint16  Width;                  /* BR 0.01[m]   */
    uint8   Length;                 /* BR 0.1[m]    */
	uint8   QualityGeneral;         /* BR 1[%] */   /* �� �r�b�g���[�g�����̂ƈ�v���Ă��Ȃ��̂� 1 �ɒ��� */		/* 2015.05.26 K.N �Q�ƗL�� */
    /*uint8   QualityStationary;*/      /* BR 1[%] */   /* �� �r�b�g���[�g�����̂ƈ�v���Ă��Ȃ��̂� 1 �ɒ��� */	/* 2015.05.26 K.N ���g�p */
    uint8   HypoType;																								/* 2015.05.26 K.N �Q�ƗL�� */
    uint8   HypoProb;               /* BR 1[%] */   /* �� �r�b�g���[�g�����̂ƈ�v���Ă��Ȃ��̂� 1 �ɒ��� */		/* 2015.05.26 K.N �Q�ƗL�� */
	uint8   ID;																										/* 2015.05.26 K.N �Q�ƗL�� */
    uint16  pad;																								/* 2015.05.26 K.N ���g�p */
	uint8	ProbObstacle;		//ETH
	uint8	ExistenceProb;		//ETH
	uint16  pad1;
	FLOAT	DistanceVAR;		//ETH...�Œ菬���_�ł͂Ȃ�
	FLOAT	LateralDistanceVAR;	//ETH...�Œ菬���_�ł͂Ȃ�
	FLOAT	TimeToCollision;
	FLOAT	ElevDistance;
	uint32	Age;
	uint8	Classification;
	uint8	ProbaMovable;
	uint8	Proba4Wheeler;
	uint8	ProbaTruck;
	uint8	ProbaCar;
	uint8	Proba2Wheeler;
	uint8	ProbaPedestrian;
	uint8	ProbaNonObstacle;
	uint8	CutInOut;
	uint8	LaneAssignment;
	uint8	AebCdl;
    uint8   Status;
    uint8   Type;
    uint8   DynProp;
    uint8   pad2;
#else
    /*sint8   RCS;*/                    /* BR 0.5[-]    */															/* 2015.05.26 K.N ���g�p */
    uint16  Distance;               /* BR 0.1[m]    */															/* 20170823 Kudo for Fusion */
    sint16  LateralDistance;        /* BR 0.1[m] (+,-) = (Right,Left)*//* �� CAN�ƕ��������]���Ă��� */			/* 20170823 Kudo for Fusion */
    sint16  RelLngtdnlSpd;          /* BR 0.025[m/s] */															/* 20170823 Kudo for Fusion */
    sint16  RelLngtdnlAcc;          /* BR BR 0.0625[m/s^2] (+,-) = (Acceleration,DeAcceleration)*/				/* 20170823 Kudo for Fusion */
    sint16  Trajectory;             /* BR 0.1[m] (+,-) = (�s���C�s��)   */										/* 20170823 Kudo for Fusion */
    /*uint16  Width;*/                  /* BR 0.01[m]   */															/* 2015.05.26 K.N ���g�p */
    /*uint8   Length;*/                 /* BR 0.1[m]    */															/* 2015.05.26 K.N ���g�p */
    uint8   QualityGeneral;         /* BR 1[%] */   /* �� �r�b�g���[�g�����̂ƈ�v���Ă��Ȃ��̂� 1 �ɒ��� */		/* 2015.05.26 K.N �Q�ƗL�� */
    /*uint8   QualityStationary;*/      /* BR 1[%] */   /* �� �r�b�g���[�g�����̂ƈ�v���Ă��Ȃ��̂� 1 �ɒ��� */	/* 2015.05.26 K.N ���g�p */
    uint8   HypoType;																								/* 2015.05.26 K.N �Q�ƗL�� */
    uint8   HypoProb;               /* BR 1[%] */   /* �� �r�b�g���[�g�����̂ƈ�v���Ă��Ȃ��̂� 1 �ɒ��� */		/* 2015.05.26 K.N �Q�ƗL�� */
	uint8   ID;																										/* 2015.05.26 K.N �Q�ƗL�� */
    uint16   pad;																								/* 2015.05.26 K.N ���g�p */
	uint8	ProbObstacle;		//ETH
	uint8	ExistenceProb;		//ETH
	uint16  pad1;
	FLOAT	DistanceVAR;		//ETH...�Œ菬���_�ł͂Ȃ�
	FLOAT	LateralDistanceVAR;	//ETH...�Œ菬���_�ł͂Ȃ�
	FLOAT	TimeToCollision;
	FLOAT	ElevDistance;
	uint32	Age;
	uint8	Classification;
	uint8	ProbaMovable;
	uint8	Proba4Wheeler;
	uint8	ProbaTruck;
	uint8	ProbaCar;
	uint8	Proba2Wheeler;
	uint8	ProbaPedestrian;
	uint8	ProbaNonObstacle;
	uint8	CutInOut;
	uint8	LaneAssignment;
	uint8	AebCdl;
	uint8   pad2;
#endif	/* �@Bosch FR5 �M���ǉ� */
#if	1	/* 2020.01.19 JA�ȊO�ł��g�p���郁���o������̂ŏ펞�L���� */	/*( DEF_JAA_ENABLE )*/	/* 2020.03.31 JAA���� */
	FLOAT	LatRelativeSpeed;
	FLOAT	LonAbsoluteSpeed;	/* 2020.07.02 �ǉ� */
	FLOAT	LatAbsoluteSpeed;	/* 2020.07.02 �ǉ� */
	FLOAT	HeadingAngle;		/* 2020.12.03 �ǉ� */
	FLOAT	Azimuth;			/* 2020.12.04 �ǉ� */
	FLOAT	LonRelativeAcceleration;	/* CTA�����ɒǉ� */
	FLOAT	LatRelativeAcceleration;	/* CTA�����ɒǉ� */
	FLOAT	LonAbsoluteAcceleration;	/* CTA�����ɒǉ� */
	FLOAT	LatAbsoluteAcceleration;	/* CTA�����ɒǉ� */
#endif
}T_RAD_FCW_FCA_SP_DATA_BODY_FIX;
#define RAD_RCS_SP_BITRATE          (0.5f)      /* BR 0.5[-]        */
#define RAD_DISTANCE_SP_BITRATE      (0.1f)      /* BR 0.1[m]        */
#define RAD_LAT_DISTANCE_SP_BITRATE (0.1f)      /* BR 0.1[m] (+,-) = (Right,Left)*/
#define RAD_REL_LNGTDNL_SPD_BITRATE (0.025)     /* BR 0.025[m/s] */
#define RAD_REL_LNGTDNL_ACC_BITRATE (0.0625)    /* BR BR 0.0625[m/s^2] (+,-) = (Acceleration,DeAcceleration)*/
#define RAD_TRAJECTORY_SP_BITRATE   (0.1f)     /* BR 0.1[m] (+,-) = (�s���C�s��)   */
#define RAD_WIDTH_SP_BITRATE        (0.01f)     /* BR 0.01[m]       */
#define RAD_LENGTH_SP_BITRATE   (0.1f)      /* BR 0.1[m]        */
//#define RAD_QUALITY_GENERARL_SP_BITRATE (1.f)  /* BR 1[%] */
//#define RAD_QUALITY_SATTIONARY_SP_BITRATE (1.f)  /* BR 1[%] */
//#define RAD_HYPE_PORBE_SP_BITRATE (1.f)       /* BR 1[%] */

/* +++ HYPO TYPE   +++ */
#define RAD_HYPO_TYPE_NO                (0)
#define RAD_HYPO_TYPE_RunUpMoving       (1)
#define RAD_HYPO_TYPE_RunUpBraking      (2)
#define RAD_HYPO_TYPE_RunUpStationary   (3)
#define RAD_HYPO_TYPE_Follow            (4)
#define RAD_HYPO_TYPE_Pass              (5)
#define RAD_HYPO_TYPE_Collision         (6)
#define RAD_HYPO_TYPE_Unavailable       (7)
#if( ( N_RAD_TYPE == N_RAD_TYPE_CONTI_ARS410 ) || ( N_RAD_TYPE == N_RAD_TYPE_BOSCH_FR5 ) )
#define RAD_HYPO_TYPE_PedCollision      (7)	/* PedestrianCollision *//* 2016.09.22 20���̏���DynamicProperty(Possible_Pedestrian)�΍� */
#endif

typedef struct{
    uint32  TotalArray;
    T_RAD_FCW_FCA_SP_DATA_BODY_FIX Target[DEF_SP_FCW_FCA_DATA_NUM];
}T_RAD_FCW_FCA_SP_DATA_FIX;

typedef struct{
    uint8   ID;
    sint8   RCS;                    /* BR 0.5[-]    */
    uint16  Distance;               /* BR 0.1[m]    */
    sint16  LateralDistance;        /* BR 0.1[m] (+,-) = (Right,Left)*//* �� CAN�ƕ��������]���Ă��� */
    sint16  RelativeSpeed;          /* BR 0.025[m/s] *//* �� �r�b�g���[�g�����̂ƈ�v���Ă��Ȃ��̂� 0.025�ɒ��� */
    uint16  Width;                  /* BR 0.01[m]    *//* �� �r�b�g���[�g�����̂ƈ�v���Ă��Ȃ��̂� 0.01�ɒ��� */
    uint8   Length;                 /* BR 0.1[m]    */
    uint8   DynProp;
    uint8   Measured;
	FLOAT	ElevDistance;
	uint32	Age;
	uint8	ExistenceProb;
	uint8	Classification;
	uint8	ProbaMovable;
	uint8	Proba4Wheeler;
	uint8	ProbaTruck;
	uint8	ProbaCar;
	uint8	Proba2Wheeler;
	uint8	ProbaPedestrian;
	uint8	ProbaNonObstacle;
#if	1	/* 2012.12.19 */
	uint8	WidthType;
	uint8	LengthType;
	uint8	Valid;
#else
    uint8   pad1;
    uint16  pad2;
#endif	/* 2012.12.19 */
#if( N_RAD_TYPE == N_RAD_TYPE_BOSCH_FR5 )
	uint8   Status;
	uint8   Type;
	uint8	ObstacleProbability;
	sint16  RelativeAcceleration;
#endif	/* �@Bosch FR5 �M���ǉ� */
#if	1	/* 2020.01.19 JA�ȊO�ł��g�p���郁���o������̂ŏ펞�L���� */	/*( DEF_JAA_ENABLE )*/	/* 2020.03.31 JAA���� */
	FLOAT	LatRelativeSpeed;
	FLOAT	LonAbsoluteSpeed;	/* 2020.07.02 �ǉ� */
	FLOAT	LatAbsoluteSpeed;	/* 2020.07.02 �ǉ� */
	FLOAT	HeadingAngle;		/* 2020.12.03 �ǉ� */
	FLOAT	Azimuth;			/* 2020.12.04 �ǉ� */
#endif
}T_RAD_OBJ_DATA_BODY_FIX;
#define RAD_RCS_OBJ_BITRATE             (0.5f)      /* BR 0.5[-]        */
#define RAD_DISTANCE_OBJ_BITRATE        (0.1f)      /* BR 0.1[m]        */
#define RAD_LAT_DISTANCE_OBJ_BITRATE    (0.1f)      /* BR 0.1[m] (+,-) = (Right,Left)*/
#define RAD_RELATIVE_SPEED_OBJ_BITRATE  (0.025f)    /* BR 0.025[m/s]    */
#define RAD_WIDTH_OBJ_BITRATE           (0.01f)     /* BR 0.01[m]       */
#define RAD_LENGTH_OBJ_BITRATE          (0.1f)      /* BR 0.1[m]        */

/* +++ DYN PROP +++ */
#define RAD_DYN_PROP_UNCLASSIFIED   (0)
#define RAD_DYN_PROP_STANDING       (1)
#define RAD_DYN_PROP_STOPPED        (2)
#define RAD_DYN_PROP_MOVING         (3)
#define RAD_DYN_PROP_ON_COMING      (4)
#if( ( N_RAD_TYPE == N_RAD_TYPE_CONTI_ARS410 ) || ( N_RAD_TYPE == N_RAD_TYPE_BOSCH_FR5 ) )
#define RAD_DYN_PROP_POSSIBLE_PED   (6)	/* Possible_Pedestrian *//* 2016.09.22 20���̏���DynamicProperty(Possible_Pedestrian)�΍� */
#endif

/* +++ MESURED +++ */
#define RAD_MESURED_NOT_MESURED (0)
#define RAD_MESURED_MESURED     (1)
#if	1	/* 2012.12.19 */
#define	RAD_MEASURED_INIT			(0)
#define	RAD_MEASURED_NEW			(1)
#define	RAD_MEASURED_NO_MEASURED	(2)
#define	RAD_MEASURED_MEASURED		(3)

/* +++ WIDTH TYPE +++ */
#define	RAD_WIDTH_TYPE_0			(0)
#define	RAD_WIDTH_TYPE_1			(1)
#define	RAD_WIDTH_TYPE_2			(2)
#define	RAD_WIDTH_TYPE_3			(3)
#define	RAD_WIDTH_TYPE_4			(4)
#define	RAD_WIDTH_TYPE_5			(5)
#define	RAD_WIDTH_TYPE_6			(6)
#define	RAD_WIDTH_TYPE_7			(7)

/* +++ LENGTH TYPE +++ */
#define	RAD_LENGTH_TYPE_0			(0)
#define	RAD_LENGTH_TYPE_1			(1)
#define	RAD_LENGTH_TYPE_2			(2)
#define	RAD_LENGTH_TYPE_3			(3)
#define	RAD_LENGTH_TYPE_4			(4)
#define	RAD_LENGTH_TYPE_5			(5)
#define	RAD_LENGTH_TYPE_6			(6)
#define	RAD_LENGTH_TYPE_7			(7)

/* +++ VALID +++ */
#define	RAD_VALID_OFF				(0)
#define	RAD_VALID_ON				(1)
#endif	/* 2012.12.19 */

typedef struct{
    uint32  TotalArray;
    T_RAD_OBJ_DATA_BODY_FIX Target[DEF_OBJ_NUM];
}T_RAD_OBJ_DATA_FIX;

typedef struct{
    T_RAD_STATUS_FIX                Status;
    T_RAD_ROAD_ESTIMATION_FIX       RoadEst;
    T_RAD_RADAR_COMMON_DATA_FIX     RadarOriginal;
    T_RAD_RADAR_COMMON_DATA_FIX     AccDcaGstMasked;
    T_RAD_RADAR_COMMON_DATA_FIX     FcwFcaGstMasked;
    T_RAD_FCW_FCA_SP_DATA_FIX       FcwFcaSp;
    T_RAD_OBJ_DATA_FIX              Obj;
}T_RAD_INFO_FIX;
/* ################################################ */
/*	�ϐ��錾                                        */
/* ################################################ */

/* ################################################ */
/*	�v���g�^�C�v�錾                                */
/* ################################################ */
EXTERN T_RAD_INFO_FIX  const * const ptRAD_GetAllRadInfoFix(void);

#undef EXTERN
#endif
