#ifndef	__RIR_COMMON_H__
#define	__RIR_COMMON_H__

#include "n_common.h"

enum	eRirOutputModeIf{				/* 2020.05.14 �VFusion+EAP2�Ή� */
	eRIR_OUTPUT_MODE_IF_DEFAULT	= 0,	/* 0 */
	eRIR_OUTPUT_MODE_IF_RADAR,			/* 1 */
	eRIR_OUTPUT_MODE_IF_CAMERA,			/* 2 */
	eRIR_OUTPUT_MODE_IF_FRSRAD			/* 3 */
};

typedef	struct{
	struct{
		uint8	bit0	:1;
		uint8	bit1	:1;
		uint8	bit2	:1;
		uint8	bit3	:1;
		uint8	bit4	:1;
		uint8	bit5	:1;
		uint8	bit6	:1;
		uint8	bit7	:1;
	}byte0;
	struct{
		uint8	bit0	:1;
		uint8	bit1	:1;
		uint8	bit2	:1;
		uint8	bit3	:1;
		uint8	bit4	:1;
		uint8	bit5	:1;
		uint8	bit6	:1;
		uint8	bit7	:1;
	}byte1;
	struct{
		uint8	bit0	:1;
		uint8	bit1	:1;
		uint8	bit2	:1;
		uint8	bit3	:1;
		uint8	bit4	:1;
		uint8	bit5	:1;
		uint8	bit6	:1;
		uint8	bit7	:1;
	}byte2;
	struct{
		uint8	bit0	:1;
		uint8	bit1	:1;
		uint8	bit2	:1;
		uint8	bit3	:1;
		uint8	bit4	:1;
		uint8	bit5	:1;
		uint8	bit6	:1;
		uint8	bit7	:1;
	}byte3;
	struct {
		uint8	bit0 : 1;
		uint8	bit1 : 1;
		uint8	bit2 : 1;
		uint8	bit3 : 1;
		uint8	bit4 : 1;
		uint8	bit5 : 1;
		uint8	bit6 : 1;
		uint8	bit7 : 1;
	}byte4;	/* FEB���S�őΉ� 20180907 TPD */
}tRirFlags;

#define	MACRO_SIZE( A )		( ( sizeof A ) / ( sizeof A[0] ) )

#if	1	/* 2013.04.12 ���s���т����������̗p */
#define	iRIR_FLOAT_MAX	(3.402823466e+38F)
#else
#define	iRIR_FLOAT_MAX	(3.4028235677973364e+038F)
#endif
#define	iRIR_FLOAT_MIN	(-iRIR_FLOAT_MAX)
#define	iRIR_FLOAT_ZERO	(0.F)

FLOAT	fl_CalcAbs(	FLOAT	in	);

#if	0	/* 2013.08.05 n_apl_common.c ���g�p */
FLOAT	fl_FiltMaxMin(	FLOAT	v_in,
						FLOAT	v_max,
						FLOAT	v_min	);
#endif

FLOAT	fl_rir_add_max_min(	FLOAT	v_base,
							FLOAT	v_add,
							FLOAT	v_max,
							FLOAT	v_min	);

sint32	si32_rir_add_max_min(	sint32	base,
								sint32	add,
								sint32	max,
								sint32	min		);

uint16	ui16_rir_add_max_min(	uint16	base,
								uint16	add,
								uint16	max,
								uint16	min		);

uint16	ui16_rir_sub_max_min(	uint16	base,
								uint16	sub,
								uint16	max,
								uint16	min		);

/* 2�i�J���Z�ŕ������̉��Z */
uint32	ui32_rir_sqrt(	uint32	in	);
FLOAT	fl_rir_sqrt( FLOAT v_in );
FLOAT	fl_rir_pythagorean_theorem(	FLOAT	v_line1,
									FLOAT	v_line2	);

FLOAT	fl_rir_pythagorean_theorem_ax(	FLOAT	line1,
										FLOAT	line2	);

FLOAT	fl_rir_trajectory_calc(	FLOAT	v_radius,			/* [m] */
								FLOAT	v_lateral_dist,		/* [m] */
								FLOAT	v_distance,			/* [m] */
								FLOAT	v_approx_th		);	/* [m] */

uint8	ui8_rir_str_on_judge(	FLOAT	v_str_angle,
								FLOAT	m_mask_on_th,
								FLOAT	m_mask_off_th,
								uint8	out_z	);

FLOAT	fl_rir_lpf(	FLOAT	in,
					FLOAT	out_z,
					FLOAT	m0,
					FLOAT	m1		);

FLOAT	fl_rir_2nd_lpf(	FLOAT	a_in[],
						FLOAT	a_out[],
						FLOAT	m0,
						FLOAT	m1,
						FLOAT	m2	);

FLOAT 	fl_rir_bpf(	uint8	reset,		/* �������t���O */
					FLOAT	in,			/* �t�B���^���� */
					FLOAT	*in_z1,		/* �t�B���^���́i�O��l�j*/
					FLOAT	*in_z2,		/* �t�B���^���́i�O�X��l�j*/
					FLOAT	*out_z1,	/* �t�B���^�o�́i�O��l�j*/
					FLOAT	*out_z2,	/* �t�B���^�o�́i�O�X��l�j*/
					FLOAT	mdvsp0,		/* �t�B���^�萔�P */
					FLOAT	mdvsp1,		/* �t�B���^�萔�Q */
					FLOAT	mdvsp2	);	/* �t�B���^�萔�R */

void	v_SetAllRingBuffFL(	FLOAT			data,
							T_RING_BUFF_FL*	ring	);
void	v_PushRingBuffFL(	FLOAT			data,
							T_RING_BUFF_FL*	ring	);
FLOAT	FL_GetRingBuffFL(	uint16			pos,
							T_RING_BUFF_FL*	ring	);
#if 0
sint32	si32_Read3DMap(	sint32	x,
						sint32	y,
						const	T_3D_MAP	*map	);
#endif

sint16	NI_TBLWS(	const	sint16*	Table_y,
					const	sint16*	Table_x,
					const	sint16	Table_size,
					const	sint16	in			);

sint16	NI_MAPWS(	const	sint16*	Table_z,
					const	sint16*	Table_x,
					const	sint16	Table_x_size,
					const	sint16*	Table_y,
					const	sint16	Table_y_size,
					const	sint16	in_x,
					const	sint16	in_y			);

/* ADAS5 PFCW����Trajectory�v�Z���ڐA */
FLOAT fl_PFCW_ConvDistSisya(FLOAT in);

#endif	/* __RIR_COMMON_H__ */
