#ifndef	__IFCONVERT_CAMERA_H__
#define	__IFCONVERT_CAMERA_H__

extern	void	vIfConvert_Camera( void );

/* ################################################ */
/*  �C���N���[�h                                    */
/* ################################################ */
#include	"IfConvert_CameraValeoIf.h"

#endif
