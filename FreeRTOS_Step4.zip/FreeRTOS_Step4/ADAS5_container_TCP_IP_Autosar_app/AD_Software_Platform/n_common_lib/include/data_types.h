/******************************************************************************
 *
 *     Copyright (c) 2015 Nissan, Japan
 *
 ******************************************************************************
 *
 * Project			:
 * Module			:
 * Version			:
 * Author			:
 * Date				:
 * Description		:
 * Revision History	:
 *
******************************************************************************/
#ifndef	__DATA_TYPES_H__
#define	__DATA_TYPES_H__

#include	"utypedef.h"

#endif	/* __DATA_TYPES_H__ */
