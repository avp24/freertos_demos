/******************************************************************************
 *
 *     Copyright (c) 2013 Nissan, Japan
 *
 ******************************************************************************
 *
 * Project:     
 * Module:      N_Vehicle
 * Version      1.0
 * Author:      
 * Date:        
 * Description: 
 * Revision History:
 *
******************************************************************************/
#ifndef __N_COMMON_H__
#define __N_COMMON_H__
/* ################################################ */
/*	�C���N���[�h                                    */
/* ################################################ */
#include "n_apl_common.h"
#include "FEB_CommonFunc.h"
/* ################################################ */
/*	�}�N���錾                                      */
/* ################################################ */
#define TMR_STATUS_IDLE     (0u)
#define TMR_STATUS_BUSY     (1u)
#define TMR_STATUS_TIMEUP   (2u)



#ifdef  __N_COMMON_C__
#define EXTERN
#else
#define EXTERN extern
#endif

#undef EXTERN
#endif
