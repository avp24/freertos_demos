/******************************************************************************
 *
 *     Copyright (c) 2014 Nissan, Japan
 *
 ******************************************************************************
 *
 * Project:     FEB
 * Module:      Main Module
 * Version      1.0
 * Author:      
 * Date:        
 * Description: This file contains FEB application entry point 
 * Revision History:
 *
******************************************************************************/
#ifndef __FEB_vPBRK_COM_H__
#define __FEB_vPBRK_COM_H__

#ifdef  __FEB_vPBRK_COM_C__
#define EXTERN
#else
#define EXTERN extern
#endif


EXTERN sint32 si32_FEB_GetPBRK_COM(void);
EXTERN void vPBRK_COM_FEB_update(void);
EXTERN sint32 si32_Get_FEB_SLOPE(void);
EXTERN void FEB_CalcSlope(void);

#undef EXTERN
#endif
