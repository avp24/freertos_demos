/*******************************************************************************
 *
 *     Copyright (c) 2013 Nissan, Japan
 *
 *******************************************************************************
 *
 * Project:
 * Module:      Forward Emergency Braking
 * Version      0.1
 * Author:
 * Date:
 *
*******************************************************************************/
#ifndef	__FEB_type__
#define	__FEB_type__

#if	1	/* ADAS2->3 add */
/*******************************************************************************/
/* INCLUDE FILES								                               */
/*******************************************************************************/
#include	"data_types.h"
#include	"n_common.h"
#include	"FEB_CommonFunc.h"
#endif
//#include "FCA_func.h"


/* Constant declaration-definition	*/
#define	iVSP_lsb				(16u)
#define	iVSP_SERVO_lsb			(22u)
#define	iVSPD_lsb				(16u)
#define	iVREL_lsb				(16u)
#define	iDIST_lsb				(16u)
#define	iACCE_lsb				(22u)
#define	iTIME_lsb				(22u)
#define	iVC_STR_SPD_lsb			(10u)	/* 2^-8 ->2^2 */
#define	iFCA_STR_SPD_lsb		(0u)
#define	mAPO_RAW_Denomi			(125u)
#define	iDIST_IBA_INPUT_LSB		(22u)
#define	iWHLINIT_CLRWHL_lsb		(15u)
#define	iV_SERVO_lsb			(22u)	/* Vehicle speed servo operation define iV_SERVO_lsb, LSB of the vehicle speed command value */
#define	iVREL_map_lsb			(8u)
#if	1	/* ADAS2->3 add */
#define iObjTrjOfstMax			(SINT32MAX)
#define iObjTrjOfstMin			(-SINT32MAX)
#define iLsb8			 		(8)
#define iLsb16					(16)			/*	������	 16�̑��		*/
#define iLsb24					(24)
#define iAPO_ANGL_POINT			(8)
#define iLsb10000				(10000)
#define iRirTrjLsbMax			(6553600)
#define iRirTrjLsbMin			(-6553600)
#define iShift6		   			(64)			/*	������	2^6�̑��		*/
#define iShift8		  			(256)			/*	������	2^8�̑��		*/
#define iAPO_ANGL_BIT_SHIFT		(5)
#define iAPO_ANGL_DIV			(125)

#define FEB_UINT32MAX 			(UINT32MAX)
#define FEB_UINT32MIN 			(UINT32MIN)
#define FEB_SINT32MAX 			(SINT32MAX)
#define FEB_SINT32MIN 			((-FEB_SINT32MAX)-1)
#endif

/*(And corresponding mFCA_STATE) state name */
enum
{
	iFCA_BRK_OFF,		/* FCA braking OFF(0) */
	iFCA_1ST_BRK,		/* FCA preliminary braking iFCA_1ST_BRK,(1) */
	iFCA_2ND_BRK,		/* FCA emergency braking iFCA_2ND_BRK, (2) */
	iFCA_MAX_BRK,		/* FCA full braking (3) */
	iFCA_CTRL_MODE_num	/* FCA control mode number(4) */
};


/* Definition of the function table and enum buzzer for (Buzzer_Sound) */
enum
{
	iFCA_BUZ_FAIL,		/* Fail flag (BIT0) */
	iFCA_BUZ_CANC,		/* Cancel flag (BIT1) */
	iFCA_BUZ_WARN,		/* FCA alarm (BIT2) */
	iFCA_BUZ_EVT_NUM	/* Maximum number */
};

/*(And corresponding mFCA_BRK_EVENT) event name */
enum
{
	iFEB_FAIL_SOKU,		/* Cancel or fail immediately unplug iFEB_FAIL_SOKU (0) */
	iFEB_FFP_HUMI,		/* The tread accelerator (1) */
	iFEB_STOP_CANCEL,	/* Vehicle = 0km / h canceled (2) */
	iFEB_FAIL_JOJO,		/* Cancel or fail gradually disconnect (3) */
	iFEB_FAIL_HOJI,		/* Cancel or fail retention (4) */
	iFEB_BRK_INH,		/* FCA brake is not permitted (5) */
	iFEB_STOP_BRK,		/* Stop control iFEB_STOP_BRK, (6) */
	iFEB_BRK_LOST,		/* Deceleration the end of the hold (7) */
	iFEB_DEACT_OFF_FCA,	/*��쓮��� (8)*/
	iFEB_DEFAULT,		/* Default (9)*/
	iFEB_EVENT_NUM		/* Maximum number of events */
};


/* (And corresponding mFCA_BRK_STATE) state name */
enum
{
	iFCA_BRAKE_OFF,		/* Brake OFF (0)*/
	iFCA_BRAKE_ON,		/* Normally during braking (1)*/
	iFCA_FFP_OFF,		/* Gradually opener in driver accelerator */
	iFCA_STOP_ON,		/* Stop control increase(3)*/
	iFCA_STOP_FFP_OFF,	/* Stop control accelerator (4)*/
	iFCA_LOST_OFF,		/* Deceleration the end of the hold gradually opener in accelerator (5)*/
	iFCA_JOJO_OFF,		/* Cancellation, failure time (6) */
	iFCA_STOP_OFF,		/* Stop control when releasing  (7) */
	iFCA_BRK_HOJI,		/* Brake during holding (8) */
	iFCA_STATE_NUM		/* Maximum number of states */
};

/* from FCW_type.h */
enum
{
	ifeb_NO_TARGET,			/* No Target(0) */
	ifeb_MOVE_TARGET,		/* Target moving object (1) */
	ifeb_STOP_TARGET,		/* Target stationary objects (2) */
	ifeb_TARGET_TYPE_num	/* Target number of types (3) */
};

typedef struct
{
	uchar8	fSup_feb		:1;
	uchar8	fSupLatch_feb	:1;
	uchar8	dummy_hm		:6;
}feb_hm_type;


#endif
