/*******************************************************************************
 *
 *     Copyright (c) 2013 Nissan, Japan
 *
 *******************************************************************************
 *
 * Project:
 * Module:     
 * Version      0.1
 * Author:
 * Date:
 *
*******************************************************************************/
#ifndef	__FEB_CONSTDB_H__
#define	__FEB_CONSTDB_H__

#include "Rte_FEBFCWDBA.h"

#define mWIDTH_MAIN	Rte_Prm_mVEHICLE_WIDTH_FEB_mVEHICLE_WIDTH_FEB()
#define mSYOGEN_ADAS	Rte_Prm_mSYOGEN_ADAS_mSYOGEN_ADAS()

/* Task #32489 */
#define mGEAR_FINAL_FEB	Rte_Prm_mGEAR_FINAL_mGEAR_FINAL()

#define mSPEC_AXLE_TYPE	Rte_Prm_mSPEC_AXLE_TYPE_mSPEC_AXLE_TYPE()
#define iFR_TYPE	(0u)
#define iFF_TYPE	(1u)

#endif
