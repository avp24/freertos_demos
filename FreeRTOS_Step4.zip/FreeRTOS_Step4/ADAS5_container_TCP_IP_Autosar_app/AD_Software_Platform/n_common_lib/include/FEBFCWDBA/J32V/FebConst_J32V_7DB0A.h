/****************************************************************************** */
/*                                                                              */
/*     Copyright (c) 2013 Nissan, Japan                                         */
/*                                                                              */
/* **************************************************************************** */
/*                                                                              */
/* Project:     J32V FEB Const                                                  */
/* Module:                                                                      */
/* Version      10.3.0_B                                                        */
/* Author:                                                                      */
/* Making of:   ADAS5_FEB_ConstInformation.xlsm                                 */
/* MACRO Var:   1.20                                                            */
/* Description:                                                                 */
/* Revision History:                                                            */
/*                                                                              */
/********************************************************************************/
#ifndef __FEB_CONST_J32V_7DB0A_H__
#define __FEB_CONST_J32V_7DB0A_H__

#include "data_types.h"
#include "n_common.h"


extern const FLOAT  mDV_LO_LMT_1STFCA_fl;                               /* 2^(0)[m/ss], Acceleration lower limit value in case of reserve braking, -5.5 */
extern const FLOAT  mDV_LO_LMT_2NDFCA_fl;                               /* 2^(0)[m/ss], Acceleration lower limit value in case of emergency braking, -9 */
extern const FLOAT  mDV_LO_LMT_MAXFCA_fl;                               /* 2^(0)[m/ss], Acceleration lower limit value in case of emergency braking (Full braking), -15 */
extern const FLOAT  mAMDL_MIN_2NDFCA_fl;                                /* 2^(0)[m/ss], Model matching compensator acceleration lower limit value in case of emergency braking, -9 */
extern const FLOAT  mAMDL_MIN_MAXFCA_fl;                                /* 2^(0)[m/ss], Model matching compensator acceleration lower limit value in case of emergency braking (Full braking), -15 */
extern const FLOAT  mA_MDL_FCA_fl;                                      /* 2^(0)[-], (1-exp(-(1/Tb)ampling time)), 0.067608 */
extern const FLOAT  mACCCOM_FF_FCA_fl;                                  /* 2^(0)[-], 1-exp(-(1/Tb)ampling time)/sampling time, 6.760498 */
extern const FLOAT  mACCCOM_FB_FCA_fl;                                  /* 2^(0)[-], For F/B acceleration command value, 0.74 */
extern const FLOAT  mACCMDL_MAX_FCA_fl;                                 /* 2^(0)[m/ss], Model matching compensator acceleration command value maximum value, 1.7 */
extern const uint8  mSUB_GAIN_FCA_fl;                                   /* 2^(0)[-], Robust compensator calculation execution ROM SW, 1 */
extern const FLOAT  mA_FBK_FCA_fl;                                      /* 2^(0)[-], (1-exp(-(Constant in case of 1/ robust filter)ampling time))/sampling time (MB), 0.995026 */
extern const FLOAT  mN_A_LMT_FCA_fl;                                    /* 2^(0)[-], 1-exp(-(Constant in case of 1/ACCCOM_LIM_LPF)ampling time), 0.095169 */
extern const FLOAT  mD_A_LMT_FCA_fl;                                    /* 2^(0)[-], exp(-(Constant in case of 1/ACCCOM_LIM_LPF)ampling time) (MB), 0.904846 */
extern const FLOAT  mA_REF_FCA_fl;                                      /* 2^(0)[-], Sampling time1-exp(-(Constant in case of 1/robust filter)ampling time)/sampling time), 0.009951 */
/* ----- ... from const_4BA0A.c ----- */
/* ----- 4. fca_EMERG_BRK_APL_VSP_CMD_DIST_func.c ----- */
/* ----- from - const_FCA_P32RN.c ----- */
extern const FLOAT  mACC_FB_I_LMT_2ND_fl;                               /* 2^(0)[-], Servo output correction vehicle speed command change ratio limit between vehicles ( emergency braking), -0.11 */
extern const FLOAT  mACC_FB_I_LMT_1ST_fl;                               /* 2^(0)[-], Servo output offset vehicle speed command change ratio limit between vehicles (Reserve braking), -0.04 */
extern const FLOAT  mLPF_V_COM_REF_fl;                                  /* 2^(0)[-], Servo output correction LPF between vehicles, 0.904837 */
extern const FLOAT  mV_COM_FB_G_fl;                                     /* 2^(0)[-], Servo output correction FB gain between vehicles, 0.3 */
extern const FLOAT  mV_COM_FB_I_G_fl;                                   /* 2^(0)[-], Servo output correction FB_I gain between vehicles, 0.06 */
extern const FLOAT  mV_COM_FB_I_MAX_fl;                                 /* 2^(0)[-], Servo output correction FB_IUpper limit value between vehicles, 5 */
extern const FLOAT  mV_COM_FB_I_MIN_fl;                                 /* 2^(0)[-], Servo output correction FB_ILower limit value between vehicles, -0.5 */
/* ----- 5. fca_EMERG_BRK_APL_VSP_CMD_func.c ----- */
/* ----- from - const_FCA_P32RN.c ----- */
extern const FLOAT  mVSP_CMD_DN_LIM_1STFCA_fl;                          /* 2^(0)[m/ss], Vehicle speed command value change ratio (At the time of reserve braking)=acceleration command value, 0.045 */
extern const FLOAT  mVSP_CMD_DN_LIM_2NDFCA_fl;                          /* 2^(0)[m/ss], Vehicle speed command value change ratio (At the time of emergency braking)=acceleration command value, 0.15 */
extern const FLOAT  mFCA_UP_LIM_VSPCMD_fl;                              /* 2^(0)[m/s], Speed command limited value at the time of preliminary braking[km/h]:"Speed + this constant value" is considered as upper limit value, 1.36111111111111 */
extern const FLOAT  mFCA_LO_LIM_VSPCMD_fl;                              /* 2^(0)[m/s], Speed command limited value at the time of preliminary braking[km/h]:"Speed - this constant value" is considered as lower limit value, 2.22222222222222 */
/* ----- ... from const_MB_4BA0A.c ----- */
extern const FLOAT  mVSP_CMD_UP_LIM_fl;                                 /* 2^(0)[(m/s^2)/10ms], Vehicle speed command value  change ratio limiter (On increase ), 0.0098 */
/* ----- 6. CntrolFfpFca_3_1.c ----- */
/* ----- from - const_FCA_P32RN.c ----- */
extern const FLOAT  mTTC_FFP_MAX_fl;                                    /* 2^(0)[-], TTC MAX for FCA pedal operation control, 10 */
extern const FLOAT mTTC_FFP_LC_fl[10];                                  /* 2^(0) [-], TTC(LC) for FCA pedal operation control */
extern const FLOAT  mTTC_FFP_APO_HIGH_fl;                               /* 2^(0)[-], TTC(APO_HIGH) for FCA pedal operation control, 5 */
extern const FLOAT mTTC_FFP_OVR_EXC_fl[10];                             /* 2^(0) [-], TTC(INC_EXC) for FCA pedal operation control */
extern const FLOAT mAPO_ANGL_INC_fl[10];                                /* 2^(0) [%], Accelerator step-on increasing amount */
extern const FLOAT mTTC_FFP_STR_fl[10];                                 /* 2^(0) [-], TTC(STR) of FCA pedal operation control */
extern const FLOAT mFCA_STR_ANG_fl[10];                                 /* 2^(0) [deg], Driver input rudder angle */
extern const FLOAT mTTC_FFP_STR_SPD_fl[10];                             /* 2^(0) [-], TTC(STR SPD) for FCA pedal operation control */
extern const FLOAT mSTR_ANGL_SPD_FCA_fl[10];                            /* 2^(0) [deg], Driver input rudder angle */
extern const FLOAT mFFP_STR_FCA_MAP_fl[370];                            /* 2^(0) [-], FCA pedal reaction force control gain(STR) */
extern const FLOAT mFFP_STR_SPD_FCA_MAP_fl[370];                        /* 2^(0) [-], FCA pedal reaction force control gain for stop object (STR SPD)  */
extern const FLOAT mFFP_STR_STP_FCA_MAP_fl[370];                        /* 2^(0) [-], FCA pedal reaction force control gain (STR)  */
extern const FLOAT mFFP_STR_SPD_STP_FCA_MAP_fl[370];                    /* 2^(0) [-], FCA pedal reaction force control gain for stop object (STR SPD) */
extern const FLOAT  mFFP_GAIN_MAX_fl;                                   /* 2^(0)[-], FCApedal reaction force control gain MAX, 1 */
extern const FLOAT  mFFP_OBJ_SUP_M_GAIN_STP_fl;                         /* 2^(0)[-], Recognition certainty factor pedal reaction force control M gain for stop object, 0.5 */
extern const FLOAT mFFP_TRJ_H_GAIN_FCA_fl[10];                          /* 2^(0) [-], Pedal reaction force control HI gain map(Horizontal offset ratio)  */
extern const FLOAT mFFP_TRJ_M_GAIN_FCA_fl[10];                          /* 2^(0) [-], Pedal reaction force control M gain map(Horizontal offset ratio)  */
extern const FLOAT mFFP_TRJ_L_GAIN_FCA_fl[10];                          /* 2^(0) [-], Pedal reaction force control LO gain map(Horizontal offset ratio)  */
extern const FLOAT mOBJ_TRJ_OFST_HI_FCA_fl[10];                         /* 2^(0) [-], Horizontal offset ratio for map drawing */
/* ----- from - const_MB_4BA0A.c ----- */
extern const FLOAT  mAPO_OVR_HIGH_fl;                                   /* 2^(0)[%], Acceleration sudden step-on judgment threshold value, 50 */
extern const FLOAT mPCTBL_VSP_MB_fl[37];                                /* 2^(0) [m/s], Vehicle speed axis */
extern const FLOAT mSTR_ANGL_fl[10];                                    /* 2^(0) [deg], Driver input  rudder angle  axis */
extern const FLOAT mSTR_ANGL_SPD_fl[10];                                /* 2^(0) [deg], Driver input  rudder angle variation  axis */
/* ----- 7. FEB_FFP_cont.c ----- */
/* ----- from - const_FCA_P32RN.c ----- */
extern const FLOAT mFFP_FCA_BUZ_TIME_fl[10];                            /* 2^(0) [-], Warning ON time dependent pedal reaction force correction gain map for FCA */
extern const FLOAT mTBL_FFP_MAX_OVR_Y_FCA_fl[13];                       /* 2^(0) [N], Target pedal reaction force maximum value (initial) */
extern const FLOAT mTBL_FFP_APO_BUF_INI_Y_FCA_fl[11];                   /* 2^(0) [%], Accelerator opening dependent pedal reaction force correction gain (initial) axis */
extern const FLOAT mTBL_FFP_MAX_UP_Y_FCA_fl[11];                        /* 2^(0) [N/10ms], Target pedal reaction force change limit map (increasing side) */
extern const FLOAT mTBL_FFP_MAX_WARN1_Y_FCA_fl[13];                     /* 2^(0) [N], Target pedal reaction force maximum value */
extern const FLOAT mTBL_K_FFP_APO_BUF_Y_FCA_fl[11];                     /* 2^(0) [%], Accelerator opening dependent pedal reaction force correction gain axis */
extern const FLOAT mTBL_FFP_MAX_DN_Y_FCA_fl[11];                        /* 2^(0) [N/10ms], Target pedal reaction force change limit map (decreasing side) */
extern const FLOAT mTBL_FFP_APO_X_FCA_fl[11];                           /* 2^(0) [%], Accelerator opening */
extern const FLOAT mTBL_FFP_SLOPE_X_FCA_fl[13];                         /* 2^(0) [m/ss], Gradient estimate value */
extern const FLOAT  mK_FFP_OVR_FCA_fl;                                  /* 2^(0)[-], Target pedal reaction force correction calculation gain, 20 */
extern const FLOAT  mFFP_SUP_H_GAIN_fl;                                 /* 2^(0)[-], Pedal reaction force offset calculation gain (HI), 0 */
extern const FLOAT  mFFP_MAX_TIME_FCA_fl;                               /* 2^(0)[10ms], Target pedal reaction force retention time, 50 */
/* ----- from - const_MB_4BA0A.c ----- */
extern const FLOAT mCNT_FFP_DCA_BUZ_TIME_fl[10];                        /* 2^(0) [-], When buzzer in ON, Counter axis */
extern const FLOAT  m0p01_fl;                                           /* 2^(0)[-], For calculating Target Pedal  reactive force ( After correction), constant, 0.01 */
extern const FLOAT  m100pct_fl;                                         /* 2^(0)[%], 1, 100 */
extern const FLOAT  mCFC_DN_LIM_LOST_fl;                                /* 2^(0)[-], 0.01 At the time of lost, Pedal  reactive force change limit (On decrease), 0.5 */
extern const FLOAT  mCFC_DN_LIM_OVR_fl;                                 /* 2^(0)[N/10ms], 0.01 Target Pedal  reactive force change limit (On decrease), 0.3 */
extern const FLOAT  mCFC_DN_LIM_fl;                                     /* 2^(0)[N/10ms], 0.01 Target Pedal  reactive force change limit (On decrease), 0.12 */
/* ----- 8. FEB_FFP_main.c ----- */
/* ----- from - const_FCA_P32RN.c ----- */
extern const FLOAT  mCFC_UP_LIM_FCA_fl;                                 /* 2^(0)[N/10ms], 0.01 target pedal reaction force change limit (increasing side), 3 */
extern const FLOAT  mCFC_UP_LIM_OFF_FCA_fl;                             /* 2^(0)[N/10ms], 0.01 Target pedal reaction force change limit (increasing side) in case of accelerator OFF, 3 */
extern const FLOAT  mCFC_DN_LIM_OFF_FCA_fl;                             /* 2^(0)[N/10ms], 0.01 Target pedal reaction force change limit (decreasing side)in case of accelerator OFF, 0.12 */
extern const FLOAT  mCFC_DN_LIM_SLOW_FCA_fl;                            /* 2^(0)[N/10ms], 0.01 target pedal reaction force change limit (When MB is cancelled), 0.2 */
extern const FLOAT  mCFC_UP_LIM_OBJ_SUP_M_FCA_fl;                       /* 2^(0)[N/10ms], 0.01 recognition certainty factor M target pedal reaction force change limit (increasing side), 0.5 */
extern const FLOAT  mCFC_UP_MAX_FCA_fl;                                 /* 2^(0)[-], Target pedal reaction force upper limit value, 32 */
/* ----- 9. FFP_OMG_cont_FCA.c ----- */
/* ----- from - const_FCA_P32RN.c ----- */
extern const FLOAT  m100pct_FCA_fl;                                     /* 2^(0)[%], 1, 100 */
/* ----- TBD: Query-2 to NML ----- */
extern const FLOAT mTBL_FFP_OMG_GAIN_X_FCA_fl[7];                       /* 2^(0) [%/s], Accelerator opening speed axis (Note: It should be set to less than 128%/s)  */
extern const FLOAT mTBL_FFP_OMG_GAIN_Y_FCA_fl[7];                       /* 2^(0) [%], Pedal reaction force gain (accelerator opening speed dependant) axis */
extern const FLOAT  mSLPGAIN_FFPOMG_UP_FCA_fl;                          /* 2^(0)[%/(m/s^2)], Pedal reaction force correction gain (rising), 0 */
extern const FLOAT  mSLPGAIN_FFPOMG_DN_FCA_fl;                          /* 2^(0)[%/(m/s^2)], Pedal reaction force correction gain (falling), 0 */
extern const FLOAT mTBL_FFP_OMEGA_MAX_X_FCA_fl[11];                     /* 2^(0) [%], Accelerator opening axis */
extern const FLOAT mTBL_FFP_OMEGA_MAX_Y_FCA_fl[11];                     /* 2^(0) [N], Target pedal reaction force (accelerator opening speed) (before correction) axis */
extern const FLOAT  mFFP_OMG_DN_FCA_fl;                                 /* 2^(0)[N/10ms], Target pedal reaction force (accelerator opening speed) change limit (decreasing side), 0.05 */
extern const FLOAT mTBL_RECOG_RELE_FCA_fl[2];                           /* 2^(0) [-], Certainty factor (Relevant) axis */
/* ----- 10. FEB_CONT_CLR_JUDGE_main.c ----- */
/* ----- no any const ----- */
/* ----- 11. FEB_ACT_MODE_update.c ----- */
/* ----- from - const_FCA_P32RN.c ----- */
/* ----- . FEB_ACT_update.c ----- */
/* ----- .... from TUNING/const_FUNC_P32RN.c ----- */
extern const uint8  mSPEC_DCA_fl;                                       /* 2^(0)[-], DCA function existence ROM SW, 1 */
/* ----- ......from - const_FCA_P32RN.c ----- */
extern const FLOAT  mACC_1STBRK_CANC_fl;                                /* 2^(0)[m/ss], Reserve braking end acceleration, 0 */
extern const FLOAT  mACC_2NDBRK_CANC_fl;                                /* 2^(0)[m/ss], Emergency braking end acceleration, 0 */
/* ----- 13. FCA_BRK_judge.c ----- */
/* ----- from - const_FCA_P32RN.c ----- */
/* ----- 14. FEB_BRK_main.c ----- */
/* ----- no any const ----- */
/* ----- 15. FEB_BUZ_OUT_judge.c ----- */
/* ----- from - const_FCA_P32RN.c ----- */
extern const FLOAT  mVR_FCA_BUZ_OUT_fl;                                 /* 2^(0)[m/s], Buzzer output relative speed threshold value, 0 */
extern const FLOAT  mVSP_FCA_BUZ_OUT_fl;                                /* 2^(0)[m/s], Buzzer output vehicle speed threshold value, 0 */
extern const FLOAT mFCA_DEC_REACT_hosei_X_fl[13];                       /* 2^(0) [m/ss], Sloping estimation value */
extern const FLOAT mFCA_DEV_REACT_hosei_Y_fl[13];                       /* 2^(0) [s], Driver response time correction amount */
extern const FLOAT  mDRV_REACT_UP_fl;                                   /* 2^(0)[-], mDRV_REACT_UP_fl, 511.999 */
extern const FLOAT  mDRV_REACT_DN_fl;                                   /* 2^(0)[-], mDRV_REACT_DN_fl, 0 */
/* ----- 16. FCA_DIST_TAR_0_update.c ----- */
/* ----- from - const_FCA_P32RN.c ----- */
extern const FLOAT  mFCA_DEC2_fl;                                       /* 2^(0)[m/ss], Reserve braking target deceleration: DEC2, -3.92 */
extern const FLOAT  mVR_DIST_TAR_SEL1_fl;                               /* 2^(0)[m/s], Stop object target reserve braking final vehicle speed=-300[km/h], -83.3333333333333 */
extern const FLOAT  mVR_DIST_TAR_SEL2_fl;                               /* 2^(0)[m/s], Moving object target reserve braking final vehicle speed=-300[km/h], -83.3333333333333 */
extern const FLOAT mFCA_DIST_OFST_BPFS_y_fl[14];                        /* 2^(0) [m], FCA Emergency braking distance offset TBL */
extern const FLOAT mDEC1_SLOPEhosei_X_fl[13];                           /* 2^(0) [m/ss], Sloping estimation value */
extern const FLOAT mDEC1_SLOPEhosei_Y_fl[13];                           /* 2^(0) [m/ss], Deceleration correction amount */
/* ----- 17. FEB_flgset.c ----- */
/* ----- from - const_FCA_P32RN.c ----- */
extern const FLOAT  mFCA_ON_VSP_fl;                                     /* 2^(0)[m/s], Fluid pressure command value gradual disconnection vehicle speed condition when lost, 1.38888888888889 */
extern const FLOAT  mFCA_OFF_VSP_fl;                                    /* 2^(0)[m/s], FCA operation end vehicle speed, -0.833333333333333 */
extern const FLOAT  mFCA_STOPMODE_SPD_fl;                               /* 2^(0)[m/s], Stop mode transition permission vehicle speed threshold at the time of braking end, 0 */
/* ----- 18. FCA_FULLBRK_judge.c ----- */
/* ----- mFCA_MAX_BRK_VSP_ON_fl ----- */
/* ----- mFCA_MAX_BRK_VSP_OFF_fl ----- */
/* ----- 19. FCA_STATE_update.c ----- */
/* ----- no any const ----- */
/* ----- 20. FEB_torque_down.c ----- */
/* ----- from - const_FCA_P32RN.c ----- */
extern const FLOAT  mFCA_APO_MAX_fl;                                    /* 2^(0)[%], Target accelerator opening maximum value, 127.75 */
extern const FLOAT  mFCA_APO_UPLMT_fl;                                  /* 2^(0)[%], Requested accelerator opening gradual disconnection threshold value, 100 */
extern const FLOAT  mFCA_APO_RL_fl;                                     /* 2^(0)[%/s], Requested accelerator opening change limit, 100 */
/* ----- 21. fca_vVSP_CMD_STPCONTROL_update.c ----- */
/* ----- from - const_FCA_P32RN.c ----- */
extern const FLOAT  mVSP_READY_FCA_fl;                                  /* 2^(0)[m/s], Target vehicle speed calculation execution judgment for stop control: vehicle speed condition, 83.3333333333333 */
extern const FLOAT  mTHW_FCA_fl;                                        /* 2^(0)[s], Time between vehicle, 0 */
extern const FLOAT  mT_DLY_FCA_fl;                                      /* 2^(0)[s], Delay time, 0.132 */
extern const FLOAT  mTTC1_FCA_fl;                                       /* 2^(0)[s], Target vehicle speed calculation execution judgment for stop control: TTC condition 1, -512 */
extern const FLOAT  mTTC2_FCA_fl;                                       /* 2^(0)[s], Target vehicle speed calculation execution judgment for stop control: TTC condition 2, -512 */
extern const FLOAT  mACC_TARGET1_FCA_fl;                                /* 2^(0)[m/ss], Target vehicle speed calculation execution judgment for stop control: acceleration condition1, -512 */
extern const FLOAT  mACC_TARGET2_FCA_fl;                                /* 2^(0)[m/ss], Target vehicle speed calculation execution judgment for stop control: Acceleration condition 2, -512 */
extern const FLOAT  mDIST_MIN_VMIN_FCA_fl;                              /* 2^(0)[m], Target vehicle speed calculation execution judgment to prevent going near the preceding vehicle at low speed: Condition for distance between two cars, 250 */
extern const FLOAT  mACC_VMIN_CALC_FCA_fl;                              /* 2^(0)[m/ss], Target vehicle speed calculation execution judgment to prevent going near the preceding vehicle at low speed: ON condition acceleration, 1.5 */
extern const FLOAT  mACC_VMIN_CALC_OFF_FCA_fl;                          /* 2^(0)[m/ss], Target vehicle speed calculation execution judgment to prevent going near the preceding vehicle at low speed: OFF condition acceleration, 2 */
extern const FLOAT  mACC_VMIN_CALC_OFFSET_FCA_fl;                       /* 2^(0)[m/s], Target vehicle speed calculation execution judgment to prevent going near the preceding vehicle at low speed: OFF condition vehicle speed offset, 1 */
extern const FLOAT  mUP_RLIM_ACC_TARGET_FCA_fl;                         /* 2^(0)[m/sss], Targeted vehicle speed calculation for stop control:  Change ratio limiter (increasing side) of target acceleration, 0.5 */
extern const FLOAT  mLO_LMT_V_COM_STPCTRL_FCA_fl;                       /* 2^(0)[m/s], FCA vehicle speed command value lower limiter value calculation difference (This value is supplemented (added) to vehicle speed and lower limit value is calulated), -55.434402 */
extern const FLOAT  mLO_LMT_V_COM_CONST_FCA_fl;                         /* 2^(0)[m/s], FCAvehicle speed command value lower limit limiter value, -10 */
extern const FLOAT  mLO_LMT_ACC_TARGET_2NDBRK_fl;                       /* 2^(0)[m/ss], Target acceleration lower limit value at the time of emergency braking, -6 */
extern const FLOAT  mLO_LMT_ACC_TARGET_MAXBRK_fl;                       /* 2^(0)[m/ss], Target acceleration lower limit value at the time of emergency braking (Full braking), -11 */
extern const FLOAT  mDIST_MIN_FCA_1ST_fl;                               /* 2^(0)[m], Minimum distance between two cars, -1 */
extern const FLOAT  mDIST_MIN_FCA_2ND_fl;                               /* 2^(0)[m], Minimum distance between two cars, 1 */
extern const FLOAT  mDN_RCLMT_ACC_TARGET_2ND_fl;                        /* 2^(0)[m/sss], Targeted acceleration change ratio limiter at the time of emergency braking, 1.24 */
extern const FLOAT  mDN_RCLMT_ACC_TARGET_1ST_fl;                        /* 2^(0)[m/sss], Targeted acceleration change ratio limiter at the time of reserve braking, 0.067 */
/* ----- ..... from const_4BA0A.c ----- */
extern const FLOAT  mDIST_ERR_MIN_fl;                                   /* 2^(0)[-], mDIST_ERR_MIN_fl, 0.5 */
extern const FLOAT  mACC_TARGET_UP_RL_fl;                               /* 2^(0)[m/sss], Target vehicle speed calculation to prevent going  near the preceding vehicle at low speed: Change ratio limiter of target acceleration (increasing side), 0.01 */
extern const FLOAT  mACC_TARGET_DN_RL_fl;                               /* 2^(0)[m/sss], Target vehicle speed calculation to prevent going near the preceding vehicle at low speed: Change ratio limiter of target acceleration (decreasing side), 0.5 */
extern const FLOAT  mV_COM_VMIN_UP_fl;                                  /* 2^(0)[-], Constant to calculate upper limit of stop control targeted speed., 2.862 */
extern const FLOAT  mV_COM_VMIN_LO_fl;                                  /* 2^(0)[-], Constant to calculate lower limit of stop control targeted speed, -5.434402 */
extern const FLOAT  mVSP_DIFF_fl;                                       /* 2^(0)[m/s], mVSP_DIFF_fl, 0 */
extern const FLOAT  mVSP_C_ZERO_DIV_fl;                                 /* 2^(0)[m/ss], Acceleration difference minimum value (0 % prevention), 0.01 */
extern const FLOAT  mVSP_T_ACC_TARGET_STOP_fl;                          /* 2^(0)[m/s], Leading vehicle stop judgment vehicle speed threshold value, 0.1 */
extern const FLOAT  mVSP_C_ACC_TARGET_STOP_fl;                          /* 2^(0)[m/s], Vehicle speed threshold value of judgment of stopping the leading vehicle ahead, 0 */
extern const FLOAT  mDIST_MIN_ST_fl;                                    /* 2^(0)[m], mDIST_MIN_ST_fl, 0.25 */
extern const FLOAT  mUP_LMT_ACC_TARGET_fl;                              /* 2^(0)[m/ss], Upper limit of final targeted acceleration, 0 */
extern const FLOAT  mVSP_CTRL_ENBL_ACC_TARGET_fl;                       /* 2^(0)[m/ss], mVSP_CTRL_ENBL_ACC_TARGET_fl, -0.01 */
extern const FLOAT  mTsmpl_fl;                                          /* 2^(0)[-], Delta value of time to calculate integral of stop control targeted speed., 0.01 */
extern const FLOAT  mUP_LMT_V_COM_STOPCONTROL_fl;                       /* 2^(0)[m/s], Targeted speed calculation: Targeted upper limit for stop control, 2.862 */
/* ----- 22. FCAControl.c ----- */
/* ----- from - const_FCA_P32RN.c ----- */
extern const FLOAT  mAPO_ON_ANGL_FCA_fl;                                /* 2^(0)[%], Accelerator operation judgment threshold value, 1 */
extern const FLOAT  mAPO_ON_ANGL_FCA_BRK_fl;                            /* 2^(0)[-], Accelerator operation judgment(Brake judgment) threshold value, 50 */
extern const uint16 mCNT_APO_OVR_START_fl;                              /* 2^(0)[10ms], Accelerator START time, 200 */
/* ----- from - SpecChange.c ----- */
extern const uint8  mAPO_OVR_FCA_SW;                                    /* 2^(0)[-], �į��Ӱ�ސؑ֎d�l(N13), 0 */
/* ----- 23. FEB_GOSTP_main.c ----- */
/* ----- from - const_FCA_P32RN.c ----- */
extern const FLOAT  mVCOMO_LOW_FCA_fl;                                  /* 2^(0)[m/s], Vehicle speed command value threshold value for stop mode judgment, 1.38888888888889 */
extern const FLOAT  mL_STOP_MODE_FCA_fl;                                /* 2^(0)[m], Stop control judgment between vehicle ( mDIST_MIN+1m)(5.5 MB control spec. -F26), 5.8 */
extern const FLOAT  mVSP_STOP_HI_FCA_fl;                                /* 2^(0)[m/s], Vehicle speed threshold value for stop mode judgment (HI), 5.56 */
extern const FLOAT  mPRECEDING_STP_VSP_FCA_fl;                          /* 2^(0)[m/s], Stop judgment leading vehicle speed threshold value, 0.77222 */
extern const FLOAT  mVR_STOP_FCA_fl;                                    /* 2^(0)[m/s], Relative speed threshold value for stop mode judgment, 2.78 */
extern const FLOAT  mVSP_STOP_LOW_FCA_fl;                               /* 2^(0)[m/s], Vehicle speed threshold value for stop mode judgment, 0.833333333333333 */
extern const uint16 mVSP_STOP_TIME_FCA_fl;                              /* 2^(0)[10ms], Vehicle speed condition continuous time for stop mode judgment, 10 */
/* ----- from - const_MB_4BA0A.c ----- */
extern const FLOAT  mGOSTP_PRMT_ACCSUB2_05MS_MB_fl;                     /* 2^(0)[m/ss], Stop control permited slope, 0.5 */
extern const FLOAT mDIST_STOP_MB_X_fl[6];                               /* 2^(0) [m/s], Vehicle speed  axis */
extern const FLOAT mDIST_STOP_MB_Y_fl[6];                               /* 2^(0) [m/s], Relative velocity */
extern const FLOAT mDIST_STOP_MB_Z_fl[36];                              /* 2^(0) [m], Threshold value distance between vehicles for stop mode */
/* ----- from - const_4BA0A.c ----- */
extern const uint16 mSTOP_TIME_fl;                                      /* 2^(0)[10ms], Stop control time threshold value of ACC, 200 */
extern const FLOAT  mVSP_EST_LMT_fl;                                    /* 2^(0)[m/s], Vehicle speed measurement starting speed, 0.15 */
extern const FLOAT  mGOSTP_PRMT_001KMH_fl;                              /* 2^(0)[m/s], Stop mode shifting permited vehicle speed threshold value, 0.1 */
/* ----- from - ACC/cont/cont_constant.c ----- */
extern const uint16 mGOSTP_PRMT_01SEC_fl;                               /* 0.01[s], 0.1sec, 0.1 */
/* ----- 24. FEB_VSERVO_main.c ----- */
/* ----- from - const_FCA_P32RN.c ----- */
extern const FLOAT  mWHLINIT_CLRWHL_FCA_fl;                             /* 2^(0)[-], Vehicle speed command value additional value calculation constant (Constant in case of VSPMDL) at the time of vehicle speed servo leading vehicle interchange , 0.142853 */
extern const FLOAT  mACOMROB_INIT_MAXFCA_fl;                            /* 2^(0)[m/s], At the time of emergency braking, vehicle speed servo FF filter initialization value (in case of full braking), 1.42857146263123 */
extern const FLOAT  mACOMROB_INIT_2NDFCA_fl;                            /* 2^(0)[m/s], At the time of emergency braking, vehicle speed servo FF filter initialization value (in case of emergency braking), 0.857143 */
extern const FLOAT mACCMDL_MIN_MAP_FCA_fl[5];                           /* 2^(0) [m/ss], ACCMDL_MIN map value */
extern const FLOAT mACCMDL_MIN_VSP_FCA_fl[5];                           /* 2^(0) [m/s], Vehicle speed axis for ACCMDL_MIN map drawing */
/* ----- 25. FEB_VSP_CMD_DIST_main.c ----- */
/* ----- no any const ----- */
/* ----- 26. VSP_CMD_FCA_main.c ----- */
/* ----- no any const ----- */
/* ----- 27. FEB_VSP_update.c ----- */
/* ----- no any const ----- */
/* ----- FCA_DataIn.c ----- */
/* ----- const_4BA0A.c ----- */
extern const FLOAT  mTTC_STOP_CONTROL_fl;                               /* 2^(0)[s], TTC upper value, 20 */
extern const uint16 mCNT_APO_INC_EXC;                                   /* 0.01[s], ���ٓ��ݍ��ݔ��f�p������, 0.5 */
extern const uint16 mCNT_APO_INC;                                       /* 0.01[s], ���ٓ��ݍ��ݔ��f�p������, 3 */
extern const sint32 mACC_OFF_RECO_EXC;                                  /* 2^-16[%/s], ���يJ�x���x臒l, -1 */
extern const sint32 mACC_OFF_RECO1_EXC;                                 /* 2^-16[%/s], ���يJ�x���x臒l1, -50 */
extern const sint16 mACC_OVR_RECO_EXC;                                  /* 2^-8[%], ���ٓ��ݑ������f臒l(�m�M�x�ύX�p), 10 */
extern const uint16 mCNT_ACCOVR_RECO_EXC_MAX;                           /* 0.01[s], ����ON���ԍő�l, 5 */
extern const uint16 mCNT_APO_OVR_RECO_EXC;                              /* 0.01[s], ���ٓ��ݑ������f�p������, 3 */
extern const uint16 mCNT_VR_OVR_EXC;                                    /* 0.01[s], ���ً}���ݍ��݉������莞��, 1 */
extern const uint16 mCNT_ON_EXC;                                        /* 0.01[s], ���ً}���ݍ��݌p�����莞��, 10 */
extern const uint16 mCNT_FFP_OVR_OFF;                                   /* 0.01[s], ���ً}���ݍ��ݱ���OFF���莞��, 2 */
extern const sint32 mVR_FFP_OVR_EXC;                                    /* 2^-16[m/s], ���ً}���ݍ��݉������Α�臒l, -1 */
extern const sint32 mDIST_FFP_OVR_EXC;                                  /* 2^-16[m], ���ً}���ݍ��ݔ��苗��臒l, 80 */
extern const sint16 mAPO_OVR_HIGH;                                      /* 2^-8[%], ���ً}���ݍ��ݔ���臒l, 50 */
extern const sint32 mR_LC_JDG;                                          /* 2^-12[m], ���ړ����fR臒l, 40 */
extern const uint16 mLC_CNT_TSIG_TH;                                    /* 2^(0)[-], ���ړ����f�p����臒l, 3 */
extern const uint16 mLC_CNT_TH;                                         /* 2^(0)[-], ���ړ����f�p����臒l, 3 */
extern const sint32 mLC_TRJ_OFST_TSIG_TH;                               /* 2^-16[-], ���ړ����f�pTRJ臒l, 0.494 */
extern const sint32 mLC_TRJ_OFST_TH;                                    /* 2^-16[-], ���ړ����f�pTRJ臒l, 0.494 */
extern const sint32 mLC_LAT_TSIG_TH;                                    /* 2^-16[m], ���ړ����f�p���ʒu臒l, 0.3841 */
extern const sint32 mLC_LAT_TH;                                         /* 2^-16[m], ���ړ����f�p���ʒu臒l, 0.43895 */
extern const sint32 mLC_TRJ_OFST_CNT_TSIG_TH;                           /* 2^-16[-], ���ړ����f�pTRJ���ċ���臒l, 0.165 */
extern const sint32 mLC_TRJ_OFST_CNT_TH;                                /* 2^-16[-], ���ړ����f�pTRJ���ċ���臒l, 0.21948 */
extern const sint32 mLC_TRJ_OFST_CNT_RST_TSIG_TH;                       /* 2^-16[-], ���ړ����f�pTRJ���ċ֎~臒l, 0.44 */
extern const sint32 mLC_TRJ_OFST_CNT_RST_TH;                            /* 2^-16[-], ���ړ����f�pTRJ���ċ֎~臒l, 0.60356 */
extern const sint32 mLC_DIST_TSIG_TH;                                   /* 2^-16[m], ���ړ����f�p��������臒l, 40 */
extern const sint32 mLC_DIST_TH;                                        /* 2^-16[m], ���ړ����f�p��������臒l, 30 */
extern const uint16 mCNT_LC_JDG;                                        /* 0.01[s], ���ړ����fON����, 5 */
extern const sint32 mVSP_TH_DECOMP_PRS;                                 /* 2^-16[m/s], �u���[�L���X�������x�ύX, 1.38888549804688 */
/* ----- 28. �t�F�[���Z�[�t�f�f�萔 ----- */
/* -----  ----- */
/* ----- �`���[�j���O�萔 ----- */
extern const sint32 mLOST_DEC_CHANGE_50KMPH;                            /* 2^-16[m/s], 50 [km/h]����, 13.8888888888889 */
extern const T_3D_MAP mFEB_P_UPLIM_Map;                                 /* X:2^-8 [m/s], Y:2^-6 [m], Z:2^-16 [MPa/10ms], mFEB_P_UPLIM_Map */
extern const T_2D_MAP mDECOMP_PRESS_TBL_MAP_DR;                         /* X:2^-8 [m/s], Y:2^-13 [PMa/10ms], mDECOMP_PRESS_TBL_MAP_DR */
extern const T_2D_MAP mTBL_DECOMP_PRS_MB;                               /* X:2^-8 [m/s], Y:2^-13 [PMa/10ms], mTBL_DECOMP_PRS_MB */
extern const T_2D_MAP mTBL_DECOMP_PRS_MB_JOJO;                          /* X:2^-8 [m/s], Y:2^-13 [PMa/10ms], �u���[�L�I�[�o�[���C�h���ɍč쓮�֎~��500ms�}�X�N�ɓ���ɂ������� */
extern const T_2D_MAP mTBL_S_TEIKOU;                                    /* X:2^-8 [m/s], Y:2^-12 [m/s^2], X:LSB:2^-8 ���ԑ���,Y:LSB:2^-12 ���s��R�� */
extern const T_2D_MAP mFCA_1STBRK_YAW_LMT;                              /* X:0.05 [deg/s], Y:2^-12 [MPa], const_FCA_P32RN.c */
extern const sint32 mBRAKE_PRESSURE_CMD_STOPMIN;                        /* 2^-22[MPa], �Œ�t�������l const_4BA0A.c , 0.8 */
extern const uint16 mDRV_BRK_PRS_ON_FEB;                                /* 0.05[bar], ��ײ����ڰ��t����ݾ�臒l, 20 */
/* ----- ��`���[�j���O�萔 ----- */
extern const sint32 mFEB_LOST_DECOMP_H;                                 /* 2^-22[MPa/10ms], 20[MPa/s]���� , 0.2 */
extern const sint32 mFEB_LOST_DECOMP_L;                                 /* 2^-22[MPa/10ms], 2[MPa/s]���� , 0.02 */
extern const sint32 mFEB_ONCEACC_DECOMP;                                /* 2^-22[MPa/10ms], 2[MPa/s]���� , 0.02 */
extern const sint32 mFEB_ONCEACC_DECOMP2;                               /* 2^-22[MPa/10ms], 5[MPa/s]���� , 0.05 */
extern const sint32 mFEB_BRAKE_PRESSURE_CMD_MAX;                        /* 2^-22[MPa], 3[MPa] , 3 */
extern const sint32 mFEB_BRAKE_PRESSURE_CMD_MIN ;                       /* 2^-22[MPa], 0[MPa] , 0 */
extern const sint32 mFEB_BRAKE_PRESSURE_CMD_GO;                         /* 2^-22[MPa], 0.5[MPa] , 0.5 */
extern const sint32 mFEB_BRAKE_PRESSURE_DOWN;                           /* 2^-22[MPa/10ms], 2.4[MPa/s]���� , 0.024 */
extern const FLOAT mFCA_MARGIN_MAP_YOKO_y_fl[14];                       /* 2^(0) [-], mFCA_MARGIN_MAP_YOKO_y_fl */
extern const FLOAT mFCA_MARGIN_MAP_YOKO_MOVE_y_fl[14];                  /* 2^(0) [-], mFCA_MARGIN_MAP_YOKO_MOVE_y_fl */
extern const FLOAT mFCA_TTC_STR_YOKO2_y_fl[11];                         /* 2^(0) [-], mFCA_TTC_STR_YOKO2_y_fl */
extern const FLOAT mFCA_TTC_STR_YOKO_x_fl[11];                          /* 2^(0) [-], mFCA_TTC_STR_YOKO_x_fl */
extern const FLOAT mFCA_DIST_OFST_BPFS_YOKO_y_fl[14];                   /* 2^(0) [-], mFCA_DIST_OFST_BPFS_YOKO_y_fl */
extern const FLOAT mFCA_TTC_STR_YOKO1_y_fl[11];                         /* 2^(0) [-], mFCA_TTC_STR_YOKO1_y_fl */
extern const FLOAT mFCA_TTC_STR_YOKO_MOVE_x_fl[11];                     /* 2^(0) [-], mFCA_TTC_STR_YOKO_MOVE_x_fl */
extern const FLOAT mFCA_DIST_OFST_BPFS_YOKO_MOVE_y_fl[14];              /* 2^(0) [-], mFCA_DIST_OFST_BPFS_YOKO_MOVE */
extern const FLOAT mFCA_TTC_STR_YOKO_MOVE2_y_fl[11];                    /* 2^(0) [-], mFCA_TTC_STR_YOKO_MOVE2_y_fl */
extern const FLOAT mFCA_TTC_STR_YOKO_MOVE1_y_fl[11];                    /* 2^(0) [-], mFCA_TTC_STR_YOKO_MOVE1_y_fl */
extern const FLOAT  mVSP_FCA_PRE_BRK_FOR_MOVE_fl;                       /* 2^(0)[m/s], mVSP_FCA_PRE_BRK_FOR_MOVE_fl, 9.722229 */
extern const FLOAT mFCA_DEV_REACT_MOVE_hosei_Y_fl[13];                  /* 2^(0) [s], mFCA_DEV_REACT_MOVE_hosei_Y_fl */
extern const T_2D_MAP mFCA_1STBRK_VSP_LMT;                              /* X:2^-8 [m/s], Y:2^-12 [MPa], mFCA_1STBRK_VSP_LMT */
extern const T_2D_MAP mFCA_1STBRK_VSP_LMT_MOVE;                         /* X:2^-8 [m/s], Y:2^-12 [MPa], �ړ����p�̗\�����������~�b�g 0.6G�ً}�����ƂȂ邱�Ƃ�z�肵�ė\���͂����C���ɂ��Ă����B */
extern const sint16 mTBL_APO_OVR_Y[2];                                  /* 2^-8 [%], ���ٓ��ݑ������f���يJ�x臒l�� */
extern const sint16 mAPO_ANGL_INC_GAIN[10];                             /* 2^-8 [-], ���ٓ��ݍ��ݗʈˑ�����ٔ��͕␳ϯ�� */
extern const sint16 mCNT_FFP_DCA_BUZ_TIME[10];                          /* 2^(0) [-], �x��ON���Զ����� */
extern const uint8  mFEB_FFP_OPTION;                                    /* 2^(0)[-], mFEB_FFP_OPTION, 0 */
extern const sint32 mFCA_VSP_TH_APOOVR;                                 /* 2^(0)[-], mFCA_VSP_TH_APOOVR, 40777956 */
/* ----- ADAS5_FULLBRK ----- */
extern const uint16 mJDG_MAX_BRK_TH_STR_OFF_ON_TIME ;                   /* 2^(0)[-], LSB:10 �t�����������ǔ���OFF�EON�A�Ǝ���[msec]�ˏƍ��񐔂ɕϊ�, 20 */
extern const uint16 mJDG_MAX_BRK_TH_STR_ON_OFF_TIME;                    /* 2^(0)[-], LSB:10 �t�����������ǔ���ON�EOFF�A�Ǝ���[msec]�ˏƍ��񐔂ɕϊ�, 20 */
extern const uint16 mJDG_MAX_BRK_TH_YAW_OFF_ON_TIME;                    /* 2^(0)[-], LSB:10 �t�����������[���[�g����OFF�EON�A�Ǝ���[msec]�ˏƍ��񐔂ɕϊ�, 20 */
extern const uint16 mJDG_MAX_BRK_TH_YAW_ON_OFF_TIME;                    /* 2^(0)[-], LSB:10 �t�����������[���[�g����ON�EOFF�A�Ǝ���[msec]�ˏƍ��񐔂ɕϊ�, 20 */
extern const sint32 mFCA_MAX_BRK_VSP_ON_LO;                             /* 2^(0)[m/s], LSB:2^-16 �t����������ON���f�ԑ�(�ᑬ), 659001 */
extern const sint32 mFCA_MAX_BRK_VSP_OFF_LO;                            /* 2^(0)[m/s], LSB:2^-16 �t����������OFF���f�ԑ�(�ᑬ), 677205 */
extern const sint16 mMAX_BRK_TH_STR_MAP_x[16];                          /* 2^(0) [deg/s], LSB:2^-8 �t�������ԑ�����臒l�}�b�v �ԑ��� */
extern const sint16 mMAX_BRK_TH_STR_MAP_y[16];                          /* 2^(0) [deg], LSB:2^-8 �t�������ԑ�����臒l�}�b�v ���Ǌp�� */
extern const sint16 mMAX_BRK_TH_YAW_MAP_x[16];                          /* 2^(0) [m/s], LSB:2^-8 �t�������ԑ�����臒l�}�b�v �ԑ��� */
extern const sint16 mMAX_BRK_TH_YAW_MAP_y[16];                          /* 2^(0) [deg/s], LSB:2^-12 �t�������ԑ�����臒l�}�b�v ���Ǌp�� */
/* ----- JAA(Junction Assist Aeb) ----- */
/* ----- MODE�Ⴂ�ł̉񐶃R�[�X�g�g���N�ʂ��l�����郍�W�b�N ----- */
extern const sint16 mFCA_TARGET_PBRK_COAST_MAX_COMP[21];                /* 2^(0) [Mpa], LSB:2^-12 �\�������p�ڕW�t���␳�l */
extern const sint16 mFCA_TARGET_PBRK_COAST_MAX_ePdP[21];                /* 2^(0) [Mpa], LSB:2^-12 �\�������p�ڕW�t���␳�l */
extern const sint16 mFCA_TARGET_PBRK_COAST_2ND_ePdP[21];                /* 2^(0) [Mpa], LSB:2^-12 �\�������p�ڕW�t���␳�l */
extern const sint16 mFCA_TARGET_PBRK_COAST_1ST_ePdP[21];                /* 2^(0) [Mpa], LSB:2^-12 �ِ����p�ڕW�t���␳�l */
extern const sint16 mFCA_TARGET_PBRK_COAST_MAX_ePdC[21];                /* 2^(0) [Mpa], LSB:2^-12 �\�������p�ڕW�t���␳�l */
extern const sint16 mFCA_TARGET_PBRK_COAST_2ND_ePdC[21];                /* 2^(0) [Mpa], LSB:2^-12 �\�������p�ڕW�t���␳�l */
extern const sint16 mFCA_TARGET_PBRK_COAST_1ST_ePdC[21];                /* 2^(0) [Mpa], LSB:2^-12 �ِ����p�ڕW�t���␳�l */
extern const uint16 mSTOP_TIME_TIMEOUT_fl;                              /* 2^(0)[10ms], CS�ǉ��p�V�K�萔�ǉ�, 400 */

#define mWIDTH_OBJ0_MIN                               (StVariantRAM_FEB.mmWIDTH_OBJ0_MIN)
#define mTSIG_ON_DLY_TIME                             (StVariantRAM_FEB.mmTSIG_ON_DLY_TIME)
#define mTBL_RECOG_RELE                               (StVariantRAM_FEB.mmTBL_RECOG_RELE)
#define mAPO_OFF_RECO                                 (StVariantRAM_FEB.mmAPO_OFF_RECO)
#define mAPO_OFF_RECO1                                (StVariantRAM_FEB.mmAPO_OFF_RECO1)
#define mCNT_FFP_ON_MAX                               (StVariantRAM_FEB.mmCNT_FFP_ON_MAX)
#define mCNT_APO_OVR_RECO                             (StVariantRAM_FEB.mmCNT_APO_OVR_RECO)
#define mAPO_OVR_RECO                                 (StVariantRAM_FEB.mmAPO_OVR_RECO)
#define m1_5hzBPF0                                    (StVariantRAM_FEB.mm1_5hzBPF0)
#define m1_5hzBPF1                                    (StVariantRAM_FEB.mm1_5hzBPF1)
#define m1_5hzBPF2                                    (StVariantRAM_FEB.mm1_5hzBPF2)
#define mINV_GAIN_ENGINE_MB                           (StVariantRAM_FEB.mmINV_GAIN_ENGINE_MB)
#define mAPO_ANGL_INC_LATCH                           (StVariantRAM_FEB.mmAPO_ANGL_INC_LATCH)
#define mFFP_BUZ_TIME                                 (StVariantRAM_FEB.mmFFP_BUZ_TIME)
#define mAPO_ANGL_DECOMP_FCA                          (StVariantRAM_FEB.mmAPO_ANGL_DECOMP_FCA)
#define mFCA_ARMYU                                    (StVariantRAM_FEB.mmFCA_ARMYU)
#define mBP_UP_FCA_1ST                                (StVariantRAM_FEB.mmBP_UP_FCA_1ST)
#define mBP_UP_FCA_1ST_CROSS                          (StVariantRAM_FEB.mmBP_UP_FCA_1ST_CROSS)
#define mFCA_BRK_ENABLE1                              (StVariantRAM_FEB.mmFCA_BRK_ENABLE1)
#define mFCA_BRK_DISABLE1                             (StVariantRAM_FEB.mmFCA_BRK_DISABLE1)
#define mBRK_PRES_CMD_MIN_2NDFCA                      (StVariantRAM_FEB.mmBRK_PRES_CMD_MIN_2NDFCA)
#define mBRK_PRES_CMD_MIN_2NDFCA_BPFS                 (StVariantRAM_FEB.mmBRK_PRES_CMD_MIN_2NDFCA_BPFS)
#define mBRK_PRES_CMD_MIN_MAXFCA                      (StVariantRAM_FEB.mmBRK_PRES_CMD_MIN_MAXFCA)
#define mBRK_PRES_CMD_MIN_MAXFCA_BPFS                 (StVariantRAM_FEB.mmBRK_PRES_CMD_MIN_MAXFCA_BPFS)
#define mBRK_PRES_CMD_MIN_Prefill                     (StVariantRAM_FEB.mmBRK_PRES_CMD_MIN_Prefill)
#define mBRK_PRES_CMD_MIN                             (StVariantRAM_FEB.mmBRK_PRES_CMD_MIN)
#define mBRAKE_PRESSURE_CMD_MIN_FEB                   (StVariantRAM_FEB.mmBRAKE_PRESSURE_CMD_MIN_FEB)
#define mBRK_PRES_CMD_MAX_1STFCA                      (StVariantRAM_FEB.mmBRK_PRES_CMD_MAX_1STFCA)
#define mBRK_PRES_CMD_MAX_2NDFCA                      (StVariantRAM_FEB.mmBRK_PRES_CMD_MAX_2NDFCA)
#define mBRK_PRES_CMD_MAX_2NDFCA_BPFS                 (StVariantRAM_FEB.mmBRK_PRES_CMD_MAX_2NDFCA_BPFS)
#define mBRK_PRES_CMD_MAX_MAXFCA                      (StVariantRAM_FEB.mmBRK_PRES_CMD_MAX_MAXFCA)
#define mBRK_PRES_CMD_MAX_MAXFCA_BPFS                 (StVariantRAM_FEB.mmBRK_PRES_CMD_MAX_MAXFCA_BPFS)
#define mFCA_MAX_BRK_ABS_HILMT                        (StVariantRAM_FEB.mmFCA_MAX_BRK_ABS_HILMT)
#define mFCA_MAX_BRK_ABS_JOJO                         (StVariantRAM_FEB.mmFCA_MAX_BRK_ABS_JOJO)
#define mFCA_JOJO_TBL                                 (StVariantRAM_FEB.mmFCA_JOJO_TBL)
#define mFCA_1STBRK_PRMT_DIST_STOP_MAP                (StVariantRAM_FEB.mmFCA_1STBRK_PRMT_DIST_STOP_MAP)
#define mFCA_CONST_A_fl                               (StVariantRAM_FEB.mmFCA_CONST_A_fl)
#define mFCA_INV_JARK1_fl                             (StVariantRAM_FEB.mmFCA_INV_JARK1_fl)
#define mFCA_MARGIN_MAP_y_fl                          (StVariantRAM_FEB.mmFCA_MARGIN_MAP_y_fl)
#define mFCA_TARGET_PBRK_SUP_M_MAP                    (StVariantRAM_FEB.mmFCA_TARGET_PBRK_SUP_M_MAP)
#define mFCA_TARGET_PBRK_MAP                          (StVariantRAM_FEB.mmFCA_TARGET_PBRK_MAP)
#define FS_FEB_DRVER_BRKOVER                          (StVariantRAM_FEB.mFS_FEB_DRVER_BRKOVER)
#define mDIST_TAR_0_LOMIN                             (StVariantRAM_FEB.mmDIST_TAR_0_LOMIN)
#define mFCA_MAXBRK_PRMT_DIST_STOP_fl                 (StVariantRAM_FEB.mmFCA_MAXBRK_PRMT_DIST_STOP_fl)
#define mFCA_MAXBRK_PRMT_DIST_MOVE_fl                 (StVariantRAM_FEB.mmFCA_MAXBRK_PRMT_DIST_MOVE_fl)
#define mFCA_1STBRK_PRMT_DIST_STOP_fl                 (StVariantRAM_FEB.mmFCA_1STBRK_PRMT_DIST_STOP_fl)
#define mFCA_1STBRK_PRMT_DIST_MOVE_fl                 (StVariantRAM_FEB.mmFCA_1STBRK_PRMT_DIST_MOVE_fl)
#define mFCA_2NDBRK_PRMT_DIST_STOP_fl                 (StVariantRAM_FEB.mmFCA_2NDBRK_PRMT_DIST_STOP_fl)
#define mFCA_2NDBRK_PRMT_DIST_MOVE_fl                 (StVariantRAM_FEB.mmFCA_2NDBRK_PRMT_DIST_MOVE_fl)
#define mT_DRV_REACT_y_fl                             (StVariantRAM_FEB.mmT_DRV_REACT_y_fl)
#define mFCA_DEC_REACT_Y_fl                           (StVariantRAM_FEB.mmFCA_DEC_REACT_Y_fl)
#define mT_DRV_REACT_y_prebrk_fl                      (StVariantRAM_FEB.mmT_DRV_REACT_y_prebrk_fl)
#define mFCA_DEC_REACT_Y_prebrk_fl                    (StVariantRAM_FEB.mmFCA_DEC_REACT_Y_prebrk_fl)
#define mTTC_STR_STAND1_fl                            (StVariantRAM_FEB.mmTTC_STR_STAND1_fl)
#define mTTC_STR_STAND2_fl                            (StVariantRAM_FEB.mmTTC_STR_STAND2_fl)
#define mTTC_STR1_fl                                  (StVariantRAM_FEB.mmTTC_STR1_fl)
#define mTTC_STR2_fl                                  (StVariantRAM_FEB.mmTTC_STR2_fl)
#define mT_DRV_REACT_BRK_x_fl                         (StVariantRAM_FEB.mmT_DRV_REACT_BRK_x_fl)
#define mFCA_DEC_REACT_X_fl                           (StVariantRAM_FEB.mmFCA_DEC_REACT_X_fl)
#define mT_DRV_REACT_BRK_y_fl                         (StVariantRAM_FEB.mmT_DRV_REACT_BRK_y_fl)
#define mT_DRV_REACT_BRK_y_prebrk_fl                  (StVariantRAM_FEB.mmT_DRV_REACT_BRK_y_prebrk_fl)
#define mT_DRV_REACT_MOVE_y_prebrk_fl                 (StVariantRAM_FEB.mmT_DRV_REACT_MOVE_y_prebrk_fl)
#define mFCA_DEC_REACT_MOVE_Y_prebrk_fl               (StVariantRAM_FEB.mmFCA_DEC_REACT_MOVE_Y_prebrk_fl)
#define mFCA_DEC1_LMT_fl                              (StVariantRAM_FEB.mmFCA_DEC1_LMT_fl)
#define mFCA_INV_DEC1_2ND_fl                          (StVariantRAM_FEB.mmFCA_INV_DEC1_2ND_fl)
#define mFCA_MAX_BRK_VSP_ON_fl                        (StVariantRAM_FEB.mmFCA_MAX_BRK_VSP_ON_fl)
#define mFCA_MAX_BRK_VSP_OFF_fl                       (StVariantRAM_FEB.mmFCA_MAX_BRK_VSP_OFF_fl)
#define mFCA_TARGET_PBRK_PED_MAP                      (StVariantRAM_FEB.mmFCA_TARGET_PBRK_PED_MAP)
#define mFCA_TARGET_PBRK_MAP_ACCEL                    (StVariantRAM_FEB.mmFCA_TARGET_PBRK_MAP_ACCEL)
#define mBRK_PRES_CMD_MAX_MAXFCA_MAP                  (StVariantRAM_FEB.mmBRK_PRES_CMD_MAX_MAXFCA_MAP)
#define mBRK_PRES_CMD_MIN_MAXFCA_MAP                  (StVariantRAM_FEB.mmBRK_PRES_CMD_MIN_MAXFCA_MAP)
#define mFCA_TARGET_PBRK_Prefill_MAP                  (StVariantRAM_FEB.mmFCA_TARGET_PBRK_Prefill_MAP)
#define mBP_UP_FCA_1ST_MAP                            (StVariantRAM_FEB.mmBP_UP_FCA_1ST_MAP)
#define mFCA_MARGIN_MAP_MOVE_x_fl                     (StVariantRAM_FEB.mmFCA_MARGIN_MAP_MOVE_x_fl)
#define mFCA_MARGIN_MAP_MOVE_y_fl                     (StVariantRAM_FEB.mmFCA_MARGIN_MAP_MOVE_y_fl)
#define mFCA_DEC1_fl                                  (StVariantRAM_FEB.mmFCA_DEC1_fl)
#define mFCA_INV_DEC1_MAX_fl                          (StVariantRAM_FEB.mmFCA_INV_DEC1_MAX_fl)
#define mFCA_MARGIN_MAP_x_fl                          (StVariantRAM_FEB.mmFCA_MARGIN_MAP_x_fl)
#define mBRK_PRES_CMD_PREFILL                         (StVariantRAM_FEB.mmBRK_PRES_CMD_PREFILL)
#define mT_DRV_REACT_BRK_MOVE_y_prebrk_fl             (StVariantRAM_FEB.mmT_DRV_REACT_BRK_MOVE_y_prebrk_fl)
#define mFCA_TARGET_PBRK_VEH_MAP                      (StVariantRAM_FEB.mmFCA_TARGET_PBRK_VEH_MAP)
#define mBP_UP_FCA_1ST_PED_MAP                        (StVariantRAM_FEB.mmBP_UP_FCA_1ST_PED_MAP)
#define mBP_UP_FCA_1ST_VEH_MAP                        (StVariantRAM_FEB.mmBP_UP_FCA_1ST_VEH_MAP)
#define mFCA_MAX_BRK_VSP_ON_HI                        (StVariantRAM_FEB.mmFCA_MAX_BRK_VSP_ON_HI)
#define mFCA_MAX_BRK_VSP_OFF_HI                       (StVariantRAM_FEB.mmFCA_MAX_BRK_VSP_OFF_HI)
#define mBRK_PRES_CMD_JAA                             (StVariantRAM_FEB.mmBRK_PRES_CMD_JAA)
#define mFCA_TARGET_PBRK_COAST_COMP                   (StVariantRAM_FEB.mmFCA_TARGET_PBRK_COAST_COMP)
#define mFCA_TARGET_PBRK_COAST_2ND_COMP               (StVariantRAM_FEB.mmFCA_TARGET_PBRK_COAST_2ND_COMP)
#define mFCA_TARGET_PBRK_COAST_1ST_COMP               (StVariantRAM_FEB.mmFCA_TARGET_PBRK_COAST_1ST_COMP)
#define mTTC_STR_STAND1_WITH_AD2_fl                   (StVariantRAM_FEB.mmTTC_STR_STAND1_WITH_AD2_fl)
#define mTTC_STR_STAND2_WITH_AD2_fl                   (StVariantRAM_FEB.mmTTC_STR_STAND2_WITH_AD2_fl)
#define mTTC_STR1_WITH_AD2_fl                         (StVariantRAM_FEB.mmTTC_STR1_WITH_AD2_fl)
#define mTTC_STR2_WITH_AD2_fl                         (StVariantRAM_FEB.mmTTC_STR2_WITH_AD2_fl)
#endif /* __FEB_CONST_J32V_7DB0A_H__ */
