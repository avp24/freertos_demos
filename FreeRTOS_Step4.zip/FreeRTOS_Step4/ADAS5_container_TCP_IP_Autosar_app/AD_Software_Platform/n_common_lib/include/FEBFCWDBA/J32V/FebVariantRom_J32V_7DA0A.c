/****************************************************************************** */
/*                                                                              */
/*     Copyright (c) 2013 Nissan, Japan                                         */
/*                                                                              */
/* **************************************************************************** */
/*                                                                              */
/* Project:     J32V FEB Const                                                  */
/* Module:                                                                      */
/* Version      10.3.0_B                                                        */
/* Author:                                                                      */
/* Making of:   ADAS5_FEB_ConstInformation.xlsm                                 */
/* MACRO Var:   1.20                                                            */
/* Description:                                                                 */
/* Revision History:                                                            */
/*                                                                              */
/********************************************************************************/
#define __FEB_VARIANT_ROM_J32V_7DA0A_C__

/* ######################################################################### */
/*  Include                                                                  */
/* ######################################################################### */

/* ######################################################################### */
/*  Macro                                                                    */
/* ######################################################################### */

/* ######################################################################### */
/*  Variable                                                                 */
/* ######################################################################### */
#pragma section farrom "OEM_CALIB_SECTION_VAR_FEB"
#if BASEVAR_7DA0A == 1
#include "FebVariantRom_J32V_7DA0A_284E97DA1A.c"
#elif BASEVAR_7DA0A == 2
#include "FebVariantRom_J32V_7DA0A_284E97DA2D.c"
#elif BASEVAR_7DA0A == 3
#include "FebVariantRom_J32V_7DA0A_284E97DA4B.c"
#elif BASEVAR_7DA0A == 4
#include "FebVariantRom_J32V_7DA0A_284E97DA5E.c"
#elif BASEVAR_7DA0A == 5
#include "FebVariantRom_J32V_7DA0A_284E97DA1B.c"
#elif BASEVAR_7DA0A == 6
#include "FebVariantRom_J32V_7DA0A_284E97DA3B.c"
#elif BASEVAR_7DA0A == 7
#include "FebVariantRom_J32V_7DA0A_284E97DA4C.c"
#elif BASEVAR_7DA0A == 8
#include "FebVariantRom_J32V_7DA0A_284E97DA6A.c"
#elif BASEVAR_7DA0A == 9
#include "FebVariantRom_J32V_7DA0A_284E97DA1D.c"
#elif BASEVAR_7DA0A == 10
#include "FebVariantRom_J32V_7DA0A_284E97DA4A.c"
#elif BASEVAR_7DA0A == 11
#include "FebVariantRom_J32V_7DA0A_284E97DA4E.c"
#elif BASEVAR_7DA0A == 12
#include "FebVariantRom_J32V_7DA0A_284E97DA6E.c"
#elif BASEVAR_7DA0A == 13
#include "FebVariantRom_J32V_7DA0A_284E97DA1C.c"
#elif BASEVAR_7DA0A == 14
#include "FebVariantRom_J32V_7DA0A_284E97DA3E.c"
#elif BASEVAR_7DA0A == 15
#include "FebVariantRom_J32V_7DA0A_284E97DA4D.c"
#elif BASEVAR_7DA0A == 16
#include "FebVariantRom_J32V_7DA0A_284E97DA6D.c"
#elif BASEVAR_7DA0A == 17
#include "FebVariantRom_J32V_7DA0A_284E97DA2C.c"
#elif BASEVAR_7DA0A == 18
#include "FebVariantRom_J32V_7DA0A_284E97DA3D.c"
#elif BASEVAR_7DA0A == 19
#include "FebVariantRom_J32V_7DA0A_284E97DA5B.c"
#elif BASEVAR_7DA0A == 20
#include "FebVariantRom_J32V_7DA0A_284E97DA6C.c"
#elif BASEVAR_7DA0A == 21
#include "FebVariantRom_J32V_7DA0A_284E97DA1E.c"
#elif BASEVAR_7DA0A == 22
#include "FebVariantRom_J32V_7DA0A_284E97DA3C.c"
#elif BASEVAR_7DA0A == 23
#include "FebVariantRom_J32V_7DA0A_284E97DA5A.c"
#elif BASEVAR_7DA0A == 24
#include "FebVariantRom_J32V_7DA0A_284E97DA6B.c"
#elif BASEVAR_7DA0A == 25
#include "FebVariantRom_J32V_7DA0A_284E97DA2B.c"
#elif BASEVAR_7DA0A == 26
#include "FebVariantRom_J32V_7DA0A_284E97DA2E.c"
#elif BASEVAR_7DA0A == 27
#include "FebVariantRom_J32V_7DA0A_284E97DA5D.c"
#elif BASEVAR_7DA0A == 28
#include "FebVariantRom_J32V_7DA0A_284E97DA7B.c"
#elif BASEVAR_7DA0A == 29
#include "FebVariantRom_J32V_7DA0A_284E97DA2A.c"
#elif BASEVAR_7DA0A == 30
#include "FebVariantRom_J32V_7DA0A_284E97DA3A.c"
#elif BASEVAR_7DA0A == 31
#include "FebVariantRom_J32V_7DA0A_284E97DA5C.c"
#elif BASEVAR_7DA0A == 32
#include "FebVariantRom_J32V_7DA0A_284E97DA7A.c"
#else
#error "Undefined Variant! : FEB BASEVAR_7DA0A"
#endif
#pragma section farrom restore

/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/* VARIANT NUMBER ALL                                                                                     */
/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
const st_variant_const_FEB  *StVariantROM_FEB[ADAS_MAX_VARIANT_NUM]={
#if BASEVAR_7DA0A == 1
    &StVariantROM_FEB_J32V_7DA0A_284E97DA1A
#elif BASEVAR_7DA0A == 2
    &StVariantROM_FEB_J32V_7DA0A_284E97DA2D
#elif BASEVAR_7DA0A == 3
    &StVariantROM_FEB_J32V_7DA0A_284E97DA4B
#elif BASEVAR_7DA0A == 4
    &StVariantROM_FEB_J32V_7DA0A_284E97DA5E
#elif BASEVAR_7DA0A == 5
    &StVariantROM_FEB_J32V_7DA0A_284E97DA1B
#elif BASEVAR_7DA0A == 6
    &StVariantROM_FEB_J32V_7DA0A_284E97DA3B
#elif BASEVAR_7DA0A == 7
    &StVariantROM_FEB_J32V_7DA0A_284E97DA4C
#elif BASEVAR_7DA0A == 8
    &StVariantROM_FEB_J32V_7DA0A_284E97DA6A
#elif BASEVAR_7DA0A == 9
    &StVariantROM_FEB_J32V_7DA0A_284E97DA1D
#elif BASEVAR_7DA0A == 10
    &StVariantROM_FEB_J32V_7DA0A_284E97DA4A
#elif BASEVAR_7DA0A == 11
    &StVariantROM_FEB_J32V_7DA0A_284E97DA4E
#elif BASEVAR_7DA0A == 12
    &StVariantROM_FEB_J32V_7DA0A_284E97DA6E
#elif BASEVAR_7DA0A == 13
    &StVariantROM_FEB_J32V_7DA0A_284E97DA1C
#elif BASEVAR_7DA0A == 14
    &StVariantROM_FEB_J32V_7DA0A_284E97DA3E
#elif BASEVAR_7DA0A == 15
    &StVariantROM_FEB_J32V_7DA0A_284E97DA4D
#elif BASEVAR_7DA0A == 16
    &StVariantROM_FEB_J32V_7DA0A_284E97DA6D
#elif BASEVAR_7DA0A == 17
    &StVariantROM_FEB_J32V_7DA0A_284E97DA2C
#elif BASEVAR_7DA0A == 18
    &StVariantROM_FEB_J32V_7DA0A_284E97DA3D
#elif BASEVAR_7DA0A == 19
    &StVariantROM_FEB_J32V_7DA0A_284E97DA5B
#elif BASEVAR_7DA0A == 20
    &StVariantROM_FEB_J32V_7DA0A_284E97DA6C
#elif BASEVAR_7DA0A == 21
    &StVariantROM_FEB_J32V_7DA0A_284E97DA1E
#elif BASEVAR_7DA0A == 22
    &StVariantROM_FEB_J32V_7DA0A_284E97DA3C
#elif BASEVAR_7DA0A == 23
    &StVariantROM_FEB_J32V_7DA0A_284E97DA5A
#elif BASEVAR_7DA0A == 24
    &StVariantROM_FEB_J32V_7DA0A_284E97DA6B
#elif BASEVAR_7DA0A == 25
    &StVariantROM_FEB_J32V_7DA0A_284E97DA2B
#elif BASEVAR_7DA0A == 26
    &StVariantROM_FEB_J32V_7DA0A_284E97DA2E
#elif BASEVAR_7DA0A == 27
    &StVariantROM_FEB_J32V_7DA0A_284E97DA5D
#elif BASEVAR_7DA0A == 28
    &StVariantROM_FEB_J32V_7DA0A_284E97DA7B
#elif BASEVAR_7DA0A == 29
    &StVariantROM_FEB_J32V_7DA0A_284E97DA2A
#elif BASEVAR_7DA0A == 30
    &StVariantROM_FEB_J32V_7DA0A_284E97DA3A
#elif BASEVAR_7DA0A == 31
    &StVariantROM_FEB_J32V_7DA0A_284E97DA5C
#elif BASEVAR_7DA0A == 32
    &StVariantROM_FEB_J32V_7DA0A_284E97DA7A
#else
    &StVariantROM_FEB_J32V_7DA0A_284E97DA1A
#endif
};
