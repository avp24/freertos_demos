/****************************************************************************** */
/*                                                                              */
/*     Copyright (c) 2013 Nissan, Japan                                         */
/*                                                                              */
/* **************************************************************************** */
/*                                                                              */
/* Project:     J32V FEB Const                                                  */
/* Module:                                                                      */
/* Version      10.3.0_B                                                        */
/* Author:                                                                      */
/* Making of:   ADAS5_FEB_ConstInformation.xlsm                                 */
/* MACRO Var:   1.20                                                            */
/* Description:                                                                 */
/* Revision History:                                                            */
/*                                                                              */
/********************************************************************************/
#ifndef __FEB_CONST_J32V_H__
#define __FEB_CONST_J32V_H__
/* ######################################################################### */
/*  Macro                                                                    */
/* ######################################################################### */

/* ######################################################################### */
/*  Struct Declaration                                                       */
/* ######################################################################### */

/* ######################################################################### */
/*  COMMON                                                                   */
/* ######################################################################### */

/* ################################################ */
/* DEFENITION                                       */
/* ################################################ */
#pragma ghs startdata
#if J32V_7DA0A
    #include "FebConst_J32V_7DA0A.h"
#elif J32V_7DB0A
    #include "FebConst_J32V_7DB0A.h"
#else
    #error "Not Correct FEB Const !!"
#endif

/* ################################################ */
/* BODY                                             */
/* ################################################ */
#ifdef __FEB_CONST_C__        /* Only included when FEB_const.c is compiling */

volatile static const uint8 version_FEB_CONST[] __attribute__((used,protect)) = "FEB_10.3.0_B"; 

#pragma section farrom "OEM_CALIB_SECTION_PNO_FEB"
#if J32V_7DA0A
    #include "FebConst_J32V_7DA0A.c"
#elif J32V_7DB0A
    #include "FebConst_J32V_7DB0A.c"
#else
    #error "Not Correct FEB Const !!"
#endif
#pragma section farrom restore

#endif /* __FEB_CONST_C__ */
#pragma ghs enddata
#endif /* __FEB_CONST_J32V_H__ */

