/****************************************************************************** */
/*                                                                              */
/*     Copyright (c) 2013 Nissan, Japan                                         */
/*                                                                              */
/* **************************************************************************** */
/*                                                                              */
/* Project:     J32V FEB Const                                                  */
/* Module:                                                                      */
/* Version      10.3.0_B                                                        */
/* Author:                                                                      */
/* Making of:   ADAS5_FEB_ConstInformation.xlsm                                 */
/* MACRO Var:   1.20                                                            */
/* Description:                                                                 */
/* Revision History:                                                            */
/*                                                                              */
/********************************************************************************/
#define __FEB_VARIANT_ROM_J32V_7DB0A_C__

/* ######################################################################### */
/*  Include                                                                  */
/* ######################################################################### */

/* ######################################################################### */
/*  Macro                                                                    */
/* ######################################################################### */

/* ######################################################################### */
/*  Variable                                                                 */
/* ######################################################################### */
#pragma section farrom "OEM_CALIB_SECTION_VAR_FEB"
#if BASEVAR_7DB0A == 1
#include "FebVariantRom_J32V_7DB0A_284E97DB1A.c"
#elif BASEVAR_7DB0A == 2
#include "FebVariantRom_J32V_7DB0A_284E97DB3A.c"
#elif BASEVAR_7DB0A == 3
#include "FebVariantRom_J32V_7DB0A_284E97DB1D.c"
#elif BASEVAR_7DB0A == 4
#include "FebVariantRom_J32V_7DB0A_284E97DB4A.c"
#elif BASEVAR_7DB0A == 5
#include "FebVariantRom_J32V_7DB0A_284E97DB2C.c"
#elif BASEVAR_7DB0A == 6
#include "FebVariantRom_J32V_7DB0A_284E97DB4C.c"
#elif BASEVAR_7DB0A == 7
#include "FebVariantRom_J32V_7DB0A_284E97DB2A.c"
#elif BASEVAR_7DB0A == 8
#include "FebVariantRom_J32V_7DB0A_284E97DB3E.c"
#elif BASEVAR_7DB0A == 9
#include "FebVariantRom_J32V_7DB0A_284E97DB2B.c"
#elif BASEVAR_7DB0A == 10
#include "FebVariantRom_J32V_7DB0A_284E97DB4D.c"
#elif BASEVAR_7DB0A == 11
#include "FebVariantRom_J32V_7DB0A_284E97DJ1A.c"
#elif BASEVAR_7DB0A == 12
#include "FebVariantRom_J32V_7DB0A_284E97DJ1B.c"
#elif BASEVAR_7DB0A == 13
#include "FebVariantRom_J32V_7DB0A_284E97DJ1C.c"
#else
#error "Undefined Variant! : FEB BASEVAR_7DB0A"
#endif
#pragma section farrom restore

/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/* VARIANT NUMBER ALL                                                                                     */
/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
const st_variant_const_FEB  *StVariantROM_FEB[ADAS_MAX_VARIANT_NUM]={
#if BASEVAR_7DB0A == 1
    &StVariantROM_FEB_J32V_7DB0A_284E97DB1A
#elif BASEVAR_7DB0A == 2
    &StVariantROM_FEB_J32V_7DB0A_284E97DB3A
#elif BASEVAR_7DB0A == 3
    &StVariantROM_FEB_J32V_7DB0A_284E97DB1D
#elif BASEVAR_7DB0A == 4
    &StVariantROM_FEB_J32V_7DB0A_284E97DB4A
#elif BASEVAR_7DB0A == 5
    &StVariantROM_FEB_J32V_7DB0A_284E97DB2C
#elif BASEVAR_7DB0A == 6
    &StVariantROM_FEB_J32V_7DB0A_284E97DB4C
#elif BASEVAR_7DB0A == 7
    &StVariantROM_FEB_J32V_7DB0A_284E97DB2A
#elif BASEVAR_7DB0A == 8
    &StVariantROM_FEB_J32V_7DB0A_284E97DB3E
#elif BASEVAR_7DB0A == 9
    &StVariantROM_FEB_J32V_7DB0A_284E97DB2B
#elif BASEVAR_7DB0A == 10
    &StVariantROM_FEB_J32V_7DB0A_284E97DB4D
#elif BASEVAR_7DB0A == 11
    &StVariantROM_FEB_J32V_7DB0A_284E97DJ1A
#elif BASEVAR_7DB0A == 12
    &StVariantROM_FEB_J32V_7DB0A_284E97DJ1B
#elif BASEVAR_7DB0A == 13
    &StVariantROM_FEB_J32V_7DB0A_284E97DJ1C
#else
    &StVariantROM_FEB_J32V_7DB0A_284E97DB1A
#endif
};
