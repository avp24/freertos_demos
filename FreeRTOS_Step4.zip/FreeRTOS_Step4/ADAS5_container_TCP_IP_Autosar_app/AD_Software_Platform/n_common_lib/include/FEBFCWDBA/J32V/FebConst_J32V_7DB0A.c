/****************************************************************************** */
/*                                                                              */
/*     Copyright (c) 2013 Nissan, Japan                                         */
/*                                                                              */
/* **************************************************************************** */
/*                                                                              */
/* Project:     J32V FEB Const                                                  */
/* Module:                                                                      */
/* Version      10.3.0_B                                                        */
/* Making of:   ADAS5_FEB_ConstInformation.xlsm                                 */
/* MACRO Var:   1.20                                                            */
/* Description:                                                                 */
/* Revision History:                                                            */
/*                                                                              */
/********************************************************************************/
#define __FEB_CONST_J32V_7DB0A_C__


const FLOAT  mDV_LO_LMT_1STFCA_fl                = (-5.5F);                     /* 2^(0)[m/ss], Acceleration lower limit value in case of reserve braking, -5.5 */
const FLOAT  mDV_LO_LMT_2NDFCA_fl                = (-9.0F);                     /* 2^(0)[m/ss], Acceleration lower limit value in case of emergency braking, -9 */
const FLOAT  mDV_LO_LMT_MAXFCA_fl                = (-15.0F);                    /* 2^(0)[m/ss], Acceleration lower limit value in case of emergency braking (Full braking), -15 */
const FLOAT  mAMDL_MIN_2NDFCA_fl                 = (-9.0F);                     /* 2^(0)[m/ss], Model matching compensator acceleration lower limit value in case of emergency braking, -9 */
const FLOAT  mAMDL_MIN_MAXFCA_fl                 = (-15.0F);                    /* 2^(0)[m/ss], Model matching compensator acceleration lower limit value in case of emergency braking (Full braking), -15 */
const FLOAT  mA_MDL_FCA_fl                       = (0.067608F);                 /* 2^(0)[-], (1-exp(-(1/Tb)ampling time)), 0.067608 */
const FLOAT  mACCCOM_FF_FCA_fl                   = (6.760498F);                 /* 2^(0)[-], 1-exp(-(1/Tb)ampling time)/sampling time, 6.760498 */
const FLOAT  mACCCOM_FB_FCA_fl                   = (0.74F);                     /* 2^(0)[-], For F/B acceleration command value, 0.74 */
const FLOAT  mACCMDL_MAX_FCA_fl                  = (1.7F);                      /* 2^(0)[m/ss], Model matching compensator acceleration command value maximum value, 1.7 */
const uint8  mSUB_GAIN_FCA_fl                    = (1);                         /* 2^(0)[-], Robust compensator calculation execution ROM SW, 1 */
const FLOAT  mA_FBK_FCA_fl                       = (0.995026F);                 /* 2^(0)[-], (1-exp(-(Constant in case of 1/ robust filter)ampling time))/sampling time (MB), 0.995026 */
const FLOAT  mN_A_LMT_FCA_fl                     = (0.095169F);                 /* 2^(0)[-], 1-exp(-(Constant in case of 1/ACCCOM_LIM_LPF)ampling time), 0.095169 */
const FLOAT  mD_A_LMT_FCA_fl                     = (0.904846F);                 /* 2^(0)[-], exp(-(Constant in case of 1/ACCCOM_LIM_LPF)ampling time) (MB), 0.904846 */
const FLOAT  mA_REF_FCA_fl                       = (0.009951F);                 /* 2^(0)[-], Sampling time1-exp(-(Constant in case of 1/robust filter)ampling time)/sampling time), 0.009951 */
/* ----- ... from const_4BA0A.c ----- */
/* ----- 4. fca_EMERG_BRK_APL_VSP_CMD_DIST_func.c ----- */
/* ----- from - const_FCA_P32RN.c ----- */
const FLOAT  mACC_FB_I_LMT_2ND_fl                = (-0.11F);                    /* 2^(0)[-], Servo output correction vehicle speed command change ratio limit between vehicles ( emergency braking), -0.11 */
const FLOAT  mACC_FB_I_LMT_1ST_fl                = (-0.04F);                    /* 2^(0)[-], Servo output offset vehicle speed command change ratio limit between vehicles (Reserve braking), -0.04 */
const FLOAT  mLPF_V_COM_REF_fl                   = (0.904837F);                 /* 2^(0)[-], Servo output correction LPF between vehicles, 0.904837 */
const FLOAT  mV_COM_FB_G_fl                      = (0.3F);                      /* 2^(0)[-], Servo output correction FB gain between vehicles, 0.3 */
const FLOAT  mV_COM_FB_I_G_fl                    = (0.06F);                     /* 2^(0)[-], Servo output correction FB_I gain between vehicles, 0.06 */
const FLOAT  mV_COM_FB_I_MAX_fl                  = (5.0F);                      /* 2^(0)[-], Servo output correction FB_IUpper limit value between vehicles, 5 */
const FLOAT  mV_COM_FB_I_MIN_fl                  = (-0.5F);                     /* 2^(0)[-], Servo output correction FB_ILower limit value between vehicles, -0.5 */
/* ----- 5. fca_EMERG_BRK_APL_VSP_CMD_func.c ----- */
/* ----- from - const_FCA_P32RN.c ----- */
const FLOAT  mVSP_CMD_DN_LIM_1STFCA_fl           = (0.045F);                    /* 2^(0)[m/ss], Vehicle speed command value change ratio (At the time of reserve braking)=acceleration command value, 0.045 */
const FLOAT  mVSP_CMD_DN_LIM_2NDFCA_fl           = (0.15F);                     /* 2^(0)[m/ss], Vehicle speed command value change ratio (At the time of emergency braking)=acceleration command value, 0.15 */
const FLOAT  mFCA_UP_LIM_VSPCMD_fl               = (1.36111111111111F);         /* 2^(0)[m/s], Speed command limited value at the time of preliminary braking[km/h]:"Speed + this constant value" is considered as upper limit value, 1.36111111111111 */
const FLOAT  mFCA_LO_LIM_VSPCMD_fl               = (2.22222222222222F);         /* 2^(0)[m/s], Speed command limited value at the time of preliminary braking[km/h]:"Speed - this constant value" is considered as lower limit value, 2.22222222222222 */
/* ----- ... from const_MB_4BA0A.c ----- */
const FLOAT  mVSP_CMD_UP_LIM_fl                  = (0.0098F);                   /* 2^(0)[(m/s^2)/10ms], Vehicle speed command value  change ratio limiter (On increase ), 0.0098 */
/* ----- 6. CntrolFfpFca_3_1.c ----- */
/* ----- from - const_FCA_P32RN.c ----- */
const FLOAT  mTTC_FFP_MAX_fl                     = (10.0F);                     /* 2^(0)[-], TTC MAX for FCA pedal operation control, 10 */
/* 2^(0) [-], TTC(LC) for FCA pedal operation control */
const FLOAT mTTC_FFP_LC_fl[10] = {
	10.0F,	10.0F,	10.0F,	10.0F,	10.0F,	10.0F,	10.0F,	10.0F,	10.0F,	10.0F
};
const FLOAT  mTTC_FFP_APO_HIGH_fl                = (5.0F);                      /* 2^(0)[-], TTC(APO_HIGH) for FCA pedal operation control, 5 */
/* 2^(0) [-], TTC(INC_EXC) for FCA pedal operation control */
const FLOAT mTTC_FFP_OVR_EXC_fl[10] = {
	10.0F,	10.0F,	10.0F,	10.0F,	10.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F
};
/* 2^(0) [%], Accelerator step-on increasing amount */
const FLOAT mAPO_ANGL_INC_fl[10] = {
	0.0F,	10.0F,	20.0F,	30.0F,	40.0F,	50.0F,	60.0F,	70.0F,	80.0F,	90.0F
};
/* 2^(0) [-], TTC(STR) of FCA pedal operation control */
const FLOAT mTTC_FFP_STR_fl[10] = {
	10.0F,	10.0F,	10.0F,	10.0F,	10.0F,	10.0F,	10.0F,	10.0F,	10.0F,	10.0F
};
/* 2^(0) [deg], Driver input rudder angle */
const FLOAT mFCA_STR_ANG_fl[10] = {
	0.0F,	10.0F,	20.0F,	30.0F,	40.0F,	50.0F,	60.0F,	70.0F,	80.0F,	90.0F
};
/* 2^(0) [-], TTC(STR SPD) for FCA pedal operation control */
const FLOAT mTTC_FFP_STR_SPD_fl[10] = {
	10.0F,	10.0F,	10.0F,	10.0F,	10.0F,	10.0F,	10.0F,	10.0F,	10.0F,	10.0F
};
/* 2^(0) [deg], Driver input rudder angle */
const FLOAT mSTR_ANGL_SPD_FCA_fl[10] = {
	-2.0F,	-1.5F,	-1.0F,	-0.5F,	0.0F,	0.5F,	1.0F,	1.5F,	2.0F,	2.5F
};
/* 2^(0) [-], FCA pedal reaction force control gain(STR) */
const FLOAT mFFP_STR_FCA_MAP_fl[370] = {
	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,
	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,
	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,
	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,
	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,
	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,
	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,
	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,
	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,
	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,
	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,
	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,
	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,
	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,
	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,
	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,
	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,
	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,
	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,
	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,
	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,
	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,
	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,
	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,
	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,
	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,
	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,
	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,
	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,
	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,
	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,
	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,
	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,
	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,
	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,
	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,
	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F
};
/* 2^(0) [-], FCA pedal reaction force control gain for stop object (STR SPD)  */
const FLOAT mFFP_STR_SPD_FCA_MAP_fl[370] = {
	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,
	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,
	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,
	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,
	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,
	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,
	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,
	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,
	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,
	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,
	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,
	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,
	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,
	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,
	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,
	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,
	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,
	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,
	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,
	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,
	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,
	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,
	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,
	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,
	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,
	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,
	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,
	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,
	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,
	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,
	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,
	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,
	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,
	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,
	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,
	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,
	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F
};
/* 2^(0) [-], FCA pedal reaction force control gain (STR)  */
const FLOAT mFFP_STR_STP_FCA_MAP_fl[370] = {
	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,
	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,
	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,
	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,
	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,
	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,
	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,
	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,
	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,
	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,
	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,
	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,
	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,
	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,
	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,
	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,
	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,
	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,
	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,
	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,
	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,
	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,
	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,
	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,
	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,
	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,
	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,
	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,
	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,
	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,
	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,
	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,
	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,
	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,
	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,
	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,
	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F
};
/* 2^(0) [-], FCA pedal reaction force control gain for stop object (STR SPD) */
const FLOAT mFFP_STR_SPD_STP_FCA_MAP_fl[370] = {
	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,
	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,
	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,
	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,
	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,
	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,
	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,
	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,
	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,
	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,
	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,
	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,
	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,
	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,
	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,
	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,
	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,
	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,
	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,
	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,
	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,
	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,
	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,
	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,
	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,
	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,
	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,
	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,
	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,
	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,
	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,
	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,
	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,
	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,
	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,
	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,
	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F
};
const FLOAT  mFFP_GAIN_MAX_fl                    = (1.0F);                      /* 2^(0)[-], FCApedal reaction force control gain MAX, 1 */
const FLOAT  mFFP_OBJ_SUP_M_GAIN_STP_fl          = (0.5F);                      /* 2^(0)[-], Recognition certainty factor pedal reaction force control M gain for stop object, 0.5 */
/* 2^(0) [-], Pedal reaction force control HI gain map(Horizontal offset ratio)  */
const FLOAT mFFP_TRJ_H_GAIN_FCA_fl[10] = {
	1.0F,	0.7F,	0.5F,	0.5F,	0.5F,	0.5F,	0.5F,	0.5F,	0.5F,	0.5F
};
/* 2^(0) [-], Pedal reaction force control M gain map(Horizontal offset ratio)  */
const FLOAT mFFP_TRJ_M_GAIN_FCA_fl[10] = {
	1.0F,	0.7F,	0.5F,	0.5F,	0.5F,	0.5F,	0.5F,	0.5F,	0.5F,	0.5F
};
/* 2^(0) [-], Pedal reaction force control LO gain map(Horizontal offset ratio)  */
const FLOAT mFFP_TRJ_L_GAIN_FCA_fl[10] = {
	1.0F,	0.65F,	0.55F,	0.5F,	0.5F,	0.5F,	0.5F,	0.5F,	0.5F,	0.5F
};
/* 2^(0) [-], Horizontal offset ratio for map drawing */
const FLOAT mOBJ_TRJ_OFST_HI_FCA_fl[10] = {
	0.285F,	0.492F,	0.547F,	0.66F,	0.77F,	0.88F,	1.0F,	1.1F,	1.2F,	1.3F
};
/* ----- from - const_MB_4BA0A.c ----- */
const FLOAT  mAPO_OVR_HIGH_fl                    = (50.0F);                     /* 2^(0)[%], Acceleration sudden step-on judgment threshold value, 50 */
/* 2^(0) [m/s], Vehicle speed axis */
const FLOAT mPCTBL_VSP_MB_fl[37] = {
	0.0F,	1.0F,	2.0F,	3.0F,	4.0F,	5.0F,	6.0F,	7.0F,	8.0F,	9.0F,
	10.0F,	10.5F,	12.0F,	13.0F,	14.0F,	15.0F,	16.0F,	17.0F,	18.0F,	19.0F,
	20.0F,	21.0F,	22.0F,	23.0F,	24.0F,	25.0F,	26.0F,	27.0F,	28.0F,	29.0F,
	30.0F,	31.0F,	32.0F,	33.0F,	34.0F,	35.0F,	36.0F
};
/* 2^(0) [deg], Driver input  rudder angle  axis */
const FLOAT mSTR_ANGL_fl[10] = {
	-2.0F,	-1.5F,	-1.0F,	-0.5F,	0.0F,	0.5F,	1.0F,	1.5F,	2.0F,	2.5F
};
/* 2^(0) [deg], Driver input  rudder angle variation  axis */
const FLOAT mSTR_ANGL_SPD_fl[10] = {
	-2.0F,	-1.5F,	-1.0F,	-0.5F,	0.0F,	0.5F,	1.0F,	1.5F,	2.0F,	2.5F
};
/* ----- 7. FEB_FFP_cont.c ----- */
/* ----- from - const_FCA_P32RN.c ----- */
/* 2^(0) [-], Warning ON time dependent pedal reaction force correction gain map for FCA */
const FLOAT mFFP_FCA_BUZ_TIME_fl[10] = {
	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	1.0F,	0.0F,	0.0F
};
/* 2^(0) [N], Target pedal reaction force maximum value (initial) */
const FLOAT mTBL_FFP_MAX_OVR_Y_FCA_fl[13] = {
	23.0F,	23.0F,	23.0F,	23.0F,	23.0F,	23.0F,	23.0F,	23.0F,	23.0F,	23.0F,
	23.0F,	23.0F,	23.0F
};
/* 2^(0) [%], Accelerator opening dependent pedal reaction force correction gain (initial) axis */
const FLOAT mTBL_FFP_APO_BUF_INI_Y_FCA_fl[11] = {
	100.0F,	100.0F,	100.0F,	100.0F,	100.0F,	100.0F,	100.0F,	100.0F,	100.0F,	100.0F,
	100.0F
};
/* 2^(0) [N/10ms], Target pedal reaction force change limit map (increasing side) */
const FLOAT mTBL_FFP_MAX_UP_Y_FCA_fl[11] = {
	3.0F,	3.0F,	3.0F,	3.0F,	3.0F,	3.0F,	3.0F,	3.0F,	3.0F,	3.0F,
	3.0F
};
/* 2^(0) [N], Target pedal reaction force maximum value */
const FLOAT mTBL_FFP_MAX_WARN1_Y_FCA_fl[13] = {
	23.0F,	23.0F,	23.0F,	23.0F,	23.0F,	23.0F,	23.0F,	23.0F,	23.0F,	23.0F,
	23.0F,	23.0F,	23.0F
};
/* 2^(0) [%], Accelerator opening dependent pedal reaction force correction gain axis */
const FLOAT mTBL_K_FFP_APO_BUF_Y_FCA_fl[11] = {
	100.0F,	100.0F,	100.0F,	100.0F,	100.0F,	100.0F,	100.0F,	100.0F,	100.0F,	100.0F,
	100.0F
};
/* 2^(0) [N/10ms], Target pedal reaction force change limit map (decreasing side) */
const FLOAT mTBL_FFP_MAX_DN_Y_FCA_fl[11] = {
	0.074F,	0.074F,	0.074F,	0.074F,	0.074F,	0.074F,	0.074F,	0.074F,	0.074F,	0.074F,
	0.074F
};
/* 2^(0) [%], Accelerator opening */
const FLOAT mTBL_FFP_APO_X_FCA_fl[11] = {
	0.0F,	10.0F,	20.0F,	30.0F,	40.0F,	50.0F,	60.0F,	70.0F,	80.0F,	90.0F,
	100.0F
};
/* 2^(0) [m/ss], Gradient estimate value */
const FLOAT mTBL_FFP_SLOPE_X_FCA_fl[13] = {
	-2.94F,	-2.45F,	-1.96F,	-1.47F,	-0.98F,	-0.49F,	0.0F,	0.49F,	0.98F,	1.47F,
	1.96F,	2.45F,	2.94F
};
const FLOAT  mK_FFP_OVR_FCA_fl                   = (20.0F);                     /* 2^(0)[-], Target pedal reaction force correction calculation gain, 20 */
const FLOAT  mFFP_SUP_H_GAIN_fl                  = (0.0F);                      /* 2^(0)[-], Pedal reaction force offset calculation gain (HI), 0 */
const FLOAT  mFFP_MAX_TIME_FCA_fl                = (50.0F);                     /* 2^(0)[10ms], Target pedal reaction force retention time, 50 */
/* ----- from - const_MB_4BA0A.c ----- */
/* 2^(0) [-], When buzzer in ON, Counter axis */
const FLOAT mCNT_FFP_DCA_BUZ_TIME_fl[10] = {
	0.0F,	50.0F,	60.0F,	80.0F,	100.0F,	120.0F,	140.0F,	250.0F,	300.0F,	400.0F
};
const FLOAT  m0p01_fl                            = (0.01F);                     /* 2^(0)[-], For calculating Target Pedal  reactive force ( After correction), constant, 0.01 */
const FLOAT  m100pct_fl                          = (100.0F);                    /* 2^(0)[%], 1, 100 */
const FLOAT  mCFC_DN_LIM_LOST_fl                 = (0.5F);                      /* 2^(0)[-], 0.01 At the time of lost, Pedal  reactive force change limit (On decrease), 0.5 */
const FLOAT  mCFC_DN_LIM_OVR_fl                  = (0.3F);                      /* 2^(0)[N/10ms], 0.01 Target Pedal  reactive force change limit (On decrease), 0.3 */
const FLOAT  mCFC_DN_LIM_fl                      = (0.12F);                     /* 2^(0)[N/10ms], 0.01 Target Pedal  reactive force change limit (On decrease), 0.12 */
/* ----- 8. FEB_FFP_main.c ----- */
/* ----- from - const_FCA_P32RN.c ----- */
const FLOAT  mCFC_UP_LIM_FCA_fl                  = (3.0F);                      /* 2^(0)[N/10ms], 0.01 target pedal reaction force change limit (increasing side), 3 */
const FLOAT  mCFC_UP_LIM_OFF_FCA_fl              = (3.0F);                      /* 2^(0)[N/10ms], 0.01 Target pedal reaction force change limit (increasing side) in case of accelerator OFF, 3 */
const FLOAT  mCFC_DN_LIM_OFF_FCA_fl              = (0.12F);                     /* 2^(0)[N/10ms], 0.01 Target pedal reaction force change limit (decreasing side)in case of accelerator OFF, 0.12 */
const FLOAT  mCFC_DN_LIM_SLOW_FCA_fl             = (0.2F);                      /* 2^(0)[N/10ms], 0.01 target pedal reaction force change limit (When MB is cancelled), 0.2 */
const FLOAT  mCFC_UP_LIM_OBJ_SUP_M_FCA_fl        = (0.5F);                      /* 2^(0)[N/10ms], 0.01 recognition certainty factor M target pedal reaction force change limit (increasing side), 0.5 */
const FLOAT  mCFC_UP_MAX_FCA_fl                  = (32.0F);                     /* 2^(0)[-], Target pedal reaction force upper limit value, 32 */
/* ----- 9. FFP_OMG_cont_FCA.c ----- */
/* ----- from - const_FCA_P32RN.c ----- */
const FLOAT  m100pct_FCA_fl                      = (100.0F);                    /* 2^(0)[%], 1, 100 */
/* ----- TBD: Query-2 to NML ----- */
/* 2^(0) [%/s], Accelerator opening speed axis (Note: It should be set to less than 128%/s)  */
const FLOAT mTBL_FFP_OMG_GAIN_X_FCA_fl[7] = {
	-24.0F,	-16.0F,	-8.0F,	0.0F,	4.0F,	16.0F,	24.0F
};
/* 2^(0) [%], Pedal reaction force gain (accelerator opening speed dependant) axis */
const FLOAT mTBL_FFP_OMG_GAIN_Y_FCA_fl[7] = {
	0.0F,	0.0F,	0.0F,	0.0F,	50.0F,	100.0F,	100.0F
};
const FLOAT  mSLPGAIN_FFPOMG_UP_FCA_fl           = (0.0F);                      /* 2^(0)[%/(m/s^2)], Pedal reaction force correction gain (rising), 0 */
const FLOAT  mSLPGAIN_FFPOMG_DN_FCA_fl           = (0.0F);                      /* 2^(0)[%/(m/s^2)], Pedal reaction force correction gain (falling), 0 */
/* 2^(0) [%], Accelerator opening axis */
const FLOAT mTBL_FFP_OMEGA_MAX_X_FCA_fl[11] = {
	0.0F,	10.0F,	20.0F,	30.0F,	40.0F,	50.0F,	60.0F,	70.0F,	80.0F,	90.0F,
	100.0F
};
/* 2^(0) [N], Target pedal reaction force (accelerator opening speed) (before correction) axis */
const FLOAT mTBL_FFP_OMEGA_MAX_Y_FCA_fl[11] = {
	7.0F,	7.0F,	7.0F,	7.0F,	7.0F,	7.0F,	7.0F,	7.0F,	7.0F,	7.0F,
	7.0F
};
const FLOAT  mFFP_OMG_DN_FCA_fl                  = (0.05F);                     /* 2^(0)[N/10ms], Target pedal reaction force (accelerator opening speed) change limit (decreasing side), 0.05 */
/* 2^(0) [-], Certainty factor (Relevant) axis */
const FLOAT mTBL_RECOG_RELE_FCA_fl[2] = {
	0.6F,	0.8F
};
/* ----- 10. FEB_CONT_CLR_JUDGE_main.c ----- */
/* ----- no any const ----- */
/* ----- 11. FEB_ACT_MODE_update.c ----- */
/* ----- from - const_FCA_P32RN.c ----- */
/* ----- . FEB_ACT_update.c ----- */
/* ----- .... from TUNING/const_FUNC_P32RN.c ----- */
const uint8  mSPEC_DCA_fl                        = (1);                         /* 2^(0)[-], DCA function existence ROM SW, 1 */
/* ----- ......from - const_FCA_P32RN.c ----- */
const FLOAT  mACC_1STBRK_CANC_fl                 = (0.0F);                      /* 2^(0)[m/ss], Reserve braking end acceleration, 0 */
const FLOAT  mACC_2NDBRK_CANC_fl                 = (0.0F);                      /* 2^(0)[m/ss], Emergency braking end acceleration, 0 */
/* ----- 13. FCA_BRK_judge.c ----- */
/* ----- from - const_FCA_P32RN.c ----- */
/* ----- 14. FEB_BRK_main.c ----- */
/* ----- no any const ----- */
/* ----- 15. FEB_BUZ_OUT_judge.c ----- */
/* ----- from - const_FCA_P32RN.c ----- */
const FLOAT  mVR_FCA_BUZ_OUT_fl                  = (0.0F);                      /* 2^(0)[m/s], Buzzer output relative speed threshold value, 0 */
const FLOAT  mVSP_FCA_BUZ_OUT_fl                 = (0.0F);                      /* 2^(0)[m/s], Buzzer output vehicle speed threshold value, 0 */
/* 2^(0) [m/ss], Sloping estimation value */
const FLOAT mFCA_DEC_REACT_hosei_X_fl[13] = {
	-2.94F,	-2.45F,	-1.96F,	-1.47F,	-0.98F,	-0.49F,	0.0F,	0.49F,	0.98F,	1.47F,
	1.96F,	2.45F,	2.94F
};
/* 2^(0) [s], Driver response time correction amount */
const FLOAT mFCA_DEV_REACT_hosei_Y_fl[13] = {
	0.0F,	0.0F,	0.0F,	0.0F,	0.0F,	0.0F,	0.0F,	0.0F,	0.0F,	0.0F,
	0.0F,	0.0F,	0.0F
};
const FLOAT  mDRV_REACT_UP_fl                    = (511.999F);                  /* 2^(0)[-], mDRV_REACT_UP_fl, 511.999 */
const FLOAT  mDRV_REACT_DN_fl                    = (0.0F);                      /* 2^(0)[-], mDRV_REACT_DN_fl, 0 */
/* ----- 16. FCA_DIST_TAR_0_update.c ----- */
/* ----- from - const_FCA_P32RN.c ----- */
const FLOAT  mFCA_DEC2_fl                        = (-3.92F);                    /* 2^(0)[m/ss], Reserve braking target deceleration: DEC2, -3.92 */
const FLOAT  mVR_DIST_TAR_SEL1_fl                = (-83.3333333333333F);        /* 2^(0)[m/s], Stop object target reserve braking final vehicle speed=-300[km/h], -83.3333333333333 */
const FLOAT  mVR_DIST_TAR_SEL2_fl                = (-83.3333333333333F);        /* 2^(0)[m/s], Moving object target reserve braking final vehicle speed=-300[km/h], -83.3333333333333 */
/* 2^(0) [m], FCA Emergency braking distance offset TBL */
const FLOAT mFCA_DIST_OFST_BPFS_y_fl[14] = {
	2.0F,	2.0F,	2.0F,	2.0F,	2.0F,	2.0F,	2.0F,	2.0F,	2.0F,	2.0F,
	2.0F,	2.0F,	2.0F,	2.0F
};
/* 2^(0) [m/ss], Sloping estimation value */
const FLOAT mDEC1_SLOPEhosei_X_fl[13] = {
	-2.939941F,	-2.449951F,	-1.959961F,	-1.469971F,	-0.97998F,	-0.48999F,	0.0F,	0.48999F,	0.97998F,	1.469971F,
	1.959961F,	2.449951F,	2.939941F
};
/* 2^(0) [m/ss], Deceleration correction amount */
const FLOAT mDEC1_SLOPEhosei_Y_fl[13] = {
	0.0F,	0.0F,	0.0F,	0.0F,	0.0F,	0.0F,	0.0F,	0.0F,	0.0F,	0.0F,
	0.0F,	0.0F,	0.0F
};
/* ----- 17. FEB_flgset.c ----- */
/* ----- from - const_FCA_P32RN.c ----- */
const FLOAT  mFCA_ON_VSP_fl                      = (1.38888888888889F);         /* 2^(0)[m/s], Fluid pressure command value gradual disconnection vehicle speed condition when lost, 1.38888888888889 */
const FLOAT  mFCA_OFF_VSP_fl                     = (-0.833333333333333F);       /* 2^(0)[m/s], FCA operation end vehicle speed, -0.833333333333333 */
const FLOAT  mFCA_STOPMODE_SPD_fl                = (0.0F);                      /* 2^(0)[m/s], Stop mode transition permission vehicle speed threshold at the time of braking end, 0 */
/* ----- 18. FCA_FULLBRK_judge.c ----- */
/* ----- mFCA_MAX_BRK_VSP_ON_fl ----- */
/* ----- mFCA_MAX_BRK_VSP_OFF_fl ----- */
/* ----- 19. FCA_STATE_update.c ----- */
/* ----- no any const ----- */
/* ----- 20. FEB_torque_down.c ----- */
/* ----- from - const_FCA_P32RN.c ----- */
const FLOAT  mFCA_APO_MAX_fl                     = (127.75F);                   /* 2^(0)[%], Target accelerator opening maximum value, 127.75 */
const FLOAT  mFCA_APO_UPLMT_fl                   = (100.0F);                    /* 2^(0)[%], Requested accelerator opening gradual disconnection threshold value, 100 */
const FLOAT  mFCA_APO_RL_fl                      = (100.0F);                    /* 2^(0)[%/s], Requested accelerator opening change limit, 100 */
/* ----- 21. fca_vVSP_CMD_STPCONTROL_update.c ----- */
/* ----- from - const_FCA_P32RN.c ----- */
const FLOAT  mVSP_READY_FCA_fl                   = (83.3333333333333F);         /* 2^(0)[m/s], Target vehicle speed calculation execution judgment for stop control: vehicle speed condition, 83.3333333333333 */
const FLOAT  mTHW_FCA_fl                         = (0.0F);                      /* 2^(0)[s], Time between vehicle, 0 */
const FLOAT  mT_DLY_FCA_fl                       = (0.132F);                    /* 2^(0)[s], Delay time, 0.132 */
const FLOAT  mTTC1_FCA_fl                        = (-512.0F);                   /* 2^(0)[s], Target vehicle speed calculation execution judgment for stop control: TTC condition 1, -512 */
const FLOAT  mTTC2_FCA_fl                        = (-512.0F);                   /* 2^(0)[s], Target vehicle speed calculation execution judgment for stop control: TTC condition 2, -512 */
const FLOAT  mACC_TARGET1_FCA_fl                 = (-512.0F);                   /* 2^(0)[m/ss], Target vehicle speed calculation execution judgment for stop control: acceleration condition1, -512 */
const FLOAT  mACC_TARGET2_FCA_fl                 = (-512.0F);                   /* 2^(0)[m/ss], Target vehicle speed calculation execution judgment for stop control: Acceleration condition 2, -512 */
const FLOAT  mDIST_MIN_VMIN_FCA_fl               = (250.0F);                    /* 2^(0)[m], Target vehicle speed calculation execution judgment to prevent going near the preceding vehicle at low speed: Condition for distance between two cars, 250 */
const FLOAT  mACC_VMIN_CALC_FCA_fl               = (1.5F);                      /* 2^(0)[m/ss], Target vehicle speed calculation execution judgment to prevent going near the preceding vehicle at low speed: ON condition acceleration, 1.5 */
const FLOAT  mACC_VMIN_CALC_OFF_FCA_fl           = (2.0F);                      /* 2^(0)[m/ss], Target vehicle speed calculation execution judgment to prevent going near the preceding vehicle at low speed: OFF condition acceleration, 2 */
const FLOAT  mACC_VMIN_CALC_OFFSET_FCA_fl        = (1.0F);                      /* 2^(0)[m/s], Target vehicle speed calculation execution judgment to prevent going near the preceding vehicle at low speed: OFF condition vehicle speed offset, 1 */
const FLOAT  mUP_RLIM_ACC_TARGET_FCA_fl          = (0.5F);                      /* 2^(0)[m/sss], Targeted vehicle speed calculation for stop control:  Change ratio limiter (increasing side) of target acceleration, 0.5 */
const FLOAT  mLO_LMT_V_COM_STPCTRL_FCA_fl        = (-55.434402F);               /* 2^(0)[m/s], FCA vehicle speed command value lower limiter value calculation difference (This value is supplemented (added) to vehicle speed and lower limit value is calulated), -55.434402 */
const FLOAT  mLO_LMT_V_COM_CONST_FCA_fl          = (-10.0F);                    /* 2^(0)[m/s], FCAvehicle speed command value lower limit limiter value, -10 */
const FLOAT  mLO_LMT_ACC_TARGET_2NDBRK_fl        = (-6.0F);                     /* 2^(0)[m/ss], Target acceleration lower limit value at the time of emergency braking, -6 */
const FLOAT  mLO_LMT_ACC_TARGET_MAXBRK_fl        = (-11.0F);                    /* 2^(0)[m/ss], Target acceleration lower limit value at the time of emergency braking (Full braking), -11 */
const FLOAT  mDIST_MIN_FCA_1ST_fl                = (-1.0F);                     /* 2^(0)[m], Minimum distance between two cars, -1 */
const FLOAT  mDIST_MIN_FCA_2ND_fl                = (1.0F);                      /* 2^(0)[m], Minimum distance between two cars, 1 */
const FLOAT  mDN_RCLMT_ACC_TARGET_2ND_fl         = (1.24F);                     /* 2^(0)[m/sss], Targeted acceleration change ratio limiter at the time of emergency braking, 1.24 */
const FLOAT  mDN_RCLMT_ACC_TARGET_1ST_fl         = (0.067F);                    /* 2^(0)[m/sss], Targeted acceleration change ratio limiter at the time of reserve braking, 0.067 */
/* ----- ..... from const_4BA0A.c ----- */
const FLOAT  mDIST_ERR_MIN_fl                    = (0.5F);                      /* 2^(0)[-], mDIST_ERR_MIN_fl, 0.5 */
const FLOAT  mACC_TARGET_UP_RL_fl                = (0.01F);                     /* 2^(0)[m/sss], Target vehicle speed calculation to prevent going  near the preceding vehicle at low speed: Change ratio limiter of target acceleration (increasing side), 0.01 */
const FLOAT  mACC_TARGET_DN_RL_fl                = (0.5F);                      /* 2^(0)[m/sss], Target vehicle speed calculation to prevent going near the preceding vehicle at low speed: Change ratio limiter of target acceleration (decreasing side), 0.5 */
const FLOAT  mV_COM_VMIN_UP_fl                   = (2.862F);                    /* 2^(0)[-], Constant to calculate upper limit of stop control targeted speed., 2.862 */
const FLOAT  mV_COM_VMIN_LO_fl                   = (-5.434402F);                /* 2^(0)[-], Constant to calculate lower limit of stop control targeted speed, -5.434402 */
const FLOAT  mVSP_DIFF_fl                        = (0.0F);                      /* 2^(0)[m/s], mVSP_DIFF_fl, 0 */
const FLOAT  mVSP_C_ZERO_DIV_fl                  = (0.01F);                     /* 2^(0)[m/ss], Acceleration difference minimum value (0 % prevention), 0.01 */
const FLOAT  mVSP_T_ACC_TARGET_STOP_fl           = (0.1F);                      /* 2^(0)[m/s], Leading vehicle stop judgment vehicle speed threshold value, 0.1 */
const FLOAT  mVSP_C_ACC_TARGET_STOP_fl           = (0.0F);                      /* 2^(0)[m/s], Vehicle speed threshold value of judgment of stopping the leading vehicle ahead, 0 */
const FLOAT  mDIST_MIN_ST_fl                     = (0.25F);                     /* 2^(0)[m], mDIST_MIN_ST_fl, 0.25 */
const FLOAT  mUP_LMT_ACC_TARGET_fl               = (0.0F);                      /* 2^(0)[m/ss], Upper limit of final targeted acceleration, 0 */
const FLOAT  mVSP_CTRL_ENBL_ACC_TARGET_fl        = (-0.01F);                    /* 2^(0)[m/ss], mVSP_CTRL_ENBL_ACC_TARGET_fl, -0.01 */
const FLOAT  mTsmpl_fl                           = (0.01F);                     /* 2^(0)[-], Delta value of time to calculate integral of stop control targeted speed., 0.01 */
const FLOAT  mUP_LMT_V_COM_STOPCONTROL_fl        = (2.862F);                    /* 2^(0)[m/s], Targeted speed calculation: Targeted upper limit for stop control, 2.862 */
/* ----- 22. FCAControl.c ----- */
/* ----- from - const_FCA_P32RN.c ----- */
const FLOAT  mAPO_ON_ANGL_FCA_fl                 = (1.0F);                      /* 2^(0)[%], Accelerator operation judgment threshold value, 1 */
const FLOAT  mAPO_ON_ANGL_FCA_BRK_fl             = (50.0F);                     /* 2^(0)[-], Accelerator operation judgment(Brake judgment) threshold value, 50 */
const uint16 mCNT_APO_OVR_START_fl               = (200);                       /* 2^(0)[10ms], Accelerator START time, 200 */
/* ----- from - SpecChange.c ----- */
const uint8  mAPO_OVR_FCA_SW                     = (0);                         /* 2^(0)[-], �į��Ӱ�ސؑ֎d�l(N13), 0 */
/* ----- 23. FEB_GOSTP_main.c ----- */
/* ----- from - const_FCA_P32RN.c ----- */
const FLOAT  mVCOMO_LOW_FCA_fl                   = (1.38888888888889F);         /* 2^(0)[m/s], Vehicle speed command value threshold value for stop mode judgment, 1.38888888888889 */
const FLOAT  mL_STOP_MODE_FCA_fl                 = (5.8F);                      /* 2^(0)[m], Stop control judgment between vehicle ( mDIST_MIN+1m)(5.5 MB control spec. -F26), 5.8 */
const FLOAT  mVSP_STOP_HI_FCA_fl                 = (5.56F);                     /* 2^(0)[m/s], Vehicle speed threshold value for stop mode judgment (HI), 5.56 */
const FLOAT  mPRECEDING_STP_VSP_FCA_fl           = (0.77222F);                  /* 2^(0)[m/s], Stop judgment leading vehicle speed threshold value, 0.77222 */
const FLOAT  mVR_STOP_FCA_fl                     = (2.78F);                     /* 2^(0)[m/s], Relative speed threshold value for stop mode judgment, 2.78 */
const FLOAT  mVSP_STOP_LOW_FCA_fl                = (0.833333333333333F);        /* 2^(0)[m/s], Vehicle speed threshold value for stop mode judgment, 0.833333333333333 */
const uint16 mVSP_STOP_TIME_FCA_fl               = (10);                        /* 2^(0)[10ms], Vehicle speed condition continuous time for stop mode judgment, 10 */
/* ----- from - const_MB_4BA0A.c ----- */
const FLOAT  mGOSTP_PRMT_ACCSUB2_05MS_MB_fl      = (0.5F);                      /* 2^(0)[m/ss], Stop control permited slope, 0.5 */
/* 2^(0) [m/s], Vehicle speed  axis */
const FLOAT mDIST_STOP_MB_X_fl[6] = {
	0.0F,	0.5F,	1.0F,	1.38888888888889F,	2.77777777777778F,	5.55555555555556F
};
/* 2^(0) [m/s], Relative velocity */
const FLOAT mDIST_STOP_MB_Y_fl[6] = {
	0.1F,	0.0F,	-0.555555555555556F,	-1.38888888888889F,	-2.77777777777778F,	-4.16666666666667F
};
/* 2^(0) [m], Threshold value distance between vehicles for stop mode */
const FLOAT mDIST_STOP_MB_Z_fl[36] = {
	3.7F,	3.7F,	3.7F,	3.7F,	3.7F,	3.7F,	3.7F,	3.7F,	3.7F,	3.9F,
	3.9F,	3.9F,	3.7F,	3.7F,	3.7F,	3.9F,	3.9F,	3.9F,	3.7F,	3.7F,
	3.7F,	3.9F,	4.2F,	4.2F,	3.7F,	3.7F,	3.7F,	3.9F,	4.2F,	4.5F,
	3.7F,	3.7F,	3.7F,	3.9F,	4.2F,	4.5F
};
/* ----- from - const_4BA0A.c ----- */
const uint16 mSTOP_TIME_fl                       = (200);                       /* 2^(0)[10ms], Stop control time threshold value of ACC, 200 */
const FLOAT  mVSP_EST_LMT_fl                     = (0.15F);                     /* 2^(0)[m/s], Vehicle speed measurement starting speed, 0.15 */
const FLOAT  mGOSTP_PRMT_001KMH_fl               = (0.1F);                      /* 2^(0)[m/s], Stop mode shifting permited vehicle speed threshold value, 0.1 */
/* ----- from - ACC/cont/cont_constant.c ----- */
const uint16 mGOSTP_PRMT_01SEC_fl                = (10);                        /* 0.01[s], 0.1sec, 0.1 */
/* ----- 24. FEB_VSERVO_main.c ----- */
/* ----- from - const_FCA_P32RN.c ----- */
const FLOAT  mWHLINIT_CLRWHL_FCA_fl              = (0.142853F);                 /* 2^(0)[-], Vehicle speed command value additional value calculation constant (Constant in case of VSPMDL) at the time of vehicle speed servo leading vehicle interchange , 0.142853 */
const FLOAT  mACOMROB_INIT_MAXFCA_fl             = (1.42857146263123F);         /* 2^(0)[m/s], At the time of emergency braking, vehicle speed servo FF filter initialization value (in case of full braking), 1.42857146263123 */
const FLOAT  mACOMROB_INIT_2NDFCA_fl             = (0.857143F);                 /* 2^(0)[m/s], At the time of emergency braking, vehicle speed servo FF filter initialization value (in case of emergency braking), 0.857143 */
/* 2^(0) [m/ss], ACCMDL_MIN map value */
const FLOAT mACCMDL_MIN_MAP_FCA_fl[5] = {
	-4.0F,	-4.0F,	-3.0F,	-3.0F,	-3.0F
};
/* 2^(0) [m/s], Vehicle speed axis for ACCMDL_MIN map drawing */
const FLOAT mACCMDL_MIN_VSP_FCA_fl[5] = {
	0.0F,	5.0F,	20.0F,	21.0F,	22.0F
};
/* ----- 25. FEB_VSP_CMD_DIST_main.c ----- */
/* ----- no any const ----- */
/* ----- 26. VSP_CMD_FCA_main.c ----- */
/* ----- no any const ----- */
/* ----- 27. FEB_VSP_update.c ----- */
/* ----- no any const ----- */
/* ----- FCA_DataIn.c ----- */
/* ----- const_4BA0A.c ----- */
const FLOAT  mTTC_STOP_CONTROL_fl                = (20.0F);                     /* 2^(0)[s], TTC upper value, 20 */
const uint16 mCNT_APO_INC_EXC                    = (50);                        /* 0.01[s], ���ٓ��ݍ��ݔ��f�p������, 0.5 */
const uint16 mCNT_APO_INC                        = (300);                       /* 0.01[s], ���ٓ��ݍ��ݔ��f�p������, 3 */
const sint32 mACC_OFF_RECO_EXC                   = (-65536);                    /* 2^-16[%/s], ���يJ�x���x臒l, -1 */
const sint32 mACC_OFF_RECO1_EXC                  = (-3276800);                  /* 2^-16[%/s], ���يJ�x���x臒l1, -50 */
const sint16 mACC_OVR_RECO_EXC                   = (2560);                      /* 2^-8[%], ���ٓ��ݑ������f臒l(�m�M�x�ύX�p), 10 */
const uint16 mCNT_ACCOVR_RECO_EXC_MAX            = (500);                       /* 0.01[s], ����ON���ԍő�l, 5 */
const uint16 mCNT_APO_OVR_RECO_EXC               = (300);                       /* 0.01[s], ���ٓ��ݑ������f�p������, 3 */
const uint16 mCNT_VR_OVR_EXC                     = (100);                       /* 0.01[s], ���ً}���ݍ��݉������莞��, 1 */
const uint16 mCNT_ON_EXC                         = (1000);                      /* 0.01[s], ���ً}���ݍ��݌p�����莞��, 10 */
const uint16 mCNT_FFP_OVR_OFF                    = (200);                       /* 0.01[s], ���ً}���ݍ��ݱ���OFF���莞��, 2 */
const sint32 mVR_FFP_OVR_EXC                     = (-65536);                    /* 2^-16[m/s], ���ً}���ݍ��݉������Α�臒l, -1 */
const sint32 mDIST_FFP_OVR_EXC                   = (5242880);                   /* 2^-16[m], ���ً}���ݍ��ݔ��苗��臒l, 80 */
const sint16 mAPO_OVR_HIGH                       = (12800);                     /* 2^-8[%], ���ً}���ݍ��ݔ���臒l, 50 */
const sint32 mR_LC_JDG                           = (163840);                    /* 2^-12[m], ���ړ����fR臒l, 40 */
const uint16 mLC_CNT_TSIG_TH                     = (3);                         /* 2^(0)[-], ���ړ����f�p����臒l, 3 */
const uint16 mLC_CNT_TH                          = (3);                         /* 2^(0)[-], ���ړ����f�p����臒l, 3 */
const sint32 mLC_TRJ_OFST_TSIG_TH                = (32375);                     /* 2^-16[-], ���ړ����f�pTRJ臒l, 0.494 */
const sint32 mLC_TRJ_OFST_TH                     = (32375);                     /* 2^-16[-], ���ړ����f�pTRJ臒l, 0.494 */
const sint32 mLC_LAT_TSIG_TH                     = (25172);                     /* 2^-16[m], ���ړ����f�p���ʒu臒l, 0.3841 */
const sint32 mLC_LAT_TH                          = (28767);                     /* 2^-16[m], ���ړ����f�p���ʒu臒l, 0.43895 */
const sint32 mLC_TRJ_OFST_CNT_TSIG_TH            = (10813);                     /* 2^-16[-], ���ړ����f�pTRJ���ċ���臒l, 0.165 */
const sint32 mLC_TRJ_OFST_CNT_TH                 = (14384);                     /* 2^-16[-], ���ړ����f�pTRJ���ċ���臒l, 0.21948 */
const sint32 mLC_TRJ_OFST_CNT_RST_TSIG_TH        = (28836);                     /* 2^-16[-], ���ړ����f�pTRJ���ċ֎~臒l, 0.44 */
const sint32 mLC_TRJ_OFST_CNT_RST_TH             = (39555);                     /* 2^-16[-], ���ړ����f�pTRJ���ċ֎~臒l, 0.60356 */
const sint32 mLC_DIST_TSIG_TH                    = (2621440);                   /* 2^-16[m], ���ړ����f�p��������臒l, 40 */
const sint32 mLC_DIST_TH                         = (1966080);                   /* 2^-16[m], ���ړ����f�p��������臒l, 30 */
const uint16 mCNT_LC_JDG                         = (500);                       /* 0.01[s], ���ړ����fON����, 5 */
const sint32 mVSP_TH_DECOMP_PRS                  = (91022);                     /* 2^-16[m/s], �u���[�L���X�������x�ύX, 1.38888549804688 */
/* ----- 28. �t�F�[���Z�[�t�f�f�萔 ----- */
/* -----  ----- */
/* ----- �`���[�j���O�萔 ----- */
const sint32 mLOST_DEC_CHANGE_50KMPH             = (910222);                    /* 2^-16[m/s], 50 [km/h]����, 13.8888888888889 */
/* X:2^-8 [m/s], Y:2^-6 [m], Z:2^-16 [MPa/10ms], mFEB_P_UPLIM_Map */
/* X:    0 0.5 1.38888888888889 2.77777777777778 4.16666666666667 5.55555555555556 */
/* Y:    0 1.9 2 3 3.7 4.5 */
/* Z:    0.006 0.01 0.014 0.014 0.014 0.014 */
/*       0.006 0.01 0.014 0.014 0.014 0.014 */
/*       0.006 0.01 0.014 0.014 0.014 0.014 */
/*       0.006 0.01 0.014 0.014 0.014 0.014 */
/*       0.004 0.0045 0.006 0.008 0.01 0.012 */
/*       0.0045 0.0045 0.006 0.006 0.008 0.01 */
static const sint32 mFEB_P_UPLIM_Map_x[6] = {0, 128, 356, 711, 1067, 1422};
static const sint32 mFEB_P_UPLIM_Map_y[6] = {0, 122, 128, 192, 237, 288};
static const sint32 mFEB_P_UPLIM_Map_z[6][6] = {
    {393, 655, 918, 918, 918, 918},
    {393, 655, 918, 918, 918, 918},
    {393, 655, 918, 918, 918, 918},
    {393, 655, 918, 918, 918, 918},
    {262, 295, 393, 524, 655, 786},
    {295, 295, 393, 393, 524, 655}
};
const T_3D_MAP mFEB_P_UPLIM_Map = {6, &mFEB_P_UPLIM_Map_x[0], 6, &mFEB_P_UPLIM_Map_y[0], &mFEB_P_UPLIM_Map_z[0][0]};
/* X:2^-8 [m/s], Y:2^-13 [PMa/10ms], mDECOMP_PRESS_TBL_MAP_DR */
static const T_2D_MAP_BODY mDECOMP_PRESS_TBL_MAP_DR_b[9] = {
    {0, 123},                                    /* X:0, Y:0.015 */
    {71, 123},                                   /* X:0.277777777777778, Y:0.015 */
    {213, 123},                                  /* X:0.833333333333333, Y:0.015 */
    {356, 123},                                  /* X:1.38888888888889, Y:0.015 */
    {498, 123},                                  /* X:1.94444444444444, Y:0.015 */
    {711, 123},                                  /* X:2.77777777777778, Y:0.015 */
    {2844, 123},                                 /* X:11.1111111111111, Y:0.015 */
    {4978, 123},                                 /* X:19.4444444444444, Y:0.015 */
    {7111, 123}                                  /* X:27.7777777777778, Y:0.015 */
};
const T_2D_MAP mDECOMP_PRESS_TBL_MAP_DR = {9, &mDECOMP_PRESS_TBL_MAP_DR_b[0]};
/* X:2^-8 [m/s], Y:2^-13 [PMa/10ms], mTBL_DECOMP_PRS_MB */
static const T_2D_MAP_BODY mTBL_DECOMP_PRS_MB_b[10] = {
    {0, 1966},                                   /* X:0, Y:0.24 */
    {2048, 1966},                                /* X:8, Y:0.24 */
    {4096, 1966},                                /* X:16, Y:0.24 */
    {6144, 1966},                                /* X:24, Y:0.24 */
    {8192, 1966},                                /* X:32, Y:0.24 */
    {10240, 1966},                               /* X:40, Y:0.24 */
    {12288, 1966},                               /* X:48, Y:0.24 */
    {14336, 1966},                               /* X:56, Y:0.24 */
    {16384, 1966},                               /* X:64, Y:0.24 */
    {18432, 1966}                                /* X:72, Y:0.24 */
};
const T_2D_MAP mTBL_DECOMP_PRS_MB = {10, &mTBL_DECOMP_PRS_MB_b[0]};
/* X:2^-8 [m/s], Y:2^-13 [PMa/10ms], �u���[�L�I�[�o�[���C�h���ɍč쓮�֎~��500ms�}�X�N�ɓ���ɂ������� */
static const T_2D_MAP_BODY mTBL_DECOMP_PRS_MB_JOJO_b[10] = {
    {0, 163},                                    /* X:0, Y:0.0198974609375 */
    {2048, 163},                                 /* X:8, Y:0.0198974609375 */
    {4096, 328},                                 /* X:16, Y:0.0400390625 */
    {6144, 492},                                 /* X:24, Y:0.06005859375 */
    {8192, 655},                                 /* X:32, Y:0.0799560546875 */
    {10240, 819},                                /* X:40, Y:0.0999755859375 */
    {12288, 983},                                /* X:48, Y:0.1199951171875 */
    {14336, 1147},                               /* X:56, Y:0.1400146484375 */
    {16384, 1310},                               /* X:64, Y:0.159912109375 */
    {18432, 1310}                                /* X:72, Y:0.159912109375 */
};
const T_2D_MAP mTBL_DECOMP_PRS_MB_JOJO = {10, &mTBL_DECOMP_PRS_MB_JOJO_b[0]};
/* X:2^-8 [m/s], Y:2^-12 [m/s^2], X:LSB:2^-8 ���ԑ���,Y:LSB:2^-12 ���s��R�� */
static const T_2D_MAP_BODY mTBL_S_TEIKOU_b[16] = {
    {0, 161},                                    /* X:0, Y:0.039306640625 */
    {1024, 187},                                 /* X:4, Y:0.045654296875 */
    {2048, 265},                                 /* X:8, Y:0.064697265625 */
    {3072, 395},                                 /* X:12, Y:0.096435546875 */
    {4096, 573},                                 /* X:16, Y:0.139892578125 */
    {5120, 846},                                 /* X:20, Y:0.20654296875 */
    {6144, 1163},                                /* X:24, Y:0.283935546875 */
    {7168, 1523},                                /* X:28, Y:0.371826171875 */
    {8192, 1923},                                /* X:32, Y:0.469482421875 */
    {9216, 2363},                                /* X:36, Y:0.576904296875 */
    {10240, 2840},                               /* X:40, Y:0.693359375 */
    {11264, 3355},                               /* X:44, Y:0.819091796875 */
    {12288, 3906},                               /* X:48, Y:0.95361328125 */
    {13312, 4492},                               /* X:52, Y:1.0966796875 */
    {14336, 5113},                               /* X:56, Y:1.248291015625 */
    {15360, 5769}                                /* X:60, Y:1.408447265625 */
};
const T_2D_MAP mTBL_S_TEIKOU = {16, &mTBL_S_TEIKOU_b[0]};
/* X:0.05 [deg/s], Y:2^-12 [MPa], const_FCA_P32RN.c */
static const T_2D_MAP_BODY mFCA_1STBRK_YAW_LMT_b[15] = {
    {0, 32767},                                  /* X:0, Y:7.99975 */
    {20, 32767},                                 /* X:1, Y:7.99975 */
    {40, 32767},                                 /* X:2, Y:7.99975 */
    {60, 32767},                                 /* X:3, Y:7.99975 */
    {80, 32767},                                 /* X:4, Y:7.99975 */
    {100, 32767},                                /* X:5, Y:7.99975 */
    {120, 32767},                                /* X:6, Y:7.99975 */
    {140, 32767},                                /* X:7, Y:7.99975 */
    {160, 32767},                                /* X:8, Y:7.99975 */
    {180, 32767},                                /* X:9, Y:7.99975 */
    {200, 32767},                                /* X:10, Y:7.99975 */
    {220, 32767},                                /* X:11, Y:7.99975 */
    {240, 32767},                                /* X:12, Y:7.99975 */
    {260, 32767},                                /* X:13, Y:7.99975 */
    {280, 32767}                                 /* X:14, Y:7.99975 */
};
const T_2D_MAP mFCA_1STBRK_YAW_LMT = {15, &mFCA_1STBRK_YAW_LMT_b[0]};
const sint32 mBRAKE_PRESSURE_CMD_STOPMIN         = (3355443);                   /* 2^-22[MPa], �Œ�t�������l const_4BA0A.c , 0.8 */
const uint16 mDRV_BRK_PRS_ON_FEB                 = (400);                       /* 0.05[bar], ��ײ����ڰ��t����ݾ�臒l, 20 */
/* ----- ��`���[�j���O�萔 ----- */
const sint32 mFEB_LOST_DECOMP_H                  = (838861);                    /* 2^-22[MPa/10ms], 20[MPa/s]���� , 0.2 */
const sint32 mFEB_LOST_DECOMP_L                  = (83886);                     /* 2^-22[MPa/10ms], 2[MPa/s]���� , 0.02 */
const sint32 mFEB_ONCEACC_DECOMP                 = (83886);                     /* 2^-22[MPa/10ms], 2[MPa/s]���� , 0.02 */
const sint32 mFEB_ONCEACC_DECOMP2                = (209715);                    /* 2^-22[MPa/10ms], 5[MPa/s]���� , 0.05 */
const sint32 mFEB_BRAKE_PRESSURE_CMD_MAX         = (12582912);                  /* 2^-22[MPa], 3[MPa] , 3 */
const sint32 mFEB_BRAKE_PRESSURE_CMD_MIN         = (0);                         /* 2^-22[MPa], 0[MPa] , 0 */
const sint32 mFEB_BRAKE_PRESSURE_CMD_GO          = (2097152);                   /* 2^-22[MPa], 0.5[MPa] , 0.5 */
const sint32 mFEB_BRAKE_PRESSURE_DOWN            = (100663);                    /* 2^-22[MPa/10ms], 2.4[MPa/s]���� , 0.024 */
/* 2^(0) [-], mFCA_MARGIN_MAP_YOKO_y_fl */
const FLOAT mFCA_MARGIN_MAP_YOKO_y_fl[14] = {
	0.0F,	1.5F,	1.5F,	1.5F,	1.5F,	1.5F,	1.5F,	0.799988F,	0.799988F,	0.799988F,
	0.799988F,	0.799988F,	0.799988F,	0.799988F
};
/* 2^(0) [-], mFCA_MARGIN_MAP_YOKO_MOVE_y_fl */
const FLOAT mFCA_MARGIN_MAP_YOKO_MOVE_y_fl[14] = {
	0.0F,	0.799988F,	0.900024F,	1.0F,	1.0F,	1.0F,	0.900024F,	0.799988F,	0.799988F,	0.799988F,
	0.799988F,	0.799988F,	0.799988F,	0.799988F
};
/* 2^(0) [-], mFCA_TTC_STR_YOKO2_y_fl */
const FLOAT mFCA_TTC_STR_YOKO2_y_fl[11] = {
	0.630005F,	0.630005F,	0.630005F,	0.630005F,	0.630005F,	0.630005F,	0.630005F,	0.630005F,	0.630005F,	0.630005F,
	0.630005F
};
/* 2^(0) [-], mFCA_TTC_STR_YOKO_x_fl */
const FLOAT mFCA_TTC_STR_YOKO_x_fl[11] = {
	0.0F,	0.199951F,	0.399902F,	0.600098F,	0.800049F,	1.0F,	1.199951F,	1.399902F,	1.600098F,	1.800049F,
	2.0F
};
/* 2^(0) [-], mFCA_DIST_OFST_BPFS_YOKO_y_fl */
const FLOAT mFCA_DIST_OFST_BPFS_YOKO_y_fl[14] = {
	0.650024F,	0.650024F,	0.599976F,	0.549988F,	0.5F,	0.450012F,	0.400024F,	0.349976F,	0.299988F,	0.299988F,
	0.299988F,	0.299988F,	0.299988F,	0.299988F
};
/* 2^(0) [-], mFCA_TTC_STR_YOKO1_y_fl */
const FLOAT mFCA_TTC_STR_YOKO1_y_fl[11] = {
	0.630005F,	0.630005F,	0.630005F,	0.630005F,	0.630005F,	0.630005F,	0.630005F,	0.630005F,	0.630005F,	0.630005F,
	0.630005F
};
/* 2^(0) [-], mFCA_TTC_STR_YOKO_MOVE_x_fl */
const FLOAT mFCA_TTC_STR_YOKO_MOVE_x_fl[11] = {
	0.0F,	0.199951F,	0.399902F,	0.600098F,	0.800049F,	1.0F,	1.199951F,	1.399902F,	1.600098F,	1.800049F,
	2.0F
};
/* 2^(0) [-], mFCA_DIST_OFST_BPFS_YOKO_MOVE */
const FLOAT mFCA_DIST_OFST_BPFS_YOKO_MOVE_y_fl[14] = {
	0.650024F,	0.650024F,	0.599976F,	0.549988F,	0.5F,	0.450012F,	0.400024F,	0.349976F,	0.299988F,	0.299988F,
	0.299988F,	0.299988F,	0.299988F,	0.299988F
};
/* 2^(0) [-], mFCA_TTC_STR_YOKO_MOVE2_y_fl */
const FLOAT mFCA_TTC_STR_YOKO_MOVE2_y_fl[11] = {
	0.630005F,	0.630005F,	0.630005F,	0.630005F,	0.630005F,	0.630005F,	0.630005F,	0.630005F,	0.630005F,	0.630005F,
	0.630005F
};
/* 2^(0) [-], mFCA_TTC_STR_YOKO_MOVE1_y_fl */
const FLOAT mFCA_TTC_STR_YOKO_MOVE1_y_fl[11] = {
	0.630005F,	0.630005F,	0.630005F,	0.630005F,	0.630005F,	0.630005F,	0.630005F,	0.630005F,	0.630005F,	0.630005F,
	0.630005F
};
const FLOAT  mVSP_FCA_PRE_BRK_FOR_MOVE_fl        = (9.722229F);                 /* 2^(0)[m/s], mVSP_FCA_PRE_BRK_FOR_MOVE_fl, 9.722229 */
/* 2^(0) [s], mFCA_DEV_REACT_MOVE_hosei_Y_fl */
const FLOAT mFCA_DEV_REACT_MOVE_hosei_Y_fl[13] = {
	0.0F,	0.0F,	0.0F,	0.0F,	0.0F,	0.0F,	0.0F,	0.0F,	0.0F,	0.0F,
	0.0F,	0.0F,	0.0F
};
/* X:2^-8 [m/s], Y:2^-12 [MPa], mFCA_1STBRK_VSP_LMT */
static const T_2D_MAP_BODY mFCA_1STBRK_VSP_LMT_b[15] = {
    {0, 24576},                                  /* X:0, Y:6 */
    {356, 24576},                                /* X:1.38888888888889, Y:6 */
    {711, 24576},                                /* X:2.77777777777778, Y:6 */
    {1067, 24576},                               /* X:4.16666666666667, Y:6 */
    {1422, 24576},                               /* X:5.55555555555556, Y:6 */
    {1778, 24576},                               /* X:6.94444444444444, Y:6 */
    {2133, 24576},                               /* X:8.33333333333333, Y:6 */
    {2489, 24576},                               /* X:9.72222222222222, Y:6 */
    {2844, 24576},                               /* X:11.1111111111111, Y:6 */
    {3200, 24576},                               /* X:12.5, Y:6 */
    {3556, 24576},                               /* X:13.8888888888889, Y:6 */
    {3911, 24576},                               /* X:15.2777777777778, Y:6 */
    {4267, 24576},                               /* X:16.6666666666667, Y:6 */
    {4622, 24576},                               /* X:18.0555555555556, Y:6 */
    {4978, 24576}                                /* X:19.4444444444444, Y:6 */
};
const T_2D_MAP mFCA_1STBRK_VSP_LMT = {15, &mFCA_1STBRK_VSP_LMT_b[0]};
/* X:2^-8 [m/s], Y:2^-12 [MPa], �ړ����p�̗\�����������~�b�g 0.6G�ً}�����ƂȂ邱�Ƃ�z�肵�ė\���͂����C���ɂ��Ă����B */
static const T_2D_MAP_BODY mFCA_1STBRK_VSP_LMT_MOVE_b[15] = {
    {0, 24576},                                  /* X:0, Y:6 */
    {356, 24576},                                /* X:1.38888888888889, Y:6 */
    {711, 24576},                                /* X:2.77777777777778, Y:6 */
    {1067, 24576},                               /* X:4.16666666666667, Y:6 */
    {1422, 24576},                               /* X:5.55555555555556, Y:6 */
    {1778, 24576},                               /* X:6.94444444444444, Y:6 */
    {2133, 24576},                               /* X:8.33333333333333, Y:6 */
    {2489, 24576},                               /* X:9.72222222222222, Y:6 */
    {2844, 24576},                               /* X:11.1111111111111, Y:6 */
    {3200, 24576},                               /* X:12.5, Y:6 */
    {3556, 24576},                               /* X:13.8888888888889, Y:6 */
    {3911, 24576},                               /* X:15.2777777777778, Y:6 */
    {4267, 24576},                               /* X:16.6666666666667, Y:6 */
    {4622, 24576},                               /* X:18.0555555555556, Y:6 */
    {4978, 24576}                                /* X:19.4444444444444, Y:6 */
};
const T_2D_MAP mFCA_1STBRK_VSP_LMT_MOVE = {15, &mFCA_1STBRK_VSP_LMT_MOVE_b[0]};
/* 2^-8 [%], ���ٓ��ݑ������f���يJ�x臒l�� */
const sint16 mTBL_APO_OVR_Y[2] = {
	256,	256
};
/* 2^-8 [-], ���ٓ��ݍ��ݗʈˑ�����ٔ��͕␳ϯ�� */
const sint16 mAPO_ANGL_INC_GAIN[10] = {
	256,	256,	230,	205,	179,	179,	179,	179,	179,	179
};
/* 2^(0) [-], �x��ON���Զ����� */
const sint16 mCNT_FFP_DCA_BUZ_TIME[10] = {
	0,	50,	60,	80,	100,	120,	140,	250,	300,	400
};
const uint8  mFEB_FFP_OPTION                     = (0);                         /* 2^(0)[-], mFEB_FFP_OPTION, 0 */
const sint32 mFCA_VSP_TH_APOOVR                  = (40777956);                  /* 2^(0)[-], mFCA_VSP_TH_APOOVR, 40777956 */
/* ----- ADAS5_FULLBRK ----- */
const uint16 mJDG_MAX_BRK_TH_STR_OFF_ON_TIME     = (20);                        /* 2^(0)[-], LSB:10 �t�����������ǔ���OFF�EON�A�Ǝ���[msec]�ˏƍ��񐔂ɕϊ�, 20 */
const uint16 mJDG_MAX_BRK_TH_STR_ON_OFF_TIME     = (20);                        /* 2^(0)[-], LSB:10 �t�����������ǔ���ON�EOFF�A�Ǝ���[msec]�ˏƍ��񐔂ɕϊ�, 20 */
const uint16 mJDG_MAX_BRK_TH_YAW_OFF_ON_TIME     = (20);                        /* 2^(0)[-], LSB:10 �t�����������[���[�g����OFF�EON�A�Ǝ���[msec]�ˏƍ��񐔂ɕϊ�, 20 */
const uint16 mJDG_MAX_BRK_TH_YAW_ON_OFF_TIME     = (20);                        /* 2^(0)[-], LSB:10 �t�����������[���[�g����ON�EOFF�A�Ǝ���[msec]�ˏƍ��񐔂ɕϊ�, 20 */
const sint32 mFCA_MAX_BRK_VSP_ON_LO              = (659001);                    /* 2^(0)[m/s], LSB:2^-16 �t����������ON���f�ԑ�(�ᑬ), 659001 */
const sint32 mFCA_MAX_BRK_VSP_OFF_LO             = (677205);                    /* 2^(0)[m/s], LSB:2^-16 �t����������OFF���f�ԑ�(�ᑬ), 677205 */
/* 2^(0) [deg/s], LSB:2^-8 �t�������ԑ�����臒l�}�b�v �ԑ��� */
const sint16 mMAX_BRK_TH_STR_MAP_x[16] = {
	0,	1422,	2133,	2844,	3556,	4267,	5689,	7111,	8533,	8533,
	8533,	8533,	8533,	8533,	8533,	8533
};
/* 2^(0) [deg], LSB:2^-8 �t�������ԑ�����臒l�}�b�v ���Ǌp�� */
const sint16 mMAX_BRK_TH_STR_MAP_y[16] = {
	10240,	10240,	10240,	10240,	10240,	7890,	5649,	4577,	3905,	3905,
	3905,	3905,	3905,	3905,	3905,	3905
};
/* 2^(0) [m/s], LSB:2^-8 �t�������ԑ�����臒l�}�b�v �ԑ��� */
const sint16 mMAX_BRK_TH_YAW_MAP_x[16] = {
	0,	1422,	2133,	2844,	3556,	4267,	5689,	7111,	8533,	8533,
	8533,	8533,	8533,	8533,	8533,	8533
};
/* 2^(0) [deg/s], LSB:2^-12 �t�������ԑ�����臒l�}�b�v ���Ǌp�� */
const sint16 mMAX_BRK_TH_YAW_MAP_y[16] = {
	32767,	32767,	32767,	32767,	32767,	26076,	18626,	14172,	11018,	11018,
	11018,	11018,	11018,	11018,	11018,	11018
};
/* ----- JAA(Junction Assist Aeb) ----- */
/* ----- MODE�Ⴂ�ł̉񐶃R�[�X�g�g���N�ʂ��l�����郍�W�b�N ----- */
/* 2^(0) [Mpa], LSB:2^-12 �\�������p�ڕW�t���␳�l */
const sint16 mFCA_TARGET_PBRK_COAST_MAX_COMP[21] = {
	0,	0,	0,	0,	0,	0,	0,	0,	0,	0,
	0,	0,	0,	0,	0,	0,	0,	0,	0,	0,
	0
};
/* 2^(0) [Mpa], LSB:2^-12 �\�������p�ڕW�t���␳�l */
const sint16 mFCA_TARGET_PBRK_COAST_MAX_ePdP[21] = {
	0,	0,	0,	0,	0,	0,	0,	0,	0,	0,
	0,	0,	0,	0,	0,	0,	0,	0,	0,	0,
	0
};
/* 2^(0) [Mpa], LSB:2^-12 �\�������p�ڕW�t���␳�l */
const sint16 mFCA_TARGET_PBRK_COAST_2ND_ePdP[21] = {
	0,	0,	0,	0,	0,	0,	0,	0,	0,	0,
	0,	0,	0,	0,	0,	0,	0,	0,	0,	0,
	0
};
/* 2^(0) [Mpa], LSB:2^-12 �ِ����p�ڕW�t���␳�l */
const sint16 mFCA_TARGET_PBRK_COAST_1ST_ePdP[21] = {
	0,	0,	0,	0,	0,	0,	0,	0,	0,	0,
	0,	0,	0,	0,	0,	0,	0,	0,	0,	0,
	0
};
/* 2^(0) [Mpa], LSB:2^-12 �\�������p�ڕW�t���␳�l */
const sint16 mFCA_TARGET_PBRK_COAST_MAX_ePdC[21] = {
	0,	0,	0,	0,	0,	0,	0,	0,	0,	0,
	0,	0,	0,	0,	0,	0,	0,	0,	0,	0,
	0
};
/* 2^(0) [Mpa], LSB:2^-12 �\�������p�ڕW�t���␳�l */
const sint16 mFCA_TARGET_PBRK_COAST_2ND_ePdC[21] = {
	0,	0,	0,	0,	0,	0,	0,	0,	0,	0,
	0,	0,	0,	0,	0,	0,	0,	0,	0,	0,
	0
};
/* 2^(0) [Mpa], LSB:2^-12 �ِ����p�ڕW�t���␳�l */
const sint16 mFCA_TARGET_PBRK_COAST_1ST_ePdC[21] = {
	0,	0,	0,	0,	0,	0,	0,	0,	0,	0,
	0,	0,	0,	0,	0,	0,	0,	0,	0,	0,
	0
};
const uint16 mSTOP_TIME_TIMEOUT_fl               = (400);                       /* 2^(0)[10ms], CS�ǉ��p�V�K�萔�ǉ�, 400 */
