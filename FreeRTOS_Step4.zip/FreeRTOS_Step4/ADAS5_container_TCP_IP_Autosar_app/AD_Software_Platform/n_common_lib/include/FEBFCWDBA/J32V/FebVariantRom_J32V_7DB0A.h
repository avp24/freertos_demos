/****************************************************************************** */
/*                                                                              */
/*     Copyright (c) 2013 Nissan, Japan                                         */
/*                                                                              */
/* **************************************************************************** */
/*                                                                              */
/* Project:     J32V FEB Const                                                  */
/* Module:                                                                      */
/* Version      10.3.0_B                                                        */
/* Author:                                                                      */
/* Making of:   ADAS5_FEB_ConstInformation.xlsm                                 */
/* MACRO Var:   1.20                                                            */
/* Description:                                                                 */
/* Revision History:                                                            */
/*                                                                              */
/********************************************************************************/
#ifndef __FEB_VARIANT_ROM_J32V_7DB0A_H__
#define __FEB_VARIANT_ROM_J32V_7DB0A_H__


/* ------------------------------------------------ */
/*  �ϐ��E�\���̐錾                                */
/* ------------------------------------------------ */
typedef struct{
    sint32 mmWIDTH_OBJ0_MIN;                          /* 2^-16[m],��s�Ԏԗ����Œ�l    */
    uint16 mmTSIG_ON_DLY_TIME;                        /*  0.01 [s],��ݶ�ON�x������    */
    const sint16 * mmTBL_RECOG_RELE;                  /* [],�m�M�x(Relevant)��    */
    sint32 mmAPO_OFF_RECO;                            /* 2^-16[%/s],���يJ�x���x臒l    */
    sint32 mmAPO_OFF_RECO1;                           /* 2^-16[%/s],���يJ�x���x臒l1    */
    uint16 mmCNT_FFP_ON_MAX;                          /* [10ms],����ON���ԍő�l    */
    uint16 mmCNT_APO_OVR_RECO;                        /* [10ms],���ٓ��ݑ������f�p������    */
    sint16 mmAPO_OVR_RECO;                            /* 2^-8[%],���ٓ��ݑ������f臒l(�m�M�x�ύX�p)    */
    sint32 mm1_5hzBPF0;                               /* 2^-16[],1.5Hz BPF�p�萔(���يJ�x���x�p)    */
    sint32 mm1_5hzBPF1;                               /* 2^-16[],1.5Hz BPF�p�萔(���يJ�x���x�p)    */
    sint32 mm1_5hzBPF2;                               /* 2^-16[],1.5Hz BPF�p�萔(���يJ�x���x�p)    */
    sint16 mmINV_GAIN_ENGINE_MB;                      /* 2^-8[],�ݼ�ݹ޲݋t��    */
    const sint16 * mmAPO_ANGL_INC_LATCH;              /* [],���ٓ��ݑ����ʎ�    */
    const sint16 * mmFFP_BUZ_TIME;                    /* [],�x��ON���Ԉˑ�����ٔ��͕␳�޲�ϯ��    */
    sint16 mmAPO_ANGL_DECOMP_FCA;                     /* 2^-8[%],���َ����X�������f���يJ�x臒l    */
    sint32 mmFCA_ARMYU;                               /* 2^-22[MPa/Nm],��ڰ������萔    */
    sint32 mmBP_UP_FCA_1ST;                           /* 2^-22[MPa/10ms],�\�������u���[�L�t���ω����Я�    */
    sint32 mmBP_UP_FCA_1ST_CROSS;                     /* 2^-22[Mpa/10ms],�\�������u���[�L�t���ω����Я�    */
    sint32 mmFCA_BRK_ENABLE1;                         /* 2^-22[MPa],��ڰ��t���o�͊J�n臒l    */
    sint32 mmFCA_BRK_DISABLE1;                        /* 2^-22[MPa],��ڰ��t���o�͏I��臒l    */
    sint32 mmBRK_PRES_CMD_MIN_2NDFCA;                 /* 2^-22[MPa],�ً}��������ڰ��t���ŏ��l    */
    sint32 mmBRK_PRES_CMD_MIN_2NDFCA_BPFS;            /* 2^-22[MPa],�ً}��������ڰ��t���ŏ��l(�u���[�L���쎞)    */
    sint32 mmBRK_PRES_CMD_MIN_MAXFCA;                 /* 2^-22[MPa],�ِ�������ڰ��t���ŏ��l    */
    sint32 mmBRK_PRES_CMD_MIN_MAXFCA_BPFS;            /* 2^-22[MPa],�ِ�������ڰ��t���ŏ��l(�u���[�L���쎞)    */
    sint32 mmBRK_PRES_CMD_MIN_Prefill;                /* 2^-22[MPa],�v���t�B�����ڕW�u���[�L���ŏ��l    */
    sint32 mmBRK_PRES_CMD_MIN;                        /* 2^-22[MPa],�ڕW�u���[�L���ŏ��l    */
    sint32 mmBRAKE_PRESSURE_CMD_MIN_FEB;              /* 2^-22[MPa],�ڕW�u���[�L���ŏ��l(SCAM3�ȊO)    */
    sint32 mmBRK_PRES_CMD_MAX_1STFCA;                 /* 2^-22[MPa],�\����������ڰ��t���ő�l    */
    sint32 mmBRK_PRES_CMD_MAX_2NDFCA;                 /* 2^-22[MPa],�ً}��������ڰ��t���ő�l    */
    sint32 mmBRK_PRES_CMD_MAX_2NDFCA_BPFS;            /* 2^-22[MPa],�ً}��������ڰ��t���ő�l(�u���[�L���쎞)    */
    sint32 mmBRK_PRES_CMD_MAX_MAXFCA;                 /* 2^-22[MPa],�ِ�������ڰ��t���ő�l    */
    sint32 mmBRK_PRES_CMD_MAX_MAXFCA_BPFS;            /* 2^-22[MPa],�ِ�������ڰ��t���ő�l(�u���[�L���쎞)    */
    sint32 mmFCA_MAX_BRK_ABS_HILMT;                   /* 2^-22[MPa],�ِ�����ABS�쓮����ڰ��t���ő�l    */
    sint32 mmFCA_MAX_BRK_ABS_JOJO;                    /* 2^-22[MPa/10ms],�ِ�����ABS�쓮����ڰ��t���ω����F�ω�����=0.03125[s]    */
    T_2D_MAP mmFCA_JOJO_TBL;                          /* [],���X�����}�b�v    */
    T_FL_2D_MAP mmFCA_1STBRK_PRMT_DIST_STOP_MAP;      /* [m/s],��~���\���������Ԋԋ����}�b�v    */
    FLOAT mmFCA_CONST_A_fl;                           /* [],Acceleration change ratio at the time of emergency braking start-up*0.5[m/sss]=JARK1    */
    FLOAT mmFCA_INV_JARK1_fl;                         /* [],At the time of emergency braking start-up, acceleration change ratio inverse number =1/JARK1=JARK_TIME1/(DEC1-DEC2)    */
    const FLOAT * mmFCA_MARGIN_MAP_y_fl;              /* [m],FCA margin distance TBL    */
    T_2D_MAP mmFCA_TARGET_PBRK_SUP_M_MAP;             /* [],���}�����ڕW�t�����~�b�g�}�b�v    */
    T_2D_MAP mmFCA_TARGET_PBRK_MAP;                   /* [],�ڕW�t�����~�b�g�}�b�v    */
    uint16 mFS_FEB_DRVER_BRKOVER;                     /*  0.05 [bar],FEB �h���C�o�E�u���[�L�t���L�����Z��臒l    */
    FLOAT mmDIST_TAR_0_LOMIN;                         /* [m],�ً}���������������l    */
    FLOAT mmFCA_MAXBRK_PRMT_DIST_STOP_fl;             /* [m],Stop object full braking permission distance between two cars    */
    FLOAT mmFCA_MAXBRK_PRMT_DIST_MOVE_fl;             /* [m],Moving object full braking permission distance between two cars    */
    FLOAT mmFCA_1STBRK_PRMT_DIST_STOP_fl;             /* [m],Stop object reserve braking permission distance between two cars    */
    FLOAT mmFCA_1STBRK_PRMT_DIST_MOVE_fl;             /* [m],Moving object reserve braking permission distance between two cars    */
    FLOAT mmFCA_2NDBRK_PRMT_DIST_STOP_fl;             /* [m],Stop object emergency braking permission distance between two cars    */
    FLOAT mmFCA_2NDBRK_PRMT_DIST_MOVE_fl;             /* [m],Moving object emergency braking permission distance between two cars    */
    const FLOAT * mmT_DRV_REACT_y_fl;                 /* [s],Driver Response Time at the time of no braking operations    */
    const FLOAT * mmFCA_DEC_REACT_Y_fl;               /* [s],TTC axis in case of own vehicle acceleration judgment    */
    const FLOAT * mmT_DRV_REACT_y_prebrk_fl;          /* [s],Driver Response Time at the time of no braking operations(For preliminary braking)     */
    const FLOAT * mmFCA_DEC_REACT_Y_prebrk_fl;        /* [s],TTC axis at the time of auto acceleration judgment(For preliminary braking)     */
    FLOAT mmTTC_STR_STAND1_fl;                        /* [s],Stop object target full braking permission TTC    */
    FLOAT mmTTC_STR_STAND2_fl;                        /* [s],Stop object target emergency braking permission TTC    */
    FLOAT mmTTC_STR1_fl;                              /* [s],Moving object target full braking permission TTC    */
    FLOAT mmTTC_STR2_fl;                              /* [s],Moving object target emergency braking permission TTC    */
    const FLOAT * mmT_DRV_REACT_BRK_x_fl;             /* [m/s],Relative speed after FCA correction    */
    const FLOAT * mmFCA_DEC_REACT_X_fl;               /* [m/ss],Own vehicle acceleration axis    */
    const FLOAT * mmT_DRV_REACT_BRK_y_fl;             /* [s],Driver brake reaction time    */
    const FLOAT * mmT_DRV_REACT_BRK_y_prebrk_fl;      /* [s],Driver Response Time at the time of braking operations(For preliminary braking)     */
    const FLOAT * mmT_DRV_REACT_MOVE_y_prebrk_fl;     /* [],    */
    const FLOAT * mmFCA_DEC_REACT_MOVE_Y_prebrk_fl;   /* [],    */
    FLOAT mmFCA_DEC1_LMT_fl;                          /* [m/ss],Emergency braking target deceleration: DEC1_LMT    */
    FLOAT mmFCA_INV_DEC1_2ND_fl;                      /* [ss/m],Emergency braking target deceleration inverse number: 1/(2*DEC1_LMT)    */
    FLOAT mmFCA_MAX_BRK_VSP_ON_fl;                    /* [m/s],Full braking permission ON judgment vehicle speed    */
    FLOAT mmFCA_MAX_BRK_VSP_OFF_fl;                   /* [m/s],Full braking permission OFF judgment vehicle speed    */
    T_2D_MAP mmFCA_TARGET_PBRK_PED_MAP;               /* [],�Ε��s�ҖڕW�t�����~�b�g�}�b�v    */
    T_2D_MAP mmFCA_TARGET_PBRK_MAP_ACCEL;             /* [],�Ύԗ��ڕW�t�����~�b�g�}�b�v    */
    T_2D_MAP mmBRK_PRES_CMD_MAX_MAXFCA_MAP;           /* [],�t���������ڕW�u���[�L�t���ő�l�}�b�v    */
    T_2D_MAP mmBRK_PRES_CMD_MIN_MAXFCA_MAP;           /* [],�t���������ڕW�u���[�L�t���ŏ��l�}�b�v    */
    T_2D_MAP mmFCA_TARGET_PBRK_Prefill_MAP;           /* [],�v���t�B�����ڕW�t�����~�b�g�}�b�v    */
    T_2D_MAP mmBP_UP_FCA_1ST_MAP;                     /* [],�ڕW��ڰ��t���ω����Я��}�b�v    */
    const FLOAT * mmFCA_MARGIN_MAP_MOVE_x_fl;         /* [],    */
    const FLOAT * mmFCA_MARGIN_MAP_MOVE_y_fl;         /* [],    */
    FLOAT mmFCA_DEC1_fl;                              /* [m/ss],Full braking target deceleration: DEC1    */
    FLOAT mmFCA_INV_DEC1_MAX_fl;                      /* [ss/m],Full braking target deceleration inverse number: 1/(2*DEC1)    */
    const FLOAT * mmFCA_MARGIN_MAP_x_fl;              /* [m/s],FCA Margin distance TBL relative speed axis (symbol reverse)    */
    sint32 mmBRK_PRES_CMD_PREFILL;                    /* [MPa],�v���t�B���t��    */
    const FLOAT * mmT_DRV_REACT_BRK_MOVE_y_prebrk_fl; /* [],    */
    T_2D_MAP mmFCA_TARGET_PBRK_VEH_MAP;               /* [],�Ύԗ��ڕW�t�����~�b�g�}�b�v    */
    T_2D_MAP mmBP_UP_FCA_1ST_PED_MAP;                 /* [],�ڕW��ڰ��t���ω����Я��}�b�v    */
    T_2D_MAP mmBP_UP_FCA_1ST_VEH_MAP;                 /* [],�ڕW��ڰ��t���ω����Я��}�b�v    */
    sint32 mmFCA_MAX_BRK_VSP_ON_HI;                   /* [m/s],LSB:2^-16 �t����������ON���f�ԑ�(����)     */
    sint32 mmFCA_MAX_BRK_VSP_OFF_HI;                  /* [m/s],LSB:2^-16 �t����������OFF���f�ԑ�(����)    */
    sint32 mmBRK_PRES_CMD_JAA;                        /* [MPa],mBRK_PRES_CMD_JAA    */
    const sint16 * mmFCA_TARGET_PBRK_COAST_COMP;      /* [m/ss],LSB:2^-8 �R�[�X�g�����x    */
    const sint16 * mmFCA_TARGET_PBRK_COAST_2ND_COMP;  /* [Mpa],LSB:2^-12 �\�������p�ڕW�t���␳�l    */
    const sint16 * mmFCA_TARGET_PBRK_COAST_1ST_COMP;  /* [Mpa],LSB:2^-12 �ِ����p�ڕW�t���␳�l    */
    FLOAT mmTTC_STR_STAND1_WITH_AD2_fl;               /* [s],Stop object target full braking permission TTC    */
    FLOAT mmTTC_STR_STAND2_WITH_AD2_fl;               /* [s],Stop object target emergency braking permission TTC    */
    FLOAT mmTTC_STR1_WITH_AD2_fl;                     /* [s],Moving object target full braking permission TTC    */
    FLOAT mmTTC_STR2_WITH_AD2_fl;                     /* [s],Moving object target emergency braking permission TTC    */
}st_variant_const_FEB;

#define mWIDTH_OBJ0_MIN                               (StVariantRAM_FEB.mmWIDTH_OBJ0_MIN)
#define mTSIG_ON_DLY_TIME                             (StVariantRAM_FEB.mmTSIG_ON_DLY_TIME)
#define mTBL_RECOG_RELE                               (StVariantRAM_FEB.mmTBL_RECOG_RELE)
#define mAPO_OFF_RECO                                 (StVariantRAM_FEB.mmAPO_OFF_RECO)
#define mAPO_OFF_RECO1                                (StVariantRAM_FEB.mmAPO_OFF_RECO1)
#define mCNT_FFP_ON_MAX                               (StVariantRAM_FEB.mmCNT_FFP_ON_MAX)
#define mCNT_APO_OVR_RECO                             (StVariantRAM_FEB.mmCNT_APO_OVR_RECO)
#define mAPO_OVR_RECO                                 (StVariantRAM_FEB.mmAPO_OVR_RECO)
#define m1_5hzBPF0                                    (StVariantRAM_FEB.mm1_5hzBPF0)
#define m1_5hzBPF1                                    (StVariantRAM_FEB.mm1_5hzBPF1)
#define m1_5hzBPF2                                    (StVariantRAM_FEB.mm1_5hzBPF2)
#define mINV_GAIN_ENGINE_MB                           (StVariantRAM_FEB.mmINV_GAIN_ENGINE_MB)
#define mAPO_ANGL_INC_LATCH                           (StVariantRAM_FEB.mmAPO_ANGL_INC_LATCH)
#define mFFP_BUZ_TIME                                 (StVariantRAM_FEB.mmFFP_BUZ_TIME)
#define mAPO_ANGL_DECOMP_FCA                          (StVariantRAM_FEB.mmAPO_ANGL_DECOMP_FCA)
#define mFCA_ARMYU                                    (StVariantRAM_FEB.mmFCA_ARMYU)
#define mBP_UP_FCA_1ST                                (StVariantRAM_FEB.mmBP_UP_FCA_1ST)
#define mBP_UP_FCA_1ST_CROSS                          (StVariantRAM_FEB.mmBP_UP_FCA_1ST_CROSS)
#define mFCA_BRK_ENABLE1                              (StVariantRAM_FEB.mmFCA_BRK_ENABLE1)
#define mFCA_BRK_DISABLE1                             (StVariantRAM_FEB.mmFCA_BRK_DISABLE1)
#define mBRK_PRES_CMD_MIN_2NDFCA                      (StVariantRAM_FEB.mmBRK_PRES_CMD_MIN_2NDFCA)
#define mBRK_PRES_CMD_MIN_2NDFCA_BPFS                 (StVariantRAM_FEB.mmBRK_PRES_CMD_MIN_2NDFCA_BPFS)
#define mBRK_PRES_CMD_MIN_MAXFCA                      (StVariantRAM_FEB.mmBRK_PRES_CMD_MIN_MAXFCA)
#define mBRK_PRES_CMD_MIN_MAXFCA_BPFS                 (StVariantRAM_FEB.mmBRK_PRES_CMD_MIN_MAXFCA_BPFS)
#define mBRK_PRES_CMD_MIN_Prefill                     (StVariantRAM_FEB.mmBRK_PRES_CMD_MIN_Prefill)
#define mBRK_PRES_CMD_MIN                             (StVariantRAM_FEB.mmBRK_PRES_CMD_MIN)
#define mBRAKE_PRESSURE_CMD_MIN_FEB                   (StVariantRAM_FEB.mmBRAKE_PRESSURE_CMD_MIN_FEB)
#define mBRK_PRES_CMD_MAX_1STFCA                      (StVariantRAM_FEB.mmBRK_PRES_CMD_MAX_1STFCA)
#define mBRK_PRES_CMD_MAX_2NDFCA                      (StVariantRAM_FEB.mmBRK_PRES_CMD_MAX_2NDFCA)
#define mBRK_PRES_CMD_MAX_2NDFCA_BPFS                 (StVariantRAM_FEB.mmBRK_PRES_CMD_MAX_2NDFCA_BPFS)
#define mBRK_PRES_CMD_MAX_MAXFCA                      (StVariantRAM_FEB.mmBRK_PRES_CMD_MAX_MAXFCA)
#define mBRK_PRES_CMD_MAX_MAXFCA_BPFS                 (StVariantRAM_FEB.mmBRK_PRES_CMD_MAX_MAXFCA_BPFS)
#define mFCA_MAX_BRK_ABS_HILMT                        (StVariantRAM_FEB.mmFCA_MAX_BRK_ABS_HILMT)
#define mFCA_MAX_BRK_ABS_JOJO                         (StVariantRAM_FEB.mmFCA_MAX_BRK_ABS_JOJO)
#define mFCA_JOJO_TBL                                 (StVariantRAM_FEB.mmFCA_JOJO_TBL)
#define mFCA_1STBRK_PRMT_DIST_STOP_MAP                (StVariantRAM_FEB.mmFCA_1STBRK_PRMT_DIST_STOP_MAP)
#define mFCA_CONST_A_fl                               (StVariantRAM_FEB.mmFCA_CONST_A_fl)
#define mFCA_INV_JARK1_fl                             (StVariantRAM_FEB.mmFCA_INV_JARK1_fl)
#define mFCA_MARGIN_MAP_y_fl                          (StVariantRAM_FEB.mmFCA_MARGIN_MAP_y_fl)
#define mFCA_TARGET_PBRK_SUP_M_MAP                    (StVariantRAM_FEB.mmFCA_TARGET_PBRK_SUP_M_MAP)
#define mFCA_TARGET_PBRK_MAP                          (StVariantRAM_FEB.mmFCA_TARGET_PBRK_MAP)
#define FS_FEB_DRVER_BRKOVER                          (StVariantRAM_FEB.mFS_FEB_DRVER_BRKOVER)
#define mDIST_TAR_0_LOMIN                             (StVariantRAM_FEB.mmDIST_TAR_0_LOMIN)
#define mFCA_MAXBRK_PRMT_DIST_STOP_fl                 (StVariantRAM_FEB.mmFCA_MAXBRK_PRMT_DIST_STOP_fl)
#define mFCA_MAXBRK_PRMT_DIST_MOVE_fl                 (StVariantRAM_FEB.mmFCA_MAXBRK_PRMT_DIST_MOVE_fl)
#define mFCA_1STBRK_PRMT_DIST_STOP_fl                 (StVariantRAM_FEB.mmFCA_1STBRK_PRMT_DIST_STOP_fl)
#define mFCA_1STBRK_PRMT_DIST_MOVE_fl                 (StVariantRAM_FEB.mmFCA_1STBRK_PRMT_DIST_MOVE_fl)
#define mFCA_2NDBRK_PRMT_DIST_STOP_fl                 (StVariantRAM_FEB.mmFCA_2NDBRK_PRMT_DIST_STOP_fl)
#define mFCA_2NDBRK_PRMT_DIST_MOVE_fl                 (StVariantRAM_FEB.mmFCA_2NDBRK_PRMT_DIST_MOVE_fl)
#define mT_DRV_REACT_y_fl                             (StVariantRAM_FEB.mmT_DRV_REACT_y_fl)
#define mFCA_DEC_REACT_Y_fl                           (StVariantRAM_FEB.mmFCA_DEC_REACT_Y_fl)
#define mT_DRV_REACT_y_prebrk_fl                      (StVariantRAM_FEB.mmT_DRV_REACT_y_prebrk_fl)
#define mFCA_DEC_REACT_Y_prebrk_fl                    (StVariantRAM_FEB.mmFCA_DEC_REACT_Y_prebrk_fl)
#define mTTC_STR_STAND1_fl                            (StVariantRAM_FEB.mmTTC_STR_STAND1_fl)
#define mTTC_STR_STAND2_fl                            (StVariantRAM_FEB.mmTTC_STR_STAND2_fl)
#define mTTC_STR1_fl                                  (StVariantRAM_FEB.mmTTC_STR1_fl)
#define mTTC_STR2_fl                                  (StVariantRAM_FEB.mmTTC_STR2_fl)
#define mT_DRV_REACT_BRK_x_fl                         (StVariantRAM_FEB.mmT_DRV_REACT_BRK_x_fl)
#define mFCA_DEC_REACT_X_fl                           (StVariantRAM_FEB.mmFCA_DEC_REACT_X_fl)
#define mT_DRV_REACT_BRK_y_fl                         (StVariantRAM_FEB.mmT_DRV_REACT_BRK_y_fl)
#define mT_DRV_REACT_BRK_y_prebrk_fl                  (StVariantRAM_FEB.mmT_DRV_REACT_BRK_y_prebrk_fl)
#define mT_DRV_REACT_MOVE_y_prebrk_fl                 (StVariantRAM_FEB.mmT_DRV_REACT_MOVE_y_prebrk_fl)
#define mFCA_DEC_REACT_MOVE_Y_prebrk_fl               (StVariantRAM_FEB.mmFCA_DEC_REACT_MOVE_Y_prebrk_fl)
#define mFCA_DEC1_LMT_fl                              (StVariantRAM_FEB.mmFCA_DEC1_LMT_fl)
#define mFCA_INV_DEC1_2ND_fl                          (StVariantRAM_FEB.mmFCA_INV_DEC1_2ND_fl)
#define mFCA_MAX_BRK_VSP_ON_fl                        (StVariantRAM_FEB.mmFCA_MAX_BRK_VSP_ON_fl)
#define mFCA_MAX_BRK_VSP_OFF_fl                       (StVariantRAM_FEB.mmFCA_MAX_BRK_VSP_OFF_fl)
#define mFCA_TARGET_PBRK_PED_MAP                      (StVariantRAM_FEB.mmFCA_TARGET_PBRK_PED_MAP)
#define mFCA_TARGET_PBRK_MAP_ACCEL                    (StVariantRAM_FEB.mmFCA_TARGET_PBRK_MAP_ACCEL)
#define mBRK_PRES_CMD_MAX_MAXFCA_MAP                  (StVariantRAM_FEB.mmBRK_PRES_CMD_MAX_MAXFCA_MAP)
#define mBRK_PRES_CMD_MIN_MAXFCA_MAP                  (StVariantRAM_FEB.mmBRK_PRES_CMD_MIN_MAXFCA_MAP)
#define mFCA_TARGET_PBRK_Prefill_MAP                  (StVariantRAM_FEB.mmFCA_TARGET_PBRK_Prefill_MAP)
#define mBP_UP_FCA_1ST_MAP                            (StVariantRAM_FEB.mmBP_UP_FCA_1ST_MAP)
#define mFCA_MARGIN_MAP_MOVE_x_fl                     (StVariantRAM_FEB.mmFCA_MARGIN_MAP_MOVE_x_fl)
#define mFCA_MARGIN_MAP_MOVE_y_fl                     (StVariantRAM_FEB.mmFCA_MARGIN_MAP_MOVE_y_fl)
#define mFCA_DEC1_fl                                  (StVariantRAM_FEB.mmFCA_DEC1_fl)
#define mFCA_INV_DEC1_MAX_fl                          (StVariantRAM_FEB.mmFCA_INV_DEC1_MAX_fl)
#define mFCA_MARGIN_MAP_x_fl                          (StVariantRAM_FEB.mmFCA_MARGIN_MAP_x_fl)
#define mBRK_PRES_CMD_PREFILL                         (StVariantRAM_FEB.mmBRK_PRES_CMD_PREFILL)
#define mT_DRV_REACT_BRK_MOVE_y_prebrk_fl             (StVariantRAM_FEB.mmT_DRV_REACT_BRK_MOVE_y_prebrk_fl)
#define mFCA_TARGET_PBRK_VEH_MAP                      (StVariantRAM_FEB.mmFCA_TARGET_PBRK_VEH_MAP)
#define mBP_UP_FCA_1ST_PED_MAP                        (StVariantRAM_FEB.mmBP_UP_FCA_1ST_PED_MAP)
#define mBP_UP_FCA_1ST_VEH_MAP                        (StVariantRAM_FEB.mmBP_UP_FCA_1ST_VEH_MAP)
#define mFCA_MAX_BRK_VSP_ON_HI                        (StVariantRAM_FEB.mmFCA_MAX_BRK_VSP_ON_HI)
#define mFCA_MAX_BRK_VSP_OFF_HI                       (StVariantRAM_FEB.mmFCA_MAX_BRK_VSP_OFF_HI)
#define mBRK_PRES_CMD_JAA                             (StVariantRAM_FEB.mmBRK_PRES_CMD_JAA)
#define mFCA_TARGET_PBRK_COAST_COMP                   (StVariantRAM_FEB.mmFCA_TARGET_PBRK_COAST_COMP)
#define mFCA_TARGET_PBRK_COAST_2ND_COMP               (StVariantRAM_FEB.mmFCA_TARGET_PBRK_COAST_2ND_COMP)
#define mFCA_TARGET_PBRK_COAST_1ST_COMP               (StVariantRAM_FEB.mmFCA_TARGET_PBRK_COAST_1ST_COMP)
#define mTTC_STR_STAND1_WITH_AD2_fl                   (StVariantRAM_FEB.mmTTC_STR_STAND1_WITH_AD2_fl)
#define mTTC_STR_STAND2_WITH_AD2_fl                   (StVariantRAM_FEB.mmTTC_STR_STAND2_WITH_AD2_fl)
#define mTTC_STR1_WITH_AD2_fl                         (StVariantRAM_FEB.mmTTC_STR1_WITH_AD2_fl)
#define mTTC_STR2_WITH_AD2_fl                         (StVariantRAM_FEB.mmTTC_STR2_WITH_AD2_fl)

extern const st_variant_const_FEB  *StVariantROM_FEB[ADAS_MAX_VARIANT_NUM];

#endif /* __FEB_VARIANT_ROM_J32V_7DB0A_H__ */
