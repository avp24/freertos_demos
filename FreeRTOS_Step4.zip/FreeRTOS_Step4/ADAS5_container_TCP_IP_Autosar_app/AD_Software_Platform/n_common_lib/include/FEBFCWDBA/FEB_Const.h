/*******************************************************************************
 *
 *     Copyright (c) 2013 Nissan, Japan
 *
 *******************************************************************************
 *
 * Project:
 * Module:     Forward Emergency Braking
 * Version      0.1
 * Author:
 * Date:
 *
*******************************************************************************/
#ifndef	__FEB_CONST_H__
#define	__FEB_CONST_H__

#include "FEB_variant_rom.h"

/*******************************************************************************/
/* INCLUDE FILES								                               */
/*******************************************************************************/
#if	DEF_B02E
	#include	"./B02E/FebConst_B02E.h"
#elif	DEF_P32R_17MY
	#include	"./P32R_17MY/FebConst_P32R_17MY.h"
#elif	DEF_P32S
	#include	"./P32S/FebConst_P32S.h"
#elif	DEF_L42N_19MY
	#include	"./L42N/FebConst_L42N.h"
#elif	DEF_P42M_19MY
	#include	"./P42M/FebConst_P42M.h"
#elif	DEF_L21B
	#include	"./L21B/FebConst_L21B.h"
#elif	DEF_P13A
	#include	"./P13A/FebConst_P13A.h"
#elif	DEF_P33A
	#include	"./P33A/FebConst_P33A.h"
#elif	DEF_P42R
	#include	"./P42R/FebConst_P42R.h"
#elif	DEF_P33B
	#include	"./P33B/FebConst_P33B.h"
#elif	DEF_PZ1A
	#include	"./PZ1A/FebConst_PZ1A.h"
#elif	DEF_J32V
	#include	"./J32V/FebConst_J32V.h"
#elif	DEF_UZ2C
	#include	"./UZ2C/FebConst_UZ2C.h"
#elif	DEF_LZ2A
	#include	"./LZ2A/FebConst_LZ2A.h"
#elif	DEF_P61Q
	#include	"./P61Q/FebConst_P61Q.h"
#elif	0
	#include	"./DMY/FebConst_DMY.h"
#else
	#error		"Not Correct Specs"
#endif

#ifndef __FEB_CONST_SM_H__
	#include "FEB_ConstDB.h"
#endif

#endif
