/*********************************************************************************
 *
 *     Copyright (c) 2014 Nissan, Japan
 *
 *********************************************************************************
 *
 * Project:     FEB
 * Author:      NISSAN
 * Description: FEB Const declaration area
 * Macro Ver.:  Ver.1.00
 * Revision History:
 *
*********************************************************************************/
#ifndef __FEB_VARIANT_ROM_H__
#define __FEB_VARIANT_ROM_H__

/* ------------------------------------------------ */
/*  �C���N���[�h                                    */
/* ------------------------------------------------ */

/* ------------------------------------------------ */
/*  �}�N���錾                                      */
/* ------------------------------------------------ */
#ifdef __FEB_VARIANT_ROM_C__
#define EXTERN
#else
#define EXTERN extern
#endif

/* -------------------------------- */
/* INCLUDE MORE DETAIL              */
/* -------------------------------- */
#if	DEF_B02E
	#include	"./B02E/FebVariantRom_B02E.h"
#elif	DEF_P32R_17MY
	#include	"./P32R_17MY/FebVariantRom_P32R_17MY.h"
#elif	DEF_P32S
	#include	"./P32S/FebVariantRom_P32S.h"
#elif	DEF_L42N_19MY
	#include	"./L42N/FebVariantRom_L42N.h"
#elif	DEF_P42M_19MY
	#include	"./P42M/FebVariantRom_P42M.h"
#elif	DEF_L21B
	#include	"./L21B/FebVariantRom_L21B.h"
#elif	DEF_P13A
	#include	"./P13A/FebVariantRom_P13A.h"
#elif	DEF_P33A
	#include	"./P33A/FebVariantRom_P33A.h"
#elif	DEF_P42R
	#include	"./P42R/FebVariantRom_P42R.h"
#elif	DEF_P33B
	#include	"./P33B/FebVariantRom_P33B.h"
#elif	DEF_PZ1A
	#include	"./PZ1A/FebVariantRom_PZ1A.h"
#elif	DEF_J32V
	#include	"./J32V/FebVariantRom_J32V.h"
#elif	DEF_UZ2C
	#include	"./UZ2C/FebVariantRom_UZ2C.h"
#elif	DEF_LZ2A
	#include	"./LZ2A/FebVariantRom_LZ2A.h"
#elif	DEF_P61Q
	#include	"./P61Q/FebVariantRom_P61Q.h"
#elif	0
	#include	"./DMY/FebVariantRom_DMY.h"
#else
	#error		"Not Correct Specs"
#endif


/* ------------------------------------------------ */
/* extern �錾                                      */
/* ------------------------------------------------ */
EXTERN st_variant_const_FEB StVariantRAM_FEB;

#undef EXTERN
#endif
