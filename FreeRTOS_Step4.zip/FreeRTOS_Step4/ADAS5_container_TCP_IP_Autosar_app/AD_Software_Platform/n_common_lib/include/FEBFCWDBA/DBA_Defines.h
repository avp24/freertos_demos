/****************************************************************************************************/
/*	Copyright (c) 2014 Nissan, Japan																*/
/****************************************************************************************************/
/****************************************************************************************************/
/*																									*/
/*	DBA_Defines.h																					*/
/*																									*/
/*																									*/
/*																									*/
/****************************************************************************************************/

#ifndef	__DBA_DEFINES__
#define __DBA_DEFINES__

/*--------------------------------------------------------------------------------------------------*/
/*	vDBAStatus�������p																				*/
/*--------------------------------------------------------------------------------------------------*/
#define	iDBA_STATUS_INIT_VALUE		{													\
										0,		/*	������		LSB:-			*/	\
										0,		/*	��ڰ����		LSB:-			*/	\
										0,		/*	��а			LSB:-			*/	\
										0,		/*	�����x�w�ߒl	LSB:2^-22[m/ss]	*/	\
										0		/*	��ڰ��t��		LSB:2^22[MPa]	*/	\
									}

/*--------------------------------------------------------------------------------------------------*/
/*	DAB����																							*/
/*--------------------------------------------------------------------------------------------------*/
#define	DBA_ON						(1u)
#define	DBA_OFF						(0u)

#define	DBA_SET						(1u)
#define	DBA_RESET					(0u)

#define	DBA_ZERO					(0u)
#define	DBA_ONE						(1u)
#define	DBA_TWO						(2u)
#define	DBA_THREE					(3u)
#define	DBA_FOUR					(4u)
#define	DBA_SIXTEEN					(16u)
#define	DBA_THIRTY_ONE				(31u)
#define	DBA_THIRTY_TWO				(32u)

#define	DBA_Z0						(0u)
#define	DBA_Z1						(1u)
#define	DBA_Z2						(2u)
#define	DBA_Z3						(3u)

/*--------------------------------------------------------------------------------------------------*/
/*	FailSafe�֘A																					*/
/*--------------------------------------------------------------------------------------------------*/
#define	FS_BRK_OFF					(0x01)								/*	��ڰ�������			*/
#define	FS_BRK_SLOW					(0x02)								/*	��ڰ��x�ߏ��X����	*/
#define	FS_BRK_FAST					(0x10)								/*	��ڰ����ߏ��X����	*/
#define	FS_BRK_STANDARD				(0x20)								/*	��ڰ��W�����X����	*/
#define	FS_BRK_INH					(0x40)								/*	��ڰ��֎~			*/
#define	FS_BRK_OFF_INH				( FS_BRK_OFF | FS_BRK_INH )			/*	��ڰ�������			*/
#define	FS_BRK_FAST_INH				( FS_BRK_FAST | FS_BRK_INH )		/*	��ڰ����ߏ��X����	*/
#define FS_BRK_SLOW_INH				( FS_BRK_SLOW | FS_BRK_INH)			/*	��ڰ��x�ߏ��X����	*/
#define	FS_BRK_STANDARD_INH			( FS_BRK_STANDARD | FS_BRK_INH )	/*	��ڰ��W�����X����	*/

/*--------------------------------------------------------------------------------------------------*/
/*	LSB�֘A																							*/
/*--------------------------------------------------------------------------------------------------*/
#define	iVREL_map_lsb				(8u)
#define	iWHLINIT_CLRWHL_lsb			(15u)
#define	iACCCOM_FB_lsb				(15u)		/*	mACCCOM_FB��LSB		*/
#define	iVSP_lsb					(16u)
#define	iVREL_lsb					(16u)
#define	iDIST_lsb					(16u)
#define	iACCE_lsb					(22u)
#define	iV_SERVO_lsb				(22u)		/*	Vehicle speed servo operation define iV_SERVO_lsb, LSB of the vehicle speed command value	*/
#define	iTIME_lsb					(22u)
#define	iVSP_SERVO_lsb				(22u)
#define	iBRK_CMD_calc_lsb			(22u)
#define	iV_COM_FB_G_lsb				(30u)
#define	iconst_b_lsb				(31u)		/*	-1/(2*DEC1)��LSB	*/

#define	iONE_30						(1073741824u)	/* 0x40000000 */

#define	iR_SHIFT_1					(1u)		/*	0.5�{	*/
#define	iL_SHIFT_1					(1u)		/*	2.0�{	*/
#define	iL_SHIFT_6					(6u)		/*	64.0�{	*/
#define	iL_SHIFT_14					(14u)		/*			*/

#define	iL_SHIFT_18_mul				(262144u)	/*	2^18	*/
#define	iL_SHIFT_1_mul				(2u)		/*	2^1		*/
#define	iDR_PRES_trans_const		(25u)		/*	25		*/

/* 2016.09.12 S.Tsunekado �r�b�g���[�g�s��Ή� �r�b�g���[�g�l�}�N���� */
#define	iA_FBK_lsb					(15u)
#define	iA_MDL_lsb					(18u)
#define	iACCCOM_FF_lsb				(12u)
#define	iN_A_LMT_lsb				(16u)
#define	iD_A_LMT_lsb				(15u)
#define	iA_REF_lsb					(20u)
#define	iTsmpl_lsb					(16u)	/* DBA_defferential_lpf()�Ŏg���T���v�����O���Ԃ̃r�b�g���[�g */

/*--------------------------------------------------------------------------------------------------*/
/*	DBA_BRK_CMD_main.c																				*/
/*--------------------------------------------------------------------------------------------------*/
#define	iOPE_MODE					(0x0f)
#define	iAPL_MODE					(0xf0)

#define	iBRK_COM_INIT				(0x01)
#define	iBRK_GRAD_INIT				(0x02)
#define	iBRK_COM_GRAD_INIT			( iBRK_COM_INIT | iBRK_GRAD_INIT )

#define	iWHL_TRQ_CMD_BIN_POINT		(16u)
#define	iBRK_CMD_calc_lsb			(22u)
#define	iBRK_CMD_lsb				(23u)

#define	iJOJO_STEP_MAX				(2147483647u)	/*	�ޮ�ޮ�������̍ő吔						*/

#define	iBRK_CMD_BIN_POINT			(22u)
#define	iTW_BRK_CMD_BIN_POINT		(16u)
#define	iTRQ_CMD_BIN_POINT			(16u)
#define	iTRQ_ENG_BIN_POINT			(16u)
#define	iARMYU_BIN_POINT			(22u)

#define	DBA_PBRK_LMT_GAIN_lsb		(22u)
#define	iEMBRK_PRS_COM_SOKU_INI		(32768)		/*	��ڰ����������c���w��	1bit��:0.0078125[MPa]	*/

/*--------------------------------------------------------------------------------------------------*/
/*	VSP_CMD_DIST_SEL_calc.c																			*/
/*--------------------------------------------------------------------------------------------------*/
#define	iINTEG_calc_num_dba			(2u)

#define	iVSP_LSB					(16u)
#define	iVSP_SQUARE_LSB				(16u)
#define	iVSP_C_CALC_LSB				(20u)
#define	iD_LSB						(16u)
#define	iD_DENOMINATION_LSB			(8u)
#define	iACC_LSB					(22u)
#define	iACC_DENOMINATION_LSB		(12u)
#define	iACC_STP_DENOMI_LSB			(7u)
#define	iACC_STP_NUMERA_LSB			(14u)
#define	iTIME_LSB					(22u)
#define	iTsmpl_LSB					(16u)
#define	iINTEG_calc_delta_t_LSB		(14u)
#define	iINTEG_calc_num				(2u)
#define	iINTEG_calc_pr_LSB			(22u)

/*--------------------------------------------------------------------------------------------------*/
/*	DBA_CTRL_MODE_judge.c																			*/
/*--------------------------------------------------------------------------------------------------*/
#if	1	/* 2016.10.28 J32U JNCAP�Ή� *//* 161012 T.Inoue */
#define	iDBA_ON_COND				(150u)		/*	COND1,COND2��ON��OFF�A�Ǝ���	LSB:0.01[s]	*/
#else
#define	iDBA_ON_COND				(50u)		/*	COND1,COND2��ON��OFF�A�Ǝ���	LSB:0.01[s]	*/
#endif

#define	iDBA_PRS					(11u)
#define	iDBA_PRS_AVE_const			(10u)		/*	1/(iDBA_PRS-1)/mDBA_CYCLE = 1/10/0.01 = 10	*/

#define	iDBA_JARK					(16u)
#define	iDBA_JARK_AVE_const1		(20u)		/*	1/(iDBA_JARK-1)/mDBA_CYCLE = 1/15/0.01 = 20/3	*/
#define	iDBA_JARK_AVE_const2		(3u)		/*	1/(iDBA_JARK-1)/mDBA_CYCLE = 1/15/0.01 = 20/3	*/

/*--------------------------------------------------------------------------------------------------*/
/*																									*/
/*--------------------------------------------------------------------------------------------------*/
#define	SIZE(A)						((sizeof A)/(sizeof A[0]))

#endif	/*__DBA_DEFINES__*/
