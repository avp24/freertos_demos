/*******************************************************************************
 *
 *     Copyright (c) 2013 Nissan, Japan
 *
 *******************************************************************************
 *
 * Project:
 * Module:      Forward Emergency Braking
 * Version      0.1
 * Author:
 * Date:
 *
*******************************************************************************/
#ifndef	__FEB_COMMON_FUNC_H__
#define	__FEB_COMMON_FUNC_H__

/*******************************************************************************/
/* INCLUDE FILES								                               */
/*******************************************************************************/
#if	0	/* ADAS2->3 change */
/*#include	"FEB_Defines.h"*/
#include	"n_apl_common.h" /* Added for FLOAT typedef */
#else
#include	"FEB_Defines.h"
#include	"n_common.h"
#endif
#include "spec.h" /* ���g���G���f�B�A���Ή� Task #8628 */
/*******************************************************************************/
/* Check variable body or extern 											   */
/*******************************************************************************/
#ifdef __FEB_COMMON_FUNC_C__
#define EXTERN
#else
#define EXTERN  extern
#endif

/*******************************************************************************/
/* STRUCTURE DEFINITION 													   */
/*******************************************************************************/
typedef struct
{
	uchar8	( *JUDGE_EVENT )(void);
	uchar8	EVENT_CODE;
}judge_event_fca;

/*  func_trans_state()?p */
typedef struct
{
	uchar8		STATE;
	void		(*EN_ACT)(void);
}trans_state_fca;

/*******************************************************************************/
/* ENUMS				 													   */
/*******************************************************************************/
enum
{
	Z0_fca,			/* Current value */
	Z1_fca,			/* 1 past time before value */
};

/* from ADAS2/COMMON/commom_func.h */
enum
{
	FALL_fca,
	RISE_fca,
	EDGE_fca
};

enum
{
	BYTE_fca,
	WORD_fca,
	D_WORD_fca
};


/*******************************************************************************/
/* FUNCTION DECLARATIONS 													   */
/*******************************************************************************/
EXTERN FLOAT   	FEB_MACRO_lim(FLOAT macro_in_lim, FLOAT lim_hi, FLOAT lim_lo);
EXTERN FLOAT   	FEB_MACRO_MIN(FLOAT macro_min_in_a, FLOAT macro_min_in_b);
EXTERN FLOAT  	FEB_MACRO_MAX(FLOAT macro_max_in_a, FLOAT macro_max_in_b);
EXTERN FLOAT  	FEB_LIMIT_MAX(FLOAT in_val_max, FLOAT max_val);
EXTERN FLOAT  	FEB_LIMIT_MIN(FLOAT in_val_min, FLOAT min_val);

EXTERN void 	fca_func_pr_update( void *p, uchar8 num, uchar8 type );
/*EXTERN uchar8  	fca_func_edge( uchar8 in,  uchar8  in_z1, uchar8 type );*/
EXTERN FLOAT  	FEB_func_lim_L( FLOAT in_lim_l, FLOAT uplim_lim_l, FLOAT dnlim_lim_l );
EXTERN void     FEB_func_inc( uint16 *p_cnt, uint16 uplim_inc );
EXTERN void 	FEB_func_trans_state(uchar8 *state, const trans_state_fca *table );
EXTERN uchar8   FEB_func_judge_event( const judge_event_fca* p, uchar8 event_num );

EXTERN FLOAT 	FEB_lookup1dtbl(const FLOAT outvalues[], const FLOAT invalues[], FLOAT x, uint32 num_points);
EXTERN sint16 	FEB_lookup1dtbl_si16(const sint16 outvalues[], const sint16 invalues[], sint16 x, uint32 num_points);
EXTERN FLOAT	FEB_MAPWS( const FLOAT* Map_name,const FLOAT* X_Table,const uint16  NumX,
			    const FLOAT* Y_Table,const uint16  NumY,FLOAT	X_Data,FLOAT	Y_Data);
EXTERN FLOAT  	FEB_RATE_LIMIT(FLOAT vin_rl, FLOAT vout_z1_rl, FLOAT const_up_lim_rl, FLOAT const_dn_lim_rl);
EXTERN void 	FEB_func_integ( FLOAT out_integ[], FLOAT rate, FLOAT delta_t);
/*EXTERN void 	fl_fca_func_pr_update( FLOAT *p, uchar8 num );*/
EXTERN FLOAT 	FEB_defferential_lpf( FLOAT in_lpf, FLOAT *mid, FLOAT mde_lpf, FLOAT sample );
EXTERN FLOAT	FEB_accuracy_lpf( FLOAT in_a_lpf, FLOAT out_old_a_lpf, FLOAT mac_lpf);
EXTERN FLOAT	FEB_lpf( FLOAT in_old, FLOAT out_old_lpf1, FLOAT const_in_old, FLOAT const_out_old);
EXTERN void  	FEB_func_edge_cnt( uint16 *cnt_edge, uint8 edge );
EXTERN uchar8	FEB_func_cross( FLOAT in_cross[], FLOAT thres, uchar8 type_cross);
EXTERN FLOAT  	FEB_func_rate_lim_up_L( FLOAT vin_rate_lim, FLOAT vout_z1_rate_lim, FLOAT const_up_lim_rate_lim );
EXTERN sint32 FEB_func_lim_si( sint32 in_si, sint32 uplim_si, sint32 dnlim_si );
EXTERN schar8 FEB_func_lim_si_sc( sint32 in_lim_sisc, schar8 uplim_sisc, schar8 dnlim_sisc );
EXTERN uchar8 FEB_func_lim_si_uc( sint32 in_siuc, uchar8 uplim_siuc, uchar8 dnlim_siuc );
EXTERN sint16 FEB_func_lim_si_ss( sint32 in_siss, sint16 uplim_siss, sint16 dnlim_siss );
EXTERN sint32 FEB_VirtualVehicleAssign(const uchar8 vout_offset,const sint32 vin_vv,const uchar8 vin_offset_vv);
EXTERN sint32  FEB_func_rate_lim_up_si( sint32 vin_rlsi, sint32 vout_z1_rlsi, sint32 const_up_lim_rlsi );
EXTERN sint32  FEB_RATE_LIMIT_SINT32(sint32 vin, sint32 vout_z1, sint32 const_up_lim, sint32 const_dn_lim);

EXTERN void FEB_func_delay( uchar8 in_delay[ ], uint16* cnt_delay, uint16 rise_delay, uint16 fall_delay );
#define fca_SIZE(A) ((sizeof (A))/(sizeof (A)[FEB_ZERO]))

#if 1 /* use FEB Common Function *//* B02E VC2 n_common�ւ̎������Ԃɍ����Ă��Ȃ����߃A�v�����ɓ���Ă��� */
#ifndef NULL
#define NULL ((void*)0)
#endif
#define 	ZERO				((uint32)(0x00))	/* 0 */
#define 	ONE					((uint32)(0x01))	/* 1 */
#define 	TWO					((uint32)(0x02))	/* 2 */
#define 	THREE				((uint32)(0x03))	/* 3 */
#define 	FOUR				((uint32)(0x04))	/* 4 */
#define 	FIVE				((uint32)(0x05))	/* 5 */
#define 	SIX					((uint32)(0x06))	/* 6 */
#define 	SEVEN				((uint32)(0x07))	/* 7 */
#define 	EIGHT				((uint32)(0x08))	/* 8 */
#define 	NINE				((uint32)(0x09))	/* 9 */
#define 	TEN					((uint32)(0x0A))	/* 10 */
#define 	ELEVEN				((uint32)(0x0B))	/* 11 */
#define 	TWELVE				((uint32)(0x0C))	/* 12 */
#define 	THIRTEEN			((uint32)(0x0D))	/* 13 */
#define 	FIFTEEN				((uint32)(0x0F))	/* 15 */
#define 	SIXTEEN				((uint32)(0x10))	/* 16 */
#define 	NINETEEN			((uint32)(0x13))	/* 19 */
#define 	TWENTY				((uint32)(0x14))	/* 20 */
#define 	TWENTY_ONE			((uint32)(0x15))	/* 21 */
#define 	TWENTY_SEVEN		((uint32)(0x1B))	/* 27 */
#define		TWENTY_NINE			((uint32)(0x1D))	/* 29 */
#define		THIRTY				((uint32)(0x1E))	/* 30 */
#define     THIRTY_ONE          ((uint32)(0x1F))    /* 31 */

#if (DYNAMIC_EMULATOR || LITTLE_ENDIAN_SW) /*** little endian ***//* ���g���G���f�B�A���Ή� Task #8556 */
typedef struct{
    uint32 fraction :23;
    uint32 exponent :8;
    uint32 sign     :1;
}T_IEE754_FLOAT;
#else /* DYNAMIC_EMULATOR */
typedef struct{
    uint32 sign     :1;
    uint32 exponent :8;
    uint32 fraction :23;
}T_IEE754_FLOAT;
#endif /* DYNAMIC_EMULATOR */

#define FL_STATUS_NORMAL    (0u)
#define FL_STATUS_OVERFLOW  (1u)
#define FL_STATUS_UNDERFLOW (2u)
#define FL_STATUS_DIV_ZERO  (3u)

EXTERN sint32 si32_Read3DMap(sint32 x, sint32 y, const T_3D_MAP *map);
/* �z��T�C�Y�擾 */
#define ARRAY_NUM(A)   ( (sizeof(A)) / (sizeof(A[0])) )
EXTERN FLOAT fl_Read2DMap(FLOAT x, const T_FL_2D_MAP *map);
EXTERN FLOAT fl_Read3DMap(FLOAT x, FLOAT y, const T_FL_3D_MAP *map);
EXTERN FLOAT fl_SelectMax( FLOAT a, FLOAT b );
EXTERN FLOAT fl_SelectMin( FLOAT a, FLOAT b );
EXTERN FLOAT fl_abs(FLOAT abs_val);
EXTERN FLOAT fl_Fix2Float(sint32 in, sint32 in_pos );
EXTERN sint32 si32_Float2Fix( FLOAT in, sint32 out_pos);
#endif /* use FEB Common Function *//* B02E VC2 n_common�ւ̎������Ԃɍ����Ă��Ȃ����߃A�v�����ɓ���Ă��� */
#if 1 /* adas31_ldp */
/* �����O�o�b�t�@���� */
EXTERN void v_PushRingBuff(sint32 data,  T_RING_BUFF *ring);
EXTERN sint32 si32_GetRingBuff(uint16 pos, T_RING_BUFF *ring);
#endif


#undef EXTERN
#endif /* __FEB_COMMON_FUNC_H__ */
