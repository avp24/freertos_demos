/****************************************************************************************************/
/*	Copyright (c) 2014 Nissan, Japan																*/
/****************************************************************************************************/

#ifndef	__DBA_func__
#define	__DBA_func__

#include "data_types.h"
#include "n_common.h"
#include "DBA_type.h"

/*--------------------------------------------------------------------------------------------------*/
/*	DBA�֐�																							*/
/*--------------------------------------------------------------------------------------------------*/
/*---- DBAControl.c						--------*/
extern	void	DBAControl( void );

/*---- DBADataIn.c						--------*/
extern	void	DBADataIn( void );

/*---- DBADataOut.c						--------*/
extern	void	DBADataOut( void );

/*---- DBA_flgset.c						--------*/
extern	void	DBA_flgset( void );

/*---- DBA_DIST_TAR_0_update.c			--------*/
extern	sint32	vDBA_DIST_TAR_0_update(
								const	sint32	vr,				/*	���Α��x	LSB:2^-16[m/s]	*/
								const	uchar8	fdba_max_brk );	/*	�ِ��������f	*/

/*---- DBA_CTRL_MODE_judge.c			--------*/
extern	uchar8	fDBA_ON_JUDGE_update(
								const uchar8 fbpfs_on,
								const uchar8 ffcw_warn,
#if	1	/* 2016.10.28 J32U JNCAP�Ή� *///160905 T.Inoue
								const uchar8 fvehicle_ba_temp,	/* 161018 T.Inoue */
								const uchar8 ffeb_warn,
#endif
								const uint16 pressure_sens,
								const sint16 long_acc,
#if	1	/* 2016.10.28 J32U JNCAP�Ή� *///160922 T.Inoue
								const uint8 vfca_ctrl_mode,
								const sint16 apo_angl,
								const sint32 target_acc );
#else
								const sint16 apo_angl );
#endif
extern uchar8 fDBA_OFF_JUDGE_update(const uchar8 fbpfs_on,
								const uint16 pressure_sens,
#if 0// ������ 160922 T.Inoue //160909 T.Inoue
								const sint16 apo_angl,
								const sint32 target_acc);
#elif 1 //iBooster �Ή�
								const sint16 apo_angl,
								const sint32 vr,
								const sint32 vdist);

#else
								const sint16 apo_angl );
#endif
extern	void	vDBA_CTRL_MODE_update(
								const sint32 dist,
								const sint32 vrel,
								const sint32 vsp,
								const sint32 dist_tar0,
								const uchar8 dba_ready,
								const uchar8 full_brk,
								const uchar8 on_judge,
								const uchar8 off_judge,
								const uchar8 dist_prmt );

/*---- DBA_BRK_judge.c					--------*/
extern	uchar8	FAIL_SOKU_DBA_judge( void );
extern	uchar8	FAIL_JOJO_DBA_judge( void );
extern	uchar8	FAIL_JOJO_TMP_DBA_judge( void );
extern	uchar8	BRK_INH_DBA_judge( void );
extern	uchar8	BRK_LOST_DBA_judge( void );

/*---- DBA_flgset.c						--------*/
extern	void	DBA_flgset( void );

/*---- DBA_CTRL_MODE_main.c				--------*/
extern	void	DBA_CTRL_MODE_main( void );

/*---- CONT_CLR_JUDGE_DBA_main.c		--------*/
extern	void	CONT_CLR_JUDGE_DBA_main( void );

/*---- VSP_CMD_DIST_DBA_main.c			--------*/
extern	void	VSP_CMD_DIST_DBA_main( void );

/*---- VSP_CMD_DIST_SEL_calc.c			--------*/
extern	sint32	DBA_VSP_CMD_DIST_SEL_calc( const uchar8 ctrl_type, const sint32 vsp_cmd_dist );

/*---- VSP_CMD_DBA_main.c				--------*/
extern	void	VSP_CMD_DBA_main( void );

/*---- VSERVO_DBA_main.c				--------*/
extern	void	VSERVO_DBA_main( void );

/*---- DBA_BRK_main.c					--------*/
extern	void	DBA_BRK_main( void );


/*--------------------------------------------------------------------------------------------------*/
/*	DBA Get�֐�																						*/
/*--------------------------------------------------------------------------------------------------*/
/*---- DBADataOut.c						--------*/
extern	const	DBAStatus* getDBAStatus( void );

/*---- DBA_BRK_CMD_main.c				--------*/
extern	const	sint32	get_DBA_BRK_CMD( void );
extern	void	DBA_BRK_CMD_main( void );

/*---- CONT_CLR_JUDGE_DBA_main.c		--------*/
extern	uchar8	get_DIST_CONT_CLEAR_DBA( void );
extern	uchar8	get_VSP_CONT_CLEAR_DBA( void );

/*---- VSP_CMD_DIST_DBA_main.c			--------*/
extern	sint32	get_VSP_CMD_DIST_DBA( void );

/*---- VSP_CMD_DBA_main.c				--------*/
extern	sint32	get_VSP_CMD_DBA( void );

/*---- VSERVO_DBA_main.c				--------*/
extern	const	vservo*	get_VSERVO_DBA( void );

/*---- DBA_BRK_main.c					--------*/
extern	uchar8	get_DBA_BRK_STATE( void );

/*---- DBA_CTRL_MODE_main.c					--------*/
extern	uchar8	get_DBA_OFF_JUDGE( void );

#endif	/*__DBA_func__*/
