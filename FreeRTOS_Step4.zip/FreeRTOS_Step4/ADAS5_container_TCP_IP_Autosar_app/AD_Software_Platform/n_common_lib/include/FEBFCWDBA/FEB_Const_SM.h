/*******************************************************************************
 *
 *     Copyright (c) 2020 Nissan, Japan
 *
 *******************************************************************************
 *
 * Project:
 * Module:     Forward Emergency Braking for Safety Module
 * Version      0.1
 * Author:
 * Date:
 *
*******************************************************************************/
#ifndef	__FEB_CONST_SM_H__
#define	__FEB_CONST_SM_H__

#include "FEB_Const.h"

#endif
