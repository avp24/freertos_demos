/*******************************************************************************
 *
 *     Copyright (c) 2013 Nissan, Japan
 *
 *******************************************************************************
 *
 * Project:
 * Module:      Forward Emergency Braking
 * Version      0.1
 * Author:
 * Date:
 *
 *******************************************************************************/
#ifndef	__FEB_DEFINES__
#define __FEB_DEFINES__

/*******************************************************************************/
/* INCLUDE FILES								                               */
/*******************************************************************************/
#if	0	/* ADAS2->3 delete */
#include	"n_apl_common.h" /* Added for FLOAT typedef */


#include	"UTYPEDEF.h"
#endif
/*******************************************************************************/
/* MACROS								                             		   */
/*******************************************************************************/
#define 		FEB_ZERO			(0)
#define 		FEB_ONE				(1)
#define			FEB_TWO				(2)
#define 		FEB_THREE			(3)
#define 		FEB_FOUR			(4)
#define 		FEB_FIVE			(5)
#define 		FEB_SIX				(6)
#define 		FEB_SEVEN			(7)
#define 		FEB_EIGHT			(8)
#define 		FEB_NINE			(9)
#define 		FEB_TEN				(10)
#define 		FEB_TWELVE			(12)
#define 		FEB_SIXTEEN			(16)
#define 		FEB_TWENTY_TWO		(22)
#define 		FEB_TWENTY_THREE	(23)
#define 		FEB_TWENTY_FOUR		(24)
#define 		FEB_TWENTY_FIVE		(25)
#define 		FEB_THIRTY_ONE		(31)
#define 		FEB_THIRTY_TWO		(32)
#define			FEB_FOURTY_ONE      (41)

#define 		FEB_FL_ZERO		(0.f)
#define 		FEB_FL_ONE		(1.f)
#define 		FEB_FL_TWO		(2.f)
#define 		FEB_FL_THREE	(3.f)

#define			FEB_SET			(1u)
#define			FEB_RESET		(0u)
#define			FEB_OFF			((uchar8)0)

#if 0	/* 20150113 �t�F�[���Z�[�t����̂��ߏꏊ���ړ� */
#define 		FEB_FS_BRK_OFF		   (0x01u)     									/* Brake already released */
#define 		FEB_FS_BRK_SLOW		   (0x02u)										/* Brake gradual release */
#define 		FEB_FS_BRK_KEEP		   (0x04u)										/* Brake continued */
#define 		FEB_FS_BRK_HOJI		   (0x08u)										/* Brake maintain */
#define 		FEB_FS_BRK_FAST		   (0x10u)										/* Brake Quick gradual release */
#define 		FEB_FS_BRK_STANDARD	   (0x20u)										/* Brake Standard gradual release */
#define 		FEB_FS_BRK_INH		   (0x40u)										/* Brake Prohibited */
#define 		FEB_FS_BRK_OFF_INH	   (FEB_FS_BRK_OFF | FEB_FS_BRK_INH)			/* Brake already released */
#define 		FEB_FS_BRK_SLOW_INH	   (FEB_FS_BRK_SLOW	| FEB_FS_BRK_INH)			/* Brake gradual release */
#define 		FEB_FS_BRK_FAST_INH	   (FEB_FS_BRK_FAST	| FEB_FS_BRK_INH)			/* Brake Quick gradual release */
#define 		FEB_FS_BRK_STANDARD_INH	(FEB_FS_BRK_STANDARD | FEB_FS_BRK_INH)		/* Brake Standard gradual release */
#endif

/* ---< @@ Label of St_FailAct_FCA.U08_Etq  @@ >--- */
#define FEB_FS_ETQ_APO		0x01u	/* Required accelerator opening speed gradual release */
#define FEB_FS_ETQ_INH		0x02u	/* Required accelerator opening speed prohibition */



#define 	BIT_RATE_2_PWR_0		(1.f)
#define		BIT_RATE_2_PWR_3		(8.f)
#define		BIT_RATE_2_PWR_4		(16.f)
#define 	BIT_RATE_2_PWR_7		(128.f)
#define		BIT_RATE_2_PWR_8		(256.f)
#define		BIT_RATE_2_PWR_10		(1024.f)
#define		BIT_RATE_2_PWR_12		(4096.f)
#define		BIT_RATE_2_PWR_13		(8192.f)
#define		BIT_RATE_2_PWR_14		(16384.f)
#define		BIT_RATE_2_PWR_16		(65536.f)
#define		BIT_RATE_2_PWR_18		(262144.f)
#define		BIT_RATE_2_PWR_22		(4194304.f)
#define		BIT_RATE_2_PWR_23		(8388608.f)

#define		SINT32_MAX_LIMIT_BR22	(511.99f)				/* SINT32MAX/2^22 i.e 2147483647/4194304 */
#define		SINT32_MIN_LIMIT_BR22	(-512.f)				/* SINT32MIN/2^22 i.e -2147483648/2^22  */

#define		SINT32_MAX_LIMIT_BR16	(32767.99998f)			/* SINT32MAX/2^16 i.e 2147483647/65536 */
#define		SINT32_MIN_LIMIT_BR16	(-32768.f)				/* SINT32MIN/2^16 i.e -2147483648/65536 */

#define		SINT32_MAX_LIMIT_BR8	(8388607.996094f)		/* SINT32MAX/2^8 i.e 2147483647/256 */
#define		SINT32_MIN_LIMIT_BR8	(-8388608.f)		    /* SINT32MIN/2^8 i.e -2147483648/256  */

#define		SINT16_MAX_LIMIT_BR08	(127.996f)				/* SINT16MAX/2^8 i.e 32767/256 */
#define		SINT16_MIN_LIMIT_BR08	(-128.f)				/* SINT16MIN/2^8 i.e -32768/256 */
 
#define	iFCA_TTC_STR_YOKO_y_shift	 256	                /*2^8*/  
#define iFCA_TTC_STR_YOKO_x_SIZE     11						 
#define iT_DRV_REACT_BRK_x_SIZE      14						
#define iFCA_DEC_REACT_X_SIZE        17					
#define iFCA_DEC_REACT_hosei_X_SIZE  13					
#define	iL_SHIFT_10					 1024	                /*2^10*/   
#define iDEC1_SLOPEhosei_X_SIZE	     13						
#define	iFCA_MARGIN_MAP_shift        4	                    /*mFCAA_MARGIN_MAP_y��vFCA_MARGIN��LSB�ɕύX 2^-14��2^-16*/ 
#define iFCA_MARGIN_MAP_x_SIZE       14     
#define iMAX_BRK_TH_MAP_SIZE         16						/* �t�������ԑ�����臒l�}�b�v�T�C�Y */

/* ADAS3.1 20151109 S.Hiko n_common.h����ڐA */
#define	WASTE_TIME_MAX	41				/*ACC,DCA ACCREF���ʎ��ԗp�z��(400msec�܂őΉ���40+1)*/
#define iNUM_REF 		WASTE_TIME_MAX	/*��޽�LPF�o�͒l�ߋ��l�ێ���*/	/*400msec�܂ŗp��*/	/*[ADAS03]*/
#define iNUM_REF_SUB2 	10			//��޽�LPF�o�͒l�ߋ��l�ێ���		//[IAS05]
#define iNO_RELE 		0xFF		//�S�Ă�relevant�׸ނ�OFF�̎���relevant No		//[IAS03]

/* ADAS3.1 20151109 S.Hiko sysinfo.h����ڐA */
#define iBRK_0MPa			(0u)									/* �t�� 0MPa�o�� */
#define iBRK_SOKU			(1u)									/* �t�������� */
#define iBRK_INIT			(1u)									/* �t�������� */
#define iBRK_ACT_ON			(2u)									/* �ʏ�u���[�L���� */
#define iBRK_ACT_OFF		(3u)									/* �u���[�L�������� */
#define iBRK_STOP_RELEASE	(4u)									/* �X�g�b�v���[�h�������(�A�N�Z���I�[�o�[���C�h) */
#define iBRK_ACT_OVR		(5u)									/* �A�N�Z���I�[�o�[���C�h���� */
#define iBRK_STOP			(6u)									/* �X�g�b�v���[�h���� */
#define iBRK_KEIZOKU		(7u)									/* �p������ */
#define iBRK_JOJO			(8u)									/* �L�����Z���E�t�F�[���ɂ��������X�������� */
#define iBRK_JOJO_ADJ		(9u)									/* �X�g�b�v���[�h����̃L�����Z���E�t�F�[���ɂ��������X�������� */

/* Task #32672 */
enum {
	iPRCDNG_ACC,		/* 0�FACC			   */
	iPRCDNG_DCA,		/* 1�FDCA			   */
	iPRCDNG_FCW_MOV,	/* 2�FFCW�ړ��� 	   */
	iPRCDNG_FCW_STP,	/* 3�FFCW��~�� 	   */
	iPRCDNG_IBA_MOV,	/* 4�FIBA�ړ��� 	   */
	iPRCDNG_IBA_STP,	/* 5�FIBA��~�� 	   */
	iNUM_APPLICATION	/* 6�F��s�Ա��؍ő吔 */
};

#endif
