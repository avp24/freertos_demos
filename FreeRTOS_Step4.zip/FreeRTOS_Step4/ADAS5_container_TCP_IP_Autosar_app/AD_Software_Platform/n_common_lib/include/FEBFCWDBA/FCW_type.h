/*******************************************************************************
 *
 *     Copyright (c) 2013 Nissan, Japan
 *
 *******************************************************************************
 *
 * Project:
 * Module:      Forward Collision Warning     
 * Version      0.1
 * Author:
 * Date:
 *
*******************************************************************************/	
#ifndef	__fcw_type__
#define	__fcw_type__
/*******************************************************************************/
/* INCLUDE FILES								                               */
/*******************************************************************************/
#if 1	/* ADAS2->3 change */
#include	"data_types.h"
#include	"n_common.h"
#else
#include	"can_type.h"
#include	"MB_type.h"
#include	"InsideManageIF.h"
#endif
/*******************************************************************************/
/* MACRO DEFINITION  							              		  		   */
/*******************************************************************************/
#define	iABST_BIN_POINT	16
#define	iDIST_LSB_FCW	22
#define	iFCW_SHIFT_BUZ_WARN	4
#define	iFCW_SHIFT10		1024
#if 0	/* ADAS2->3 delete */
#define iLsb16			16
#endif
#define	iMSK_VSV_LSB	12		/*Leading vehicle acceleration ratio for warning calculation (Mask)	*/
#define	iMSK_DIST_LSB	12		/*Leading vehicle acceleration ratio  offset coefficient (Vehicle distance)	*/
#define	iMSK_DSV_LSB	10		/*Own vehicle acceleration for warning calculation (Mask)	*/
#define	iMSK_DPOV_LSB	10		/*Leading vehicle acceleration for warning calculation (Mask)	*/
#define	iPARA_VSV_LSB	19		/*Own vehicle speed */
#define	iPARA_VPOV_LSB	19		/*Leading vehicle speed*/
#define	iPARA_DSV_LSB	22		/*Own vehicle acceleration rate	 */
#define	iPARA_DPOV_LSB	22		/*Leading vehicle acceleration rate	*/
#define	iPARA_VR_LSB	19		/*Own vehicle acceleration rate	*/
#define	iPARA_DVR_LSB	22		/*Relative acceleration rate*/
#if 1	/* ADAS2->3 add */
#define			FCW_SET			(1u)
#define			FCW_RESET		(0u)
/*#define			FCW_OFF			((uchar8)0)*//* ADAS3.1 20160118 S.Hiko �g���Ă��Ȃ�����Warning�΍�ō폜 */

#endif

#ifndef ON
#define ON	(NAP_ON)
#endif
#ifndef OFF
#define OFF	(NAP_OFF)
#endif

/*******************************************************************************/
/* VARIABLE DECLARATIONS 													   */
/*******************************************************************************/
typedef struct
{
	sint32		FLT_VSV;			/* Base own vehicle speed for warning calculation LSB:2^-22m/s	*/
	sint32		FLT_VPOV;			/* Base leading vehicle speed for warning calculation LSB:2^-22m/s	*/
	sint32		FLT_DSV;			/* Base own vehicle speed for warning calculation LSB:2^-22m/ss	*/
	sint32		FLT_DPOV;			/* Base leading vehicle speed for warning calculation LSB:2^-22m/ss	*/
} fcw_filt;

/* warn_distance_calc() */
typedef struct
{
	uchar8		mcond_mask;
	sint32		( *func_dist )(void);
	sint32		*mcoef;
} dist_calc_item;

typedef struct
{
	sint16		MSK_VSV;
	sint16		MSK_DIST;
	sint16		MSK_DSV;
	sint16		MSK_DPOV;
} fcw_mask;

typedef struct
{
	sint16		TP;
	sint16		TS;
	sint16		TM;
	sint16		HYS_HI;
	sint16		HYS_LO;
	sint16		HYS_FCT;
} fcw_warn;

typedef struct
{
	uchar8		fVR		:1	;
	uchar8		fTPOV	:1	;
	uchar8		fTSV	:1	;
	uchar8		fTCOL	:1	;
	uchar8		fCMPR	:1	;
	uchar8		Fu		:3	;
} s_rng;

typedef struct
{
	sint32	DPOV_TCOL_VPOV;
	sint32	DPOV_TCCON_VPOV;
	sint32	VPOV;
} vpov_end;

typedef struct
{
	sint32		VSV_TSV_ABST;		/*Own vehicle speed integrated distance	LSB:2^-16[m]	*/
	sint32		VPOV_TPOV_ABST;		/*Leading vehicle speed integrated distance LSB:2^-16[m]	*/
	sint32		VR_TCOL_ABST;		/*Collision avoidance operation time integrated distance LSB:2^-16[m]	*/
	sint32		VSV_TCCON_ABST;		/*Own vehicle speed stop time integrated distance  LSB:2^-16[m]	*/
	sint32		VPOV_TCCON_ABST;	/*Leading vehicle speed stop time integrated distance LSB:2^-16[m]	*/
	sint32		VR_TCCON_ABST;		/*free running time integrated distance	LSB:2^-16[m]	*/
	sint32		BRK_BETA_TSV;		/*Assumed deceleration rate own vehicle stop time integrated distance LSB:2^-16[m]	*/
	sint32		BRK_BETA_TCOL;		/*Assumed deceleration rate collision avoidance time integrated distance LSB:2^-16[m]	*/
	sint32		BRK_BETA_TCCON;		/*Assumed deceleration rate free running time integrated distance	LSB:2^-16[m]	*/
} fcw_abst_s;

	
typedef struct
{
	sint32		PARA_VSV;			/*Own vehicle speed	LSB:2^-19[m/s]	*/
	sint32		PARA_VPOV;			/*Leading vehicle speed	LSB:2^-19[m/s]	*/
	sint32		PARA_DSV;			/*Own vehicle acceleration rate	LSB:2^-22[m/ss]	*/
	sint32		PARA_DPOV;			/*Leading vehicle acceleration rate	LSB:2^-22[m/ss]	*/
	sint32		PARA_VR;			/*Relative speed LSB:2^-19[m/s]	*/
	sint32		PARA_DVR;			/*Relative acceleration rate LSB:2^-22[m/ss]	*/
	sint32		PARA_TSV;			/*Own vehicle stop time	LSB:2^-16[s]	*/
	sint32		PARA_TPOV;			/*Leading vehicle stop time LSB:2^-16[s]	*/
	sint32		PARA_TCOL;			/*Collision avoidance time LSB:2^-16[s]	*/
	sint32		PARA_TCCON;			/*Warning time between vehicles	LSB:2^-16[s]	*/
	sint32		PARA_vS;			/*Warning distance between vehicles	LSB:2^-16[s]	*/
	uchar8		PARA_dSTATUS;		/*Warning vehicle distance calculation status LSB:1	*/
} fcw_para;



typedef	struct
{
	uchar8		f_FCW_STOP_OBJ_LOCK2	:1	;	/* 8  Moving object lock flag for FCW 2	*/
	uchar8		f_FCW_STOP_OBJ_1		:1	;	/* 6  Stopped vehicle lock flag (Before calculating predicted position)	*/
	uchar8		fWidthUnfitWd			:1	;	/* 5-1 Breadth mismatching flag time lapse flag	*/
	uchar8		fAmpHolWd				:1	;	/* 5-1AMP_HOL flag time lapse flag	*/
	uchar8		fAmpWHolWd				:1	;	/* 5-1AMP_WHOL flag time lapse flag	*/
	uchar8		fu22					:1	;	/* reserve */
	uchar8		fu21					:1	;	/* reserve	*/
	uchar8		fNReliabilityPv			:1	;	/* 5-2 leading vehicle not confirmed flag */

	uchar8		fu_17					:1	;	/* reserve	*/
	uchar8		fWidthUnfit				:1	;	/* 5 Breadth mismatching flag time lapse flag	*/
	uchar8		fAmpHol					:1	;	/* 5 AMP_HOL flag time lapse flag	*/
	uchar8		fAmpWHol				:1	;	/* 5 AMP_WHOL flag time lapse flag	*/
	uchar8		fHABA_CANCEL			:1	;	/* 4-1Breadth not detected flag	*/
	uchar8		fPeakCancel				:1	;	/* 4  Peak not detected flag */
	uchar8		fFcwStopObjHaba			:1	;	/* 3-2Breadth judgment stopped vehicle flag	*/
	uchar8		fFcwStopObjPeak			:1	;	/* 3-1Peak judgment stopped vehicle flag */

}target_lock_f;


typedef	struct
{
	
	target_lock_f	f;

	

	sint32		STOP_VEHICLE_REC_DIST;	/* 2-1 Own vehicle in lane stay distance */
	uint16		REC_DIST_HOLD_CNT;		/* 2-1 Own vehicle judgment hold timer	*/
	uint16		vMON_DIST_PK_INCCNT;	/* 2-2 Peak detection increment counter lower limit value */
	uint16		vMON_DIST_WD_INCCNT;	/* 2-2Breadth detection increment counter lower limit value	*/
	sint32		THRESH_CURVE;			/* 2-1 Curve radius	*/
	uint16		CNT_PEAK_DETECT;		/* 3-1 Peak detection counter*/
	uint16		PEAK_CANCEL_TIMER;		/* 3-1 Peak not detected timer */
	uint16		VSP_DIST_INCCNT;		/* 3-1 Counter increase ratio for stopped vehicle detection	*/
	sint32		vMIN_ST_HABA;			/* 3-2 Lower limit value for breadth judgment	*/
	sint32		vMAX_ST_HABA;			/* 3-2 Upper limit value for breadth judgment	*/
	sint32		STOP_V_REC_THRESH;		/* 3-2 Own vehicle in lane stay judgment threshold value */
	uint16		STOP_HABA_INCCNT;		/* 3-2 Breadth judgment counter increase ratio	*/
	uint16		CNT_ST_OBJ;				/* 3-2 Breadth judgment stopped vehicle counter	*/
	uint16		CNT_CANCEL_HABA;		/* 3-2 Breadth not detected counter	*/
	uint16		CNT_PEAK_CANCEL;		/* 4  Peak cancel counter	*/
	uint16		CNT_HABA_CANCEL;		/* 4-1Breadth judgment cancel countet	*/	
	uint16		CNT_WIDTH_UNFIT;		/* 5  Breadth not matching flag time lapse counter	*/
	uint16		CNT_AMP_HOL;			/* 5  AMP_HOL flag time lapse counter */
	uint16		CNT_AMP_WHOL;			/* 5  AMP_WHOL flag time lapse counter	*/
	uint16		CNT_WIDTH_UNFIT_WD;		/* 5-1 Breadth not matching flag time lapse counter	*/
	uint16		CNT_AMP_HOL_WD;			/* 5-1AMP_HOL flag time lapse counter	*/
	uint16		CNT_AMP_WHOL_WD;		/* 5-1AMP_WHOL flag time lapse counter */
	sint32		vR_OBJ_pos;				/* 7  Relative position of entity(2^-12m) */
	sint32		vR_OBJ_REL_POS_FCW;		/* 7  Relative position of entity for gyrating radius of own vehicle(2^-12m) */
}target_lock_info;


typedef	struct																
{
	uchar8		fFCW_FUNC_ENABLE	:1;		/* FCW operation permission flag */
	uchar8		fFCW_FAIL			:1;		/* FCW fail flag */
	uchar8		fDISP_BLIC_FCW		:1;		/* FCW indicator blinking flag */
	uchar8		FCW_SWmode_Main		:1;		/* FCW main SW flag	 */
	uchar8		Buzzer_Sound;				/* Buzzer sound	*/
	uchar8		fFCW_VSP_ENABLE;			/* Warning permission flag (vehicle speed) *//* 20211004 �Ε��s��FCW�x��Ή� */
}FCWStatus;


typedef	struct
{
	sint32	vVR_PRE_INFO;
	sint32	vABST_PRE_INFO;
	uchar8	fLOCK_PRE_INFO;
}preinfo_datain;

/*******************************************************************************/
/* ENUM DECLARATIONS 											   		       */
/*******************************************************************************/
enum
{
	iNO_TARGET,					/* No target(0) */
	iMOVE_TARGET,				/* Target moving object (1) */
	iSTOP_TARGET,				/* target stopped object (2) */
	iTARGET_TYPE_num			/* target type count (3) */
};


/*	enum definition for buzzer (Buzzer_Sound)	*/
enum																
{
	iFCW_BUZ_FAIL,			/* Fail flag  (BIT0)*/
	iFCW_BUZ_CANC,			/* Cancel flag (BIT1)*/
	iFCW_BUZ_WARN,			/* FCW warning	 (BIT2)	*/
	iFCW_BUZ_EVT_NUM		/* Maximum count */
};
/*******************************************************************************/
/* FUNCTION DECLARATIONS 													   */
/*******************************************************************************/
extern	const FCWStatus	*getFCWStatus(void);
extern	uchar8	BUZZER_FCW_FAIL_judge(void);
extern	uchar8	BUZZER_FCW_CANCEL_judge(void);
extern	uchar8	BUZZER_FCW_WARN_judge(void);
#if 1	/* ADAS2->3 add */
extern	void	PrecedingInfoCollection( sint32 * const, sint32 * const, const preinfo_datain *const, const preinfo_datain *const, const preinfo_datain *const);		/*[ADAS04][ADAS05]*/
#endif
#endif
/**********************************EOF******************************************/