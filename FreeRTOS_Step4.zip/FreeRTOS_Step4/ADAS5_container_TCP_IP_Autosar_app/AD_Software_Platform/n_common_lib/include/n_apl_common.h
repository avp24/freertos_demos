/******************************************************************************
 *
 *     Copyright (c) 2007 Nissan, Japan
 *
 ******************************************************************************
 *
 * Project:     
 * Module:      ���Y�����\�t�g���ʊ֐����C�u����
 * Version      1.0
 * Author:      
 * Date:        
 * Description: 
 * Revision History:
 *
******************************************************************************/
#ifndef __N_APL_COMMON_H__
#define __N_APL_COMMON_H__

#ifdef __N_APL_COMMON_C__
#define EXTERN
#else
#define EXTERN  extern
#endif

#include "utypedef.h"

/* -------------------------------------------- */
/* �}�N���錾                                   */
/* -------------------------------------------- */
#define NAP_OFF (0U)
#define NAP_ON  (1U)

#ifndef NULL
#define NULL ( (void*)0 )
#endif

#define	NAP_FLOAT_ZERO	(0.F)
#define	NAP_FLOAT_MAX	(3.402823466e+38F)
#define	NAP_FLOAT_MIN	(-NAP_FLOAT_MAX)

#define NAP_FL_PLUS_NEAR_ZERO   (0.00000000001F)
#define NAP_FL_MINUS_NEAR_ZERO (-0.00000000001F)

#define NAP_PI      (3.1415926535898f)
#define NAP_HALF_PI (1.5707963267949f)

/* ---------------------------------------- */
/* �C���W�P�[�^�A�u�U�[�X�e�[�^�X           */
/* ---------------------------------------- */
#define NAP_IDLE (NAP_OFF)       /* �_��1��������    */
#define NAP_BUSY (NAP_ON)        /* �_�Ŏ��s��       */

/* -------------------------------------------- */
/* 2�����p MAP                                  */
/* -------------------------------------------- */
typedef struct{
    sint32  x;
    sint32  y;
}T_2D_MAP_BODY;
typedef struct{
    uint32      x_size;
    const T_2D_MAP_BODY  *body;
}T_2D_MAP;

typedef	struct{
	uint32	x_size;
	sint32	*x_table;
	uint32	y_size;
	sint32	*y_table;
	sint32	*z_table;
}T_3D_MAP;

typedef struct{
    FLOAT  x;
    FLOAT  y;
}T_FL_2D_MAP_BODY;
typedef struct{
    uint32      x_size;
    const T_FL_2D_MAP_BODY  *body;
}T_FL_2D_MAP;

typedef struct{
    uint16 Pos;
    uint16 Size;
    FLOAT *Buff;
}T_RING_BUFF_FL;
/* -------------------------------------------- */
/* 3�����p MAP                                  */
/* -------------------------------------------- */
typedef struct{
    uint32  x_size;
    FLOAT   *x;
    uint32  y_size;
    FLOAT   *y;
    FLOAT   *z;
}T_FL_3D_MAP;

/* -------------------------------------------- */
/* ���[�p�X�t�B���^�p                           */
/* -------------------------------------------- */
typedef struct{
    sint32 val;
    sint32 pos;
}T_LPF_VAL;

typedef struct{
    T_LPF_VAL   A;
    T_LPF_VAL   B;
}T_LPF_PARAM;

/* -------------------------------------------- */
/* �����O�o�b�t�@�p                             */
/* -------------------------------------------- */
typedef struct{
    uint16  Pos;
    uint16  Size;
    sint32  *Buff;
}T_RING_BUFF;

typedef struct{
    uint16 Pos;
    uint16 Size;
    sint16 *Buff;
}T_RING_BUFF_S16;

typedef struct{
    uint16 Pos;
    uint16 Size;
    uint16 *Buff;
}T_RING_BUFF_U16;

/* -------------------------------------------- */
/* IEEE 754 �P���x?(32bit)                      */
/* -------------------------------------------- */
typedef union{
    uint32  l;
    FLOAT   f;
}U_IEEE_754_32BIT;

/* -------------------------------------------- */
/* ON/OFF�p�^�[��                               */
/* -------------------------------------------- */
typedef struct{
    const uint16 *Time;           /* On/Off �p������  */
    uint8   Out;            /* �o��             */
    uint8   Next;           /* ���Ԍo�ߌ�̎��̏�Ԕԍ� */
    uint8   Chara;          /* ���̑��̑���             *//* bp7: �J�n��ԁAbp0: �ŏI��� */
}T_ON_OFF_PATTERN;
#define CHAR_NONE    (0x00)
#define CHAR_START   (0x80)
#define CHAR_END     (0x01)

#define NO_NEXT_WITH_OFF  (0xFF)
#define NO_NEXT_WITH_ON   (0xFE)

#define    NAP_DISABLE  ((uint8)0U)
#define    NAP_ENABLE   ((uint8)1U)

#define BUZZ_UNLIMIT (0x00)

#define NAP_SET     (NAP_ON)
#define NAP_RESET   (NAP_OFF)

#if	0	/* 2013.08.06 J42H����ڐA */
typedef struct{
    uint32 target;
    uint32 now;
    uint32 old;
    uint8  *stat_ptr;
    uint16  thresh_cnt;
}T_NIF_ChecFlagIn;
#endif

/* -------------------------------------------- */
/* �}�N���֐��錾                               */
/* -------------------------------------------- */
#define ARRAY_NUM(A)   ( (sizeof(A)) / (sizeof(A[0])) )

#ifndef NULL
#define NULL ((void*)0)
#endif
EXTERN const uint8 *pNIF_VerInfoPtr;
#define  NIF_DEF_PI (3.1415926f)
#define  NIF_DEF_DEG2RAD    (3.1415926535897932f/180.f)      //DEG �� RAD �ϊ�
#if	1	/* 2013.08.06 J42H����ڐA */
#define  NIF_DEF_G      (9.8f)          /* G -> m/(s^2) CONVERT */
#endif
/* -------------------------------------------- */
/* �v���g�^�C�v�錾                             */
/* -------------------------------------------- */
EXTERN uint8 ui8_GetFPSCR_Cause(void);
EXTERN sint32 n_CalcSint32Mul(sint32 x, sint32 x_pos, sint32 y, sint32 y_pos, sint32 *z, sint32 z_pos);
EXTERN sint32 n_CalcSint32Div(sint32 x, sint32 x_pos, sint32 y, sint32 y_pos, sint32 *z, sint32 z_pos);
EXTERN sint32 si32_LowPassFilter( sint32 x, sint32 x_pos, sint32 y_z, sint32 y_z_pos,const T_LPF_PARAM *param, sint32 out_pos);
EXTERN void v_SetAllRingBuff(sint32 val, T_RING_BUFF *in);
EXTERN void v_ClearRingBuff( T_RING_BUFF *ring );
EXTERN void v_PushRingBuff(sint32 data,  T_RING_BUFF *ring);
EXTERN sint32 si32_GetRingBuff(uint16 pos, T_RING_BUFF *ring);

EXTERN void v_SetAllRingBuffS16(sint16 val, T_RING_BUFF_S16 *in);
EXTERN void v_ClearRingBuffS16( T_RING_BUFF_S16 *ring );
EXTERN sint16 si16_GetRingBuffS16(uint16  pos, T_RING_BUFF_S16 *ring);
EXTERN void v_PushRingBuffS16(sint16 data,  T_RING_BUFF_S16 *ring);

EXTERN void v_SetAllRingBuffU16(uint16 val, T_RING_BUFF_U16 *in);
EXTERN void v_ClearRingBuffU16( T_RING_BUFF_U16 *ring );
EXTERN void v_PushRingBuffU16(uint16 data,  T_RING_BUFF_U16 *ring);
EXTERN uint16 ui16_GetRingBuffU16(uint16  pos, T_RING_BUFF_U16 *ring);

EXTERN sint32 si32_Read2DMap(sint32 x, const T_2D_MAP *map);
EXTERN sint32 si32_CalcAverage(sint32 num, T_RING_BUFF *buff);
EXTERN sint32 si32_CalcAbs(sint32 in);
EXTERN sint32 si32_SelectMax( sint32 a, sint32 b );
EXTERN sint32 si32_SelectMin( sint32 a, sint32 b );
EXTERN sint32 si32_FiltMaxMin( sint32 in, sint32 max, sint32 min);
EXTERN uint16 ui16_IncCount(uint16 count,uint16 max);
EXTERN uint16 ui16_DecCount(uint16 count);
EXTERN uint32 ui32_IncCount(uint32 count,uint32 max);
EXTERN uint32 ui32_DecCount(uint32 count);
EXTERN sint32 si32_SelectMinN(sint32 *in, sint32 num);
EXTERN sint32 si32_SelectMaxN(sint32 *in, sint32 num);
EXTERN uint32 ui32_IncCount2(uint32 count,uint32 max, uint32 init);
EXTERN uint8 ui8_DecCount2(uint16 *cnt, uint8 reset_req, uint16 reset_val);
EXTERN uint8 ui8_DelChatter(uint8 now, uint8 old, uint16 *cnt, uint16 on_thresh, uint16 off_thresh);
EXTERN uint8 ui8_ActOnOff(uint8 *out,uint8 *mode, const T_ON_OFF_PATTERN * const pat, uint16 *cnt);
EXTERN uint16 ui16_AddCnt(uint16 count, sint16 addval, uint16 max);

EXTERN uint8  ui8_CheckFlagEdge(uint8 now, uint8 old, uint8 edge_type);
#define CHECK_UP_EDGE     (0)
#define CHECK_DOWN_EDGE   (1)
#define CHECK_UPDOWN_EDGE (2)

EXTERN uint8 ui8_NIF_Make_CRC_8_SAE_1850(uint8 *in, uint32 size);
EXTERN uint32 unNIF_Check_CRC_8_SAE_1850(uint8 orig_crc, uint8 *in, uint32 size);
EXTERN FLOAT fl_Fix2Float(sint32 in, sint32 in_pos );
EXTERN sint32 si32_Float2Fix( FLOAT in, sint32 out_pos);
EXTERN DOUBLE db_Fix2Double(sint32 in, sint32 in_pos );
EXTERN sint32 si32_Double2Fix( DOUBLE in, sint32 out_pos);

EXTERN FLOAT fl_Read2DMap(FLOAT x, const T_FL_2D_MAP *map);
EXTERN FLOAT fl_Read3DMap(FLOAT x, FLOAT y, const T_FL_3D_MAP *map);
EXTERN sint32 si32_ReadHi2DMap(sint32 *output_table, sint32 *input_table, sint32 x, uint32 x_size);
EXTERN FLOAT fl_ReadHi2DMap(FLOAT *output_table, FLOAT *input_table, FLOAT x, uint32 x_size);

EXTERN FLOAT fl_CalcFlAdd(FLOAT a, FLOAT b);
EXTERN FLOAT fl_CalcFlSub(FLOAT a, FLOAT b);
EXTERN FLOAT fl_CalcFlMul(FLOAT a, FLOAT b);
EXTERN FLOAT fl_CalcFlDiv(FLOAT a, FLOAT b);
EXTERN DOUBLE db_CalcDbAdd(DOUBLE a, DOUBLE b);
EXTERN DOUBLE db_CalcDbSub(DOUBLE a, DOUBLE b);
EXTERN DOUBLE db_CalcDbMul(DOUBLE a, DOUBLE b);
EXTERN DOUBLE db_CalcDbDiv(DOUBLE a, DOUBLE b);
EXTERN FLOAT fl_sqrt(FLOAT number);
EXTERN FLOAT fl_atan_calc(FLOAT a_val);
EXTERN FLOAT fl_atan(FLOAT atan_value);
EXTERN FLOAT fl_tan(FLOAT tan_value);
EXTERN FLOAT fl_tan_calc(FLOAT tan_val_rad);
EXTERN FLOAT fl_abs(FLOAT abs_val);
EXTERN FLOAT fl_FiltMaxMin( FLOAT in, FLOAT max, FLOAT min );	/* 2013.08.05 rir_common.c,pms_common.c����ڐA */
//EXTERN uint32 fNIF_CheckFlagChange(T_NIF_ChecFlagIn *in);		/* 2013.08.06 J42H����ڐA */
EXTERN FLOAT ExpCalc(FLOAT x);
EXTERN FLOAT fl_sin(FLOAT in);
EXTERN FLOAT fl_cos(FLOAT in);
EXTERN FLOAT Select_Hi_fl(FLOAT in1,	FLOAT in2);
EXTERN FLOAT Select_Lo_fl(FLOAT in1,	FLOAT in2);
EXTERN void calc_AVG_WithDist(FLOAT *avg, uint32 *cnt, FLOAT in, uint32 max_cnt,FLOAT vsp, FLOAT time_step, FLOAT thr_dist);
EXTERN void calc_AVG(FLOAT *avg, uint32 *cnt, FLOAT in, uint32 max_cnt);
EXTERN FLOAT  fl_FiFoRingBuffFloat(FLOAT data,  T_RING_BUFF_FL *ring);

EXTERN FLOAT fl_pythagorean_theorem( FLOAT v_line1, FLOAT v_line2);
EXTERN FLOAT fl_pythagorean_theorem_ax( FLOAT line1, FLOAT line2);
EXTERN FLOAT fl_trajectory_calc( FLOAT v_radius, FLOAT v_lateral_dist, FLOAT	v_distance, FLOAT v_approx_th);
EXTERN FLOAT fl_lpf( FLOAT in, FLOAT out_z, FLOAT m0, FLOAT	m1);
EXTERN FLOAT fl_2nd_lpf( FLOAT a_in[], FLOAT a_out[], FLOAT	m0, FLOAT m1, FLOAT	m2);
EXTERN FLOAT fl_bpf( uint8	reset, FLOAT in, FLOAT *in_z1, FLOAT *in_z2, FLOAT *out_z1, FLOAT *out_z2, FLOAT mdvsp0,  FLOAT	mdvsp1, FLOAT mdvsp2);
EXTERN void	vSetAllRingBuffFL( FLOAT data, T_RING_BUFF_FL*	ring);
EXTERN void	vPushRingBuffFL( FLOAT data, T_RING_BUFF_FL* ring);
EXTERN FLOAT fl_GetRingBuffFL( uint16 pos, T_RING_BUFF_FL*	ring);
EXTERN sint32 si32_Read3DMap( sint32 x, sint32 y, const T_3D_MAP *map);
EXTERN FLOAT fl_add_max_min( FLOAT v_base, FLOAT v_add, FLOAT v_max, FLOAT v_min);
EXTERN sint32 si32_add_max_min(	sint32	base, sint32 add, sint32 max, sint32 min);
EXTERN uint16 ui16_add_max_min(	uint16	base, uint16 add, uint16 max, uint16 min);
EXTERN uint16 ui16_sub_max_min(	uint16	base, uint16 sub, uint16 max, uint16 min);
EXTERN uint32 ui32_sqrt(uint32 in);

EXTERN FLOAT fl_sin_calc(FLOAT s_val);
EXTERN FLOAT fl_cos_calc(FLOAT s_cos_val);

#undef EXTERN
#endif          /* __N_APL_COMMON_H__ */
