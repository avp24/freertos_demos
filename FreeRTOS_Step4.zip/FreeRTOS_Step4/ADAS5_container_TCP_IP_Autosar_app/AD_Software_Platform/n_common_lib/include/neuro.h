/*******************************************************************************
 *
 *     Copyright (c) 2019 Nissan, Japan
 *
 *******************************************************************************
 *
 * Project: P33A
 * Module: Header File of Library for neural network
 * Version: 0.1
 * Author:
 * Date: 2019.06.10
 *
*******************************************************************************/
#ifndef __NEURO_H__
#define __NEURO_H__

#include "spec.h"
#include "n_apl_common.h"
#include "tjp_common.h"

#ifdef __NEURO_C__
#define EXTERN
#else
#define EXTERN extern
#endif

/* ################################################ */
/* macro                                           */
/* ################################################ */
#define EMB_ONLY                (1)   /* �w�K�p�֐����R���p�C�����Ȃ�����1 (��{ 1)  */
#define COMPILE_ON_ADAS			(1)
/* ################################################ */
/* variable,struct                                  */
/* ################################################ */
/* Scaling �p�\���� */
typedef struct{
    FLOAT a;
    FLOAT b;
    FLOAT c;
    FLOAT d;
}T_SCALING_FACTOR;

typedef struct{
    uint32 num;
    T_SCALING_FACTOR const * const fact;
}T_SCALING_FACTORS;

/* ++++++++++++++++++++++++++++ */
/* EPS�p�\����                  */
/* ++++++++++++++++++++++++++++ */
typedef struct{
    FLOAT   init;
    FLOAT   max;
    FLOAT   min;
    FLOAT   add;
    FLOAT   sub;
}T_NEU_EPS_SETTING;

/* ++++++++++++++++++++++++++++ */
/* ���t�f�[�^�p�\����           */
/* ++++++++++++++++++++++++++++ */
typedef struct{
    uint32  attr;   /* ��?�?�E                  */
    FLOAT   *data;  /* ��?ۂ̃f�[�^�ւ̃|�C���^ */
}T_NEU_TEACH_DATA;

typedef struct{
    uint32  total;  /* �E�f�[�^?�E              */
    T_NEU_TEACH_DATA in;  /* ���� */
    T_NEU_TEACH_DATA out; /* �o�� */
}T_NEU_TEACH_DATA_IO;

#if !EMB_ONLY
/* ++++++++++++++++++++++++++++ */
/* �w�K�p�\���̒�`             */
/* ++++++++++++++++++++++++++++ */
typedef struct{
    U_IEEE_754_32BIT  *weight;
    FLOAT y;
    FLOAT z;
}T_NEURON;

typedef struct T_NEURON_LAYER_tag{
    uint32              layer_num;
    FLOAT               (* const * const function)(FLOAT);
    uint32              num_of_neuron;
    T_NEURON            *neuron;
    struct T_NEURON_LAYER_tag  *left;
    struct T_NEURON_LAYER_tag  *right;
}T_NEURON_LAYER;

typedef struct{
    uint32 init_models;         /* ���ݎg�p���Ă��Ȃ� */
    uint32 init_epoch;          /* ���ݎg�p���Ă��Ȃ� */
    uint32 max_epoch;
	T_NEU_EPS_SETTING eps;
}T_NEU_LEARN_SETTING;
#endif

/* ++++++++++++++++++++++++++++ */
/* �{�ԗp�\���̒�`             */
/* ++++++++++++++++++++++++++++ */
typedef struct{
    U_IEEE_754_32BIT  const *weight;
}T_NEURON_FF;
typedef struct T_NEURON_LAYER_FF_tag{
    uint32              layer_num;
    FLOAT               (* const * const function)(FLOAT);
    uint32              num_of_neuron;
    T_NEURON_FF         const * const neuron;
    struct T_NEURON_LAYER_FF_tag  const * const left;
    struct T_NEURON_LAYER_FF_tag  const * const right;
}T_NEURON_LAYER_FF;

/* ################################################ */
/* functions                                        */
/* ################################################ */
#if (!EMB_ONLY)
EXTERN void vNEU_Learn(T_NEURON_LAYER *layers, T_NEU_TEACH_DATA_IO *teacher, T_NEU_LEARN_SETTING *setting);
#endif

#if (!EMB_ONLY) || (COMPILE_ON_ADAS)
EXTERN void vNEU_WorkSpaceInit(FLOAT *workspace, uint32 num,FLOAT **y_ptr,T_NEURON_LAYER_FF const * const filt);
EXTERN void vNEU_Left2Right_FF(T_NEURON_LAYER_FF const * const filt,FLOAT **y_ptr);
extern FLOAT (* const pfl_NEU_Sigmoids[3])(FLOAT);
extern FLOAT (* const pfl_NEU_Ramps[3])(FLOAT);
extern FLOAT (* const pfl_NEU_Liners[3])(FLOAT);
extern FLOAT (* const pfl_NEU_Tanhs[3])(FLOAT);
extern FLOAT (* const pfl_NEU_SoftMaxs[3])(FLOAT);
#else
/* mabx, simulink ��?�E���static�Ŗ{�̂�?錾����̂ł���Ȃ� */
#endif

#undef EXTERN

#endif          /* __NEURO_H__ */
