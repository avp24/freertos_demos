#ifndef	_TJPCOMMON
#define _TJPCOMMON

#include "utypedef.h"
#include "spec.h"
//#include "n_apl_common.h"
#include "rir_common.h"

#define COMPILE_ON_ADAS (1)   /* Simulink, Micro Auto Box��??��� 0 �ɂ���    */

#define TJP_SIM_UNIT    (0)             /* sim unit */
#define TJP_EPM_UNIT    (1)             /* epm unit */

#define TJP_CAMERA_UNIT (TJP_SIM_UNIT)
#endif
