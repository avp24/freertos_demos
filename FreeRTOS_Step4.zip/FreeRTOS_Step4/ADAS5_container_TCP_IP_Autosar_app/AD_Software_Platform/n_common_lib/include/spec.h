/*
	Copyright (c) 2015 Nissan, Japan
	Version	:
	History	:
		Date		Author	Description
		2015.09.01	XE3 K.N	New
		2016.11.16	�e�N�m	����		P32R�p��define����ѕ��Ԃ̒�`�A�z��l�ő�l��ǉ�
		2016.11.28	�e�N�m	Quyen		P32S�p��define����ѕ��Ԃ̒�`�A�z��l�ő�l��ǉ�
		2017.02.10	�e�N�m	����		B12P CAMERA�̂�FEB�̂��߂�CAMERA��YawRate�g�p�̂��߂�CSW��ǉ���P32R�ɂ����f
*/

#ifndef	__SPEC_H__
#define	__SPEC_H__

#define	SYS_OFF	(0u)
#define	SYS_ON	(1u)


/* ---- */
/* P33A */
/* ---- */
#define P33A_6RS2A	(0)
#define P33A_6RU6A	(0)
#define P33A_6RU7A	(0)
#define P33A_6RU8A	(0)
#define P33A_6RU9A	(0)
#define P33A_6RA0D	(0)
#define P33A_6RA1D	(0)
#define P33A_6RA0E	(0)
#define P33A_6RU4A	(0)
#define P33A_6RA1E	(0)
#define P33A_6RU5A	(0)

/* ---- */
/* P33B */
/* ---- */
#define P33B_6UA1D	(0)
#define P33B_6UA0A	(0)
#define P33B_6UA2E	(0)
#define P33B_6UA0C	(0)
#define P33B_6UA2D	(0)
#define P33B_6UA3D	(0)
#define P33B_6UA0B	(0)
#define P33B_6UA0D	(0)
#define P33B_6UM0A	(0)
#define P33B_6UM1A	(0)
#define P33B_6UM2A	(0)
#define P33B_6UM3A	(0)
#define P33B_6UR1A	(0)
#define P33B_6UM0B	(0)
#define P33B_6UM1B	(0)
#define P33B_6UM2B	(0)
#define P33B_6UM3B	(0)
#define P33B_6UM4B	(0)
#define P33B_6UM5B	(0)
#define P33B_6UM6B	(0)
#define P33B_6UM7B	(0)

/* ---- */
/* P42R */
/* ---- */
#define P42R_6TA0A	(0)
#define P42R_6TV0A	(0)
#define P42R_6TK2A	(0)
#define P42R_6TJ0A	(0)
#define P42R_6TA7A	(0)
#define P42R_6TA1A	(0)
#define P42R_6TJ1A	(0)
#define P42R_6TV1A	(0)
#define P42R_6TV0C	(0)
#define P42R_6TV1C	(0)

/* ---- */
/* PZ1A */
/* ---- */
#define PZ1A_5MP4B	(0)
#define PZ1A_5MP0E	(0)
#define PZ1A_5MP0B	(0)
#define PZ1A_5MP0D	(0)
#define PZ1A_5MP4A	(0)
#define PZ1A_5MP1A	(0)
#define PZ1A_5MP1B	(0)
#define PZ1A_5MP2A	(0)
#define PZ1A_5MP2B	(0)
#define PZ1A_5MP5A	(0)
#define PZ1A_5MP4E	(0)
#define PZ1A_5MP5B	(0)
#define PZ1A_5MP2C	(0)
#define PZ1A_5MP3A	(0)
#define PZ1A_5MP3B	(0)
#define PZ1A_5MP4D	(0)
#define PZ1A_5MP3C	(0)
#define PZ1A_5MP4C	(0)
#define PZ1A_5MP3D	(0)

/* ---- */
/* J32V */
/* ---- */
#define J32V_7DB0A	(1)

/* P33B Destination */
#define DEF_P33B_EUR_AC ( P33B_6UA1D + P33B_6UA0A + P33B_6UA2D + P33B_6UA0B + P33B_6UM0A + P33B_6UM1A + P33B_6UM2B + P33B_6UM3B )
#define DEF_P33B_EUR_C ( P33B_6UA2E + P33B_6UA0C + P33B_6UA3D + P33B_6UA0D + P33B_6UM2A + P33B_6UM3A + P33B_6UM0B + P33B_6UM1B )
#define DEF_P33B_ASR ( P33B_6UM4B + P33B_6UM5B )
#define DEF_P33B_GOM ( P33B_6UM6B + P33B_6UM7B )
#define DEF_P33B_PRC ( P33B_6UR1A )
#define DEF_P33B_JPN ( 0 )
#define	DEF_P33B_NAM ( 0 )

/* P33B Region Sorting */
#define	DEF_P33B_ENCAP ( DEF_P33B_EUR_AC + DEF_P33B_ASR )/* ENCAP + ANCAP */ /* Task #31782 */
#define	DEF_P33B_CNCAP ( DEF_P33B_PRC ) /* PRC */ /* Task #32396 */
#define	DEF_P33B_JNCAP ( DEF_P33B_JPN ) /* JPN */

#define DEF_P33A_EUR_AC ( P33A_6RU4A + P33A_6RU5A )
#define DEF_P33A_EUR_C ( P33A_6RA0E + P33A_6RA1E )
#define DEF_P33A_ASR ( P33A_6RU7A + P33A_6RU9A ) /* [J32V-2565][ADAS_CR_0563] FS_ACT ���t�@�N�^�����O���[�j���O�폜�̂��߂ɒ�`���ύX */
#define	DEF_P33A_GOM ( P33A_6RU6A + P33A_6RU8A )
#define	DEF_P33A_PRC ( P33A_6RS2A )
#define	DEF_P33A_JPN ( P33A_6RA0D + P33A_6RA1D )
#define	DEF_P33A_NAM ( 0 )


/* Task #10595 */
#define	DEF_P33A_ENCAP ( DEF_P33A_EUR_AC + DEF_P33B_ASR )
#define	DEF_P33A_CNCAP ( DEF_P33A_PRC )
#define	DEF_P33A_JNCAP ( DEF_P33A_JPN )

/* Task #10687 */
#define DEF_P42R_ENCAP ( 0 ) /* ����P42R�ł�RUS�̂ݓ��Yspec.h���g�p���邽��0�Œ�` */
#define DEF_P42R_NAM ( P42R_6TA0A + P42R_6TV0A + P42R_6TK2A + P42R_6TJ0A + P42R_6TA7A + P42R_6TA1A + P42R_6TJ1A + P42R_6TV1A )
#define DEF_P42R_RUS ( P42R_6TV0C + P42R_6TV1C )	/* Task #32353 */
#define	DEF_P42R_CNCAP ( 0 )

#define DEF_PZ1A_JNCAP ( PZ1A_5MP0B + PZ1A_5MP2A + PZ1A_5MP3A )
#define DEF_PZ1A_ENCAP ( PZ1A_5MP0E + PZ1A_5MP1A + PZ1A_5MP4E + PZ1A_5MP2C + PZ1A_5MP3C + PZ1A_5MP3D )
#define DEF_PZ1A_NAM ( PZ1A_5MP0D + PZ1A_5MP2B + PZ1A_5MP3B )
#define DEF_PZ1A_EURC ( PZ1A_5MP4B + PZ1A_5MP4A + PZ1A_5MP1B + PZ1A_5MP5A + PZ1A_5MP5B + PZ1A_5MP4D + PZ1A_5MP4C )
#define	DEF_PZ1A_CNCAP ( 0 )

/* Task #10595 */
#define DEF_P33A	(DEF_P33A_EUR_AC + DEF_P33A_EUR_C + DEF_P33B_ASR + DEF_P33A_GOM + DEF_P33A_PRC + DEF_P33A_JPN + DEF_P33A_NAM) /* Task #10213 No.1 */
#define DEF_P42R	(DEF_P42R_NAM + DEF_P42R_RUS + DEF_P42R_ENCAP + DEF_P42R_CNCAP)	/* Task #10687 */ /* Task #32353 */ /* Task #32676 */
#define DEF_P33B	(DEF_P33B_EUR_AC + DEF_P33B_EUR_C + DEF_P33B_ASR + DEF_P33B_GOM + DEF_P33B_PRC + DEF_P33B_JPN + DEF_P33B_NAM)
#define DEF_PZ1A	(DEF_PZ1A_JNCAP + DEF_PZ1A_ENCAP + DEF_PZ1A_NAM + DEF_PZ1A_EURC + DEF_PZ1A_CNCAP)
#define DEF_J32V	(J32V_7DB0A)
#define DEF_ADAS5	(DEF_P33A + DEF_P33B + DEF_P42R + DEF_PZ1A + DEF_J32V)


#if	( DEF_ADAS5 != 1 )
	#error
#endif

/* include hedder file which is modified for each part number START */
#if (DEF_P33A)
#define ADAS_CAR_MODEL_STR "P33A"	/* Task #8965 */
#include "spec_P33A.h"
#elif (DEF_P42R)
#define ADAS_CAR_MODEL_STR "P42R"	/* Task #8965 */
#include "spec_P42R.h"				/* Task #10687 */
#elif (DEF_P33B)
#define ADAS_CAR_MODEL_STR "P33B"
#include "spec_P33B.h"
#elif (DEF_PZ1A)
#define ADAS_CAR_MODEL_STR "PZ1A"
#include "spec_PZ1A.h"
#elif (DEF_J32V)
#define ADAS_CAR_MODEL_STR "J32V"
#include "spec_J32V.h"
#else
#error 
#endif
/* include hedder file which is modified for each part number END */

/*** RIR���ł̃��[���؂�ւ��Ή�(��ԕ��s�҂̑Ό��ԃ��[��/�H��������؂�ւ���) ***/
#define DEF_FDT_ONCOMINGCARSIDE_RIGHT (0)							/* �Ό��ԁF�E �^ �H���F�� */	/* USNCAP,CNCAP�ȊO */
#define DEF_FDT_ONCOMINGCARSIDE_LEFT  (1)							/* �Ό��ԁF�� �^ �H���F�E */	/* USNCAP,CNCAP */


/* tentative */
#if 0 /* AD2 */
	#define CAM_RAD_EXE_20MS (1)
	#define N_NOENTRY_ENABLE (1) /* J32V AD2 �ł͗L���ɂȂ��Ă��� */
	
	#define CAM_RAD_AD2_OBJAGE_COUNTER			(1)
	#define CAM_RAD_AD2_DMSOUTPUT				(1)
	#define CAM_RAD_AD2_RTE			 			(1)
	#define CAM_RAD_AD2_ADD_DATA				(1)
	
	#define CAM_RAD_AD2_CHOOSE_LDP2_ENCAP		(1)  /* 0:ENCAP  1: LDP2(AD2) */

	#define DEF_DMS_SENT_CAMERA_DATA_NUM		(5)	
	
	/* �b�� �|�C���^�^�s���ɂȂ� AD1 PF ��AD2�ݒ�ł̃r���h�m�F�̂���*/
	#define CAM_RAD_COMPILE_TENTATIVEHACK

	#define DEF_JPN								(0)
	#define DEF_US								(0)
	#define DEF_EUR								(0)
#else /* AD1 */
	#define CAM_RAD_EXE_10MS (1)
	#define CAM_RAD_AD2_RTE						(0)
	#define CAM_RAD_AD2_ADD_DATA				(0)

	/* AD1/2��HMI��{���̂���DEF_JPN,DEF_US,DEF_EUR���`���Ă��� */
	#define DEF_JPN								(0)
	#define DEF_US								(0)
	#define DEF_EUR								(0)

	#define DEF_REDUN_SPEED_EBA					(1) // VSI�R���p�C���G���[�Ή��̂���AD2��`���b��ǉ�
	#define DEF_REDUN_SPEED_OUTREV_TM			(0) // VSI�R���p�C���G���[�Ή��̂���AD2��`���b��ǉ�
	#define DEF_REDUN_SPEED_OUTREV_WHL			(0) // VSI�R���p�C���G���[�Ή��̂���AD2��`���b��ǉ�


	#if DEF_JPN || DEF_US || DEF_EUR
	#error DEF_JPN ,DEF_US and DEF_EUR should be 0 in AD1
	#endif

#endif

#ifdef CAM_RAD_EXE_20MS
	#define CAM_RAD_SAMPLE_TIME_S	(0.02F)
	#define CAM_RAD_SAMPLE_TIME_MS	(20U)
#elif  CAM_RAD_EXE_10MS
	#define CAM_RAD_SAMPLE_TIME_S	(0.01F)
	#define CAM_RAD_SAMPLE_TIME_MS	(10U)
#else
	#error "CAM_RAD Sampling Setting Missing"
#endif

#define CAM_RAD_100MS_TimeCnt	(100U/CAM_RAD_SAMPLE_TIME_MS)




#endif	/* __SPEC_H__ */
