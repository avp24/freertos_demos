/**
 * @file
 * @brief �x�N�g�������C���^�[�t�F�[�X
 *
 * @author morimoto
 */

#ifndef UTIL_VECTOR_H_
#define UTIL_VECTOR_H_

#ifdef __cplusplus
extern "C" {
#endif 

/*---------------*
 * include files *
 *---------------*/
#include "utypedef.h"

/*------------------*
 * macro definition *
 *------------------*/


/*-------------------*
 * struct definition *
 *-------------------*/
#ifndef VECTOR_T_
#define VECTOR_T_
/**
 * @brief 2-D Vector struct
 */
typedef struct {
	/// x element
	double x;
	/// y element 
	double y;
} Vector_t;

#endif

typedef struct {
	/// x element
	FLOAT x;
	/// y element 
	FLOAT y;
} Vector_fl_t;

/*----------------------*
 * function declaration *
 *----------------------*/
/* Comments for functions are descrived at definition section. */
double InnerProduct(const Vector_t vec_src1, const Vector_t vec_src2);
FLOAT InnerProduct_fl(const Vector_fl_t vec_src1, const Vector_fl_t vec_src2);
	
double OuterProduct(const Vector_t vec_src1, const Vector_t vec_src2);
FLOAT OuterProduct_fl(const Vector_fl_t vec_src1, const Vector_fl_t vec_src2);
	
double VectorAngle(const Vector_t vec_src1, const Vector_t vec_src2);
FLOAT VectorAngle_fl(const Vector_fl_t vec_src1, const Vector_fl_t vec_src2);

double VectorNorm(const Vector_t vec_src);
FLOAT VectorNorm_fl(const Vector_fl_t vec_src);

Vector_t VectorAdd(const Vector_t vec_src1,
									 const Vector_t vec_src2);
Vector_fl_t VectorAdd_fl(const Vector_fl_t vec_src1,
									 const Vector_fl_t vec_src2);

Vector_t VectorDiff(const Vector_t vec_src1,
										const Vector_t vec_src2);
Vector_fl_t VectorDiff_fl(const Vector_fl_t vec_src1,
										const Vector_fl_t vec_src2);

Vector_t VectorScalarMultiple(const Vector_t vec_src,
															const double mag);
Vector_fl_t VectorScalarMultiple_fl(const Vector_fl_t vec_src,
															const FLOAT mag);

Vector_t VectorRotate(const Vector_t vec_src,
											const double rot_rad);
Vector_fl_t VectorRotate_fl(const Vector_fl_t vec_src,
											const FLOAT rot_rad);

Vector_t CoordTrans(const Vector_t vec_src,
										const Vector_t vec_ref,
										const double ang_rot);
Vector_fl_t CoordTrans_fl(const Vector_fl_t vec_src,
										const Vector_fl_t vec_ref,
										const FLOAT ang_rot);

#ifdef __cplusplus
}
#endif 

#endif

