#ifndef MABX2_COMMON_H_
#define MABX2_COMMON_H_
/** *********************************************************
 * @file  mabx2_common.h
 * @brief Common header for C-language. C����p�̋��ʃw�b�_
 * @author n.hodohara
 * @date   2018/07/04
 ***********************************************************/
#include <stdio.h>
#include <float.h>

#ifdef __STDC_VERSION__
/* Standard C */
#if  (__STDC_VERSION__ >= 199901L)
/* GreenHils (greater C99) */
#include <stdint.h>
#else
/* C95 */
#include "stdint_dummy.h"
#endif
#elif defined(_MSC_VER)
/* VisualStudio (near C89) */
#if (_MSC_VER >= 1700) /* later than Visual Studio 2012. ref:qiita.com/yumetodo/items/8c112fca0a8e6b47072d */
#include <stdint.h>
#else
#include "stdint_dummy.h"
#endif
#else
 /* C89 or others */
#include "stdint_dummy.h"
#endif

/* Justification for Misra C:2012 21.1: To use M_PI definition, it is necessary to define _USE_MATH_DEFINES. */
#define _USE_MATH_DEFINES
#include <math.h>

#include "sensor_obj.h"

/*-------------------*
 * Compile Switch
 *-------------------*/
#define UNUSED_CODE 0 /**< |Def:Activate unused code or not. |Unit:boolean |Range:{0:invalid, 1:valid} |Resol:- | */
//#define MABX2_DEBUG_

#ifdef MABX2_DEBUG_
#define dbg_printf printf
#else
#define dbg_printf(...)
#endif

/*-------------------*
 * Definitions for s-function (mABX2)
 *-------------------*/
#include "utypedef.h"
#ifndef TRUE
#define TRUE (1)
#endif
#ifndef FALSE
#define FALSE (0)
#endif

//typedef unsigned char BOOL_t;
typedef boolean BOOL_t;

#ifndef M_PI
#define M_PI (3.14159265359)
#endif

//#define SAMPLE_TIME 0.01

/* The number of data */
#define NUM_FRONT_CAMERA_OBJ_10 10
#define NUM_SIDE_FRONT_RADAR_OBJ_6 6
#define NUM_SIDE_REAR_RADAR_OBJ_8 8
#define NUM_SIDE_RADAR_OBJ_28 28
#define NUM_CLUSTERED_SIDE_RADAR_OBJ_20 20
#define NUM_SURROUND_OBJ_20 20
#define NUM_OBS_MEMORY_64 64
#define NUM_FRONT_RADAR_ST_8 8

/* for lane */
#define LEFT 0
#define RIGHT 1
#define L0 LEFT
#define R1 RIGHT
#define NUM_LANE_2 2
#define NUM_LANE_5 5
#define LANE_MAX NUM_LANE_2
#define LEFT_RIGHT NUM_LANE_2
#define LEFT_RGHT NUM_LANE_2

#define FRNT_0 0
#define REAR_1 1
#define FRNT_REAR_2 2

#define CENTER_REAR_2 2

#define CENT_2 2
#define LEFT_RGHT_CENT_3 3

#define NOVEHICLE_0 0
#define LEFT_1 1
#define RIGHT_2 2
#define HOST_3 3

/*#define FRNT        (0)*/
#define SIDE_1 (1)
#define REAR_2 (2)
#define FRNT_REAR_3 (3)

#define LANE_CENT_0 0
#define LANE_INNER_1 1u
#define LANE_OUTER_2 2u
#define LANE_LEFT_IN_3 3u
#define LANE_RGHT_IN_4 4u
#define LANE_LEFT_OUT_5 5u
#define LANE_RGHT_OUT_6 6u
#define LANE_UNDEFINED_10 10

#define INDEX_CENT 0u
#define INDEX_LEFT 1u
#define INDEX_RGHT 2u
#define INDEX_LANE 3

#define STAY 0u
#define LOW 1u
#define HIGH 2u

/* for time delay */
#define Z0 0
#define Z1 1
#define Z2 2

/*-------------------*
* Definitions for Object
*-------------------*/
/* camera obstacle types
000 Vehicle
001 Truck
010 Bike
011 Ped
100 Bicycle
*/
#define VEHICLE_CAM_OBJ		0u
#define TRUCK_CAM_OBJ		1u
#define BIKE_CAM_OBJ		2u
#define PED_CAM_OBJ			3u
#define BICYCLE_CAM_OBJ		4u
#define VEHICLE2_CAM_OBJ	7u

/* camera obj status
0 Undefined
1 Standing (never moved, back lights are on)
2 Stopped (movable)
3 Moving
4 Oncoming
5 Parked (never moved, back lights are off)
6 Unused
*/
#define ME_STATUS_NOT_DEFINED 0
#define ME_STATUS_STANDING 1
#define ME_STATUS_PARKED 2
#define ME_STATUS_STOPEPD 3
#define ME_STATUS_UNKNOWN 4
#define ME_STATUS_MOVING 5
#define ME_STATUS_STOPPED_MOVING 6
#define ME_STATUS_UNKNOWN_MOVING 7
#define ME_STATUS_ONCOMING 8
#define ME_STATUS_CROSSING 9
#define ME_STATUS_CLOSE_CUTIN 10
#define ME_STATUS_MOVING_UNKNOWN 11
#define ME_STATUS_STOPPED_UNKNOWN 12

/*Camera_CANFD_DB_Dec_28_2017_format2_009_rev009*/ /* from calc_pass_offset.h */
#define TYPE_CAMUNKNOWN 0u
#define TYPE_TRUCK 1u
#define TYPE_VEHICLE 2u
#define TYPE_BIKE 3u
#define TYPE_BICYCLE 4u
#define TYPE_PED 5u
#define TYPE_UNDEFINED 6u
#define TYPE_CAMUNKNOWN_Z 10u
#define TYPE_TRUCK_Z 11u
#define TYPE_VEHICLE_Z 12u
#define TYPE_BIKE_Z 13u
#define TYPE_BICYCLE_Z 14u
#define TYPE_PED_Z 15u
#define TYPE_UNDEFINED_Z 16u
#define TYPE_UNKNOWN 20u
#define NUM_FRONT_CAMERA_OBS_10 10

#define MAX_PED_HISTORY 2                   // #20101120 NTCNA SATO
#define MAX_NUM_PED NUM_FRONT_CAMERA_OBS_10 // #20101118 NTCNA SATO
#define MAX_NUM_PED_DATA 11                 // #20101118 NTCNA SATO

#define NUM_ARS_OBJ_3 3
#define ARS_CENT_2 2

/* from sf_zutoliv_side_radar_obs_calc.h ����� all_obs_calc_main.h */
#define OBS_THRESHOLD (0.2) /* ���̔F������confidence�����l */
#define OBS_TOLERANCE (5.0) /* �}�[�W���� */

/* from all_obs_calc_main_common.h */
#define NUM_DATA_OUTPUT 10
#define NUM_OBS_MEMORY 64
#define NUM_ID_MEMORY 10

/*#define TYPE_VEHICLE 0
#define TYPE_TRUCK 1
#define TYPE_BIKE 2
#define TYPE_PED 3
#define TYPE_BICYCLE 4
#define TYPE_UNDEFINED 7

// type for object detected by only radar
#define TYPE_VEHICLE_Z 10
#define TYPE_TRUCK_Z 11
#define TYPE_BIKE_Z 12
#define TYPE_PED_Z 13
#define TYPE_BICYCLE_Z 14
#define TYPE_UNKNOWN 20
*/
#define INVALID_ID_255 255

/* for autoliv_side_radar_obs_calc & all_obs_calc_main */
#define BRDR_OUTSIDE 0u
#define BRDR_INSIDE 1u
#define BRDR_ERR 2u
#define BRDR_SNA 3u

/*-------------------*
* Definition for lane
*-------------------*/
#define LANE_NL 0
#define LANE_L 1
#define LANE_CENT_2 2
#define LANE_R 3
#define LANE_NR 4

#define ORDINARY_ROAD_WIDTH 3.0 ///< |Def:City road width in Japan|Unit:m|
#define HIGHWAY_ROAD_WIDTH 3.5  ///< |Def:Road width of highway in Japan|Unit:m|

#define LANE_GRID_INTERVAL 5.0 ///< |Def:Size of 1 grid of lane|Unit:m|

#define NUM_LINE_POINTS_REARWARD 9
#define NUM_LINE_POINTS_FORWARD 18
#define NUM_LANE_POINTS_OUT (NUM_LINE_POINTS_FORWARD + NUM_LINE_POINTS_REARWARD)

#define FRONT_CAM_LANE_TYPES_NUM 13

#define UPDATE_DIST             100 /* for PathPlanner */

/*-------------------*
 * Macro definition
 *-------------------*/
#ifndef ROUND // F/B �F���W�b�N���ς���Ă��܂��Ă���̂ŁA���ɖ߂�
#define ROUND(d) ((int)(d + 0.5)) // F/B �F���W�b�N���ς���Ă��܂��Ă���̂ŁA���ɖ߂�
#endif // F/B �F���W�b�N���ς���Ă��܂��Ă���̂ŁA���ɖ߂�
#ifndef MAX
#define MAX(a, b) ((a) > (b) ? (a) : (b))
#endif
#ifndef MIN
#define MIN(a, b) ((a) < (b) ? (a) : (b))
#endif
#define KMPH2MPS(x) ((x) / 3.6)
#define MPS2KMPH(x) ((x)*3.6)
#define SATURATE(a, x, b) MIN(MAX(a, x), b)
#define MICROSEC2SEC(x) ((double)(x) / 1000000.0)
#define CONVERT_MABX2_TIME(x) MICROSEC2SEC(x) /* convert llTimeStamp(us) to RX_time(sec) in ECU code */

/*-------------------*
 * type definition
 *-------------------*/
#ifndef VECTOR_T_
#define VECTOR_T_
/**
 * @brief 2-D Vector struct
 */
typedef struct {
    double x; ///< |Def:x element.|Unit:different as each use.|Range:different as each use.|Resol:-|Init:-|
    double y; ///< |Def:y element.|Unit:different as each use.|Range:different as each use.|Resol:-|Init:-|
} Vector_t;
#endif

/**
 * @brief Error code.
 */
/*
#include "utypedef.h"
*/
/*
#define NAP_RET int32_t
#define NAP_NG (-1)
#define NAP_OK (1)
#define NULL_CHECK(p)        \
    {                        \
        if ((p) == NULL) {   \
            return (NAP_NG); \
        }                    \
    }
#define NULL_CHECK_NORETURN(p) \
    {                          \
        if ((p) == NULL) {     \
            return;            \
        }                      \
    }
#define NULL_CHECK_RETURN(p, r) \
    {                           \
        if ((p) == NULL) {      \
            return (r);         \
        }                       \
    }
#define RET_CHECK(r1)         \
    {                        \
        if ((r1) != NAP_OK) { \
            return (NAP_NG); \
        }                    \
    }
*/
typedef enum e_NAP_RET {
	NAP_NG = 0,
	NAP_OK = 1
} NAP_RET;
#define NULL_CHECK(p)			{if(p==NULL){return(NAP_NG);}}
#define NULL_CHECK_NORETURN(p)	{if(p==NULL){return;}}
#define NULL_CHECK_RETURN(p,r)	{if(p==NULL){return(r);}}
#define RET_CHECK(r)			{if(r==NAP_NG){return(NAP_NG);}}

/*-------------------*
* Structture
*-------------------*/
/**
* @brief The general Fusion object data. 
*/
typedef struct {
	Vector_t pos; /**< | Def:Position of the obj. | Unit:m | Range:- | Resol:- | Init:(0.0, 0.0) | */
	Vector_t vel; /**< | Def:Velocity of the obj. | Unit:m/s | Range:- | Resol:- | Init:(0.0, 0.0) | */

	double lat_pos_in_lane[NUM_LANE_5]; /**< | Def:Relative lateral position in lane. | Unit:m | Range:- | Resol:- | Init:(0.0,...) | */
	double lat_vel_in_lane;             /**< | Def:Relative lateral velocity in lane. | Unit:m/s | Range:- | Resol:- | Init:0.0 | */
	double width;                       /**< | Def:Width of the lane. | Unit:m | Range:- | Resol:- | Init:0.0 | */

	uint32_t ID;        /**< | Def:ID of the obj. | Unit:- | Range:??? | Resol:- | Init:0 | */
	uint32_t type;      /**< | Def:Type of the obj. | Unit:Camera_CANFD_DB_Dec_28_2017_format2_009_rev009 | Range:0~20 | Resol:- | Init:TYPE_UNKNOWN | */
	uint8_t  lane;      /**< | Def:Locating lane. | Unit:??? | Range:0~6 | Resol:- | Init:0 | */
	BOOL_t   is_valid;  /**< | Def:Whether the obj is valid or not. | Unit:boolean | Range:- | Resol:- | Init:0 | */
	BOOL_t   is_usable; /**< | Def:Whether the obj is usable(?). | Unit:boolean | Range:- | Resol:- | Init:0 | */
	uint32_t border;	/**< | Def:Obj border(?). | Unit:- | Range:- | Resol:- | Init:0 | */ /** Added by TCS as per Query Answer. Date: 20181025*/
	BOOL_t   lost;
} SGeneralObj;

/**
* @brief The general object data for display.
*/
typedef struct {
	double  RX_time;
	uint8_t	V_x_ObjectID;
	double	V_m_ObjectWidth;
	double	V_m_ObjectPosX;
	double	V_m_ObjectPosY;
	double	V_mps_ObjectVelX;
	double	V_mps_ObjectVelY;
	uint8_t	V_x_ObjectType;
	uint8_t	V_x_ObjectStatus;
	uint8_t	V_x_ObjectAngle;
	double  V_m_Trajectory;
	double  V_m_Pos_Y_Trajectory;
	double	V_mps_ObejectRelVelocity;
	BOOL_t  flg_update;
	uint8_t flg_on_lane;
	double 	Pos_Y_L_Edge;
	double 	Pos_Y_R_Edge;
	uint32_t num;
}SGeneralDispObj;

/**
* @brief used in all_obs_calc_main, calc_5_lane, meter_disp_module, meter_disp_obj_calc3.
*/
typedef struct {
	uint32_t type;
	uint32_t quality;
	double   position;
	double   heading;
	double   curvature;
	double   curvature_derivative;
	double   view_range;
	double   rx_time;
	double   elapsed_time;
} LaneInfo_t;

#ifndef ENABLE_MABX2_LANESELECTOR
typedef struct _LaneSelector_LaneInfo_t {
	double map_lane_info_lateral_f[5][NUM_LINE_POINTS_FORWARD];
	double map_lane_info_longitudinal_f[5][NUM_LINE_POINTS_FORWARD];
	double map_lane_info_lateral_r[5][NUM_LINE_POINTS_REARWARD];
	double map_lane_info_longitudinal_r[5][NUM_LINE_POINTS_REARWARD];
	unsigned int map_lane_info_valid;
} LaneSelector_LaneInfo_t;
#endif

#ifndef ENABLE_MABX2_MAPTRANSLATOR
typedef struct _MapTranslator_HMI_t {
	unsigned int hmi_DistToMergeStart;
	unsigned int hmi_DistToMergeEnd;
	unsigned int hmi_MergeType;
	unsigned int hmi_DistToMergeStart2nd;
	unsigned int hmi_DistToMergeEnd2nd;
	unsigned int hmi_MergeType2nd;
	unsigned int hmi_MergeViewAreaMeter;
	unsigned int hmi_MergeViewAreaControl;
	unsigned int hmi_DistToBranchStart;
	unsigned int hmi_DistToBranchEnd;
	unsigned int hmi_BranchType;
	unsigned int hmi_DistToBranchStart2nd;
	unsigned int hmi_DistToBranchEnd2nd;
	unsigned int hmi_BranchType2nd;
	unsigned int hmi_DistToTollgateStart;
	unsigned int hmi_DistToTollgateEnd;
	unsigned int hmi_DistToHighwayEntrance;
	unsigned int hmi_DistToHighwayExit;
	unsigned int hmi_DistToLaneWidthChange;
	unsigned int hmi_LaneWidthChange;
	unsigned int hmi_HD_NumOfLane;
	unsigned int hmi_HD_CurrentLanePos;
	unsigned int hmi_HD_LaneType[4];
	unsigned int hmi_HD_LaneColor[4];
	unsigned int hmi_DistToEndNaviPoint;
	unsigned int hmi_CurrentSpeedLimit;
	unsigned int hmi_NextSpeedLimit;
	unsigned int hmi_DistToNextSpeedLimit;
	unsigned int hmi_Reliability[2];
	unsigned int hmi_Reliability2nd[2];
	unsigned int hmi_Divider;
	unsigned int hmi_Divider2nd;
	unsigned int hmi_DistToNextDivider;
	unsigned int hmi_DistToNextReliability[2];
	unsigned int hmi_CutInAreaLeft;
	unsigned int hmi_CutInAreaRight;
	unsigned int hmi_DistToDecelerationSec1;
	unsigned int hmi_DistToDecelerationSec2;
	unsigned int hmi_DistToAccelerationSection;
	unsigned int hmi_HD_LaneType_25m_1;
	unsigned int hmi_HD_LaneType_25m_2;
	unsigned int hmi_DistToCrossSectionStart;
	unsigned int hmi_DistToCrossSectionEnd;
	unsigned int hmi_CrossSectionType;
	unsigned int hmi_ThikLinePosLeft;
	unsigned int hmi_ThikLinePosRight;
	unsigned int hmi_RoadShoulderLeft;
	unsigned int hmi_RoadShoulderRight;
	double       hmi_TSR_Position_X[6];
	double       hmi_TSR_Position_Y[6];
	double       hmi_TSR_Position_Z[6];
	unsigned int hmi_TSR_Type[6];
	unsigned int hmi_TSR_AddAttrFlg[6];
} MapTranslator_HMI_t;
#endif

/*-------------------*
 * common function declaration
 *-------------------*/
#ifdef __cplusplus
extern "C" {
#endif

int32_t iRound(double x);
NAP_RET comb_sort(int32_t size, double dist[], int32_t index[]);
#if 0 /* avoid multiple definition */
double  lookup1dtbl(const double invalues[], const double outvalues[], uint32_t num_points, double x);
#else
double  MABX2_lookup1dtbl(const double invalues[], const double outvalues[], uint32_t num_points, double x);
#define lookup1dtbl MABX2_lookup1dtbl
#endif
double  LPF(BOOL_t init, double u_z0, double u_z1_in, double y_z1_in, double sample_time, double fc);
double  Backlash(BOOL_t init, double u_z0, double y_z1_in, double deadband_width);
uint8_t convert_fcam_lane_type_to_EQ3(uint8_t lane_type);

#ifdef __cplusplus
} // extern "C" 
#endif

#endif /* MABX2_COMMON_H_ */
