#ifndef SURROUND_INFO_IO_H_
#define SURROUND_INFO_IO_H_

/***********************************************************
 * file name:   SurroundInfo_io.h
 * breif:       mABOX2�� SurroundInfo ��I/F ��`�E�\���� �w�b�_ 
 * author:      n.hodohara
 * date:        2018/10/01
 ***********************************************************/
#include "mabx2_common.h"
#ifdef ENABLE_MABX2_MAPTRANSLATOR
#include "MapTranslater_IF.h"		/* Added by TCS as per review ID 10*/
#endif

/*-------------------*
 * Definitions 
 *-------------------*/
#define NUM_NEXT_LANE_OBJ_DM 4
#define NUM_NEXT_LANE_OBJ_AVM 5
#define NUM_METER_VEC_OBJ 9
#define NUM_METER_VECTOR_OBJ 9
#define NUM_MASTER_OBJ_DATA 10
#define RCAR_HMI_MAN_SAMPLING_SEC 0.1
#define OBJ_SEL_AVM_SAMPLING_SEC 0.1
#define OBJ_SEL_DM_SAMPLING_SEC 0.05

/*-------------------*
 * Structure for External I/F
 *-------------------*/

 /**
 * @brief part of output of RCarHMIManagement SWC.
 */
typedef struct {
	uint8_t x;		/**< | Def:x position of the obj. | Unit:m | Range:- | Resol:- | Init:(0.0, 0.0) | */
	int8_t y;		/**< | Def:y position of the obj. | Unit:m | Range:- | Resol:- | Init:(0.0, 0.0) | */
	uint8_t type;		/**< | Def:Type of the obj. | Unit:- | Range:(?) | Resol:- | Init:TYPE_UNKNOWN | */
	uint8_t color;
} slMeterVec;

typedef struct {
	slMeterVec vec1;
	slMeterVec vec2;
	slMeterVec vec3;
	slMeterVec vec4;
	slMeterVec vec5;
	slMeterVec vec6;
	slMeterVec vec7;
	slMeterVec vec8;
	slMeterVec vec9;
} slMeterVecs;

typedef struct {
	Vector_t pos;		/**< | Def:Position of the obj. | Unit:m | Range:- | Resol:- | Init:(0.0, 0.0) | */
	uint8_t type;		/**< | Def:Type of the obj. | Unit:- | Range:(?) | Resol:- | Init:TYPE_UNKNOWN | */
	uint8_t color;
} SMeterVector;

/**
* @brief The input of RCarHMIManagement SWC.
*/
typedef struct {
    ST_FRONT_CAM_OBJ MasterObjDataModified[ NUM_MASTER_OBJ_DATA ]; /**< | Def: | Unit: | Range: | Resol: | Init: | */
	SGeneralObj surround_objects_info[NUM_OBS_MEMORY_64]; 					/**< | Def:???. Wanted better name... | Unit:- | Range:- | Resol:- | Init:- | */
    ST_FRONT_CAM_LANE       front_cam_lane[2];                     /**< | Def:Front camera lane information. |  */		/* Added by TCS as per review ID 10 */
    ST_FRONT_CAM_LANE_SEL	front_cam_lane_sel;																			/* Added by TCS as per review ID 10 */
	ST_VEHICLE_STATUS       vehicle_status;                        /**< | Def:Ego vehicle information. |  */			/* Added by TCS as per review ID 10 */
    ST_CTRL_FLAG            ctrl_flag;                             /**< | Def:Control flag from RH850. |  */			/* Added by TCS as per review ID 10 */
	ST_PREC_VEHICLE_INFO 	prec_vehicle_info;                     /**< | Def:Preceding vehicle information. | Unit:- | Range:- | Resol:- | Init:- | */		
	MapTranslator_HMI_t		maptranslator_hmi;																			/* Added by TCS as per review ID 10 */
	uint32_t 				lane_type[5];																				/* Added by TCS as per review ID 10 */
	uint32_t 				road_class;																					/* Added by TCS as per review ID 10 */
	uint32_t				lat_pos;
} SRcarHMIManagementInput;

/**
 * @brief The output of RCarHMIManagement SWC.
 */
typedef struct {
	slMeterVec meter_vec[NUM_METER_VEC_OBJ];			/**	< | Def: | Unit: | Range: | Resol: | Init: | */
	SGeneralDispObj Disp_Centre_Vehicle;							/**	< | Output of DispMeter_10Obj */
} SRcarHMIManagementOutput;

/**
* @brief The input of ObjectSelectionAVM SWC.
*/
typedef struct {
   SGeneralObj sorted_side_radar_obj[NUM_SIDE_RADAR_OBJ_28];              /**< | Def:Sorted side radar objects. | Unit:- | Range:- | Resol:- | Init:- | */
   double 	   vsp;			/**< | Def:Vehicle Speed [ mps ]| Unit: | Range: | Resol: | Init: | */
   double 	   yaw_rate;					/**< | Def:Yawrate | Unit: | Range: | Resol: | Init: | */
} SObjectSelectionAVMInput;

/**
 * @brief The output of ObjectSelectionAVM SWC.
 */
typedef struct {
    SGeneralObj sr_object_avm[NUM_NEXT_LANE_OBJ_AVM]; /**< | Def: | Unit: | Range: | Resol: | Init: | */
} SObjectSelectionAVMOutput;

/**
* @brief The input of ObjectSelectionDM SWC.
*/
typedef struct {
    SGeneralObj surround_obj_left[NUM_SURROUND_OBJ_20];                    /**< | Def:Selected objects on left lane. | Unit:- | Range:- | Resol:- | Init:- | */
    SGeneralObj surround_obj_right[NUM_SURROUND_OBJ_20];                   /**< | Def:Selected objects on right lane. | Unit:- | Range:- | Resol:- | Init:- | */
} SObjectSelectionDMInput;

/**
 * @brief The output of ObjectSelectionDM SWC.
 */
typedef struct {
    SGeneralObj nearest_obj[NUM_NEXT_LANE_OBJ_DM];     /**< |Def:FrontLeft:-nearest_obj[0],FrontRight:-nearest_obj[1],RearLeft:-nearest_obj[2], RearRight:- nearest_obj[3] |Unit:-|Range:-|Resol:-|Init:-| Define some other Name ??|	*/
} SObjectSelectionDMOutput;

/*-------------------*
 * Structure for Internal I/F
 *-------------------*/
typedef struct MBH_Disp_ {
	BOOL_t flg_valid;
	BOOL_t flg_usable;
	Vector_t pos;
	Vector_t vel;
	uint8_t type;

	int32_t lane;
	double lat_pos_in_lane;
	double width;
	BOOL_t matched;
	BOOL_t highlight;
} MBHDisp_t;

typedef struct {
	double filt_in;
	double filt_out;
	double rate_output;
	double backlash_in;
	double backlash_out;
}Filter_z1_t;

typedef struct DispObj_ {
	Vector_t pos;
	Vector_t vel;
	double lat_pos_in_lane;
	double lat_pos_in_z1;
	double lat_pos_out;
	double lat_in_disp;
	double x_z1;
	double width;
	int32_t cnt_off;
	int32_t cnt_on;
	uint8_t type;
	int32_t lane;
	int32_t lane_z1;
	int32_t lane_out_z1;
	int32_t lane_cnt;
	BOOL_t flg_off;
	uint8_t type_target;
	uint8_t state_z1;
	Filter_z1_t filt_x;
	Filter_z1_t filt_y;
	BOOL_t highlight;
} DispObj_t;

 /*-------------------*
 * Function Declaration for ECU code
 *-------------------*/
#ifndef MATLAB_MEX_FILE
#ifdef __cplusplus
namespace RCarHMIManagement {
NAP_RET get_input(SRcarHMIManagementInput* input_data);
NAP_RET set_output(const SRcarHMIManagementOutput& output_data);
}

namespace ObjectSelectionAVM {
NAP_RET get_input(SObjectSelectionAVMInput* input_data);
NAP_RET set_output(const SObjectSelectionAVMOutput& output_data);
}

namespace ObjectSelectionDM {
NAP_RET get_input(SObjectSelectionDMInput* input_data);
NAP_RET set_output(const SObjectSelectionDMOutput& output_data);
}
#endif /* __cpluplus */
#endif /* MATLAB_MEX_FILE */

#endif /* SURROUND_INFO_IO_H_ */
