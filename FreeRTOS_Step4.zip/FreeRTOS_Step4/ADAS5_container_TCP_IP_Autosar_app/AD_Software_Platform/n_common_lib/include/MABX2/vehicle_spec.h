/**
 * @file
 * @brief
 *
 * @author
 */

#ifndef VEHICLE_SPEC_H_
#define VEHICLE_SPEC_H_


/*------------------*
 * macro definition *
 *------------------*/
#define OVERALL_LENGTH	(4.815)
#define OVERALL_WIDTH	(1.820)
#define FRONT_OVERHANG	(0.845) // this value is old model's value. Overall length is 25mm short.

#endif
