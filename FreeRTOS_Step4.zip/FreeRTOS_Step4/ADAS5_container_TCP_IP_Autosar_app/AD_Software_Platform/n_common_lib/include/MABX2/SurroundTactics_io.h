#ifndef SURROUND_TACTICS_IO_H_
#define SURROUND_TACTICS_IO_H_
/** *********************************************************
 * @file  SurroundTactics_io.h
 * @brief mABOX2�� SurroundTactics ��I/F ��`�E�\���� �w�b�_
 * @author n.hodohara
 * @date   2018/09/26
 ***********************************************************/
#ifdef ENABLE_MABX2_ALCREQUEST
#include "ALCRequest_io.h"
#endif
#include "SurroundFusion_io.h"
#ifdef ENABLE_MABX2_LANESELECTOR
#include "LaneSelector_IF.h"
#endif
#include "mabx2_common.h"
#include "util_vector.h"

/*-------------------*
 * Definitions
 *-------------------*/

#define SURROUND_OBJ_MAX 20
#define ALC_POS_JDG_SAMPLING_SEC 0.05
#define TRAF_AWARE_SAMPLING_SEC 0.1

/*-------------------*
 * Structure
 *-------------------*/
/**
 * @brief A part of output of auto_lane_change_jdg_n.
 */
typedef struct {
    Vector_t pos;       /**< @brief | Def:Position of the obj. | Unit:m | Range:- | Resol:- | Init:[0.0,0.0] | */
    Vector_t vel;       /**< @brief | Def:Velocity of the obj. | Unit:m/s | Range:- | Resol:- | Init:[0.0,0.0] | */
    double   gap_rear;  /**< @brief | Def:Gap from rear of the obj. | Unit:m | Range:- | Resol:- | Init:0.0 | */
    double   gap_front; /**< @brief | Def:Gap from front of the obj. | Unit:m | Range:- | Resol:- | Init:0.0| */
    uint32_t num_sel;   /**< @brief | Def:The index of the selected obj in array of fusioned objects. | Unit:- | Range:[0,20) | Resol:- | Init:0 | */
    BOOL_t   flg;       /**< @brief | Def:Flag whether a side vehicle is selected or not. | Unit:boolean | Range:- | Resol:- | Init:FALSE | */
} SSideTargetObj;

/*-------------------*
 * Structure for External I/F
 *-------------------*/
/**
 * @brief The input of TrafficAware SWC.
 */
typedef struct {
    SGeneralObj           clustered_side_radar_obj[NUM_CLUSTERED_SIDE_RADAR_OBJ_20]; /**< @brief | Def:Clustered side radar objects. | Unit:- | Range:- | Resol:- | Init:- | */
    ST_FRONT_CAM_OBJ      front_cam_obj[NUM_FRONT_CAMERA_OBJ_10];                    /**< @brief | Def:Front camera objects. | Unit:- | Range:- | Resol:- | Init:- | */
    ST_FRONT_CAM_LANE     front_cam_lane[NUM_LANE_2];                                /**< @brief | Def:Front camera lane information. | Unit:- | Range:- | Resol:- | Init:- | */
    ST_FRONT_CAM_NEXTLANE front_cam_nextlane[NUM_LANE_2];                            /**< @brief | Def:Front camera next-lane information. | Unit:- | Range:- | Resol:- | Init:- | */
    ST_CTRL_FLAG          ctrl_flag;      /**< @brief | Def:Control flag from RH850. Actually use only F_x_Lch_on, V_x_Lch_dir_fix, F_x_Lch|Unit:-|Range:-|Resol:-|Init:-| */
    ST_VEHICLE_STATUS     vehicle_status; /**< @brief | Def:Ego vehicle information. | Unit:- | Range:- | Resol:- | Init:- | */
    uint8_t               merge_dir;      /**< @brief | Def:Direction of merge line. | Unit:0:none,1:left,2:right | Range:- | Resol:- | Init:0 | */
    BOOL_t                f_merge_line;   /**< @brief | Def:Flag whether merge line exists. | Unit:boolean | Range:- | Resol:- | Init:FALSE | */
    int32_t               clustered_side_radar_obj_num; /**< @brief | Def: the number of clustered Side Radar Objects. | Unit:- | Range:[0,20] | Resol:- | Init:0 | */ /** Added by TCS 20181025*/
    int32_t               front_cam_obj_num; /**< @brief |Def:the number of front camera objects. |Unit:- |Range:[0,10] |Resol:- |Init:0 | */
} STrafficAwareInput;

/**
 * @brief The output of TrafficAware SWC.
 */
typedef struct {
    SGeneralObj mbh_objects[NUM_OBS_MEMORY_64]; /**< @brief | Def:unique objects detected by all_obs_calc_main | Unit:- | Range:- | Resol:- | Init:- | */
    double      near_object_pos_x[3];           /**< @brief | Def:posittion of near 3 objects. | Unit:m | Range:- | Resol:- | Init:0.0 | */
    double      pass_offset;                    /**< @brief | Def:lateral distance to be offset. | Unit:m | Range:- | Resol:- | Init:0.0 | */
} STrafficAwareOutput;

/**
 * @brief The input of AutoLCPossibilityJdg (auto_lane_change_jdg1) SWC.
 */
typedef struct {
    SGeneralObj          surround_obj_left[SURROUND_OBJ_MAX];                    /**< @brief | Def:Selected objects on left lane. | Unit:- | Range:- | Resol:- | Init:- | */
    SGeneralObj          surround_obj_rearcenter[NUM_SURROUND_OBJ_REARCENTER_4]; /**< @brief | Def:Selected objects on rear-center lane. | Unit:- | Range:- | Resol:- | Init:- | */
    SGeneralObj          surround_obj_right[SURROUND_OBJ_MAX];                   /**< @brief | Def:Selected objects on right lane. | Unit:- | Range:- | Resol:- | Init:- | */
	BOOL_t               f_LaneChangeReq[NUM_LANE_2];							 /**< @brief | Def:System(R-Car) request for lane change. | Unit:- | Range:- | Resol:- | Init:- | */
    ST_CTRL_FLAG         ctrl_flag;              /**< @brief | Def:Control flag from RH850. Actually use only F_x_Lch_on, V_x_Lch_dir_fix, F_x_Lch|Unit:-|Range:-|Resol:-|Init:-| */
    ST_VEHICLE_STATUS    vehicle_status;         /**< @brief | Def:Ego vehicle information. | Unit:- | Range:- | Resol:- | Init:- | */
    ST_PREC_VEHICLE_INFO prec_vehicle_info;      /**< @brief | Def:Preceding vehicle information. | Unit:- | Range:- | Resol:- | Init:- | */
    BOOL_t               merge_area[NUM_LANE_2]; /**< @brief | Def:Flag whether there is merge area. | Unit:boolean | Range:- | Resol:- | Init:FALSE | */
    BOOL_t               cutin_area[NUM_LANE_2]; /**< @brief | Def:Flag whether there is cut-in (to be merged) area. | Unit:boolean | Range:- | Resol:- | Init:FALSE | */
    uint8_t              V_x_SigSetSpeed;        /**< |Def:User setting speed for AutoCruseControl. |Unit:m/s |Range:[0.0,-] |Resol:- | */
} SAutoLCPossibilityJdgInput;

/**
 * @brief The output of AutoLCPossibilityJdg (auto_lane_change_jdg1) SWC.
 */
typedef struct {
    SSideTargetObj side_radar_tgt[NUM_LANE_2];       /**< @brief | Def:Object on side of host-vehicle to be followed. | Unit:- | Range:- | Resol:- | Init:- | */
    uint8_t        lane_change_possible[NUM_LANE_2]; /**< @brief | Def:Whether host-vehicle can change lane to Left/Right. | Unit:0:Low,1:Middle,2:High | Range:0~2 | Resol:- | Init:[0,0] | */
} SAutoLCPossibilityJdgOutput;

/*-------------------*
 * Structure for Internal I/F
 *-------------------*/

/*-------------------*
* Function Declaration for ECU code
*-------------------*/
#ifndef MATLAB_MEX_FILE
#ifdef __cplusplus
namespace AutoLCPossibilityJdg {
NAP_RET get_input(SAutoLCPossibilityJdgInput* input_data);
NAP_RET set_output(const SAutoLCPossibilityJdgOutput& output_data);
}
namespace TrafficAware {
void initialize_obj_checker(void);
NAP_RET get_input(STrafficAwareInput* input_data);
NAP_RET set_output(const STrafficAwareOutput& output_data);
}
#endif /* __cpluplus */
#endif /* MATLAB_MEX_FILE */

#endif /* SURROUND_TACTICS_IO_H_ */
