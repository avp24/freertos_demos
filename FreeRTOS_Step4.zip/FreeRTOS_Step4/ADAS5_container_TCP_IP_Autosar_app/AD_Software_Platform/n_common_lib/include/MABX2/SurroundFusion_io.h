#ifndef SURROUND_FUSION_IO_H_
#define SURROUND_FUSION_IO_H_
/** *********************************************************
 * @file  SurroundFusion_io.h
 * @brief mABOX2 SurroundFusion I/F structures & functions.
 * @author n.hodohara
 * @date   2018/09/25
 ***********************************************************/
#ifdef ENABLE_MABX2_LANESELECTOR
#include "LaneSelector_IF.h"
#endif
#include "mabx2_common.h"

/*-------------------*
 * Definitions
 *-------------------*/
#define NUM_SURROUND_OBJ_REARCENTER_4 4 /**< |Def:the number of detected rear center objects. |Unit:-|  */
#define NUM_LINE_HISTORY_9 9u           /**< |Def:Number of history logged by LaneMemory2 module.|Unit:-| */
#define FCAM_INVALID_ID 255u

typedef enum { SURROUND_DIR_LEFT = 0, SURROUND_DIR_RIGHT = 1, SURROUND_DIR_REAR_CENTER = 2, SURROUND_DIR_MAX = 3 } SURROUND_DIR;

/*-------------------*
 * Structure for External I/F
 *-------------------*/
/* ST_TA_PREC_VEHICLE */
typedef struct
{
	float		V_m_Ta_PrecVehicleDistance;
	float		V_mps_Ta_PrecVehicleRelVelocity;
	float		V_mps2_Ta_PrecVehicleRelAccel;
	float		V_m_Ta_PrecVehicleLatDistance;
	uint8		V_x_Ta_PrecVehicleDynamic;
	uint8		V_x_Ta_PrecVehicleObjType;
	uint8		V_x_Ta_PrecVehicleObjID;
	float		V_mps_Ta_PrecVehicleVelocity;
} ST_TA_PREC_VEHICLE;

/**
 * @brief The input of SurroundFusion SWC.
 */
typedef struct {
    ST_FRONT_SIDE_RADAR_OBJ front_left_radar_obj[NUM_SIDE_FRONT_RADAR_OBJ_6];  /**< | Def:Front-Left  side radar objects. |  */
    ST_FRONT_SIDE_RADAR_OBJ front_right_radar_obj[NUM_SIDE_FRONT_RADAR_OBJ_6]; /**< | Def:Front-Right side radar objects. |  */
    ST_REAR_SIDE_RADAR_OBJ  rear_left_radar_obj[NUM_SIDE_REAR_RADAR_OBJ_8];    /**< | Def:Rear-Left   side radar objects. |  */
    ST_REAR_SIDE_RADAR_OBJ  rear_right_radar_obj[NUM_SIDE_REAR_RADAR_OBJ_8];  /**< | Def:Rear-Right  side radar objects. |  */
    ST_SIDE_RADAR_STATUS    side_radar_status[4];                              /**< | Def:Status for 4 side radars. |  */
    ST_FRONT_CAM_OBJ        front_cam_obj[NUM_FRONT_CAMERA_OBJ_10];            /**< | Def:Front camera objects. |  */
    ST_FRONT_CAM_LANE       front_cam_lane[2];                                 /**< | Def:Front camera lane information. |  */
    ST_FRONT_CAM_NEXTLANE   front_cam_nextlane[2];                             /**< | Def:Front camera next-lane information. |  */
    ST_FRONT_CAM_ROADINFO   front_cam_roadinfo;                                /**< | Def:Road information from front camera |  */
    ST_VEHICLE_STATUS       vehicle_status;                                    /**< | Def:Ego vehicle information. |  */
    ST_CTRL_FLAG            ctrl_flag;                                         /**< | Def:Control flag from RH850. |  */
	LaneSelector_LaneInfo_t map_lane_grid;                                     /**< | Def:Lane grid made from HD-Hamp. |  */
    ST_FRONT_RADAR_ST_OBJ  front_radar_st_obj;  /**< | Def:Rear-Right  side radar objects. |  */
} SSurroundFusionInput;

/**
 * @brief The output of SurroundFusion SWC.
 */
typedef struct {
    SGeneralObj surround_obj_nextleft[NUM_SURROUND_OBJ_20];                /**< | Def:Selected objects on next-left lane. |  */
    SGeneralObj surround_obj_left[NUM_SURROUND_OBJ_20];                    /**< | Def:Selected objects on left lane. |  */
    SGeneralObj surround_obj_rearcenter[NUM_SURROUND_OBJ_REARCENTER_4];    /**< | Def:Selected objects on rear-center lane. |  */
    SGeneralObj surround_obj_right[NUM_SURROUND_OBJ_20];                   /**< | Def:Selected objects on right lane. |  */
    SGeneralObj surround_obj_nextright[NUM_SURROUND_OBJ_20];               /**< | Def:Selected objects on next-right lane. |  */
    SGeneralObj surround_obj_center[NUM_SURROUND_OBJ_20];                  /**< | Def:Selected objects on center lane. This data is not used currently. |  */
    SGeneralObj sorted_side_radar_obj[NUM_SIDE_RADAR_OBJ_28];              /**< | Def:Sorted side radar objects. |  */
    SGeneralObj clustered_side_radar_obj[NUM_CLUSTERED_SIDE_RADAR_OBJ_20]; /**< | Def:Clustered side radar objects. |  */
    int32_t     clustered_side_radar_obj_num; /**< | Def: Number of Side Radar Objects (?) | Unit:- | Range:- | Resol:- | Init:- | */ /** Added by TCS 20181025*/
    ST_TA_PREC_VEHICLE ta_prec_vehicle;
    float V_m_SideRadarViewRangeRear;
} SSurroundFusionOutput;

/*-------------------*
 * Structure for Internal I/F
 *-------------------*/
/**
 * @brief Position, angle, speed of the ego-vehicle.
 */
typedef struct {
    Vector_t pos_m;     ///< |Def:Position|Unit:m|Range:-|Resol:-|Init:-|
    double   head_rad;  ///< |Def:Head angle|Unit:radian(counterclockwise)|Range:???|Resol:-|Init:-|
    double   speed_mps; ///< |Def:Speed|Unit:m/s|Range:-|Resol:-|Init:-|
} SVehiclePosition;

/**
 * @brief The output data of LaneMemory2. The histroy of L&R lane points which are logged every 100m driving.
 */
typedef struct {
    Vector_t left[NUM_LINE_HISTORY_9];  /**< |Def:Left lane points history.|Unit:m|Range:-|Resol:-|Init:-| */
    Vector_t right[NUM_LINE_HISTORY_9]; /**< |Def:Right lane points history.|Unit:m|Range:-|Resol:-|Init:-| */
    uint8_t
        disp_range_valid[NUM_LANE_5]; /**< | Def:Whether each lane is in disp_range of front camera. (Currently not used, but may be used in future.) | Unit:boolean | Range:- | Resol:- | Init:- | */
} SLineHistory;

/**
    @brief  The data structure for points of a single lane.
*/
typedef struct {
    Vector_t pos[NUM_LANE_POINTS_OUT]; /**< |Def:Grid position of the lane|Unit:m| Range:-| Resolution:-| Initial[0.0, 0.0]| */
    double   width;                    /**< |Def:Width of this lane.|Unit:m|Range:-|Resolution:-|Initial:3.5| */
    int32_t  num_points;               /**< |Def:Number of valid points in this lanes.|Unit:m|Range:0-27|Resolution:1|Initial:0| */
    BOOL_t   is_valid;                 /**< |Def:Valid flag of this lane.|Unit:bool|Range:-|Resolution:-|Initial:false| */
} SLanePoints;

/**
    @brief  The data structure for grid of 5 lanes.
*/
typedef struct {
    SLanePoints lane[NUM_LANE_5]; /**< |Def:Each lane points.|Unit:-|Range:-|Resol:-|Init:-| */
} SLaneGrid;

/*-------------------*
* Function Declaration for ECU code
*-------------------*/
#ifndef MATLAB_MEX_FILE
#ifdef __cplusplus
namespace SurroundFusion {
void initialize_obj_checker(void);
NAP_RET get_input(SSurroundFusionInput* input_data);
NAP_RET set_output(SSurroundFusionOutput& output_data);
}
#endif /* __cpluplus */
#endif /* MATLAB_MEX_FILE */

#endif /* SURROUND_FUSION_IO_H_ */
