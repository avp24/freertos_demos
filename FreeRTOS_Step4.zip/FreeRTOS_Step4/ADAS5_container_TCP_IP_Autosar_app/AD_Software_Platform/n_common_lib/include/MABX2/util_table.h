/**
 * @file
 * @brief �e�[�u�������C���^�[�t�F�[�X
 *
 * @author morimoto
 */

#ifndef UTIL_TABLE_H_
#define UTIL_TABLE_H_


/*---------------*
 * include files *
 *---------------*/

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

/*------------------*
 * macro definition *
 *------------------*/
#ifndef NULL_PTR
/// Null pointer
#define NULL_PTR ((void *)0)
#endif


/*-------------------*
 * struct definition *
 *-------------------*/


/*----------------------*
 * function declaration *
 *----------------------*/
/* Comments for functions are descrived at definition section. */
void BinarySearch(const double x,
									const double xdat[],
									const unsigned int sz,
									unsigned int *const p_up,
									unsigned int *const p_lo);

double LookupTable(const double x,
									 const double xdat[],
									 const double ydat[],
									 const unsigned int sz,
									 const unsigned char flg_clip_h,
									 const unsigned char flg_clip_l,
									 unsigned int *const p_up,
									 unsigned int *const p_lo);

#ifdef __cplusplus
} // extern "C"
#endif /* __cplusplus */

#endif /* UTIL_TABLE_H_ */
