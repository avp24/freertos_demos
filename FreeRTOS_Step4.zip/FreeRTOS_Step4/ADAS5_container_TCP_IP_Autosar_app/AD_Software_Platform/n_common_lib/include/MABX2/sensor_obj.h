#ifndef _SENSOR_OBJ_H_
#define _SENSOR_OBJ_H_

#include "utypedef.h"

/**********************************************************************/
/*  Struct Definition                                                  */
/**********************************************************************/
/* DATA of FRONT RADAR */
/* ST_FRONT_RADAR_ST_OBJ */
typedef struct															/*[14]*/
{																		/*[14]*/
	uint32		llTimeStamp;											/*[14]*/
	float		V_m_ST_Object_Distance_list[8];							/*[14]*/
	float		V_m_ST_Object_Lateral_Distance_list[8];					/*[14]*/
	float		V_mps_ST_Object_Relative_Speed_list[8];					/*[14]*/
	float		V_m_ST_Object_RCS_list[8];								/*[14]*/
	uint8		V_x_ST_Object_Height[8];								/*[14]*/
	uint8		V_x_ST_Object_Measured_list[8];							/*[14]*/
	float		V_m_ST_Object_Width_list[8];							/*[14]*/
	float		V_m_ST_Length_list[8];									/*[14]*/
	uint8		V_x_ST_Object_ID_list[8];								/*[14]*/
} ST_FRONT_RADAR_ST_OBJ;												/*[14]*/

/* DATA of SIDE RADAR */
/* ST_SIDE_RADAR_STATUS */
typedef struct															/*[01]*/
{																		/*[01]*/
    uint32      llTimeStamp;											/*[01]*/
	boolean	F_x_Initialize;												/*[01]*/
	boolean	F_x_FaliureDetected;										/*[01]*/
	boolean	F_x_BlockageDetected;										/*[01]*/
	boolean	F_x_Identification;											/*[01]*/
	uint8	V_pct_AlignmentPercentage;									/*[01]*/
	uint8	V_x_AlignmentStatus;										/*[01]*/
	uint8	V_pct_EOL_AlignmentPercentage;								/*[01]*/
	uint8	V_x_EOL_AlignmentStatus;									/*[01]*/
	uint8	V_x_Confidence;												/*[05]*/
	uint8	V_x_EstStatus;												/*[05]*/
	float	V_m_EstRange;												/*[10]*/
} ST_SIDE_RADAR_STATUS;													/*[01]*/

/* ST_FRONT_SIDE_RADAR_OBJ */
typedef struct
{
    uint32      llTimeStamp;
    uint8       V_x_Id;
    float       V_m_Dist_X;												/*[01]*/
    float       V_m_Dist_Y;												/*[01]*/
	boolean		F_x_ObjectInfoChange;									/*[01]*/
    float       V_mps_Relspd_X;											/*[01]*/
    float       V_mps_Relspd_Y;											/*[01]*/
	uint8		V_x_ObjMagn;											/*[01]*/
	float		V_mps2_Accel_X;											/*[01]*/
	float		V_mps2_Accel_y;											/*[01]*/
    uint8       V_x_RelPos_Frspc;
    uint8       V_x_MtnClass;
	float		V_s_TTCtoObject;										/*[01]*/
	uint8		V_x_MsgCntA;											/*[01]*/
	uint8		V_x_MsgCntB;											/*[01]*/
} ST_FRONT_SIDE_RADAR_OBJ;

/* ST_REAR_SIDE_RADAR_OBJ */
typedef struct
{
    uint32      llTimeStamp;
    uint8       V_x_Id;
    float       V_m_Dist_X;												/*[01]*/
    float       V_m_Dist_Y;												/*[01]*/
	boolean		F_x_ObjectInfoChange;									/*[01]*/
    float       V_mps_Relspd_X;											/*[01]*/
    float       V_mps_Relspd_Y;											/*[01]*/
	uint8		V_x_ObjMagn;											/*[01]*/
	float		V_mps2_Accel_X;											/*[01]*/
	float		V_mps2_Accel_y;											/*[01]*/
    uint8       V_x_RelPos_RdBrdr;
    uint8       V_x_MtnClass;
	float		V_s_TTCtoObject;										/*[01]*/
	uint8		V_x_MsgCntA;											/*[01]*/
	uint8		V_x_MsgCntB;											/*[01]*/
} ST_REAR_SIDE_RADAR_OBJ;

/* DATA of CAMERA */
/* ST_FRONT_CAM_LANE    */
typedef struct															/*[01]*/
{																		/*[01]*/
	uint32	llTimeStamp;												/*[01]*/
	uint8	V_x_LaneType;												/*[01]*/
	uint8	V_x_LaneQuality;											/*[01]*/
	float	V_m_LanePosition;											/*[01]*/
	float	V_pm_LineCurv;												/*[01]*/
	float	V_pm2_LineCurvaRate;										/*[01]*/
	float	V_m_Lane_Mark_Width;										/*[01]*/
	float	V_rad_LineYawAng;											/*[01]*/
	float	V_m_ViewRange_Start;										/*[01]*/
	float	V_m_ViewRange_End;											/*[01]*/
	uint8	V_x_Lane_Crossing;											/*[01]*/
	uint8	F_x_Highway_Exit;											/*[01]*/
	uint8	V_x_Confidence_HWE;											/*[01]*/
} ST_FRONT_CAM_LANE;													/*[01]*/

/* ST_FRONT_CAM_NEXTLANE    */
typedef struct															/*[01]*/
{																		/*[01]*/
	uint32	llTimeStamp;												/*[01]*/
	uint8	V_x_NextLaneType;											/*[01]*/
	uint8	V_x_NextLaneQuality;										/*[01]*/
	float	V_m_NextLanePosition;										/*[01]*/
	float	V_pm_NextLineCurv;											/*[01]*/
	float	V_pm2_NextLineCurvaRate;									/*[01]*/
	float	V_m_NextLane_Mark_Width;									/*[01]*/
	float	V_rad_NextLineYawAng;										/*[01]*/
	float	V_m_NextViewRange_Start;									/*[01]*/
	float	V_m_NextViewRange_End;										/*[01]*/
	float	V_x_ConfMeasure;											/*[11]*/
} ST_FRONT_CAM_NEXTLANE;												/*[01]*/

/* ST_FRONT_CAM_LANE_SEL    */
typedef struct															/*[01]*/
{																		/*[01]*/
	uint32	llTimeStamp;												/*[01]*/
	float	V_rad_Heading_LKA_SEL_LANE;									/*[01]*/
	float	V_m_Position_LKA_SEL_LANE;									/*[01]*/
	uint8	V_x_Quality_LKA_SEL_LANE;									/*[01]*/
	float	V_pm_Curvature_LKA_SEL;										/*[01]*/
	float	V_pm2_Curvature_derivative_LKA_SEL;							/*[01]*/
	uint8	V_x_LINE_SEL_HOKAN;											/*[01]*/
	float	V_m_Lane_Width;												/*[01]*/
	float	V_m_Position_SEL_LANE_Offset;								/*[01]*/
	float	V_m_offset_from_1st_lane;									/*[01]*/
	boolean	F_x_Line_Cross;												/*[01]*/
	float	V_rad_Heading_LKA_SEL_LANE_hokan;							/*[01]*/
	float	V_pm_Curvature_LKA_SEL_hokan;								/*[01]*/
} ST_FRONT_CAM_LANE_SEL;												/*[01]*/

/* ST_FRONT_CAM_ROADINFO    */
typedef struct															/*[01]*/
{																		/*[01]*/
	uint32	llTimeStamp;												/*[01]*/
	boolean	F_x_Construction_Area;										/*[01]*/
	boolean	F_x_Road_Type;												/*[01]*/
	uint8	V_x_Lane_Assignment_Host_Index_0m;							/*[01]*/
	uint8	V_x_Lane_Assignment_Host_Index_35m;							/*[01]*/
	uint8	V_x_NumOfLanes_near;										/*[01]*/ /*[04]*/
	uint8	V_x_NumOfLanes_far;											/*[01]*/ /*[04]*/
	uint8	V_x_Number_Of_Lanes;										/*[01]*/
	float	V_x_HPP_Left_weight;										/*[01]*/
	float	V_x_HPP_Right_weight;										/*[01]*/
	float	V_x_Road_Left_weight;										/*[01]*/
	float	V_x_Road_Right_weight;										/*[01]*/
} ST_FRONT_CAM_ROADINFO;												/*[01]*/

/* ST_FRONT_CAM_OBJ */
typedef struct															/*[01]*/
{																		/*[01]*/
	uint32	llTimeStamp;												/*[01]*/
	uint8	V_x_ObjectID;												/*[01]*/
	uint8	F_x_CIPV;													/*[01]*/
	float	V_x_ObjectLength;											/*[01]*/
	float	V_m_ObjectWidth;											/*[01]*/
	float	V_m_ObjectPosX;												/*[01]*/
	float	V_m_ObjectPosY;												/*[01]*/
	float	V_mps_ObjectVelX;											/*[01]*/
	float	V_mps_ObjectVelY;											/*[05]*/
	uint8	V_x_ObjectType;												/*[01]*/
	uint8	V_x_ObjectStatus;											/*[01]*/
	uint8	V_x_ObjectValid;											/*[01]*/
	uint8	V_x_ObejctBrakeLights;										/*[01]*/
	uint16	V_x_ObjectAge;												/*[01]*/
	uint8	V_x_ObjectLane;												/*[01]*/
	float	V_s_TTC;													/*[01]*/
	float	V_mps2_ObjectAccelX;										/*[01]*/
	uint8	V_x_BlinkInfo;												/*[01]*/
	uint8	V_x_Cutin_and_Out;											/*[01]*/
	float	V_degps_ObjectAngleRate;									/*[01]*/
	float	V_deg_ObjectAngle;											/*[01]*/
	float	V_mps_ObejectRelVelocity;									/*[01]*/
	boolean	F_x_DayTimeIndicator;										/*[01]*/
	float	V_x_ObjectScaleChange;										/*[01]*/
	boolean	F_x_ObjectReplaced;											/*[01]*/
	boolean	F_x_Wall_valid;												/*[01]*/
	uint8	V_x_FCW_Calc_Status;										/*[01]*/
	uint8	V_x_Lane_Movement_Type;										/*[01]*/
	uint8	V_x_MsgCnt;													/*[01]*/
} ST_FRONT_CAM_OBJ;														/*[01]*/

/* DATA of VEHICLE */
/* ST_CTRL_FLAG */
typedef struct
{
    uint32      llTimeStamp;
    uint8       F_x_Lch_on;
    sint8       V_x_Lch_dir_fix;
    uint8       F_x_DriverSteer;
    boolean     F_x_Lanechange_abort;
	uint8		V_x_LatControlModeSel;									/*[01]*/
	boolean		F_x_Lch_pass_announce_toRight;							/*[01]*/
	boolean		F_x_Lch_return_announce_toLeft;							/*[01]*/
	uint8		V_x_InternalACCStatus;									/*[01]*/
	boolean		F_x_HandsOnJdg;											/*[01]*/
	uint8		V_x_ADCtrlStat;											/*[01]*/
	uint8		V_x_NumOfSystemAutoLC_Right;							/*[03]*/
	uint8		V_x_LaneChangeType;										/*[03]*/
	uint8		V_x_ALCInternalStatus;									/*[05]*/
	uint8		V_x_AutoLCDirection;									/*[05]*/
	uint16		V_x_FS_ALCState;										/*[10]*/
	boolean		F_x_InitLane;											/*[05]*/
	boolean		F_x_InitSteer;											/*[05]*/
	boolean		F_x_SteerCntrl2;										/*[05]*/
	boolean		F_x_TurnIndLeftValid;									/*[05]*/
	boolean		F_x_TurnIndRightValid;									/*[05]*/
	sint8		V_x_Lch_dir_pre;										/*[05]*/
	uint8		V_x_OvertakeSpdSet;										/*[13]*/
	uint8		V_x_AutoLC_Reason;										/*[13]*/
} ST_CTRL_FLAG;

/* ST_VEHICLE_STATUS    */
typedef struct
{
    uint32      llTimeStamp;
    float       V_mps_AVE_VSP;											/*[01]*/
    float       V_mps_VSP_LPF;											/*[01]*/
    float       V_mps_VehicleSpeed_Est;									/*[01]*/
    uint8       V_x_TurnInd;
    uint8       V_x_TURN_IND_Filter;
    boolean     F_x_MainSwOn4;
    float       V_rad_PINION_ANGLE;										/*[01]*/
    float		V_degps_YawRateCorrected;								/*[01]*/ /*[03]*/
    float       V_kmph_VDC_VSP;											/*[01]*/
    uint8       V_x_Turn_Signal_Com;
	boolean		F_x_CancelButton;										/*[01]*/
	float		V_m_ycr_l;												/*[01]*/
	float		V_rad_phi_l;											/*[01]*/
	float		V_pm_rho_l;												/*[01]*/
	float		V_degps_OfstYawrate;									/*[03]*/
	float		V_degps_YawRate02;										/*[03]*/
	float		V_deg_StrAngle;											/*[03]*/
	uint8		V_x_IND_RNG;											/*[03]*/
	float		V_rpm_WRRL;												/*[03]*/
	float		V_rpm_WRRR;												/*[03]*/
	float		V_rpm_WRFL;												/*[03]*/
	float		V_rpm_WRFR;												/*[03]*/
	uint8		V_top_WSPRR;											/*[05]*/
	uint8		V_top_WSPRL;											/*[05]*/
	float		V_bar_PRSSR_SENSR_VAL;									/*[05]*/
	float		V_pct_RawPedal_APOFS;									/*[05]*/
	boolean		F_x_BPFS_NO;											/*[05]*/
} ST_VEHICLE_STATUS;

/* DATA of PRECEDING */
/* ST_PREC_VEHICLE_INFO     */
typedef struct															/*[01]*/
{																		/*[01]*/
	uint32		llTimeStamp;											/*[01]*/
	boolean		F_x_Target;												/*[01]*/
	float		V_m_Distance;											/*[01]*/
	float		V_m_PrecVehicleLatDistance;								/*[05]*/
	float		V_mps_TargetSpeed;										/*[01]*/
	float		V_mps2_PrecVehicleAcceleration_Est;						/*[01]*/
	float		V_mps_RelativeSpeed;									/*[01]*/
	float		V_s_TimeToCollision_Est;								/*[01]*/
	boolean		F_x_ObjectStationary;									/*[01]*/
	boolean		F_x_Obstacle;											/*[01]*/
	uint8		V_x_SENSOR_SEL;											/*[03]*/
	uint8		V_x_SensorSelEgo;										/*[05]*/
	float		V_mps2_DecelerationEgo;									/*[05]*/
	float		V_mps_RelativeSpeedEgo;									/*[01]*/
	float		V_m_DistanceEgo;										/*[01]*/
} ST_PREC_VEHICLE_INFO;													/*[01]*/

/* CamLane : Lane Type */
#define LANE_TYPE_UNDECIDED		0
#define LANE_TYPE_SOLID			1
#define LANE_TYPE_DASHED		2
#define LANE_TYPE_DOUBLE_LINE	4
#define LANE_TYPE_BOTTS_DOTS	7
#define LANE_TYPE_ROAD_EDGE		10
#define LANE_TYPE_BARRIER		12

/* CamLane : Quality */
#define LANE_QUALITY_VERY_LOW	0
#define LANE_QUALITY_LOW		1
#define LANE_QUALITY_PREDICTION	2
#define LANE_QUALITY_HIGH		3

#endif /* _SENSOR_OBJ_H_ */
