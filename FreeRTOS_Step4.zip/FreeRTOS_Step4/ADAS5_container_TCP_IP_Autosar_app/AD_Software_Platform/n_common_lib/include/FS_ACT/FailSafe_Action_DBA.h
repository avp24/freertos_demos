/******************************************************************************
 *
 *     Copyright (c) 2014 Nissan, Japan
 *
 ******************************************************************************
 *
 * Project:     Failsafe
 * Module:      DBA
 * Version      
 * Author:      
 * Date:        
 * Description: 
 * Revision History:
 *
******************************************************************************/
#ifndef __FAILSAFE_ACTION_DBA_H__
#define __FAILSAFE_ACTION_DBA_H__

#include "data_types.h"
#include "n_common.h"
#include "FailSafe_Action_FCA.h"
#include "spec.h"

#ifdef  __FAILSAFE_ACTION_DBA_C__
#define EXTERN
#else
#define EXTERN extern
#endif


/* ################################################ */
/*	�萔�錾                                        */
/* ################################################ */
/*-----------------*/
/* Control mode    */
/*-----------------*/

/*-----------------*/
/* Action table    */
/*-----------------*/
typedef union{
	uint16	data;
	struct{
#if (DYNAMIC_EMULATOR || LITTLE_ENDIAN_SW) /*** little endian ***//* ���g���G���f�B�A���Ή� Task #8556 */
	uint8	pad1				:7;
	uint8	CAN_DBA				:1;		/* �ً}���������t���O         */
	uint8	U08_Emerge_Brk;				/* �ً}�����u���[�L�A�N�V���� */
#else /* DYNAMIC_EMULATOR */
	uint8	U08_Emerge_Brk;				/* �ً}�����u���[�L�A�N�V���� */
	uint8	CAN_DBA				:1;		/* �ً}���������t���O         */
	uint8	pad1				:7;
#endif /* DYNAMIC_EMULATOR */
	}val;
}T_FS_DBAFailState;

/*-----------------*/
/* Action flag     */
/*-----------------*/
/* Action type */
#define	eFS_DBA_NOCHECK		(0x00000000)
#define	eFS_DBA_FAIL_01		(BRK_FAST|EMERGE_BRAKE_CANC|EMERGE_BRAKE_INH)
#define	eFS_DBA_FAIL_02		(BRK_FAST|EMERGE_BRAKE_CANC)
#define	eFS_DBA_FAIL_03		(BRK_STANDARD|EMERGE_BRAKE_CANC|EMERGE_BRAKE_INH)
#define	eFS_DBA_FAIL_04		(BRK_STANDARD|EMERGE_BRAKE_CANC)
#define	eFS_DBA_FAIL_05		(BRK_OFF|EMERGE_BRAKE_CANC|EMERGE_BRAKE_INH)

/* eFS_DBA_FAIL_06 -> if OFFLAMP_COMMON == 1 then eFS_DBA_FAIL_08 else eFS_DBA_NOCHECK */
/* eFS_APPLI_FCW, eFS_APPLI_FEBCamFEB, eFS_APPLI_DBA, eFS_APPLI_EAP2 �p�̃G���[���b�Z�[�W�Ɣ��Ȃ����̂�ݒ肷�� */
#define eFS_DBA_FAIL_06		0xFFFFFFFF

#define	eFS_DBA_FAIL_08		(EMERGE_BRAKE_INH)
#define	eFS_DBA_FAIL_09		(BRK_SLOW|EMERGE_BRAKE_CANC|EMERGE_BRAKE_INH)

/* ################################################ */
/*  �v���g�^�C�v�錾                                */
/* ################################################ */
EXTERN void vFS_FailSafe_Action_DBA(void);
EXTERN const uint16 ui16_FS_GetDBAFailState( void );


#undef EXTERN
#endif
