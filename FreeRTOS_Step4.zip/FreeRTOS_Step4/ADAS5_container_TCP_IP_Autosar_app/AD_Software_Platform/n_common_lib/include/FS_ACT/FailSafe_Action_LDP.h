/******************************************************************************
 *
 *     Copyright (c) 2015 Nissan, Japan
 *
 ******************************************************************************
 *
 * Project:     Failsafe flag convert
 * Module:      LDP/LDW flag set
 * Version      1.0
 * Author:      
 * Date:        
 * Description: This file contains LDP/LDW failsafe entry point 
 * Revision History:
 *
******************************************************************************/
#ifndef	__FAILSAFE_ACTION_LDP_H__
#define	__FAILSAFE_ACTION_LDP_H__

#include "data_types.h"
#include "n_common.h"

#ifdef  __FAILSAFE_ACTION_LDP_C__
	#define	EXTERN
#else
	#define	EXTERN	extern
#endif	/* __FAILSAFE_ACTION_LDP_C__ */

/* ################################################ */
/*	�萔�錾                                        */
/* ################################################ */
/*-----------------*/
/* Action flag     */
/*-----------------*/
#define	eFS_LDW_NOCHECK			(0x0000)	/* 0000 0000 0000 0000 */
#define	eFS_LDW_FAIL_A			(0x0001)	/* 0000 0000 0000 0001 */
#define	eFS_LDW_FAIL_B			(0x0002)	/* 0000 0000 0000 0010 */
#define	eFS_LDW_FAIL_C			(0x0004)	/* 0000 0000 0000 0100 */
#define	eFS_LDW_FAIL_D			(0x0008)	/* 0000 0000 0000 1000 */
#define	eFS_LDW_FAIL_E			(0x0010)	/* 0000 0000 0001 0000 */
#define	eFS_LDW_FAIL_F			(0x0020)	/* 0000 0000 0010 0000 */
#define	eFS_LDW_FAIL_G			(0x0040)	/* 0000 0000 0100 0000 */
#define	eFS_LDW_FAIL_H			(0x0080)	/* 0000 0000 1000 0000 */
#define	eFS_LDW_FAIL_I			(0x0100)	/* 0000 0001 0000 0000 */

/* ################################################ */
/*  �v���g�^�C�v�錾                                */
/* ################################################ */
EXTERN	void	vFS_FailSafe_Action_LDP( void );
EXTERN	const uint16 ui16_FS_GetLDWFailState( void );

#undef EXTERN

#endif	/* __FAILSAFE_ACTION_LDP_H__ */
