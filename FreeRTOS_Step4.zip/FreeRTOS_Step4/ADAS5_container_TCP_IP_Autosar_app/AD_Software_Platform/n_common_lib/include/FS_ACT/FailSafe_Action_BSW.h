/******************************************************************************
 *
 *     Copyright (c) 2015 Nissan, Japan
 *
 ******************************************************************************
 *
 * Project:     Failsafe flag convert
 * Module:      BSW flag set
 * Version      1.0
 * Author:      
 * Date:        
 * Description: This file contains BSW failsafe entry point 
 * Revision History:
 *
******************************************************************************/
#ifndef	__FAILSAFE_ACTION_BSW_H__
#define	__FAILSAFE_ACTION_BSW_H__

#include "data_types.h"
#include "n_common.h"

#ifdef  __FAILSAFE_ACTION_BSW_C__
	#define	EXTERN
#else
	#define	EXTERN	extern
#endif	/* __FAILSAFE_ACTION_BSW_C__ */

/* ################################################ */
/*	�萔�錾                                        */
/* ################################################ */
/*-----------------*/
/* Action table    */
/*-----------------*/
#define	eFS_BSW_NOCHECK		(0x0000)
#define	eFS_BSW_FAIL_A		(0x0001)
#define	eFS_BSW_FAIL_B		(0x0002)
#define	eFS_BSW_FAIL_C		(0x0004)
#define	eFS_BSW_FAIL_D		(0x0008)
#define	eFS_BSW_FAIL_E		(0x0010)
#define	eFS_BSW_FAIL_F		(0x0020)
#define	eFS_BSW_FAIL_G		(0x0040)
#define	eFS_BSW_FAIL_X		(0x0080)
#define	eFS_BSW_FAIL_Y		(0x0100)
#define	eFS_BSW_FAIL_H		(0x0200)
#define	eFS_BSW_FAIL_I		(0x0400)
#define	eFS_BSW_IDM_BSI		(0x2000)
#define	eFS_BSW_FAIL		(0x4000)
#define	eFS_BSW_SW_OFF		(0x8000)

/* ################################################ */
/*  �v���g�^�C�v�錾                                */
/* ################################################ */
EXTERN	void	vFS_FailSafe_Action_BSW( void );
EXTERN	const uint16 ui16_FS_GetBSWFailState( void );


#undef EXTERN
#endif	/* __FAILSAFE_ACTION_BSW_H__ */
