/******************************************************************************
 *
 *     Copyright (c) 2015 Nissan, Japan
 *
 ******************************************************************************
 *
 * Project:     Failsafe flag convert
 * Module:      FCW flag set
 * Version      1.0
 * Author:      
 * Date:        
 * Description: This file contains FCW application entry point 
 * Revision History:
 *
******************************************************************************/
#ifndef __FAILSAFE_ACTION_FCW_H__
#define __FAILSAFE_ACTION_FCW_H__

#include "data_types.h"
#include "n_common.h"

#ifdef  __FAILSAFE_ACTION_FCW_C__
#define EXTERN
#else
#define EXTERN extern
#endif	/* __FAILSAFE_ACTION_FCW_C__ */

/* ################################################ */
/*	�萔�錾                                        */
/* ################################################ */
/*-----------------*/
/* Action flag     */
/*-----------------*/
/* RADAR FCW */
#define	eFS_RAD_FCW_NOCHECK		(0x0000)	/* 0000 0000 0000 0000 */
#define	eFS_RAD_FCW_FAIL_A		(0x0001)	/* 0000 0000 0000 0001 */

/* CAMERA FCW */
#define	eFS_FCW_NOCHECK			(0x0000)	/* 0000 0000 0000 0000 */
#define	eFS_FCW_FAIL_A			(0x0001)	/* 0000 0000 0000 0001 */
#define	eFS_FCW_FAIL_B			(0x0002)	/* 0000 0000 0000 0010 */
#define	eFS_FCW_FAIL_C			(0x0004)	/* 0000 0000 0000 0100 */
#define	eFS_FCW_FAIL_D			(0x0008)	/* 0000 0000 0000 1000 */
#define	eFS_FCW_FAIL_E			(0x0010)	/* 0000 0000 0001 0000 */
#if	1	/* HapticBrake�����g�� */
#define	eFS_FCW_FAIL_AHB_INH	(0x0020)	/* 0000 0000 0010 0000 */
#define	eFS_FCW_FAIL_AHB_CAN	(0x0040)	/* 0000 0000 0100 0000 */
#endif
#define	eFS_FCW_FAIL_FCTA		(0x0080)	/* 0000 0000 1000 0000 */
#define	eFS_FCW_INH				(0x4000)	/* 0100 0000 0000 1000 */
#define	eFS_FCW_BLINK			(0x8000)	/* 1000 0000 0001 0000 */

/* eFS_FCW_FAIL_A_OFFLAMP -> if OFFLAMP_COMMON == 1 then eFS_FCW_FAIL_A else eFS_FCW_NOCHECK */
/* eFS_APPLI_FCW, eFS_APPLI_FEBCamFEB, eFS_APPLI_DBA, eFS_APPLI_EAP2 �p�̃G���[���b�Z�[�W�Ɣ��Ȃ����̂�ݒ肷�� */
#define	eFS_FCW_FAIL_A_OFFLAMP	(0xFFFF)	/* 1111 1111 1111 1111 */


/* ################################################ */
/*  �v���g�^�C�v�錾                                */
/* ################################################ */
EXTERN void vFS_FailSafe_Action_FCW(void);
EXTERN const uint16 ui16_FS_GetFCWFailState( void );


#undef EXTERN

#endif	/* __FAILSAFE_ACTION_FCW_H__ */
