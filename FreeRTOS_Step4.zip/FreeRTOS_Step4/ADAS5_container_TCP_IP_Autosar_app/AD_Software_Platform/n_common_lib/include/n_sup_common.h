/******************************************************************************
 *
 *     Copyright (c) 2007 Nissan, Japan
 *
 ******************************************************************************
 *
 * Project:     
 * Module:      n_sup_common.h
 * Version      1.0
 * Author:      
 * Date:        
 * Description: Include header file for Common Function library (Based on Supplier Source Code)
 * Revision History:
 *
******************************************************************************/
#ifndef __N_SUP_COMMON_H__
#define __N_SUP_COMMON_H__

#include "utypedef.h"

extern void OEM_func_memset_UL(
    uint32* ptr,
    uint32  data,
    uint32  num);

extern void OEM_func_memcpy_UL(
    uint32* ptr1,
    uint32* ptr2,
    uint32  num);

#endif          /* __N_SUP_COMMON_H__ */
