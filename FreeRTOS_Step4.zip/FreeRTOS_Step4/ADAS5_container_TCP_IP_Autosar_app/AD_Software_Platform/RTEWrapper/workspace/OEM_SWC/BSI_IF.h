#ifndef __BSI_IF_H__
#define __BSI_IF_H__

//! SWC:BSI
typedef struct {
	Float			V_rad_BSI_SteeringWheelAngle_Req;
	Float			V_x_BSI_GainEpsK1;
	SInt32			V_Nm_LSMOMBOUND_SCP;
	SInt32			V_Nm_SCP_mom_ls;
	SInt32			V_Nm_SCP_mom_ls0prepm;
	SInt32			V_Nm_mom_ls_LDP_SCP;
	SInt32			V_degps_yawrate_SLB;
	UInt8			V_x_BSICnclReason;
	UInt8			V_x_BSI_AlertLeft_v2;
	UInt8			V_x_BSI_AlertRight_v2;
	UInt8			V_x_HMIState_L;
	UInt8			V_x_HMIState_R;
	UInt8			V_x_vBSI_SetCancelReason;
	UInt8			V_x_vMSS_CTA;
	UInt8			V_x_vMssBsSCP;
	UInt8			V_x_vMssBsSOW;
	UInt8			V_x_vMssCMNSCP;
	UInt8			V_x_vSTS_CTA;
	UInt8			V_x_vStsDBs;
	UInt8			V_x_vStsDBs_Inc_TempF;
	UInt8			V_x_vStsWBs;
	UInt8 			V_x_SCP_LSOUT; // Added manually
	Boolean			F_x_AlertSOWJudgeL;
	Boolean			F_x_AlertSOWJudgeR;
	Boolean			F_x_BSIBuzReq;
	Boolean			F_x_BSICnclBuzReq;
	Boolean			F_x_BSI_CancelReq;
	Boolean			F_x_BSI_OverrideOrder;
	Boolean			F_x_BSI_SideDisplayInfo;
	Boolean			F_x_BSI_SteeringAngleRequestOrder;
	Boolean			F_x_BSWBuzOut;
	Boolean			F_x_CTABuzOut;
	Boolean			F_x_CTAChgReq;
	Boolean			F_x_LDPReadyMask;
	Boolean			F_x_LSOUT2_LDP_SCP;
	Boolean			F_x_LSOUT2_SCP_LDP;
	Boolean			F_x_LSOUT2dir_SCP_LDP;
	Boolean			F_x_SCP_ACTIVE2;
	Boolean			F_x_SCP_ACTIVE3;
	Boolean			F_x_SCP_LSOUT;
	Boolean			F_x_SCP_LSOUT2;
	Boolean			F_x_SRcor_imstop_LDW;
	Boolean			F_x_SRcor_ovr_mask_LDW;
	Boolean			F_x_VS_LSOWBlockCondiDetected;
	Boolean			F_x_VS_RSOWBlockCondiDetected;
	Boolean			F_x_fBSI_SW_MAIN_OFF;
	Boolean			F_x_f_LSOUT2_SCP_LDP;
} V_x_BSIDataSet;

#endif // __BSI_IF_H__
