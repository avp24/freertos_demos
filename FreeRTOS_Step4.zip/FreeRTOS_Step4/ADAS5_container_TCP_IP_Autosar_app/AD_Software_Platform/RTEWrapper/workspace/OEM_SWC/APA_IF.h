#ifndef __APA_IF_H__
#define __APA_IF_H__

//! SWC:APA
typedef struct {
	Float			V_Nm_APA_AEBBrkWhlTq3Arbd;
	Float			V_Nm_APA_AEBBrkWhlTqArbd_RD;
	Float			V_Nm_APA_BrkWhlTqArbd;
	Float			V_Nm_APA_BrkWhlTqArbd_RD;
	Float			V_Nm_APA_PLCBrkWhlTqReqRaw;
	Float			V_Nm_APA_PtWhlTqArbd;
	Float			V_Nm_APA_WhlTqLimnReqArbd;
	Float			V_deg_APA_PLCSteerAgReq;
	Float			V_x_APA_PLCSteerGainK1;
	UInt8			V_x_APA_ADmodeSts;
	UInt8			V_x_APA_ADmodeSts_RD;
	UInt8			V_x_APA_AEBBrkWhlTqOrd3Arbd;
	UInt8			V_x_APA_AEBBrkWhlTqOrdArbd_RD;
	UInt8			V_x_APA_BrkWhlTqOrdArbd_RD;
	UInt8			V_x_APA_DoorlockReq;
	UInt8			V_x_APA_EPKBReq;
	UInt8			V_x_APA_GearShifterReqUnarb;
	UInt8			V_x_APA_MirrFoldgReq;
	UInt8			V_x_APA_PLCPrkngSeqSts;
	UInt8			V_x_APA_PLCStdstillReq;
	UInt8			V_x_APA_TurnLampOrd;
	UInt8			V_x_APA_TurnLampReq;
	Boolean			F_x_APA_BrkWhlTqOrdArbd;
	Boolean			F_x_APA_EPKBReq_RD;
	Boolean			F_x_APA_EPKBTout;
	Boolean			F_x_APA_HeadLightReq;
	Boolean			F_x_APA_NominalPathFai;
	Boolean			F_x_APA_PLCStdstillReq;
	Boolean			F_x_APA_PtWhlTqOrdArbd;
	Boolean			F_x_APA_WhlTqLimnOrdArbd;
	Boolean			V_x_APA_ADASAPAFai;
	Boolean			V_x_APA_HzrdLampReq;
	Boolean			V_x_APA_PLCSteerAgOrd;
} V_x_APADataSet;

#endif // __APA_IF_H__
