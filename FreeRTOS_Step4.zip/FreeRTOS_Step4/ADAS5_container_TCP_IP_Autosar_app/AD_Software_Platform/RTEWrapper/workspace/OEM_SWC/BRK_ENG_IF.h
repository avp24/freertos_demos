#ifndef __BRK_ENG_IF_H__
#define __BRK_ENG_IF_H__

//! SWC:BRK_ENG
typedef struct {
	Float			V_Mpa_ItsTrgtPrssr;
	Float			V_nm_PWTWheelTorqueCmd_Request;
	SInt32			V_bar_ACC_BRK_CMD;
	SInt32			V_bar_BrkComSel;
	SInt32			V_mpa_vVC_PBRK_COM_ICC;
	SInt32			V_nm_VC_TP_HEV_CMD;
	SInt16			V_nm_TECMD_M;
	SInt16			V_pct_ApoVal;
	UInt8			V_x_ACC_StandStillRequest;
	UInt8			V_x_AEB_BrakeWheelTorqueOrder_BRKENG;
	UInt8			V_x_AEB_StopStartRequest;
	UInt8			V_x_HighGearInhibitRequest;
	UInt8			V_x_TJP_EPKB_request;
	UInt8			V_x_TJP_StandStillRequest;
	UInt8           V_x_AEB_BrakeWheelTorqueOrder2_BRKENG; // Added manually
	Boolean			F_x_ACCBrakeWheelTorqueOrd;
	Boolean			F_x_ACC_PWTWheelTorqueRequestOrder_NiSW;
	Boolean			F_x_ACC_REQUEST;
	Boolean			F_x_ADAS_HazardLampRequest;
	Boolean			F_x_ADAS_PWTwheelTorqueOrder;
	Boolean			F_x_BlsOn;
	Boolean			F_x_DriverBrake;
	Boolean			F_x_DriverBrake_TJP;
	Boolean			F_x_FcaAct;
	Boolean			F_x_FcaasFlag;
	Boolean			F_x_ISSINH;
} V_x_BRK_ENGDataSet;

#endif // __BRK_ENG_IF_H__
