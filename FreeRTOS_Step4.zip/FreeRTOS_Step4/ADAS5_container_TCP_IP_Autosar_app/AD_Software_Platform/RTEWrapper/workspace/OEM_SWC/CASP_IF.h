#ifndef __CASP_IF_H__
#define __CASP_IF_H__

//! SWC:CASP
typedef struct {
	UInt8			V_x_CoENextZoneType_1;
	UInt8			V_x_CoENextZoneType_2;
	UInt8			V_x_CoENextZoneType_3;
	UInt8			V_x_CoENextZoneType_4;
	UInt8			V_x_CoENextZoneType_5;
	UInt8			V_x_CoENextZoneType_6;
	UInt8			V_x_CoENextZoneType_7;
	UInt8			V_x_CoENextZoneType_8;
	UInt8			V_x_CoENextZoneType_9;
	UInt8			V_x_CoENextZoneType_10;
	UInt8			padding[2];
} V_x_CoENextZoneTypeElement;

//! SWC:CASP
typedef struct {
	Float			V_m_CoEDistance2NextZone_1;
	Float			V_m_CoEDistance2NextZone_2;
	Float			V_m_CoEDistance2NextZone_3;
	Float			V_m_CoEDistance2NextZone_4;
	Float			V_m_CoEDistance2NextZone_5;
	Float			V_m_CoEDistance2NextZone_6;
	Float			V_m_CoEDistance2NextZone_7;
	Float			V_m_CoEDistance2NextZone_8;
	Float			V_m_CoEDistance2NextZone_9;
	Float			V_m_CoEDistance2NextZone_10;
} V_m_CoEDistance2NextZoneElement;

//! SWC:CASP
typedef struct {
	Float			V_m_CoEBreaking_Distance_1;
	Float			V_m_CoEBreaking_Distance_2;
	Float			V_m_CoEBreaking_Distance_3;
	Float			V_m_CoEBreaking_Distance_4;
	Float			V_m_CoEBreaking_Distance_5;
	Float			V_m_CoEBreaking_Distance_6;
	Float			V_m_CoEBreaking_Distance_7;
	Float			V_m_CoEBreaking_Distance_8;
	Float			V_m_CoEBreaking_Distance_9;
	Float			V_m_CoEBreaking_Distance_10;
} V_m_CoEBreaking_DistanceElement;

//! SWC:CASP
typedef struct {
	Float			V_m_CoEAdvice_Distance_1;
	Float			V_m_CoEAdvice_Distance_2;
	Float			V_m_CoEAdvice_Distance_3;
	Float			V_m_CoEAdvice_Distance_4;
	Float			V_m_CoEAdvice_Distance_5;
	Float			V_m_CoEAdvice_Distance_6;
	Float			V_m_CoEAdvice_Distance_7;
	Float			V_m_CoEAdvice_Distance_8;
	Float			V_m_CoEAdvice_Distance_9;
	Float			V_m_CoEAdvice_Distance_10;
} V_m_CoEAdvice_DistanceElement;

//! SWC:CASP
typedef struct {
	Float			V_mps_CoENextZoneSpeed_1;
	Float			V_mps_CoENextZoneSpeed_2;
	Float			V_mps_CoENextZoneSpeed_3;
	Float			V_mps_CoENextZoneSpeed_4;
	Float			V_mps_CoENextZoneSpeed_5;
	Float			V_mps_CoENextZoneSpeed_6;
	Float			V_mps_CoENextZoneSpeed_7;
	Float			V_mps_CoENextZoneSpeed_8;
	Float			V_mps_CoENextZoneSpeed_9;
	Float			V_mps_CoENextZoneSpeed_10;
} V_mps_CoENextZoneSpeedElement;

//! SWC:CASP
typedef struct {
	UInt8			V_x_CoEAdviceStatus_1;
	UInt8			V_x_CoEAdviceStatus_2;
	UInt8			V_x_CoEAdviceStatus_3;
	UInt8			V_x_CoEAdviceStatus_4;
	UInt8			V_x_CoEAdviceStatus_5;
	UInt8			V_x_CoEAdviceStatus_6;
	UInt8			V_x_CoEAdviceStatus_7;
	UInt8			V_x_CoEAdviceStatus_8;
	UInt8			V_x_CoEAdviceStatus_9;
	UInt8			V_x_CoEAdviceStatus_10;
	UInt8			padding[2];
} V_x_CoEAdviceStatusElement;

//! SWC:CASP
typedef struct {
	V_x_CoENextZoneTypeElement		V_x_CoENextZoneType;
	V_m_CoEDistance2NextZoneElement		V_m_CoEDistance2NextZone;
	V_m_CoEBreaking_DistanceElement		V_m_CoEBreaking_Distance;
	V_m_CoEAdvice_DistanceElement		V_m_CoEAdvice_Distance;
	V_mps_CoENextZoneSpeedElement		V_mps_CoENextZoneSpeed;
	V_x_CoEAdviceStatusElement		V_x_CoEAdviceStatus;
	Float			V_est_m_Distance2Event_Model;
	Float			V_m_Distance2LegalSpeed_Model;
	Float			V_est_mps_PredSpeed;
	Float			V_m_D_advice;
	Float			V_m_Breaking_Distances_Model;
	Float			V_x_CASP_OffsetValueRequest;
	UInt8			Var_x_ContextType_Model;
	UInt8			Var_x_AdviceStatus_Model;
	UInt8			Var_x_DisplayColour_Model;
	UInt8			V_x_LegalSpeedNext_1;
	UInt8			V_x_LegalSpeedCurrent_Simu_Model;
	UInt8			V_x_ContextType1_Raw_Model;
	UInt8			V_kph_CurrentLegalSpdZone_Model;
	UInt8			V_x_PrioritizedEvent;
	UInt8			V_x_CASP_OffsetActivationRequest;
	Boolean			F_x_InCurveCASP;
	Boolean			F_x_CASPInfoStatus;
	UInt8			padding;
} V_x_CASPToAD1Enh;

//! SWC:CASP
typedef struct {
	V_x_CASPToAD1Enh		V_x_CASPToAD1Enh;
	Float			V_m_ClosestRadiusCurve;
	Float			V_m_D_ClosestCurve;
	Float			V_m_D_ClosestEndCurve;
	Float			V_m_TSRPredictiveDistance;
	Float			V_mps2_RoadExitControlAcceltnUp;
	Float			V_mps2_RoadExit_ControlAcceleration;
	Float			V_mps2_TSRPredDeceleration;
	Float			V_mps_MinCurveSpeed;
	Float			V_mps_MinRampSpeed;
	Float			V_mps_RoadExit_ControlSpeed;
	Float			V_x_CASPtoFUSION[10];
	Float			V_x_CASPtoLAT[10];
	Float			V_x_CASPtoLONGI[10];
	Float			V_x_CurrentSpeedLimit;
	UInt16			V_x_Current_Event_Radius;
	SInt8			V_x_LKA_CurvDirection;
	UInt8			V_x_CurrentFormOfWay;
	UInt8			V_x_DecelPermitEventNum;
	UInt8			V_x_ExitJudge;
	UInt8			V_x_LKA_NaviCurvDirection;
	UInt8			V_x_MetaSpeedUnit;
	UInt8			V_x_NoSpeedSignModeStatus;
	UInt8			V_x_RoundaboutPermit;
	UInt8			V_x_TSRDisplayNextSpeed;
	UInt8			V_x_TSRDisplaySpeed;
	UInt8			V_x_TSRPredictiveDisplaySpeed;
	UInt8			V_x_TSRPredictiveMode;
	UInt8			V_x_TSRPredictiveRequestSpeed;
	UInt8			V_x_TSRRequestSpeed;
	Boolean			F_x_ACCStandingObjControlReq;
	Boolean			F_x_ApproachToJunction;
	Boolean			F_x_CASPLowAcceleReq;
	Boolean			F_x_ContextSpeed_Decel_Chg;
	Boolean			F_x_CurrentDivider;
	Boolean			F_x_CurvContext_OverrideCancel;
	Boolean			F_x_CurvPrediction;
	Boolean			F_x_CurvPrediction_EnterExit;
	Boolean			F_x_CutInDetectRequest;
	Boolean			F_x_DecelMax;
	Boolean			F_x_DecelPermit_CurveContext;
	Boolean			F_x_DriveHighwayADTutorial;
	Boolean			F_x_DriveHighwayNavi;
	Boolean			F_x_DriveHighwayORJunction;
	Boolean			F_x_DriveHighwayPredACCNavi;
	Boolean			F_x_DriveHighwaySALC;
	Boolean			F_x_DriveHighwayTSRCoop;
	Boolean			F_x_DriveHighwayTSRNavi;
	Boolean			F_x_HweNaviLeft;
	Boolean			F_x_HweNaviRight;
	Boolean			F_x_InhibitAcceleOveridePredACC;
	Boolean			F_x_Inhibit_ICC_LatGDecel;
	Boolean			F_x_LKA_WideLaneCancel;
	Boolean			F_x_NaviTollBooth;
	Boolean			F_x_RampDirectionHMI;
	Boolean			F_x_RoadExitPermtAfterOverride;
	Boolean			F_x_RoadExit_LowAcceleReq;
	Boolean			F_x_RoadExit_SpeedControl;
	Boolean			F_x_Roundabout_LowAccelReq;
	Boolean			F_x_TSRPredictiveAuto;
	Boolean			F_x_TSRPredictiveRequest;
	Boolean			F_x_TSR_Coop_Inhibit;
	Boolean			F_x_TSR_ResumeSpeedUpdate;
	Boolean			F_x_TSR_chg_MaskFlag;
} V_x_CASPDataSet;

#endif // __CASP_IF_H__
