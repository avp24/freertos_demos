#ifndef __AUTOLCPOSSIBILITYJDG_IF_H__
#define __AUTOLCPOSSIBILITYJDG_IF_H__

//! SWC:AutoLCPossibilityJdg
typedef struct {
	Float			V_m_Dcj_ObjLeftPosX;
	Float			V_m_Dcj_ObjLeftPosY;
	Float			V_mps_Dcj_ObjLeftVelX;
	Float			V_mps_Dcj_ObjLeftVelY;
	Float			V_m_Dcj_ObjLeftGapF;
	Float			V_m_Dcj_ObjLeftGapR;
	Float			V_m_Dcj_ObjRightPosX;
	Float			V_m_Dcj_ObjRightPosY;
	Float			V_mps_Dcj_ObjRightVelX;
	Float			V_mps_Dcj_ObjRightVelY;
	Float			V_m_Dcj_ObjRightGapF;
	Float			V_m_Dcj_ObjRightGapR;
	UInt8			V_x_Dcj_ObjLeftNum;
	UInt8			V_x_Dcj_ObjRightNum;
	Boolean			F_x_Dcj_ObjLeft;
	Boolean			V_x_Dcj_ObjRight;
} V_x_ST_OUTPUT_DYNAMIC_CONFL_JDG;

//! SWC:AutoLCPossibilityJdg
typedef struct {
	UInt8			V_x_lane_change_possible_left;
	UInt8			V_x_lane_change_possible_right;
	UInt8			V_x_lane_change_pass_right;
	UInt8			V_x_lane_change_return_left;
	UInt8			F_x_next_lane_free_left;
	UInt8			F_x_next_lane_free_right;
	UInt8			padding[2];
} V_x_ST_OUTPUT_ALC;

//! SWC:AutoLCPossibilityJdg
typedef struct {
	V_x_ST_OUTPUT_DYNAMIC_CONFL_JDG		V_x_st_Output_DynamicConflJdgDiag;
	V_x_ST_OUTPUT_ALC		V_x_st_Output_Alc;
} V_x_AutoLCPossibilityJdgOutput;

//! SWC:AutoLCPossibilityJdg
typedef struct {
	V_x_AutoLCPossibilityJdgOutput		V_x_AutoLCPossibilityJdgOutput;
} V_x_AutoLCPossibilityJdgDataSet;

#endif // __AUTOLCPOSSIBILITYJDG_IF_H__
