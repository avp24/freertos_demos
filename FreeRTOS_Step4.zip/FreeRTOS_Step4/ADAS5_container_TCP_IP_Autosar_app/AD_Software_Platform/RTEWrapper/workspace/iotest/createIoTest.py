import os
import sys
import shutil
import json
import pandas
import argparse
import copy
import re

IotestCreation_version = 1.0

# logging
from logging import getLogger, StreamHandler, FileHandler, Formatter, DEBUG, INFO, WARNING, ERROR, CRITICAL

class MyLogger:
    def __init__(self, logfile):
        self._logger = getLogger(__name__)
        self._handler1 = FileHandler(filename = logfile)
        self._handler1.setLevel(DEBUG)
        self._handler1.setFormatter(Formatter("%(asctime)s %(levelname)s: %(message)s"))
        self._handler2 = StreamHandler()
        self._handler2.setLevel(INFO)
        self._logger.setLevel(DEBUG)
        self._logger.addHandler(self._handler1)
        self._logger.addHandler(self._handler2)
        self._logger.propagate = False

    def log(self, level, msg):
        if self._logger is None:
            return
        if level == DEBUG:
            self._logger.debug(msg)
        elif level == INFO:
            self._logger.info(msg)
        elif level == WARNING:
            self._logger.warning(msg)
        elif level == ERROR:
            self._logger.error(msg)
        elif level == CRITICAL:
            self._logger.critical(msg)

class ExcelHandler:
    _sheets = {}
    _dataframes = {}

    def __init__(self, in_file, logger = None):
        self._ifilepath = in_file
        self._logger = logger

    def __del__(self):
        self.close()

    def read_sheet(self, name, key):
        if name in self._dataframes:
            df = self._dataframes[name]
            self._sheets[key] = {'df' : df, 'ncols' : len(df.columns), 'nrows' : len(df.index)}
            return True
        try:
            df = pandas.read_excel(self._ifilepath, sheet_name = name)
        except Exception as e:
            return False
        df.fillna('', inplace = True)
        self._sheets[key] = {'df' : df, 'ncols' : len(df.columns), 'nrows' : len(df.index)}
        self._dataframes[name] = df
        return True

    def search_cell(self, sheet_key, search_str):
        if sheet_key not in self._sheets:
            return -1, -1
        df = self._sheets[sheet_key]['df']
        nrows = self._sheets[sheet_key]['nrows']
        ncols = self._sheets[sheet_key]['ncols']
        for row in range(0, nrows):
            for col in range(0, ncols):
                if df.iat[row, col] == search_str:
                    return row, col
        self._log(WARNING, 'Not found "%s" in "%s" sheet' % (search_str, sheet_key))
        return -1, -1

    def get_sheet(self, key):
        return None if key not in self._sheets else self._sheets[key]

    def close(self):
        self._sheets.clear()

    def _log(self, level, msg):
        if self._logger is None:
            return
        self._logger.log(level, msg)

class RTESignalDBReader:

    STDINT_TYPES = {'B'      : 'boolean',
                    'U8'     : 'uint8',
                    'S8'     : 'sint8',
                    'U16'    : 'uint16',
                    'S16'    : 'sint16',
                    'U32'    : 'uint32',
                    'S32'    : 'sint32',
                    'U64'    : 'uint64',
                    'S64'    : 'sint64',
                    'Fl32'   : 'float32',
                    'Fl64'   : 'float64'}

    FLOAT_TYPES = {'Fl32'   : 'float32',
                   'Fl64'   : 'float64'}

    MEMSET_NONE = 0
    MEMSET_ARRAY = 1
    MEMSET_POINTER = 2

    _swcs = {}

    def __init__(self, fpath, group, logger = None):
        self._logger = logger
        self._excel = ExcelHandler(fpath)
        self._group = group

    def __del__(self):
        self.close()

    def close(self):
        self._excel.close()

    '''
    Read all signals and create categorized structure per transmitter SWCs
    Skip signals with RTE_group is not '1'

    <structure>
    * self._swcs
      'swcname' : {
        'type' : type of SWC ('sup', 'mbd', 'n', ...)
        'col'  : column number
        'sig'  : {
                    'port' : {'symbol' : symbol, 'type' : data type, 'R' : [swc#1, swc#2, ...], 'multi' : multiplicity}
                 }
      }
    '''
    def read(self):
        if not self._excel.read_sheet('RTE_Signal for 2018T2', 'RTE'):
            self._log(ERROR, 'Failed to read "RTE_Signal for 2018T2"')
            return None
        if not self._probe_rte():
            self._log(ERROR, 'Failed to probe "RTE_Signal for 2018T2"')
            return None

        # read signals
        self._log(INFO, 'Reading signals ...')
        sheet = self._excel.get_sheet('RTE')
        df = sheet['df']
        for row in range(sheet['row_label'] + 1, sheet['nrows']):
            if str(df.iat[row, sheet['col_group']]) != '1':
                continue
            port = df.iat[row, sheet['col_port']]
            symbol = df.iat[row, sheet['col_sym']]
            datatype = df.iat[row, sheet['col_type']]
            multi = int(df.iat[row, sheet['col_multi']])

            # search 'T' swc
            swcT = None
            swcR = []
            for swcname, swcval in self._swcs.items():
                TorR = str(df.iat[row, swcval['col']])
                if TorR == 'T':
                    swcT = swcval
                elif TorR == 'R':
                    swcR.append(swcname)
            if swcT is None:
                self._log(WARNING, '*** %s : Not found T' % port)
                continue

            if datatype == 'Fl':
                datatype = 'Fl32'

            if datatype in self.STDINT_TYPES:
                var = 'tmp_' + datatype
                var += '' if multi <= 1 else '_' + str(multi) + '[' + str(multi) + ']'
                swcT['var'][var] = [self.STDINT_TYPES[datatype], self.MEMSET_ARRAY if multi > 1 else self.MEMSET_NONE] # [datatype, memset]
            elif datatype == 'BUS' or datatype == 'STR':
                var = 'tmp_' + symbol
                var += '' if multi <= 1 else '_' + str(multi) + '[' + str(multi) + ']'
                swcT['var'][var] = [port, self.MEMSET_ARRAY if multi > 1 else self.MEMSET_POINTER] # [datatype, memset]
            else:
                self._log(WARNING, '*** %s : Invalid data type (%s)', port, datatype)

            swcT['sig'][port] = {'symbol' : symbol, 'type' : datatype, 'multi' : multi, 'R' : swcR}
            swcT['numOfR'] += len(swcR)

        self._log(INFO, 'Reading signals ... finish')

        # dump info
        self._log(INFO, '=== Result ===')
        for swcname, val in self._swcs.items():
            self._log(INFO, '> %s - T(%d) R(%d)' % (swcname, len(val['sig']), val['numOfR']))
            for port, v in val['sig'].items():
                self._log(DEBUG, '  %s (%s) : %s' % (port, v['type'], str(v['R'])))
        self._log(INFO, '==============')

        return self._swcs

    def get_oem_swcs(self):
        return self._oem_swcs

    def get_sup_swcs(self):
        return self._sup_swcs

    def get_bus_testspec(self):
        return None

    def _probe_rte(self):
        self._log(INFO, 'Probing "RTE" sheet ...')
        # search label row and column
        row, col = self._excel.search_cell('RTE', 'RTE Signal ID')
        if row == -1 or col == -1:
            self._log(ERROR, 'RTE Signal ID cell not found')
            self._log(INFO, 'Probing "RTE" sheet ... fail')
            return False
        sheet = self._excel.get_sheet('RTE')
        sheet['row_label'] = row
        sheet['row_swctype'] = row - 1
        df = sheet['df']

        group = 'rte_group' + self._group.lower()
        labels = {'port name'                   : 'col_port',
                  'symbol for ram'              : 'col_sym',
                  'autosar signal data type'    : 'col_type',
                  'multiplicity'                : 'col_multi',
                  'number of t'                 : 'col_r',
                  'number of r'                 : 'col_r',
                  group                         : 'col_group'}
        for col in range(0, sheet['ncols']):
            val = df.iat[sheet['row_label'], col].lower()
            val = val.replace('\n', '')
            swctype = df.iat[sheet['row_swctype'], col].lower()
            if val in labels:
                sheet[labels[val]] = col
                self._log(DEBUG, 'Column "%s" found at %d' % (val, col))
            if swctype != '' and 'col_r' in sheet:
                self._swcs[df.iat[sheet['row_label'], col]] = {'type' : swctype, 'col' : col, 'sig' : {}, 'numOfR' : 0, 'var' : {}}

        # check all columns are found
        for key, val in labels.items():
            if not val in sheet:
                self._log(ERROR, 'Column "%s" not found' % key)
                self._log(INFO, 'Probing "RTE" sheet ... fail')
                return False

        self._oem_swcs = [name for name, val in self._swcs.items() if val['type'] != 'sup']
        self._sup_swcs = [name for name, val in self._swcs.items() if val['type'] == 'sup']

        self._log(INFO, 'Probing "RTE" sheet ... success')
        return True

    def _probe_bus(self):
        # search label row and column
        row, col = self._excel.search_cell('BUS', 'Bus name')
        if row == -1 or col == -1:
            return False
        sheet = self._excel.get_sheet('BUS')
        sheet['row_label'] = row
        df = sheet['df']

        labels = {'bus name'                    : 'col_port',
                  '変数型'                      : 'col_type',
                  'メンバ名'                    : 'col_member',
                  'multiplicity'                : 'col_multi'}
        for col in range(0, sheet['ncols']):
            val = _df.iat[sheet['row_label'], col].lower()
            if val in labels:
                sheet[labels[val]] = col
                self._log(DEBUG, '[BUS] "%s" found at %d', val, col)

        # check all columns are found
        for val in labels.values():
            if not val in sheet:
                return False

        return True

    def _log(self, level, msg):
        if self._logger is None:
            return
        self._logger.log(level, msg)

class TestSpecReader:

    STDINT_TYPES = {'B'      : 'boolean',
                    'U8'     : 'uint8',
                    'S8'     : 'sint8',
                    'U16'    : 'uint16',
                    'S16'    : 'sint16',
                    'U32'    : 'uint32',
                    'S32'    : 'sint32',
                    'U64'    : 'uint64',
                    'S64'    : 'sint64',
                    'Fl32'   : 'float32',
                    'Fl64'   : 'float64'}

    FLOAT_TYPES = {'Fl32'   : 'float32',
                   'Fl64'   : 'float64'}

    SHEET_KEY_TESTSPEC = 'TestSpec'
    SHEET_KEY_BUS = 'BUS'

    MEMSET_NONE = 0
    MEMSET_ARRAY = 1
    MEMSET_POINTER = 2

    _swcs = {}
    _bus = {}

    def __init__(self, fpath, logger = None):
        self._logger = logger
        self._excel = ExcelHandler(fpath)

    def __del__(self):
        self.close()

    def close(self):
        self._excel.close()

    '''
    Read all signals and create categorized structure per transmitter SWCs

    <structure>
    * self._swcs
      'swcname' : {
        'type' : type of SWC ('sup', 'mbd', 'n', ...)
        'col'  : column number
        'sig'  : {
                    'port' : {'type' : data type, 'R' : [swc#1, swc#2, ...], 'multi' : multiplicity}
                 }
      }
    '''
    def read(self):
        if not self._excel.read_sheet('TestSpec', self.SHEET_KEY_TESTSPEC):
            self._log(ERROR, 'Failed to read "' + self.SHEET_KEY_TESTSPEC + '"')
            return None
        if not self._probe_testspec():
            self._log(ERROR, 'Failed to probe "' + self.SHEET_KEY_TESTSPEC + '"')
            return None
        if not self._excel.read_sheet('BUS', self.SHEET_KEY_BUS):
            self._log(ERROR, 'Failed to read "' + self.SHEET_KEY_BUS + '"')
            return None
        if not self._probe_bus():
            self._log(ERROR, 'Failed to probe "' + self.SHEET_KEY_BUS + '"')
            return None

        # read signals
        self._log(INFO, 'Reading signals ...')
        sheet = self._excel.get_sheet(self.SHEET_KEY_TESTSPEC)
        df = sheet['df']
        for row in range(sheet['row_label'] + 1, sheet['nrows']):
            port = df.iat[row, sheet['col_port']]
            datatype = df.iat[row, sheet['col_type']]
            multi = int(df.iat[row, sheet['col_multi']])
            min_val = df.iat[row, sheet['col_min']]
            max_val = df.iat[row, sheet['col_max']]
            rand_val = df.iat[row, sheet['col_rand']]

            # search 'T' swc
            swcT = None
            swcR = []
            for swcname, swcval in self._swcs.items():
                TorR = str(df.iat[row, swcval['col']])
                if TorR == 'T':
                    swcT = swcval
                elif TorR == 'R':
                    swcR.append(swcname)
            if swcT is None:
                self._log(WARNING, '*** %s : Not found T' % port)
                continue

            if datatype == 'Fl':
                datatype = 'Fl32'

            if datatype in self.STDINT_TYPES:
                var = 'tmp_' + datatype
                var += '' if multi <= 1 else '_' + str(multi) + '[' + str(multi) + ']'
                swcT['var'][var] = [self.STDINT_TYPES[datatype], self.MEMSET_ARRAY if multi > 1 else self.MEMSET_NONE] # [datatype, memset]
            elif datatype == 'BUS' or datatype == 'STR':
                var = 'tmp_' + re.sub('^[V,F]_\w_', '', port) # extract symbol in port name
                var += '' if multi <= 1 else '_' + str(multi) + '[' + str(multi) + ']'
                print('BUS:', port, var)
                swcT['var'][var] = [port, self.MEMSET_ARRAY if multi > 1 else self.MEMSET_POINTER] # [datatype, memset]
            else:
                self._log(WARNING, '*** %s : Invalid data type (%s)', port, datatype)

            swcT['sig'][port] = {'type' : datatype, 'multi' : multi, 'R' : swcR,
                                 'min_val' : str(min_val), 'max_val' : str(max_val), 'rand_val' : str(rand_val)}
            swcT['numOfR'] += len(swcR)

        self._log(INFO, 'Reading signals ... finish')

        # read bus
        self._log(INFO, 'Reading bus ...')
        sheet = self._excel.get_sheet(self.SHEET_KEY_BUS)
        df = sheet['df']
        for row in range(sheet['row_label'] + 1, sheet['nrows']):
            name = df.iat[row, sheet['col_name']]
            member = df.iat[row, sheet['col_member']]
            datatype = df.iat[row, sheet['col_type']]
            multi = int(df.iat[row, sheet['col_multi']])
            min_val = df.iat[row, sheet['col_min']]
            max_val = df.iat[row, sheet['col_max']]
            rand_val = df.iat[row, sheet['col_rand']]

            if datatype == 'Fl':
                datatype = 'Fl32'

            if name not in self._bus:
                self._bus[name] = {}
                self._bus[name]['mem'] = []
                self._bus[name]['var'] = {}

            if datatype in self.STDINT_TYPES:
                var = 'tmp_' + datatype
                var += '' if multi <= 1 else '_' + str(multi) + '[' + str(multi) + ']'
                self._bus[name]['var'][var] = [self.STDINT_TYPES[datatype], self.MEMSET_ARRAY if multi > 1 else self.MEMSET_NONE] # [datatype, memset]
            else:
                self._log(WARNING, '*** %s : Invalid data type (%s)', name, datatype)

            self._bus[name]['mem'].append({'name' : member, 'type' : datatype, 'multi' : multi,
                                           'min_val' : str(min_val), 'max_val' : str(max_val), 'rand_val' : str(rand_val)})

        self._log(INFO, 'Reading bus ... finish')

        # dump info
        self._log(INFO, '=== Result ===')
        for swcname, val in self._swcs.items():
            self._log(INFO, '> %s - T(%d) R(%d)' % (swcname, len(val['sig']), val['numOfR']))
            for port, v in val['sig'].items():
                self._log(DEBUG, '  %s (%s) : %s' % (port, v['type'], str(v['R'])))
        self._log(DEBUG, '--- BUS -----')
        for busname, val in self._bus.items():
            self._log(INFO, '> %s - num of member = %d' % (busname, len(val['mem'])))
        self._log(INFO, '==============')

        return self._swcs

    def get_oem_swcs(self):
        return self._oem_swcs

    def get_sup_swcs(self):
        return self._sup_swcs

    def get_bus_testspec(self):
        return self._bus

    def _probe_testspec(self):
        self._log(INFO, 'Probing "' + self.SHEET_KEY_TESTSPEC + '" sheet ...')
        # search label row and column
        row, col = self._excel.search_cell(self.SHEET_KEY_TESTSPEC, 'RTE Signal ID')
        if row == -1 or col == -1:
            self._log(ERROR, 'RTE Signal ID cell not found')
            self._log(INFO, 'Probing "' + self.SHEET_KEY_TESTSPEC + '" sheet ... fail')
            return False
        sheet = self._excel.get_sheet(self.SHEET_KEY_TESTSPEC)
        sheet['row_label'] = row
        sheet['row_swctype'] = row - 1
        df = sheet['df']

        labels = {'port name'                   : 'col_port',
                  'autosar signal data type'    : 'col_type',
                  'multiplicity'                : 'col_multi',
                  'random'                      : 'col_rand',
                  'min'                         : 'col_min',
                  'max'                         : 'col_max'}
        for col in range(0, sheet['ncols']):
            val = df.iat[sheet['row_label'], col].lower()
            val = val.replace('\n', '')
            swctype = df.iat[sheet['row_swctype'], col].lower()
            if val in labels:
                sheet[labels[val]] = col
                self._log(DEBUG, 'Column "%s" found at %d' % (val, col))
            if swctype != '' and 'col_max' in sheet:
                self._swcs[df.iat[sheet['row_label'], col]] = {'type' : swctype, 'col' : col, 'sig' : {}, 'numOfR' : 0, 'var' : {}}

        # check all columns are found
        for key, val in labels.items():
            if not val in sheet:
                self._log(ERROR, 'Column "%s" not found' % key)
                self._log(INFO, 'Probing "' + self.SHEET_KEY_TESTSPEC + '" sheet ... fail')
                return False

        self._oem_swcs = [name for name, val in self._swcs.items() if val['type'] != 'sup']
        self._sup_swcs = [name for name, val in self._swcs.items() if val['type'] == 'sup']

        self._log(INFO, 'Probing "' + self.SHEET_KEY_TESTSPEC + '" sheet ... success')
        return True

    def _probe_bus(self):
        # search label row and column
        row, col = self._excel.search_cell(self.SHEET_KEY_BUS, 'Bus name')
        if row == -1 or col == -1:
            return False
        sheet = self._excel.get_sheet(self.SHEET_KEY_BUS)
        sheet['row_label'] = row
        df = sheet['df']

        labels = {'bus name'                    : 'col_name',
                  'autosar signal data type'    : 'col_type',
                  'member'                      : 'col_member',
                  'multiplicity'                : 'col_multi',
                  'random'                      : 'col_rand',
                  'min'                         : 'col_min',
                  'max'                         : 'col_max'}
        for col in range(0, sheet['ncols']):
            val = df.iat[sheet['row_label'], col].lower()
            if val in labels:
                sheet[labels[val]] = col
                self._log(DEBUG, '[BUS] "%s" found at %d' % (val, col))

        # check all columns are found
        for val in labels.values():
            if not val in sheet:
                return False

        return True

    def _log(self, level, msg):
        if self._logger is None:
            return
        self._logger.log(level, msg)

class IoTestCreator:

    GTEST_PATH = "gtest/gtest.h"
    GTEST_VERIFY_MACRO_STDINT = "EXPECT_EQ"
    GTEST_VERIFY_MACRO_FLOAT = "EXPECT_FLOAT_EQ"

    PORT_VAR_REPLAC_FILE = "port_var_replacement.json"
    PORT_RW_REPLAC_FILE = "port_rw_replacement.json"

    TEST_FUNCS_TEMPL = {
        's2o' : {'ofp_main' : None, 'ofp_pre' : None, 'ofp_vfy' : None, 'ofp_vfy_b' : None, 'ofp_vfy_h' : None, 'pre_func' : [], 'vfy_func' : []},
        's2o_min' : {'ofp_main' : None, 'ofp_pre' : None, 'ofp_vfy' : None, 'ofp_vfy_b' : None, 'ofp_vfy_h' : None, 'pre_func' : [], 'vfy_func' : []},
        's2o_max' : {'ofp_main' : None, 'ofp_pre' : None, 'ofp_vfy' : None, 'ofp_vfy_b' : None, 'ofp_vfy_h' : None, 'pre_func' : [], 'vfy_func' : []},
        'o2s' : {'ofp_main' : None, 'ofp_pre' : None, 'ofp_vfy' : None, 'ofp_vfy_b' : None, 'ofp_vfy_h' : None, 'pre_func' : [], 'vfy_func' : []},
        'o2s_max' : {'ofp_main' : None, 'ofp_pre' : None, 'ofp_vfy' : None, 'ofp_vfy_b' : None, 'ofp_vfy_h' : None, 'pre_func' : [], 'vfy_func' : []},
        'o2s_min' : {'ofp_main' : None, 'ofp_pre' : None, 'ofp_vfy' : None, 'ofp_vfy_b' : None, 'ofp_vfy_h' : None, 'pre_func' : [], 'vfy_func' : []},
        'o2o_cache' : {'ofp_main' : None, 'ofp_pre' : None, 'ofp_vfy' : None, 'ofp_vfy_b' : None, 'ofp_vfy_h' : None, 'pre_func' : [], 'vfy_func' : []},
        'o2o_cache_max' : {'ofp_main' : None, 'ofp_pre' : None, 'ofp_vfy' : None, 'ofp_vfy_b' : None, 'ofp_vfy_h' : None, 'pre_func' : [], 'vfy_func' : []},
        'o2o_cache_min' : {'ofp_main' : None, 'ofp_pre' : None, 'ofp_vfy' : None, 'ofp_vfy_b' : None, 'ofp_vfy_h' : None, 'pre_func' : [], 'vfy_func' : []},
        'o2o_noncache' : {'ofp_main' : None, 'ofp_pre' : None, 'ofp_vfy' : None, 'ofp_vfy_b' : None, 'ofp_vfy_h' : None, 'pre_func' : [], 'vfy_func' : []},
        'o2o_noncache_max' : {'ofp_main' : None, 'ofp_pre' : None, 'ofp_vfy' : None, 'ofp_vfy_b' : None, 'ofp_vfy_h' : None, 'pre_func' : [], 'vfy_func' : []},
        'o2o_noncache_min' : {'ofp_main' : None, 'ofp_pre' : None, 'ofp_vfy' : None, 'ofp_vfy_b' : None, 'ofp_vfy_h' : None, 'pre_func' : [], 'vfy_func' : []},
    }

    SUPER_SWCS = {
        'C0_SM' : [
            'SafetyModule',
        ],
        'C1_1' : [
            'DiagControl',
            'OEM_DIAG',
            'ActivationManagement',
            'VehStatus_In',
            'VehStatus_Out',
            'BRK_ENG',
            'YAW',
            'HMI',
            'CAM_RAD',
            'Fusion',
            'FS_ACT',
            'FEBFCWDBA',
            'LDPLDW',
            'BSI',
            'DAA',
            'EAP',
            'Control_Longi',
            'Control_Lat',
            'EDR',
            'HOD',
            'EHR',
            'CASP',
            'APA',
            'NoEntry',
            'LCDN',
        ],
        'C2_1' : [
            'SurroundFusion',
            'VehStatus_In_10',
        ],
        'C2_2' : [
            'AutoLCPossibilityJdg',
            'ObjectSelectionDM',
            'VehStatus_In_50',
        ],
        'C2_3' : [
            'RCarHMIManagement',
            'ObjectSelectionAVM',
            'VehStatus_In_100',
        ]
    }

    TEST_FUNCS = {}

    STDINT_TYPES_VAL = {'B'      : {'val' : 0, 'inc' : 1, 'min' : 1, 'max' : 255},
                        'U8'     : {'val' : 0, 'inc' : 1, 'min' : 1, 'max' : 255},
                        'S8'     : {'val' : 0, 'inc' : 1, 'min' : 1, 'max' : 127},
                        'U16'    : {'val' : 0, 'inc' : 1, 'min' : 1, 'max' : 65535},
                        'S16'    : {'val' : 0, 'inc' : 1, 'min' : 1, 'max' : 32767},
                        'U32'    : {'val' : 0, 'inc' : 1, 'min' : 1, 'max' : 4294967295},
                        'S32'    : {'val' : 0, 'inc' : 1, 'min' : 1, 'max' : 2147483647},
                        'U64'    : {'val' : 0, 'inc' : 1, 'min' : 1, 'max' : 18446744073709551615},
                        'S64'    : {'val' : 0, 'inc' : 1, 'min' : 1, 'max' : 9223372036854775807},
                        'Fl32'   : {'val' : 0, 'inc' : 1, 'min' : 1, 'max' : 2.14748365e+09},
                        'Fl64'   : {'val' : 0, 'inc' : 1, 'min' : 1, 'max' : 2.14748365e+09}}

    STDINT_MIN_MAX = {'B'      : ['0', 'UCHAR_MAX'],
                      'U8'     : ['0', 'UCHAR_MAX'],
                      'S8'     : ['CHAR_MIN', 'CHAR_MAX'],
                      'U16'    : ['0', 'USHRT_MAX'],
                      'S16'    : ['SHRT_MIN', 'SHRT_MAX'],
                      'U32'    : ['0', 'UINT_MAX'],
                      'S32'    : ['INT_MIN', 'INT_MAX'],
                      'U64'    : ['0', 'ULLONG_MAX'],
                      'S64'    : ['LLONG_MIN', 'LLONG_MAX'],
                      'Fl32'   : ['FLT_MIN', 'FLT_MAX'],
                      'Fl64'   : ['DBL_MIN', 'DBL_MAX']}

    _swcs = {}
    _oem_swcs = []
    _sup_swcs = []

    def __init__(self, fpath, group, is_rte, outdir):
        self._logger = MyLogger('createIoTest.log')
        self._is_rte = is_rte
        if is_rte:
            self._rte = RTESignalDBReader(fpath, group, self._logger)
        else:
            self._rte = TestSpecReader(fpath, self._logger)
        self._outdir = os.path.abspath(outdir)
        self._port_var_replacement = {}
        self._port_rw_replacement = {}
        self._init_test_funcs()
        self._load_port_replacement()

        self._log(INFO, '=== Setting ===')
        self._log(INFO, 'File  : ' + fpath)
        self._log(INFO, 'RTE   : ' + str(is_rte))
        self._log(INFO, 'Group : ' + group)
        self._log(INFO, 'Out   : ' + self._outdir)
        self._log(INFO, '===============')

    def __del__(self):
        self._rte.close()

    def _log(self, level, msg):
        self._logger.log(level, msg)

    def _init_test_funcs(self):
        for superswc in self.SUPER_SWCS.keys():
            self.TEST_FUNCS[superswc] = copy.deepcopy(self.TEST_FUNCS_TEMPL)

    def _load_port_replacement(self):
        if os.path.exists(self.PORT_VAR_REPLAC_FILE):
            self._log(INFO, 'Loading ' + self.PORT_VAR_REPLAC_FILE + ' ...')
            with open(self.PORT_VAR_REPLAC_FILE, 'r') as f:
                try:
                    self._port_var_replacement = json.load(f)
                    self._log(INFO, 'Loading ' + self.PORT_VAR_REPLAC_FILE + ' ... success')
                except Exception as e:
                    self._log(INFO, 'Loading ' + self.PORT_VAR_REPLAC_FILE + ' ... fail !!')
                    self._log(ERROR, '*** JSON load error in %s : %s' % (self.PORT_VAR_REPLAC_FILE, e))
                f.close()
        if os.path.exists(self.PORT_RW_REPLAC_FILE):
            self._log(INFO, 'Loading ' + self.PORT_RW_REPLAC_FILE + ' ...')
            with open(self.PORT_RW_REPLAC_FILE, 'r') as f:
                try:
                    self._port_rw_replacement = json.load(f)
                    self._log(INFO, 'Loading ' + self.PORT_RW_REPLAC_FILE + ' ... success')
                except Exception as e:
                    self._log(INFO, 'Loading ' + self.PORT_RW_REPLAC_FILE + ' ... fail !!')
                    self._log(ERROR, '*** JSON load error in %s : %s' % (self.PORT_RW_REPLAC_FILE, e))
                f.close()

    '''
    Read all signals and create categorized structure per transmitter SWCs
    Skip signals with RTE_group is not '1'

    <structure>
    * self._swcs
      'swcname' : {
        'type' : type of SWC ('sup', 'mbd', 'n', ...)
        'col'  : column number
        'sig'  : {
                    'port' : {'symbol' : symbol, 'type' : data type, 'R' : [swc#1, swc#2, ...], 'multi' : multiplicity}
                 }
      }
    '''
    def read(self):
        self._swcs = self._rte.read()
        if self._swcs is None:
            return False
        self._sup_swcs = self._rte.get_sup_swcs()
        self._oem_swcs = self._rte.get_oem_swcs()
        self._bus = self._rte.get_bus_testspec()
        return True

    def export(self):
        if len(self._swcs) == 0:
            self._log(ERROR, 'No signal was read. call read() at first')
            return False
        
        if not os.path.exists(self._outdir):
            self._log(INFO, '* mkdir %s' % self._outdir)
            os.makedirs(self._outdir)

        self._open_prepare()
        self._open_verify_tmp()

        for swcname, val in self._swcs.items():
            if val['type'] == 'sup':
                for superswc in self.SUPER_SWCS.keys():
                    self._export_sup_to_oem(swcname, val, superswc)
                    self._export_sup_to_oem(swcname, val, superswc, isMin = True)
                    self._export_sup_to_oem(swcname, val, superswc, isMax = True)
            else:
                for superswc in self.SUPER_SWCS.keys():
                    self._export_oem_to_sup(swcname, val, superswc)
                    self._export_oem_to_sup(swcname, val, superswc, isMin = True)
                    self._export_oem_to_sup(swcname, val, superswc, isMax = True)
                    self._export_oem_to_oem_cache(swcname, val, superswc)
                    self._export_oem_to_oem_cache(swcname, val, superswc, isMin = True)
                    self._export_oem_to_oem_cache(swcname, val, superswc, isMax = True)
                    self._export_oem_to_oem_noncache(swcname, val, superswc)
                    self._export_oem_to_oem_noncache(swcname, val, superswc, isMin = True)
                    self._export_oem_to_oem_noncache(swcname, val, superswc, isMax = True)

            self._log(INFO, 'export %s (%s) ... success' % (swcname, val['type']))

        # finalyze output files
        self._close_prepare()
        self._concat_verify()

        # output test case
        self._open_test_main()
        self._export_test_main()
        self._close_test_main()
        
    def _open_test_main(self, mode = 'w'):
        for superswc, funcs in self.TEST_FUNCS.items():
            for testcase, vals in funcs.items():
                if vals['ofp_main'] is None:
                    opath = os.path.join(self._outdir, superswc + '_' + testcase + '_test.cpp')
                    vals['ofp_main'] = open(os.path.join(self._outdir, opath), mode)
 
    def _close_test_main(self, mode = 'w'):
        for superswc, funcs in self.TEST_FUNCS.items():
            for testcase, vals in funcs.items():
                if vals['ofp_main'] is not None:
                    vals['ofp_main'].close()
                    vals['ofp_main'] = None

    def _open_prepare(self, mode = 'w'):
        for superswc, funcs in self.TEST_FUNCS.items():
            for testcase, vals in funcs.items():
                if vals['ofp_pre'] is None:
                    self._log(DEBUG, '%s : open prepare' % superswc)
                    opath = os.path.join(self._outdir, superswc + '_' + testcase + '_prepare.cpp')
                    vals['ofp_pre'] = open(os.path.join(self._outdir, opath), mode)
 
    def _close_prepare(self, mode = 'w'):
        for superswc, funcs in self.TEST_FUNCS.items():
            for testcase, vals in funcs.items():
                if vals['ofp_pre'] is not None:
                    vals['ofp_pre'].close()
                    vals['ofp_pre'] = None
 
    def _open_verify(self, mode = 'w'):
        for superswc, funcs in self.TEST_FUNCS.items():
            for testcase, vals in funcs.items():
                if vals['ofp_vfy'] is None:
                    opath = os.path.join(self._outdir, superswc + '_' + testcase + '_verify.cpp')
                    vals['ofp_vfy'] = open(os.path.join(self._outdir, opath), mode)
 
    def _close_verify(self, mode = 'w'):
        for superswc, funcs in self.TEST_FUNCS.items():
            for testcase, vals in funcs.items():
                if vals['ofp_vfy'] is not None:
                    vals['ofp_vfy'].close()
                    vals['ofp_vfy'] = None
 
    def _open_verify_tmp(self, mode = 'w'):
        for superswc, funcs in self.TEST_FUNCS.items():
            for testcase, vals in funcs.items():
                if vals['ofp_vfy_h'] is None:
                    opath = os.path.join(self._outdir, superswc + '_' + testcase + '_verify_h')
                    vals['ofp_vfy_h'] = open(os.path.join(self._outdir, opath), mode)
                if vals['ofp_vfy_b'] is None:
                    opath = os.path.join(self._outdir, superswc + '_' + testcase + '_verify_b')
                    vals['ofp_vfy_b'] = open(os.path.join(self._outdir, opath), mode)
 
    def _close_verify_tmp(self, mode = 'w'):
        for superswc, funcs in self.TEST_FUNCS.items():
            for testcase, vals in funcs.items():
                if vals['ofp_vfy_h'] is not None:
                    vals['ofp_vfy_h'].close()
                    vals['ofp_vfy_h'] = None
                if vals['ofp_vfy_b'] is not None:
                    vals['ofp_vfy_b'].close()
                    vals['ofp_vfy_b'] = None

    def _remove_verify_tmp(self):
        for superswc, funcs in self.TEST_FUNCS.items():
            for testcase, vals in funcs.items():
                opath = os.path.join(self._outdir, superswc + '_' + testcase + '_verify_h')
                os.remove(opath)
                opath = os.path.join(self._outdir, superswc + '_' + testcase + '_verify_b')
                os.remove(opath)

    def _concat_verify(self):
        self._close_verify_tmp()
        self._open_verify_tmp('r')
        self._open_verify()
        for superswc, funcs in self.TEST_FUNCS.items():
            for testcase, vals in funcs.items():
                vals['ofp_vfy'].write(vals['ofp_vfy_h'].read())
                vals['ofp_vfy'].write(vals['ofp_vfy_b'].read())
        self._close_verify_tmp()
        self._close_verify()
        self._remove_verify_tmp()
            
    def _export_sup_to_oem(self, swcname, val, superswc, isMin = False, isMax = False):
        testcase = 's2o'
        if isMin:
            testcase = 's2o_min'
        elif isMax:
            testcase = 's2o_max'
        ofp_pre = self.TEST_FUNCS[superswc][testcase]['ofp_pre']
        ofp_vfy_h = self.TEST_FUNCS[superswc][testcase]['ofp_vfy_h']
        ofp_vfy_b = self.TEST_FUNCS[superswc][testcase]['ofp_vfy_b']

        pre_func = superswc + '_' + testcase + '_prepare_' + swcname
        vfy_func = superswc + '_' + testcase + '_verify_' + swcname

        if ofp_pre.tell() == 0:
            ofp_pre.write('#include <limits.h>\n')
            ofp_pre.write('#include <float.h>\n')
            ofp_pre.write('#define DUMMY_RTE_INCLUDE_MULTI_SWC_HEADER\n')
            ofp_pre.write('#include "Platform_Types.h"\n')
            ofp_pre.write('#ifdef __cplusplus\n')
            ofp_pre.write('extern "C" {\n')
            ofp_pre.write('#endif\n')
            for swc in self._sup_swcs:
                ofp_pre.write('#include "Rte_' + swc + '.h"\n')
            ofp_pre.write('#ifdef __cplusplus\n')
            ofp_pre.write('}\n')
            ofp_pre.write('#endif\n')
        if ofp_vfy_h.tell() == 0:
            ofp_vfy_h.write('#include <limits.h>\n')
            ofp_vfy_h.write('#include <float.h>\n')
            ofp_vfy_h.write('#include "' + self.GTEST_PATH + '"\n')
            ofp_vfy_h.write('#include "Platform_Types.h"\n')

        ofp_pre.write('\n')
        ofp_pre.write('void ' + pre_func + '(void)\n{\n')
        for varname, vartype in val['var'].items():
            ofp_pre.write('    ' + vartype[0] + ' ' + varname + ';\n')
        ofp_pre.write('\n')
        ofp_vfy_b.write('\n')
        ofp_vfy_b.write('void ' + vfy_func + '(void)\n{\n')
        ofp_vfy_h.write('\n')

        # loop all signals
        for port, v in val['sig'].items():
            if v['type'] in self._rte.STDINT_TYPES:
                varname = 'tmp_' + v['type'] + ('' if v['multi'] <= 1 else '_' + str(v['multi']))
                skip = True

                # only receiver is OEM
                for swcR in v['R']:
                    if swcR in self.SUPER_SWCS[superswc]:
                        skip = False
                        break

                if skip:
                    continue

                variable = 'gOEM_SWC_' + superswc + port # OEM_SWC variable

                if port in self._port_rw_replacement:
                    self._log(INFO, 'RTE : %s -> %s' % (port, self._port_rw_replacement[port]))
                    port = self._port_rw_replacement[port]

                idx = '' if v['multi'] <= 1 else '[' + str(v['multi']) + ']'
                ofp_vfy_h.write('extern ' + self._rte.STDINT_TYPES[v['type']] + ' ' + variable + idx + ';\n')
                for i in range(0, v['multi']):
                    idx = '' if v['multi'] <= 1 else '[' + str(i) + ']'
                    ptrstr = '' if v['multi'] <= 1 else '&'
                    if isMin:
                        if 'min_val' in v:
                            _val = v['min_val'].split(',')[i]
                        else:
                            _val = self.STDINT_MIN_MAX[v['type']][0]
                    elif isMax:
                        if 'max_val' in v:
                            _val = v['max_val'].split(',')[i]
                        else:
                            _val = self.STDINT_MIN_MAX[v['type']][1]
                    else:
                        if 'rand_val' in v:
                            _val = v['rand_val'].split(',')[i]
                        else:
                            _val = self._increment_val(v['type'])
                    ofp_pre.write('    ' + varname + idx + ' = ' + str(_val) + ';\n')
                    vfy_macro = self.GTEST_VERIFY_MACRO_FLOAT if v['type'] in self._rte.FLOAT_TYPES else self.GTEST_VERIFY_MACRO_STDINT
                    ofp_vfy_b.write('    ' + vfy_macro + '(' + variable + idx + ', ' + str(_val) + ');\n')
                    self._log(DEBUG, '%s: %s[%d], %s' % (testcase, port, i, str(_val)))
                ofp_pre.write('    Rte_Write_' + port + '_' + port + '(' + ptrstr + varname + ');\n')

        ofp_pre.write('}\n')
        ofp_vfy_b.write('}\n')

        self.TEST_FUNCS[superswc][testcase]['pre_func'].append(pre_func)
        self.TEST_FUNCS[superswc][testcase]['vfy_func'].append(vfy_func)

    def _export_oem_to_sup(self, swcname, val, superswc, isMin = False, isMax = False):
        if swcname not in self.SUPER_SWCS[superswc]:
            return
        testcase = 'o2s'
        if isMin:
            testcase = 'o2s_min'
        elif isMax:
            testcase = 'o2s_max'
        ofp_pre = self.TEST_FUNCS[superswc][testcase]['ofp_pre']
        ofp_vfy_h = self.TEST_FUNCS[superswc][testcase]['ofp_vfy_h']
        ofp_vfy_b = self.TEST_FUNCS[superswc][testcase]['ofp_vfy_b']

        pre_func = superswc + '_' + testcase + '_prepare_' + swcname
        vfy_func = superswc + '_' + testcase + '_verify_' + swcname

        if ofp_pre.tell() == 0:
            ofp_pre.write('#include <limits.h>\n')
            ofp_pre.write('#include <float.h>\n')
            ofp_pre.write('#define DUMMY_RTE_INCLUDE_MULTI_SWC_HEADER\n')
            ofp_pre.write('#include "Platform_Types.h"\n')
            ofp_pre.write('#ifdef __cplusplus\n')
            ofp_pre.write('extern "C" {\n')
            ofp_pre.write('#endif\n')
            ofp_pre.write('#ifdef __cplusplus\n')
            ofp_pre.write('}\n')
            ofp_pre.write('#endif\n')
        if ofp_vfy_h.tell() == 0:
            ofp_vfy_h.write('#include <limits.h>\n')
            ofp_vfy_h.write('#include <float.h>\n')
            ofp_vfy_h.write('#include "' + self.GTEST_PATH + '"\n')
            ofp_vfy_h.write('#include "Platform_Types.h"\n')

        ofp_pre.write('\n')
        ofp_pre.write('#include "Rte_Wrapper_' + swcname + '.h"\n')
        ofp_pre.write('void ' + pre_func + '(void)\n{\n')
        for varname, vartype in val['var'].items():
            ofp_pre.write('    ' + vartype[0] + ' ' + varname + ';\n')
        ofp_pre.write('\n')
        ofp_vfy_b.write('\n')
        ofp_vfy_b.write('void ' + vfy_func + '(void)\n{\n')
        ofp_vfy_h.write('\n')

        # loop all signals
        for port, v in val['sig'].items():
            if v['type'] in self._rte.STDINT_TYPES:
                varname = 'tmp_' + v['type'] + ('' if v['multi'] <= 1 else '_' + str(v['multi']))
                skip = True

                # only receiver is SUP
                for swcR in v['R']:
                    if swcR in self._sup_swcs:
                        skip = False
                        break

                if skip:
                    continue

                port_rte = port
                if port in self._port_var_replacement:
                    self._log(INFO, 'Dummy variable : %s -> %s' % (port, self._port_var_replacement[port]))
                    port_rte = self._port_var_replacement[port]

                variable = 'Rte_OEM_SWC_' + superswc + '_' + port_rte + '_' + port_rte # Dummy RTE variable

                if port in self._port_rw_replacement:
                    self._log(INFO, 'RTE : %s -> %s' % (port, self._port_rw_replacement[port]))
                    port = self._port_rw_replacement[port]

                idx = '' if v['multi'] <= 1 else '[' + str(v['multi']) + ']'
                ofp_vfy_h.write('extern ' + self._rte.STDINT_TYPES[v['type']] + ' ' + variable + idx + ';\n')
                for i in range(0, v['multi']):
                    idx = '' if v['multi'] <= 1 else '[' + str(i) + ']'
                    if isMin:
                        if 'min_val' in v:
                            _val = v['min_val'].split(',')[i]
                        else:
                            _val = self.STDINT_MIN_MAX[v['type']][0]
                    elif isMax:
                        if 'max_val' in v:
                            _val = v['max_val'].split(',')[i]
                        else:
                            _val = self.STDINT_MIN_MAX[v['type']][1]
                    else:
                        if 'rand_val' in v:
                            _val = v['rand_val'].split(',')[i]
                        else:
                            _val = self._increment_val(v['type'])
                    ofp_pre.write('    ' + varname + idx + ' = ' + str(_val) + ';\n')
                    vfy_macro = self.GTEST_VERIFY_MACRO_FLOAT if v['type'] in self._rte.FLOAT_TYPES else self.GTEST_VERIFY_MACRO_STDINT
                    ofp_vfy_b.write('    ' + vfy_macro + '(' + variable + idx + ', ' + str(_val) + ');\n')
                    self._log(DEBUG, '%s: %s[%d], %s' % (testcase, port, i, str(_val)))
                ofp_pre.write('    Rte_Write_' + port + '_' + port + '(' + varname + ');\n')

        ofp_pre.write('}\n')
        ofp_vfy_b.write('}\n')

        self.TEST_FUNCS[superswc][testcase]['pre_func'].append(pre_func)
        self.TEST_FUNCS[superswc][testcase]['vfy_func'].append(vfy_func)

    def _export_oem_to_oem_cache(self, swcname, val, superswc, isMin = False, isMax = False):
        if swcname not in self.SUPER_SWCS[superswc]:
            return
        testcase = 'o2o_cache'
        if isMin:
            testcase = 'o2o_cache_min'
        elif isMax:
            testcase = 'o2o_cache_max'
        ofp_pre = self.TEST_FUNCS[superswc][testcase]['ofp_pre']
        ofp_vfy_h = self.TEST_FUNCS[superswc][testcase]['ofp_vfy_h']
        ofp_vfy_b = self.TEST_FUNCS[superswc][testcase]['ofp_vfy_b']

        pre_func = superswc + '_' + testcase + '_prepare_' + swcname
        vfy_func = superswc + '_' + testcase + '_verify_' + swcname

        if ofp_pre.tell() == 0:
            ofp_pre.write('#include <limits.h>\n')
            ofp_pre.write('#include <float.h>\n')
            ofp_pre.write('#define DUMMY_RTE_INCLUDE_MULTI_SWC_HEADER\n')
            ofp_pre.write('#include "Platform_Types.h"\n')
        if ofp_vfy_h.tell() == 0:
            ofp_vfy_h.write('#include <limits.h>\n')
            ofp_vfy_h.write('#include <float.h>\n')
            ofp_vfy_h.write('#include "' + self.GTEST_PATH + '"\n')
            ofp_vfy_h.write('#include "Rte_Union.h"\n')
            ofp_vfy_h.write('#include "Platform_Types.h"\n')

        ofp_pre.write('\n')
        ofp_pre.write('#include "Rte_Wrapper_' + swcname + '.h"\n')
        ofp_pre.write('void ' + pre_func + '(void)\n{\n')
        for varname, vartype in val['var'].items():
            ofp_pre.write('    ' + vartype[0] + ' ' + varname + ';\n')
        ofp_pre.write('\n')
        ofp_vfy_b.write('\n')
        ofp_vfy_b.write('extern U' + swcname + 'DataSet gOEM_SWC_' + superswc + 'U' + swcname + 'DataSet;\n')
        ofp_vfy_b.write('void ' + vfy_func + '(void)\n{\n')
        for varname, vartype in val['var'].items():
            ofp_vfy_b.write('    ' + vartype[0] + ' ' + varname + ';\n')
        ofp_vfy_b.write('\n')

        # loop all signals
        for port, v1 in val['sig'].items():
            # only receiver is same OEM_SWC
            swcR = [swc for swc in v1['R'] if swc in self.SUPER_SWCS[superswc]]
            if len(swcR) <= 0:
                continue

            variable_base = 'gOEM_SWC_' + superswc + 'U' + swcname + 'DataSet'
            if port in self._port_rw_replacement:
                self._log(INFO, 'RTE : %s -> %s' % (port, self._port_rw_replacement[port]))
                port = self._port_rw_replacement[port]

            variable = variable_base + '.mConc.' + port # DataSet.member

            v2 = []
            isBus = False
            if v1['type'] in self._rte.STDINT_TYPES:
                v2.append(v1)
            elif self._bus is not None:
                v2 = self._bus[port]['mem']
                isBus = True
            else:
                continue
            
            ofp_vfy_b.write('    /* ' + port + ' */\n')

            for v in v2:
                tail = v2.index(v) == len(v2) - 1
                if isBus:
                    varname = 'tmp_' + re.sub('^[V,F]_\w_', '', port)
                    member = '.' + v['name']
                    ptrstr = '&'
                else:
                    varname = 'tmp_' + v['type'] + ('' if v['multi'] <= 1 else '_' + str(v['multi']))
                    member = ''
                    ptrstr = ''

                _vals = []
                for i in range(0, v['multi']):
                    idx = '' if v['multi'] <= 1 else '[' + str(i) + ']'
                    if isMin:
                        if 'min_val' in v:
                            _val = v['min_val'].split(',')[i]
                        else:
                            _val = self.STDINT_MIN_MAX[v['type']][0]
                    elif isMax:
                        if 'max_val' in v:
                            _val = v['max_val'].split(',')[i]
                        else:
                            _val = self.STDINT_MIN_MAX[v['type']][1]
                    else:
                        if 'rand_val' in v:
                            _val = v['rand_val'].split(',')[i]
                        else:
                            _val = self._increment_val(v['type'])
                    ofp_pre.write('    ' + varname + member + idx + ' = ' + str(_val) + ';\n')
                    vfy_macro = self.GTEST_VERIFY_MACRO_FLOAT if v['type'] in self._rte.FLOAT_TYPES else self.GTEST_VERIFY_MACRO_STDINT
                    ofp_vfy_b.write('    ' + vfy_macro + '(' + variable + member + idx + ', ' + str(_val) + ');\n')
                    _vals.append(_val)
                if tail:
                    ofp_pre.write('    Rte_Write_' + port + '_' + port + '(' + ptrstr + varname + ');\n')

                # check per indivisual SWCs
                for swc in swcR:
                    inner_func = ''
                    if isBus:
                        idx = ''
                        vartype = port
                        member = '.' + v['name']
                        class_idx = '_' + str(v2.index(v))
                    else:
                        idx = '' if v['multi'] <= 1 else '[' + str(v['multi']) + ']'
                        vartype = self._rte.STDINT_TYPES[v['type']]
                        member = ''
                        class_idx = ''
                    class_name = 'func_' + port + '_' + swc + class_idx
                    inner_func += '    struct _' + class_name + ' {\n'
                    inner_func += '        static void verify(void) {\n'
                    inner_func += '#include "Rte_Wrapper_' + swc + '.h"\n'
                    inner_func += '            ' + vartype + ' ' + varname + idx + ';\n'
                    inner_func += '            Rte_Read_' + port + '_' + port + '(&' + varname + ');\n'
                    for i in range(0, v['multi']):
                        idx = '' if v['multi'] <= 1 else '[' + str(i) + ']'
                        _val = _vals[i]
                        vfy_macro = self.GTEST_VERIFY_MACRO_FLOAT if v['type'] in self._rte.FLOAT_TYPES else self.GTEST_VERIFY_MACRO_STDINT
                        inner_func += '            ' + vfy_macro + '(' + varname + member + idx + ', ' + str(_val) + ');\n'
                    inner_func += '        }\n'
                    inner_func += '    } ' + class_name + ';\n'
                    inner_func += '    ' + class_name + '.verify();\n'
                    ofp_vfy_b.write(inner_func)

                ofp_vfy_b.write('\n')

        ofp_pre.write('}\n')
        ofp_vfy_b.write('}\n')

        self.TEST_FUNCS[superswc][testcase]['pre_func'].append(pre_func)
        self.TEST_FUNCS[superswc][testcase]['vfy_func'].append(vfy_func)

    def _export_oem_to_oem_noncache(self, swcname, val, superswc, isMin = False, isMax = False):
        if swcname not in self.SUPER_SWCS[superswc]:
            return
        testcase = 'o2o_noncache'
        if isMin:
            testcase = 'o2o_noncache_min'
        elif isMax:
            testcase = 'o2o_noncache_max'
        ofp_pre = self.TEST_FUNCS[superswc][testcase]['ofp_pre']
        ofp_vfy_h = self.TEST_FUNCS[superswc][testcase]['ofp_vfy_h']
        ofp_vfy_b = self.TEST_FUNCS[superswc][testcase]['ofp_vfy_b']

        pre_func = superswc + '_' + testcase + '_prepare_' + swcname
        vfy_func = superswc + '_' + testcase + '_verify_' + swcname

        if ofp_pre.tell() == 0:
            ofp_pre.write('#include <limits.h>\n')
            ofp_pre.write('#include <float.h>\n')
            ofp_pre.write('#define DUMMY_RTE_INCLUDE_MULTI_SWC_HEADER\n')
            ofp_pre.write('#include "Platform_Types.h"\n')
        if ofp_vfy_h.tell() == 0:
            ofp_vfy_h.write('#include <limits.h>\n')
            ofp_vfy_h.write('#include <float.h>\n')
            ofp_vfy_h.write('#include "' + self.GTEST_PATH + '"\n')
            ofp_vfy_h.write('#include "Rte_Union.h"\n')
            ofp_vfy_h.write('#include "Platform_Types.h"\n')
            ofp_vfy_h.write('\n')
            for swc in self.SUPER_SWCS[superswc]:
                ofp_vfy_h.write('extern U' + swc + 'DataSet gOEM_SWC_' + superswc + 'U' + swc + 'DataSet;\n')

        ofp_pre.write('\n')
        ofp_pre.write('#include "Rte_Wrapper_' + swcname + '.h"\n')
        ofp_pre.write('void ' + pre_func + '(void)\n{\n')
        for varname, vartype in val['var'].items():
            ofp_pre.write('    ' + vartype[0] + ' ' + varname + ';\n')
        ofp_pre.write('\n')
        ofp_vfy_b.write('\n')
        ofp_vfy_b.write('void ' + vfy_func + '(void)\n{\n')
        for varname, vartype in val['var'].items():
            ofp_vfy_b.write('    ' + vartype[0] + ' ' + varname + ';\n')
        ofp_vfy_b.write('\n')

        # loop all signals
        for port, v1 in val['sig'].items():
            superswcs_R = []

            # only receiver is other OEM_SWC
            skip = True
            for swcR in v1['R']:
                for superswc_R, children in self.SUPER_SWCS.items():
                    if superswc_R == superswc:
                        continue
                    if swcR in children:
                        skip = False
                        superswcs_R.append([superswc_R, swcR])
                        self._log(DEBUG, '%s: %s [%s -> %s]' % (testcase, port, swcname, swcR))

            if skip:
                continue

            if port in self._port_rw_replacement:
                self._log(INFO, 'RTE : %s -> %s' % (port, self._port_rw_replacement[port]))
                port = self._port_rw_replacement[port]

            v2 = []
            isBus = False
            if v1['type'] in self._rte.STDINT_TYPES:
                v2.append(v1)
            elif self._bus is not None:
                v2 = self._bus[port]['mem']
                isBus = True
            else:
                continue
            
            ofp_vfy_b.write('    /* ' + port + '*/\n')
            for v in v2:
                tail = v2.index(v) == len(v2) - 1
                if isBus:
                    varname = 'tmp_' + re.sub('^[V,F]_\w_', '', port)
                    member = '.' + v['name']
                    ptrstr = '&'
                else:
                    varname = 'tmp_' + v['type'] + ('' if v['multi'] <= 1 else '_' + str(v['multi']))
                    member = ''
                    ptrstr = ''

                variable = 'gOEM_SWC_' + superswc + 'U' + swcname + 'DataSet.mConc.' + port # DataSet
                variable_R = []
                for superswc_R, swcR in superswcs_R:
                    variable_R.append('gOEM_SWC_' + superswc_R + 'U' + swcname + 'DataSet.mConc.' + port)
                    ofp_vfy_b.write('    extern U' + swcname + 'DataSet gOEM_SWC_' + superswc_R + 'U' + swcname + 'DataSet;\n')

                _vals = []
                for i in range(0, v['multi']):
                    idx = '' if v['multi'] <= 1 else '[' + str(i) + ']'
                    if isMin:
                        if 'min_val' in v:
                            _val = v['min_val'].split(',')[i]
                        else:
                            _val = self.STDINT_MIN_MAX[v['type']][0]
                    elif isMax:
                        if 'max_val' in v:
                            _val = v['max_val'].split(',')[i]
                        else:
                            _val = self.STDINT_MIN_MAX[v['type']][1]
                    else:
                        if 'rand_val' in v:
                            _val = v['rand_val'].split(',')[i]
                        else:
                            _val = self._increment_val(v['type'])
                    ofp_pre.write('    ' + varname + member + idx + ' = ' + str(_val) + ';\n')
                    vfy_macro = self.GTEST_VERIFY_MACRO_FLOAT if v['type'] in self._rte.FLOAT_TYPES else self.GTEST_VERIFY_MACRO_STDINT
                    ofp_vfy_b.write('    ' + vfy_macro + '(' + variable + member + idx + ', ' + str(_val) + ');\n')
                    for varname_R in variable_R:
                        ofp_vfy_b.write('    ' + vfy_macro + '(' + varname_R + member + idx + ', ' + str(_val) + ');\n')
                    _vals.append(_val)
                    self._log(DEBUG, '%s: %s[%d], %s' % (testcase, port, i, str(_val)))
                if tail:
                    ofp_pre.write('    Rte_Write_' + port + '_' + port + '(' + ptrstr + varname + ');\n')
                    # ofp_vfy_b.write('    Rte_Read_' + port + '_' + port + '(' + varname + ');\n')

                # check per indivisual SWCs
                for superswc_R, swc in superswcs_R:
                    inner_func = ''
                    if isBus:
                        idx = ''
                        vartype = port
                        member = '.' + v['name']
                        class_idx = '_' + str(v2.index(v))
                    else:
                        idx = '' if v['multi'] <= 1 else '[' + str(v['multi']) + ']'
                        vartype = self._rte.STDINT_TYPES[v['type']]
                        member = ''
                        class_idx = ''
                    class_name = 'func_' + port + '_' + swc + class_idx
                    inner_func += '    struct _' + class_name + ' {\n'
                    inner_func += '        static void verify(void) {\n'
                    inner_func += '#include "Rte_Wrapper_' + swc + '.h"\n'
                    inner_func += '            ' + vartype + ' ' + varname + idx + ';\n'
                    inner_func += '            Rte_Read_' + port + '_' + port + '(&' + varname + ');\n'
                    for i in range(0, v['multi']):
                        idx = '' if v['multi'] <= 1 else '[' + str(i) + ']'
                        _val = _vals[i]
                        vfy_macro = self.GTEST_VERIFY_MACRO_FLOAT if v['type'] in self._rte.FLOAT_TYPES else self.GTEST_VERIFY_MACRO_STDINT
                        inner_func += '            ' + vfy_macro + '(' + varname + member + idx + ', ' + str(_val) + ');\n'
                    inner_func += '        }\n'
                    inner_func += '    } ' + class_name + ';\n'
                    inner_func += '    ' + class_name + '.verify();\n'
                    ofp_vfy_b.write(inner_func)

                ofp_vfy_b.write('\n')

        ofp_pre.write('}\n')
        ofp_vfy_b.write('}\n')

        self.TEST_FUNCS[superswc][testcase]['pre_func'].append(pre_func)
        self.TEST_FUNCS[superswc][testcase]['vfy_func'].append(vfy_func)

    def _export_test_main(self):
        for superswc, funcs in self.TEST_FUNCS.items():
            for testcase, vals in funcs.items():
                ofp = vals['ofp_main']
                if ofp is None:
                    continue

                other_superswcs = [s for s in self.TEST_FUNCS.keys() if s != superswc]
                infunc = 'OEM_SWC_' + superswc + '_input_From_SUP'
                outfunc = 'OEM_SWC_' + superswc + '_output'

                ofp.write('#include "' + self.GTEST_PATH + '"\n\n')
                # extern
                ofp.write('#ifdef __cplusplus\n')
                ofp.write('extern "C" {\n')
                ofp.write('#endif\n')
                ofp.write('extern void ' + infunc + '(void);\n')
                ofp.write('extern void ' + outfunc + '(void);\n')
                if testcase.startswith('o2o_noncache'):
                    for s in other_superswcs:
                        ofp.write('extern void OEM_SWC_' + s + '_input_From_OEM(void);\n')
                ofp.write('#ifdef __cplusplus\n')
                ofp.write('}\n')
                ofp.write('#endif\n\n')
                for func in vals['pre_func']:
                    ofp.write('extern void ' + func + '(void);\n')
                for func in vals['vfy_func']:
                    ofp.write('extern void ' + func + '(void);\n')
                # prepare
                ofp.write('void ' + superswc + '_' + testcase + '_prepare(void)\n{\n')
                for func in vals['pre_func']:
                    ofp.write('    ' + func + '();\n')
                ofp.write('}\n\n')
                # verify
                ofp.write('void ' + superswc + '_' + testcase + '_verify(void)\n{\n')
                for func in vals['vfy_func']:
                    ofp.write('    ' + func + '();\n')
                ofp.write('}\n\n')
                # test
                ofp.write('TEST(IOTest, ' + superswc + '_' + testcase + '_test)\n{\n')
                ofp.write('    ' + superswc + '_' + testcase + '_prepare();\n')
                if testcase.startswith('s2o'):
                    ofp.write('    ' + infunc + '();\n')
                elif testcase.startswith('o2s'):
                    ofp.write('    ' + outfunc + '();\n')
                elif testcase.startswith('o2o_noncache'):
                    ofp.write('    ' + outfunc + '();\n')
                    for s in other_superswcs:
                        ofp.write('    OEM_SWC_' + s + '_input_From_OEM();\n')
                ofp.write('    ' + superswc + '_' + testcase + '_verify();\n')
                ofp.write('}\n')

    def _increment_val(self, vartype):
        val = self.STDINT_TYPES_VAL[vartype]['val']
        if val >= self.STDINT_TYPES_VAL[vartype]['max']:
            val = self.STDINT_TYPES_VAL[vartype]['min']
        else:
            val += self.STDINT_TYPES_VAL[vartype]['inc']
        self.STDINT_TYPES_VAL[vartype]['val'] = val
        return str(val)

def parseArguments():
    argparser = argparse.ArgumentParser(description='Create Initialization function for FOTA IGN-ON')
    argparser.add_argument('-i', action = 'store', dest = 'InFile', required = True,
                           help = 'set Test Spec or RTE_SignalDB file path (ex. -i ~/work/hitachi_b1_spec/GroupD/*.xlsx)')
    argparser.add_argument('-g', action = 'store', dest = 'Group', default = 'A',
                           help = 'set Group [Default = A] (ex. -g D)')
    argparser.add_argument('-o', action = 'store', dest = 'OutDir', default = './stub',
                           help = 'set Directory to output generated files [Default = ./] (ex. -o ./AD_Software_platform/out)')
    argparser.add_argument('-r', action = 'store_true', dest = 'IsRteDB', default = False,
                           help = 'set if Input file is RTE_SignalDB')
    # argparser.add_argument('-s', action = 'store', dest = 'Setting', default = None,
    #                        help = 'set setting.json file path [Default = None] (ex. -s ./setting.json)')
    # argparser.add_argument('--onedir', action='store_true', dest='OneDir', default=False,
    #                        help = 'output files at the same directory')

    args = argparser.parse_args()
    return args

if __name__ == '__main__':
    args = parseArguments()

    # if args.Setting is not None:
    #     settingParser = SettingParser('settings.json', args.OutDir, args.OneDir)
    #     settingParser.read()
    #     swcDict = settingParser.parse()

    ioctx = IoTestCreator(args.InFile, args.Group, args.IsRteDB, args.OutDir)
    if not ioctx.read():
        sys.exit()
    ioctx.export()
