#include "gtest/gtest.h"

#ifdef __cplusplus
extern "C" {
#endif
extern void OEM_SWC_C0_SM_input_From_SUP(void);
extern void OEM_SWC_C0_SM_output(void);
#ifdef __cplusplus
}
#endif

extern void C0_SM_s2o_min_prepare_ADC(void);
extern void C0_SM_s2o_min_prepare_DIO(void);
extern void C0_SM_s2o_min_prepare_EEPROM(void);
extern void C0_SM_s2o_min_prepare_PWM(void);
extern void C0_SM_s2o_min_prepare_SUP_DIAG(void);
extern void C0_SM_s2o_min_prepare_UDSCOM(void);
extern void C0_SM_s2o_min_prepare_LINIF(void);
extern void C0_SM_s2o_min_prepare_CANIF(void);
extern void C0_SM_s2o_min_prepare_EthIF(void);
extern void C0_SM_s2o_min_prepare_OEMRAMClear(void);
extern void C0_SM_s2o_min_verify_ADC(void);
extern void C0_SM_s2o_min_verify_DIO(void);
extern void C0_SM_s2o_min_verify_EEPROM(void);
extern void C0_SM_s2o_min_verify_PWM(void);
extern void C0_SM_s2o_min_verify_SUP_DIAG(void);
extern void C0_SM_s2o_min_verify_UDSCOM(void);
extern void C0_SM_s2o_min_verify_LINIF(void);
extern void C0_SM_s2o_min_verify_CANIF(void);
extern void C0_SM_s2o_min_verify_EthIF(void);
extern void C0_SM_s2o_min_verify_OEMRAMClear(void);
void C0_SM_s2o_min_prepare(void)
{
    C0_SM_s2o_min_prepare_ADC();
    C0_SM_s2o_min_prepare_DIO();
    C0_SM_s2o_min_prepare_EEPROM();
    C0_SM_s2o_min_prepare_PWM();
    C0_SM_s2o_min_prepare_SUP_DIAG();
    C0_SM_s2o_min_prepare_UDSCOM();
    C0_SM_s2o_min_prepare_LINIF();
    C0_SM_s2o_min_prepare_CANIF();
    C0_SM_s2o_min_prepare_EthIF();
    C0_SM_s2o_min_prepare_OEMRAMClear();
}

void C0_SM_s2o_min_verify(void)
{
    C0_SM_s2o_min_verify_ADC();
    C0_SM_s2o_min_verify_DIO();
    C0_SM_s2o_min_verify_EEPROM();
    C0_SM_s2o_min_verify_PWM();
    C0_SM_s2o_min_verify_SUP_DIAG();
    C0_SM_s2o_min_verify_UDSCOM();
    C0_SM_s2o_min_verify_LINIF();
    C0_SM_s2o_min_verify_CANIF();
    C0_SM_s2o_min_verify_EthIF();
    C0_SM_s2o_min_verify_OEMRAMClear();
}

TEST(IOTest, C0_SM_s2o_min_test)
{
    C0_SM_s2o_min_prepare();
    OEM_SWC_C0_SM_input_From_SUP();
    C0_SM_s2o_min_verify();
}
