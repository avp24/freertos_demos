#include <limits.h>
#include <float.h>
#define DUMMY_RTE_INCLUDE_MULTI_SWC_HEADER
#include "Platform_Types.h"

#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
void C2_2_o2o_noncache_prepare_AutoLCPossibilityJdg(void)
{
    V_x_AutoLCPossibilityJdgOutput tmp_AutoLCPossibilityJdgOutput;

    tmp_AutoLCPossibilityJdgOutput.V_x_st_Output_DynamicConflJdgDiag.F_x_Dcj_ObjLeft = 4;
    tmp_AutoLCPossibilityJdgOutput.V_x_st_Output_DynamicConflJdgDiag.V_m_Dcj_ObjLeftPosX = 809.17;
    tmp_AutoLCPossibilityJdgOutput.V_x_st_Output_DynamicConflJdgDiag.V_m_Dcj_ObjLeftPosY = -365.12;
    tmp_AutoLCPossibilityJdgOutput.V_x_st_Output_DynamicConflJdgDiag.V_mps_Dcj_ObjLeftVelX = 247;
    tmp_AutoLCPossibilityJdgOutput.V_x_st_Output_DynamicConflJdgDiag.V_mps_Dcj_ObjLeftVelY = 508.3;
    tmp_AutoLCPossibilityJdgOutput.V_x_st_Output_DynamicConflJdgDiag.V_m_Dcj_ObjLeftGapF = 771.54;
    tmp_AutoLCPossibilityJdgOutput.V_x_st_Output_DynamicConflJdgDiag.V_m_Dcj_ObjLeftGapR = -117.17;
    tmp_AutoLCPossibilityJdgOutput.V_x_st_Output_DynamicConflJdgDiag.V_x_Dcj_ObjLeftNum = 64;
    tmp_AutoLCPossibilityJdgOutput.V_x_st_Output_DynamicConflJdgDiag.V_x_Dcj_ObjRight = 77;
    tmp_AutoLCPossibilityJdgOutput.V_x_st_Output_DynamicConflJdgDiag.V_m_Dcj_ObjRightPosX = 102.28;
    tmp_AutoLCPossibilityJdgOutput.V_x_st_Output_DynamicConflJdgDiag.V_m_Dcj_ObjRightPosY = -4.54;
    tmp_AutoLCPossibilityJdgOutput.V_x_st_Output_DynamicConflJdgDiag.V_mps_Dcj_ObjRightVelX = -456.04;
    tmp_AutoLCPossibilityJdgOutput.V_x_st_Output_DynamicConflJdgDiag.V_mps_Dcj_ObjRightVelY = -411.43;
    tmp_AutoLCPossibilityJdgOutput.V_x_st_Output_DynamicConflJdgDiag.V_m_Dcj_ObjRightGapF = -103.83;
    tmp_AutoLCPossibilityJdgOutput.V_x_st_Output_DynamicConflJdgDiag.V_m_Dcj_ObjRightGapR = 71.73;
    tmp_AutoLCPossibilityJdgOutput.V_x_st_Output_DynamicConflJdgDiag.V_x_Dcj_ObjRightNum = 123;
    tmp_AutoLCPossibilityJdgOutput.V_x_st_Output_Alc.V_x_lane_change_possible_left = 40;
    tmp_AutoLCPossibilityJdgOutput.V_x_st_Output_Alc.V_x_lane_change_possible_right = 175;
    tmp_AutoLCPossibilityJdgOutput.V_x_st_Output_Alc.V_x_lane_change_pass_right = 239;
    tmp_AutoLCPossibilityJdgOutput.V_x_st_Output_Alc.V_x_lane_change_return_left = 240;
    tmp_AutoLCPossibilityJdgOutput.V_x_st_Output_Alc.F_x_next_lane_free_left = 157;
    tmp_AutoLCPossibilityJdgOutput.V_x_st_Output_Alc.F_x_next_lane_free_right = 221;
    Rte_Write_V_x_AutoLCPossibilityJdgOutput_V_x_AutoLCPossibilityJdgOutput(&tmp_AutoLCPossibilityJdgOutput);
}

#include "Rte_Wrapper_ObjectSelectionDM.h"
void C2_2_o2o_noncache_prepare_ObjectSelectionDM(void)
{
    V_x_ObjectSelectionDMOutput tmp_ObjectSelectionDMOutput;

    tmp_ObjectSelectionDMOutput.V_m_FL_SideRadarPosX_DMS = -294.72;
    tmp_ObjectSelectionDMOutput.V_m_FL_SideRadarPosY_DMS = -376.55;
    tmp_ObjectSelectionDMOutput.V_mps_FL_SideRadarRelVelX_DMS = 436.68;
    tmp_ObjectSelectionDMOutput.V_m_FR_SideRadarPosX_DMS = -104.99;
    tmp_ObjectSelectionDMOutput.V_m_FR_SideRadarPosY_DMS = 285.88;
    tmp_ObjectSelectionDMOutput.V_mps_FR_SideRadarRelVelX_DMS = 613.71;
    tmp_ObjectSelectionDMOutput.V_m_RL_SideRadarPosX_DMS = 4.97;
    tmp_ObjectSelectionDMOutput.V_m_RL_SideRadarPosY_DMS = -366.85;
    tmp_ObjectSelectionDMOutput.V_mps_RL_SideRadarRelVelX_DMS = -94.81;
    tmp_ObjectSelectionDMOutput.V_m_RR_SideRadarPosX_DMS = -731.74;
    tmp_ObjectSelectionDMOutput.V_m_RR_SideRadarPosY_DMS = 598.76;
    tmp_ObjectSelectionDMOutput.V_mps_RR_SideRadarRelVelX_DMS = 52.8;
    Rte_Write_V_x_ObjectSelectionDMOutput_V_x_ObjectSelectionDMOutput(&tmp_ObjectSelectionDMOutput);
}

#include "Rte_Wrapper_VehStatus_In_50.h"
void C2_2_o2o_noncache_prepare_VehStatus_In_50(void)
{
    V_x_surround_obj_left_t tmp_surround_obj_left_t;
    V_x_surround_obj_rearcenter_t tmp_surround_obj_rearcenter_t;
    V_x_surround_obj_right_t tmp_surround_obj_right_t;

}
