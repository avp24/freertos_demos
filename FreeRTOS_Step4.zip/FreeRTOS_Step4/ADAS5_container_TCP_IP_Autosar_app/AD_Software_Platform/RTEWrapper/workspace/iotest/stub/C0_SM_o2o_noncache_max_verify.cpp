#include <limits.h>
#include <float.h>
#include "gtest/gtest.h"
#include "Rte_Union.h"
#include "Platform_Types.h"

extern USafetyModuleDataSet gOEM_SWC_C0_SMUSafetyModuleDataSet;

void C0_SM_o2o_noncache_max_verify_SafetyModule(void)
{
    uint16 tmp_U16;
    sint16 tmp_S16;
    sint8 tmp_S8;
    uint8 tmp_U8;

}
