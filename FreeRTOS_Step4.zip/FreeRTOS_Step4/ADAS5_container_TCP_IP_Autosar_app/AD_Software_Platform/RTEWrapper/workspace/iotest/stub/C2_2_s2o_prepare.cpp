#include <limits.h>
#include <float.h>
#define DUMMY_RTE_INCLUDE_MULTI_SWC_HEADER
#include "Platform_Types.h"
#ifdef __cplusplus
extern "C" {
#endif
#include "Rte_ADC.h"
#include "Rte_DIO.h"
#include "Rte_EEPROM.h"
#include "Rte_PWM.h"
#include "Rte_SUP_DIAG.h"
#include "Rte_UDSCOM.h"
#include "Rte_LINIF.h"
#include "Rte_CANIF.h"
#include "Rte_EthIF.h"
#include "Rte_OEMRAMClear.h"
#ifdef __cplusplus
}
#endif

void C2_2_s2o_prepare_ADC(void)
{
    uint16 tmp_U16;

}

void C2_2_s2o_prepare_DIO(void)
{
    boolean tmp_B;

}

void C2_2_s2o_prepare_EEPROM(void)
{
    boolean tmp_B;
    uint8 tmp_U8;
    float32 tmp_Fl32;
    uint32 tmp_U32;
    uint16 tmp_U16;
    uint8 tmp_U8_5[5];
    sint8 tmp_S8;
    uint8 tmp_U8_40[40];
    uint8 tmp_U8_48[48];

}

void C2_2_s2o_prepare_PWM(void)
{

}

void C2_2_s2o_prepare_SUP_DIAG(void)
{
    boolean tmp_B;
    uint8 tmp_U8;

}

void C2_2_s2o_prepare_UDSCOM(void)
{
    boolean tmp_B;
    uint16 tmp_U16;
    uint8 tmp_U8;

}

void C2_2_s2o_prepare_LINIF(void)
{
    boolean tmp_B;
    uint8 tmp_U8;

}

void C2_2_s2o_prepare_CANIF(void)
{
    boolean tmp_B;
    uint8 tmp_U8;
    sint16 tmp_S16;
    uint16 tmp_U16;
    float32 tmp_Fl32;
    sint32 tmp_S32;
    uint32 tmp_U32;
    uint8 tmp_U8_8[8];
    sint8 tmp_S8;

}

void C2_2_s2o_prepare_EthIF(void)
{
    boolean tmp_B;
    float32 tmp_Fl32;
    uint32 tmp_U32;
    uint8 tmp_U8;
    uint16 tmp_U16;

}

void C2_2_s2o_prepare_OEMRAMClear(void)
{
    boolean tmp_B;
    uint8 tmp_U8;

}
