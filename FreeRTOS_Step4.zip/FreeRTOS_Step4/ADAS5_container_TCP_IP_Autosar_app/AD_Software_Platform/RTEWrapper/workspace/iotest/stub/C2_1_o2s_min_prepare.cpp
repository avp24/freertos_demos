#include <limits.h>
#include <float.h>
#define DUMMY_RTE_INCLUDE_MULTI_SWC_HEADER
#include "Platform_Types.h"
#ifdef __cplusplus
extern "C" {
#endif
#ifdef __cplusplus
}
#endif

#include "Rte_Wrapper_SurroundFusion.h"
void C2_1_o2s_min_prepare_SurroundFusion(void)
{
    V_x_SurroundFusionOutput tmp_SurroundFusionOutput;
    sint32 tmp_S32;
    V_x_clustered_side_radar_obj_t_inter tmp_clustered_side_radar_obj_t_inter;
    V_x_sorted_side_radar_obj_t_inter tmp_sorted_side_radar_obj_t_inter;
    V_x_surround_obj_left_t_inter tmp_surround_obj_left_t_inter;
    V_x_surround_obj_rearcenter_t_inter tmp_surround_obj_rearcenter_t_inter;
    V_x_surround_obj_right_t_inter tmp_surround_obj_right_t_inter;

}

#include "Rte_Wrapper_VehStatus_In_10.h"
void C2_1_o2s_min_prepare_VehStatus_In_10(void)
{
    uint8 tmp_U8;
    V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;

}
