#include "gtest/gtest.h"

#ifdef __cplusplus
extern "C" {
#endif
extern void OEM_SWC_C2_3_input_From_SUP(void);
extern void OEM_SWC_C2_3_output(void);
#ifdef __cplusplus
}
#endif

extern void C2_3_o2o_cache_prepare_RCarHMIManagement(void);
extern void C2_3_o2o_cache_prepare_ObjectSelectionAVM(void);
extern void C2_3_o2o_cache_prepare_VehStatus_In_100(void);
extern void C2_3_o2o_cache_verify_RCarHMIManagement(void);
extern void C2_3_o2o_cache_verify_ObjectSelectionAVM(void);
extern void C2_3_o2o_cache_verify_VehStatus_In_100(void);
void C2_3_o2o_cache_prepare(void)
{
    C2_3_o2o_cache_prepare_RCarHMIManagement();
    C2_3_o2o_cache_prepare_ObjectSelectionAVM();
    C2_3_o2o_cache_prepare_VehStatus_In_100();
}

void C2_3_o2o_cache_verify(void)
{
    C2_3_o2o_cache_verify_RCarHMIManagement();
    C2_3_o2o_cache_verify_ObjectSelectionAVM();
    C2_3_o2o_cache_verify_VehStatus_In_100();
}

TEST(IOTest, C2_3_o2o_cache_test)
{
    C2_3_o2o_cache_prepare();
    C2_3_o2o_cache_verify();
}
