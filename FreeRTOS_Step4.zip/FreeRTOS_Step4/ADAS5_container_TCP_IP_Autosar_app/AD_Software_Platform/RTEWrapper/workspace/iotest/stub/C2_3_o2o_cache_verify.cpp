#include <limits.h>
#include <float.h>
#include "gtest/gtest.h"
#include "Rte_Union.h"
#include "Platform_Types.h"

extern URCarHMIManagementDataSet gOEM_SWC_C2_3URCarHMIManagementDataSet;
void C2_3_o2o_cache_verify_RCarHMIManagement(void)
{
    V_x_RCarHMIManagementOutput tmp_RCarHMIManagementOutput;

}

extern UObjectSelectionAVMDataSet gOEM_SWC_C2_3UObjectSelectionAVMDataSet;
void C2_3_o2o_cache_verify_ObjectSelectionAVM(void)
{
    V_x_ObjectSelectionAVMOutput tmp_ObjectSelectionAVMOutput;

}

extern UVehStatus_In_100DataSet gOEM_SWC_C2_3UVehStatus_In_100DataSet;
void C2_3_o2o_cache_verify_VehStatus_In_100(void)
{
    V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
    sint32 tmp_S32;
    V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
    V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;

    /* V_x_RCarHMIManagementSensorInput */
    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[0].llTimeStamp, 358708636);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_0 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[0].llTimeStamp, 358708636);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_0;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_0.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[0].V_x_ObjectID, 113);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_1 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[0].V_x_ObjectID, 113);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_1;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_1.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[0].F_x_CIPV, 208);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_2 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[0].F_x_CIPV, 208);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_2;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_2.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[0].V_x_ObjectLength, -892.05);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_3 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[0].V_x_ObjectLength, -892.05);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_3;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_3.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[0].V_m_ObjectWidth, -44.58);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_4 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[0].V_m_ObjectWidth, -44.58);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_4;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_4.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[0].V_m_ObjectPosX, 733.19);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_5 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[0].V_m_ObjectPosX, 733.19);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_5;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_5.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[0].V_m_ObjectPosY, -475.73);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_6 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[0].V_m_ObjectPosY, -475.73);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_6;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_6.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[0].V_mps_ObjectVelX, -387.91);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_7 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[0].V_mps_ObjectVelX, -387.91);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_7;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_7.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[0].V_mps_ObjectVelY, 557.03);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_8 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[0].V_mps_ObjectVelY, 557.03);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_8;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_8.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[0].V_x_ObjectType, 102);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_9 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[0].V_x_ObjectType, 102);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_9;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_9.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[0].V_x_ObjectStatus, 187);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_10 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[0].V_x_ObjectStatus, 187);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_10;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_10.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[0].V_x_ObjectValid, 216);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_11 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[0].V_x_ObjectValid, 216);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_11;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_11.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[0].V_x_ObjectLane, 156);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_12 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[0].V_x_ObjectLane, 156);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_12;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_12.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[0].V_s_TTC, 971.62);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_13 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[0].V_s_TTC, 971.62);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_13;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_13.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[0].V_mps2_ObjectAccelX, 295.08);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_14 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[0].V_mps2_ObjectAccelX, 295.08);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_14;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_14.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[0].V_x_BlinkInfo, 162);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_15 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[0].V_x_BlinkInfo, 162);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_15;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_15.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[0].V_degps_ObjectAngleRate, -22.51);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_16 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[0].V_degps_ObjectAngleRate, -22.51);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_16;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_16.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[0].V_deg_ObjectAngle, 852.67);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_17 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[0].V_deg_ObjectAngle, 852.67);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_17;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_17.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[0].V_mps_ObejectRelVelocity, 302.22);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_18 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[0].V_mps_ObejectRelVelocity, 302.22);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_18;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_18.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[1].llTimeStamp, 3640905660);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_19 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[1].llTimeStamp, 3640905660);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_19;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_19.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[1].V_x_ObjectID, 226);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_20 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[1].V_x_ObjectID, 226);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_20;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_20.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[1].F_x_CIPV, 83);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_21 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[1].F_x_CIPV, 83);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_21;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_21.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[1].V_x_ObjectLength, 364.15);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_22 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[1].V_x_ObjectLength, 364.15);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_22;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_22.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[1].V_m_ObjectWidth, -967.12);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_23 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[1].V_m_ObjectWidth, -967.12);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_23;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_23.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[1].V_m_ObjectPosX, -893.92);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_24 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[1].V_m_ObjectPosX, -893.92);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_24;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_24.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[1].V_m_ObjectPosY, 260.21);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_25 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[1].V_m_ObjectPosY, 260.21);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_25;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_25.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[1].V_mps_ObjectVelX, 695.33);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_26 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[1].V_mps_ObjectVelX, 695.33);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_26;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_26.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[1].V_mps_ObjectVelY, -478.65);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_27 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[1].V_mps_ObjectVelY, -478.65);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_27;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_27.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[1].V_x_ObjectType, 212);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_28 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[1].V_x_ObjectType, 212);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_28;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_28.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[1].V_x_ObjectStatus, 199);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_29 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[1].V_x_ObjectStatus, 199);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_29;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_29.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[1].V_x_ObjectValid, 102);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_30 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[1].V_x_ObjectValid, 102);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_30;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_30.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[1].V_x_ObjectLane, 63);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_31 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[1].V_x_ObjectLane, 63);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_31;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_31.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[1].V_s_TTC, 666.1);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_32 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[1].V_s_TTC, 666.1);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_32;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_32.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[1].V_mps2_ObjectAccelX, 477.75);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_33 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[1].V_mps2_ObjectAccelX, 477.75);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_33;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_33.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[1].V_x_BlinkInfo, 38);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_34 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[1].V_x_BlinkInfo, 38);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_34;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_34.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[1].V_degps_ObjectAngleRate, -71.6);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_35 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[1].V_degps_ObjectAngleRate, -71.6);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_35;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_35.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[1].V_deg_ObjectAngle, 678.74);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_36 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[1].V_deg_ObjectAngle, 678.74);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_36;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_36.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[1].V_mps_ObejectRelVelocity, -633.91);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_37 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[1].V_mps_ObejectRelVelocity, -633.91);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_37;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_37.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[2].llTimeStamp, 3042638024);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_38 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[2].llTimeStamp, 3042638024);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_38;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_38.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[2].V_x_ObjectID, 111);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_39 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[2].V_x_ObjectID, 111);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_39;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_39.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[2].F_x_CIPV, 47);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_40 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[2].F_x_CIPV, 47);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_40;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_40.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[2].V_x_ObjectLength, 541.34);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_41 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[2].V_x_ObjectLength, 541.34);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_41;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_41.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[2].V_m_ObjectWidth, -355.8);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_42 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[2].V_m_ObjectWidth, -355.8);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_42;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_42.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[2].V_m_ObjectPosX, 107.64);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_43 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[2].V_m_ObjectPosX, 107.64);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_43;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_43.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[2].V_m_ObjectPosY, 211.92);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_44 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[2].V_m_ObjectPosY, 211.92);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_44;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_44.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[2].V_mps_ObjectVelX, 676.96);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_45 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[2].V_mps_ObjectVelX, 676.96);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_45;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_45.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[2].V_mps_ObjectVelY, -974.02);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_46 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[2].V_mps_ObjectVelY, -974.02);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_46;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_46.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[2].V_x_ObjectType, 226);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_47 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[2].V_x_ObjectType, 226);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_47;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_47.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[2].V_x_ObjectStatus, 104);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_48 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[2].V_x_ObjectStatus, 104);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_48;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_48.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[2].V_x_ObjectValid, 207);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_49 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[2].V_x_ObjectValid, 207);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_49;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_49.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[2].V_x_ObjectLane, 231);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_50 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[2].V_x_ObjectLane, 231);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_50;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_50.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[2].V_s_TTC, -533.72);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_51 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[2].V_s_TTC, -533.72);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_51;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_51.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[2].V_mps2_ObjectAccelX, -123.77);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_52 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[2].V_mps2_ObjectAccelX, -123.77);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_52;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_52.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[2].V_x_BlinkInfo, 147);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_53 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[2].V_x_BlinkInfo, 147);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_53;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_53.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[2].V_degps_ObjectAngleRate, 677.32);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_54 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[2].V_degps_ObjectAngleRate, 677.32);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_54;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_54.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[2].V_deg_ObjectAngle, -837.32);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_55 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[2].V_deg_ObjectAngle, -837.32);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_55;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_55.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[2].V_mps_ObejectRelVelocity, 387.33);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_56 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[2].V_mps_ObejectRelVelocity, 387.33);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_56;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_56.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[3].llTimeStamp, 3851528642);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_57 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[3].llTimeStamp, 3851528642);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_57;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_57.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[3].V_x_ObjectID, 54);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_58 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[3].V_x_ObjectID, 54);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_58;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_58.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[3].F_x_CIPV, 178);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_59 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[3].F_x_CIPV, 178);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_59;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_59.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[3].V_x_ObjectLength, -565.99);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_60 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[3].V_x_ObjectLength, -565.99);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_60;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_60.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[3].V_m_ObjectWidth, -854.83);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_61 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[3].V_m_ObjectWidth, -854.83);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_61;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_61.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[3].V_m_ObjectPosX, -759.65);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_62 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[3].V_m_ObjectPosX, -759.65);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_62;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_62.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[3].V_m_ObjectPosY, -16.72);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_63 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[3].V_m_ObjectPosY, -16.72);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_63;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_63.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[3].V_mps_ObjectVelX, -857.65);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_64 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[3].V_mps_ObjectVelX, -857.65);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_64;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_64.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[3].V_mps_ObjectVelY, -248.85);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_65 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[3].V_mps_ObjectVelY, -248.85);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_65;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_65.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[3].V_x_ObjectType, 72);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_66 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[3].V_x_ObjectType, 72);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_66;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_66.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[3].V_x_ObjectStatus, 204);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_67 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[3].V_x_ObjectStatus, 204);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_67;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_67.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[3].V_x_ObjectValid, 245);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_68 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[3].V_x_ObjectValid, 245);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_68;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_68.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[3].V_x_ObjectLane, 3);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_69 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[3].V_x_ObjectLane, 3);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_69;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_69.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[3].V_s_TTC, -477.81);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_70 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[3].V_s_TTC, -477.81);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_70;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_70.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[3].V_mps2_ObjectAccelX, -692.15);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_71 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[3].V_mps2_ObjectAccelX, -692.15);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_71;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_71.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[3].V_x_BlinkInfo, 192);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_72 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[3].V_x_BlinkInfo, 192);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_72;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_72.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[3].V_degps_ObjectAngleRate, -930.65);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_73 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[3].V_degps_ObjectAngleRate, -930.65);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_73;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_73.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[3].V_deg_ObjectAngle, 874.15);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_74 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[3].V_deg_ObjectAngle, 874.15);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_74;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_74.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[3].V_mps_ObejectRelVelocity, 539.8);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_75 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[3].V_mps_ObejectRelVelocity, 539.8);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_75;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_75.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[4].llTimeStamp, 154993187);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_76 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[4].llTimeStamp, 154993187);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_76;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_76.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[4].V_x_ObjectID, 224);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_77 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[4].V_x_ObjectID, 224);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_77;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_77.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[4].F_x_CIPV, 64);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_78 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[4].F_x_CIPV, 64);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_78;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_78.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[4].V_x_ObjectLength, -214.61);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_79 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[4].V_x_ObjectLength, -214.61);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_79;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_79.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[4].V_m_ObjectWidth, -784.26);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_80 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[4].V_m_ObjectWidth, -784.26);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_80;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_80.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[4].V_m_ObjectPosX, -972.23);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_81 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[4].V_m_ObjectPosX, -972.23);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_81;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_81.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[4].V_m_ObjectPosY, 265.94);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_82 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[4].V_m_ObjectPosY, 265.94);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_82;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_82.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[4].V_mps_ObjectVelX, 226.22);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_83 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[4].V_mps_ObjectVelX, 226.22);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_83;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_83.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[4].V_mps_ObjectVelY, -236.03);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_84 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[4].V_mps_ObjectVelY, -236.03);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_84;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_84.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[4].V_x_ObjectType, 168);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_85 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[4].V_x_ObjectType, 168);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_85;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_85.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[4].V_x_ObjectStatus, 231);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_86 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[4].V_x_ObjectStatus, 231);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_86;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_86.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[4].V_x_ObjectValid, 221);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_87 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[4].V_x_ObjectValid, 221);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_87;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_87.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[4].V_x_ObjectLane, 200);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_88 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[4].V_x_ObjectLane, 200);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_88;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_88.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[4].V_s_TTC, -25.69);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_89 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[4].V_s_TTC, -25.69);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_89;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_89.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[4].V_mps2_ObjectAccelX, 883.85);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_90 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[4].V_mps2_ObjectAccelX, 883.85);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_90;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_90.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[4].V_x_BlinkInfo, 6);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_91 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[4].V_x_BlinkInfo, 6);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_91;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_91.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[4].V_degps_ObjectAngleRate, -945.67);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_92 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[4].V_degps_ObjectAngleRate, -945.67);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_92;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_92.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[4].V_deg_ObjectAngle, -139.78);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_93 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[4].V_deg_ObjectAngle, -139.78);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_93;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_93.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[4].V_mps_ObejectRelVelocity, -25.35);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_94 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[4].V_mps_ObejectRelVelocity, -25.35);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_94;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_94.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[5].llTimeStamp, 1625587405);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_95 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[5].llTimeStamp, 1625587405);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_95;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_95.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[5].V_x_ObjectID, 31);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_96 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[5].V_x_ObjectID, 31);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_96;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_96.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[5].F_x_CIPV, 88);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_97 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[5].F_x_CIPV, 88);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_97;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_97.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[5].V_x_ObjectLength, 641.71);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_98 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[5].V_x_ObjectLength, 641.71);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_98;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_98.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[5].V_m_ObjectWidth, -711.19);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_99 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[5].V_m_ObjectWidth, -711.19);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_99;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_99.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[5].V_m_ObjectPosX, 609.21);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_100 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[5].V_m_ObjectPosX, 609.21);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_100;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_100.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[5].V_m_ObjectPosY, -597);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_101 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[5].V_m_ObjectPosY, -597);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_101;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_101.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[5].V_mps_ObjectVelX, 776.61);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_102 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[5].V_mps_ObjectVelX, 776.61);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_102;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_102.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[5].V_mps_ObjectVelY, -751.9);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_103 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[5].V_mps_ObjectVelY, -751.9);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_103;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_103.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[5].V_x_ObjectType, 135);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_104 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[5].V_x_ObjectType, 135);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_104;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_104.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[5].V_x_ObjectStatus, 154);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_105 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[5].V_x_ObjectStatus, 154);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_105;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_105.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[5].V_x_ObjectValid, 27);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_106 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[5].V_x_ObjectValid, 27);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_106;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_106.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[5].V_x_ObjectLane, 3);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_107 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[5].V_x_ObjectLane, 3);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_107;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_107.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[5].V_s_TTC, 725.13);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_108 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[5].V_s_TTC, 725.13);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_108;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_108.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[5].V_mps2_ObjectAccelX, 975.61);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_109 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[5].V_mps2_ObjectAccelX, 975.61);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_109;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_109.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[5].V_x_BlinkInfo, 54);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_110 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[5].V_x_BlinkInfo, 54);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_110;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_110.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[5].V_degps_ObjectAngleRate, -973.66);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_111 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[5].V_degps_ObjectAngleRate, -973.66);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_111;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_111.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[5].V_deg_ObjectAngle, -776.73);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_112 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[5].V_deg_ObjectAngle, -776.73);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_112;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_112.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[5].V_mps_ObejectRelVelocity, 213.04);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_113 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[5].V_mps_ObejectRelVelocity, 213.04);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_113;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_113.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[6].llTimeStamp, 228469806);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_114 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[6].llTimeStamp, 228469806);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_114;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_114.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[6].V_x_ObjectID, 110);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_115 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[6].V_x_ObjectID, 110);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_115;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_115.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[6].F_x_CIPV, 102);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_116 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[6].F_x_CIPV, 102);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_116;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_116.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[6].V_x_ObjectLength, -681.95);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_117 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[6].V_x_ObjectLength, -681.95);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_117;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_117.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[6].V_m_ObjectWidth, 75.15);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_118 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[6].V_m_ObjectWidth, 75.15);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_118;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_118.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[6].V_m_ObjectPosX, -488.75);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_119 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[6].V_m_ObjectPosX, -488.75);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_119;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_119.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[6].V_m_ObjectPosY, -693.28);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_120 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[6].V_m_ObjectPosY, -693.28);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_120;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_120.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[6].V_mps_ObjectVelX, 557.95);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_121 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[6].V_mps_ObjectVelX, 557.95);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_121;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_121.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[6].V_mps_ObjectVelY, -248.54);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_122 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[6].V_mps_ObjectVelY, -248.54);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_122;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_122.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[6].V_x_ObjectType, 65);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_123 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[6].V_x_ObjectType, 65);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_123;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_123.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[6].V_x_ObjectStatus, 133);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_124 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[6].V_x_ObjectStatus, 133);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_124;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_124.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[6].V_x_ObjectValid, 121);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_125 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[6].V_x_ObjectValid, 121);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_125;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_125.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[6].V_x_ObjectLane, 91);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_126 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[6].V_x_ObjectLane, 91);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_126;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_126.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[6].V_s_TTC, 330.82);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_127 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[6].V_s_TTC, 330.82);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_127;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_127.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[6].V_mps2_ObjectAccelX, 277.22);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_128 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[6].V_mps2_ObjectAccelX, 277.22);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_128;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_128.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[6].V_x_BlinkInfo, 41);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_129 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[6].V_x_BlinkInfo, 41);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_129;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_129.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[6].V_degps_ObjectAngleRate, 773.84);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_130 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[6].V_degps_ObjectAngleRate, 773.84);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_130;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_130.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[6].V_deg_ObjectAngle, -110.91);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_131 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[6].V_deg_ObjectAngle, -110.91);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_131;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_131.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[6].V_mps_ObejectRelVelocity, -900.87);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_132 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[6].V_mps_ObejectRelVelocity, -900.87);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_132;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_132.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[7].llTimeStamp, 3217290101);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_133 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[7].llTimeStamp, 3217290101);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_133;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_133.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[7].V_x_ObjectID, 167);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_134 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[7].V_x_ObjectID, 167);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_134;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_134.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[7].F_x_CIPV, 80);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_135 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[7].F_x_CIPV, 80);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_135;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_135.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[7].V_x_ObjectLength, -720.68);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_136 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[7].V_x_ObjectLength, -720.68);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_136;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_136.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[7].V_m_ObjectWidth, 637.47);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_137 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[7].V_m_ObjectWidth, 637.47);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_137;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_137.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[7].V_m_ObjectPosX, 874.99);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_138 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[7].V_m_ObjectPosX, 874.99);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_138;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_138.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[7].V_m_ObjectPosY, 707.14);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_139 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[7].V_m_ObjectPosY, 707.14);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_139;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_139.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[7].V_mps_ObjectVelX, -21.8);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_140 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[7].V_mps_ObjectVelX, -21.8);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_140;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_140.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[7].V_mps_ObjectVelY, 352.3);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_141 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[7].V_mps_ObjectVelY, 352.3);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_141;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_141.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[7].V_x_ObjectType, 157);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_142 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[7].V_x_ObjectType, 157);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_142;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_142.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[7].V_x_ObjectStatus, 97);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_143 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[7].V_x_ObjectStatus, 97);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_143;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_143.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[7].V_x_ObjectValid, 138);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_144 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[7].V_x_ObjectValid, 138);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_144;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_144.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[7].V_x_ObjectLane, 222);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_145 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[7].V_x_ObjectLane, 222);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_145;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_145.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[7].V_s_TTC, -802.23);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_146 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[7].V_s_TTC, -802.23);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_146;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_146.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[7].V_mps2_ObjectAccelX, -518.28);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_147 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[7].V_mps2_ObjectAccelX, -518.28);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_147;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_147.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[7].V_x_BlinkInfo, 245);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_148 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[7].V_x_BlinkInfo, 245);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_148;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_148.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[7].V_degps_ObjectAngleRate, -773.69);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_149 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[7].V_degps_ObjectAngleRate, -773.69);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_149;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_149.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[7].V_deg_ObjectAngle, -402.13);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_150 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[7].V_deg_ObjectAngle, -402.13);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_150;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_150.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[7].V_mps_ObejectRelVelocity, -127.03);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_151 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[7].V_mps_ObejectRelVelocity, -127.03);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_151;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_151.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[8].llTimeStamp, 1398503567);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_152 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[8].llTimeStamp, 1398503567);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_152;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_152.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[8].V_x_ObjectID, 132);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_153 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[8].V_x_ObjectID, 132);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_153;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_153.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[8].F_x_CIPV, 1);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_154 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[8].F_x_CIPV, 1);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_154;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_154.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[8].V_x_ObjectLength, 348.5);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_155 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[8].V_x_ObjectLength, 348.5);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_155;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_155.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[8].V_m_ObjectWidth, 920.82);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_156 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[8].V_m_ObjectWidth, 920.82);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_156;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_156.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[8].V_m_ObjectPosX, 35.77);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_157 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[8].V_m_ObjectPosX, 35.77);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_157;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_157.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[8].V_m_ObjectPosY, 751.06);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_158 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[8].V_m_ObjectPosY, 751.06);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_158;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_158.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[8].V_mps_ObjectVelX, -891.8);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_159 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[8].V_mps_ObjectVelX, -891.8);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_159;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_159.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[8].V_mps_ObjectVelY, 452.61);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_160 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[8].V_mps_ObjectVelY, 452.61);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_160;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_160.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[8].V_x_ObjectType, 223);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_161 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[8].V_x_ObjectType, 223);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_161;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_161.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[8].V_x_ObjectStatus, 154);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_162 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[8].V_x_ObjectStatus, 154);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_162;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_162.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[8].V_x_ObjectValid, 226);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_163 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[8].V_x_ObjectValid, 226);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_163;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_163.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[8].V_x_ObjectLane, 200);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_164 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[8].V_x_ObjectLane, 200);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_164;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_164.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[8].V_s_TTC, -454.49);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_165 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[8].V_s_TTC, -454.49);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_165;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_165.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[8].V_mps2_ObjectAccelX, -83.43);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_166 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[8].V_mps2_ObjectAccelX, -83.43);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_166;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_166.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[8].V_x_BlinkInfo, 2);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_167 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[8].V_x_BlinkInfo, 2);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_167;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_167.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[8].V_degps_ObjectAngleRate, -187.47);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_168 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[8].V_degps_ObjectAngleRate, -187.47);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_168;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_168.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[8].V_deg_ObjectAngle, -276.68);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_169 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[8].V_deg_ObjectAngle, -276.68);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_169;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_169.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[8].V_mps_ObejectRelVelocity, 850.79);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_170 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[8].V_mps_ObejectRelVelocity, 850.79);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_170;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_170.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[9].llTimeStamp, 1551951265);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_171 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[9].llTimeStamp, 1551951265);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_171;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_171.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[9].V_x_ObjectID, 113);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_172 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[9].V_x_ObjectID, 113);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_172;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_172.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[9].F_x_CIPV, 11);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_173 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[9].F_x_CIPV, 11);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_173;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_173.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[9].V_x_ObjectLength, 154.67);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_174 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[9].V_x_ObjectLength, 154.67);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_174;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_174.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[9].V_m_ObjectWidth, -585.36);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_175 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[9].V_m_ObjectWidth, -585.36);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_175;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_175.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[9].V_m_ObjectPosX, 650.34);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_176 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[9].V_m_ObjectPosX, 650.34);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_176;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_176.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[9].V_m_ObjectPosY, 524.52);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_177 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[9].V_m_ObjectPosY, 524.52);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_177;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_177.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[9].V_mps_ObjectVelX, -766.58);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_178 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[9].V_mps_ObjectVelX, -766.58);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_178;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_178.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[9].V_mps_ObjectVelY, 977.8);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_179 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[9].V_mps_ObjectVelY, 977.8);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_179;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_179.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[9].V_x_ObjectType, 87);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_180 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[9].V_x_ObjectType, 87);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_180;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_180.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[9].V_x_ObjectStatus, 188);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_181 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[9].V_x_ObjectStatus, 188);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_181;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_181.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[9].V_x_ObjectValid, 125);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_182 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[9].V_x_ObjectValid, 125);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_182;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_182.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[9].V_x_ObjectLane, 36);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_183 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[9].V_x_ObjectLane, 36);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_183;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_183.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[9].V_s_TTC, -524.75);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_184 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[9].V_s_TTC, -524.75);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_184;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_184.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[9].V_mps2_ObjectAccelX, 231.35);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_185 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[9].V_mps2_ObjectAccelX, 231.35);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_185;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_185.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[9].V_x_BlinkInfo, 146);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_186 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[9].V_x_BlinkInfo, 146);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_186;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_186.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[9].V_degps_ObjectAngleRate, -228.04);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_187 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[9].V_degps_ObjectAngleRate, -228.04);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_187;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_187.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[9].V_deg_ObjectAngle, 712.5);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_188 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[9].V_deg_ObjectAngle, 712.5);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_188;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_188.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[9].V_mps_ObejectRelVelocity, -729.5);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_189 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[9].V_mps_ObejectRelVelocity, -729.5);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_189;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_189.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_front_cam_lane_2[0].llTimeStamp, 1020315453);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_190 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_EQ(tmp_RCarHMIManagementSensorInput.V_x_front_cam_lane_2[0].llTimeStamp, 1020315453);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_190;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_190.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_front_cam_lane_2[0].V_x_LaneType, 216);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_191 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_EQ(tmp_RCarHMIManagementSensorInput.V_x_front_cam_lane_2[0].V_x_LaneType, 216);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_191;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_191.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_front_cam_lane_2[0].V_x_LaneQuality, 132);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_192 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_EQ(tmp_RCarHMIManagementSensorInput.V_x_front_cam_lane_2[0].V_x_LaneQuality, 132);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_192;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_192.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_front_cam_lane_2[0].V_m_LanePosition, 300.46);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_193 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_front_cam_lane_2[0].V_m_LanePosition, 300.46);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_193;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_193.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_front_cam_lane_2[0].V_pm_LineCurv, 651.84);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_194 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_front_cam_lane_2[0].V_pm_LineCurv, 651.84);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_194;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_194.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_front_cam_lane_2[0].V_pm2_LineCurvaRate, -829.28);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_195 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_front_cam_lane_2[0].V_pm2_LineCurvaRate, -829.28);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_195;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_195.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_front_cam_lane_2[0].V_m_Lane_Mark_Width, -177.88);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_196 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_front_cam_lane_2[0].V_m_Lane_Mark_Width, -177.88);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_196;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_196.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_front_cam_lane_2[0].V_rad_LineYawAng, -951.72);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_197 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_front_cam_lane_2[0].V_rad_LineYawAng, -951.72);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_197;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_197.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_front_cam_lane_2[0].V_m_ViewRange_Start, -251.1);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_198 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_front_cam_lane_2[0].V_m_ViewRange_Start, -251.1);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_198;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_198.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_front_cam_lane_2[0].V_m_ViewRange_End, 242.91);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_199 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_front_cam_lane_2[0].V_m_ViewRange_End, 242.91);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_199;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_199.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_front_cam_lane_2[0].V_x_Lane_Crossing, 148);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_200 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_EQ(tmp_RCarHMIManagementSensorInput.V_x_front_cam_lane_2[0].V_x_Lane_Crossing, 148);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_200;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_200.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_front_cam_lane_2[0].V_x_Confidence_HWE, 174);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_201 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_EQ(tmp_RCarHMIManagementSensorInput.V_x_front_cam_lane_2[0].V_x_Confidence_HWE, 174);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_201;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_201.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_front_cam_lane_2[1].llTimeStamp, 792920287);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_202 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_EQ(tmp_RCarHMIManagementSensorInput.V_x_front_cam_lane_2[1].llTimeStamp, 792920287);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_202;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_202.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_front_cam_lane_2[1].V_x_LaneType, 91);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_203 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_EQ(tmp_RCarHMIManagementSensorInput.V_x_front_cam_lane_2[1].V_x_LaneType, 91);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_203;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_203.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_front_cam_lane_2[1].V_x_LaneQuality, 15);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_204 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_EQ(tmp_RCarHMIManagementSensorInput.V_x_front_cam_lane_2[1].V_x_LaneQuality, 15);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_204;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_204.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_front_cam_lane_2[1].V_m_LanePosition, 550.89);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_205 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_front_cam_lane_2[1].V_m_LanePosition, 550.89);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_205;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_205.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_front_cam_lane_2[1].V_pm_LineCurv, 664.72);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_206 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_front_cam_lane_2[1].V_pm_LineCurv, 664.72);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_206;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_206.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_front_cam_lane_2[1].V_pm2_LineCurvaRate, 496);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_207 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_front_cam_lane_2[1].V_pm2_LineCurvaRate, 496);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_207;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_207.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_front_cam_lane_2[1].V_m_Lane_Mark_Width, 760.07);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_208 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_front_cam_lane_2[1].V_m_Lane_Mark_Width, 760.07);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_208;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_208.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_front_cam_lane_2[1].V_rad_LineYawAng, -584.65);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_209 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_front_cam_lane_2[1].V_rad_LineYawAng, -584.65);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_209;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_209.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_front_cam_lane_2[1].V_m_ViewRange_Start, 134.42);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_210 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_front_cam_lane_2[1].V_m_ViewRange_Start, 134.42);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_210;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_210.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_front_cam_lane_2[1].V_m_ViewRange_End, 869.23);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_211 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_front_cam_lane_2[1].V_m_ViewRange_End, 869.23);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_211;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_211.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_front_cam_lane_2[1].V_x_Lane_Crossing, 86);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_212 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_EQ(tmp_RCarHMIManagementSensorInput.V_x_front_cam_lane_2[1].V_x_Lane_Crossing, 86);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_212;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_212.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_front_cam_lane_2[1].V_x_Confidence_HWE, 91);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_213 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_EQ(tmp_RCarHMIManagementSensorInput.V_x_front_cam_lane_2[1].V_x_Confidence_HWE, 91);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_213;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_213.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_front_cam_nextlane_2[0].V_x_NextLaneType, 79);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_214 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_EQ(tmp_RCarHMIManagementSensorInput.V_x_front_cam_nextlane_2[0].V_x_NextLaneType, 79);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_214;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_214.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_front_cam_nextlane_2[0].V_x_NextLaneQuality, 165);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_215 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_EQ(tmp_RCarHMIManagementSensorInput.V_x_front_cam_nextlane_2[0].V_x_NextLaneQuality, 165);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_215;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_215.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_front_cam_nextlane_2[0].V_m_NextLanePosition, 920.42);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_216 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_front_cam_nextlane_2[0].V_m_NextLanePosition, 920.42);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_216;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_216.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_front_cam_nextlane_2[0].V_pm_NextLineCurv, 194.91);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_217 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_front_cam_nextlane_2[0].V_pm_NextLineCurv, 194.91);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_217;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_217.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_front_cam_nextlane_2[0].V_pm2_NextLineCurvaRate, -531.93);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_218 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_front_cam_nextlane_2[0].V_pm2_NextLineCurvaRate, -531.93);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_218;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_218.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_front_cam_nextlane_2[0].V_m_NextLane_Mark_Width, 273.12);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_219 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_front_cam_nextlane_2[0].V_m_NextLane_Mark_Width, 273.12);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_219;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_219.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_front_cam_nextlane_2[0].V_rad_NextLineYawAng, 515.32);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_220 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_front_cam_nextlane_2[0].V_rad_NextLineYawAng, 515.32);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_220;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_220.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_front_cam_nextlane_2[0].V_m_NextViewRange_Start, 839.64);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_221 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_front_cam_nextlane_2[0].V_m_NextViewRange_Start, 839.64);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_221;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_221.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_front_cam_nextlane_2[0].V_m_NextViewRange_End, 146.24);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_222 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_front_cam_nextlane_2[0].V_m_NextViewRange_End, 146.24);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_222;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_222.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_front_cam_nextlane_2[0].V_x_ConfMeasure, -635.02);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_223 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_front_cam_nextlane_2[0].V_x_ConfMeasure, -635.02);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_223;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_223.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_front_cam_nextlane_2[1].V_x_NextLaneType, 194);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_224 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_EQ(tmp_RCarHMIManagementSensorInput.V_x_front_cam_nextlane_2[1].V_x_NextLaneType, 194);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_224;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_224.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_front_cam_nextlane_2[1].V_x_NextLaneQuality, 108);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_225 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_EQ(tmp_RCarHMIManagementSensorInput.V_x_front_cam_nextlane_2[1].V_x_NextLaneQuality, 108);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_225;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_225.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_front_cam_nextlane_2[1].V_m_NextLanePosition, -629.99);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_226 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_front_cam_nextlane_2[1].V_m_NextLanePosition, -629.99);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_226;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_226.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_front_cam_nextlane_2[1].V_pm_NextLineCurv, 860.47);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_227 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_front_cam_nextlane_2[1].V_pm_NextLineCurv, 860.47);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_227;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_227.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_front_cam_nextlane_2[1].V_pm2_NextLineCurvaRate, -83.93);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_228 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_front_cam_nextlane_2[1].V_pm2_NextLineCurvaRate, -83.93);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_228;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_228.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_front_cam_nextlane_2[1].V_m_NextLane_Mark_Width, -702.04);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_229 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_front_cam_nextlane_2[1].V_m_NextLane_Mark_Width, -702.04);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_229;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_229.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_front_cam_nextlane_2[1].V_rad_NextLineYawAng, 448.8);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_230 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_front_cam_nextlane_2[1].V_rad_NextLineYawAng, 448.8);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_230;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_230.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_front_cam_nextlane_2[1].V_m_NextViewRange_Start, -186.45);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_231 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_front_cam_nextlane_2[1].V_m_NextViewRange_Start, -186.45);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_231;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_231.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_front_cam_nextlane_2[1].V_m_NextViewRange_End, 987.96);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_232 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_front_cam_nextlane_2[1].V_m_NextViewRange_End, 987.96);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_232;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_232.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_front_cam_nextlane_2[1].V_x_ConfMeasure, 443.76);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_233 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_front_cam_nextlane_2[1].V_x_ConfMeasure, 443.76);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_233;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_233.verify();

    /* V_x_clustered_side_radar_obj_num */
    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_num, -111108555);
    struct _func_V_x_clustered_side_radar_obj_num_RCarHMIManagement {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            sint32 tmp_S32;
            Rte_Read_V_x_clustered_side_radar_obj_num_V_x_clustered_side_radar_obj_num(&tmp_S32);
            EXPECT_EQ(tmp_S32, -111108555);
        }
    } func_V_x_clustered_side_radar_obj_num_RCarHMIManagement;
    func_V_x_clustered_side_radar_obj_num_RCarHMIManagement.verify();

    /* V_x_clustered_side_radar_obj_t */
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[0].V_x_pos.V_m_X, 615.4);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_0 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[0].V_x_pos.V_m_X, 615.4);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_0;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_0.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[0].V_x_pos.V_m_Y, 37.78);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_1 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[0].V_x_pos.V_m_Y, 37.78);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_1;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_1.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[0].V_x_vel.V_m_X, 645.58);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_2 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[0].V_x_vel.V_m_X, 645.58);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_2;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_2.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[0].V_x_vel.V_m_Y, 131.08);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_3 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[0].V_x_vel.V_m_Y, 131.08);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_3;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_3.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[0].V_m_lat_pos_in_lane[0], -927.18);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[0].V_m_lat_pos_in_lane[1], -809.46);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[0].V_m_lat_pos_in_lane[2], -619.72);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[0].V_m_lat_pos_in_lane[3], -722.86);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[0].V_m_lat_pos_in_lane[4], -668.64);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_4 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[0].V_m_lat_pos_in_lane[0], -927.18);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[0].V_m_lat_pos_in_lane[1], -809.46);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[0].V_m_lat_pos_in_lane[2], -619.72);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[0].V_m_lat_pos_in_lane[3], -722.86);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[0].V_m_lat_pos_in_lane[4], -668.64);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_4;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_4.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[0].V_m_lat_vel_in_lane, -64.2);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_5 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[0].V_m_lat_vel_in_lane, -64.2);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_5;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_5.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[0].V_m_width, -115.42);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_6 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[0].V_m_width, -115.42);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_6;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_6.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[0].V_x_ID, 2708760123);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_7 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[0].V_x_ID, 2708760123);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_7;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_7.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[0].V_x_type, 2923914311);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_8 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[0].V_x_type, 2923914311);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_8;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_8.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[0].V_x_lane, 67);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_9 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[0].V_x_lane, 67);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_9;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_9.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[0].V_x_is_valid, 171);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_10 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[0].V_x_is_valid, 171);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_10;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_10.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[0].V_x_is_usable, 173);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_11 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[0].V_x_is_usable, 173);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_11;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_11.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[0].V_x_border, 2123685011);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_12 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[0].V_x_border, 2123685011);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_12;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_12.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[0].V_x_lost, 94);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_13 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[0].V_x_lost, 94);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_13;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_13.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[1].V_x_pos.V_m_X, 519.47);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_14 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[1].V_x_pos.V_m_X, 519.47);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_14;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_14.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[1].V_x_pos.V_m_Y, -398.82);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_15 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[1].V_x_pos.V_m_Y, -398.82);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_15;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_15.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[1].V_x_vel.V_m_X, 671.37);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_16 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[1].V_x_vel.V_m_X, 671.37);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_16;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_16.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[1].V_x_vel.V_m_Y, -907.5);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_17 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[1].V_x_vel.V_m_Y, -907.5);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_17;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_17.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[1].V_m_lat_pos_in_lane[0], 17.34);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[1].V_m_lat_pos_in_lane[1], -693.79);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[1].V_m_lat_pos_in_lane[2], -126.8);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[1].V_m_lat_pos_in_lane[3], 558.1);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[1].V_m_lat_pos_in_lane[4], -280.52);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_18 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[1].V_m_lat_pos_in_lane[0], 17.34);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[1].V_m_lat_pos_in_lane[1], -693.79);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[1].V_m_lat_pos_in_lane[2], -126.8);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[1].V_m_lat_pos_in_lane[3], 558.1);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[1].V_m_lat_pos_in_lane[4], -280.52);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_18;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_18.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[1].V_m_lat_vel_in_lane, 950.06);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_19 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[1].V_m_lat_vel_in_lane, 950.06);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_19;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_19.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[1].V_m_width, 235.4);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_20 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[1].V_m_width, 235.4);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_20;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_20.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[1].V_x_ID, 2003333187);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_21 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[1].V_x_ID, 2003333187);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_21;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_21.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[1].V_x_type, 631076892);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_22 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[1].V_x_type, 631076892);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_22;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_22.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[1].V_x_lane, 109);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_23 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[1].V_x_lane, 109);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_23;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_23.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[1].V_x_is_valid, 63);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_24 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[1].V_x_is_valid, 63);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_24;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_24.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[1].V_x_is_usable, 41);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_25 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[1].V_x_is_usable, 41);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_25;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_25.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[1].V_x_border, 3880919095);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_26 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[1].V_x_border, 3880919095);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_26;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_26.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[1].V_x_lost, 149);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_27 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[1].V_x_lost, 149);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_27;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_27.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[2].V_x_pos.V_m_X, -780.76);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_28 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[2].V_x_pos.V_m_X, -780.76);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_28;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_28.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[2].V_x_pos.V_m_Y, 802.66);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_29 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[2].V_x_pos.V_m_Y, 802.66);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_29;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_29.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[2].V_x_vel.V_m_X, -179.38);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_30 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[2].V_x_vel.V_m_X, -179.38);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_30;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_30.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[2].V_x_vel.V_m_Y, 309.03);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_31 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[2].V_x_vel.V_m_Y, 309.03);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_31;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_31.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[2].V_m_lat_pos_in_lane[0], -193.12);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[2].V_m_lat_pos_in_lane[1], 217.72);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[2].V_m_lat_pos_in_lane[2], 488.47);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[2].V_m_lat_pos_in_lane[3], 21.29);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[2].V_m_lat_pos_in_lane[4], -965.96);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_32 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[2].V_m_lat_pos_in_lane[0], -193.12);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[2].V_m_lat_pos_in_lane[1], 217.72);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[2].V_m_lat_pos_in_lane[2], 488.47);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[2].V_m_lat_pos_in_lane[3], 21.29);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[2].V_m_lat_pos_in_lane[4], -965.96);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_32;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_32.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[2].V_m_lat_vel_in_lane, -638.44);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_33 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[2].V_m_lat_vel_in_lane, -638.44);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_33;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_33.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[2].V_m_width, 288.96);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_34 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[2].V_m_width, 288.96);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_34;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_34.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[2].V_x_ID, 4223779233);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_35 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[2].V_x_ID, 4223779233);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_35;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_35.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[2].V_x_type, 1037378663);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_36 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[2].V_x_type, 1037378663);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_36;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_36.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[2].V_x_lane, 52);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_37 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[2].V_x_lane, 52);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_37;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_37.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[2].V_x_is_valid, 126);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_38 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[2].V_x_is_valid, 126);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_38;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_38.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[2].V_x_is_usable, 149);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_39 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[2].V_x_is_usable, 149);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_39;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_39.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[2].V_x_border, 3738099296);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_40 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[2].V_x_border, 3738099296);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_40;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_40.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[2].V_x_lost, 217);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_41 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[2].V_x_lost, 217);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_41;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_41.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[3].V_x_pos.V_m_X, 662.52);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_42 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[3].V_x_pos.V_m_X, 662.52);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_42;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_42.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[3].V_x_pos.V_m_Y, -884.84);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_43 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[3].V_x_pos.V_m_Y, -884.84);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_43;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_43.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[3].V_x_vel.V_m_X, -618.7);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_44 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[3].V_x_vel.V_m_X, -618.7);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_44;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_44.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[3].V_x_vel.V_m_Y, 163.68);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_45 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[3].V_x_vel.V_m_Y, 163.68);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_45;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_45.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[3].V_m_lat_pos_in_lane[0], 830.67);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[3].V_m_lat_pos_in_lane[1], 224.84);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[3].V_m_lat_pos_in_lane[2], -768.11);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[3].V_m_lat_pos_in_lane[3], -807.09);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[3].V_m_lat_pos_in_lane[4], -3.99);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_46 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[3].V_m_lat_pos_in_lane[0], 830.67);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[3].V_m_lat_pos_in_lane[1], 224.84);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[3].V_m_lat_pos_in_lane[2], -768.11);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[3].V_m_lat_pos_in_lane[3], -807.09);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[3].V_m_lat_pos_in_lane[4], -3.99);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_46;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_46.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[3].V_m_lat_vel_in_lane, 446.81);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_47 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[3].V_m_lat_vel_in_lane, 446.81);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_47;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_47.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[3].V_m_width, -946.23);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_48 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[3].V_m_width, -946.23);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_48;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_48.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[3].V_x_ID, 1820544134);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_49 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[3].V_x_ID, 1820544134);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_49;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_49.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[3].V_x_type, 2085428637);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_50 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[3].V_x_type, 2085428637);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_50;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_50.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[3].V_x_lane, 107);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_51 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[3].V_x_lane, 107);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_51;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_51.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[3].V_x_is_valid, 70);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_52 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[3].V_x_is_valid, 70);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_52;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_52.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[3].V_x_is_usable, 157);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_53 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[3].V_x_is_usable, 157);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_53;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_53.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[3].V_x_border, 3157605959);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_54 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[3].V_x_border, 3157605959);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_54;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_54.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[3].V_x_lost, 51);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_55 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[3].V_x_lost, 51);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_55;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_55.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[4].V_x_pos.V_m_X, 385.11);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_56 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[4].V_x_pos.V_m_X, 385.11);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_56;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_56.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[4].V_x_pos.V_m_Y, 34.77);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_57 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[4].V_x_pos.V_m_Y, 34.77);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_57;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_57.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[4].V_x_vel.V_m_X, 147.69);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_58 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[4].V_x_vel.V_m_X, 147.69);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_58;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_58.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[4].V_x_vel.V_m_Y, -742.96);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_59 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[4].V_x_vel.V_m_Y, -742.96);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_59;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_59.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[4].V_m_lat_pos_in_lane[0], 859.84);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[4].V_m_lat_pos_in_lane[1], -200.52);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[4].V_m_lat_pos_in_lane[2], 901.55);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[4].V_m_lat_pos_in_lane[3], 168.1);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[4].V_m_lat_pos_in_lane[4], -854.62);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_60 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[4].V_m_lat_pos_in_lane[0], 859.84);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[4].V_m_lat_pos_in_lane[1], -200.52);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[4].V_m_lat_pos_in_lane[2], 901.55);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[4].V_m_lat_pos_in_lane[3], 168.1);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[4].V_m_lat_pos_in_lane[4], -854.62);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_60;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_60.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[4].V_m_lat_vel_in_lane, -770.61);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_61 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[4].V_m_lat_vel_in_lane, -770.61);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_61;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_61.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[4].V_m_width, 851.96);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_62 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[4].V_m_width, 851.96);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_62;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_62.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[4].V_x_ID, 649863161);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_63 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[4].V_x_ID, 649863161);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_63;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_63.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[4].V_x_type, 1835305064);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_64 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[4].V_x_type, 1835305064);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_64;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_64.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[4].V_x_lane, 17);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_65 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[4].V_x_lane, 17);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_65;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_65.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[4].V_x_is_valid, 152);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_66 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[4].V_x_is_valid, 152);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_66;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_66.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[4].V_x_is_usable, 150);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_67 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[4].V_x_is_usable, 150);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_67;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_67.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[4].V_x_border, 3744885181);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_68 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[4].V_x_border, 3744885181);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_68;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_68.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[4].V_x_lost, 202);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_69 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[4].V_x_lost, 202);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_69;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_69.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[5].V_x_pos.V_m_X, -502.22);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_70 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[5].V_x_pos.V_m_X, -502.22);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_70;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_70.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[5].V_x_pos.V_m_Y, -903.21);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_71 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[5].V_x_pos.V_m_Y, -903.21);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_71;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_71.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[5].V_x_vel.V_m_X, -88.74);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_72 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[5].V_x_vel.V_m_X, -88.74);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_72;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_72.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[5].V_x_vel.V_m_Y, 754.99);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_73 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[5].V_x_vel.V_m_Y, 754.99);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_73;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_73.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[5].V_m_lat_pos_in_lane[0], 487.15);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[5].V_m_lat_pos_in_lane[1], -844.56);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[5].V_m_lat_pos_in_lane[2], -507.78);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[5].V_m_lat_pos_in_lane[3], -333.12);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[5].V_m_lat_pos_in_lane[4], -45.56);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_74 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[5].V_m_lat_pos_in_lane[0], 487.15);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[5].V_m_lat_pos_in_lane[1], -844.56);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[5].V_m_lat_pos_in_lane[2], -507.78);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[5].V_m_lat_pos_in_lane[3], -333.12);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[5].V_m_lat_pos_in_lane[4], -45.56);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_74;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_74.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[5].V_m_lat_vel_in_lane, 115.29);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_75 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[5].V_m_lat_vel_in_lane, 115.29);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_75;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_75.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[5].V_m_width, -855.82);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_76 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[5].V_m_width, -855.82);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_76;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_76.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[5].V_x_ID, 111827740);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_77 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[5].V_x_ID, 111827740);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_77;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_77.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[5].V_x_type, 700644897);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_78 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[5].V_x_type, 700644897);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_78;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_78.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[5].V_x_lane, 98);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_79 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[5].V_x_lane, 98);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_79;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_79.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[5].V_x_is_valid, 121);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_80 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[5].V_x_is_valid, 121);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_80;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_80.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[5].V_x_is_usable, 60);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_81 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[5].V_x_is_usable, 60);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_81;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_81.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[5].V_x_border, 690572026);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_82 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[5].V_x_border, 690572026);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_82;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_82.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[5].V_x_lost, 190);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_83 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[5].V_x_lost, 190);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_83;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_83.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[6].V_x_pos.V_m_X, -89.39);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_84 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[6].V_x_pos.V_m_X, -89.39);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_84;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_84.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[6].V_x_pos.V_m_Y, -197.91);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_85 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[6].V_x_pos.V_m_Y, -197.91);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_85;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_85.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[6].V_x_vel.V_m_X, 446.47);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_86 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[6].V_x_vel.V_m_X, 446.47);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_86;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_86.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[6].V_x_vel.V_m_Y, -756.95);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_87 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[6].V_x_vel.V_m_Y, -756.95);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_87;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_87.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[6].V_m_lat_pos_in_lane[0], -854.38);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[6].V_m_lat_pos_in_lane[1], -323.07);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[6].V_m_lat_pos_in_lane[2], -835.98);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[6].V_m_lat_pos_in_lane[3], -611.77);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[6].V_m_lat_pos_in_lane[4], -598.04);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_88 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[6].V_m_lat_pos_in_lane[0], -854.38);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[6].V_m_lat_pos_in_lane[1], -323.07);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[6].V_m_lat_pos_in_lane[2], -835.98);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[6].V_m_lat_pos_in_lane[3], -611.77);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[6].V_m_lat_pos_in_lane[4], -598.04);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_88;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_88.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[6].V_m_lat_vel_in_lane, -532.34);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_89 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[6].V_m_lat_vel_in_lane, -532.34);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_89;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_89.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[6].V_m_width, -798.81);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_90 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[6].V_m_width, -798.81);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_90;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_90.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[6].V_x_ID, 3543720658);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_91 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[6].V_x_ID, 3543720658);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_91;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_91.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[6].V_x_type, 1279420907);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_92 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[6].V_x_type, 1279420907);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_92;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_92.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[6].V_x_lane, 82);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_93 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[6].V_x_lane, 82);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_93;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_93.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[6].V_x_is_valid, 109);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_94 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[6].V_x_is_valid, 109);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_94;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_94.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[6].V_x_is_usable, 17);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_95 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[6].V_x_is_usable, 17);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_95;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_95.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[6].V_x_border, 2444398679);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_96 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[6].V_x_border, 2444398679);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_96;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_96.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[6].V_x_lost, 131);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_97 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[6].V_x_lost, 131);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_97;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_97.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[7].V_x_pos.V_m_X, 936.35);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_98 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[7].V_x_pos.V_m_X, 936.35);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_98;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_98.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[7].V_x_pos.V_m_Y, -274.67);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_99 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[7].V_x_pos.V_m_Y, -274.67);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_99;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_99.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[7].V_x_vel.V_m_X, 414.24);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_100 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[7].V_x_vel.V_m_X, 414.24);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_100;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_100.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[7].V_x_vel.V_m_Y, 17.5);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_101 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[7].V_x_vel.V_m_Y, 17.5);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_101;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_101.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[7].V_m_lat_pos_in_lane[0], -964.92);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[7].V_m_lat_pos_in_lane[1], -672.14);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[7].V_m_lat_pos_in_lane[2], -250.83);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[7].V_m_lat_pos_in_lane[3], 32.4);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[7].V_m_lat_pos_in_lane[4], 143.08);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_102 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[7].V_m_lat_pos_in_lane[0], -964.92);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[7].V_m_lat_pos_in_lane[1], -672.14);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[7].V_m_lat_pos_in_lane[2], -250.83);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[7].V_m_lat_pos_in_lane[3], 32.4);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[7].V_m_lat_pos_in_lane[4], 143.08);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_102;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_102.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[7].V_m_lat_vel_in_lane, 111.47);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_103 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[7].V_m_lat_vel_in_lane, 111.47);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_103;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_103.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[7].V_m_width, 901.75);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_104 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[7].V_m_width, 901.75);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_104;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_104.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[7].V_x_ID, 3654808746);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_105 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[7].V_x_ID, 3654808746);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_105;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_105.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[7].V_x_type, 3208897914);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_106 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[7].V_x_type, 3208897914);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_106;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_106.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[7].V_x_lane, 211);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_107 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[7].V_x_lane, 211);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_107;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_107.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[7].V_x_is_valid, 242);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_108 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[7].V_x_is_valid, 242);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_108;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_108.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[7].V_x_is_usable, 80);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_109 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[7].V_x_is_usable, 80);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_109;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_109.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[7].V_x_border, 3469667780);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_110 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[7].V_x_border, 3469667780);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_110;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_110.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[7].V_x_lost, 75);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_111 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[7].V_x_lost, 75);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_111;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_111.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[8].V_x_pos.V_m_X, -124.31);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_112 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[8].V_x_pos.V_m_X, -124.31);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_112;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_112.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[8].V_x_pos.V_m_Y, -475.17);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_113 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[8].V_x_pos.V_m_Y, -475.17);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_113;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_113.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[8].V_x_vel.V_m_X, -179.84);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_114 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[8].V_x_vel.V_m_X, -179.84);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_114;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_114.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[8].V_x_vel.V_m_Y, 789.42);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_115 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[8].V_x_vel.V_m_Y, 789.42);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_115;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_115.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[8].V_m_lat_pos_in_lane[0], -71.48);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[8].V_m_lat_pos_in_lane[1], 579.72);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[8].V_m_lat_pos_in_lane[2], -704.84);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[8].V_m_lat_pos_in_lane[3], -924.05);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[8].V_m_lat_pos_in_lane[4], -494.82);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_116 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[8].V_m_lat_pos_in_lane[0], -71.48);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[8].V_m_lat_pos_in_lane[1], 579.72);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[8].V_m_lat_pos_in_lane[2], -704.84);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[8].V_m_lat_pos_in_lane[3], -924.05);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[8].V_m_lat_pos_in_lane[4], -494.82);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_116;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_116.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[8].V_m_lat_vel_in_lane, 925.73);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_117 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[8].V_m_lat_vel_in_lane, 925.73);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_117;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_117.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[8].V_m_width, -16.03);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_118 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[8].V_m_width, -16.03);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_118;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_118.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[8].V_x_ID, 399056100);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_119 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[8].V_x_ID, 399056100);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_119;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_119.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[8].V_x_type, 250957186);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_120 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[8].V_x_type, 250957186);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_120;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_120.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[8].V_x_lane, 110);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_121 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[8].V_x_lane, 110);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_121;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_121.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[8].V_x_is_valid, 6);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_122 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[8].V_x_is_valid, 6);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_122;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_122.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[8].V_x_is_usable, 15);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_123 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[8].V_x_is_usable, 15);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_123;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_123.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[8].V_x_border, 2037366581);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_124 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[8].V_x_border, 2037366581);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_124;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_124.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[8].V_x_lost, 152);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_125 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[8].V_x_lost, 152);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_125;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_125.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[9].V_x_pos.V_m_X, 371.66);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_126 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[9].V_x_pos.V_m_X, 371.66);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_126;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_126.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[9].V_x_pos.V_m_Y, 936.28);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_127 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[9].V_x_pos.V_m_Y, 936.28);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_127;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_127.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[9].V_x_vel.V_m_X, -164.86);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_128 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[9].V_x_vel.V_m_X, -164.86);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_128;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_128.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[9].V_x_vel.V_m_Y, 451.55);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_129 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[9].V_x_vel.V_m_Y, 451.55);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_129;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_129.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[9].V_m_lat_pos_in_lane[0], -278.41);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[9].V_m_lat_pos_in_lane[1], 692.22);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[9].V_m_lat_pos_in_lane[2], -391.11);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[9].V_m_lat_pos_in_lane[3], 755.71);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[9].V_m_lat_pos_in_lane[4], 154.83);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_130 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[9].V_m_lat_pos_in_lane[0], -278.41);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[9].V_m_lat_pos_in_lane[1], 692.22);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[9].V_m_lat_pos_in_lane[2], -391.11);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[9].V_m_lat_pos_in_lane[3], 755.71);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[9].V_m_lat_pos_in_lane[4], 154.83);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_130;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_130.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[9].V_m_lat_vel_in_lane, -974.33);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_131 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[9].V_m_lat_vel_in_lane, -974.33);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_131;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_131.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[9].V_m_width, -510.51);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_132 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[9].V_m_width, -510.51);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_132;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_132.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[9].V_x_ID, 2561943314);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_133 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[9].V_x_ID, 2561943314);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_133;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_133.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[9].V_x_type, 2064418007);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_134 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[9].V_x_type, 2064418007);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_134;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_134.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[9].V_x_lane, 63);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_135 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[9].V_x_lane, 63);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_135;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_135.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[9].V_x_is_valid, 177);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_136 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[9].V_x_is_valid, 177);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_136;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_136.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[9].V_x_is_usable, 198);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_137 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[9].V_x_is_usable, 198);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_137;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_137.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[9].V_x_border, 993307319);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_138 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[9].V_x_border, 993307319);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_138;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_138.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[9].V_x_lost, 143);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_139 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[9].V_x_lost, 143);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_139;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_139.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[10].V_x_pos.V_m_X, -892.92);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_140 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[10].V_x_pos.V_m_X, -892.92);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_140;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_140.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[10].V_x_pos.V_m_Y, -259.62);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_141 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[10].V_x_pos.V_m_Y, -259.62);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_141;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_141.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[10].V_x_vel.V_m_X, -606.83);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_142 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[10].V_x_vel.V_m_X, -606.83);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_142;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_142.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[10].V_x_vel.V_m_Y, 882.83);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_143 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[10].V_x_vel.V_m_Y, 882.83);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_143;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_143.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[10].V_m_lat_pos_in_lane[0], -742.14);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[10].V_m_lat_pos_in_lane[1], -644.23);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[10].V_m_lat_pos_in_lane[2], 498.98);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[10].V_m_lat_pos_in_lane[3], -736.66);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[10].V_m_lat_pos_in_lane[4], 489.32);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_144 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[10].V_m_lat_pos_in_lane[0], -742.14);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[10].V_m_lat_pos_in_lane[1], -644.23);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[10].V_m_lat_pos_in_lane[2], 498.98);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[10].V_m_lat_pos_in_lane[3], -736.66);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[10].V_m_lat_pos_in_lane[4], 489.32);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_144;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_144.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[10].V_m_lat_vel_in_lane, 870.73);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_145 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[10].V_m_lat_vel_in_lane, 870.73);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_145;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_145.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[10].V_m_width, 238.07);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_146 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[10].V_m_width, 238.07);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_146;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_146.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[10].V_x_ID, 2774422546);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_147 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[10].V_x_ID, 2774422546);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_147;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_147.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[10].V_x_type, 308704794);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_148 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[10].V_x_type, 308704794);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_148;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_148.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[10].V_x_lane, 162);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_149 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[10].V_x_lane, 162);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_149;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_149.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[10].V_x_is_valid, 118);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_150 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[10].V_x_is_valid, 118);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_150;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_150.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[10].V_x_is_usable, 203);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_151 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[10].V_x_is_usable, 203);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_151;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_151.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[10].V_x_border, 3799726149);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_152 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[10].V_x_border, 3799726149);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_152;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_152.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[10].V_x_lost, 149);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_153 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[10].V_x_lost, 149);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_153;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_153.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[11].V_x_pos.V_m_X, 91.81);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_154 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[11].V_x_pos.V_m_X, 91.81);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_154;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_154.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[11].V_x_pos.V_m_Y, 805.43);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_155 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[11].V_x_pos.V_m_Y, 805.43);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_155;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_155.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[11].V_x_vel.V_m_X, 608.55);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_156 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[11].V_x_vel.V_m_X, 608.55);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_156;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_156.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[11].V_x_vel.V_m_Y, 790.93);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_157 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[11].V_x_vel.V_m_Y, 790.93);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_157;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_157.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[11].V_m_lat_pos_in_lane[0], 467.67);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[11].V_m_lat_pos_in_lane[1], 112.29);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[11].V_m_lat_pos_in_lane[2], 629.19);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[11].V_m_lat_pos_in_lane[3], -226.17);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[11].V_m_lat_pos_in_lane[4], -1.35);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_158 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[11].V_m_lat_pos_in_lane[0], 467.67);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[11].V_m_lat_pos_in_lane[1], 112.29);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[11].V_m_lat_pos_in_lane[2], 629.19);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[11].V_m_lat_pos_in_lane[3], -226.17);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[11].V_m_lat_pos_in_lane[4], -1.35);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_158;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_158.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[11].V_m_lat_vel_in_lane, 418.2);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_159 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[11].V_m_lat_vel_in_lane, 418.2);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_159;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_159.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[11].V_m_width, 188.68);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_160 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[11].V_m_width, 188.68);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_160;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_160.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[11].V_x_ID, 3068518335);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_161 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[11].V_x_ID, 3068518335);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_161;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_161.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[11].V_x_type, 4200523570);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_162 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[11].V_x_type, 4200523570);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_162;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_162.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[11].V_x_lane, 44);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_163 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[11].V_x_lane, 44);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_163;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_163.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[11].V_x_is_valid, 217);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_164 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[11].V_x_is_valid, 217);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_164;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_164.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[11].V_x_is_usable, 49);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_165 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[11].V_x_is_usable, 49);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_165;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_165.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[11].V_x_border, 3903218492);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_166 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[11].V_x_border, 3903218492);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_166;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_166.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[11].V_x_lost, 122);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_167 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[11].V_x_lost, 122);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_167;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_167.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[12].V_x_pos.V_m_X, -909.33);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_168 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[12].V_x_pos.V_m_X, -909.33);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_168;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_168.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[12].V_x_pos.V_m_Y, -61.74);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_169 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[12].V_x_pos.V_m_Y, -61.74);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_169;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_169.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[12].V_x_vel.V_m_X, -562.39);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_170 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[12].V_x_vel.V_m_X, -562.39);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_170;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_170.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[12].V_x_vel.V_m_Y, 948.95);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_171 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[12].V_x_vel.V_m_Y, 948.95);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_171;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_171.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[12].V_m_lat_pos_in_lane[0], 262.14);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[12].V_m_lat_pos_in_lane[1], 921.67);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[12].V_m_lat_pos_in_lane[2], -898.93);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[12].V_m_lat_pos_in_lane[3], -205.02);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[12].V_m_lat_pos_in_lane[4], 647.95);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_172 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[12].V_m_lat_pos_in_lane[0], 262.14);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[12].V_m_lat_pos_in_lane[1], 921.67);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[12].V_m_lat_pos_in_lane[2], -898.93);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[12].V_m_lat_pos_in_lane[3], -205.02);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[12].V_m_lat_pos_in_lane[4], 647.95);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_172;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_172.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[12].V_m_lat_vel_in_lane, -187.4);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_173 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[12].V_m_lat_vel_in_lane, -187.4);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_173;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_173.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[12].V_m_width, 209.13);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_174 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[12].V_m_width, 209.13);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_174;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_174.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[12].V_x_ID, 1326334516);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_175 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[12].V_x_ID, 1326334516);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_175;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_175.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[12].V_x_type, 65630179);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_176 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[12].V_x_type, 65630179);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_176;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_176.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[12].V_x_lane, 22);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_177 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[12].V_x_lane, 22);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_177;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_177.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[12].V_x_is_valid, 96);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_178 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[12].V_x_is_valid, 96);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_178;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_178.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[12].V_x_is_usable, 125);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_179 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[12].V_x_is_usable, 125);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_179;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_179.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[12].V_x_border, 4003145351);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_180 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[12].V_x_border, 4003145351);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_180;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_180.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[12].V_x_lost, 160);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_181 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[12].V_x_lost, 160);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_181;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_181.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[13].V_x_pos.V_m_X, 858.71);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_182 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[13].V_x_pos.V_m_X, 858.71);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_182;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_182.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[13].V_x_pos.V_m_Y, 506.87);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_183 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[13].V_x_pos.V_m_Y, 506.87);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_183;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_183.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[13].V_x_vel.V_m_X, -734.32);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_184 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[13].V_x_vel.V_m_X, -734.32);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_184;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_184.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[13].V_x_vel.V_m_Y, 98.51);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_185 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[13].V_x_vel.V_m_Y, 98.51);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_185;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_185.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[13].V_m_lat_pos_in_lane[0], 692.42);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[13].V_m_lat_pos_in_lane[1], -414.14);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[13].V_m_lat_pos_in_lane[2], -867.6);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[13].V_m_lat_pos_in_lane[3], 284.59);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[13].V_m_lat_pos_in_lane[4], -997.97);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_186 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[13].V_m_lat_pos_in_lane[0], 692.42);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[13].V_m_lat_pos_in_lane[1], -414.14);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[13].V_m_lat_pos_in_lane[2], -867.6);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[13].V_m_lat_pos_in_lane[3], 284.59);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[13].V_m_lat_pos_in_lane[4], -997.97);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_186;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_186.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[13].V_m_lat_vel_in_lane, 235.04);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_187 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[13].V_m_lat_vel_in_lane, 235.04);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_187;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_187.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[13].V_m_width, 233.59);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_188 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[13].V_m_width, 233.59);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_188;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_188.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[13].V_x_ID, 1137220057);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_189 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[13].V_x_ID, 1137220057);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_189;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_189.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[13].V_x_type, 2911121737);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_190 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[13].V_x_type, 2911121737);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_190;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_190.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[13].V_x_lane, 113);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_191 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[13].V_x_lane, 113);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_191;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_191.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[13].V_x_is_valid, 97);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_192 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[13].V_x_is_valid, 97);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_192;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_192.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[13].V_x_is_usable, 37);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_193 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[13].V_x_is_usable, 37);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_193;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_193.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[13].V_x_border, 4059315474);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_194 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[13].V_x_border, 4059315474);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_194;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_194.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[13].V_x_lost, 15);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_195 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[13].V_x_lost, 15);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_195;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_195.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[14].V_x_pos.V_m_X, 218.85);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_196 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[14].V_x_pos.V_m_X, 218.85);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_196;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_196.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[14].V_x_pos.V_m_Y, 350.36);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_197 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[14].V_x_pos.V_m_Y, 350.36);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_197;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_197.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[14].V_x_vel.V_m_X, 841.02);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_198 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[14].V_x_vel.V_m_X, 841.02);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_198;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_198.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[14].V_x_vel.V_m_Y, 575.9);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_199 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[14].V_x_vel.V_m_Y, 575.9);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_199;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_199.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[14].V_m_lat_pos_in_lane[0], -477.4);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[14].V_m_lat_pos_in_lane[1], -326.98);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[14].V_m_lat_pos_in_lane[2], -406.91);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[14].V_m_lat_pos_in_lane[3], 239.35);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[14].V_m_lat_pos_in_lane[4], -739.82);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_200 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[14].V_m_lat_pos_in_lane[0], -477.4);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[14].V_m_lat_pos_in_lane[1], -326.98);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[14].V_m_lat_pos_in_lane[2], -406.91);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[14].V_m_lat_pos_in_lane[3], 239.35);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[14].V_m_lat_pos_in_lane[4], -739.82);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_200;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_200.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[14].V_m_lat_vel_in_lane, 897.02);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_201 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[14].V_m_lat_vel_in_lane, 897.02);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_201;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_201.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[14].V_m_width, -767.86);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_202 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[14].V_m_width, -767.86);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_202;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_202.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[14].V_x_ID, 1311258077);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_203 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[14].V_x_ID, 1311258077);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_203;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_203.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[14].V_x_type, 600915231);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_204 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[14].V_x_type, 600915231);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_204;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_204.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[14].V_x_lane, 28);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_205 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[14].V_x_lane, 28);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_205;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_205.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[14].V_x_is_valid, 74);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_206 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[14].V_x_is_valid, 74);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_206;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_206.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[14].V_x_is_usable, 131);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_207 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[14].V_x_is_usable, 131);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_207;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_207.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[14].V_x_border, 2220465293);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_208 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[14].V_x_border, 2220465293);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_208;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_208.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[14].V_x_lost, 136);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_209 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[14].V_x_lost, 136);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_209;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_209.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[15].V_x_pos.V_m_X, -355.81);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_210 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[15].V_x_pos.V_m_X, -355.81);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_210;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_210.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[15].V_x_pos.V_m_Y, -144.6);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_211 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[15].V_x_pos.V_m_Y, -144.6);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_211;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_211.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[15].V_x_vel.V_m_X, 975.09);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_212 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[15].V_x_vel.V_m_X, 975.09);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_212;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_212.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[15].V_x_vel.V_m_Y, -547.95);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_213 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[15].V_x_vel.V_m_Y, -547.95);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_213;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_213.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[15].V_m_lat_pos_in_lane[0], -421.56);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[15].V_m_lat_pos_in_lane[1], -537.35);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[15].V_m_lat_pos_in_lane[2], 702.9);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[15].V_m_lat_pos_in_lane[3], 957.77);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[15].V_m_lat_pos_in_lane[4], 855.39);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_214 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[15].V_m_lat_pos_in_lane[0], -421.56);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[15].V_m_lat_pos_in_lane[1], -537.35);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[15].V_m_lat_pos_in_lane[2], 702.9);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[15].V_m_lat_pos_in_lane[3], 957.77);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[15].V_m_lat_pos_in_lane[4], 855.39);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_214;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_214.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[15].V_m_lat_vel_in_lane, 439.15);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_215 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[15].V_m_lat_vel_in_lane, 439.15);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_215;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_215.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[15].V_m_width, -353.59);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_216 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[15].V_m_width, -353.59);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_216;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_216.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[15].V_x_ID, 2267430476);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_217 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[15].V_x_ID, 2267430476);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_217;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_217.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[15].V_x_type, 2971236861);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_218 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[15].V_x_type, 2971236861);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_218;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_218.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[15].V_x_lane, 119);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_219 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[15].V_x_lane, 119);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_219;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_219.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[15].V_x_is_valid, 156);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_220 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[15].V_x_is_valid, 156);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_220;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_220.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[15].V_x_is_usable, 91);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_221 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[15].V_x_is_usable, 91);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_221;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_221.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[15].V_x_border, 4053874525);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_222 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[15].V_x_border, 4053874525);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_222;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_222.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[15].V_x_lost, 246);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_223 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[15].V_x_lost, 246);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_223;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_223.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[16].V_x_pos.V_m_X, -424.75);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_224 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[16].V_x_pos.V_m_X, -424.75);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_224;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_224.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[16].V_x_pos.V_m_Y, 733.13);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_225 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[16].V_x_pos.V_m_Y, 733.13);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_225;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_225.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[16].V_x_vel.V_m_X, 874.54);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_226 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[16].V_x_vel.V_m_X, 874.54);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_226;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_226.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[16].V_x_vel.V_m_Y, 532.35);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_227 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[16].V_x_vel.V_m_Y, 532.35);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_227;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_227.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[16].V_m_lat_pos_in_lane[0], 457.42);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[16].V_m_lat_pos_in_lane[1], -538.14);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[16].V_m_lat_pos_in_lane[2], 185.05);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[16].V_m_lat_pos_in_lane[3], -294.17);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[16].V_m_lat_pos_in_lane[4], 22.71);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_228 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[16].V_m_lat_pos_in_lane[0], 457.42);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[16].V_m_lat_pos_in_lane[1], -538.14);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[16].V_m_lat_pos_in_lane[2], 185.05);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[16].V_m_lat_pos_in_lane[3], -294.17);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[16].V_m_lat_pos_in_lane[4], 22.71);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_228;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_228.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[16].V_m_lat_vel_in_lane, 457.38);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_229 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[16].V_m_lat_vel_in_lane, 457.38);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_229;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_229.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[16].V_m_width, -744.24);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_230 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[16].V_m_width, -744.24);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_230;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_230.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[16].V_x_ID, 1608847648);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_231 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[16].V_x_ID, 1608847648);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_231;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_231.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[16].V_x_type, 2439764867);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_232 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[16].V_x_type, 2439764867);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_232;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_232.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[16].V_x_lane, 38);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_233 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[16].V_x_lane, 38);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_233;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_233.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[16].V_x_is_valid, 105);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_234 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[16].V_x_is_valid, 105);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_234;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_234.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[16].V_x_is_usable, 210);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_235 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[16].V_x_is_usable, 210);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_235;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_235.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[16].V_x_border, 1432355815);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_236 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[16].V_x_border, 1432355815);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_236;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_236.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[16].V_x_lost, 192);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_237 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[16].V_x_lost, 192);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_237;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_237.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[17].V_x_pos.V_m_X, -91.59);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_238 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[17].V_x_pos.V_m_X, -91.59);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_238;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_238.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[17].V_x_pos.V_m_Y, -473.64);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_239 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[17].V_x_pos.V_m_Y, -473.64);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_239;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_239.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[17].V_x_vel.V_m_X, 796.58);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_240 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[17].V_x_vel.V_m_X, 796.58);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_240;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_240.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[17].V_x_vel.V_m_Y, -373.54);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_241 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[17].V_x_vel.V_m_Y, -373.54);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_241;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_241.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[17].V_m_lat_pos_in_lane[0], -968.5);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[17].V_m_lat_pos_in_lane[1], 607.72);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[17].V_m_lat_pos_in_lane[2], 199.25);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[17].V_m_lat_pos_in_lane[3], 652.72);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[17].V_m_lat_pos_in_lane[4], -827.33);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_242 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[17].V_m_lat_pos_in_lane[0], -968.5);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[17].V_m_lat_pos_in_lane[1], 607.72);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[17].V_m_lat_pos_in_lane[2], 199.25);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[17].V_m_lat_pos_in_lane[3], 652.72);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[17].V_m_lat_pos_in_lane[4], -827.33);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_242;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_242.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[17].V_m_lat_vel_in_lane, 630.36);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_243 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[17].V_m_lat_vel_in_lane, 630.36);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_243;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_243.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[17].V_m_width, -541.68);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_244 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[17].V_m_width, -541.68);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_244;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_244.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[17].V_x_ID, 1255335751);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_245 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[17].V_x_ID, 1255335751);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_245;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_245.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[17].V_x_type, 1346798698);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_246 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[17].V_x_type, 1346798698);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_246;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_246.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[17].V_x_lane, 183);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_247 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[17].V_x_lane, 183);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_247;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_247.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[17].V_x_is_valid, 138);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_248 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[17].V_x_is_valid, 138);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_248;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_248.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[17].V_x_is_usable, 34);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_249 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[17].V_x_is_usable, 34);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_249;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_249.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[17].V_x_border, 4155148245);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_250 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[17].V_x_border, 4155148245);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_250;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_250.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[17].V_x_lost, 56);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_251 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[17].V_x_lost, 56);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_251;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_251.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[18].V_x_pos.V_m_X, 533.62);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_252 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[18].V_x_pos.V_m_X, 533.62);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_252;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_252.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[18].V_x_pos.V_m_Y, 258.92);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_253 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[18].V_x_pos.V_m_Y, 258.92);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_253;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_253.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[18].V_x_vel.V_m_X, -383.54);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_254 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[18].V_x_vel.V_m_X, -383.54);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_254;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_254.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[18].V_x_vel.V_m_Y, 976.56);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_255 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[18].V_x_vel.V_m_Y, 976.56);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_255;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_255.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[18].V_m_lat_pos_in_lane[0], -14.03);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[18].V_m_lat_pos_in_lane[1], 857.95);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[18].V_m_lat_pos_in_lane[2], 380.53);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[18].V_m_lat_pos_in_lane[3], -4.04);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[18].V_m_lat_pos_in_lane[4], 595.21);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_256 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[18].V_m_lat_pos_in_lane[0], -14.03);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[18].V_m_lat_pos_in_lane[1], 857.95);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[18].V_m_lat_pos_in_lane[2], 380.53);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[18].V_m_lat_pos_in_lane[3], -4.04);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[18].V_m_lat_pos_in_lane[4], 595.21);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_256;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_256.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[18].V_m_lat_vel_in_lane, -12.45);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_257 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[18].V_m_lat_vel_in_lane, -12.45);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_257;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_257.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[18].V_m_width, -988.89);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_258 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[18].V_m_width, -988.89);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_258;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_258.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[18].V_x_ID, 789172096);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_259 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[18].V_x_ID, 789172096);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_259;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_259.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[18].V_x_type, 2995668706);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_260 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[18].V_x_type, 2995668706);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_260;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_260.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[18].V_x_lane, 245);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_261 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[18].V_x_lane, 245);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_261;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_261.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[18].V_x_is_valid, 103);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_262 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[18].V_x_is_valid, 103);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_262;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_262.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[18].V_x_is_usable, 146);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_263 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[18].V_x_is_usable, 146);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_263;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_263.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[18].V_x_border, 3662852370);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_264 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[18].V_x_border, 3662852370);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_264;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_264.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[18].V_x_lost, 34);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_265 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[18].V_x_lost, 34);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_265;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_265.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[19].V_x_pos.V_m_X, 944.82);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_266 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[19].V_x_pos.V_m_X, 944.82);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_266;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_266.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[19].V_x_pos.V_m_Y, 522.05);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_267 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[19].V_x_pos.V_m_Y, 522.05);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_267;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_267.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[19].V_x_vel.V_m_X, 312.65);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_268 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[19].V_x_vel.V_m_X, 312.65);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_268;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_268.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[19].V_x_vel.V_m_Y, -875.81);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_269 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[19].V_x_vel.V_m_Y, -875.81);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_269;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_269.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[19].V_m_lat_pos_in_lane[0], 867.03);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[19].V_m_lat_pos_in_lane[1], 624.72);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[19].V_m_lat_pos_in_lane[2], -531.36);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[19].V_m_lat_pos_in_lane[3], 191.06);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[19].V_m_lat_pos_in_lane[4], -543.83);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_270 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[19].V_m_lat_pos_in_lane[0], 867.03);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[19].V_m_lat_pos_in_lane[1], 624.72);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[19].V_m_lat_pos_in_lane[2], -531.36);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[19].V_m_lat_pos_in_lane[3], 191.06);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[19].V_m_lat_pos_in_lane[4], -543.83);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_270;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_270.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[19].V_m_lat_vel_in_lane, 83.71);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_271 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[19].V_m_lat_vel_in_lane, 83.71);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_271;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_271.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[19].V_m_width, -348.3);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_272 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[19].V_m_width, -348.3);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_272;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_272.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[19].V_x_ID, 3340443344);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_273 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[19].V_x_ID, 3340443344);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_273;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_273.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[19].V_x_type, 3966528718);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_274 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[19].V_x_type, 3966528718);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_274;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_274.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[19].V_x_lane, 78);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_275 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[19].V_x_lane, 78);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_275;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_275.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[19].V_x_is_valid, 139);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_276 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[19].V_x_is_valid, 139);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_276;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_276.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[19].V_x_is_usable, 214);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_277 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[19].V_x_is_usable, 214);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_277;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_277.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[19].V_x_border, 2256746837);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_278 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[19].V_x_border, 2256746837);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_278;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_278.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[19].V_x_lost, 54);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_279 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[19].V_x_lost, 54);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_279;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_279.verify();

    /* V_x_sorted_side_radar_obj_t */
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[0].V_x_pos.V_m_X, 577.3);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_0 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[0].V_x_pos.V_m_X, 577.3);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_0;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_0.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[0].V_x_pos.V_m_Y, 327.83);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_1 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[0].V_x_pos.V_m_Y, 327.83);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_1;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_1.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[0].V_x_vel.V_m_X, 940.28);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_2 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[0].V_x_vel.V_m_X, 940.28);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_2;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_2.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[0].V_x_vel.V_m_Y, 890.38);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_3 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[0].V_x_vel.V_m_Y, 890.38);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_3;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_3.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[0].V_m_lat_pos_in_lane[0], 551.99);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[0].V_m_lat_pos_in_lane[1], -711.92);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[0].V_m_lat_pos_in_lane[2], -954.01);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[0].V_m_lat_pos_in_lane[3], -376.62);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[0].V_m_lat_pos_in_lane[4], -720.91);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_4 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[0].V_m_lat_pos_in_lane[0], 551.99);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[0].V_m_lat_pos_in_lane[1], -711.92);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[0].V_m_lat_pos_in_lane[2], -954.01);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[0].V_m_lat_pos_in_lane[3], -376.62);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[0].V_m_lat_pos_in_lane[4], -720.91);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_4;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_4.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[0].V_m_lat_vel_in_lane, -127.49);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_5 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[0].V_m_lat_vel_in_lane, -127.49);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_5;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_5.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[0].V_m_width, 833.56);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_6 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[0].V_m_width, 833.56);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_6;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_6.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[0].V_x_ID, 3076842694);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_7 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[0].V_x_ID, 3076842694);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_7;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_7.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[0].V_x_type, 137377335);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_8 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[0].V_x_type, 137377335);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_8;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_8.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[0].V_x_lane, 104);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_9 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[0].V_x_lane, 104);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_9;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_9.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[0].V_x_is_valid, 74);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_10 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[0].V_x_is_valid, 74);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_10;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_10.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[0].V_x_is_usable, 56);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_11 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[0].V_x_is_usable, 56);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_11;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_11.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[0].V_x_border, 955726533);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_12 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[0].V_x_border, 955726533);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_12;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_12.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[0].V_x_lost, 80);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_13 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[0].V_x_lost, 80);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_13;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_13.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[1].V_x_pos.V_m_X, -435.73);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_14 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[1].V_x_pos.V_m_X, -435.73);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_14;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_14.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[1].V_x_pos.V_m_Y, -87.34);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_15 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[1].V_x_pos.V_m_Y, -87.34);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_15;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_15.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[1].V_x_vel.V_m_X, -90.54);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_16 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[1].V_x_vel.V_m_X, -90.54);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_16;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_16.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[1].V_x_vel.V_m_Y, 0.47);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_17 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[1].V_x_vel.V_m_Y, 0.47);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_17;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_17.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[1].V_m_lat_pos_in_lane[0], -247.5);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[1].V_m_lat_pos_in_lane[1], -428.77);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[1].V_m_lat_pos_in_lane[2], 150.93);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[1].V_m_lat_pos_in_lane[3], 730.26);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[1].V_m_lat_pos_in_lane[4], -300.42);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_18 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[1].V_m_lat_pos_in_lane[0], -247.5);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[1].V_m_lat_pos_in_lane[1], -428.77);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[1].V_m_lat_pos_in_lane[2], 150.93);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[1].V_m_lat_pos_in_lane[3], 730.26);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[1].V_m_lat_pos_in_lane[4], -300.42);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_18;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_18.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[1].V_m_lat_vel_in_lane, 256.65);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_19 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[1].V_m_lat_vel_in_lane, 256.65);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_19;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_19.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[1].V_m_width, -934.19);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_20 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[1].V_m_width, -934.19);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_20;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_20.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[1].V_x_ID, 2804976061);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_21 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[1].V_x_ID, 2804976061);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_21;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_21.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[1].V_x_type, 3133549493);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_22 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[1].V_x_type, 3133549493);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_22;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_22.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[1].V_x_lane, 49);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_23 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[1].V_x_lane, 49);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_23;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_23.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[1].V_x_is_valid, 31);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_24 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[1].V_x_is_valid, 31);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_24;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_24.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[1].V_x_is_usable, 244);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_25 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[1].V_x_is_usable, 244);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_25;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_25.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[1].V_x_border, 1227702945);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_26 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[1].V_x_border, 1227702945);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_26;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_26.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[1].V_x_lost, 176);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_27 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[1].V_x_lost, 176);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_27;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_27.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[2].V_x_pos.V_m_X, -625);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_28 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[2].V_x_pos.V_m_X, -625);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_28;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_28.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[2].V_x_pos.V_m_Y, -500.07);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_29 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[2].V_x_pos.V_m_Y, -500.07);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_29;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_29.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[2].V_x_vel.V_m_X, 448.99);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_30 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[2].V_x_vel.V_m_X, 448.99);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_30;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_30.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[2].V_x_vel.V_m_Y, -114.18);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_31 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[2].V_x_vel.V_m_Y, -114.18);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_31;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_31.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[2].V_m_lat_pos_in_lane[0], -404.7);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[2].V_m_lat_pos_in_lane[1], 576.46);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[2].V_m_lat_pos_in_lane[2], 69.95);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[2].V_m_lat_pos_in_lane[3], -341.86);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[2].V_m_lat_pos_in_lane[4], -567.97);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_32 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[2].V_m_lat_pos_in_lane[0], -404.7);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[2].V_m_lat_pos_in_lane[1], 576.46);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[2].V_m_lat_pos_in_lane[2], 69.95);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[2].V_m_lat_pos_in_lane[3], -341.86);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[2].V_m_lat_pos_in_lane[4], -567.97);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_32;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_32.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[2].V_m_lat_vel_in_lane, 609.41);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_33 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[2].V_m_lat_vel_in_lane, 609.41);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_33;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_33.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[2].V_m_width, 747.37);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_34 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[2].V_m_width, 747.37);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_34;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_34.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[2].V_x_ID, 358662089);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_35 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[2].V_x_ID, 358662089);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_35;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_35.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[2].V_x_type, 3736194410);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_36 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[2].V_x_type, 3736194410);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_36;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_36.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[2].V_x_lane, 160);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_37 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[2].V_x_lane, 160);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_37;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_37.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[2].V_x_is_valid, 138);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_38 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[2].V_x_is_valid, 138);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_38;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_38.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[2].V_x_is_usable, 56);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_39 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[2].V_x_is_usable, 56);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_39;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_39.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[2].V_x_border, 1287167442);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_40 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[2].V_x_border, 1287167442);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_40;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_40.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[2].V_x_lost, 87);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_41 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[2].V_x_lost, 87);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_41;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_41.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[3].V_x_pos.V_m_X, -650.18);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_42 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[3].V_x_pos.V_m_X, -650.18);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_42;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_42.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[3].V_x_pos.V_m_Y, 746.25);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_43 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[3].V_x_pos.V_m_Y, 746.25);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_43;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_43.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[3].V_x_vel.V_m_X, 798);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_44 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[3].V_x_vel.V_m_X, 798);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_44;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_44.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[3].V_x_vel.V_m_Y, 957.24);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_45 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[3].V_x_vel.V_m_Y, 957.24);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_45;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_45.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[3].V_m_lat_pos_in_lane[0], -800.12);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[3].V_m_lat_pos_in_lane[1], -191.83);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[3].V_m_lat_pos_in_lane[2], -109.6);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[3].V_m_lat_pos_in_lane[3], 848.95);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[3].V_m_lat_pos_in_lane[4], -508.2);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_46 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[3].V_m_lat_pos_in_lane[0], -800.12);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[3].V_m_lat_pos_in_lane[1], -191.83);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[3].V_m_lat_pos_in_lane[2], -109.6);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[3].V_m_lat_pos_in_lane[3], 848.95);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[3].V_m_lat_pos_in_lane[4], -508.2);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_46;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_46.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[3].V_m_lat_vel_in_lane, 133.12);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_47 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[3].V_m_lat_vel_in_lane, 133.12);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_47;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_47.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[3].V_m_width, -455.69);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_48 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[3].V_m_width, -455.69);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_48;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_48.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[3].V_x_ID, 1568916519);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_49 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[3].V_x_ID, 1568916519);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_49;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_49.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[3].V_x_type, 592888121);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_50 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[3].V_x_type, 592888121);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_50;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_50.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[3].V_x_lane, 177);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_51 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[3].V_x_lane, 177);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_51;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_51.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[3].V_x_is_valid, 182);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_52 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[3].V_x_is_valid, 182);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_52;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_52.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[3].V_x_is_usable, 91);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_53 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[3].V_x_is_usable, 91);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_53;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_53.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[3].V_x_border, 450513329);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_54 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[3].V_x_border, 450513329);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_54;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_54.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[3].V_x_lost, 33);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_55 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[3].V_x_lost, 33);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_55;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_55.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[4].V_x_pos.V_m_X, 405.99);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_56 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[4].V_x_pos.V_m_X, 405.99);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_56;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_56.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[4].V_x_pos.V_m_Y, -633.43);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_57 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[4].V_x_pos.V_m_Y, -633.43);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_57;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_57.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[4].V_x_vel.V_m_X, -755.53);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_58 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[4].V_x_vel.V_m_X, -755.53);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_58;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_58.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[4].V_x_vel.V_m_Y, 860.26);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_59 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[4].V_x_vel.V_m_Y, 860.26);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_59;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_59.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[4].V_m_lat_pos_in_lane[0], -211.54);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[4].V_m_lat_pos_in_lane[1], 832.14);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[4].V_m_lat_pos_in_lane[2], 574.83);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[4].V_m_lat_pos_in_lane[3], -979.05);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[4].V_m_lat_pos_in_lane[4], 890.57);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_60 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[4].V_m_lat_pos_in_lane[0], -211.54);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[4].V_m_lat_pos_in_lane[1], 832.14);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[4].V_m_lat_pos_in_lane[2], 574.83);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[4].V_m_lat_pos_in_lane[3], -979.05);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[4].V_m_lat_pos_in_lane[4], 890.57);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_60;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_60.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[4].V_m_lat_vel_in_lane, 838.96);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_61 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[4].V_m_lat_vel_in_lane, 838.96);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_61;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_61.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[4].V_m_width, -693.67);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_62 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[4].V_m_width, -693.67);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_62;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_62.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[4].V_x_ID, 302413288);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_63 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[4].V_x_ID, 302413288);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_63;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_63.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[4].V_x_type, 2079506148);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_64 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[4].V_x_type, 2079506148);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_64;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_64.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[4].V_x_lane, 151);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_65 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[4].V_x_lane, 151);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_65;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_65.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[4].V_x_is_valid, 216);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_66 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[4].V_x_is_valid, 216);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_66;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_66.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[4].V_x_is_usable, 135);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_67 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[4].V_x_is_usable, 135);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_67;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_67.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[4].V_x_border, 4124703158);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_68 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[4].V_x_border, 4124703158);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_68;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_68.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[4].V_x_lost, 18);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_69 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[4].V_x_lost, 18);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_69;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_69.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[5].V_x_pos.V_m_X, -953.68);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_70 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[5].V_x_pos.V_m_X, -953.68);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_70;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_70.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[5].V_x_pos.V_m_Y, 345.42);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_71 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[5].V_x_pos.V_m_Y, 345.42);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_71;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_71.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[5].V_x_vel.V_m_X, 569.6);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_72 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[5].V_x_vel.V_m_X, 569.6);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_72;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_72.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[5].V_x_vel.V_m_Y, -300.09);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_73 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[5].V_x_vel.V_m_Y, -300.09);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_73;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_73.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[5].V_m_lat_pos_in_lane[0], 958.35);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[5].V_m_lat_pos_in_lane[1], 722.06);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[5].V_m_lat_pos_in_lane[2], 434.26);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[5].V_m_lat_pos_in_lane[3], -633.41);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[5].V_m_lat_pos_in_lane[4], 93.54);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_74 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[5].V_m_lat_pos_in_lane[0], 958.35);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[5].V_m_lat_pos_in_lane[1], 722.06);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[5].V_m_lat_pos_in_lane[2], 434.26);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[5].V_m_lat_pos_in_lane[3], -633.41);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[5].V_m_lat_pos_in_lane[4], 93.54);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_74;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_74.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[5].V_m_lat_vel_in_lane, -879);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_75 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[5].V_m_lat_vel_in_lane, -879);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_75;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_75.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[5].V_m_width, 334.34);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_76 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[5].V_m_width, 334.34);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_76;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_76.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[5].V_x_ID, 3525510879);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_77 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[5].V_x_ID, 3525510879);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_77;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_77.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[5].V_x_type, 1458520396);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_78 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[5].V_x_type, 1458520396);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_78;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_78.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[5].V_x_lane, 13);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_79 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[5].V_x_lane, 13);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_79;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_79.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[5].V_x_is_valid, 62);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_80 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[5].V_x_is_valid, 62);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_80;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_80.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[5].V_x_is_usable, 175);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_81 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[5].V_x_is_usable, 175);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_81;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_81.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[5].V_x_border, 2263215074);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_82 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[5].V_x_border, 2263215074);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_82;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_82.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[5].V_x_lost, 9);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_83 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[5].V_x_lost, 9);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_83;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_83.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[6].V_x_pos.V_m_X, -508.29);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_84 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[6].V_x_pos.V_m_X, -508.29);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_84;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_84.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[6].V_x_pos.V_m_Y, -781.86);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_85 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[6].V_x_pos.V_m_Y, -781.86);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_85;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_85.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[6].V_x_vel.V_m_X, -286.15);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_86 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[6].V_x_vel.V_m_X, -286.15);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_86;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_86.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[6].V_x_vel.V_m_Y, -853.7);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_87 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[6].V_x_vel.V_m_Y, -853.7);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_87;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_87.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[6].V_m_lat_pos_in_lane[0], -622.02);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[6].V_m_lat_pos_in_lane[1], -871.47);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[6].V_m_lat_pos_in_lane[2], -365.61);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[6].V_m_lat_pos_in_lane[3], -777.94);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[6].V_m_lat_pos_in_lane[4], 46.0);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_88 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[6].V_m_lat_pos_in_lane[0], -622.02);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[6].V_m_lat_pos_in_lane[1], -871.47);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[6].V_m_lat_pos_in_lane[2], -365.61);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[6].V_m_lat_pos_in_lane[3], -777.94);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[6].V_m_lat_pos_in_lane[4], 46.0);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_88;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_88.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[6].V_m_lat_vel_in_lane, 4.01);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_89 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[6].V_m_lat_vel_in_lane, 4.01);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_89;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_89.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[6].V_m_width, 98.7);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_90 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[6].V_m_width, 98.7);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_90;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_90.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[6].V_x_ID, 4143018642);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_91 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[6].V_x_ID, 4143018642);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_91;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_91.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[6].V_x_type, 3452097891);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_92 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[6].V_x_type, 3452097891);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_92;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_92.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[6].V_x_lane, 99);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_93 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[6].V_x_lane, 99);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_93;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_93.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[6].V_x_is_valid, 106);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_94 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[6].V_x_is_valid, 106);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_94;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_94.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[6].V_x_is_usable, 129);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_95 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[6].V_x_is_usable, 129);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_95;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_95.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[6].V_x_border, 3755182923);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_96 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[6].V_x_border, 3755182923);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_96;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_96.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[6].V_x_lost, 8);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_97 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[6].V_x_lost, 8);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_97;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_97.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[7].V_x_pos.V_m_X, 94.61);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_98 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[7].V_x_pos.V_m_X, 94.61);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_98;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_98.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[7].V_x_pos.V_m_Y, -267.31);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_99 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[7].V_x_pos.V_m_Y, -267.31);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_99;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_99.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[7].V_x_vel.V_m_X, 856.56);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_100 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[7].V_x_vel.V_m_X, 856.56);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_100;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_100.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[7].V_x_vel.V_m_Y, 288.58);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_101 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[7].V_x_vel.V_m_Y, 288.58);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_101;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_101.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[7].V_m_lat_pos_in_lane[0], 812.35);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[7].V_m_lat_pos_in_lane[1], -316.18);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[7].V_m_lat_pos_in_lane[2], -311.01);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[7].V_m_lat_pos_in_lane[3], 398.41);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[7].V_m_lat_pos_in_lane[4], -990.34);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_102 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[7].V_m_lat_pos_in_lane[0], 812.35);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[7].V_m_lat_pos_in_lane[1], -316.18);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[7].V_m_lat_pos_in_lane[2], -311.01);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[7].V_m_lat_pos_in_lane[3], 398.41);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[7].V_m_lat_pos_in_lane[4], -990.34);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_102;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_102.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[7].V_m_lat_vel_in_lane, 145.19);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_103 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[7].V_m_lat_vel_in_lane, 145.19);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_103;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_103.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[7].V_m_width, 254.58);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_104 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[7].V_m_width, 254.58);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_104;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_104.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[7].V_x_ID, 3806867802);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_105 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[7].V_x_ID, 3806867802);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_105;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_105.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[7].V_x_type, 523909888);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_106 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[7].V_x_type, 523909888);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_106;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_106.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[7].V_x_lane, 169);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_107 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[7].V_x_lane, 169);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_107;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_107.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[7].V_x_is_valid, 85);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_108 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[7].V_x_is_valid, 85);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_108;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_108.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[7].V_x_is_usable, 219);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_109 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[7].V_x_is_usable, 219);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_109;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_109.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[7].V_x_border, 3183469072);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_110 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[7].V_x_border, 3183469072);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_110;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_110.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[7].V_x_lost, 110);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_111 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[7].V_x_lost, 110);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_111;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_111.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[8].V_x_pos.V_m_X, 317.45);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_112 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[8].V_x_pos.V_m_X, 317.45);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_112;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_112.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[8].V_x_pos.V_m_Y, 499.62);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_113 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[8].V_x_pos.V_m_Y, 499.62);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_113;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_113.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[8].V_x_vel.V_m_X, 357.83);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_114 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[8].V_x_vel.V_m_X, 357.83);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_114;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_114.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[8].V_x_vel.V_m_Y, 954.25);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_115 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[8].V_x_vel.V_m_Y, 954.25);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_115;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_115.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[8].V_m_lat_pos_in_lane[0], -619.06);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[8].V_m_lat_pos_in_lane[1], 742.81);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[8].V_m_lat_pos_in_lane[2], -414.04);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[8].V_m_lat_pos_in_lane[3], 629.9);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[8].V_m_lat_pos_in_lane[4], 93.82);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_116 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[8].V_m_lat_pos_in_lane[0], -619.06);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[8].V_m_lat_pos_in_lane[1], 742.81);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[8].V_m_lat_pos_in_lane[2], -414.04);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[8].V_m_lat_pos_in_lane[3], 629.9);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[8].V_m_lat_pos_in_lane[4], 93.82);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_116;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_116.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[8].V_m_lat_vel_in_lane, 773.27);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_117 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[8].V_m_lat_vel_in_lane, 773.27);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_117;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_117.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[8].V_m_width, 308.21);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_118 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[8].V_m_width, 308.21);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_118;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_118.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[8].V_x_ID, 1556933925);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_119 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[8].V_x_ID, 1556933925);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_119;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_119.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[8].V_x_type, 3180793196);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_120 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[8].V_x_type, 3180793196);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_120;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_120.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[8].V_x_lane, 193);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_121 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[8].V_x_lane, 193);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_121;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_121.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[8].V_x_is_valid, 199);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_122 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[8].V_x_is_valid, 199);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_122;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_122.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[8].V_x_is_usable, 81);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_123 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[8].V_x_is_usable, 81);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_123;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_123.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[8].V_x_border, 3363212329);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_124 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[8].V_x_border, 3363212329);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_124;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_124.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[8].V_x_lost, 120);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_125 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[8].V_x_lost, 120);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_125;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_125.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[9].V_x_pos.V_m_X, -98.23);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_126 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[9].V_x_pos.V_m_X, -98.23);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_126;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_126.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[9].V_x_pos.V_m_Y, -746.78);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_127 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[9].V_x_pos.V_m_Y, -746.78);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_127;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_127.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[9].V_x_vel.V_m_X, -112.54);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_128 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[9].V_x_vel.V_m_X, -112.54);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_128;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_128.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[9].V_x_vel.V_m_Y, -522.44);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_129 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[9].V_x_vel.V_m_Y, -522.44);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_129;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_129.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[9].V_m_lat_pos_in_lane[0], 110.62);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[9].V_m_lat_pos_in_lane[1], -453.87);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[9].V_m_lat_pos_in_lane[2], -29.62);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[9].V_m_lat_pos_in_lane[3], -613.25);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[9].V_m_lat_pos_in_lane[4], -373.25);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_130 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[9].V_m_lat_pos_in_lane[0], 110.62);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[9].V_m_lat_pos_in_lane[1], -453.87);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[9].V_m_lat_pos_in_lane[2], -29.62);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[9].V_m_lat_pos_in_lane[3], -613.25);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[9].V_m_lat_pos_in_lane[4], -373.25);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_130;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_130.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[9].V_m_lat_vel_in_lane, 327.56);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_131 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[9].V_m_lat_vel_in_lane, 327.56);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_131;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_131.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[9].V_m_width, 719.13);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_132 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[9].V_m_width, 719.13);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_132;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_132.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[9].V_x_ID, 3011647360);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_133 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[9].V_x_ID, 3011647360);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_133;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_133.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[9].V_x_type, 2232237108);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_134 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[9].V_x_type, 2232237108);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_134;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_134.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[9].V_x_lane, 19);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_135 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[9].V_x_lane, 19);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_135;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_135.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[9].V_x_is_valid, 210);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_136 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[9].V_x_is_valid, 210);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_136;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_136.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[9].V_x_is_usable, 14);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_137 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[9].V_x_is_usable, 14);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_137;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_137.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[9].V_x_border, 389528250);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_138 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[9].V_x_border, 389528250);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_138;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_138.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[9].V_x_lost, 82);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_139 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[9].V_x_lost, 82);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_139;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_139.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[10].V_x_pos.V_m_X, 554.79);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_140 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[10].V_x_pos.V_m_X, 554.79);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_140;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_140.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[10].V_x_pos.V_m_Y, -916.12);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_141 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[10].V_x_pos.V_m_Y, -916.12);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_141;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_141.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[10].V_x_vel.V_m_X, -317.6);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_142 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[10].V_x_vel.V_m_X, -317.6);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_142;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_142.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[10].V_x_vel.V_m_Y, -335.31);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_143 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[10].V_x_vel.V_m_Y, -335.31);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_143;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_143.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[10].V_m_lat_pos_in_lane[0], -907.19);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[10].V_m_lat_pos_in_lane[1], -993.89);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[10].V_m_lat_pos_in_lane[2], -715.21);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[10].V_m_lat_pos_in_lane[3], -829.21);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[10].V_m_lat_pos_in_lane[4], 781.44);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_144 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[10].V_m_lat_pos_in_lane[0], -907.19);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[10].V_m_lat_pos_in_lane[1], -993.89);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[10].V_m_lat_pos_in_lane[2], -715.21);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[10].V_m_lat_pos_in_lane[3], -829.21);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[10].V_m_lat_pos_in_lane[4], 781.44);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_144;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_144.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[10].V_m_lat_vel_in_lane, -894.47);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_145 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[10].V_m_lat_vel_in_lane, -894.47);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_145;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_145.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[10].V_m_width, 657.33);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_146 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[10].V_m_width, 657.33);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_146;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_146.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[10].V_x_ID, 4292354725);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_147 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[10].V_x_ID, 4292354725);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_147;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_147.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[10].V_x_type, 1760158730);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_148 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[10].V_x_type, 1760158730);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_148;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_148.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[10].V_x_lane, 79);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_149 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[10].V_x_lane, 79);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_149;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_149.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[10].V_x_is_valid, 134);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_150 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[10].V_x_is_valid, 134);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_150;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_150.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[10].V_x_is_usable, 29);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_151 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[10].V_x_is_usable, 29);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_151;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_151.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[10].V_x_border, 1857316698);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_152 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[10].V_x_border, 1857316698);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_152;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_152.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[10].V_x_lost, 215);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_153 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[10].V_x_lost, 215);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_153;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_153.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[11].V_x_pos.V_m_X, -257.6);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_154 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[11].V_x_pos.V_m_X, -257.6);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_154;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_154.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[11].V_x_pos.V_m_Y, -54.13);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_155 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[11].V_x_pos.V_m_Y, -54.13);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_155;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_155.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[11].V_x_vel.V_m_X, 594.61);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_156 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[11].V_x_vel.V_m_X, 594.61);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_156;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_156.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[11].V_x_vel.V_m_Y, 792.68);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_157 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[11].V_x_vel.V_m_Y, 792.68);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_157;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_157.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[11].V_m_lat_pos_in_lane[0], 228.0);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[11].V_m_lat_pos_in_lane[1], 760.83);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[11].V_m_lat_pos_in_lane[2], 497.06);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[11].V_m_lat_pos_in_lane[3], 18.34);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[11].V_m_lat_pos_in_lane[4], 42.59);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_158 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[11].V_m_lat_pos_in_lane[0], 228.0);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[11].V_m_lat_pos_in_lane[1], 760.83);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[11].V_m_lat_pos_in_lane[2], 497.06);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[11].V_m_lat_pos_in_lane[3], 18.34);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[11].V_m_lat_pos_in_lane[4], 42.59);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_158;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_158.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[11].V_m_lat_vel_in_lane, -869.47);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_159 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[11].V_m_lat_vel_in_lane, -869.47);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_159;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_159.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[11].V_m_width, 550.52);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_160 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[11].V_m_width, 550.52);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_160;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_160.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[11].V_x_ID, 3015267149);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_161 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[11].V_x_ID, 3015267149);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_161;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_161.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[11].V_x_type, 736500711);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_162 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[11].V_x_type, 736500711);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_162;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_162.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[11].V_x_lane, 124);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_163 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[11].V_x_lane, 124);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_163;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_163.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[11].V_x_is_valid, 209);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_164 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[11].V_x_is_valid, 209);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_164;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_164.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[11].V_x_is_usable, 116);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_165 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[11].V_x_is_usable, 116);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_165;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_165.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[11].V_x_border, 1746915199);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_166 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[11].V_x_border, 1746915199);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_166;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_166.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[11].V_x_lost, 119);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_167 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[11].V_x_lost, 119);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_167;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_167.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[12].V_x_pos.V_m_X, 739.78);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_168 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[12].V_x_pos.V_m_X, 739.78);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_168;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_168.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[12].V_x_pos.V_m_Y, 973.17);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_169 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[12].V_x_pos.V_m_Y, 973.17);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_169;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_169.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[12].V_x_vel.V_m_X, 595.72);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_170 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[12].V_x_vel.V_m_X, 595.72);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_170;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_170.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[12].V_x_vel.V_m_Y, 630.93);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_171 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[12].V_x_vel.V_m_Y, 630.93);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_171;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_171.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[12].V_m_lat_pos_in_lane[0], -209.22);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[12].V_m_lat_pos_in_lane[1], -309.11);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[12].V_m_lat_pos_in_lane[2], -882.33);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[12].V_m_lat_pos_in_lane[3], 971.25);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[12].V_m_lat_pos_in_lane[4], 798.75);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_172 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[12].V_m_lat_pos_in_lane[0], -209.22);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[12].V_m_lat_pos_in_lane[1], -309.11);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[12].V_m_lat_pos_in_lane[2], -882.33);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[12].V_m_lat_pos_in_lane[3], 971.25);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[12].V_m_lat_pos_in_lane[4], 798.75);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_172;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_172.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[12].V_m_lat_vel_in_lane, 973.51);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_173 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[12].V_m_lat_vel_in_lane, 973.51);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_173;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_173.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[12].V_m_width, -643.15);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_174 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[12].V_m_width, -643.15);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_174;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_174.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[12].V_x_ID, 2108169569);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_175 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[12].V_x_ID, 2108169569);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_175;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_175.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[12].V_x_type, 2129805354);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_176 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[12].V_x_type, 2129805354);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_176;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_176.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[12].V_x_lane, 142);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_177 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[12].V_x_lane, 142);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_177;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_177.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[12].V_x_is_valid, 215);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_178 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[12].V_x_is_valid, 215);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_178;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_178.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[12].V_x_is_usable, 126);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_179 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[12].V_x_is_usable, 126);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_179;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_179.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[12].V_x_border, 1266021968);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_180 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[12].V_x_border, 1266021968);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_180;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_180.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[12].V_x_lost, 204);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_181 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[12].V_x_lost, 204);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_181;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_181.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[13].V_x_pos.V_m_X, -400.88);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_182 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[13].V_x_pos.V_m_X, -400.88);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_182;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_182.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[13].V_x_pos.V_m_Y, 250.2);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_183 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[13].V_x_pos.V_m_Y, 250.2);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_183;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_183.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[13].V_x_vel.V_m_X, 734.83);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_184 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[13].V_x_vel.V_m_X, 734.83);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_184;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_184.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[13].V_x_vel.V_m_Y, -846.94);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_185 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[13].V_x_vel.V_m_Y, -846.94);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_185;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_185.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[13].V_m_lat_pos_in_lane[0], -418.41);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[13].V_m_lat_pos_in_lane[1], -695.55);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[13].V_m_lat_pos_in_lane[2], -971.45);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[13].V_m_lat_pos_in_lane[3], 840.46);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[13].V_m_lat_pos_in_lane[4], -685.08);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_186 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[13].V_m_lat_pos_in_lane[0], -418.41);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[13].V_m_lat_pos_in_lane[1], -695.55);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[13].V_m_lat_pos_in_lane[2], -971.45);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[13].V_m_lat_pos_in_lane[3], 840.46);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[13].V_m_lat_pos_in_lane[4], -685.08);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_186;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_186.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[13].V_m_lat_vel_in_lane, 183.37);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_187 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[13].V_m_lat_vel_in_lane, 183.37);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_187;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_187.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[13].V_m_width, -373.2);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_188 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[13].V_m_width, -373.2);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_188;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_188.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[13].V_x_ID, 2116305980);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_189 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[13].V_x_ID, 2116305980);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_189;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_189.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[13].V_x_type, 2040703953);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_190 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[13].V_x_type, 2040703953);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_190;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_190.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[13].V_x_lane, 50);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_191 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[13].V_x_lane, 50);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_191;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_191.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[13].V_x_is_valid, 37);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_192 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[13].V_x_is_valid, 37);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_192;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_192.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[13].V_x_is_usable, 38);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_193 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[13].V_x_is_usable, 38);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_193;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_193.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[13].V_x_border, 2567333881);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_194 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[13].V_x_border, 2567333881);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_194;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_194.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[13].V_x_lost, 190);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_195 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[13].V_x_lost, 190);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_195;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_195.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[14].V_x_pos.V_m_X, -759.91);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_196 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[14].V_x_pos.V_m_X, -759.91);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_196;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_196.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[14].V_x_pos.V_m_Y, 231.04);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_197 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[14].V_x_pos.V_m_Y, 231.04);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_197;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_197.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[14].V_x_vel.V_m_X, -183.34);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_198 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[14].V_x_vel.V_m_X, -183.34);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_198;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_198.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[14].V_x_vel.V_m_Y, -228.26);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_199 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[14].V_x_vel.V_m_Y, -228.26);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_199;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_199.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[14].V_m_lat_pos_in_lane[0], -545.25);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[14].V_m_lat_pos_in_lane[1], -390.79);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[14].V_m_lat_pos_in_lane[2], 136.26);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[14].V_m_lat_pos_in_lane[3], 381.08);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[14].V_m_lat_pos_in_lane[4], 465.86);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_200 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[14].V_m_lat_pos_in_lane[0], -545.25);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[14].V_m_lat_pos_in_lane[1], -390.79);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[14].V_m_lat_pos_in_lane[2], 136.26);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[14].V_m_lat_pos_in_lane[3], 381.08);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[14].V_m_lat_pos_in_lane[4], 465.86);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_200;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_200.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[14].V_m_lat_vel_in_lane, -430.63);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_201 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[14].V_m_lat_vel_in_lane, -430.63);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_201;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_201.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[14].V_m_width, -16.36);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_202 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[14].V_m_width, -16.36);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_202;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_202.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[14].V_x_ID, 2909775756);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_203 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[14].V_x_ID, 2909775756);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_203;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_203.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[14].V_x_type, 3342804760);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_204 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[14].V_x_type, 3342804760);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_204;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_204.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[14].V_x_lane, 85);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_205 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[14].V_x_lane, 85);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_205;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_205.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[14].V_x_is_valid, 241);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_206 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[14].V_x_is_valid, 241);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_206;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_206.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[14].V_x_is_usable, 206);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_207 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[14].V_x_is_usable, 206);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_207;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_207.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[14].V_x_border, 1106426984);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_208 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[14].V_x_border, 1106426984);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_208;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_208.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[14].V_x_lost, 15);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_209 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[14].V_x_lost, 15);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_209;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_209.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[15].V_x_pos.V_m_X, 355.16);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_210 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[15].V_x_pos.V_m_X, 355.16);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_210;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_210.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[15].V_x_pos.V_m_Y, -252.61);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_211 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[15].V_x_pos.V_m_Y, -252.61);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_211;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_211.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[15].V_x_vel.V_m_X, 742.25);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_212 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[15].V_x_vel.V_m_X, 742.25);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_212;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_212.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[15].V_x_vel.V_m_Y, -183.78);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_213 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[15].V_x_vel.V_m_Y, -183.78);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_213;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_213.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[15].V_m_lat_pos_in_lane[0], -716.49);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[15].V_m_lat_pos_in_lane[1], 275.54);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[15].V_m_lat_pos_in_lane[2], -980.16);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[15].V_m_lat_pos_in_lane[3], -560.95);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[15].V_m_lat_pos_in_lane[4], 372.41);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_214 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[15].V_m_lat_pos_in_lane[0], -716.49);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[15].V_m_lat_pos_in_lane[1], 275.54);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[15].V_m_lat_pos_in_lane[2], -980.16);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[15].V_m_lat_pos_in_lane[3], -560.95);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[15].V_m_lat_pos_in_lane[4], 372.41);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_214;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_214.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[15].V_m_lat_vel_in_lane, -316.17);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_215 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[15].V_m_lat_vel_in_lane, -316.17);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_215;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_215.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[15].V_m_width, -394.53);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_216 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[15].V_m_width, -394.53);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_216;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_216.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[15].V_x_ID, 2134334032);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_217 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[15].V_x_ID, 2134334032);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_217;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_217.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[15].V_x_type, 1444817154);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_218 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[15].V_x_type, 1444817154);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_218;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_218.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[15].V_x_lane, 103);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_219 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[15].V_x_lane, 103);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_219;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_219.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[15].V_x_is_valid, 148);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_220 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[15].V_x_is_valid, 148);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_220;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_220.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[15].V_x_is_usable, 178);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_221 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[15].V_x_is_usable, 178);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_221;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_221.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[15].V_x_border, 1404057224);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_222 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[15].V_x_border, 1404057224);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_222;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_222.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[15].V_x_lost, 29);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_223 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[15].V_x_lost, 29);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_223;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_223.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[16].V_x_pos.V_m_X, 945.39);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_224 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[16].V_x_pos.V_m_X, 945.39);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_224;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_224.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[16].V_x_pos.V_m_Y, 595.75);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_225 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[16].V_x_pos.V_m_Y, 595.75);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_225;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_225.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[16].V_x_vel.V_m_X, 829.67);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_226 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[16].V_x_vel.V_m_X, 829.67);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_226;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_226.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[16].V_x_vel.V_m_Y, 293.48);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_227 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[16].V_x_vel.V_m_Y, 293.48);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_227;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_227.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[16].V_m_lat_pos_in_lane[0], -651.02);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[16].V_m_lat_pos_in_lane[1], -951.65);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[16].V_m_lat_pos_in_lane[2], -817.98);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[16].V_m_lat_pos_in_lane[3], 997.54);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[16].V_m_lat_pos_in_lane[4], 956.31);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_228 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[16].V_m_lat_pos_in_lane[0], -651.02);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[16].V_m_lat_pos_in_lane[1], -951.65);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[16].V_m_lat_pos_in_lane[2], -817.98);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[16].V_m_lat_pos_in_lane[3], 997.54);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[16].V_m_lat_pos_in_lane[4], 956.31);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_228;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_228.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[16].V_m_lat_vel_in_lane, -152.75);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_229 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[16].V_m_lat_vel_in_lane, -152.75);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_229;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_229.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[16].V_m_width, 457.66);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_230 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[16].V_m_width, 457.66);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_230;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_230.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[16].V_x_ID, 1753976739);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_231 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[16].V_x_ID, 1753976739);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_231;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_231.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[16].V_x_type, 3337132052);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_232 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[16].V_x_type, 3337132052);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_232;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_232.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[16].V_x_lane, 28);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_233 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[16].V_x_lane, 28);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_233;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_233.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[16].V_x_is_valid, 120);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_234 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[16].V_x_is_valid, 120);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_234;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_234.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[16].V_x_is_usable, 169);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_235 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[16].V_x_is_usable, 169);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_235;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_235.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[16].V_x_border, 4032476112);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_236 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[16].V_x_border, 4032476112);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_236;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_236.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[16].V_x_lost, 127);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_237 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[16].V_x_lost, 127);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_237;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_237.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[17].V_x_pos.V_m_X, -783.8);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_238 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[17].V_x_pos.V_m_X, -783.8);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_238;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_238.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[17].V_x_pos.V_m_Y, 146.73);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_239 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[17].V_x_pos.V_m_Y, 146.73);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_239;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_239.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[17].V_x_vel.V_m_X, 536.07);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_240 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[17].V_x_vel.V_m_X, 536.07);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_240;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_240.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[17].V_x_vel.V_m_Y, -73.3);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_241 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[17].V_x_vel.V_m_Y, -73.3);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_241;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_241.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[17].V_m_lat_pos_in_lane[0], 909.38);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[17].V_m_lat_pos_in_lane[1], 917.38);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[17].V_m_lat_pos_in_lane[2], -478.13);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[17].V_m_lat_pos_in_lane[3], 314.57);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[17].V_m_lat_pos_in_lane[4], -305.16);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_242 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[17].V_m_lat_pos_in_lane[0], 909.38);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[17].V_m_lat_pos_in_lane[1], 917.38);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[17].V_m_lat_pos_in_lane[2], -478.13);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[17].V_m_lat_pos_in_lane[3], 314.57);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[17].V_m_lat_pos_in_lane[4], -305.16);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_242;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_242.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[17].V_m_lat_vel_in_lane, -822.21);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_243 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[17].V_m_lat_vel_in_lane, -822.21);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_243;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_243.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[17].V_m_width, 59.27);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_244 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[17].V_m_width, 59.27);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_244;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_244.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[17].V_x_ID, 3677087068);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_245 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[17].V_x_ID, 3677087068);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_245;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_245.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[17].V_x_type, 1220146845);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_246 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[17].V_x_type, 1220146845);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_246;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_246.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[17].V_x_lane, 85);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_247 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[17].V_x_lane, 85);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_247;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_247.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[17].V_x_is_valid, 56);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_248 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[17].V_x_is_valid, 56);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_248;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_248.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[17].V_x_is_usable, 253);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_249 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[17].V_x_is_usable, 253);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_249;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_249.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[17].V_x_border, 943081654);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_250 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[17].V_x_border, 943081654);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_250;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_250.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[17].V_x_lost, 86);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_251 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[17].V_x_lost, 86);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_251;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_251.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[18].V_x_pos.V_m_X, -701.72);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_252 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[18].V_x_pos.V_m_X, -701.72);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_252;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_252.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[18].V_x_pos.V_m_Y, -752.33);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_253 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[18].V_x_pos.V_m_Y, -752.33);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_253;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_253.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[18].V_x_vel.V_m_X, -522.17);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_254 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[18].V_x_vel.V_m_X, -522.17);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_254;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_254.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[18].V_x_vel.V_m_Y, 365.2);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_255 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[18].V_x_vel.V_m_Y, 365.2);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_255;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_255.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[18].V_m_lat_pos_in_lane[0], -222.84);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[18].V_m_lat_pos_in_lane[1], -16.68);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[18].V_m_lat_pos_in_lane[2], -238.35);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[18].V_m_lat_pos_in_lane[3], -768.39);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[18].V_m_lat_pos_in_lane[4], -607.32);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_256 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[18].V_m_lat_pos_in_lane[0], -222.84);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[18].V_m_lat_pos_in_lane[1], -16.68);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[18].V_m_lat_pos_in_lane[2], -238.35);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[18].V_m_lat_pos_in_lane[3], -768.39);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[18].V_m_lat_pos_in_lane[4], -607.32);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_256;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_256.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[18].V_m_lat_vel_in_lane, 903.43);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_257 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[18].V_m_lat_vel_in_lane, 903.43);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_257;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_257.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[18].V_m_width, 610.63);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_258 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[18].V_m_width, 610.63);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_258;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_258.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[18].V_x_ID, 2729724498);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_259 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[18].V_x_ID, 2729724498);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_259;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_259.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[18].V_x_type, 2116700379);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_260 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[18].V_x_type, 2116700379);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_260;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_260.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[18].V_x_lane, 141);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_261 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[18].V_x_lane, 141);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_261;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_261.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[18].V_x_is_valid, 162);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_262 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[18].V_x_is_valid, 162);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_262;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_262.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[18].V_x_is_usable, 91);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_263 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[18].V_x_is_usable, 91);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_263;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_263.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[18].V_x_border, 2015697200);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_264 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[18].V_x_border, 2015697200);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_264;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_264.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[18].V_x_lost, 51);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_265 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[18].V_x_lost, 51);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_265;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_265.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[19].V_x_pos.V_m_X, 139.74);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_266 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[19].V_x_pos.V_m_X, 139.74);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_266;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_266.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[19].V_x_pos.V_m_Y, 104.7);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_267 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[19].V_x_pos.V_m_Y, 104.7);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_267;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_267.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[19].V_x_vel.V_m_X, -797.2);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_268 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[19].V_x_vel.V_m_X, -797.2);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_268;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_268.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[19].V_x_vel.V_m_Y, 873.93);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_269 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[19].V_x_vel.V_m_Y, 873.93);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_269;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_269.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[19].V_m_lat_pos_in_lane[0], -579.39);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[19].V_m_lat_pos_in_lane[1], -484.93);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[19].V_m_lat_pos_in_lane[2], 274.69);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[19].V_m_lat_pos_in_lane[3], 437.08);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[19].V_m_lat_pos_in_lane[4], 871.6);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_270 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[19].V_m_lat_pos_in_lane[0], -579.39);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[19].V_m_lat_pos_in_lane[1], -484.93);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[19].V_m_lat_pos_in_lane[2], 274.69);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[19].V_m_lat_pos_in_lane[3], 437.08);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[19].V_m_lat_pos_in_lane[4], 871.6);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_270;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_270.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[19].V_m_lat_vel_in_lane, 352.14);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_271 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[19].V_m_lat_vel_in_lane, 352.14);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_271;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_271.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[19].V_m_width, -429.64);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_272 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[19].V_m_width, -429.64);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_272;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_272.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[19].V_x_ID, 1897048280);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_273 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[19].V_x_ID, 1897048280);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_273;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_273.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[19].V_x_type, 714700975);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_274 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[19].V_x_type, 714700975);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_274;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_274.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[19].V_x_lane, 111);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_275 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[19].V_x_lane, 111);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_275;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_275.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[19].V_x_is_valid, 91);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_276 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[19].V_x_is_valid, 91);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_276;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_276.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[19].V_x_is_usable, 154);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_277 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[19].V_x_is_usable, 154);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_277;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_277.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[19].V_x_border, 1632425072);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_278 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[19].V_x_border, 1632425072);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_278;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_278.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[19].V_x_lost, 127);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_279 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[19].V_x_lost, 127);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_279;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_279.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[20].V_x_pos.V_m_X, 292.47);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_280 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[20].V_x_pos.V_m_X, 292.47);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_280;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_280.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[20].V_x_pos.V_m_Y, -519.72);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_281 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[20].V_x_pos.V_m_Y, -519.72);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_281;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_281.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[20].V_x_vel.V_m_X, -515.17);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_282 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[20].V_x_vel.V_m_X, -515.17);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_282;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_282.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[20].V_x_vel.V_m_Y, -517.15);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_283 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[20].V_x_vel.V_m_Y, -517.15);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_283;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_283.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[20].V_m_lat_pos_in_lane[0], -752.5);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[20].V_m_lat_pos_in_lane[1], -867.31);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[20].V_m_lat_pos_in_lane[2], 824.54);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[20].V_m_lat_pos_in_lane[3], 509.95);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[20].V_m_lat_pos_in_lane[4], -222.56);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_284 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[20].V_m_lat_pos_in_lane[0], -752.5);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[20].V_m_lat_pos_in_lane[1], -867.31);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[20].V_m_lat_pos_in_lane[2], 824.54);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[20].V_m_lat_pos_in_lane[3], 509.95);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[20].V_m_lat_pos_in_lane[4], -222.56);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_284;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_284.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[20].V_m_lat_vel_in_lane, 598.67);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_285 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[20].V_m_lat_vel_in_lane, 598.67);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_285;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_285.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[20].V_m_width, -730.85);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_286 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[20].V_m_width, -730.85);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_286;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_286.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[20].V_x_ID, 1434085659);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_287 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[20].V_x_ID, 1434085659);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_287;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_287.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[20].V_x_type, 328540928);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_288 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[20].V_x_type, 328540928);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_288;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_288.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[20].V_x_lane, 161);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_289 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[20].V_x_lane, 161);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_289;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_289.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[20].V_x_is_valid, 189);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_290 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[20].V_x_is_valid, 189);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_290;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_290.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[20].V_x_is_usable, 160);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_291 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[20].V_x_is_usable, 160);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_291;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_291.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[20].V_x_border, 1802912522);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_292 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[20].V_x_border, 1802912522);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_292;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_292.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[20].V_x_lost, 74);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_293 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[20].V_x_lost, 74);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_293;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_293.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[21].V_x_pos.V_m_X, 456);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_294 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[21].V_x_pos.V_m_X, 456);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_294;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_294.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[21].V_x_pos.V_m_Y, -26.58);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_295 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[21].V_x_pos.V_m_Y, -26.58);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_295;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_295.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[21].V_x_vel.V_m_X, -162.65);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_296 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[21].V_x_vel.V_m_X, -162.65);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_296;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_296.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[21].V_x_vel.V_m_Y, -213.68);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_297 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[21].V_x_vel.V_m_Y, -213.68);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_297;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_297.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[21].V_m_lat_pos_in_lane[0], 833.46);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[21].V_m_lat_pos_in_lane[1], -93.5);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[21].V_m_lat_pos_in_lane[2], 125.52);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[21].V_m_lat_pos_in_lane[3], -554.95);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[21].V_m_lat_pos_in_lane[4], 851.88);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_298 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[21].V_m_lat_pos_in_lane[0], 833.46);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[21].V_m_lat_pos_in_lane[1], -93.5);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[21].V_m_lat_pos_in_lane[2], 125.52);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[21].V_m_lat_pos_in_lane[3], -554.95);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[21].V_m_lat_pos_in_lane[4], 851.88);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_298;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_298.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[21].V_m_lat_vel_in_lane, 176.99);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_299 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[21].V_m_lat_vel_in_lane, 176.99);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_299;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_299.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[21].V_m_width, 492.59);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_300 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[21].V_m_width, 492.59);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_300;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_300.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[21].V_x_ID, 2639938007);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_301 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[21].V_x_ID, 2639938007);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_301;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_301.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[21].V_x_type, 1306412627);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_302 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[21].V_x_type, 1306412627);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_302;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_302.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[21].V_x_lane, 206);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_303 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[21].V_x_lane, 206);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_303;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_303.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[21].V_x_is_valid, 19);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_304 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[21].V_x_is_valid, 19);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_304;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_304.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[21].V_x_is_usable, 86);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_305 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[21].V_x_is_usable, 86);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_305;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_305.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[21].V_x_border, 715565417);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_306 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[21].V_x_border, 715565417);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_306;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_306.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[21].V_x_lost, 160);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_307 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[21].V_x_lost, 160);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_307;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_307.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[22].V_x_pos.V_m_X, 468.66);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_308 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[22].V_x_pos.V_m_X, 468.66);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_308;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_308.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[22].V_x_pos.V_m_Y, 222.26);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_309 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[22].V_x_pos.V_m_Y, 222.26);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_309;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_309.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[22].V_x_vel.V_m_X, -685.42);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_310 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[22].V_x_vel.V_m_X, -685.42);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_310;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_310.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[22].V_x_vel.V_m_Y, -291.07);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_311 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[22].V_x_vel.V_m_Y, -291.07);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_311;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_311.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[22].V_m_lat_pos_in_lane[0], 116.04);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[22].V_m_lat_pos_in_lane[1], 284.3);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[22].V_m_lat_pos_in_lane[2], -861.41);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[22].V_m_lat_pos_in_lane[3], -315.5);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[22].V_m_lat_pos_in_lane[4], -618.45);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_312 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[22].V_m_lat_pos_in_lane[0], 116.04);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[22].V_m_lat_pos_in_lane[1], 284.3);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[22].V_m_lat_pos_in_lane[2], -861.41);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[22].V_m_lat_pos_in_lane[3], -315.5);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[22].V_m_lat_pos_in_lane[4], -618.45);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_312;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_312.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[22].V_m_lat_vel_in_lane, 531.17);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_313 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[22].V_m_lat_vel_in_lane, 531.17);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_313;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_313.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[22].V_m_width, -719.83);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_314 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[22].V_m_width, -719.83);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_314;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_314.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[22].V_x_ID, 3251451111);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_315 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[22].V_x_ID, 3251451111);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_315;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_315.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[22].V_x_type, 3784309887);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_316 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[22].V_x_type, 3784309887);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_316;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_316.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[22].V_x_lane, 125);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_317 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[22].V_x_lane, 125);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_317;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_317.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[22].V_x_is_valid, 251);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_318 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[22].V_x_is_valid, 251);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_318;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_318.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[22].V_x_is_usable, 102);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_319 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[22].V_x_is_usable, 102);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_319;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_319.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[22].V_x_border, 1082609509);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_320 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[22].V_x_border, 1082609509);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_320;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_320.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[22].V_x_lost, 245);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_321 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[22].V_x_lost, 245);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_321;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_321.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[23].V_x_pos.V_m_X, 752.16);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_322 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[23].V_x_pos.V_m_X, 752.16);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_322;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_322.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[23].V_x_pos.V_m_Y, -336.79);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_323 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[23].V_x_pos.V_m_Y, -336.79);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_323;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_323.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[23].V_x_vel.V_m_X, -522.41);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_324 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[23].V_x_vel.V_m_X, -522.41);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_324;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_324.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[23].V_x_vel.V_m_Y, 641.61);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_325 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[23].V_x_vel.V_m_Y, 641.61);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_325;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_325.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[23].V_m_lat_pos_in_lane[0], -282.09);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[23].V_m_lat_pos_in_lane[1], 796.53);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[23].V_m_lat_pos_in_lane[2], 894.55);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[23].V_m_lat_pos_in_lane[3], -824.51);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[23].V_m_lat_pos_in_lane[4], 615.63);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_326 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[23].V_m_lat_pos_in_lane[0], -282.09);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[23].V_m_lat_pos_in_lane[1], 796.53);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[23].V_m_lat_pos_in_lane[2], 894.55);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[23].V_m_lat_pos_in_lane[3], -824.51);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[23].V_m_lat_pos_in_lane[4], 615.63);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_326;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_326.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[23].V_m_lat_vel_in_lane, 939.08);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_327 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[23].V_m_lat_vel_in_lane, 939.08);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_327;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_327.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[23].V_m_width, 510.58);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_328 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[23].V_m_width, 510.58);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_328;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_328.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[23].V_x_ID, 1311057519);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_329 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[23].V_x_ID, 1311057519);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_329;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_329.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[23].V_x_type, 1771292228);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_330 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[23].V_x_type, 1771292228);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_330;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_330.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[23].V_x_lane, 188);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_331 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[23].V_x_lane, 188);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_331;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_331.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[23].V_x_is_valid, 188);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_332 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[23].V_x_is_valid, 188);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_332;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_332.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[23].V_x_is_usable, 43);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_333 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[23].V_x_is_usable, 43);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_333;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_333.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[23].V_x_border, 473520939);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_334 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[23].V_x_border, 473520939);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_334;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_334.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[23].V_x_lost, 180);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_335 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[23].V_x_lost, 180);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_335;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_335.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[24].V_x_pos.V_m_X, 569.31);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_336 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[24].V_x_pos.V_m_X, 569.31);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_336;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_336.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[24].V_x_pos.V_m_Y, -109.18);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_337 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[24].V_x_pos.V_m_Y, -109.18);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_337;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_337.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[24].V_x_vel.V_m_X, 764.57);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_338 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[24].V_x_vel.V_m_X, 764.57);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_338;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_338.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[24].V_x_vel.V_m_Y, 770.43);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_339 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[24].V_x_vel.V_m_Y, 770.43);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_339;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_339.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[24].V_m_lat_pos_in_lane[0], -752.4);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[24].V_m_lat_pos_in_lane[1], -593.12);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[24].V_m_lat_pos_in_lane[2], 100.07);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[24].V_m_lat_pos_in_lane[3], 320.05);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[24].V_m_lat_pos_in_lane[4], -836.66);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_340 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[24].V_m_lat_pos_in_lane[0], -752.4);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[24].V_m_lat_pos_in_lane[1], -593.12);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[24].V_m_lat_pos_in_lane[2], 100.07);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[24].V_m_lat_pos_in_lane[3], 320.05);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[24].V_m_lat_pos_in_lane[4], -836.66);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_340;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_340.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[24].V_m_lat_vel_in_lane, -84.98);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_341 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[24].V_m_lat_vel_in_lane, -84.98);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_341;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_341.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[24].V_m_width, 68.51);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_342 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[24].V_m_width, 68.51);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_342;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_342.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[24].V_x_ID, 3578375552);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_343 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[24].V_x_ID, 3578375552);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_343;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_343.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[24].V_x_type, 1258387527);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_344 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[24].V_x_type, 1258387527);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_344;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_344.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[24].V_x_lane, 32);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_345 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[24].V_x_lane, 32);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_345;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_345.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[24].V_x_is_valid, 228);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_346 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[24].V_x_is_valid, 228);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_346;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_346.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[24].V_x_is_usable, 154);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_347 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[24].V_x_is_usable, 154);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_347;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_347.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[24].V_x_border, 2616268132);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_348 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[24].V_x_border, 2616268132);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_348;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_348.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[24].V_x_lost, 206);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_349 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[24].V_x_lost, 206);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_349;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_349.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[25].V_x_pos.V_m_X, -785.17);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_350 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[25].V_x_pos.V_m_X, -785.17);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_350;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_350.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[25].V_x_pos.V_m_Y, -971.73);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_351 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[25].V_x_pos.V_m_Y, -971.73);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_351;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_351.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[25].V_x_vel.V_m_X, -80.13);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_352 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[25].V_x_vel.V_m_X, -80.13);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_352;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_352.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[25].V_x_vel.V_m_Y, -191.71);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_353 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[25].V_x_vel.V_m_Y, -191.71);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_353;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_353.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[25].V_m_lat_pos_in_lane[0], 561.15);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[25].V_m_lat_pos_in_lane[1], -974.74);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[25].V_m_lat_pos_in_lane[2], 38.01);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[25].V_m_lat_pos_in_lane[3], 98.8);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[25].V_m_lat_pos_in_lane[4], -315.02);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_354 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[25].V_m_lat_pos_in_lane[0], 561.15);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[25].V_m_lat_pos_in_lane[1], -974.74);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[25].V_m_lat_pos_in_lane[2], 38.01);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[25].V_m_lat_pos_in_lane[3], 98.8);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[25].V_m_lat_pos_in_lane[4], -315.02);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_354;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_354.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[25].V_m_lat_vel_in_lane, 890.59);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_355 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[25].V_m_lat_vel_in_lane, 890.59);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_355;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_355.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[25].V_m_width, -69.57);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_356 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[25].V_m_width, -69.57);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_356;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_356.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[25].V_x_ID, 3221139213);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_357 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[25].V_x_ID, 3221139213);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_357;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_357.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[25].V_x_type, 4044453891);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_358 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[25].V_x_type, 4044453891);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_358;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_358.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[25].V_x_lane, 120);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_359 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[25].V_x_lane, 120);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_359;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_359.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[25].V_x_is_valid, 19);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_360 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[25].V_x_is_valid, 19);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_360;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_360.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[25].V_x_is_usable, 54);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_361 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[25].V_x_is_usable, 54);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_361;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_361.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[25].V_x_border, 4151065275);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_362 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[25].V_x_border, 4151065275);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_362;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_362.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[25].V_x_lost, 83);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_363 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[25].V_x_lost, 83);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_363;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_363.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[26].V_x_pos.V_m_X, -818.25);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_364 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[26].V_x_pos.V_m_X, -818.25);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_364;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_364.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[26].V_x_pos.V_m_Y, 353.55);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_365 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[26].V_x_pos.V_m_Y, 353.55);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_365;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_365.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[26].V_x_vel.V_m_X, 387.19);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_366 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[26].V_x_vel.V_m_X, 387.19);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_366;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_366.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[26].V_x_vel.V_m_Y, -798.35);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_367 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[26].V_x_vel.V_m_Y, -798.35);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_367;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_367.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[26].V_m_lat_pos_in_lane[0], -175.66);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[26].V_m_lat_pos_in_lane[1], -433.04);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[26].V_m_lat_pos_in_lane[2], 215.42);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[26].V_m_lat_pos_in_lane[3], -759.67);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[26].V_m_lat_pos_in_lane[4], 193.92);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_368 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[26].V_m_lat_pos_in_lane[0], -175.66);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[26].V_m_lat_pos_in_lane[1], -433.04);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[26].V_m_lat_pos_in_lane[2], 215.42);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[26].V_m_lat_pos_in_lane[3], -759.67);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[26].V_m_lat_pos_in_lane[4], 193.92);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_368;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_368.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[26].V_m_lat_vel_in_lane, -147.26);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_369 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[26].V_m_lat_vel_in_lane, -147.26);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_369;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_369.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[26].V_m_width, 586.18);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_370 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[26].V_m_width, 586.18);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_370;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_370.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[26].V_x_ID, 3395225645);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_371 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[26].V_x_ID, 3395225645);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_371;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_371.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[26].V_x_type, 2137628848);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_372 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[26].V_x_type, 2137628848);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_372;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_372.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[26].V_x_lane, 212);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_373 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[26].V_x_lane, 212);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_373;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_373.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[26].V_x_is_valid, 209);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_374 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[26].V_x_is_valid, 209);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_374;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_374.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[26].V_x_is_usable, 135);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_375 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[26].V_x_is_usable, 135);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_375;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_375.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[26].V_x_border, 549972853);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_376 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[26].V_x_border, 549972853);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_376;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_376.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[26].V_x_lost, 5);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_377 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[26].V_x_lost, 5);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_377;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_377.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[27].V_x_pos.V_m_X, 932.11);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_378 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[27].V_x_pos.V_m_X, 932.11);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_378;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_378.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[27].V_x_pos.V_m_Y, -516.56);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_379 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[27].V_x_pos.V_m_Y, -516.56);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_379;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_379.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[27].V_x_vel.V_m_X, -20.58);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_380 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[27].V_x_vel.V_m_X, -20.58);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_380;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_380.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[27].V_x_vel.V_m_Y, 913.13);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_381 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[27].V_x_vel.V_m_Y, 913.13);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_381;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_381.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[27].V_m_lat_pos_in_lane[0], -303.91);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[27].V_m_lat_pos_in_lane[1], 594.12);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[27].V_m_lat_pos_in_lane[2], -529.93);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[27].V_m_lat_pos_in_lane[3], -15.66);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[27].V_m_lat_pos_in_lane[4], -600.12);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_382 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[27].V_m_lat_pos_in_lane[0], -303.91);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[27].V_m_lat_pos_in_lane[1], 594.12);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[27].V_m_lat_pos_in_lane[2], -529.93);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[27].V_m_lat_pos_in_lane[3], -15.66);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[27].V_m_lat_pos_in_lane[4], -600.12);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_382;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_382.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[27].V_m_lat_vel_in_lane, 590.88);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_383 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[27].V_m_lat_vel_in_lane, 590.88);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_383;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_383.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[27].V_m_width, -539.81);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_384 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[27].V_m_width, -539.81);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_384;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_384.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[27].V_x_ID, 3864996250);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_385 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[27].V_x_ID, 3864996250);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_385;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_385.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[27].V_x_type, 76636);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_386 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[27].V_x_type, 76636);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_386;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_386.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[27].V_x_lane, 96);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_387 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[27].V_x_lane, 96);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_387;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_387.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[27].V_x_is_valid, 183);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_388 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[27].V_x_is_valid, 183);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_388;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_388.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[27].V_x_is_usable, 199);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_389 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[27].V_x_is_usable, 199);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_389;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_389.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[27].V_x_border, 3123937434);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_390 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[27].V_x_border, 3123937434);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_390;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_390.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[27].V_x_lost, 141);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_391 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[27].V_x_lost, 141);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_391;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_391.verify();

}
