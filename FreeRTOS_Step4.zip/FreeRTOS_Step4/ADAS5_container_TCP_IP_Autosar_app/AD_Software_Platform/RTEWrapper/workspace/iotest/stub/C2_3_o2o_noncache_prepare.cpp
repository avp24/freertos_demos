#include <limits.h>
#include <float.h>
#define DUMMY_RTE_INCLUDE_MULTI_SWC_HEADER
#include "Platform_Types.h"

#include "Rte_Wrapper_RCarHMIManagement.h"
void C2_3_o2o_noncache_prepare_RCarHMIManagement(void)
{
    V_x_RCarHMIManagementOutput tmp_RCarHMIManagementOutput;

    tmp_RCarHMIManagementOutput.V_x_PeriVehRecog_MetVecX[0] = 244;
    tmp_RCarHMIManagementOutput.V_x_PeriVehRecog_MetVecX[1] = 107;
    tmp_RCarHMIManagementOutput.V_x_PeriVehRecog_MetVecX[2] = 244;
    tmp_RCarHMIManagementOutput.V_x_PeriVehRecog_MetVecX[3] = 249;
    tmp_RCarHMIManagementOutput.V_x_PeriVehRecog_MetVecX[4] = 233;
    tmp_RCarHMIManagementOutput.V_x_PeriVehRecog_MetVecX[5] = 56;
    tmp_RCarHMIManagementOutput.V_x_PeriVehRecog_MetVecX[6] = 101;
    tmp_RCarHMIManagementOutput.V_x_PeriVehRecog_MetVecX[7] = 209;
    tmp_RCarHMIManagementOutput.V_x_PeriVehRecog_MetVecX[8] = 43;
    tmp_RCarHMIManagementOutput.V_x_PeriVehRecog_MetVecY[0] = 86;
    tmp_RCarHMIManagementOutput.V_x_PeriVehRecog_MetVecY[1] = -20;
    tmp_RCarHMIManagementOutput.V_x_PeriVehRecog_MetVecY[2] = 54;
    tmp_RCarHMIManagementOutput.V_x_PeriVehRecog_MetVecY[3] = -97;
    tmp_RCarHMIManagementOutput.V_x_PeriVehRecog_MetVecY[4] = 112;
    tmp_RCarHMIManagementOutput.V_x_PeriVehRecog_MetVecY[5] = 67;
    tmp_RCarHMIManagementOutput.V_x_PeriVehRecog_MetVecY[6] = -104;
    tmp_RCarHMIManagementOutput.V_x_PeriVehRecog_MetVecY[7] = -94;
    tmp_RCarHMIManagementOutput.V_x_PeriVehRecog_MetVecY[8] = 94;
    tmp_RCarHMIManagementOutput.V_x_PeriVehRecog_MetVecType[0] = 159;
    tmp_RCarHMIManagementOutput.V_x_PeriVehRecog_MetVecType[1] = 9;
    tmp_RCarHMIManagementOutput.V_x_PeriVehRecog_MetVecType[2] = 164;
    tmp_RCarHMIManagementOutput.V_x_PeriVehRecog_MetVecType[3] = 45;
    tmp_RCarHMIManagementOutput.V_x_PeriVehRecog_MetVecType[4] = 149;
    tmp_RCarHMIManagementOutput.V_x_PeriVehRecog_MetVecType[5] = 64;
    tmp_RCarHMIManagementOutput.V_x_PeriVehRecog_MetVecType[6] = 148;
    tmp_RCarHMIManagementOutput.V_x_PeriVehRecog_MetVecType[7] = 106;
    tmp_RCarHMIManagementOutput.V_x_PeriVehRecog_MetVecType[8] = 156;
    Rte_Write_V_x_RCarHMIManagementOutput_V_x_RCarHMIManagementOutput(&tmp_RCarHMIManagementOutput);
}

#include "Rte_Wrapper_ObjectSelectionAVM.h"
void C2_3_o2o_noncache_prepare_ObjectSelectionAVM(void)
{
    V_x_ObjectSelectionAVMOutput tmp_ObjectSelectionAVMOutput;

    tmp_ObjectSelectionAVMOutput.V_cm_Object1_X = 241.69;
    tmp_ObjectSelectionAVMOutput.V_cm_Object1_Y = 471.23;
    tmp_ObjectSelectionAVMOutput.V_mps_Object1_Xspeed = 425.15;
    tmp_ObjectSelectionAVMOutput.V_mps_Object1_Yspeed = 511.99;
    tmp_ObjectSelectionAVMOutput.V_x_Object1_ID = 180;
    tmp_ObjectSelectionAVMOutput.V_cm_Object2_X = -851.81;
    tmp_ObjectSelectionAVMOutput.V_cm_Object2_Y = 704.32;
    tmp_ObjectSelectionAVMOutput.V_mps_Object2_Xspeed = 545.95;
    tmp_ObjectSelectionAVMOutput.V_mps_Object2_Yspeed = -346.04;
    tmp_ObjectSelectionAVMOutput.V_x_Object2_ID = 248;
    tmp_ObjectSelectionAVMOutput.V_cm_Object3_X = 482.69;
    tmp_ObjectSelectionAVMOutput.V_cm_Object3_Y = -401.04;
    tmp_ObjectSelectionAVMOutput.V_mps_Object3_Xspeed = -163.64;
    tmp_ObjectSelectionAVMOutput.V_mps_Object3_Yspeed = -13.89;
    tmp_ObjectSelectionAVMOutput.V_x_Object3_ID = 23;
    tmp_ObjectSelectionAVMOutput.V_cm_Object4_X = 454.14;
    tmp_ObjectSelectionAVMOutput.V_cm_Object4_Y = 1.94;
    tmp_ObjectSelectionAVMOutput.V_mps_Object4_Xspeed = -987.66;
    tmp_ObjectSelectionAVMOutput.V_mps_Object4_Yspeed = -686;
    tmp_ObjectSelectionAVMOutput.V_x_Object4_ID = 167;
    tmp_ObjectSelectionAVMOutput.V_cm_Object5_X = -631.14;
    tmp_ObjectSelectionAVMOutput.V_cm_Object5_Y = -814.63;
    tmp_ObjectSelectionAVMOutput.V_mps_Object5_Xspeed = 980.44;
    tmp_ObjectSelectionAVMOutput.V_mps_Object5_Yspeed = 93.31;
    tmp_ObjectSelectionAVMOutput.V_x_Object5_ID = 34;
    tmp_ObjectSelectionAVMOutput.V_x_DetectionDirection = 238;
    Rte_Write_V_x_ObjectSelectionAVMOutput_V_x_ObjectSelectionAVMOutput(&tmp_ObjectSelectionAVMOutput);
}

#include "Rte_Wrapper_VehStatus_In_100.h"
void C2_3_o2o_noncache_prepare_VehStatus_In_100(void)
{
    V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
    sint32 tmp_S32;
    V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
    V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;

}
