#include <limits.h>
#include <float.h>
#include "gtest/gtest.h"
#include "Rte_Union.h"
#include "Platform_Types.h"

extern URCarHMIManagementDataSet gOEM_SWC_C2_3URCarHMIManagementDataSet;
extern UObjectSelectionAVMDataSet gOEM_SWC_C2_3UObjectSelectionAVMDataSet;
extern UVehStatus_In_100DataSet gOEM_SWC_C2_3UVehStatus_In_100DataSet;

void C2_3_o2o_noncache_min_verify_RCarHMIManagement(void)
{
    V_x_RCarHMIManagementOutput tmp_RCarHMIManagementOutput;

    /* V_x_RCarHMIManagementOutput*/
    extern URCarHMIManagementDataSet gOEM_SWC_C1_1URCarHMIManagementDataSet;
    EXPECT_EQ(gOEM_SWC_C2_3URCarHMIManagementDataSet.mConc.V_x_RCarHMIManagementOutput.V_x_PeriVehRecog_MetVecX[0], 0);
    EXPECT_EQ(gOEM_SWC_C1_1URCarHMIManagementDataSet.mConc.V_x_RCarHMIManagementOutput.V_x_PeriVehRecog_MetVecX[0], 0);
    EXPECT_EQ(gOEM_SWC_C2_3URCarHMIManagementDataSet.mConc.V_x_RCarHMIManagementOutput.V_x_PeriVehRecog_MetVecX[1], 0);
    EXPECT_EQ(gOEM_SWC_C1_1URCarHMIManagementDataSet.mConc.V_x_RCarHMIManagementOutput.V_x_PeriVehRecog_MetVecX[1], 0);
    EXPECT_EQ(gOEM_SWC_C2_3URCarHMIManagementDataSet.mConc.V_x_RCarHMIManagementOutput.V_x_PeriVehRecog_MetVecX[2], 0);
    EXPECT_EQ(gOEM_SWC_C1_1URCarHMIManagementDataSet.mConc.V_x_RCarHMIManagementOutput.V_x_PeriVehRecog_MetVecX[2], 0);
    EXPECT_EQ(gOEM_SWC_C2_3URCarHMIManagementDataSet.mConc.V_x_RCarHMIManagementOutput.V_x_PeriVehRecog_MetVecX[3], 0);
    EXPECT_EQ(gOEM_SWC_C1_1URCarHMIManagementDataSet.mConc.V_x_RCarHMIManagementOutput.V_x_PeriVehRecog_MetVecX[3], 0);
    EXPECT_EQ(gOEM_SWC_C2_3URCarHMIManagementDataSet.mConc.V_x_RCarHMIManagementOutput.V_x_PeriVehRecog_MetVecX[4], 0);
    EXPECT_EQ(gOEM_SWC_C1_1URCarHMIManagementDataSet.mConc.V_x_RCarHMIManagementOutput.V_x_PeriVehRecog_MetVecX[4], 0);
    EXPECT_EQ(gOEM_SWC_C2_3URCarHMIManagementDataSet.mConc.V_x_RCarHMIManagementOutput.V_x_PeriVehRecog_MetVecX[5], 0);
    EXPECT_EQ(gOEM_SWC_C1_1URCarHMIManagementDataSet.mConc.V_x_RCarHMIManagementOutput.V_x_PeriVehRecog_MetVecX[5], 0);
    EXPECT_EQ(gOEM_SWC_C2_3URCarHMIManagementDataSet.mConc.V_x_RCarHMIManagementOutput.V_x_PeriVehRecog_MetVecX[6], 0);
    EXPECT_EQ(gOEM_SWC_C1_1URCarHMIManagementDataSet.mConc.V_x_RCarHMIManagementOutput.V_x_PeriVehRecog_MetVecX[6], 0);
    EXPECT_EQ(gOEM_SWC_C2_3URCarHMIManagementDataSet.mConc.V_x_RCarHMIManagementOutput.V_x_PeriVehRecog_MetVecX[7], 0);
    EXPECT_EQ(gOEM_SWC_C1_1URCarHMIManagementDataSet.mConc.V_x_RCarHMIManagementOutput.V_x_PeriVehRecog_MetVecX[7], 0);
    EXPECT_EQ(gOEM_SWC_C2_3URCarHMIManagementDataSet.mConc.V_x_RCarHMIManagementOutput.V_x_PeriVehRecog_MetVecX[8], 0);
    EXPECT_EQ(gOEM_SWC_C1_1URCarHMIManagementDataSet.mConc.V_x_RCarHMIManagementOutput.V_x_PeriVehRecog_MetVecX[8], 0);
    struct _func_V_x_RCarHMIManagementOutput_VehStatus_In_0 {
        static void verify(void) {
#include "Rte_Wrapper_VehStatus_In.h"
            V_x_RCarHMIManagementOutput tmp_RCarHMIManagementOutput;
            Rte_Read_V_x_RCarHMIManagementOutput_V_x_RCarHMIManagementOutput(&tmp_RCarHMIManagementOutput);
            EXPECT_EQ(tmp_RCarHMIManagementOutput.V_x_PeriVehRecog_MetVecX[0], 0);
            EXPECT_EQ(tmp_RCarHMIManagementOutput.V_x_PeriVehRecog_MetVecX[1], 0);
            EXPECT_EQ(tmp_RCarHMIManagementOutput.V_x_PeriVehRecog_MetVecX[2], 0);
            EXPECT_EQ(tmp_RCarHMIManagementOutput.V_x_PeriVehRecog_MetVecX[3], 0);
            EXPECT_EQ(tmp_RCarHMIManagementOutput.V_x_PeriVehRecog_MetVecX[4], 0);
            EXPECT_EQ(tmp_RCarHMIManagementOutput.V_x_PeriVehRecog_MetVecX[5], 0);
            EXPECT_EQ(tmp_RCarHMIManagementOutput.V_x_PeriVehRecog_MetVecX[6], 0);
            EXPECT_EQ(tmp_RCarHMIManagementOutput.V_x_PeriVehRecog_MetVecX[7], 0);
            EXPECT_EQ(tmp_RCarHMIManagementOutput.V_x_PeriVehRecog_MetVecX[8], 0);
        }
    } func_V_x_RCarHMIManagementOutput_VehStatus_In_0;
    func_V_x_RCarHMIManagementOutput_VehStatus_In_0.verify();

    extern URCarHMIManagementDataSet gOEM_SWC_C1_1URCarHMIManagementDataSet;
    EXPECT_EQ(gOEM_SWC_C2_3URCarHMIManagementDataSet.mConc.V_x_RCarHMIManagementOutput.V_x_PeriVehRecog_MetVecY[0], -128);
    EXPECT_EQ(gOEM_SWC_C1_1URCarHMIManagementDataSet.mConc.V_x_RCarHMIManagementOutput.V_x_PeriVehRecog_MetVecY[0], -128);
    EXPECT_EQ(gOEM_SWC_C2_3URCarHMIManagementDataSet.mConc.V_x_RCarHMIManagementOutput.V_x_PeriVehRecog_MetVecY[1], -128);
    EXPECT_EQ(gOEM_SWC_C1_1URCarHMIManagementDataSet.mConc.V_x_RCarHMIManagementOutput.V_x_PeriVehRecog_MetVecY[1], -128);
    EXPECT_EQ(gOEM_SWC_C2_3URCarHMIManagementDataSet.mConc.V_x_RCarHMIManagementOutput.V_x_PeriVehRecog_MetVecY[2], -128);
    EXPECT_EQ(gOEM_SWC_C1_1URCarHMIManagementDataSet.mConc.V_x_RCarHMIManagementOutput.V_x_PeriVehRecog_MetVecY[2], -128);
    EXPECT_EQ(gOEM_SWC_C2_3URCarHMIManagementDataSet.mConc.V_x_RCarHMIManagementOutput.V_x_PeriVehRecog_MetVecY[3], -128);
    EXPECT_EQ(gOEM_SWC_C1_1URCarHMIManagementDataSet.mConc.V_x_RCarHMIManagementOutput.V_x_PeriVehRecog_MetVecY[3], -128);
    EXPECT_EQ(gOEM_SWC_C2_3URCarHMIManagementDataSet.mConc.V_x_RCarHMIManagementOutput.V_x_PeriVehRecog_MetVecY[4], -128);
    EXPECT_EQ(gOEM_SWC_C1_1URCarHMIManagementDataSet.mConc.V_x_RCarHMIManagementOutput.V_x_PeriVehRecog_MetVecY[4], -128);
    EXPECT_EQ(gOEM_SWC_C2_3URCarHMIManagementDataSet.mConc.V_x_RCarHMIManagementOutput.V_x_PeriVehRecog_MetVecY[5], -128);
    EXPECT_EQ(gOEM_SWC_C1_1URCarHMIManagementDataSet.mConc.V_x_RCarHMIManagementOutput.V_x_PeriVehRecog_MetVecY[5], -128);
    EXPECT_EQ(gOEM_SWC_C2_3URCarHMIManagementDataSet.mConc.V_x_RCarHMIManagementOutput.V_x_PeriVehRecog_MetVecY[6], -128);
    EXPECT_EQ(gOEM_SWC_C1_1URCarHMIManagementDataSet.mConc.V_x_RCarHMIManagementOutput.V_x_PeriVehRecog_MetVecY[6], -128);
    EXPECT_EQ(gOEM_SWC_C2_3URCarHMIManagementDataSet.mConc.V_x_RCarHMIManagementOutput.V_x_PeriVehRecog_MetVecY[7], -128);
    EXPECT_EQ(gOEM_SWC_C1_1URCarHMIManagementDataSet.mConc.V_x_RCarHMIManagementOutput.V_x_PeriVehRecog_MetVecY[7], -128);
    EXPECT_EQ(gOEM_SWC_C2_3URCarHMIManagementDataSet.mConc.V_x_RCarHMIManagementOutput.V_x_PeriVehRecog_MetVecY[8], -128);
    EXPECT_EQ(gOEM_SWC_C1_1URCarHMIManagementDataSet.mConc.V_x_RCarHMIManagementOutput.V_x_PeriVehRecog_MetVecY[8], -128);
    struct _func_V_x_RCarHMIManagementOutput_VehStatus_In_1 {
        static void verify(void) {
#include "Rte_Wrapper_VehStatus_In.h"
            V_x_RCarHMIManagementOutput tmp_RCarHMIManagementOutput;
            Rte_Read_V_x_RCarHMIManagementOutput_V_x_RCarHMIManagementOutput(&tmp_RCarHMIManagementOutput);
            EXPECT_EQ(tmp_RCarHMIManagementOutput.V_x_PeriVehRecog_MetVecY[0], -128);
            EXPECT_EQ(tmp_RCarHMIManagementOutput.V_x_PeriVehRecog_MetVecY[1], -128);
            EXPECT_EQ(tmp_RCarHMIManagementOutput.V_x_PeriVehRecog_MetVecY[2], -128);
            EXPECT_EQ(tmp_RCarHMIManagementOutput.V_x_PeriVehRecog_MetVecY[3], -128);
            EXPECT_EQ(tmp_RCarHMIManagementOutput.V_x_PeriVehRecog_MetVecY[4], -128);
            EXPECT_EQ(tmp_RCarHMIManagementOutput.V_x_PeriVehRecog_MetVecY[5], -128);
            EXPECT_EQ(tmp_RCarHMIManagementOutput.V_x_PeriVehRecog_MetVecY[6], -128);
            EXPECT_EQ(tmp_RCarHMIManagementOutput.V_x_PeriVehRecog_MetVecY[7], -128);
            EXPECT_EQ(tmp_RCarHMIManagementOutput.V_x_PeriVehRecog_MetVecY[8], -128);
        }
    } func_V_x_RCarHMIManagementOutput_VehStatus_In_1;
    func_V_x_RCarHMIManagementOutput_VehStatus_In_1.verify();

    extern URCarHMIManagementDataSet gOEM_SWC_C1_1URCarHMIManagementDataSet;
    EXPECT_EQ(gOEM_SWC_C2_3URCarHMIManagementDataSet.mConc.V_x_RCarHMIManagementOutput.V_x_PeriVehRecog_MetVecType[0], 0);
    EXPECT_EQ(gOEM_SWC_C1_1URCarHMIManagementDataSet.mConc.V_x_RCarHMIManagementOutput.V_x_PeriVehRecog_MetVecType[0], 0);
    EXPECT_EQ(gOEM_SWC_C2_3URCarHMIManagementDataSet.mConc.V_x_RCarHMIManagementOutput.V_x_PeriVehRecog_MetVecType[1], 0);
    EXPECT_EQ(gOEM_SWC_C1_1URCarHMIManagementDataSet.mConc.V_x_RCarHMIManagementOutput.V_x_PeriVehRecog_MetVecType[1], 0);
    EXPECT_EQ(gOEM_SWC_C2_3URCarHMIManagementDataSet.mConc.V_x_RCarHMIManagementOutput.V_x_PeriVehRecog_MetVecType[2], 0);
    EXPECT_EQ(gOEM_SWC_C1_1URCarHMIManagementDataSet.mConc.V_x_RCarHMIManagementOutput.V_x_PeriVehRecog_MetVecType[2], 0);
    EXPECT_EQ(gOEM_SWC_C2_3URCarHMIManagementDataSet.mConc.V_x_RCarHMIManagementOutput.V_x_PeriVehRecog_MetVecType[3], 0);
    EXPECT_EQ(gOEM_SWC_C1_1URCarHMIManagementDataSet.mConc.V_x_RCarHMIManagementOutput.V_x_PeriVehRecog_MetVecType[3], 0);
    EXPECT_EQ(gOEM_SWC_C2_3URCarHMIManagementDataSet.mConc.V_x_RCarHMIManagementOutput.V_x_PeriVehRecog_MetVecType[4], 0);
    EXPECT_EQ(gOEM_SWC_C1_1URCarHMIManagementDataSet.mConc.V_x_RCarHMIManagementOutput.V_x_PeriVehRecog_MetVecType[4], 0);
    EXPECT_EQ(gOEM_SWC_C2_3URCarHMIManagementDataSet.mConc.V_x_RCarHMIManagementOutput.V_x_PeriVehRecog_MetVecType[5], 0);
    EXPECT_EQ(gOEM_SWC_C1_1URCarHMIManagementDataSet.mConc.V_x_RCarHMIManagementOutput.V_x_PeriVehRecog_MetVecType[5], 0);
    EXPECT_EQ(gOEM_SWC_C2_3URCarHMIManagementDataSet.mConc.V_x_RCarHMIManagementOutput.V_x_PeriVehRecog_MetVecType[6], 0);
    EXPECT_EQ(gOEM_SWC_C1_1URCarHMIManagementDataSet.mConc.V_x_RCarHMIManagementOutput.V_x_PeriVehRecog_MetVecType[6], 0);
    EXPECT_EQ(gOEM_SWC_C2_3URCarHMIManagementDataSet.mConc.V_x_RCarHMIManagementOutput.V_x_PeriVehRecog_MetVecType[7], 0);
    EXPECT_EQ(gOEM_SWC_C1_1URCarHMIManagementDataSet.mConc.V_x_RCarHMIManagementOutput.V_x_PeriVehRecog_MetVecType[7], 0);
    EXPECT_EQ(gOEM_SWC_C2_3URCarHMIManagementDataSet.mConc.V_x_RCarHMIManagementOutput.V_x_PeriVehRecog_MetVecType[8], 0);
    EXPECT_EQ(gOEM_SWC_C1_1URCarHMIManagementDataSet.mConc.V_x_RCarHMIManagementOutput.V_x_PeriVehRecog_MetVecType[8], 0);
    struct _func_V_x_RCarHMIManagementOutput_VehStatus_In_2 {
        static void verify(void) {
#include "Rte_Wrapper_VehStatus_In.h"
            V_x_RCarHMIManagementOutput tmp_RCarHMIManagementOutput;
            Rte_Read_V_x_RCarHMIManagementOutput_V_x_RCarHMIManagementOutput(&tmp_RCarHMIManagementOutput);
            EXPECT_EQ(tmp_RCarHMIManagementOutput.V_x_PeriVehRecog_MetVecType[0], 0);
            EXPECT_EQ(tmp_RCarHMIManagementOutput.V_x_PeriVehRecog_MetVecType[1], 0);
            EXPECT_EQ(tmp_RCarHMIManagementOutput.V_x_PeriVehRecog_MetVecType[2], 0);
            EXPECT_EQ(tmp_RCarHMIManagementOutput.V_x_PeriVehRecog_MetVecType[3], 0);
            EXPECT_EQ(tmp_RCarHMIManagementOutput.V_x_PeriVehRecog_MetVecType[4], 0);
            EXPECT_EQ(tmp_RCarHMIManagementOutput.V_x_PeriVehRecog_MetVecType[5], 0);
            EXPECT_EQ(tmp_RCarHMIManagementOutput.V_x_PeriVehRecog_MetVecType[6], 0);
            EXPECT_EQ(tmp_RCarHMIManagementOutput.V_x_PeriVehRecog_MetVecType[7], 0);
            EXPECT_EQ(tmp_RCarHMIManagementOutput.V_x_PeriVehRecog_MetVecType[8], 0);
        }
    } func_V_x_RCarHMIManagementOutput_VehStatus_In_2;
    func_V_x_RCarHMIManagementOutput_VehStatus_In_2.verify();

}

void C2_3_o2o_noncache_min_verify_ObjectSelectionAVM(void)
{
    V_x_ObjectSelectionAVMOutput tmp_ObjectSelectionAVMOutput;

    /* V_x_ObjectSelectionAVMOutput*/
    extern UObjectSelectionAVMDataSet gOEM_SWC_C1_1UObjectSelectionAVMDataSet;
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UObjectSelectionAVMDataSet.mConc.V_x_ObjectSelectionAVMOutput.V_cm_Object1_X, -340282346638528897590636046441678635008);
    EXPECT_FLOAT_EQ(gOEM_SWC_C1_1UObjectSelectionAVMDataSet.mConc.V_x_ObjectSelectionAVMOutput.V_cm_Object1_X, -340282346638528897590636046441678635008);
    struct _func_V_x_ObjectSelectionAVMOutput_VehStatus_In_0 {
        static void verify(void) {
#include "Rte_Wrapper_VehStatus_In.h"
            V_x_ObjectSelectionAVMOutput tmp_ObjectSelectionAVMOutput;
            Rte_Read_V_x_ObjectSelectionAVMOutput_V_x_ObjectSelectionAVMOutput(&tmp_ObjectSelectionAVMOutput);
            EXPECT_FLOAT_EQ(tmp_ObjectSelectionAVMOutput.V_cm_Object1_X, -340282346638528897590636046441678635008);
        }
    } func_V_x_ObjectSelectionAVMOutput_VehStatus_In_0;
    func_V_x_ObjectSelectionAVMOutput_VehStatus_In_0.verify();

    extern UObjectSelectionAVMDataSet gOEM_SWC_C1_1UObjectSelectionAVMDataSet;
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UObjectSelectionAVMDataSet.mConc.V_x_ObjectSelectionAVMOutput.V_cm_Object1_Y, -340282346638528897590636046441678635008);
    EXPECT_FLOAT_EQ(gOEM_SWC_C1_1UObjectSelectionAVMDataSet.mConc.V_x_ObjectSelectionAVMOutput.V_cm_Object1_Y, -340282346638528897590636046441678635008);
    struct _func_V_x_ObjectSelectionAVMOutput_VehStatus_In_1 {
        static void verify(void) {
#include "Rte_Wrapper_VehStatus_In.h"
            V_x_ObjectSelectionAVMOutput tmp_ObjectSelectionAVMOutput;
            Rte_Read_V_x_ObjectSelectionAVMOutput_V_x_ObjectSelectionAVMOutput(&tmp_ObjectSelectionAVMOutput);
            EXPECT_FLOAT_EQ(tmp_ObjectSelectionAVMOutput.V_cm_Object1_Y, -340282346638528897590636046441678635008);
        }
    } func_V_x_ObjectSelectionAVMOutput_VehStatus_In_1;
    func_V_x_ObjectSelectionAVMOutput_VehStatus_In_1.verify();

    extern UObjectSelectionAVMDataSet gOEM_SWC_C1_1UObjectSelectionAVMDataSet;
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UObjectSelectionAVMDataSet.mConc.V_x_ObjectSelectionAVMOutput.V_mps_Object1_Xspeed, -340282346638528897590636046441678635008);
    EXPECT_FLOAT_EQ(gOEM_SWC_C1_1UObjectSelectionAVMDataSet.mConc.V_x_ObjectSelectionAVMOutput.V_mps_Object1_Xspeed, -340282346638528897590636046441678635008);
    struct _func_V_x_ObjectSelectionAVMOutput_VehStatus_In_2 {
        static void verify(void) {
#include "Rte_Wrapper_VehStatus_In.h"
            V_x_ObjectSelectionAVMOutput tmp_ObjectSelectionAVMOutput;
            Rte_Read_V_x_ObjectSelectionAVMOutput_V_x_ObjectSelectionAVMOutput(&tmp_ObjectSelectionAVMOutput);
            EXPECT_FLOAT_EQ(tmp_ObjectSelectionAVMOutput.V_mps_Object1_Xspeed, -340282346638528897590636046441678635008);
        }
    } func_V_x_ObjectSelectionAVMOutput_VehStatus_In_2;
    func_V_x_ObjectSelectionAVMOutput_VehStatus_In_2.verify();

    extern UObjectSelectionAVMDataSet gOEM_SWC_C1_1UObjectSelectionAVMDataSet;
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UObjectSelectionAVMDataSet.mConc.V_x_ObjectSelectionAVMOutput.V_mps_Object1_Yspeed, -340282346638528897590636046441678635008);
    EXPECT_FLOAT_EQ(gOEM_SWC_C1_1UObjectSelectionAVMDataSet.mConc.V_x_ObjectSelectionAVMOutput.V_mps_Object1_Yspeed, -340282346638528897590636046441678635008);
    struct _func_V_x_ObjectSelectionAVMOutput_VehStatus_In_3 {
        static void verify(void) {
#include "Rte_Wrapper_VehStatus_In.h"
            V_x_ObjectSelectionAVMOutput tmp_ObjectSelectionAVMOutput;
            Rte_Read_V_x_ObjectSelectionAVMOutput_V_x_ObjectSelectionAVMOutput(&tmp_ObjectSelectionAVMOutput);
            EXPECT_FLOAT_EQ(tmp_ObjectSelectionAVMOutput.V_mps_Object1_Yspeed, -340282346638528897590636046441678635008);
        }
    } func_V_x_ObjectSelectionAVMOutput_VehStatus_In_3;
    func_V_x_ObjectSelectionAVMOutput_VehStatus_In_3.verify();

    extern UObjectSelectionAVMDataSet gOEM_SWC_C1_1UObjectSelectionAVMDataSet;
    EXPECT_EQ(gOEM_SWC_C2_3UObjectSelectionAVMDataSet.mConc.V_x_ObjectSelectionAVMOutput.V_x_Object1_ID, 0);
    EXPECT_EQ(gOEM_SWC_C1_1UObjectSelectionAVMDataSet.mConc.V_x_ObjectSelectionAVMOutput.V_x_Object1_ID, 0);
    struct _func_V_x_ObjectSelectionAVMOutput_VehStatus_In_4 {
        static void verify(void) {
#include "Rte_Wrapper_VehStatus_In.h"
            V_x_ObjectSelectionAVMOutput tmp_ObjectSelectionAVMOutput;
            Rte_Read_V_x_ObjectSelectionAVMOutput_V_x_ObjectSelectionAVMOutput(&tmp_ObjectSelectionAVMOutput);
            EXPECT_EQ(tmp_ObjectSelectionAVMOutput.V_x_Object1_ID, 0);
        }
    } func_V_x_ObjectSelectionAVMOutput_VehStatus_In_4;
    func_V_x_ObjectSelectionAVMOutput_VehStatus_In_4.verify();

    extern UObjectSelectionAVMDataSet gOEM_SWC_C1_1UObjectSelectionAVMDataSet;
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UObjectSelectionAVMDataSet.mConc.V_x_ObjectSelectionAVMOutput.V_cm_Object2_X, -340282346638528897590636046441678635008);
    EXPECT_FLOAT_EQ(gOEM_SWC_C1_1UObjectSelectionAVMDataSet.mConc.V_x_ObjectSelectionAVMOutput.V_cm_Object2_X, -340282346638528897590636046441678635008);
    struct _func_V_x_ObjectSelectionAVMOutput_VehStatus_In_5 {
        static void verify(void) {
#include "Rte_Wrapper_VehStatus_In.h"
            V_x_ObjectSelectionAVMOutput tmp_ObjectSelectionAVMOutput;
            Rte_Read_V_x_ObjectSelectionAVMOutput_V_x_ObjectSelectionAVMOutput(&tmp_ObjectSelectionAVMOutput);
            EXPECT_FLOAT_EQ(tmp_ObjectSelectionAVMOutput.V_cm_Object2_X, -340282346638528897590636046441678635008);
        }
    } func_V_x_ObjectSelectionAVMOutput_VehStatus_In_5;
    func_V_x_ObjectSelectionAVMOutput_VehStatus_In_5.verify();

    extern UObjectSelectionAVMDataSet gOEM_SWC_C1_1UObjectSelectionAVMDataSet;
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UObjectSelectionAVMDataSet.mConc.V_x_ObjectSelectionAVMOutput.V_cm_Object2_Y, -340282346638528897590636046441678635008);
    EXPECT_FLOAT_EQ(gOEM_SWC_C1_1UObjectSelectionAVMDataSet.mConc.V_x_ObjectSelectionAVMOutput.V_cm_Object2_Y, -340282346638528897590636046441678635008);
    struct _func_V_x_ObjectSelectionAVMOutput_VehStatus_In_6 {
        static void verify(void) {
#include "Rte_Wrapper_VehStatus_In.h"
            V_x_ObjectSelectionAVMOutput tmp_ObjectSelectionAVMOutput;
            Rte_Read_V_x_ObjectSelectionAVMOutput_V_x_ObjectSelectionAVMOutput(&tmp_ObjectSelectionAVMOutput);
            EXPECT_FLOAT_EQ(tmp_ObjectSelectionAVMOutput.V_cm_Object2_Y, -340282346638528897590636046441678635008);
        }
    } func_V_x_ObjectSelectionAVMOutput_VehStatus_In_6;
    func_V_x_ObjectSelectionAVMOutput_VehStatus_In_6.verify();

    extern UObjectSelectionAVMDataSet gOEM_SWC_C1_1UObjectSelectionAVMDataSet;
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UObjectSelectionAVMDataSet.mConc.V_x_ObjectSelectionAVMOutput.V_mps_Object2_Xspeed, -340282346638528897590636046441678635008);
    EXPECT_FLOAT_EQ(gOEM_SWC_C1_1UObjectSelectionAVMDataSet.mConc.V_x_ObjectSelectionAVMOutput.V_mps_Object2_Xspeed, -340282346638528897590636046441678635008);
    struct _func_V_x_ObjectSelectionAVMOutput_VehStatus_In_7 {
        static void verify(void) {
#include "Rte_Wrapper_VehStatus_In.h"
            V_x_ObjectSelectionAVMOutput tmp_ObjectSelectionAVMOutput;
            Rte_Read_V_x_ObjectSelectionAVMOutput_V_x_ObjectSelectionAVMOutput(&tmp_ObjectSelectionAVMOutput);
            EXPECT_FLOAT_EQ(tmp_ObjectSelectionAVMOutput.V_mps_Object2_Xspeed, -340282346638528897590636046441678635008);
        }
    } func_V_x_ObjectSelectionAVMOutput_VehStatus_In_7;
    func_V_x_ObjectSelectionAVMOutput_VehStatus_In_7.verify();

    extern UObjectSelectionAVMDataSet gOEM_SWC_C1_1UObjectSelectionAVMDataSet;
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UObjectSelectionAVMDataSet.mConc.V_x_ObjectSelectionAVMOutput.V_mps_Object2_Yspeed, -340282346638528897590636046441678635008);
    EXPECT_FLOAT_EQ(gOEM_SWC_C1_1UObjectSelectionAVMDataSet.mConc.V_x_ObjectSelectionAVMOutput.V_mps_Object2_Yspeed, -340282346638528897590636046441678635008);
    struct _func_V_x_ObjectSelectionAVMOutput_VehStatus_In_8 {
        static void verify(void) {
#include "Rte_Wrapper_VehStatus_In.h"
            V_x_ObjectSelectionAVMOutput tmp_ObjectSelectionAVMOutput;
            Rte_Read_V_x_ObjectSelectionAVMOutput_V_x_ObjectSelectionAVMOutput(&tmp_ObjectSelectionAVMOutput);
            EXPECT_FLOAT_EQ(tmp_ObjectSelectionAVMOutput.V_mps_Object2_Yspeed, -340282346638528897590636046441678635008);
        }
    } func_V_x_ObjectSelectionAVMOutput_VehStatus_In_8;
    func_V_x_ObjectSelectionAVMOutput_VehStatus_In_8.verify();

    extern UObjectSelectionAVMDataSet gOEM_SWC_C1_1UObjectSelectionAVMDataSet;
    EXPECT_EQ(gOEM_SWC_C2_3UObjectSelectionAVMDataSet.mConc.V_x_ObjectSelectionAVMOutput.V_x_Object2_ID, 0);
    EXPECT_EQ(gOEM_SWC_C1_1UObjectSelectionAVMDataSet.mConc.V_x_ObjectSelectionAVMOutput.V_x_Object2_ID, 0);
    struct _func_V_x_ObjectSelectionAVMOutput_VehStatus_In_9 {
        static void verify(void) {
#include "Rte_Wrapper_VehStatus_In.h"
            V_x_ObjectSelectionAVMOutput tmp_ObjectSelectionAVMOutput;
            Rte_Read_V_x_ObjectSelectionAVMOutput_V_x_ObjectSelectionAVMOutput(&tmp_ObjectSelectionAVMOutput);
            EXPECT_EQ(tmp_ObjectSelectionAVMOutput.V_x_Object2_ID, 0);
        }
    } func_V_x_ObjectSelectionAVMOutput_VehStatus_In_9;
    func_V_x_ObjectSelectionAVMOutput_VehStatus_In_9.verify();

    extern UObjectSelectionAVMDataSet gOEM_SWC_C1_1UObjectSelectionAVMDataSet;
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UObjectSelectionAVMDataSet.mConc.V_x_ObjectSelectionAVMOutput.V_cm_Object3_X, -340282346638528897590636046441678635008);
    EXPECT_FLOAT_EQ(gOEM_SWC_C1_1UObjectSelectionAVMDataSet.mConc.V_x_ObjectSelectionAVMOutput.V_cm_Object3_X, -340282346638528897590636046441678635008);
    struct _func_V_x_ObjectSelectionAVMOutput_VehStatus_In_10 {
        static void verify(void) {
#include "Rte_Wrapper_VehStatus_In.h"
            V_x_ObjectSelectionAVMOutput tmp_ObjectSelectionAVMOutput;
            Rte_Read_V_x_ObjectSelectionAVMOutput_V_x_ObjectSelectionAVMOutput(&tmp_ObjectSelectionAVMOutput);
            EXPECT_FLOAT_EQ(tmp_ObjectSelectionAVMOutput.V_cm_Object3_X, -340282346638528897590636046441678635008);
        }
    } func_V_x_ObjectSelectionAVMOutput_VehStatus_In_10;
    func_V_x_ObjectSelectionAVMOutput_VehStatus_In_10.verify();

    extern UObjectSelectionAVMDataSet gOEM_SWC_C1_1UObjectSelectionAVMDataSet;
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UObjectSelectionAVMDataSet.mConc.V_x_ObjectSelectionAVMOutput.V_cm_Object3_Y, -340282346638528897590636046441678635008);
    EXPECT_FLOAT_EQ(gOEM_SWC_C1_1UObjectSelectionAVMDataSet.mConc.V_x_ObjectSelectionAVMOutput.V_cm_Object3_Y, -340282346638528897590636046441678635008);
    struct _func_V_x_ObjectSelectionAVMOutput_VehStatus_In_11 {
        static void verify(void) {
#include "Rte_Wrapper_VehStatus_In.h"
            V_x_ObjectSelectionAVMOutput tmp_ObjectSelectionAVMOutput;
            Rte_Read_V_x_ObjectSelectionAVMOutput_V_x_ObjectSelectionAVMOutput(&tmp_ObjectSelectionAVMOutput);
            EXPECT_FLOAT_EQ(tmp_ObjectSelectionAVMOutput.V_cm_Object3_Y, -340282346638528897590636046441678635008);
        }
    } func_V_x_ObjectSelectionAVMOutput_VehStatus_In_11;
    func_V_x_ObjectSelectionAVMOutput_VehStatus_In_11.verify();

    extern UObjectSelectionAVMDataSet gOEM_SWC_C1_1UObjectSelectionAVMDataSet;
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UObjectSelectionAVMDataSet.mConc.V_x_ObjectSelectionAVMOutput.V_mps_Object3_Xspeed, -340282346638528897590636046441678635008);
    EXPECT_FLOAT_EQ(gOEM_SWC_C1_1UObjectSelectionAVMDataSet.mConc.V_x_ObjectSelectionAVMOutput.V_mps_Object3_Xspeed, -340282346638528897590636046441678635008);
    struct _func_V_x_ObjectSelectionAVMOutput_VehStatus_In_12 {
        static void verify(void) {
#include "Rte_Wrapper_VehStatus_In.h"
            V_x_ObjectSelectionAVMOutput tmp_ObjectSelectionAVMOutput;
            Rte_Read_V_x_ObjectSelectionAVMOutput_V_x_ObjectSelectionAVMOutput(&tmp_ObjectSelectionAVMOutput);
            EXPECT_FLOAT_EQ(tmp_ObjectSelectionAVMOutput.V_mps_Object3_Xspeed, -340282346638528897590636046441678635008);
        }
    } func_V_x_ObjectSelectionAVMOutput_VehStatus_In_12;
    func_V_x_ObjectSelectionAVMOutput_VehStatus_In_12.verify();

    extern UObjectSelectionAVMDataSet gOEM_SWC_C1_1UObjectSelectionAVMDataSet;
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UObjectSelectionAVMDataSet.mConc.V_x_ObjectSelectionAVMOutput.V_mps_Object3_Yspeed, -340282346638528897590636046441678635008);
    EXPECT_FLOAT_EQ(gOEM_SWC_C1_1UObjectSelectionAVMDataSet.mConc.V_x_ObjectSelectionAVMOutput.V_mps_Object3_Yspeed, -340282346638528897590636046441678635008);
    struct _func_V_x_ObjectSelectionAVMOutput_VehStatus_In_13 {
        static void verify(void) {
#include "Rte_Wrapper_VehStatus_In.h"
            V_x_ObjectSelectionAVMOutput tmp_ObjectSelectionAVMOutput;
            Rte_Read_V_x_ObjectSelectionAVMOutput_V_x_ObjectSelectionAVMOutput(&tmp_ObjectSelectionAVMOutput);
            EXPECT_FLOAT_EQ(tmp_ObjectSelectionAVMOutput.V_mps_Object3_Yspeed, -340282346638528897590636046441678635008);
        }
    } func_V_x_ObjectSelectionAVMOutput_VehStatus_In_13;
    func_V_x_ObjectSelectionAVMOutput_VehStatus_In_13.verify();

    extern UObjectSelectionAVMDataSet gOEM_SWC_C1_1UObjectSelectionAVMDataSet;
    EXPECT_EQ(gOEM_SWC_C2_3UObjectSelectionAVMDataSet.mConc.V_x_ObjectSelectionAVMOutput.V_x_Object3_ID, 0);
    EXPECT_EQ(gOEM_SWC_C1_1UObjectSelectionAVMDataSet.mConc.V_x_ObjectSelectionAVMOutput.V_x_Object3_ID, 0);
    struct _func_V_x_ObjectSelectionAVMOutput_VehStatus_In_14 {
        static void verify(void) {
#include "Rte_Wrapper_VehStatus_In.h"
            V_x_ObjectSelectionAVMOutput tmp_ObjectSelectionAVMOutput;
            Rte_Read_V_x_ObjectSelectionAVMOutput_V_x_ObjectSelectionAVMOutput(&tmp_ObjectSelectionAVMOutput);
            EXPECT_EQ(tmp_ObjectSelectionAVMOutput.V_x_Object3_ID, 0);
        }
    } func_V_x_ObjectSelectionAVMOutput_VehStatus_In_14;
    func_V_x_ObjectSelectionAVMOutput_VehStatus_In_14.verify();

    extern UObjectSelectionAVMDataSet gOEM_SWC_C1_1UObjectSelectionAVMDataSet;
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UObjectSelectionAVMDataSet.mConc.V_x_ObjectSelectionAVMOutput.V_cm_Object4_X, -340282346638528897590636046441678635008);
    EXPECT_FLOAT_EQ(gOEM_SWC_C1_1UObjectSelectionAVMDataSet.mConc.V_x_ObjectSelectionAVMOutput.V_cm_Object4_X, -340282346638528897590636046441678635008);
    struct _func_V_x_ObjectSelectionAVMOutput_VehStatus_In_15 {
        static void verify(void) {
#include "Rte_Wrapper_VehStatus_In.h"
            V_x_ObjectSelectionAVMOutput tmp_ObjectSelectionAVMOutput;
            Rte_Read_V_x_ObjectSelectionAVMOutput_V_x_ObjectSelectionAVMOutput(&tmp_ObjectSelectionAVMOutput);
            EXPECT_FLOAT_EQ(tmp_ObjectSelectionAVMOutput.V_cm_Object4_X, -340282346638528897590636046441678635008);
        }
    } func_V_x_ObjectSelectionAVMOutput_VehStatus_In_15;
    func_V_x_ObjectSelectionAVMOutput_VehStatus_In_15.verify();

    extern UObjectSelectionAVMDataSet gOEM_SWC_C1_1UObjectSelectionAVMDataSet;
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UObjectSelectionAVMDataSet.mConc.V_x_ObjectSelectionAVMOutput.V_cm_Object4_Y, -340282346638528897590636046441678635008);
    EXPECT_FLOAT_EQ(gOEM_SWC_C1_1UObjectSelectionAVMDataSet.mConc.V_x_ObjectSelectionAVMOutput.V_cm_Object4_Y, -340282346638528897590636046441678635008);
    struct _func_V_x_ObjectSelectionAVMOutput_VehStatus_In_16 {
        static void verify(void) {
#include "Rte_Wrapper_VehStatus_In.h"
            V_x_ObjectSelectionAVMOutput tmp_ObjectSelectionAVMOutput;
            Rte_Read_V_x_ObjectSelectionAVMOutput_V_x_ObjectSelectionAVMOutput(&tmp_ObjectSelectionAVMOutput);
            EXPECT_FLOAT_EQ(tmp_ObjectSelectionAVMOutput.V_cm_Object4_Y, -340282346638528897590636046441678635008);
        }
    } func_V_x_ObjectSelectionAVMOutput_VehStatus_In_16;
    func_V_x_ObjectSelectionAVMOutput_VehStatus_In_16.verify();

    extern UObjectSelectionAVMDataSet gOEM_SWC_C1_1UObjectSelectionAVMDataSet;
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UObjectSelectionAVMDataSet.mConc.V_x_ObjectSelectionAVMOutput.V_mps_Object4_Xspeed, -340282346638528897590636046441678635008);
    EXPECT_FLOAT_EQ(gOEM_SWC_C1_1UObjectSelectionAVMDataSet.mConc.V_x_ObjectSelectionAVMOutput.V_mps_Object4_Xspeed, -340282346638528897590636046441678635008);
    struct _func_V_x_ObjectSelectionAVMOutput_VehStatus_In_17 {
        static void verify(void) {
#include "Rte_Wrapper_VehStatus_In.h"
            V_x_ObjectSelectionAVMOutput tmp_ObjectSelectionAVMOutput;
            Rte_Read_V_x_ObjectSelectionAVMOutput_V_x_ObjectSelectionAVMOutput(&tmp_ObjectSelectionAVMOutput);
            EXPECT_FLOAT_EQ(tmp_ObjectSelectionAVMOutput.V_mps_Object4_Xspeed, -340282346638528897590636046441678635008);
        }
    } func_V_x_ObjectSelectionAVMOutput_VehStatus_In_17;
    func_V_x_ObjectSelectionAVMOutput_VehStatus_In_17.verify();

    extern UObjectSelectionAVMDataSet gOEM_SWC_C1_1UObjectSelectionAVMDataSet;
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UObjectSelectionAVMDataSet.mConc.V_x_ObjectSelectionAVMOutput.V_mps_Object4_Yspeed, -340282346638528897590636046441678635008);
    EXPECT_FLOAT_EQ(gOEM_SWC_C1_1UObjectSelectionAVMDataSet.mConc.V_x_ObjectSelectionAVMOutput.V_mps_Object4_Yspeed, -340282346638528897590636046441678635008);
    struct _func_V_x_ObjectSelectionAVMOutput_VehStatus_In_18 {
        static void verify(void) {
#include "Rte_Wrapper_VehStatus_In.h"
            V_x_ObjectSelectionAVMOutput tmp_ObjectSelectionAVMOutput;
            Rte_Read_V_x_ObjectSelectionAVMOutput_V_x_ObjectSelectionAVMOutput(&tmp_ObjectSelectionAVMOutput);
            EXPECT_FLOAT_EQ(tmp_ObjectSelectionAVMOutput.V_mps_Object4_Yspeed, -340282346638528897590636046441678635008);
        }
    } func_V_x_ObjectSelectionAVMOutput_VehStatus_In_18;
    func_V_x_ObjectSelectionAVMOutput_VehStatus_In_18.verify();

    extern UObjectSelectionAVMDataSet gOEM_SWC_C1_1UObjectSelectionAVMDataSet;
    EXPECT_EQ(gOEM_SWC_C2_3UObjectSelectionAVMDataSet.mConc.V_x_ObjectSelectionAVMOutput.V_x_Object4_ID, 0);
    EXPECT_EQ(gOEM_SWC_C1_1UObjectSelectionAVMDataSet.mConc.V_x_ObjectSelectionAVMOutput.V_x_Object4_ID, 0);
    struct _func_V_x_ObjectSelectionAVMOutput_VehStatus_In_19 {
        static void verify(void) {
#include "Rte_Wrapper_VehStatus_In.h"
            V_x_ObjectSelectionAVMOutput tmp_ObjectSelectionAVMOutput;
            Rte_Read_V_x_ObjectSelectionAVMOutput_V_x_ObjectSelectionAVMOutput(&tmp_ObjectSelectionAVMOutput);
            EXPECT_EQ(tmp_ObjectSelectionAVMOutput.V_x_Object4_ID, 0);
        }
    } func_V_x_ObjectSelectionAVMOutput_VehStatus_In_19;
    func_V_x_ObjectSelectionAVMOutput_VehStatus_In_19.verify();

    extern UObjectSelectionAVMDataSet gOEM_SWC_C1_1UObjectSelectionAVMDataSet;
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UObjectSelectionAVMDataSet.mConc.V_x_ObjectSelectionAVMOutput.V_cm_Object5_X, -340282346638528897590636046441678635008);
    EXPECT_FLOAT_EQ(gOEM_SWC_C1_1UObjectSelectionAVMDataSet.mConc.V_x_ObjectSelectionAVMOutput.V_cm_Object5_X, -340282346638528897590636046441678635008);
    struct _func_V_x_ObjectSelectionAVMOutput_VehStatus_In_20 {
        static void verify(void) {
#include "Rte_Wrapper_VehStatus_In.h"
            V_x_ObjectSelectionAVMOutput tmp_ObjectSelectionAVMOutput;
            Rte_Read_V_x_ObjectSelectionAVMOutput_V_x_ObjectSelectionAVMOutput(&tmp_ObjectSelectionAVMOutput);
            EXPECT_FLOAT_EQ(tmp_ObjectSelectionAVMOutput.V_cm_Object5_X, -340282346638528897590636046441678635008);
        }
    } func_V_x_ObjectSelectionAVMOutput_VehStatus_In_20;
    func_V_x_ObjectSelectionAVMOutput_VehStatus_In_20.verify();

    extern UObjectSelectionAVMDataSet gOEM_SWC_C1_1UObjectSelectionAVMDataSet;
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UObjectSelectionAVMDataSet.mConc.V_x_ObjectSelectionAVMOutput.V_cm_Object5_Y, -340282346638528897590636046441678635008);
    EXPECT_FLOAT_EQ(gOEM_SWC_C1_1UObjectSelectionAVMDataSet.mConc.V_x_ObjectSelectionAVMOutput.V_cm_Object5_Y, -340282346638528897590636046441678635008);
    struct _func_V_x_ObjectSelectionAVMOutput_VehStatus_In_21 {
        static void verify(void) {
#include "Rte_Wrapper_VehStatus_In.h"
            V_x_ObjectSelectionAVMOutput tmp_ObjectSelectionAVMOutput;
            Rte_Read_V_x_ObjectSelectionAVMOutput_V_x_ObjectSelectionAVMOutput(&tmp_ObjectSelectionAVMOutput);
            EXPECT_FLOAT_EQ(tmp_ObjectSelectionAVMOutput.V_cm_Object5_Y, -340282346638528897590636046441678635008);
        }
    } func_V_x_ObjectSelectionAVMOutput_VehStatus_In_21;
    func_V_x_ObjectSelectionAVMOutput_VehStatus_In_21.verify();

    extern UObjectSelectionAVMDataSet gOEM_SWC_C1_1UObjectSelectionAVMDataSet;
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UObjectSelectionAVMDataSet.mConc.V_x_ObjectSelectionAVMOutput.V_mps_Object5_Xspeed, -340282346638528897590636046441678635008);
    EXPECT_FLOAT_EQ(gOEM_SWC_C1_1UObjectSelectionAVMDataSet.mConc.V_x_ObjectSelectionAVMOutput.V_mps_Object5_Xspeed, -340282346638528897590636046441678635008);
    struct _func_V_x_ObjectSelectionAVMOutput_VehStatus_In_22 {
        static void verify(void) {
#include "Rte_Wrapper_VehStatus_In.h"
            V_x_ObjectSelectionAVMOutput tmp_ObjectSelectionAVMOutput;
            Rte_Read_V_x_ObjectSelectionAVMOutput_V_x_ObjectSelectionAVMOutput(&tmp_ObjectSelectionAVMOutput);
            EXPECT_FLOAT_EQ(tmp_ObjectSelectionAVMOutput.V_mps_Object5_Xspeed, -340282346638528897590636046441678635008);
        }
    } func_V_x_ObjectSelectionAVMOutput_VehStatus_In_22;
    func_V_x_ObjectSelectionAVMOutput_VehStatus_In_22.verify();

    extern UObjectSelectionAVMDataSet gOEM_SWC_C1_1UObjectSelectionAVMDataSet;
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UObjectSelectionAVMDataSet.mConc.V_x_ObjectSelectionAVMOutput.V_mps_Object5_Yspeed, -340282346638528897590636046441678635008);
    EXPECT_FLOAT_EQ(gOEM_SWC_C1_1UObjectSelectionAVMDataSet.mConc.V_x_ObjectSelectionAVMOutput.V_mps_Object5_Yspeed, -340282346638528897590636046441678635008);
    struct _func_V_x_ObjectSelectionAVMOutput_VehStatus_In_23 {
        static void verify(void) {
#include "Rte_Wrapper_VehStatus_In.h"
            V_x_ObjectSelectionAVMOutput tmp_ObjectSelectionAVMOutput;
            Rte_Read_V_x_ObjectSelectionAVMOutput_V_x_ObjectSelectionAVMOutput(&tmp_ObjectSelectionAVMOutput);
            EXPECT_FLOAT_EQ(tmp_ObjectSelectionAVMOutput.V_mps_Object5_Yspeed, -340282346638528897590636046441678635008);
        }
    } func_V_x_ObjectSelectionAVMOutput_VehStatus_In_23;
    func_V_x_ObjectSelectionAVMOutput_VehStatus_In_23.verify();

    extern UObjectSelectionAVMDataSet gOEM_SWC_C1_1UObjectSelectionAVMDataSet;
    EXPECT_EQ(gOEM_SWC_C2_3UObjectSelectionAVMDataSet.mConc.V_x_ObjectSelectionAVMOutput.V_x_Object5_ID, 0);
    EXPECT_EQ(gOEM_SWC_C1_1UObjectSelectionAVMDataSet.mConc.V_x_ObjectSelectionAVMOutput.V_x_Object5_ID, 0);
    struct _func_V_x_ObjectSelectionAVMOutput_VehStatus_In_24 {
        static void verify(void) {
#include "Rte_Wrapper_VehStatus_In.h"
            V_x_ObjectSelectionAVMOutput tmp_ObjectSelectionAVMOutput;
            Rte_Read_V_x_ObjectSelectionAVMOutput_V_x_ObjectSelectionAVMOutput(&tmp_ObjectSelectionAVMOutput);
            EXPECT_EQ(tmp_ObjectSelectionAVMOutput.V_x_Object5_ID, 0);
        }
    } func_V_x_ObjectSelectionAVMOutput_VehStatus_In_24;
    func_V_x_ObjectSelectionAVMOutput_VehStatus_In_24.verify();

    extern UObjectSelectionAVMDataSet gOEM_SWC_C1_1UObjectSelectionAVMDataSet;
    EXPECT_EQ(gOEM_SWC_C2_3UObjectSelectionAVMDataSet.mConc.V_x_ObjectSelectionAVMOutput.V_x_DetectionDirection, 0);
    EXPECT_EQ(gOEM_SWC_C1_1UObjectSelectionAVMDataSet.mConc.V_x_ObjectSelectionAVMOutput.V_x_DetectionDirection, 0);
    struct _func_V_x_ObjectSelectionAVMOutput_VehStatus_In_25 {
        static void verify(void) {
#include "Rte_Wrapper_VehStatus_In.h"
            V_x_ObjectSelectionAVMOutput tmp_ObjectSelectionAVMOutput;
            Rte_Read_V_x_ObjectSelectionAVMOutput_V_x_ObjectSelectionAVMOutput(&tmp_ObjectSelectionAVMOutput);
            EXPECT_EQ(tmp_ObjectSelectionAVMOutput.V_x_DetectionDirection, 0);
        }
    } func_V_x_ObjectSelectionAVMOutput_VehStatus_In_25;
    func_V_x_ObjectSelectionAVMOutput_VehStatus_In_25.verify();

}

void C2_3_o2o_noncache_min_verify_VehStatus_In_100(void)
{
    V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
    sint32 tmp_S32;
    V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
    V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;

}
