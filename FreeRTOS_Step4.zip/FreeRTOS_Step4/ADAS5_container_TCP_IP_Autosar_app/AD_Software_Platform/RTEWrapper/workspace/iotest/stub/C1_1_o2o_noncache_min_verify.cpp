#include <limits.h>
#include <float.h>
#include "gtest/gtest.h"
#include "Rte_Union.h"
#include "Platform_Types.h"

extern UDiagControlDataSet gOEM_SWC_C1_1UDiagControlDataSet;
extern UOEM_DIAGDataSet gOEM_SWC_C1_1UOEM_DIAGDataSet;
extern UActivationManagementDataSet gOEM_SWC_C1_1UActivationManagementDataSet;
extern UVehStatus_InDataSet gOEM_SWC_C1_1UVehStatus_InDataSet;
extern UVehStatus_OutDataSet gOEM_SWC_C1_1UVehStatus_OutDataSet;
extern UBRK_ENGDataSet gOEM_SWC_C1_1UBRK_ENGDataSet;
extern UYAWDataSet gOEM_SWC_C1_1UYAWDataSet;
extern UHMIDataSet gOEM_SWC_C1_1UHMIDataSet;
extern UCAM_RADDataSet gOEM_SWC_C1_1UCAM_RADDataSet;
extern UFusionDataSet gOEM_SWC_C1_1UFusionDataSet;
extern UFS_ACTDataSet gOEM_SWC_C1_1UFS_ACTDataSet;
extern UFEBFCWDBADataSet gOEM_SWC_C1_1UFEBFCWDBADataSet;
extern ULDPLDWDataSet gOEM_SWC_C1_1ULDPLDWDataSet;
extern UBSIDataSet gOEM_SWC_C1_1UBSIDataSet;
extern UDAADataSet gOEM_SWC_C1_1UDAADataSet;
extern UEAPDataSet gOEM_SWC_C1_1UEAPDataSet;
extern UControl_LongiDataSet gOEM_SWC_C1_1UControl_LongiDataSet;
extern UControl_LatDataSet gOEM_SWC_C1_1UControl_LatDataSet;
extern UEDRDataSet gOEM_SWC_C1_1UEDRDataSet;
extern UHODDataSet gOEM_SWC_C1_1UHODDataSet;
extern UEHRDataSet gOEM_SWC_C1_1UEHRDataSet;
extern UCASPDataSet gOEM_SWC_C1_1UCASPDataSet;
extern UAPADataSet gOEM_SWC_C1_1UAPADataSet;
extern UNoEntryDataSet gOEM_SWC_C1_1UNoEntryDataSet;
extern ULCDNDataSet gOEM_SWC_C1_1ULCDNDataSet;

void C1_1_o2o_noncache_min_verify_DiagControl(void)
{
    boolean tmp_B;

}

void C1_1_o2o_noncache_min_verify_OEM_DIAG(void)
{
    boolean tmp_B;
    uint16 tmp_U16;

}

void C1_1_o2o_noncache_min_verify_ActivationManagement(void)
{
    boolean tmp_B;
    uint8 tmp_U8;
    sint8 tmp_S8;
    uint8 tmp_U8_16[16];
    uint8 tmp_U8_148[148];
    V_x_VariantManagement tmp_VariantManagement;

}

void C1_1_o2o_noncache_min_verify_VehStatus_In(void)
{
    boolean tmp_B;
    float32 tmp_Fl32;
    sint16 tmp_S16;
    sint32 tmp_S32;
    uint16 tmp_U16;
    uint8 tmp_U8;
    sint8 tmp_S8;
    uint32 tmp_U32;
    float32 tmp_Fl32_20[20];
    uint8 tmp_U8_8[8];
    uint8 tmp_U8_20[20];
    uint8 tmp_U8_9[9];
    sint8 tmp_S8_9[9];

}

void C1_1_o2o_noncache_min_verify_VehStatus_Out(void)
{
    boolean tmp_B;
    sint16 tmp_S16;
    uint16 tmp_U16;
    float32 tmp_Fl32;
    uint8 tmp_U8;
    sint8 tmp_S8;
    uint64 tmp_U64;
    V_x_AutoLCPossibilityJdgInput tmp_AutoLCPossibilityJdgInput;
    V_x_ObjectSelectionAVMInput tmp_ObjectSelectionAVMInput;
    V_x_RCarHMIManagementInput tmp_RCarHMIManagementInput;
    uint32 tmp_U32;
    V_x_SurroundFusionInput tmp_SurroundFusionInput;

    /* V_Nm_AEB_BrakeWheelTorqueRequest2_VSO*/
    extern UVehStatus_OutDataSet gOEM_SWC_C0_SMUVehStatus_OutDataSet;
    EXPECT_EQ(gOEM_SWC_C1_1UVehStatus_OutDataSet.mConc.V_Nm_AEB_BrakeWheelTorqueRequest2_VSO, 0);
    EXPECT_EQ(gOEM_SWC_C0_SMUVehStatus_OutDataSet.mConc.V_Nm_AEB_BrakeWheelTorqueRequest2_VSO, 0);
    struct _func_V_Nm_AEB_BrakeWheelTorqueRequest2_VSO_SafetyModule {
        static void verify(void) {
#include "Rte_Wrapper_SafetyModule.h"
            uint16 tmp_U16;
            Rte_Read_V_Nm_AEB_BrakeWheelTorqueRequest2_VSO_V_Nm_AEB_BrakeWheelTorqueRequest2_VSO(&tmp_U16);
            EXPECT_EQ(tmp_U16, 0);
        }
    } func_V_Nm_AEB_BrakeWheelTorqueRequest2_VSO_SafetyModule;
    func_V_Nm_AEB_BrakeWheelTorqueRequest2_VSO_SafetyModule.verify();

    /* V_Nm_AEB_BrakeWheelTorqueRequest3_VSO*/
    extern UVehStatus_OutDataSet gOEM_SWC_C0_SMUVehStatus_OutDataSet;
    EXPECT_EQ(gOEM_SWC_C1_1UVehStatus_OutDataSet.mConc.V_Nm_AEB_BrakeWheelTorqueRequest3_VSO, 0);
    EXPECT_EQ(gOEM_SWC_C0_SMUVehStatus_OutDataSet.mConc.V_Nm_AEB_BrakeWheelTorqueRequest3_VSO, 0);
    struct _func_V_Nm_AEB_BrakeWheelTorqueRequest3_VSO_SafetyModule {
        static void verify(void) {
#include "Rte_Wrapper_SafetyModule.h"
            uint16 tmp_U16;
            Rte_Read_V_Nm_AEB_BrakeWheelTorqueRequest3_VSO_V_Nm_AEB_BrakeWheelTorqueRequest3_VSO(&tmp_U16);
            EXPECT_EQ(tmp_U16, 0);
        }
    } func_V_Nm_AEB_BrakeWheelTorqueRequest3_VSO_SafetyModule;
    func_V_Nm_AEB_BrakeWheelTorqueRequest3_VSO_SafetyModule.verify();

    /* V_Nm_Global_PWTWheelTorqueRequest_VSO*/
    extern UVehStatus_OutDataSet gOEM_SWC_C0_SMUVehStatus_OutDataSet;
    EXPECT_EQ(gOEM_SWC_C1_1UVehStatus_OutDataSet.mConc.V_Nm_Global_PWTWheelTorqueRequest_VSO, -32768);
    EXPECT_EQ(gOEM_SWC_C0_SMUVehStatus_OutDataSet.mConc.V_Nm_Global_PWTWheelTorqueRequest_VSO, -32768);
    struct _func_V_Nm_Global_PWTWheelTorqueRequest_VSO_SafetyModule {
        static void verify(void) {
#include "Rte_Wrapper_SafetyModule.h"
            sint16 tmp_S16;
            Rte_Read_V_Nm_Global_PWTWheelTorqueRequest_VSO_V_Nm_Global_PWTWheelTorqueRequest_VSO(&tmp_S16);
            EXPECT_EQ(tmp_S16, -32768);
        }
    } func_V_Nm_Global_PWTWheelTorqueRequest_VSO_SafetyModule;
    func_V_Nm_Global_PWTWheelTorqueRequest_VSO_SafetyModule.verify();

    /* V_Nm_PWTWheelTorqueLimitationRequest_VSO*/
    extern UVehStatus_OutDataSet gOEM_SWC_C0_SMUVehStatus_OutDataSet;
    EXPECT_EQ(gOEM_SWC_C1_1UVehStatus_OutDataSet.mConc.V_Nm_PWTWheelTorqueLimitationRequest_VSO, -32768);
    EXPECT_EQ(gOEM_SWC_C0_SMUVehStatus_OutDataSet.mConc.V_Nm_PWTWheelTorqueLimitationRequest_VSO, -32768);
    struct _func_V_Nm_PWTWheelTorqueLimitationRequest_VSO_SafetyModule {
        static void verify(void) {
#include "Rte_Wrapper_SafetyModule.h"
            sint16 tmp_S16;
            Rte_Read_V_Nm_PWTWheelTorqueLimitationRequest_VSO_V_Nm_PWTWheelTorqueLimitationRequest_VSO(&tmp_S16);
            EXPECT_EQ(tmp_S16, -32768);
        }
    } func_V_Nm_PWTWheelTorqueLimitationRequest_VSO_SafetyModule;
    func_V_Nm_PWTWheelTorqueLimitationRequest_VSO_SafetyModule.verify();

    /* V_x_ADmodeStatus_VSO*/
    extern UVehStatus_OutDataSet gOEM_SWC_C0_SMUVehStatus_OutDataSet;
    EXPECT_EQ(gOEM_SWC_C1_1UVehStatus_OutDataSet.mConc.V_x_ADmodeStatus_VSO, -128);
    EXPECT_EQ(gOEM_SWC_C0_SMUVehStatus_OutDataSet.mConc.V_x_ADmodeStatus_VSO, -128);
    struct _func_V_x_ADmodeStatus_VSO_SafetyModule {
        static void verify(void) {
#include "Rte_Wrapper_SafetyModule.h"
            sint8 tmp_S8;
            Rte_Read_V_x_ADmodeStatus_VSO_V_x_ADmodeStatus_VSO(&tmp_S8);
            EXPECT_EQ(tmp_S8, -128);
        }
    } func_V_x_ADmodeStatus_VSO_SafetyModule;
    func_V_x_ADmodeStatus_VSO_SafetyModule.verify();

    /* V_x_AutoLCPossibilityJdgInput*/
    extern UVehStatus_OutDataSet gOEM_SWC_C2_2UVehStatus_OutDataSet;
    EXPECT_FLOAT_EQ(gOEM_SWC_C1_1UVehStatus_OutDataSet.mConc.V_x_AutoLCPossibilityJdgInput.V_x_vehicle_status.V_mps_VSP_LPF, -340282346638528897590636046441678635008);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_OutDataSet.mConc.V_x_AutoLCPossibilityJdgInput.V_x_vehicle_status.V_mps_VSP_LPF, -340282346638528897590636046441678635008);
    struct _func_V_x_AutoLCPossibilityJdgInput_AutoLCPossibilityJdg_0 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_AutoLCPossibilityJdgInput tmp_AutoLCPossibilityJdgInput;
            Rte_Read_V_x_AutoLCPossibilityJdgInput_V_x_AutoLCPossibilityJdgInput(&tmp_AutoLCPossibilityJdgInput);
            EXPECT_FLOAT_EQ(tmp_AutoLCPossibilityJdgInput.V_x_vehicle_status.V_mps_VSP_LPF, -340282346638528897590636046441678635008);
        }
    } func_V_x_AutoLCPossibilityJdgInput_AutoLCPossibilityJdg_0;
    func_V_x_AutoLCPossibilityJdgInput_AutoLCPossibilityJdg_0.verify();

    extern UVehStatus_OutDataSet gOEM_SWC_C2_2UVehStatus_OutDataSet;
    EXPECT_FLOAT_EQ(gOEM_SWC_C1_1UVehStatus_OutDataSet.mConc.V_x_AutoLCPossibilityJdgInput.V_x_vehicle_status.V_mps_AVE_VSP, -340282346638528897590636046441678635008);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_OutDataSet.mConc.V_x_AutoLCPossibilityJdgInput.V_x_vehicle_status.V_mps_AVE_VSP, -340282346638528897590636046441678635008);
    struct _func_V_x_AutoLCPossibilityJdgInput_AutoLCPossibilityJdg_1 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_AutoLCPossibilityJdgInput tmp_AutoLCPossibilityJdgInput;
            Rte_Read_V_x_AutoLCPossibilityJdgInput_V_x_AutoLCPossibilityJdgInput(&tmp_AutoLCPossibilityJdgInput);
            EXPECT_FLOAT_EQ(tmp_AutoLCPossibilityJdgInput.V_x_vehicle_status.V_mps_AVE_VSP, -340282346638528897590636046441678635008);
        }
    } func_V_x_AutoLCPossibilityJdgInput_AutoLCPossibilityJdg_1;
    func_V_x_AutoLCPossibilityJdgInput_AutoLCPossibilityJdg_1.verify();

    extern UVehStatus_OutDataSet gOEM_SWC_C2_2UVehStatus_OutDataSet;
    EXPECT_EQ(gOEM_SWC_C1_1UVehStatus_OutDataSet.mConc.V_x_AutoLCPossibilityJdgInput.V_x_vehicle_status.V_x_RangeIndication, 0);
    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_OutDataSet.mConc.V_x_AutoLCPossibilityJdgInput.V_x_vehicle_status.V_x_RangeIndication, 0);
    struct _func_V_x_AutoLCPossibilityJdgInput_AutoLCPossibilityJdg_2 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_AutoLCPossibilityJdgInput tmp_AutoLCPossibilityJdgInput;
            Rte_Read_V_x_AutoLCPossibilityJdgInput_V_x_AutoLCPossibilityJdgInput(&tmp_AutoLCPossibilityJdgInput);
            EXPECT_EQ(tmp_AutoLCPossibilityJdgInput.V_x_vehicle_status.V_x_RangeIndication, 0);
        }
    } func_V_x_AutoLCPossibilityJdgInput_AutoLCPossibilityJdg_2;
    func_V_x_AutoLCPossibilityJdgInput_AutoLCPossibilityJdg_2.verify();

    extern UVehStatus_OutDataSet gOEM_SWC_C2_2UVehStatus_OutDataSet;
    EXPECT_EQ(gOEM_SWC_C1_1UVehStatus_OutDataSet.mConc.V_x_AutoLCPossibilityJdgInput.V_x_vehicle_status.F_x_CancelButton, 0);
    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_OutDataSet.mConc.V_x_AutoLCPossibilityJdgInput.V_x_vehicle_status.F_x_CancelButton, 0);
    struct _func_V_x_AutoLCPossibilityJdgInput_AutoLCPossibilityJdg_3 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_AutoLCPossibilityJdgInput tmp_AutoLCPossibilityJdgInput;
            Rte_Read_V_x_AutoLCPossibilityJdgInput_V_x_AutoLCPossibilityJdgInput(&tmp_AutoLCPossibilityJdgInput);
            EXPECT_EQ(tmp_AutoLCPossibilityJdgInput.V_x_vehicle_status.F_x_CancelButton, 0);
        }
    } func_V_x_AutoLCPossibilityJdgInput_AutoLCPossibilityJdg_3;
    func_V_x_AutoLCPossibilityJdgInput_AutoLCPossibilityJdg_3.verify();

    extern UVehStatus_OutDataSet gOEM_SWC_C2_2UVehStatus_OutDataSet;
    EXPECT_EQ(gOEM_SWC_C1_1UVehStatus_OutDataSet.mConc.V_x_AutoLCPossibilityJdgInput.V_x_vehicle_status.F_x_MainSwOn4, 0);
    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_OutDataSet.mConc.V_x_AutoLCPossibilityJdgInput.V_x_vehicle_status.F_x_MainSwOn4, 0);
    struct _func_V_x_AutoLCPossibilityJdgInput_AutoLCPossibilityJdg_4 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_AutoLCPossibilityJdgInput tmp_AutoLCPossibilityJdgInput;
            Rte_Read_V_x_AutoLCPossibilityJdgInput_V_x_AutoLCPossibilityJdgInput(&tmp_AutoLCPossibilityJdgInput);
            EXPECT_EQ(tmp_AutoLCPossibilityJdgInput.V_x_vehicle_status.F_x_MainSwOn4, 0);
        }
    } func_V_x_AutoLCPossibilityJdgInput_AutoLCPossibilityJdg_4;
    func_V_x_AutoLCPossibilityJdgInput_AutoLCPossibilityJdg_4.verify();

    extern UVehStatus_OutDataSet gOEM_SWC_C2_2UVehStatus_OutDataSet;
    EXPECT_FLOAT_EQ(gOEM_SWC_C1_1UVehStatus_OutDataSet.mConc.V_x_AutoLCPossibilityJdgInput.V_x_vehicle_status.V_deg_EPS_AngleSensor, -340282346638528897590636046441678635008);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_OutDataSet.mConc.V_x_AutoLCPossibilityJdgInput.V_x_vehicle_status.V_deg_EPS_AngleSensor, -340282346638528897590636046441678635008);
    struct _func_V_x_AutoLCPossibilityJdgInput_AutoLCPossibilityJdg_5 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_AutoLCPossibilityJdgInput tmp_AutoLCPossibilityJdgInput;
            Rte_Read_V_x_AutoLCPossibilityJdgInput_V_x_AutoLCPossibilityJdgInput(&tmp_AutoLCPossibilityJdgInput);
            EXPECT_FLOAT_EQ(tmp_AutoLCPossibilityJdgInput.V_x_vehicle_status.V_deg_EPS_AngleSensor, -340282346638528897590636046441678635008);
        }
    } func_V_x_AutoLCPossibilityJdgInput_AutoLCPossibilityJdg_5;
    func_V_x_AutoLCPossibilityJdgInput_AutoLCPossibilityJdg_5.verify();

    extern UVehStatus_OutDataSet gOEM_SWC_C2_2UVehStatus_OutDataSet;
    EXPECT_FLOAT_EQ(gOEM_SWC_C1_1UVehStatus_OutDataSet.mConc.V_x_AutoLCPossibilityJdgInput.V_x_vehicle_status.V_deg_SteeringWheelAngleRaw, -340282346638528897590636046441678635008);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_OutDataSet.mConc.V_x_AutoLCPossibilityJdgInput.V_x_vehicle_status.V_deg_SteeringWheelAngleRaw, -340282346638528897590636046441678635008);
    struct _func_V_x_AutoLCPossibilityJdgInput_AutoLCPossibilityJdg_6 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_AutoLCPossibilityJdgInput tmp_AutoLCPossibilityJdgInput;
            Rte_Read_V_x_AutoLCPossibilityJdgInput_V_x_AutoLCPossibilityJdgInput(&tmp_AutoLCPossibilityJdgInput);
            EXPECT_FLOAT_EQ(tmp_AutoLCPossibilityJdgInput.V_x_vehicle_status.V_deg_SteeringWheelAngleRaw, -340282346638528897590636046441678635008);
        }
    } func_V_x_AutoLCPossibilityJdgInput_AutoLCPossibilityJdg_6;
    func_V_x_AutoLCPossibilityJdgInput_AutoLCPossibilityJdg_6.verify();

    extern UVehStatus_OutDataSet gOEM_SWC_C2_2UVehStatus_OutDataSet;
    EXPECT_FLOAT_EQ(gOEM_SWC_C1_1UVehStatus_OutDataSet.mConc.V_x_AutoLCPossibilityJdgInput.V_x_vehicle_status.V_degps_YawRateRaw, -340282346638528897590636046441678635008);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_OutDataSet.mConc.V_x_AutoLCPossibilityJdgInput.V_x_vehicle_status.V_degps_YawRateRaw, -340282346638528897590636046441678635008);
    struct _func_V_x_AutoLCPossibilityJdgInput_AutoLCPossibilityJdg_7 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_AutoLCPossibilityJdgInput tmp_AutoLCPossibilityJdgInput;
            Rte_Read_V_x_AutoLCPossibilityJdgInput_V_x_AutoLCPossibilityJdgInput(&tmp_AutoLCPossibilityJdgInput);
            EXPECT_FLOAT_EQ(tmp_AutoLCPossibilityJdgInput.V_x_vehicle_status.V_degps_YawRateRaw, -340282346638528897590636046441678635008);
        }
    } func_V_x_AutoLCPossibilityJdgInput_AutoLCPossibilityJdg_7;
    func_V_x_AutoLCPossibilityJdgInput_AutoLCPossibilityJdg_7.verify();

    extern UVehStatus_OutDataSet gOEM_SWC_C2_2UVehStatus_OutDataSet;
    EXPECT_EQ(gOEM_SWC_C1_1UVehStatus_OutDataSet.mConc.V_x_AutoLCPossibilityJdgInput.V_x_vehicle_status.V_x_TurnInd, 0);
    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_OutDataSet.mConc.V_x_AutoLCPossibilityJdgInput.V_x_vehicle_status.V_x_TurnInd, 0);
    struct _func_V_x_AutoLCPossibilityJdgInput_AutoLCPossibilityJdg_8 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_AutoLCPossibilityJdgInput tmp_AutoLCPossibilityJdgInput;
            Rte_Read_V_x_AutoLCPossibilityJdgInput_V_x_AutoLCPossibilityJdgInput(&tmp_AutoLCPossibilityJdgInput);
            EXPECT_EQ(tmp_AutoLCPossibilityJdgInput.V_x_vehicle_status.V_x_TurnInd, 0);
        }
    } func_V_x_AutoLCPossibilityJdgInput_AutoLCPossibilityJdg_8;
    func_V_x_AutoLCPossibilityJdgInput_AutoLCPossibilityJdg_8.verify();

    extern UVehStatus_OutDataSet gOEM_SWC_C2_2UVehStatus_OutDataSet;
    EXPECT_FLOAT_EQ(gOEM_SWC_C1_1UVehStatus_OutDataSet.mConc.V_x_AutoLCPossibilityJdgInput.V_x_vehicle_status.V_kph_VDCVehicleSpeed, -340282346638528897590636046441678635008);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_OutDataSet.mConc.V_x_AutoLCPossibilityJdgInput.V_x_vehicle_status.V_kph_VDCVehicleSpeed, -340282346638528897590636046441678635008);
    struct _func_V_x_AutoLCPossibilityJdgInput_AutoLCPossibilityJdg_9 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_AutoLCPossibilityJdgInput tmp_AutoLCPossibilityJdgInput;
            Rte_Read_V_x_AutoLCPossibilityJdgInput_V_x_AutoLCPossibilityJdgInput(&tmp_AutoLCPossibilityJdgInput);
            EXPECT_FLOAT_EQ(tmp_AutoLCPossibilityJdgInput.V_x_vehicle_status.V_kph_VDCVehicleSpeed, -340282346638528897590636046441678635008);
        }
    } func_V_x_AutoLCPossibilityJdgInput_AutoLCPossibilityJdg_9;
    func_V_x_AutoLCPossibilityJdgInput_AutoLCPossibilityJdg_9.verify();

    extern UVehStatus_OutDataSet gOEM_SWC_C2_2UVehStatus_OutDataSet;
    EXPECT_FLOAT_EQ(gOEM_SWC_C1_1UVehStatus_OutDataSet.mConc.V_x_AutoLCPossibilityJdgInput.V_x_vehicle_status.V_mps_VehSpeed_Est, -340282346638528897590636046441678635008);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_OutDataSet.mConc.V_x_AutoLCPossibilityJdgInput.V_x_vehicle_status.V_mps_VehSpeed_Est, -340282346638528897590636046441678635008);
    struct _func_V_x_AutoLCPossibilityJdgInput_AutoLCPossibilityJdg_10 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_AutoLCPossibilityJdgInput tmp_AutoLCPossibilityJdgInput;
            Rte_Read_V_x_AutoLCPossibilityJdgInput_V_x_AutoLCPossibilityJdgInput(&tmp_AutoLCPossibilityJdgInput);
            EXPECT_FLOAT_EQ(tmp_AutoLCPossibilityJdgInput.V_x_vehicle_status.V_mps_VehSpeed_Est, -340282346638528897590636046441678635008);
        }
    } func_V_x_AutoLCPossibilityJdgInput_AutoLCPossibilityJdg_10;
    func_V_x_AutoLCPossibilityJdgInput_AutoLCPossibilityJdg_10.verify();

    extern UVehStatus_OutDataSet gOEM_SWC_C2_2UVehStatus_OutDataSet;
    EXPECT_EQ(gOEM_SWC_C1_1UVehStatus_OutDataSet.mConc.V_x_AutoLCPossibilityJdgInput.V_x_vehicle_status.V_x_TURN_IND_Filter, 0);
    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_OutDataSet.mConc.V_x_AutoLCPossibilityJdgInput.V_x_vehicle_status.V_x_TURN_IND_Filter, 0);
    struct _func_V_x_AutoLCPossibilityJdgInput_AutoLCPossibilityJdg_11 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_AutoLCPossibilityJdgInput tmp_AutoLCPossibilityJdgInput;
            Rte_Read_V_x_AutoLCPossibilityJdgInput_V_x_AutoLCPossibilityJdgInput(&tmp_AutoLCPossibilityJdgInput);
            EXPECT_EQ(tmp_AutoLCPossibilityJdgInput.V_x_vehicle_status.V_x_TURN_IND_Filter, 0);
        }
    } func_V_x_AutoLCPossibilityJdgInput_AutoLCPossibilityJdg_11;
    func_V_x_AutoLCPossibilityJdgInput_AutoLCPossibilityJdg_11.verify();

    extern UVehStatus_OutDataSet gOEM_SWC_C2_2UVehStatus_OutDataSet;
    EXPECT_EQ(gOEM_SWC_C1_1UVehStatus_OutDataSet.mConc.V_x_AutoLCPossibilityJdgInput.V_x_vehicle_status.V_x_Turn_Signal_Com, 0);
    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_OutDataSet.mConc.V_x_AutoLCPossibilityJdgInput.V_x_vehicle_status.V_x_Turn_Signal_Com, 0);
    struct _func_V_x_AutoLCPossibilityJdgInput_AutoLCPossibilityJdg_12 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_AutoLCPossibilityJdgInput tmp_AutoLCPossibilityJdgInput;
            Rte_Read_V_x_AutoLCPossibilityJdgInput_V_x_AutoLCPossibilityJdgInput(&tmp_AutoLCPossibilityJdgInput);
            EXPECT_EQ(tmp_AutoLCPossibilityJdgInput.V_x_vehicle_status.V_x_Turn_Signal_Com, 0);
        }
    } func_V_x_AutoLCPossibilityJdgInput_AutoLCPossibilityJdg_12;
    func_V_x_AutoLCPossibilityJdgInput_AutoLCPossibilityJdg_12.verify();

    extern UVehStatus_OutDataSet gOEM_SWC_C2_2UVehStatus_OutDataSet;
    EXPECT_FLOAT_EQ(gOEM_SWC_C1_1UVehStatus_OutDataSet.mConc.V_x_AutoLCPossibilityJdgInput.V_x_vehicle_status.V_m_ycr_l, -340282346638528897590636046441678635008);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_OutDataSet.mConc.V_x_AutoLCPossibilityJdgInput.V_x_vehicle_status.V_m_ycr_l, -340282346638528897590636046441678635008);
    struct _func_V_x_AutoLCPossibilityJdgInput_AutoLCPossibilityJdg_13 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_AutoLCPossibilityJdgInput tmp_AutoLCPossibilityJdgInput;
            Rte_Read_V_x_AutoLCPossibilityJdgInput_V_x_AutoLCPossibilityJdgInput(&tmp_AutoLCPossibilityJdgInput);
            EXPECT_FLOAT_EQ(tmp_AutoLCPossibilityJdgInput.V_x_vehicle_status.V_m_ycr_l, -340282346638528897590636046441678635008);
        }
    } func_V_x_AutoLCPossibilityJdgInput_AutoLCPossibilityJdg_13;
    func_V_x_AutoLCPossibilityJdgInput_AutoLCPossibilityJdg_13.verify();

    extern UVehStatus_OutDataSet gOEM_SWC_C2_2UVehStatus_OutDataSet;
    EXPECT_FLOAT_EQ(gOEM_SWC_C1_1UVehStatus_OutDataSet.mConc.V_x_AutoLCPossibilityJdgInput.V_x_vehicle_status.V_rad_phi_l, -340282346638528897590636046441678635008);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_OutDataSet.mConc.V_x_AutoLCPossibilityJdgInput.V_x_vehicle_status.V_rad_phi_l, -340282346638528897590636046441678635008);
    struct _func_V_x_AutoLCPossibilityJdgInput_AutoLCPossibilityJdg_14 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_AutoLCPossibilityJdgInput tmp_AutoLCPossibilityJdgInput;
            Rte_Read_V_x_AutoLCPossibilityJdgInput_V_x_AutoLCPossibilityJdgInput(&tmp_AutoLCPossibilityJdgInput);
            EXPECT_FLOAT_EQ(tmp_AutoLCPossibilityJdgInput.V_x_vehicle_status.V_rad_phi_l, -340282346638528897590636046441678635008);
        }
    } func_V_x_AutoLCPossibilityJdgInput_AutoLCPossibilityJdg_14;
    func_V_x_AutoLCPossibilityJdgInput_AutoLCPossibilityJdg_14.verify();

    extern UVehStatus_OutDataSet gOEM_SWC_C2_2UVehStatus_OutDataSet;
    EXPECT_FLOAT_EQ(gOEM_SWC_C1_1UVehStatus_OutDataSet.mConc.V_x_AutoLCPossibilityJdgInput.V_x_vehicle_status.V_pm_rho_l, -340282346638528897590636046441678635008);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_OutDataSet.mConc.V_x_AutoLCPossibilityJdgInput.V_x_vehicle_status.V_pm_rho_l, -340282346638528897590636046441678635008);
    struct _func_V_x_AutoLCPossibilityJdgInput_AutoLCPossibilityJdg_15 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_AutoLCPossibilityJdgInput tmp_AutoLCPossibilityJdgInput;
            Rte_Read_V_x_AutoLCPossibilityJdgInput_V_x_AutoLCPossibilityJdgInput(&tmp_AutoLCPossibilityJdgInput);
            EXPECT_FLOAT_EQ(tmp_AutoLCPossibilityJdgInput.V_x_vehicle_status.V_pm_rho_l, -340282346638528897590636046441678635008);
        }
    } func_V_x_AutoLCPossibilityJdgInput_AutoLCPossibilityJdg_15;
    func_V_x_AutoLCPossibilityJdgInput_AutoLCPossibilityJdg_15.verify();

    extern UVehStatus_OutDataSet gOEM_SWC_C2_2UVehStatus_OutDataSet;
    EXPECT_FLOAT_EQ(gOEM_SWC_C1_1UVehStatus_OutDataSet.mConc.V_x_AutoLCPossibilityJdgInput.V_x_vehicle_status.V_degps_YawRateCorrected, -340282346638528897590636046441678635008);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_OutDataSet.mConc.V_x_AutoLCPossibilityJdgInput.V_x_vehicle_status.V_degps_YawRateCorrected, -340282346638528897590636046441678635008);
    struct _func_V_x_AutoLCPossibilityJdgInput_AutoLCPossibilityJdg_16 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_AutoLCPossibilityJdgInput tmp_AutoLCPossibilityJdgInput;
            Rte_Read_V_x_AutoLCPossibilityJdgInput_V_x_AutoLCPossibilityJdgInput(&tmp_AutoLCPossibilityJdgInput);
            EXPECT_FLOAT_EQ(tmp_AutoLCPossibilityJdgInput.V_x_vehicle_status.V_degps_YawRateCorrected, -340282346638528897590636046441678635008);
        }
    } func_V_x_AutoLCPossibilityJdgInput_AutoLCPossibilityJdg_16;
    func_V_x_AutoLCPossibilityJdgInput_AutoLCPossibilityJdg_16.verify();

    extern UVehStatus_OutDataSet gOEM_SWC_C2_2UVehStatus_OutDataSet;
    EXPECT_EQ(gOEM_SWC_C1_1UVehStatus_OutDataSet.mConc.V_x_AutoLCPossibilityJdgInput.V_x_ctrl_flag.V_x_InternalACCStatus, 0);
    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_OutDataSet.mConc.V_x_AutoLCPossibilityJdgInput.V_x_ctrl_flag.V_x_InternalACCStatus, 0);
    struct _func_V_x_AutoLCPossibilityJdgInput_AutoLCPossibilityJdg_17 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_AutoLCPossibilityJdgInput tmp_AutoLCPossibilityJdgInput;
            Rte_Read_V_x_AutoLCPossibilityJdgInput_V_x_AutoLCPossibilityJdgInput(&tmp_AutoLCPossibilityJdgInput);
            EXPECT_EQ(tmp_AutoLCPossibilityJdgInput.V_x_ctrl_flag.V_x_InternalACCStatus, 0);
        }
    } func_V_x_AutoLCPossibilityJdgInput_AutoLCPossibilityJdg_17;
    func_V_x_AutoLCPossibilityJdgInput_AutoLCPossibilityJdg_17.verify();

    extern UVehStatus_OutDataSet gOEM_SWC_C2_2UVehStatus_OutDataSet;
    EXPECT_EQ(gOEM_SWC_C1_1UVehStatus_OutDataSet.mConc.V_x_AutoLCPossibilityJdgInput.V_x_ctrl_flag.F_x_Lch_on, 0);
    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_OutDataSet.mConc.V_x_AutoLCPossibilityJdgInput.V_x_ctrl_flag.F_x_Lch_on, 0);
    struct _func_V_x_AutoLCPossibilityJdgInput_AutoLCPossibilityJdg_18 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_AutoLCPossibilityJdgInput tmp_AutoLCPossibilityJdgInput;
            Rte_Read_V_x_AutoLCPossibilityJdgInput_V_x_AutoLCPossibilityJdgInput(&tmp_AutoLCPossibilityJdgInput);
            EXPECT_EQ(tmp_AutoLCPossibilityJdgInput.V_x_ctrl_flag.F_x_Lch_on, 0);
        }
    } func_V_x_AutoLCPossibilityJdgInput_AutoLCPossibilityJdg_18;
    func_V_x_AutoLCPossibilityJdgInput_AutoLCPossibilityJdg_18.verify();

    extern UVehStatus_OutDataSet gOEM_SWC_C2_2UVehStatus_OutDataSet;
    EXPECT_EQ(gOEM_SWC_C1_1UVehStatus_OutDataSet.mConc.V_x_AutoLCPossibilityJdgInput.V_x_ctrl_flag.V_x_Lch_dir_fix, -128);
    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_OutDataSet.mConc.V_x_AutoLCPossibilityJdgInput.V_x_ctrl_flag.V_x_Lch_dir_fix, -128);
    struct _func_V_x_AutoLCPossibilityJdgInput_AutoLCPossibilityJdg_19 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_AutoLCPossibilityJdgInput tmp_AutoLCPossibilityJdgInput;
            Rte_Read_V_x_AutoLCPossibilityJdgInput_V_x_AutoLCPossibilityJdgInput(&tmp_AutoLCPossibilityJdgInput);
            EXPECT_EQ(tmp_AutoLCPossibilityJdgInput.V_x_ctrl_flag.V_x_Lch_dir_fix, -128);
        }
    } func_V_x_AutoLCPossibilityJdgInput_AutoLCPossibilityJdg_19;
    func_V_x_AutoLCPossibilityJdgInput_AutoLCPossibilityJdg_19.verify();

    extern UVehStatus_OutDataSet gOEM_SWC_C2_2UVehStatus_OutDataSet;
    EXPECT_EQ(gOEM_SWC_C1_1UVehStatus_OutDataSet.mConc.V_x_AutoLCPossibilityJdgInput.V_x_ctrl_flag.F_x_DriverSteer, 0);
    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_OutDataSet.mConc.V_x_AutoLCPossibilityJdgInput.V_x_ctrl_flag.F_x_DriverSteer, 0);
    struct _func_V_x_AutoLCPossibilityJdgInput_AutoLCPossibilityJdg_20 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_AutoLCPossibilityJdgInput tmp_AutoLCPossibilityJdgInput;
            Rte_Read_V_x_AutoLCPossibilityJdgInput_V_x_AutoLCPossibilityJdgInput(&tmp_AutoLCPossibilityJdgInput);
            EXPECT_EQ(tmp_AutoLCPossibilityJdgInput.V_x_ctrl_flag.F_x_DriverSteer, 0);
        }
    } func_V_x_AutoLCPossibilityJdgInput_AutoLCPossibilityJdg_20;
    func_V_x_AutoLCPossibilityJdgInput_AutoLCPossibilityJdg_20.verify();

    extern UVehStatus_OutDataSet gOEM_SWC_C2_2UVehStatus_OutDataSet;
    EXPECT_EQ(gOEM_SWC_C1_1UVehStatus_OutDataSet.mConc.V_x_AutoLCPossibilityJdgInput.V_x_ctrl_flag.F_x_Lanechange_abort, 0);
    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_OutDataSet.mConc.V_x_AutoLCPossibilityJdgInput.V_x_ctrl_flag.F_x_Lanechange_abort, 0);
    struct _func_V_x_AutoLCPossibilityJdgInput_AutoLCPossibilityJdg_21 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_AutoLCPossibilityJdgInput tmp_AutoLCPossibilityJdgInput;
            Rte_Read_V_x_AutoLCPossibilityJdgInput_V_x_AutoLCPossibilityJdgInput(&tmp_AutoLCPossibilityJdgInput);
            EXPECT_EQ(tmp_AutoLCPossibilityJdgInput.V_x_ctrl_flag.F_x_Lanechange_abort, 0);
        }
    } func_V_x_AutoLCPossibilityJdgInput_AutoLCPossibilityJdg_21;
    func_V_x_AutoLCPossibilityJdgInput_AutoLCPossibilityJdg_21.verify();

    extern UVehStatus_OutDataSet gOEM_SWC_C2_2UVehStatus_OutDataSet;
    EXPECT_EQ(gOEM_SWC_C1_1UVehStatus_OutDataSet.mConc.V_x_AutoLCPossibilityJdgInput.V_x_ctrl_flag.V_x_LatControlModeSel, 0);
    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_OutDataSet.mConc.V_x_AutoLCPossibilityJdgInput.V_x_ctrl_flag.V_x_LatControlModeSel, 0);
    struct _func_V_x_AutoLCPossibilityJdgInput_AutoLCPossibilityJdg_22 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_AutoLCPossibilityJdgInput tmp_AutoLCPossibilityJdgInput;
            Rte_Read_V_x_AutoLCPossibilityJdgInput_V_x_AutoLCPossibilityJdgInput(&tmp_AutoLCPossibilityJdgInput);
            EXPECT_EQ(tmp_AutoLCPossibilityJdgInput.V_x_ctrl_flag.V_x_LatControlModeSel, 0);
        }
    } func_V_x_AutoLCPossibilityJdgInput_AutoLCPossibilityJdg_22;
    func_V_x_AutoLCPossibilityJdgInput_AutoLCPossibilityJdg_22.verify();

    extern UVehStatus_OutDataSet gOEM_SWC_C2_2UVehStatus_OutDataSet;
    EXPECT_EQ(gOEM_SWC_C1_1UVehStatus_OutDataSet.mConc.V_x_AutoLCPossibilityJdgInput.V_x_ctrl_flag.F_x_Lch_pass_announce_toRight, 0);
    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_OutDataSet.mConc.V_x_AutoLCPossibilityJdgInput.V_x_ctrl_flag.F_x_Lch_pass_announce_toRight, 0);
    struct _func_V_x_AutoLCPossibilityJdgInput_AutoLCPossibilityJdg_23 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_AutoLCPossibilityJdgInput tmp_AutoLCPossibilityJdgInput;
            Rte_Read_V_x_AutoLCPossibilityJdgInput_V_x_AutoLCPossibilityJdgInput(&tmp_AutoLCPossibilityJdgInput);
            EXPECT_EQ(tmp_AutoLCPossibilityJdgInput.V_x_ctrl_flag.F_x_Lch_pass_announce_toRight, 0);
        }
    } func_V_x_AutoLCPossibilityJdgInput_AutoLCPossibilityJdg_23;
    func_V_x_AutoLCPossibilityJdgInput_AutoLCPossibilityJdg_23.verify();

    extern UVehStatus_OutDataSet gOEM_SWC_C2_2UVehStatus_OutDataSet;
    EXPECT_EQ(gOEM_SWC_C1_1UVehStatus_OutDataSet.mConc.V_x_AutoLCPossibilityJdgInput.V_x_ctrl_flag.F_x_Lch_return_announce_toLeft, 0);
    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_OutDataSet.mConc.V_x_AutoLCPossibilityJdgInput.V_x_ctrl_flag.F_x_Lch_return_announce_toLeft, 0);
    struct _func_V_x_AutoLCPossibilityJdgInput_AutoLCPossibilityJdg_24 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_AutoLCPossibilityJdgInput tmp_AutoLCPossibilityJdgInput;
            Rte_Read_V_x_AutoLCPossibilityJdgInput_V_x_AutoLCPossibilityJdgInput(&tmp_AutoLCPossibilityJdgInput);
            EXPECT_EQ(tmp_AutoLCPossibilityJdgInput.V_x_ctrl_flag.F_x_Lch_return_announce_toLeft, 0);
        }
    } func_V_x_AutoLCPossibilityJdgInput_AutoLCPossibilityJdg_24;
    func_V_x_AutoLCPossibilityJdgInput_AutoLCPossibilityJdg_24.verify();

    extern UVehStatus_OutDataSet gOEM_SWC_C2_2UVehStatus_OutDataSet;
    EXPECT_EQ(gOEM_SWC_C1_1UVehStatus_OutDataSet.mConc.V_x_AutoLCPossibilityJdgInput.V_x_ctrl_flag.V_x_HandsOnJdg, 0);
    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_OutDataSet.mConc.V_x_AutoLCPossibilityJdgInput.V_x_ctrl_flag.V_x_HandsOnJdg, 0);
    struct _func_V_x_AutoLCPossibilityJdgInput_AutoLCPossibilityJdg_25 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_AutoLCPossibilityJdgInput tmp_AutoLCPossibilityJdgInput;
            Rte_Read_V_x_AutoLCPossibilityJdgInput_V_x_AutoLCPossibilityJdgInput(&tmp_AutoLCPossibilityJdgInput);
            EXPECT_EQ(tmp_AutoLCPossibilityJdgInput.V_x_ctrl_flag.V_x_HandsOnJdg, 0);
        }
    } func_V_x_AutoLCPossibilityJdgInput_AutoLCPossibilityJdg_25;
    func_V_x_AutoLCPossibilityJdgInput_AutoLCPossibilityJdg_25.verify();

    extern UVehStatus_OutDataSet gOEM_SWC_C2_2UVehStatus_OutDataSet;
    EXPECT_EQ(gOEM_SWC_C1_1UVehStatus_OutDataSet.mConc.V_x_AutoLCPossibilityJdgInput.V_x_ctrl_flag.V_x_ADCtrlStat, 0);
    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_OutDataSet.mConc.V_x_AutoLCPossibilityJdgInput.V_x_ctrl_flag.V_x_ADCtrlStat, 0);
    struct _func_V_x_AutoLCPossibilityJdgInput_AutoLCPossibilityJdg_26 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_AutoLCPossibilityJdgInput tmp_AutoLCPossibilityJdgInput;
            Rte_Read_V_x_AutoLCPossibilityJdgInput_V_x_AutoLCPossibilityJdgInput(&tmp_AutoLCPossibilityJdgInput);
            EXPECT_EQ(tmp_AutoLCPossibilityJdgInput.V_x_ctrl_flag.V_x_ADCtrlStat, 0);
        }
    } func_V_x_AutoLCPossibilityJdgInput_AutoLCPossibilityJdg_26;
    func_V_x_AutoLCPossibilityJdgInput_AutoLCPossibilityJdg_26.verify();

    extern UVehStatus_OutDataSet gOEM_SWC_C2_2UVehStatus_OutDataSet;
    EXPECT_EQ(gOEM_SWC_C1_1UVehStatus_OutDataSet.mConc.V_x_AutoLCPossibilityJdgInput.V_x_ctrl_flag.V_x_NumOfSystemAutoLC_Right, 0);
    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_OutDataSet.mConc.V_x_AutoLCPossibilityJdgInput.V_x_ctrl_flag.V_x_NumOfSystemAutoLC_Right, 0);
    struct _func_V_x_AutoLCPossibilityJdgInput_AutoLCPossibilityJdg_27 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_AutoLCPossibilityJdgInput tmp_AutoLCPossibilityJdgInput;
            Rte_Read_V_x_AutoLCPossibilityJdgInput_V_x_AutoLCPossibilityJdgInput(&tmp_AutoLCPossibilityJdgInput);
            EXPECT_EQ(tmp_AutoLCPossibilityJdgInput.V_x_ctrl_flag.V_x_NumOfSystemAutoLC_Right, 0);
        }
    } func_V_x_AutoLCPossibilityJdgInput_AutoLCPossibilityJdg_27;
    func_V_x_AutoLCPossibilityJdgInput_AutoLCPossibilityJdg_27.verify();

    extern UVehStatus_OutDataSet gOEM_SWC_C2_2UVehStatus_OutDataSet;
    EXPECT_EQ(gOEM_SWC_C1_1UVehStatus_OutDataSet.mConc.V_x_AutoLCPossibilityJdgInput.V_x_ctrl_flag.V_x_LaneChangeType, 0);
    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_OutDataSet.mConc.V_x_AutoLCPossibilityJdgInput.V_x_ctrl_flag.V_x_LaneChangeType, 0);
    struct _func_V_x_AutoLCPossibilityJdgInput_AutoLCPossibilityJdg_28 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_AutoLCPossibilityJdgInput tmp_AutoLCPossibilityJdgInput;
            Rte_Read_V_x_AutoLCPossibilityJdgInput_V_x_AutoLCPossibilityJdgInput(&tmp_AutoLCPossibilityJdgInput);
            EXPECT_EQ(tmp_AutoLCPossibilityJdgInput.V_x_ctrl_flag.V_x_LaneChangeType, 0);
        }
    } func_V_x_AutoLCPossibilityJdgInput_AutoLCPossibilityJdg_28;
    func_V_x_AutoLCPossibilityJdgInput_AutoLCPossibilityJdg_28.verify();

    extern UVehStatus_OutDataSet gOEM_SWC_C2_2UVehStatus_OutDataSet;
    EXPECT_EQ(gOEM_SWC_C1_1UVehStatus_OutDataSet.mConc.V_x_AutoLCPossibilityJdgInput.V_x_ctrl_flag.V_x_ALC_InternalState, 0);
    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_OutDataSet.mConc.V_x_AutoLCPossibilityJdgInput.V_x_ctrl_flag.V_x_ALC_InternalState, 0);
    struct _func_V_x_AutoLCPossibilityJdgInput_AutoLCPossibilityJdg_29 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_AutoLCPossibilityJdgInput tmp_AutoLCPossibilityJdgInput;
            Rte_Read_V_x_AutoLCPossibilityJdgInput_V_x_AutoLCPossibilityJdgInput(&tmp_AutoLCPossibilityJdgInput);
            EXPECT_EQ(tmp_AutoLCPossibilityJdgInput.V_x_ctrl_flag.V_x_ALC_InternalState, 0);
        }
    } func_V_x_AutoLCPossibilityJdgInput_AutoLCPossibilityJdg_29;
    func_V_x_AutoLCPossibilityJdgInput_AutoLCPossibilityJdg_29.verify();

    extern UVehStatus_OutDataSet gOEM_SWC_C2_2UVehStatus_OutDataSet;
    EXPECT_EQ(gOEM_SWC_C1_1UVehStatus_OutDataSet.mConc.V_x_AutoLCPossibilityJdgInput.V_x_ctrl_flag.V_x_AutoLCDirection_HMI, 0);
    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_OutDataSet.mConc.V_x_AutoLCPossibilityJdgInput.V_x_ctrl_flag.V_x_AutoLCDirection_HMI, 0);
    struct _func_V_x_AutoLCPossibilityJdgInput_AutoLCPossibilityJdg_30 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_AutoLCPossibilityJdgInput tmp_AutoLCPossibilityJdgInput;
            Rte_Read_V_x_AutoLCPossibilityJdgInput_V_x_AutoLCPossibilityJdgInput(&tmp_AutoLCPossibilityJdgInput);
            EXPECT_EQ(tmp_AutoLCPossibilityJdgInput.V_x_ctrl_flag.V_x_AutoLCDirection_HMI, 0);
        }
    } func_V_x_AutoLCPossibilityJdgInput_AutoLCPossibilityJdg_30;
    func_V_x_AutoLCPossibilityJdgInput_AutoLCPossibilityJdg_30.verify();

    extern UVehStatus_OutDataSet gOEM_SWC_C2_2UVehStatus_OutDataSet;
    EXPECT_EQ(gOEM_SWC_C1_1UVehStatus_OutDataSet.mConc.V_x_AutoLCPossibilityJdgInput.V_x_ctrl_flag.V_x_FS_ALCState, 0);
    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_OutDataSet.mConc.V_x_AutoLCPossibilityJdgInput.V_x_ctrl_flag.V_x_FS_ALCState, 0);
    struct _func_V_x_AutoLCPossibilityJdgInput_AutoLCPossibilityJdg_31 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_AutoLCPossibilityJdgInput tmp_AutoLCPossibilityJdgInput;
            Rte_Read_V_x_AutoLCPossibilityJdgInput_V_x_AutoLCPossibilityJdgInput(&tmp_AutoLCPossibilityJdgInput);
            EXPECT_EQ(tmp_AutoLCPossibilityJdgInput.V_x_ctrl_flag.V_x_FS_ALCState, 0);
        }
    } func_V_x_AutoLCPossibilityJdgInput_AutoLCPossibilityJdg_31;
    func_V_x_AutoLCPossibilityJdgInput_AutoLCPossibilityJdg_31.verify();

    extern UVehStatus_OutDataSet gOEM_SWC_C2_2UVehStatus_OutDataSet;
    EXPECT_EQ(gOEM_SWC_C1_1UVehStatus_OutDataSet.mConc.V_x_AutoLCPossibilityJdgInput.V_x_ctrl_flag.F_x_InitLane, 0);
    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_OutDataSet.mConc.V_x_AutoLCPossibilityJdgInput.V_x_ctrl_flag.F_x_InitLane, 0);
    struct _func_V_x_AutoLCPossibilityJdgInput_AutoLCPossibilityJdg_32 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_AutoLCPossibilityJdgInput tmp_AutoLCPossibilityJdgInput;
            Rte_Read_V_x_AutoLCPossibilityJdgInput_V_x_AutoLCPossibilityJdgInput(&tmp_AutoLCPossibilityJdgInput);
            EXPECT_EQ(tmp_AutoLCPossibilityJdgInput.V_x_ctrl_flag.F_x_InitLane, 0);
        }
    } func_V_x_AutoLCPossibilityJdgInput_AutoLCPossibilityJdg_32;
    func_V_x_AutoLCPossibilityJdgInput_AutoLCPossibilityJdg_32.verify();

    extern UVehStatus_OutDataSet gOEM_SWC_C2_2UVehStatus_OutDataSet;
    EXPECT_EQ(gOEM_SWC_C1_1UVehStatus_OutDataSet.mConc.V_x_AutoLCPossibilityJdgInput.V_x_ctrl_flag.F_x_IniSteer, 0);
    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_OutDataSet.mConc.V_x_AutoLCPossibilityJdgInput.V_x_ctrl_flag.F_x_IniSteer, 0);
    struct _func_V_x_AutoLCPossibilityJdgInput_AutoLCPossibilityJdg_33 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_AutoLCPossibilityJdgInput tmp_AutoLCPossibilityJdgInput;
            Rte_Read_V_x_AutoLCPossibilityJdgInput_V_x_AutoLCPossibilityJdgInput(&tmp_AutoLCPossibilityJdgInput);
            EXPECT_EQ(tmp_AutoLCPossibilityJdgInput.V_x_ctrl_flag.F_x_IniSteer, 0);
        }
    } func_V_x_AutoLCPossibilityJdgInput_AutoLCPossibilityJdg_33;
    func_V_x_AutoLCPossibilityJdgInput_AutoLCPossibilityJdg_33.verify();

    extern UVehStatus_OutDataSet gOEM_SWC_C2_2UVehStatus_OutDataSet;
    EXPECT_EQ(gOEM_SWC_C1_1UVehStatus_OutDataSet.mConc.V_x_AutoLCPossibilityJdgInput.V_x_ctrl_flag.F_x_SteerCntrl2, 0);
    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_OutDataSet.mConc.V_x_AutoLCPossibilityJdgInput.V_x_ctrl_flag.F_x_SteerCntrl2, 0);
    struct _func_V_x_AutoLCPossibilityJdgInput_AutoLCPossibilityJdg_34 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_AutoLCPossibilityJdgInput tmp_AutoLCPossibilityJdgInput;
            Rte_Read_V_x_AutoLCPossibilityJdgInput_V_x_AutoLCPossibilityJdgInput(&tmp_AutoLCPossibilityJdgInput);
            EXPECT_EQ(tmp_AutoLCPossibilityJdgInput.V_x_ctrl_flag.F_x_SteerCntrl2, 0);
        }
    } func_V_x_AutoLCPossibilityJdgInput_AutoLCPossibilityJdg_34;
    func_V_x_AutoLCPossibilityJdgInput_AutoLCPossibilityJdg_34.verify();

    extern UVehStatus_OutDataSet gOEM_SWC_C2_2UVehStatus_OutDataSet;
    EXPECT_EQ(gOEM_SWC_C1_1UVehStatus_OutDataSet.mConc.V_x_AutoLCPossibilityJdgInput.V_x_ctrl_flag.F_x_TurnIndLeftValid, 0);
    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_OutDataSet.mConc.V_x_AutoLCPossibilityJdgInput.V_x_ctrl_flag.F_x_TurnIndLeftValid, 0);
    struct _func_V_x_AutoLCPossibilityJdgInput_AutoLCPossibilityJdg_35 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_AutoLCPossibilityJdgInput tmp_AutoLCPossibilityJdgInput;
            Rte_Read_V_x_AutoLCPossibilityJdgInput_V_x_AutoLCPossibilityJdgInput(&tmp_AutoLCPossibilityJdgInput);
            EXPECT_EQ(tmp_AutoLCPossibilityJdgInput.V_x_ctrl_flag.F_x_TurnIndLeftValid, 0);
        }
    } func_V_x_AutoLCPossibilityJdgInput_AutoLCPossibilityJdg_35;
    func_V_x_AutoLCPossibilityJdgInput_AutoLCPossibilityJdg_35.verify();

    extern UVehStatus_OutDataSet gOEM_SWC_C2_2UVehStatus_OutDataSet;
    EXPECT_EQ(gOEM_SWC_C1_1UVehStatus_OutDataSet.mConc.V_x_AutoLCPossibilityJdgInput.V_x_ctrl_flag.F_x_TurnIndRightValid, 0);
    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_OutDataSet.mConc.V_x_AutoLCPossibilityJdgInput.V_x_ctrl_flag.F_x_TurnIndRightValid, 0);
    struct _func_V_x_AutoLCPossibilityJdgInput_AutoLCPossibilityJdg_36 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_AutoLCPossibilityJdgInput tmp_AutoLCPossibilityJdgInput;
            Rte_Read_V_x_AutoLCPossibilityJdgInput_V_x_AutoLCPossibilityJdgInput(&tmp_AutoLCPossibilityJdgInput);
            EXPECT_EQ(tmp_AutoLCPossibilityJdgInput.V_x_ctrl_flag.F_x_TurnIndRightValid, 0);
        }
    } func_V_x_AutoLCPossibilityJdgInput_AutoLCPossibilityJdg_36;
    func_V_x_AutoLCPossibilityJdgInput_AutoLCPossibilityJdg_36.verify();

    extern UVehStatus_OutDataSet gOEM_SWC_C2_2UVehStatus_OutDataSet;
    EXPECT_EQ(gOEM_SWC_C1_1UVehStatus_OutDataSet.mConc.V_x_AutoLCPossibilityJdgInput.V_x_ctrl_flag.V_x_Lch_dir_pre, -128);
    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_OutDataSet.mConc.V_x_AutoLCPossibilityJdgInput.V_x_ctrl_flag.V_x_Lch_dir_pre, -128);
    struct _func_V_x_AutoLCPossibilityJdgInput_AutoLCPossibilityJdg_37 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_AutoLCPossibilityJdgInput tmp_AutoLCPossibilityJdgInput;
            Rte_Read_V_x_AutoLCPossibilityJdgInput_V_x_AutoLCPossibilityJdgInput(&tmp_AutoLCPossibilityJdgInput);
            EXPECT_EQ(tmp_AutoLCPossibilityJdgInput.V_x_ctrl_flag.V_x_Lch_dir_pre, -128);
        }
    } func_V_x_AutoLCPossibilityJdgInput_AutoLCPossibilityJdg_37;
    func_V_x_AutoLCPossibilityJdgInput_AutoLCPossibilityJdg_37.verify();

    extern UVehStatus_OutDataSet gOEM_SWC_C2_2UVehStatus_OutDataSet;
    EXPECT_EQ(gOEM_SWC_C1_1UVehStatus_OutDataSet.mConc.V_x_AutoLCPossibilityJdgInput.V_x_prec_vehicle_info.V_x_SENSOR_SEL, 0);
    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_OutDataSet.mConc.V_x_AutoLCPossibilityJdgInput.V_x_prec_vehicle_info.V_x_SENSOR_SEL, 0);
    struct _func_V_x_AutoLCPossibilityJdgInput_AutoLCPossibilityJdg_38 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_AutoLCPossibilityJdgInput tmp_AutoLCPossibilityJdgInput;
            Rte_Read_V_x_AutoLCPossibilityJdgInput_V_x_AutoLCPossibilityJdgInput(&tmp_AutoLCPossibilityJdgInput);
            EXPECT_EQ(tmp_AutoLCPossibilityJdgInput.V_x_prec_vehicle_info.V_x_SENSOR_SEL, 0);
        }
    } func_V_x_AutoLCPossibilityJdgInput_AutoLCPossibilityJdg_38;
    func_V_x_AutoLCPossibilityJdgInput_AutoLCPossibilityJdg_38.verify();

    extern UVehStatus_OutDataSet gOEM_SWC_C2_2UVehStatus_OutDataSet;
    EXPECT_EQ(gOEM_SWC_C1_1UVehStatus_OutDataSet.mConc.V_x_AutoLCPossibilityJdgInput.V_x_prec_vehicle_info.V_x_SensorSelEgo, 0);
    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_OutDataSet.mConc.V_x_AutoLCPossibilityJdgInput.V_x_prec_vehicle_info.V_x_SensorSelEgo, 0);
    struct _func_V_x_AutoLCPossibilityJdgInput_AutoLCPossibilityJdg_39 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_AutoLCPossibilityJdgInput tmp_AutoLCPossibilityJdgInput;
            Rte_Read_V_x_AutoLCPossibilityJdgInput_V_x_AutoLCPossibilityJdgInput(&tmp_AutoLCPossibilityJdgInput);
            EXPECT_EQ(tmp_AutoLCPossibilityJdgInput.V_x_prec_vehicle_info.V_x_SensorSelEgo, 0);
        }
    } func_V_x_AutoLCPossibilityJdgInput_AutoLCPossibilityJdg_39;
    func_V_x_AutoLCPossibilityJdgInput_AutoLCPossibilityJdg_39.verify();

    extern UVehStatus_OutDataSet gOEM_SWC_C2_2UVehStatus_OutDataSet;
    EXPECT_FLOAT_EQ(gOEM_SWC_C1_1UVehStatus_OutDataSet.mConc.V_x_AutoLCPossibilityJdgInput.V_x_prec_vehicle_info.V_mps2_DecelerationEgo, -340282346638528897590636046441678635008);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_OutDataSet.mConc.V_x_AutoLCPossibilityJdgInput.V_x_prec_vehicle_info.V_mps2_DecelerationEgo, -340282346638528897590636046441678635008);
    struct _func_V_x_AutoLCPossibilityJdgInput_AutoLCPossibilityJdg_40 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_AutoLCPossibilityJdgInput tmp_AutoLCPossibilityJdgInput;
            Rte_Read_V_x_AutoLCPossibilityJdgInput_V_x_AutoLCPossibilityJdgInput(&tmp_AutoLCPossibilityJdgInput);
            EXPECT_FLOAT_EQ(tmp_AutoLCPossibilityJdgInput.V_x_prec_vehicle_info.V_mps2_DecelerationEgo, -340282346638528897590636046441678635008);
        }
    } func_V_x_AutoLCPossibilityJdgInput_AutoLCPossibilityJdg_40;
    func_V_x_AutoLCPossibilityJdgInput_AutoLCPossibilityJdg_40.verify();

    extern UVehStatus_OutDataSet gOEM_SWC_C2_2UVehStatus_OutDataSet;
    EXPECT_FLOAT_EQ(gOEM_SWC_C1_1UVehStatus_OutDataSet.mConc.V_x_AutoLCPossibilityJdgInput.V_x_prec_vehicle_info.V_m_Distance, -340282346638528897590636046441678635008);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_OutDataSet.mConc.V_x_AutoLCPossibilityJdgInput.V_x_prec_vehicle_info.V_m_Distance, -340282346638528897590636046441678635008);
    struct _func_V_x_AutoLCPossibilityJdgInput_AutoLCPossibilityJdg_41 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_AutoLCPossibilityJdgInput tmp_AutoLCPossibilityJdgInput;
            Rte_Read_V_x_AutoLCPossibilityJdgInput_V_x_AutoLCPossibilityJdgInput(&tmp_AutoLCPossibilityJdgInput);
            EXPECT_FLOAT_EQ(tmp_AutoLCPossibilityJdgInput.V_x_prec_vehicle_info.V_m_Distance, -340282346638528897590636046441678635008);
        }
    } func_V_x_AutoLCPossibilityJdgInput_AutoLCPossibilityJdg_41;
    func_V_x_AutoLCPossibilityJdgInput_AutoLCPossibilityJdg_41.verify();

    extern UVehStatus_OutDataSet gOEM_SWC_C2_2UVehStatus_OutDataSet;
    EXPECT_FLOAT_EQ(gOEM_SWC_C1_1UVehStatus_OutDataSet.mConc.V_x_AutoLCPossibilityJdgInput.V_x_prec_vehicle_info.V_m_PrecVehicleLatDistance, -340282346638528897590636046441678635008);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_OutDataSet.mConc.V_x_AutoLCPossibilityJdgInput.V_x_prec_vehicle_info.V_m_PrecVehicleLatDistance, -340282346638528897590636046441678635008);
    struct _func_V_x_AutoLCPossibilityJdgInput_AutoLCPossibilityJdg_42 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_AutoLCPossibilityJdgInput tmp_AutoLCPossibilityJdgInput;
            Rte_Read_V_x_AutoLCPossibilityJdgInput_V_x_AutoLCPossibilityJdgInput(&tmp_AutoLCPossibilityJdgInput);
            EXPECT_FLOAT_EQ(tmp_AutoLCPossibilityJdgInput.V_x_prec_vehicle_info.V_m_PrecVehicleLatDistance, -340282346638528897590636046441678635008);
        }
    } func_V_x_AutoLCPossibilityJdgInput_AutoLCPossibilityJdg_42;
    func_V_x_AutoLCPossibilityJdgInput_AutoLCPossibilityJdg_42.verify();

    extern UVehStatus_OutDataSet gOEM_SWC_C2_2UVehStatus_OutDataSet;
    EXPECT_FLOAT_EQ(gOEM_SWC_C1_1UVehStatus_OutDataSet.mConc.V_x_AutoLCPossibilityJdgInput.V_x_prec_vehicle_info.V_mps_RelativeSpeed, -340282346638528897590636046441678635008);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_OutDataSet.mConc.V_x_AutoLCPossibilityJdgInput.V_x_prec_vehicle_info.V_mps_RelativeSpeed, -340282346638528897590636046441678635008);
    struct _func_V_x_AutoLCPossibilityJdgInput_AutoLCPossibilityJdg_43 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_AutoLCPossibilityJdgInput tmp_AutoLCPossibilityJdgInput;
            Rte_Read_V_x_AutoLCPossibilityJdgInput_V_x_AutoLCPossibilityJdgInput(&tmp_AutoLCPossibilityJdgInput);
            EXPECT_FLOAT_EQ(tmp_AutoLCPossibilityJdgInput.V_x_prec_vehicle_info.V_mps_RelativeSpeed, -340282346638528897590636046441678635008);
        }
    } func_V_x_AutoLCPossibilityJdgInput_AutoLCPossibilityJdg_43;
    func_V_x_AutoLCPossibilityJdgInput_AutoLCPossibilityJdg_43.verify();

    extern UVehStatus_OutDataSet gOEM_SWC_C2_2UVehStatus_OutDataSet;
    EXPECT_EQ(gOEM_SWC_C1_1UVehStatus_OutDataSet.mConc.V_x_AutoLCPossibilityJdgInput.V_x_SigSetSpeed, 0);
    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_OutDataSet.mConc.V_x_AutoLCPossibilityJdgInput.V_x_SigSetSpeed, 0);
    struct _func_V_x_AutoLCPossibilityJdgInput_AutoLCPossibilityJdg_44 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_AutoLCPossibilityJdgInput tmp_AutoLCPossibilityJdgInput;
            Rte_Read_V_x_AutoLCPossibilityJdgInput_V_x_AutoLCPossibilityJdgInput(&tmp_AutoLCPossibilityJdgInput);
            EXPECT_EQ(tmp_AutoLCPossibilityJdgInput.V_x_SigSetSpeed, 0);
        }
    } func_V_x_AutoLCPossibilityJdgInput_AutoLCPossibilityJdg_44;
    func_V_x_AutoLCPossibilityJdgInput_AutoLCPossibilityJdg_44.verify();

    /* V_x_Global_PWTWheelTorqueOrder_VSO*/
    extern UVehStatus_OutDataSet gOEM_SWC_C0_SMUVehStatus_OutDataSet;
    EXPECT_EQ(gOEM_SWC_C1_1UVehStatus_OutDataSet.mConc.V_x_Global_PWTWheelTorqueOrder_VSO, 0);
    EXPECT_EQ(gOEM_SWC_C0_SMUVehStatus_OutDataSet.mConc.V_x_Global_PWTWheelTorqueOrder_VSO, 0);
    struct _func_V_x_Global_PWTWheelTorqueOrder_VSO_SafetyModule {
        static void verify(void) {
#include "Rte_Wrapper_SafetyModule.h"
            uint8 tmp_U8;
            Rte_Read_V_x_Global_PWTWheelTorqueOrder_VSO_V_x_Global_PWTWheelTorqueOrder_VSO(&tmp_U8);
            EXPECT_EQ(tmp_U8, 0);
        }
    } func_V_x_Global_PWTWheelTorqueOrder_VSO_SafetyModule;
    func_V_x_Global_PWTWheelTorqueOrder_VSO_SafetyModule.verify();

    /* V_x_ObjectSelectionAVMInput*/
    extern UVehStatus_OutDataSet gOEM_SWC_C2_3UVehStatus_OutDataSet;
    EXPECT_FLOAT_EQ(gOEM_SWC_C1_1UVehStatus_OutDataSet.mConc.V_x_ObjectSelectionAVMInput.V_x_vehicle_status.V_mps_VSP_LPF, -340282346638528897590636046441678635008);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_OutDataSet.mConc.V_x_ObjectSelectionAVMInput.V_x_vehicle_status.V_mps_VSP_LPF, -340282346638528897590636046441678635008);
    struct _func_V_x_ObjectSelectionAVMInput_ObjectSelectionAVM_0 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_ObjectSelectionAVMInput tmp_ObjectSelectionAVMInput;
            Rte_Read_V_x_ObjectSelectionAVMInput_V_x_ObjectSelectionAVMInput(&tmp_ObjectSelectionAVMInput);
            EXPECT_FLOAT_EQ(tmp_ObjectSelectionAVMInput.V_x_vehicle_status.V_mps_VSP_LPF, -340282346638528897590636046441678635008);
        }
    } func_V_x_ObjectSelectionAVMInput_ObjectSelectionAVM_0;
    func_V_x_ObjectSelectionAVMInput_ObjectSelectionAVM_0.verify();

    extern UVehStatus_OutDataSet gOEM_SWC_C2_3UVehStatus_OutDataSet;
    EXPECT_FLOAT_EQ(gOEM_SWC_C1_1UVehStatus_OutDataSet.mConc.V_x_ObjectSelectionAVMInput.V_x_vehicle_status.V_mps_AVE_VSP, -340282346638528897590636046441678635008);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_OutDataSet.mConc.V_x_ObjectSelectionAVMInput.V_x_vehicle_status.V_mps_AVE_VSP, -340282346638528897590636046441678635008);
    struct _func_V_x_ObjectSelectionAVMInput_ObjectSelectionAVM_1 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_ObjectSelectionAVMInput tmp_ObjectSelectionAVMInput;
            Rte_Read_V_x_ObjectSelectionAVMInput_V_x_ObjectSelectionAVMInput(&tmp_ObjectSelectionAVMInput);
            EXPECT_FLOAT_EQ(tmp_ObjectSelectionAVMInput.V_x_vehicle_status.V_mps_AVE_VSP, -340282346638528897590636046441678635008);
        }
    } func_V_x_ObjectSelectionAVMInput_ObjectSelectionAVM_1;
    func_V_x_ObjectSelectionAVMInput_ObjectSelectionAVM_1.verify();

    extern UVehStatus_OutDataSet gOEM_SWC_C2_3UVehStatus_OutDataSet;
    EXPECT_EQ(gOEM_SWC_C1_1UVehStatus_OutDataSet.mConc.V_x_ObjectSelectionAVMInput.V_x_vehicle_status.V_x_RangeIndication, 0);
    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_OutDataSet.mConc.V_x_ObjectSelectionAVMInput.V_x_vehicle_status.V_x_RangeIndication, 0);
    struct _func_V_x_ObjectSelectionAVMInput_ObjectSelectionAVM_2 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_ObjectSelectionAVMInput tmp_ObjectSelectionAVMInput;
            Rte_Read_V_x_ObjectSelectionAVMInput_V_x_ObjectSelectionAVMInput(&tmp_ObjectSelectionAVMInput);
            EXPECT_EQ(tmp_ObjectSelectionAVMInput.V_x_vehicle_status.V_x_RangeIndication, 0);
        }
    } func_V_x_ObjectSelectionAVMInput_ObjectSelectionAVM_2;
    func_V_x_ObjectSelectionAVMInput_ObjectSelectionAVM_2.verify();

    extern UVehStatus_OutDataSet gOEM_SWC_C2_3UVehStatus_OutDataSet;
    EXPECT_EQ(gOEM_SWC_C1_1UVehStatus_OutDataSet.mConc.V_x_ObjectSelectionAVMInput.V_x_vehicle_status.F_x_CancelButton, 0);
    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_OutDataSet.mConc.V_x_ObjectSelectionAVMInput.V_x_vehicle_status.F_x_CancelButton, 0);
    struct _func_V_x_ObjectSelectionAVMInput_ObjectSelectionAVM_3 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_ObjectSelectionAVMInput tmp_ObjectSelectionAVMInput;
            Rte_Read_V_x_ObjectSelectionAVMInput_V_x_ObjectSelectionAVMInput(&tmp_ObjectSelectionAVMInput);
            EXPECT_EQ(tmp_ObjectSelectionAVMInput.V_x_vehicle_status.F_x_CancelButton, 0);
        }
    } func_V_x_ObjectSelectionAVMInput_ObjectSelectionAVM_3;
    func_V_x_ObjectSelectionAVMInput_ObjectSelectionAVM_3.verify();

    extern UVehStatus_OutDataSet gOEM_SWC_C2_3UVehStatus_OutDataSet;
    EXPECT_EQ(gOEM_SWC_C1_1UVehStatus_OutDataSet.mConc.V_x_ObjectSelectionAVMInput.V_x_vehicle_status.F_x_MainSwOn4, 0);
    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_OutDataSet.mConc.V_x_ObjectSelectionAVMInput.V_x_vehicle_status.F_x_MainSwOn4, 0);
    struct _func_V_x_ObjectSelectionAVMInput_ObjectSelectionAVM_4 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_ObjectSelectionAVMInput tmp_ObjectSelectionAVMInput;
            Rte_Read_V_x_ObjectSelectionAVMInput_V_x_ObjectSelectionAVMInput(&tmp_ObjectSelectionAVMInput);
            EXPECT_EQ(tmp_ObjectSelectionAVMInput.V_x_vehicle_status.F_x_MainSwOn4, 0);
        }
    } func_V_x_ObjectSelectionAVMInput_ObjectSelectionAVM_4;
    func_V_x_ObjectSelectionAVMInput_ObjectSelectionAVM_4.verify();

    extern UVehStatus_OutDataSet gOEM_SWC_C2_3UVehStatus_OutDataSet;
    EXPECT_FLOAT_EQ(gOEM_SWC_C1_1UVehStatus_OutDataSet.mConc.V_x_ObjectSelectionAVMInput.V_x_vehicle_status.V_deg_EPS_AngleSensor, -340282346638528897590636046441678635008);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_OutDataSet.mConc.V_x_ObjectSelectionAVMInput.V_x_vehicle_status.V_deg_EPS_AngleSensor, -340282346638528897590636046441678635008);
    struct _func_V_x_ObjectSelectionAVMInput_ObjectSelectionAVM_5 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_ObjectSelectionAVMInput tmp_ObjectSelectionAVMInput;
            Rte_Read_V_x_ObjectSelectionAVMInput_V_x_ObjectSelectionAVMInput(&tmp_ObjectSelectionAVMInput);
            EXPECT_FLOAT_EQ(tmp_ObjectSelectionAVMInput.V_x_vehicle_status.V_deg_EPS_AngleSensor, -340282346638528897590636046441678635008);
        }
    } func_V_x_ObjectSelectionAVMInput_ObjectSelectionAVM_5;
    func_V_x_ObjectSelectionAVMInput_ObjectSelectionAVM_5.verify();

    extern UVehStatus_OutDataSet gOEM_SWC_C2_3UVehStatus_OutDataSet;
    EXPECT_FLOAT_EQ(gOEM_SWC_C1_1UVehStatus_OutDataSet.mConc.V_x_ObjectSelectionAVMInput.V_x_vehicle_status.V_deg_SteeringWheelAngleRaw, -340282346638528897590636046441678635008);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_OutDataSet.mConc.V_x_ObjectSelectionAVMInput.V_x_vehicle_status.V_deg_SteeringWheelAngleRaw, -340282346638528897590636046441678635008);
    struct _func_V_x_ObjectSelectionAVMInput_ObjectSelectionAVM_6 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_ObjectSelectionAVMInput tmp_ObjectSelectionAVMInput;
            Rte_Read_V_x_ObjectSelectionAVMInput_V_x_ObjectSelectionAVMInput(&tmp_ObjectSelectionAVMInput);
            EXPECT_FLOAT_EQ(tmp_ObjectSelectionAVMInput.V_x_vehicle_status.V_deg_SteeringWheelAngleRaw, -340282346638528897590636046441678635008);
        }
    } func_V_x_ObjectSelectionAVMInput_ObjectSelectionAVM_6;
    func_V_x_ObjectSelectionAVMInput_ObjectSelectionAVM_6.verify();

    extern UVehStatus_OutDataSet gOEM_SWC_C2_3UVehStatus_OutDataSet;
    EXPECT_FLOAT_EQ(gOEM_SWC_C1_1UVehStatus_OutDataSet.mConc.V_x_ObjectSelectionAVMInput.V_x_vehicle_status.V_degps_YawRateRaw, -340282346638528897590636046441678635008);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_OutDataSet.mConc.V_x_ObjectSelectionAVMInput.V_x_vehicle_status.V_degps_YawRateRaw, -340282346638528897590636046441678635008);
    struct _func_V_x_ObjectSelectionAVMInput_ObjectSelectionAVM_7 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_ObjectSelectionAVMInput tmp_ObjectSelectionAVMInput;
            Rte_Read_V_x_ObjectSelectionAVMInput_V_x_ObjectSelectionAVMInput(&tmp_ObjectSelectionAVMInput);
            EXPECT_FLOAT_EQ(tmp_ObjectSelectionAVMInput.V_x_vehicle_status.V_degps_YawRateRaw, -340282346638528897590636046441678635008);
        }
    } func_V_x_ObjectSelectionAVMInput_ObjectSelectionAVM_7;
    func_V_x_ObjectSelectionAVMInput_ObjectSelectionAVM_7.verify();

    extern UVehStatus_OutDataSet gOEM_SWC_C2_3UVehStatus_OutDataSet;
    EXPECT_EQ(gOEM_SWC_C1_1UVehStatus_OutDataSet.mConc.V_x_ObjectSelectionAVMInput.V_x_vehicle_status.V_x_TurnInd, 0);
    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_OutDataSet.mConc.V_x_ObjectSelectionAVMInput.V_x_vehicle_status.V_x_TurnInd, 0);
    struct _func_V_x_ObjectSelectionAVMInput_ObjectSelectionAVM_8 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_ObjectSelectionAVMInput tmp_ObjectSelectionAVMInput;
            Rte_Read_V_x_ObjectSelectionAVMInput_V_x_ObjectSelectionAVMInput(&tmp_ObjectSelectionAVMInput);
            EXPECT_EQ(tmp_ObjectSelectionAVMInput.V_x_vehicle_status.V_x_TurnInd, 0);
        }
    } func_V_x_ObjectSelectionAVMInput_ObjectSelectionAVM_8;
    func_V_x_ObjectSelectionAVMInput_ObjectSelectionAVM_8.verify();

    extern UVehStatus_OutDataSet gOEM_SWC_C2_3UVehStatus_OutDataSet;
    EXPECT_FLOAT_EQ(gOEM_SWC_C1_1UVehStatus_OutDataSet.mConc.V_x_ObjectSelectionAVMInput.V_x_vehicle_status.V_kph_VDCVehicleSpeed, -340282346638528897590636046441678635008);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_OutDataSet.mConc.V_x_ObjectSelectionAVMInput.V_x_vehicle_status.V_kph_VDCVehicleSpeed, -340282346638528897590636046441678635008);
    struct _func_V_x_ObjectSelectionAVMInput_ObjectSelectionAVM_9 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_ObjectSelectionAVMInput tmp_ObjectSelectionAVMInput;
            Rte_Read_V_x_ObjectSelectionAVMInput_V_x_ObjectSelectionAVMInput(&tmp_ObjectSelectionAVMInput);
            EXPECT_FLOAT_EQ(tmp_ObjectSelectionAVMInput.V_x_vehicle_status.V_kph_VDCVehicleSpeed, -340282346638528897590636046441678635008);
        }
    } func_V_x_ObjectSelectionAVMInput_ObjectSelectionAVM_9;
    func_V_x_ObjectSelectionAVMInput_ObjectSelectionAVM_9.verify();

    extern UVehStatus_OutDataSet gOEM_SWC_C2_3UVehStatus_OutDataSet;
    EXPECT_FLOAT_EQ(gOEM_SWC_C1_1UVehStatus_OutDataSet.mConc.V_x_ObjectSelectionAVMInput.V_x_vehicle_status.V_mps_VehSpeed_Est, -340282346638528897590636046441678635008);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_OutDataSet.mConc.V_x_ObjectSelectionAVMInput.V_x_vehicle_status.V_mps_VehSpeed_Est, -340282346638528897590636046441678635008);
    struct _func_V_x_ObjectSelectionAVMInput_ObjectSelectionAVM_10 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_ObjectSelectionAVMInput tmp_ObjectSelectionAVMInput;
            Rte_Read_V_x_ObjectSelectionAVMInput_V_x_ObjectSelectionAVMInput(&tmp_ObjectSelectionAVMInput);
            EXPECT_FLOAT_EQ(tmp_ObjectSelectionAVMInput.V_x_vehicle_status.V_mps_VehSpeed_Est, -340282346638528897590636046441678635008);
        }
    } func_V_x_ObjectSelectionAVMInput_ObjectSelectionAVM_10;
    func_V_x_ObjectSelectionAVMInput_ObjectSelectionAVM_10.verify();

    extern UVehStatus_OutDataSet gOEM_SWC_C2_3UVehStatus_OutDataSet;
    EXPECT_EQ(gOEM_SWC_C1_1UVehStatus_OutDataSet.mConc.V_x_ObjectSelectionAVMInput.V_x_vehicle_status.V_x_TURN_IND_Filter, 0);
    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_OutDataSet.mConc.V_x_ObjectSelectionAVMInput.V_x_vehicle_status.V_x_TURN_IND_Filter, 0);
    struct _func_V_x_ObjectSelectionAVMInput_ObjectSelectionAVM_11 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_ObjectSelectionAVMInput tmp_ObjectSelectionAVMInput;
            Rte_Read_V_x_ObjectSelectionAVMInput_V_x_ObjectSelectionAVMInput(&tmp_ObjectSelectionAVMInput);
            EXPECT_EQ(tmp_ObjectSelectionAVMInput.V_x_vehicle_status.V_x_TURN_IND_Filter, 0);
        }
    } func_V_x_ObjectSelectionAVMInput_ObjectSelectionAVM_11;
    func_V_x_ObjectSelectionAVMInput_ObjectSelectionAVM_11.verify();

    extern UVehStatus_OutDataSet gOEM_SWC_C2_3UVehStatus_OutDataSet;
    EXPECT_EQ(gOEM_SWC_C1_1UVehStatus_OutDataSet.mConc.V_x_ObjectSelectionAVMInput.V_x_vehicle_status.V_x_Turn_Signal_Com, 0);
    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_OutDataSet.mConc.V_x_ObjectSelectionAVMInput.V_x_vehicle_status.V_x_Turn_Signal_Com, 0);
    struct _func_V_x_ObjectSelectionAVMInput_ObjectSelectionAVM_12 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_ObjectSelectionAVMInput tmp_ObjectSelectionAVMInput;
            Rte_Read_V_x_ObjectSelectionAVMInput_V_x_ObjectSelectionAVMInput(&tmp_ObjectSelectionAVMInput);
            EXPECT_EQ(tmp_ObjectSelectionAVMInput.V_x_vehicle_status.V_x_Turn_Signal_Com, 0);
        }
    } func_V_x_ObjectSelectionAVMInput_ObjectSelectionAVM_12;
    func_V_x_ObjectSelectionAVMInput_ObjectSelectionAVM_12.verify();

    extern UVehStatus_OutDataSet gOEM_SWC_C2_3UVehStatus_OutDataSet;
    EXPECT_FLOAT_EQ(gOEM_SWC_C1_1UVehStatus_OutDataSet.mConc.V_x_ObjectSelectionAVMInput.V_x_vehicle_status.V_m_ycr_l, -340282346638528897590636046441678635008);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_OutDataSet.mConc.V_x_ObjectSelectionAVMInput.V_x_vehicle_status.V_m_ycr_l, -340282346638528897590636046441678635008);
    struct _func_V_x_ObjectSelectionAVMInput_ObjectSelectionAVM_13 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_ObjectSelectionAVMInput tmp_ObjectSelectionAVMInput;
            Rte_Read_V_x_ObjectSelectionAVMInput_V_x_ObjectSelectionAVMInput(&tmp_ObjectSelectionAVMInput);
            EXPECT_FLOAT_EQ(tmp_ObjectSelectionAVMInput.V_x_vehicle_status.V_m_ycr_l, -340282346638528897590636046441678635008);
        }
    } func_V_x_ObjectSelectionAVMInput_ObjectSelectionAVM_13;
    func_V_x_ObjectSelectionAVMInput_ObjectSelectionAVM_13.verify();

    extern UVehStatus_OutDataSet gOEM_SWC_C2_3UVehStatus_OutDataSet;
    EXPECT_FLOAT_EQ(gOEM_SWC_C1_1UVehStatus_OutDataSet.mConc.V_x_ObjectSelectionAVMInput.V_x_vehicle_status.V_rad_phi_l, -340282346638528897590636046441678635008);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_OutDataSet.mConc.V_x_ObjectSelectionAVMInput.V_x_vehicle_status.V_rad_phi_l, -340282346638528897590636046441678635008);
    struct _func_V_x_ObjectSelectionAVMInput_ObjectSelectionAVM_14 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_ObjectSelectionAVMInput tmp_ObjectSelectionAVMInput;
            Rte_Read_V_x_ObjectSelectionAVMInput_V_x_ObjectSelectionAVMInput(&tmp_ObjectSelectionAVMInput);
            EXPECT_FLOAT_EQ(tmp_ObjectSelectionAVMInput.V_x_vehicle_status.V_rad_phi_l, -340282346638528897590636046441678635008);
        }
    } func_V_x_ObjectSelectionAVMInput_ObjectSelectionAVM_14;
    func_V_x_ObjectSelectionAVMInput_ObjectSelectionAVM_14.verify();

    extern UVehStatus_OutDataSet gOEM_SWC_C2_3UVehStatus_OutDataSet;
    EXPECT_FLOAT_EQ(gOEM_SWC_C1_1UVehStatus_OutDataSet.mConc.V_x_ObjectSelectionAVMInput.V_x_vehicle_status.V_pm_rho_l, -340282346638528897590636046441678635008);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_OutDataSet.mConc.V_x_ObjectSelectionAVMInput.V_x_vehicle_status.V_pm_rho_l, -340282346638528897590636046441678635008);
    struct _func_V_x_ObjectSelectionAVMInput_ObjectSelectionAVM_15 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_ObjectSelectionAVMInput tmp_ObjectSelectionAVMInput;
            Rte_Read_V_x_ObjectSelectionAVMInput_V_x_ObjectSelectionAVMInput(&tmp_ObjectSelectionAVMInput);
            EXPECT_FLOAT_EQ(tmp_ObjectSelectionAVMInput.V_x_vehicle_status.V_pm_rho_l, -340282346638528897590636046441678635008);
        }
    } func_V_x_ObjectSelectionAVMInput_ObjectSelectionAVM_15;
    func_V_x_ObjectSelectionAVMInput_ObjectSelectionAVM_15.verify();

    extern UVehStatus_OutDataSet gOEM_SWC_C2_3UVehStatus_OutDataSet;
    EXPECT_FLOAT_EQ(gOEM_SWC_C1_1UVehStatus_OutDataSet.mConc.V_x_ObjectSelectionAVMInput.V_x_vehicle_status.V_degps_YawRateCorrected, -340282346638528897590636046441678635008);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_OutDataSet.mConc.V_x_ObjectSelectionAVMInput.V_x_vehicle_status.V_degps_YawRateCorrected, -340282346638528897590636046441678635008);
    struct _func_V_x_ObjectSelectionAVMInput_ObjectSelectionAVM_16 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_ObjectSelectionAVMInput tmp_ObjectSelectionAVMInput;
            Rte_Read_V_x_ObjectSelectionAVMInput_V_x_ObjectSelectionAVMInput(&tmp_ObjectSelectionAVMInput);
            EXPECT_FLOAT_EQ(tmp_ObjectSelectionAVMInput.V_x_vehicle_status.V_degps_YawRateCorrected, -340282346638528897590636046441678635008);
        }
    } func_V_x_ObjectSelectionAVMInput_ObjectSelectionAVM_16;
    func_V_x_ObjectSelectionAVMInput_ObjectSelectionAVM_16.verify();

    /* V_x_PWTWheelTorqueLimitationOrder_VSO*/
    extern UVehStatus_OutDataSet gOEM_SWC_C0_SMUVehStatus_OutDataSet;
    EXPECT_EQ(gOEM_SWC_C1_1UVehStatus_OutDataSet.mConc.V_x_PWTWheelTorqueLimitationOrder_VSO, 0);
    EXPECT_EQ(gOEM_SWC_C0_SMUVehStatus_OutDataSet.mConc.V_x_PWTWheelTorqueLimitationOrder_VSO, 0);
    struct _func_V_x_PWTWheelTorqueLimitationOrder_VSO_SafetyModule {
        static void verify(void) {
#include "Rte_Wrapper_SafetyModule.h"
            uint8 tmp_U8;
            Rte_Read_V_x_PWTWheelTorqueLimitationOrder_VSO_V_x_PWTWheelTorqueLimitationOrder_VSO(&tmp_U8);
            EXPECT_EQ(tmp_U8, 0);
        }
    } func_V_x_PWTWheelTorqueLimitationOrder_VSO_SafetyModule;
    func_V_x_PWTWheelTorqueLimitationOrder_VSO_SafetyModule.verify();

    /* V_x_RCarHMIManagementInput*/
    extern UVehStatus_OutDataSet gOEM_SWC_C2_3UVehStatus_OutDataSet;
    EXPECT_FLOAT_EQ(gOEM_SWC_C1_1UVehStatus_OutDataSet.mConc.V_x_RCarHMIManagementInput.V_x_vehicle_status.V_mps_VSP_LPF, -340282346638528897590636046441678635008);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_OutDataSet.mConc.V_x_RCarHMIManagementInput.V_x_vehicle_status.V_mps_VSP_LPF, -340282346638528897590636046441678635008);
    struct _func_V_x_RCarHMIManagementInput_RCarHMIManagement_0 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementInput tmp_RCarHMIManagementInput;
            Rte_Read_V_x_RCarHMIManagementInput_V_x_RCarHMIManagementInput(&tmp_RCarHMIManagementInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementInput.V_x_vehicle_status.V_mps_VSP_LPF, -340282346638528897590636046441678635008);
        }
    } func_V_x_RCarHMIManagementInput_RCarHMIManagement_0;
    func_V_x_RCarHMIManagementInput_RCarHMIManagement_0.verify();

    extern UVehStatus_OutDataSet gOEM_SWC_C2_3UVehStatus_OutDataSet;
    EXPECT_FLOAT_EQ(gOEM_SWC_C1_1UVehStatus_OutDataSet.mConc.V_x_RCarHMIManagementInput.V_x_vehicle_status.V_mps_AVE_VSP, -340282346638528897590636046441678635008);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_OutDataSet.mConc.V_x_RCarHMIManagementInput.V_x_vehicle_status.V_mps_AVE_VSP, -340282346638528897590636046441678635008);
    struct _func_V_x_RCarHMIManagementInput_RCarHMIManagement_1 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementInput tmp_RCarHMIManagementInput;
            Rte_Read_V_x_RCarHMIManagementInput_V_x_RCarHMIManagementInput(&tmp_RCarHMIManagementInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementInput.V_x_vehicle_status.V_mps_AVE_VSP, -340282346638528897590636046441678635008);
        }
    } func_V_x_RCarHMIManagementInput_RCarHMIManagement_1;
    func_V_x_RCarHMIManagementInput_RCarHMIManagement_1.verify();

    extern UVehStatus_OutDataSet gOEM_SWC_C2_3UVehStatus_OutDataSet;
    EXPECT_EQ(gOEM_SWC_C1_1UVehStatus_OutDataSet.mConc.V_x_RCarHMIManagementInput.V_x_vehicle_status.V_x_RangeIndication, 0);
    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_OutDataSet.mConc.V_x_RCarHMIManagementInput.V_x_vehicle_status.V_x_RangeIndication, 0);
    struct _func_V_x_RCarHMIManagementInput_RCarHMIManagement_2 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementInput tmp_RCarHMIManagementInput;
            Rte_Read_V_x_RCarHMIManagementInput_V_x_RCarHMIManagementInput(&tmp_RCarHMIManagementInput);
            EXPECT_EQ(tmp_RCarHMIManagementInput.V_x_vehicle_status.V_x_RangeIndication, 0);
        }
    } func_V_x_RCarHMIManagementInput_RCarHMIManagement_2;
    func_V_x_RCarHMIManagementInput_RCarHMIManagement_2.verify();

    extern UVehStatus_OutDataSet gOEM_SWC_C2_3UVehStatus_OutDataSet;
    EXPECT_EQ(gOEM_SWC_C1_1UVehStatus_OutDataSet.mConc.V_x_RCarHMIManagementInput.V_x_vehicle_status.F_x_CancelButton, 0);
    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_OutDataSet.mConc.V_x_RCarHMIManagementInput.V_x_vehicle_status.F_x_CancelButton, 0);
    struct _func_V_x_RCarHMIManagementInput_RCarHMIManagement_3 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementInput tmp_RCarHMIManagementInput;
            Rte_Read_V_x_RCarHMIManagementInput_V_x_RCarHMIManagementInput(&tmp_RCarHMIManagementInput);
            EXPECT_EQ(tmp_RCarHMIManagementInput.V_x_vehicle_status.F_x_CancelButton, 0);
        }
    } func_V_x_RCarHMIManagementInput_RCarHMIManagement_3;
    func_V_x_RCarHMIManagementInput_RCarHMIManagement_3.verify();

    extern UVehStatus_OutDataSet gOEM_SWC_C2_3UVehStatus_OutDataSet;
    EXPECT_EQ(gOEM_SWC_C1_1UVehStatus_OutDataSet.mConc.V_x_RCarHMIManagementInput.V_x_vehicle_status.F_x_MainSwOn4, 0);
    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_OutDataSet.mConc.V_x_RCarHMIManagementInput.V_x_vehicle_status.F_x_MainSwOn4, 0);
    struct _func_V_x_RCarHMIManagementInput_RCarHMIManagement_4 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementInput tmp_RCarHMIManagementInput;
            Rte_Read_V_x_RCarHMIManagementInput_V_x_RCarHMIManagementInput(&tmp_RCarHMIManagementInput);
            EXPECT_EQ(tmp_RCarHMIManagementInput.V_x_vehicle_status.F_x_MainSwOn4, 0);
        }
    } func_V_x_RCarHMIManagementInput_RCarHMIManagement_4;
    func_V_x_RCarHMIManagementInput_RCarHMIManagement_4.verify();

    extern UVehStatus_OutDataSet gOEM_SWC_C2_3UVehStatus_OutDataSet;
    EXPECT_FLOAT_EQ(gOEM_SWC_C1_1UVehStatus_OutDataSet.mConc.V_x_RCarHMIManagementInput.V_x_vehicle_status.V_deg_EPS_AngleSensor, -340282346638528897590636046441678635008);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_OutDataSet.mConc.V_x_RCarHMIManagementInput.V_x_vehicle_status.V_deg_EPS_AngleSensor, -340282346638528897590636046441678635008);
    struct _func_V_x_RCarHMIManagementInput_RCarHMIManagement_5 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementInput tmp_RCarHMIManagementInput;
            Rte_Read_V_x_RCarHMIManagementInput_V_x_RCarHMIManagementInput(&tmp_RCarHMIManagementInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementInput.V_x_vehicle_status.V_deg_EPS_AngleSensor, -340282346638528897590636046441678635008);
        }
    } func_V_x_RCarHMIManagementInput_RCarHMIManagement_5;
    func_V_x_RCarHMIManagementInput_RCarHMIManagement_5.verify();

    extern UVehStatus_OutDataSet gOEM_SWC_C2_3UVehStatus_OutDataSet;
    EXPECT_FLOAT_EQ(gOEM_SWC_C1_1UVehStatus_OutDataSet.mConc.V_x_RCarHMIManagementInput.V_x_vehicle_status.V_deg_SteeringWheelAngleRaw, -340282346638528897590636046441678635008);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_OutDataSet.mConc.V_x_RCarHMIManagementInput.V_x_vehicle_status.V_deg_SteeringWheelAngleRaw, -340282346638528897590636046441678635008);
    struct _func_V_x_RCarHMIManagementInput_RCarHMIManagement_6 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementInput tmp_RCarHMIManagementInput;
            Rte_Read_V_x_RCarHMIManagementInput_V_x_RCarHMIManagementInput(&tmp_RCarHMIManagementInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementInput.V_x_vehicle_status.V_deg_SteeringWheelAngleRaw, -340282346638528897590636046441678635008);
        }
    } func_V_x_RCarHMIManagementInput_RCarHMIManagement_6;
    func_V_x_RCarHMIManagementInput_RCarHMIManagement_6.verify();

    extern UVehStatus_OutDataSet gOEM_SWC_C2_3UVehStatus_OutDataSet;
    EXPECT_FLOAT_EQ(gOEM_SWC_C1_1UVehStatus_OutDataSet.mConc.V_x_RCarHMIManagementInput.V_x_vehicle_status.V_degps_YawRateRaw, -340282346638528897590636046441678635008);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_OutDataSet.mConc.V_x_RCarHMIManagementInput.V_x_vehicle_status.V_degps_YawRateRaw, -340282346638528897590636046441678635008);
    struct _func_V_x_RCarHMIManagementInput_RCarHMIManagement_7 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementInput tmp_RCarHMIManagementInput;
            Rte_Read_V_x_RCarHMIManagementInput_V_x_RCarHMIManagementInput(&tmp_RCarHMIManagementInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementInput.V_x_vehicle_status.V_degps_YawRateRaw, -340282346638528897590636046441678635008);
        }
    } func_V_x_RCarHMIManagementInput_RCarHMIManagement_7;
    func_V_x_RCarHMIManagementInput_RCarHMIManagement_7.verify();

    extern UVehStatus_OutDataSet gOEM_SWC_C2_3UVehStatus_OutDataSet;
    EXPECT_EQ(gOEM_SWC_C1_1UVehStatus_OutDataSet.mConc.V_x_RCarHMIManagementInput.V_x_vehicle_status.V_x_TurnInd, 0);
    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_OutDataSet.mConc.V_x_RCarHMIManagementInput.V_x_vehicle_status.V_x_TurnInd, 0);
    struct _func_V_x_RCarHMIManagementInput_RCarHMIManagement_8 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementInput tmp_RCarHMIManagementInput;
            Rte_Read_V_x_RCarHMIManagementInput_V_x_RCarHMIManagementInput(&tmp_RCarHMIManagementInput);
            EXPECT_EQ(tmp_RCarHMIManagementInput.V_x_vehicle_status.V_x_TurnInd, 0);
        }
    } func_V_x_RCarHMIManagementInput_RCarHMIManagement_8;
    func_V_x_RCarHMIManagementInput_RCarHMIManagement_8.verify();

    extern UVehStatus_OutDataSet gOEM_SWC_C2_3UVehStatus_OutDataSet;
    EXPECT_FLOAT_EQ(gOEM_SWC_C1_1UVehStatus_OutDataSet.mConc.V_x_RCarHMIManagementInput.V_x_vehicle_status.V_kph_VDCVehicleSpeed, -340282346638528897590636046441678635008);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_OutDataSet.mConc.V_x_RCarHMIManagementInput.V_x_vehicle_status.V_kph_VDCVehicleSpeed, -340282346638528897590636046441678635008);
    struct _func_V_x_RCarHMIManagementInput_RCarHMIManagement_9 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementInput tmp_RCarHMIManagementInput;
            Rte_Read_V_x_RCarHMIManagementInput_V_x_RCarHMIManagementInput(&tmp_RCarHMIManagementInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementInput.V_x_vehicle_status.V_kph_VDCVehicleSpeed, -340282346638528897590636046441678635008);
        }
    } func_V_x_RCarHMIManagementInput_RCarHMIManagement_9;
    func_V_x_RCarHMIManagementInput_RCarHMIManagement_9.verify();

    extern UVehStatus_OutDataSet gOEM_SWC_C2_3UVehStatus_OutDataSet;
    EXPECT_FLOAT_EQ(gOEM_SWC_C1_1UVehStatus_OutDataSet.mConc.V_x_RCarHMIManagementInput.V_x_vehicle_status.V_mps_VehSpeed_Est, -340282346638528897590636046441678635008);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_OutDataSet.mConc.V_x_RCarHMIManagementInput.V_x_vehicle_status.V_mps_VehSpeed_Est, -340282346638528897590636046441678635008);
    struct _func_V_x_RCarHMIManagementInput_RCarHMIManagement_10 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementInput tmp_RCarHMIManagementInput;
            Rte_Read_V_x_RCarHMIManagementInput_V_x_RCarHMIManagementInput(&tmp_RCarHMIManagementInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementInput.V_x_vehicle_status.V_mps_VehSpeed_Est, -340282346638528897590636046441678635008);
        }
    } func_V_x_RCarHMIManagementInput_RCarHMIManagement_10;
    func_V_x_RCarHMIManagementInput_RCarHMIManagement_10.verify();

    extern UVehStatus_OutDataSet gOEM_SWC_C2_3UVehStatus_OutDataSet;
    EXPECT_EQ(gOEM_SWC_C1_1UVehStatus_OutDataSet.mConc.V_x_RCarHMIManagementInput.V_x_vehicle_status.V_x_TURN_IND_Filter, 0);
    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_OutDataSet.mConc.V_x_RCarHMIManagementInput.V_x_vehicle_status.V_x_TURN_IND_Filter, 0);
    struct _func_V_x_RCarHMIManagementInput_RCarHMIManagement_11 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementInput tmp_RCarHMIManagementInput;
            Rte_Read_V_x_RCarHMIManagementInput_V_x_RCarHMIManagementInput(&tmp_RCarHMIManagementInput);
            EXPECT_EQ(tmp_RCarHMIManagementInput.V_x_vehicle_status.V_x_TURN_IND_Filter, 0);
        }
    } func_V_x_RCarHMIManagementInput_RCarHMIManagement_11;
    func_V_x_RCarHMIManagementInput_RCarHMIManagement_11.verify();

    extern UVehStatus_OutDataSet gOEM_SWC_C2_3UVehStatus_OutDataSet;
    EXPECT_EQ(gOEM_SWC_C1_1UVehStatus_OutDataSet.mConc.V_x_RCarHMIManagementInput.V_x_vehicle_status.V_x_Turn_Signal_Com, 0);
    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_OutDataSet.mConc.V_x_RCarHMIManagementInput.V_x_vehicle_status.V_x_Turn_Signal_Com, 0);
    struct _func_V_x_RCarHMIManagementInput_RCarHMIManagement_12 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementInput tmp_RCarHMIManagementInput;
            Rte_Read_V_x_RCarHMIManagementInput_V_x_RCarHMIManagementInput(&tmp_RCarHMIManagementInput);
            EXPECT_EQ(tmp_RCarHMIManagementInput.V_x_vehicle_status.V_x_Turn_Signal_Com, 0);
        }
    } func_V_x_RCarHMIManagementInput_RCarHMIManagement_12;
    func_V_x_RCarHMIManagementInput_RCarHMIManagement_12.verify();

    extern UVehStatus_OutDataSet gOEM_SWC_C2_3UVehStatus_OutDataSet;
    EXPECT_FLOAT_EQ(gOEM_SWC_C1_1UVehStatus_OutDataSet.mConc.V_x_RCarHMIManagementInput.V_x_vehicle_status.V_m_ycr_l, -340282346638528897590636046441678635008);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_OutDataSet.mConc.V_x_RCarHMIManagementInput.V_x_vehicle_status.V_m_ycr_l, -340282346638528897590636046441678635008);
    struct _func_V_x_RCarHMIManagementInput_RCarHMIManagement_13 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementInput tmp_RCarHMIManagementInput;
            Rte_Read_V_x_RCarHMIManagementInput_V_x_RCarHMIManagementInput(&tmp_RCarHMIManagementInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementInput.V_x_vehicle_status.V_m_ycr_l, -340282346638528897590636046441678635008);
        }
    } func_V_x_RCarHMIManagementInput_RCarHMIManagement_13;
    func_V_x_RCarHMIManagementInput_RCarHMIManagement_13.verify();

    extern UVehStatus_OutDataSet gOEM_SWC_C2_3UVehStatus_OutDataSet;
    EXPECT_FLOAT_EQ(gOEM_SWC_C1_1UVehStatus_OutDataSet.mConc.V_x_RCarHMIManagementInput.V_x_vehicle_status.V_rad_phi_l, -340282346638528897590636046441678635008);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_OutDataSet.mConc.V_x_RCarHMIManagementInput.V_x_vehicle_status.V_rad_phi_l, -340282346638528897590636046441678635008);
    struct _func_V_x_RCarHMIManagementInput_RCarHMIManagement_14 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementInput tmp_RCarHMIManagementInput;
            Rte_Read_V_x_RCarHMIManagementInput_V_x_RCarHMIManagementInput(&tmp_RCarHMIManagementInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementInput.V_x_vehicle_status.V_rad_phi_l, -340282346638528897590636046441678635008);
        }
    } func_V_x_RCarHMIManagementInput_RCarHMIManagement_14;
    func_V_x_RCarHMIManagementInput_RCarHMIManagement_14.verify();

    extern UVehStatus_OutDataSet gOEM_SWC_C2_3UVehStatus_OutDataSet;
    EXPECT_FLOAT_EQ(gOEM_SWC_C1_1UVehStatus_OutDataSet.mConc.V_x_RCarHMIManagementInput.V_x_vehicle_status.V_pm_rho_l, -340282346638528897590636046441678635008);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_OutDataSet.mConc.V_x_RCarHMIManagementInput.V_x_vehicle_status.V_pm_rho_l, -340282346638528897590636046441678635008);
    struct _func_V_x_RCarHMIManagementInput_RCarHMIManagement_15 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementInput tmp_RCarHMIManagementInput;
            Rte_Read_V_x_RCarHMIManagementInput_V_x_RCarHMIManagementInput(&tmp_RCarHMIManagementInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementInput.V_x_vehicle_status.V_pm_rho_l, -340282346638528897590636046441678635008);
        }
    } func_V_x_RCarHMIManagementInput_RCarHMIManagement_15;
    func_V_x_RCarHMIManagementInput_RCarHMIManagement_15.verify();

    extern UVehStatus_OutDataSet gOEM_SWC_C2_3UVehStatus_OutDataSet;
    EXPECT_FLOAT_EQ(gOEM_SWC_C1_1UVehStatus_OutDataSet.mConc.V_x_RCarHMIManagementInput.V_x_vehicle_status.V_degps_YawRateCorrected, -340282346638528897590636046441678635008);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_OutDataSet.mConc.V_x_RCarHMIManagementInput.V_x_vehicle_status.V_degps_YawRateCorrected, -340282346638528897590636046441678635008);
    struct _func_V_x_RCarHMIManagementInput_RCarHMIManagement_16 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementInput tmp_RCarHMIManagementInput;
            Rte_Read_V_x_RCarHMIManagementInput_V_x_RCarHMIManagementInput(&tmp_RCarHMIManagementInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementInput.V_x_vehicle_status.V_degps_YawRateCorrected, -340282346638528897590636046441678635008);
        }
    } func_V_x_RCarHMIManagementInput_RCarHMIManagement_16;
    func_V_x_RCarHMIManagementInput_RCarHMIManagement_16.verify();

    extern UVehStatus_OutDataSet gOEM_SWC_C2_3UVehStatus_OutDataSet;
    EXPECT_EQ(gOEM_SWC_C1_1UVehStatus_OutDataSet.mConc.V_x_RCarHMIManagementInput.V_x_ctrl_flag.V_x_InternalACCStatus, 0);
    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_OutDataSet.mConc.V_x_RCarHMIManagementInput.V_x_ctrl_flag.V_x_InternalACCStatus, 0);
    struct _func_V_x_RCarHMIManagementInput_RCarHMIManagement_17 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementInput tmp_RCarHMIManagementInput;
            Rte_Read_V_x_RCarHMIManagementInput_V_x_RCarHMIManagementInput(&tmp_RCarHMIManagementInput);
            EXPECT_EQ(tmp_RCarHMIManagementInput.V_x_ctrl_flag.V_x_InternalACCStatus, 0);
        }
    } func_V_x_RCarHMIManagementInput_RCarHMIManagement_17;
    func_V_x_RCarHMIManagementInput_RCarHMIManagement_17.verify();

    extern UVehStatus_OutDataSet gOEM_SWC_C2_3UVehStatus_OutDataSet;
    EXPECT_EQ(gOEM_SWC_C1_1UVehStatus_OutDataSet.mConc.V_x_RCarHMIManagementInput.V_x_ctrl_flag.F_x_Lch_on, 0);
    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_OutDataSet.mConc.V_x_RCarHMIManagementInput.V_x_ctrl_flag.F_x_Lch_on, 0);
    struct _func_V_x_RCarHMIManagementInput_RCarHMIManagement_18 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementInput tmp_RCarHMIManagementInput;
            Rte_Read_V_x_RCarHMIManagementInput_V_x_RCarHMIManagementInput(&tmp_RCarHMIManagementInput);
            EXPECT_EQ(tmp_RCarHMIManagementInput.V_x_ctrl_flag.F_x_Lch_on, 0);
        }
    } func_V_x_RCarHMIManagementInput_RCarHMIManagement_18;
    func_V_x_RCarHMIManagementInput_RCarHMIManagement_18.verify();

    extern UVehStatus_OutDataSet gOEM_SWC_C2_3UVehStatus_OutDataSet;
    EXPECT_EQ(gOEM_SWC_C1_1UVehStatus_OutDataSet.mConc.V_x_RCarHMIManagementInput.V_x_ctrl_flag.V_x_Lch_dir_fix, -128);
    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_OutDataSet.mConc.V_x_RCarHMIManagementInput.V_x_ctrl_flag.V_x_Lch_dir_fix, -128);
    struct _func_V_x_RCarHMIManagementInput_RCarHMIManagement_19 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementInput tmp_RCarHMIManagementInput;
            Rte_Read_V_x_RCarHMIManagementInput_V_x_RCarHMIManagementInput(&tmp_RCarHMIManagementInput);
            EXPECT_EQ(tmp_RCarHMIManagementInput.V_x_ctrl_flag.V_x_Lch_dir_fix, -128);
        }
    } func_V_x_RCarHMIManagementInput_RCarHMIManagement_19;
    func_V_x_RCarHMIManagementInput_RCarHMIManagement_19.verify();

    extern UVehStatus_OutDataSet gOEM_SWC_C2_3UVehStatus_OutDataSet;
    EXPECT_EQ(gOEM_SWC_C1_1UVehStatus_OutDataSet.mConc.V_x_RCarHMIManagementInput.V_x_ctrl_flag.F_x_DriverSteer, 0);
    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_OutDataSet.mConc.V_x_RCarHMIManagementInput.V_x_ctrl_flag.F_x_DriverSteer, 0);
    struct _func_V_x_RCarHMIManagementInput_RCarHMIManagement_20 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementInput tmp_RCarHMIManagementInput;
            Rte_Read_V_x_RCarHMIManagementInput_V_x_RCarHMIManagementInput(&tmp_RCarHMIManagementInput);
            EXPECT_EQ(tmp_RCarHMIManagementInput.V_x_ctrl_flag.F_x_DriverSteer, 0);
        }
    } func_V_x_RCarHMIManagementInput_RCarHMIManagement_20;
    func_V_x_RCarHMIManagementInput_RCarHMIManagement_20.verify();

    extern UVehStatus_OutDataSet gOEM_SWC_C2_3UVehStatus_OutDataSet;
    EXPECT_EQ(gOEM_SWC_C1_1UVehStatus_OutDataSet.mConc.V_x_RCarHMIManagementInput.V_x_ctrl_flag.F_x_Lanechange_abort, 0);
    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_OutDataSet.mConc.V_x_RCarHMIManagementInput.V_x_ctrl_flag.F_x_Lanechange_abort, 0);
    struct _func_V_x_RCarHMIManagementInput_RCarHMIManagement_21 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementInput tmp_RCarHMIManagementInput;
            Rte_Read_V_x_RCarHMIManagementInput_V_x_RCarHMIManagementInput(&tmp_RCarHMIManagementInput);
            EXPECT_EQ(tmp_RCarHMIManagementInput.V_x_ctrl_flag.F_x_Lanechange_abort, 0);
        }
    } func_V_x_RCarHMIManagementInput_RCarHMIManagement_21;
    func_V_x_RCarHMIManagementInput_RCarHMIManagement_21.verify();

    extern UVehStatus_OutDataSet gOEM_SWC_C2_3UVehStatus_OutDataSet;
    EXPECT_EQ(gOEM_SWC_C1_1UVehStatus_OutDataSet.mConc.V_x_RCarHMIManagementInput.V_x_ctrl_flag.V_x_LatControlModeSel, 0);
    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_OutDataSet.mConc.V_x_RCarHMIManagementInput.V_x_ctrl_flag.V_x_LatControlModeSel, 0);
    struct _func_V_x_RCarHMIManagementInput_RCarHMIManagement_22 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementInput tmp_RCarHMIManagementInput;
            Rte_Read_V_x_RCarHMIManagementInput_V_x_RCarHMIManagementInput(&tmp_RCarHMIManagementInput);
            EXPECT_EQ(tmp_RCarHMIManagementInput.V_x_ctrl_flag.V_x_LatControlModeSel, 0);
        }
    } func_V_x_RCarHMIManagementInput_RCarHMIManagement_22;
    func_V_x_RCarHMIManagementInput_RCarHMIManagement_22.verify();

    extern UVehStatus_OutDataSet gOEM_SWC_C2_3UVehStatus_OutDataSet;
    EXPECT_EQ(gOEM_SWC_C1_1UVehStatus_OutDataSet.mConc.V_x_RCarHMIManagementInput.V_x_ctrl_flag.F_x_Lch_pass_announce_toRight, 0);
    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_OutDataSet.mConc.V_x_RCarHMIManagementInput.V_x_ctrl_flag.F_x_Lch_pass_announce_toRight, 0);
    struct _func_V_x_RCarHMIManagementInput_RCarHMIManagement_23 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementInput tmp_RCarHMIManagementInput;
            Rte_Read_V_x_RCarHMIManagementInput_V_x_RCarHMIManagementInput(&tmp_RCarHMIManagementInput);
            EXPECT_EQ(tmp_RCarHMIManagementInput.V_x_ctrl_flag.F_x_Lch_pass_announce_toRight, 0);
        }
    } func_V_x_RCarHMIManagementInput_RCarHMIManagement_23;
    func_V_x_RCarHMIManagementInput_RCarHMIManagement_23.verify();

    extern UVehStatus_OutDataSet gOEM_SWC_C2_3UVehStatus_OutDataSet;
    EXPECT_EQ(gOEM_SWC_C1_1UVehStatus_OutDataSet.mConc.V_x_RCarHMIManagementInput.V_x_ctrl_flag.F_x_Lch_return_announce_toLeft, 0);
    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_OutDataSet.mConc.V_x_RCarHMIManagementInput.V_x_ctrl_flag.F_x_Lch_return_announce_toLeft, 0);
    struct _func_V_x_RCarHMIManagementInput_RCarHMIManagement_24 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementInput tmp_RCarHMIManagementInput;
            Rte_Read_V_x_RCarHMIManagementInput_V_x_RCarHMIManagementInput(&tmp_RCarHMIManagementInput);
            EXPECT_EQ(tmp_RCarHMIManagementInput.V_x_ctrl_flag.F_x_Lch_return_announce_toLeft, 0);
        }
    } func_V_x_RCarHMIManagementInput_RCarHMIManagement_24;
    func_V_x_RCarHMIManagementInput_RCarHMIManagement_24.verify();

    extern UVehStatus_OutDataSet gOEM_SWC_C2_3UVehStatus_OutDataSet;
    EXPECT_EQ(gOEM_SWC_C1_1UVehStatus_OutDataSet.mConc.V_x_RCarHMIManagementInput.V_x_ctrl_flag.V_x_HandsOnJdg, 0);
    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_OutDataSet.mConc.V_x_RCarHMIManagementInput.V_x_ctrl_flag.V_x_HandsOnJdg, 0);
    struct _func_V_x_RCarHMIManagementInput_RCarHMIManagement_25 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementInput tmp_RCarHMIManagementInput;
            Rte_Read_V_x_RCarHMIManagementInput_V_x_RCarHMIManagementInput(&tmp_RCarHMIManagementInput);
            EXPECT_EQ(tmp_RCarHMIManagementInput.V_x_ctrl_flag.V_x_HandsOnJdg, 0);
        }
    } func_V_x_RCarHMIManagementInput_RCarHMIManagement_25;
    func_V_x_RCarHMIManagementInput_RCarHMIManagement_25.verify();

    extern UVehStatus_OutDataSet gOEM_SWC_C2_3UVehStatus_OutDataSet;
    EXPECT_EQ(gOEM_SWC_C1_1UVehStatus_OutDataSet.mConc.V_x_RCarHMIManagementInput.V_x_ctrl_flag.V_x_ADCtrlStat, 0);
    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_OutDataSet.mConc.V_x_RCarHMIManagementInput.V_x_ctrl_flag.V_x_ADCtrlStat, 0);
    struct _func_V_x_RCarHMIManagementInput_RCarHMIManagement_26 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementInput tmp_RCarHMIManagementInput;
            Rte_Read_V_x_RCarHMIManagementInput_V_x_RCarHMIManagementInput(&tmp_RCarHMIManagementInput);
            EXPECT_EQ(tmp_RCarHMIManagementInput.V_x_ctrl_flag.V_x_ADCtrlStat, 0);
        }
    } func_V_x_RCarHMIManagementInput_RCarHMIManagement_26;
    func_V_x_RCarHMIManagementInput_RCarHMIManagement_26.verify();

    extern UVehStatus_OutDataSet gOEM_SWC_C2_3UVehStatus_OutDataSet;
    EXPECT_EQ(gOEM_SWC_C1_1UVehStatus_OutDataSet.mConc.V_x_RCarHMIManagementInput.V_x_ctrl_flag.V_x_NumOfSystemAutoLC_Right, 0);
    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_OutDataSet.mConc.V_x_RCarHMIManagementInput.V_x_ctrl_flag.V_x_NumOfSystemAutoLC_Right, 0);
    struct _func_V_x_RCarHMIManagementInput_RCarHMIManagement_27 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementInput tmp_RCarHMIManagementInput;
            Rte_Read_V_x_RCarHMIManagementInput_V_x_RCarHMIManagementInput(&tmp_RCarHMIManagementInput);
            EXPECT_EQ(tmp_RCarHMIManagementInput.V_x_ctrl_flag.V_x_NumOfSystemAutoLC_Right, 0);
        }
    } func_V_x_RCarHMIManagementInput_RCarHMIManagement_27;
    func_V_x_RCarHMIManagementInput_RCarHMIManagement_27.verify();

    extern UVehStatus_OutDataSet gOEM_SWC_C2_3UVehStatus_OutDataSet;
    EXPECT_EQ(gOEM_SWC_C1_1UVehStatus_OutDataSet.mConc.V_x_RCarHMIManagementInput.V_x_ctrl_flag.V_x_LaneChangeType, 0);
    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_OutDataSet.mConc.V_x_RCarHMIManagementInput.V_x_ctrl_flag.V_x_LaneChangeType, 0);
    struct _func_V_x_RCarHMIManagementInput_RCarHMIManagement_28 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementInput tmp_RCarHMIManagementInput;
            Rte_Read_V_x_RCarHMIManagementInput_V_x_RCarHMIManagementInput(&tmp_RCarHMIManagementInput);
            EXPECT_EQ(tmp_RCarHMIManagementInput.V_x_ctrl_flag.V_x_LaneChangeType, 0);
        }
    } func_V_x_RCarHMIManagementInput_RCarHMIManagement_28;
    func_V_x_RCarHMIManagementInput_RCarHMIManagement_28.verify();

    extern UVehStatus_OutDataSet gOEM_SWC_C2_3UVehStatus_OutDataSet;
    EXPECT_EQ(gOEM_SWC_C1_1UVehStatus_OutDataSet.mConc.V_x_RCarHMIManagementInput.V_x_ctrl_flag.V_x_ALC_InternalState, 0);
    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_OutDataSet.mConc.V_x_RCarHMIManagementInput.V_x_ctrl_flag.V_x_ALC_InternalState, 0);
    struct _func_V_x_RCarHMIManagementInput_RCarHMIManagement_29 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementInput tmp_RCarHMIManagementInput;
            Rte_Read_V_x_RCarHMIManagementInput_V_x_RCarHMIManagementInput(&tmp_RCarHMIManagementInput);
            EXPECT_EQ(tmp_RCarHMIManagementInput.V_x_ctrl_flag.V_x_ALC_InternalState, 0);
        }
    } func_V_x_RCarHMIManagementInput_RCarHMIManagement_29;
    func_V_x_RCarHMIManagementInput_RCarHMIManagement_29.verify();

    extern UVehStatus_OutDataSet gOEM_SWC_C2_3UVehStatus_OutDataSet;
    EXPECT_EQ(gOEM_SWC_C1_1UVehStatus_OutDataSet.mConc.V_x_RCarHMIManagementInput.V_x_ctrl_flag.V_x_AutoLCDirection_HMI, 0);
    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_OutDataSet.mConc.V_x_RCarHMIManagementInput.V_x_ctrl_flag.V_x_AutoLCDirection_HMI, 0);
    struct _func_V_x_RCarHMIManagementInput_RCarHMIManagement_30 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementInput tmp_RCarHMIManagementInput;
            Rte_Read_V_x_RCarHMIManagementInput_V_x_RCarHMIManagementInput(&tmp_RCarHMIManagementInput);
            EXPECT_EQ(tmp_RCarHMIManagementInput.V_x_ctrl_flag.V_x_AutoLCDirection_HMI, 0);
        }
    } func_V_x_RCarHMIManagementInput_RCarHMIManagement_30;
    func_V_x_RCarHMIManagementInput_RCarHMIManagement_30.verify();

    extern UVehStatus_OutDataSet gOEM_SWC_C2_3UVehStatus_OutDataSet;
    EXPECT_EQ(gOEM_SWC_C1_1UVehStatus_OutDataSet.mConc.V_x_RCarHMIManagementInput.V_x_ctrl_flag.V_x_FS_ALCState, 0);
    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_OutDataSet.mConc.V_x_RCarHMIManagementInput.V_x_ctrl_flag.V_x_FS_ALCState, 0);
    struct _func_V_x_RCarHMIManagementInput_RCarHMIManagement_31 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementInput tmp_RCarHMIManagementInput;
            Rte_Read_V_x_RCarHMIManagementInput_V_x_RCarHMIManagementInput(&tmp_RCarHMIManagementInput);
            EXPECT_EQ(tmp_RCarHMIManagementInput.V_x_ctrl_flag.V_x_FS_ALCState, 0);
        }
    } func_V_x_RCarHMIManagementInput_RCarHMIManagement_31;
    func_V_x_RCarHMIManagementInput_RCarHMIManagement_31.verify();

    extern UVehStatus_OutDataSet gOEM_SWC_C2_3UVehStatus_OutDataSet;
    EXPECT_EQ(gOEM_SWC_C1_1UVehStatus_OutDataSet.mConc.V_x_RCarHMIManagementInput.V_x_ctrl_flag.F_x_InitLane, 0);
    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_OutDataSet.mConc.V_x_RCarHMIManagementInput.V_x_ctrl_flag.F_x_InitLane, 0);
    struct _func_V_x_RCarHMIManagementInput_RCarHMIManagement_32 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementInput tmp_RCarHMIManagementInput;
            Rte_Read_V_x_RCarHMIManagementInput_V_x_RCarHMIManagementInput(&tmp_RCarHMIManagementInput);
            EXPECT_EQ(tmp_RCarHMIManagementInput.V_x_ctrl_flag.F_x_InitLane, 0);
        }
    } func_V_x_RCarHMIManagementInput_RCarHMIManagement_32;
    func_V_x_RCarHMIManagementInput_RCarHMIManagement_32.verify();

    extern UVehStatus_OutDataSet gOEM_SWC_C2_3UVehStatus_OutDataSet;
    EXPECT_EQ(gOEM_SWC_C1_1UVehStatus_OutDataSet.mConc.V_x_RCarHMIManagementInput.V_x_ctrl_flag.F_x_IniSteer, 0);
    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_OutDataSet.mConc.V_x_RCarHMIManagementInput.V_x_ctrl_flag.F_x_IniSteer, 0);
    struct _func_V_x_RCarHMIManagementInput_RCarHMIManagement_33 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementInput tmp_RCarHMIManagementInput;
            Rte_Read_V_x_RCarHMIManagementInput_V_x_RCarHMIManagementInput(&tmp_RCarHMIManagementInput);
            EXPECT_EQ(tmp_RCarHMIManagementInput.V_x_ctrl_flag.F_x_IniSteer, 0);
        }
    } func_V_x_RCarHMIManagementInput_RCarHMIManagement_33;
    func_V_x_RCarHMIManagementInput_RCarHMIManagement_33.verify();

    extern UVehStatus_OutDataSet gOEM_SWC_C2_3UVehStatus_OutDataSet;
    EXPECT_EQ(gOEM_SWC_C1_1UVehStatus_OutDataSet.mConc.V_x_RCarHMIManagementInput.V_x_ctrl_flag.F_x_SteerCntrl2, 0);
    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_OutDataSet.mConc.V_x_RCarHMIManagementInput.V_x_ctrl_flag.F_x_SteerCntrl2, 0);
    struct _func_V_x_RCarHMIManagementInput_RCarHMIManagement_34 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementInput tmp_RCarHMIManagementInput;
            Rte_Read_V_x_RCarHMIManagementInput_V_x_RCarHMIManagementInput(&tmp_RCarHMIManagementInput);
            EXPECT_EQ(tmp_RCarHMIManagementInput.V_x_ctrl_flag.F_x_SteerCntrl2, 0);
        }
    } func_V_x_RCarHMIManagementInput_RCarHMIManagement_34;
    func_V_x_RCarHMIManagementInput_RCarHMIManagement_34.verify();

    extern UVehStatus_OutDataSet gOEM_SWC_C2_3UVehStatus_OutDataSet;
    EXPECT_EQ(gOEM_SWC_C1_1UVehStatus_OutDataSet.mConc.V_x_RCarHMIManagementInput.V_x_ctrl_flag.F_x_TurnIndLeftValid, 0);
    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_OutDataSet.mConc.V_x_RCarHMIManagementInput.V_x_ctrl_flag.F_x_TurnIndLeftValid, 0);
    struct _func_V_x_RCarHMIManagementInput_RCarHMIManagement_35 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementInput tmp_RCarHMIManagementInput;
            Rte_Read_V_x_RCarHMIManagementInput_V_x_RCarHMIManagementInput(&tmp_RCarHMIManagementInput);
            EXPECT_EQ(tmp_RCarHMIManagementInput.V_x_ctrl_flag.F_x_TurnIndLeftValid, 0);
        }
    } func_V_x_RCarHMIManagementInput_RCarHMIManagement_35;
    func_V_x_RCarHMIManagementInput_RCarHMIManagement_35.verify();

    extern UVehStatus_OutDataSet gOEM_SWC_C2_3UVehStatus_OutDataSet;
    EXPECT_EQ(gOEM_SWC_C1_1UVehStatus_OutDataSet.mConc.V_x_RCarHMIManagementInput.V_x_ctrl_flag.F_x_TurnIndRightValid, 0);
    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_OutDataSet.mConc.V_x_RCarHMIManagementInput.V_x_ctrl_flag.F_x_TurnIndRightValid, 0);
    struct _func_V_x_RCarHMIManagementInput_RCarHMIManagement_36 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementInput tmp_RCarHMIManagementInput;
            Rte_Read_V_x_RCarHMIManagementInput_V_x_RCarHMIManagementInput(&tmp_RCarHMIManagementInput);
            EXPECT_EQ(tmp_RCarHMIManagementInput.V_x_ctrl_flag.F_x_TurnIndRightValid, 0);
        }
    } func_V_x_RCarHMIManagementInput_RCarHMIManagement_36;
    func_V_x_RCarHMIManagementInput_RCarHMIManagement_36.verify();

    extern UVehStatus_OutDataSet gOEM_SWC_C2_3UVehStatus_OutDataSet;
    EXPECT_EQ(gOEM_SWC_C1_1UVehStatus_OutDataSet.mConc.V_x_RCarHMIManagementInput.V_x_ctrl_flag.V_x_Lch_dir_pre, -128);
    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_OutDataSet.mConc.V_x_RCarHMIManagementInput.V_x_ctrl_flag.V_x_Lch_dir_pre, -128);
    struct _func_V_x_RCarHMIManagementInput_RCarHMIManagement_37 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementInput tmp_RCarHMIManagementInput;
            Rte_Read_V_x_RCarHMIManagementInput_V_x_RCarHMIManagementInput(&tmp_RCarHMIManagementInput);
            EXPECT_EQ(tmp_RCarHMIManagementInput.V_x_ctrl_flag.V_x_Lch_dir_pre, -128);
        }
    } func_V_x_RCarHMIManagementInput_RCarHMIManagement_37;
    func_V_x_RCarHMIManagementInput_RCarHMIManagement_37.verify();

    extern UVehStatus_OutDataSet gOEM_SWC_C2_3UVehStatus_OutDataSet;
    EXPECT_EQ(gOEM_SWC_C1_1UVehStatus_OutDataSet.mConc.V_x_RCarHMIManagementInput.V_x_prec_vehicle_info.V_x_SENSOR_SEL, 0);
    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_OutDataSet.mConc.V_x_RCarHMIManagementInput.V_x_prec_vehicle_info.V_x_SENSOR_SEL, 0);
    struct _func_V_x_RCarHMIManagementInput_RCarHMIManagement_38 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementInput tmp_RCarHMIManagementInput;
            Rte_Read_V_x_RCarHMIManagementInput_V_x_RCarHMIManagementInput(&tmp_RCarHMIManagementInput);
            EXPECT_EQ(tmp_RCarHMIManagementInput.V_x_prec_vehicle_info.V_x_SENSOR_SEL, 0);
        }
    } func_V_x_RCarHMIManagementInput_RCarHMIManagement_38;
    func_V_x_RCarHMIManagementInput_RCarHMIManagement_38.verify();

    extern UVehStatus_OutDataSet gOEM_SWC_C2_3UVehStatus_OutDataSet;
    EXPECT_EQ(gOEM_SWC_C1_1UVehStatus_OutDataSet.mConc.V_x_RCarHMIManagementInput.V_x_prec_vehicle_info.V_x_SensorSelEgo, 0);
    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_OutDataSet.mConc.V_x_RCarHMIManagementInput.V_x_prec_vehicle_info.V_x_SensorSelEgo, 0);
    struct _func_V_x_RCarHMIManagementInput_RCarHMIManagement_39 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementInput tmp_RCarHMIManagementInput;
            Rte_Read_V_x_RCarHMIManagementInput_V_x_RCarHMIManagementInput(&tmp_RCarHMIManagementInput);
            EXPECT_EQ(tmp_RCarHMIManagementInput.V_x_prec_vehicle_info.V_x_SensorSelEgo, 0);
        }
    } func_V_x_RCarHMIManagementInput_RCarHMIManagement_39;
    func_V_x_RCarHMIManagementInput_RCarHMIManagement_39.verify();

    extern UVehStatus_OutDataSet gOEM_SWC_C2_3UVehStatus_OutDataSet;
    EXPECT_FLOAT_EQ(gOEM_SWC_C1_1UVehStatus_OutDataSet.mConc.V_x_RCarHMIManagementInput.V_x_prec_vehicle_info.V_mps2_DecelerationEgo, -340282346638528897590636046441678635008);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_OutDataSet.mConc.V_x_RCarHMIManagementInput.V_x_prec_vehicle_info.V_mps2_DecelerationEgo, -340282346638528897590636046441678635008);
    struct _func_V_x_RCarHMIManagementInput_RCarHMIManagement_40 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementInput tmp_RCarHMIManagementInput;
            Rte_Read_V_x_RCarHMIManagementInput_V_x_RCarHMIManagementInput(&tmp_RCarHMIManagementInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementInput.V_x_prec_vehicle_info.V_mps2_DecelerationEgo, -340282346638528897590636046441678635008);
        }
    } func_V_x_RCarHMIManagementInput_RCarHMIManagement_40;
    func_V_x_RCarHMIManagementInput_RCarHMIManagement_40.verify();

    extern UVehStatus_OutDataSet gOEM_SWC_C2_3UVehStatus_OutDataSet;
    EXPECT_FLOAT_EQ(gOEM_SWC_C1_1UVehStatus_OutDataSet.mConc.V_x_RCarHMIManagementInput.V_x_prec_vehicle_info.V_m_Distance, -340282346638528897590636046441678635008);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_OutDataSet.mConc.V_x_RCarHMIManagementInput.V_x_prec_vehicle_info.V_m_Distance, -340282346638528897590636046441678635008);
    struct _func_V_x_RCarHMIManagementInput_RCarHMIManagement_41 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementInput tmp_RCarHMIManagementInput;
            Rte_Read_V_x_RCarHMIManagementInput_V_x_RCarHMIManagementInput(&tmp_RCarHMIManagementInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementInput.V_x_prec_vehicle_info.V_m_Distance, -340282346638528897590636046441678635008);
        }
    } func_V_x_RCarHMIManagementInput_RCarHMIManagement_41;
    func_V_x_RCarHMIManagementInput_RCarHMIManagement_41.verify();

    extern UVehStatus_OutDataSet gOEM_SWC_C2_3UVehStatus_OutDataSet;
    EXPECT_FLOAT_EQ(gOEM_SWC_C1_1UVehStatus_OutDataSet.mConc.V_x_RCarHMIManagementInput.V_x_prec_vehicle_info.V_m_PrecVehicleLatDistance, -340282346638528897590636046441678635008);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_OutDataSet.mConc.V_x_RCarHMIManagementInput.V_x_prec_vehicle_info.V_m_PrecVehicleLatDistance, -340282346638528897590636046441678635008);
    struct _func_V_x_RCarHMIManagementInput_RCarHMIManagement_42 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementInput tmp_RCarHMIManagementInput;
            Rte_Read_V_x_RCarHMIManagementInput_V_x_RCarHMIManagementInput(&tmp_RCarHMIManagementInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementInput.V_x_prec_vehicle_info.V_m_PrecVehicleLatDistance, -340282346638528897590636046441678635008);
        }
    } func_V_x_RCarHMIManagementInput_RCarHMIManagement_42;
    func_V_x_RCarHMIManagementInput_RCarHMIManagement_42.verify();

    extern UVehStatus_OutDataSet gOEM_SWC_C2_3UVehStatus_OutDataSet;
    EXPECT_FLOAT_EQ(gOEM_SWC_C1_1UVehStatus_OutDataSet.mConc.V_x_RCarHMIManagementInput.V_x_prec_vehicle_info.V_mps_RelativeSpeed, -340282346638528897590636046441678635008);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_OutDataSet.mConc.V_x_RCarHMIManagementInput.V_x_prec_vehicle_info.V_mps_RelativeSpeed, -340282346638528897590636046441678635008);
    struct _func_V_x_RCarHMIManagementInput_RCarHMIManagement_43 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementInput tmp_RCarHMIManagementInput;
            Rte_Read_V_x_RCarHMIManagementInput_V_x_RCarHMIManagementInput(&tmp_RCarHMIManagementInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementInput.V_x_prec_vehicle_info.V_mps_RelativeSpeed, -340282346638528897590636046441678635008);
        }
    } func_V_x_RCarHMIManagementInput_RCarHMIManagement_43;
    func_V_x_RCarHMIManagementInput_RCarHMIManagement_43.verify();

    extern UVehStatus_OutDataSet gOEM_SWC_C2_3UVehStatus_OutDataSet;
    EXPECT_FLOAT_EQ(gOEM_SWC_C1_1UVehStatus_OutDataSet.mConc.V_x_RCarHMIManagementInput.V_x_front_cam_lane_sel.V_m_Position_LKA_SEL_LANE, -340282346638528897590636046441678635008);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_OutDataSet.mConc.V_x_RCarHMIManagementInput.V_x_front_cam_lane_sel.V_m_Position_LKA_SEL_LANE, -340282346638528897590636046441678635008);
    struct _func_V_x_RCarHMIManagementInput_RCarHMIManagement_44 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementInput tmp_RCarHMIManagementInput;
            Rte_Read_V_x_RCarHMIManagementInput_V_x_RCarHMIManagementInput(&tmp_RCarHMIManagementInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementInput.V_x_front_cam_lane_sel.V_m_Position_LKA_SEL_LANE, -340282346638528897590636046441678635008);
        }
    } func_V_x_RCarHMIManagementInput_RCarHMIManagement_44;
    func_V_x_RCarHMIManagementInput_RCarHMIManagement_44.verify();

    extern UVehStatus_OutDataSet gOEM_SWC_C2_3UVehStatus_OutDataSet;
    EXPECT_FLOAT_EQ(gOEM_SWC_C1_1UVehStatus_OutDataSet.mConc.V_x_RCarHMIManagementInput.V_x_front_cam_lane_sel.V_rad_Heading_LKA_SEL_LANE, -340282346638528897590636046441678635008);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_OutDataSet.mConc.V_x_RCarHMIManagementInput.V_x_front_cam_lane_sel.V_rad_Heading_LKA_SEL_LANE, -340282346638528897590636046441678635008);
    struct _func_V_x_RCarHMIManagementInput_RCarHMIManagement_45 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementInput tmp_RCarHMIManagementInput;
            Rte_Read_V_x_RCarHMIManagementInput_V_x_RCarHMIManagementInput(&tmp_RCarHMIManagementInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementInput.V_x_front_cam_lane_sel.V_rad_Heading_LKA_SEL_LANE, -340282346638528897590636046441678635008);
        }
    } func_V_x_RCarHMIManagementInput_RCarHMIManagement_45;
    func_V_x_RCarHMIManagementInput_RCarHMIManagement_45.verify();

    extern UVehStatus_OutDataSet gOEM_SWC_C2_3UVehStatus_OutDataSet;
    EXPECT_EQ(gOEM_SWC_C1_1UVehStatus_OutDataSet.mConc.V_x_RCarHMIManagementInput.V_x_front_cam_lane_sel.V_x_Quality_LKA_SEL_LANE, 0);
    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_OutDataSet.mConc.V_x_RCarHMIManagementInput.V_x_front_cam_lane_sel.V_x_Quality_LKA_SEL_LANE, 0);
    struct _func_V_x_RCarHMIManagementInput_RCarHMIManagement_46 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementInput tmp_RCarHMIManagementInput;
            Rte_Read_V_x_RCarHMIManagementInput_V_x_RCarHMIManagementInput(&tmp_RCarHMIManagementInput);
            EXPECT_EQ(tmp_RCarHMIManagementInput.V_x_front_cam_lane_sel.V_x_Quality_LKA_SEL_LANE, 0);
        }
    } func_V_x_RCarHMIManagementInput_RCarHMIManagement_46;
    func_V_x_RCarHMIManagementInput_RCarHMIManagement_46.verify();

    extern UVehStatus_OutDataSet gOEM_SWC_C2_3UVehStatus_OutDataSet;
    EXPECT_FLOAT_EQ(gOEM_SWC_C1_1UVehStatus_OutDataSet.mConc.V_x_RCarHMIManagementInput.V_x_front_cam_lane_sel.V_pm_Curvature_LKA_SEL, -340282346638528897590636046441678635008);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_OutDataSet.mConc.V_x_RCarHMIManagementInput.V_x_front_cam_lane_sel.V_pm_Curvature_LKA_SEL, -340282346638528897590636046441678635008);
    struct _func_V_x_RCarHMIManagementInput_RCarHMIManagement_47 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementInput tmp_RCarHMIManagementInput;
            Rte_Read_V_x_RCarHMIManagementInput_V_x_RCarHMIManagementInput(&tmp_RCarHMIManagementInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementInput.V_x_front_cam_lane_sel.V_pm_Curvature_LKA_SEL, -340282346638528897590636046441678635008);
        }
    } func_V_x_RCarHMIManagementInput_RCarHMIManagement_47;
    func_V_x_RCarHMIManagementInput_RCarHMIManagement_47.verify();

    extern UVehStatus_OutDataSet gOEM_SWC_C2_3UVehStatus_OutDataSet;
    EXPECT_FLOAT_EQ(gOEM_SWC_C1_1UVehStatus_OutDataSet.mConc.V_x_RCarHMIManagementInput.V_x_front_cam_lane_sel.V_pm2_Curvature_derivative_LKA_SEL, -340282346638528897590636046441678635008);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_OutDataSet.mConc.V_x_RCarHMIManagementInput.V_x_front_cam_lane_sel.V_pm2_Curvature_derivative_LKA_SEL, -340282346638528897590636046441678635008);
    struct _func_V_x_RCarHMIManagementInput_RCarHMIManagement_48 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementInput tmp_RCarHMIManagementInput;
            Rte_Read_V_x_RCarHMIManagementInput_V_x_RCarHMIManagementInput(&tmp_RCarHMIManagementInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementInput.V_x_front_cam_lane_sel.V_pm2_Curvature_derivative_LKA_SEL, -340282346638528897590636046441678635008);
        }
    } func_V_x_RCarHMIManagementInput_RCarHMIManagement_48;
    func_V_x_RCarHMIManagementInput_RCarHMIManagement_48.verify();

    extern UVehStatus_OutDataSet gOEM_SWC_C2_3UVehStatus_OutDataSet;
    EXPECT_FLOAT_EQ(gOEM_SWC_C1_1UVehStatus_OutDataSet.mConc.V_x_RCarHMIManagementInput.V_x_front_cam_lane_sel.V_m_Lane_Width, -340282346638528897590636046441678635008);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_OutDataSet.mConc.V_x_RCarHMIManagementInput.V_x_front_cam_lane_sel.V_m_Lane_Width, -340282346638528897590636046441678635008);
    struct _func_V_x_RCarHMIManagementInput_RCarHMIManagement_49 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementInput tmp_RCarHMIManagementInput;
            Rte_Read_V_x_RCarHMIManagementInput_V_x_RCarHMIManagementInput(&tmp_RCarHMIManagementInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementInput.V_x_front_cam_lane_sel.V_m_Lane_Width, -340282346638528897590636046441678635008);
        }
    } func_V_x_RCarHMIManagementInput_RCarHMIManagement_49;
    func_V_x_RCarHMIManagementInput_RCarHMIManagement_49.verify();

    extern UVehStatus_OutDataSet gOEM_SWC_C2_3UVehStatus_OutDataSet;
    EXPECT_FLOAT_EQ(gOEM_SWC_C1_1UVehStatus_OutDataSet.mConc.V_x_RCarHMIManagementInput.V_x_front_cam_lane_sel.V_pm_Curvature_LKA_SEL_hokan, -340282346638528897590636046441678635008);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_OutDataSet.mConc.V_x_RCarHMIManagementInput.V_x_front_cam_lane_sel.V_pm_Curvature_LKA_SEL_hokan, -340282346638528897590636046441678635008);
    struct _func_V_x_RCarHMIManagementInput_RCarHMIManagement_50 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementInput tmp_RCarHMIManagementInput;
            Rte_Read_V_x_RCarHMIManagementInput_V_x_RCarHMIManagementInput(&tmp_RCarHMIManagementInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementInput.V_x_front_cam_lane_sel.V_pm_Curvature_LKA_SEL_hokan, -340282346638528897590636046441678635008);
        }
    } func_V_x_RCarHMIManagementInput_RCarHMIManagement_50;
    func_V_x_RCarHMIManagementInput_RCarHMIManagement_50.verify();

    extern UVehStatus_OutDataSet gOEM_SWC_C2_3UVehStatus_OutDataSet;
    EXPECT_FLOAT_EQ(gOEM_SWC_C1_1UVehStatus_OutDataSet.mConc.V_x_RCarHMIManagementInput.V_x_front_cam_lane_sel.V_rad_Heading_LKA_SEL_hokan, -340282346638528897590636046441678635008);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_OutDataSet.mConc.V_x_RCarHMIManagementInput.V_x_front_cam_lane_sel.V_rad_Heading_LKA_SEL_hokan, -340282346638528897590636046441678635008);
    struct _func_V_x_RCarHMIManagementInput_RCarHMIManagement_51 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementInput tmp_RCarHMIManagementInput;
            Rte_Read_V_x_RCarHMIManagementInput_V_x_RCarHMIManagementInput(&tmp_RCarHMIManagementInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementInput.V_x_front_cam_lane_sel.V_rad_Heading_LKA_SEL_hokan, -340282346638528897590636046441678635008);
        }
    } func_V_x_RCarHMIManagementInput_RCarHMIManagement_51;
    func_V_x_RCarHMIManagementInput_RCarHMIManagement_51.verify();

    extern UVehStatus_OutDataSet gOEM_SWC_C2_3UVehStatus_OutDataSet;
    EXPECT_FLOAT_EQ(gOEM_SWC_C1_1UVehStatus_OutDataSet.mConc.V_x_RCarHMIManagementInput.V_x_front_cam_lane_sel.V_m_offset_from_1st_lane, -340282346638528897590636046441678635008);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_OutDataSet.mConc.V_x_RCarHMIManagementInput.V_x_front_cam_lane_sel.V_m_offset_from_1st_lane, -340282346638528897590636046441678635008);
    struct _func_V_x_RCarHMIManagementInput_RCarHMIManagement_52 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementInput tmp_RCarHMIManagementInput;
            Rte_Read_V_x_RCarHMIManagementInput_V_x_RCarHMIManagementInput(&tmp_RCarHMIManagementInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementInput.V_x_front_cam_lane_sel.V_m_offset_from_1st_lane, -340282346638528897590636046441678635008);
        }
    } func_V_x_RCarHMIManagementInput_RCarHMIManagement_52;
    func_V_x_RCarHMIManagementInput_RCarHMIManagement_52.verify();

    extern UVehStatus_OutDataSet gOEM_SWC_C2_3UVehStatus_OutDataSet;
    EXPECT_FLOAT_EQ(gOEM_SWC_C1_1UVehStatus_OutDataSet.mConc.V_x_RCarHMIManagementInput.V_x_front_cam_lane_sel.V_m_Position_SEL_LANE_Offset, -340282346638528897590636046441678635008);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_OutDataSet.mConc.V_x_RCarHMIManagementInput.V_x_front_cam_lane_sel.V_m_Position_SEL_LANE_Offset, -340282346638528897590636046441678635008);
    struct _func_V_x_RCarHMIManagementInput_RCarHMIManagement_53 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementInput tmp_RCarHMIManagementInput;
            Rte_Read_V_x_RCarHMIManagementInput_V_x_RCarHMIManagementInput(&tmp_RCarHMIManagementInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementInput.V_x_front_cam_lane_sel.V_m_Position_SEL_LANE_Offset, -340282346638528897590636046441678635008);
        }
    } func_V_x_RCarHMIManagementInput_RCarHMIManagement_53;
    func_V_x_RCarHMIManagementInput_RCarHMIManagement_53.verify();

    extern UVehStatus_OutDataSet gOEM_SWC_C2_3UVehStatus_OutDataSet;
    EXPECT_EQ(gOEM_SWC_C1_1UVehStatus_OutDataSet.mConc.V_x_RCarHMIManagementInput.V_x_front_cam_lane_sel.V_x_LINE_SEL_HOKAN, 0);
    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_OutDataSet.mConc.V_x_RCarHMIManagementInput.V_x_front_cam_lane_sel.V_x_LINE_SEL_HOKAN, 0);
    struct _func_V_x_RCarHMIManagementInput_RCarHMIManagement_54 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementInput tmp_RCarHMIManagementInput;
            Rte_Read_V_x_RCarHMIManagementInput_V_x_RCarHMIManagementInput(&tmp_RCarHMIManagementInput);
            EXPECT_EQ(tmp_RCarHMIManagementInput.V_x_front_cam_lane_sel.V_x_LINE_SEL_HOKAN, 0);
        }
    } func_V_x_RCarHMIManagementInput_RCarHMIManagement_54;
    func_V_x_RCarHMIManagementInput_RCarHMIManagement_54.verify();

    extern UVehStatus_OutDataSet gOEM_SWC_C2_3UVehStatus_OutDataSet;
    EXPECT_EQ(gOEM_SWC_C1_1UVehStatus_OutDataSet.mConc.V_x_RCarHMIManagementInput.V_x_front_cam_lane_sel.F_x_LineCross, 0);
    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_OutDataSet.mConc.V_x_RCarHMIManagementInput.V_x_front_cam_lane_sel.F_x_LineCross, 0);
    struct _func_V_x_RCarHMIManagementInput_RCarHMIManagement_55 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementInput tmp_RCarHMIManagementInput;
            Rte_Read_V_x_RCarHMIManagementInput_V_x_RCarHMIManagementInput(&tmp_RCarHMIManagementInput);
            EXPECT_EQ(tmp_RCarHMIManagementInput.V_x_front_cam_lane_sel.F_x_LineCross, 0);
        }
    } func_V_x_RCarHMIManagementInput_RCarHMIManagement_55;
    func_V_x_RCarHMIManagementInput_RCarHMIManagement_55.verify();

    /* V_x_SurroundFusionInput*/
    extern UVehStatus_OutDataSet gOEM_SWC_C2_1UVehStatus_OutDataSet;
    EXPECT_FLOAT_EQ(gOEM_SWC_C1_1UVehStatus_OutDataSet.mConc.V_x_SurroundFusionInput.V_x_vehicle_status.V_mps_VSP_LPF, -340282346638528897590636046441678635008);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_OutDataSet.mConc.V_x_SurroundFusionInput.V_x_vehicle_status.V_mps_VSP_LPF, -340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionInput_SurroundFusion_0 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionInput tmp_SurroundFusionInput;
            Rte_Read_V_x_SurroundFusionInput_V_x_SurroundFusionInput(&tmp_SurroundFusionInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionInput.V_x_vehicle_status.V_mps_VSP_LPF, -340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionInput_SurroundFusion_0;
    func_V_x_SurroundFusionInput_SurroundFusion_0.verify();

    extern UVehStatus_OutDataSet gOEM_SWC_C2_1UVehStatus_OutDataSet;
    EXPECT_FLOAT_EQ(gOEM_SWC_C1_1UVehStatus_OutDataSet.mConc.V_x_SurroundFusionInput.V_x_vehicle_status.V_mps_AVE_VSP, -340282346638528897590636046441678635008);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_OutDataSet.mConc.V_x_SurroundFusionInput.V_x_vehicle_status.V_mps_AVE_VSP, -340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionInput_SurroundFusion_1 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionInput tmp_SurroundFusionInput;
            Rte_Read_V_x_SurroundFusionInput_V_x_SurroundFusionInput(&tmp_SurroundFusionInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionInput.V_x_vehicle_status.V_mps_AVE_VSP, -340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionInput_SurroundFusion_1;
    func_V_x_SurroundFusionInput_SurroundFusion_1.verify();

    extern UVehStatus_OutDataSet gOEM_SWC_C2_1UVehStatus_OutDataSet;
    EXPECT_EQ(gOEM_SWC_C1_1UVehStatus_OutDataSet.mConc.V_x_SurroundFusionInput.V_x_vehicle_status.V_x_RangeIndication, 0);
    EXPECT_EQ(gOEM_SWC_C2_1UVehStatus_OutDataSet.mConc.V_x_SurroundFusionInput.V_x_vehicle_status.V_x_RangeIndication, 0);
    struct _func_V_x_SurroundFusionInput_SurroundFusion_2 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionInput tmp_SurroundFusionInput;
            Rte_Read_V_x_SurroundFusionInput_V_x_SurroundFusionInput(&tmp_SurroundFusionInput);
            EXPECT_EQ(tmp_SurroundFusionInput.V_x_vehicle_status.V_x_RangeIndication, 0);
        }
    } func_V_x_SurroundFusionInput_SurroundFusion_2;
    func_V_x_SurroundFusionInput_SurroundFusion_2.verify();

    extern UVehStatus_OutDataSet gOEM_SWC_C2_1UVehStatus_OutDataSet;
    EXPECT_EQ(gOEM_SWC_C1_1UVehStatus_OutDataSet.mConc.V_x_SurroundFusionInput.V_x_vehicle_status.F_x_CancelButton, 0);
    EXPECT_EQ(gOEM_SWC_C2_1UVehStatus_OutDataSet.mConc.V_x_SurroundFusionInput.V_x_vehicle_status.F_x_CancelButton, 0);
    struct _func_V_x_SurroundFusionInput_SurroundFusion_3 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionInput tmp_SurroundFusionInput;
            Rte_Read_V_x_SurroundFusionInput_V_x_SurroundFusionInput(&tmp_SurroundFusionInput);
            EXPECT_EQ(tmp_SurroundFusionInput.V_x_vehicle_status.F_x_CancelButton, 0);
        }
    } func_V_x_SurroundFusionInput_SurroundFusion_3;
    func_V_x_SurroundFusionInput_SurroundFusion_3.verify();

    extern UVehStatus_OutDataSet gOEM_SWC_C2_1UVehStatus_OutDataSet;
    EXPECT_EQ(gOEM_SWC_C1_1UVehStatus_OutDataSet.mConc.V_x_SurroundFusionInput.V_x_vehicle_status.F_x_MainSwOn4, 0);
    EXPECT_EQ(gOEM_SWC_C2_1UVehStatus_OutDataSet.mConc.V_x_SurroundFusionInput.V_x_vehicle_status.F_x_MainSwOn4, 0);
    struct _func_V_x_SurroundFusionInput_SurroundFusion_4 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionInput tmp_SurroundFusionInput;
            Rte_Read_V_x_SurroundFusionInput_V_x_SurroundFusionInput(&tmp_SurroundFusionInput);
            EXPECT_EQ(tmp_SurroundFusionInput.V_x_vehicle_status.F_x_MainSwOn4, 0);
        }
    } func_V_x_SurroundFusionInput_SurroundFusion_4;
    func_V_x_SurroundFusionInput_SurroundFusion_4.verify();

    extern UVehStatus_OutDataSet gOEM_SWC_C2_1UVehStatus_OutDataSet;
    EXPECT_FLOAT_EQ(gOEM_SWC_C1_1UVehStatus_OutDataSet.mConc.V_x_SurroundFusionInput.V_x_vehicle_status.V_deg_EPS_AngleSensor, -340282346638528897590636046441678635008);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_OutDataSet.mConc.V_x_SurroundFusionInput.V_x_vehicle_status.V_deg_EPS_AngleSensor, -340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionInput_SurroundFusion_5 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionInput tmp_SurroundFusionInput;
            Rte_Read_V_x_SurroundFusionInput_V_x_SurroundFusionInput(&tmp_SurroundFusionInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionInput.V_x_vehicle_status.V_deg_EPS_AngleSensor, -340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionInput_SurroundFusion_5;
    func_V_x_SurroundFusionInput_SurroundFusion_5.verify();

    extern UVehStatus_OutDataSet gOEM_SWC_C2_1UVehStatus_OutDataSet;
    EXPECT_FLOAT_EQ(gOEM_SWC_C1_1UVehStatus_OutDataSet.mConc.V_x_SurroundFusionInput.V_x_vehicle_status.V_deg_SteeringWheelAngleRaw, -340282346638528897590636046441678635008);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_OutDataSet.mConc.V_x_SurroundFusionInput.V_x_vehicle_status.V_deg_SteeringWheelAngleRaw, -340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionInput_SurroundFusion_6 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionInput tmp_SurroundFusionInput;
            Rte_Read_V_x_SurroundFusionInput_V_x_SurroundFusionInput(&tmp_SurroundFusionInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionInput.V_x_vehicle_status.V_deg_SteeringWheelAngleRaw, -340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionInput_SurroundFusion_6;
    func_V_x_SurroundFusionInput_SurroundFusion_6.verify();

    extern UVehStatus_OutDataSet gOEM_SWC_C2_1UVehStatus_OutDataSet;
    EXPECT_FLOAT_EQ(gOEM_SWC_C1_1UVehStatus_OutDataSet.mConc.V_x_SurroundFusionInput.V_x_vehicle_status.V_degps_YawRateRaw, -340282346638528897590636046441678635008);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_OutDataSet.mConc.V_x_SurroundFusionInput.V_x_vehicle_status.V_degps_YawRateRaw, -340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionInput_SurroundFusion_7 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionInput tmp_SurroundFusionInput;
            Rte_Read_V_x_SurroundFusionInput_V_x_SurroundFusionInput(&tmp_SurroundFusionInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionInput.V_x_vehicle_status.V_degps_YawRateRaw, -340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionInput_SurroundFusion_7;
    func_V_x_SurroundFusionInput_SurroundFusion_7.verify();

    extern UVehStatus_OutDataSet gOEM_SWC_C2_1UVehStatus_OutDataSet;
    EXPECT_EQ(gOEM_SWC_C1_1UVehStatus_OutDataSet.mConc.V_x_SurroundFusionInput.V_x_vehicle_status.V_x_TurnInd, 0);
    EXPECT_EQ(gOEM_SWC_C2_1UVehStatus_OutDataSet.mConc.V_x_SurroundFusionInput.V_x_vehicle_status.V_x_TurnInd, 0);
    struct _func_V_x_SurroundFusionInput_SurroundFusion_8 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionInput tmp_SurroundFusionInput;
            Rte_Read_V_x_SurroundFusionInput_V_x_SurroundFusionInput(&tmp_SurroundFusionInput);
            EXPECT_EQ(tmp_SurroundFusionInput.V_x_vehicle_status.V_x_TurnInd, 0);
        }
    } func_V_x_SurroundFusionInput_SurroundFusion_8;
    func_V_x_SurroundFusionInput_SurroundFusion_8.verify();

    extern UVehStatus_OutDataSet gOEM_SWC_C2_1UVehStatus_OutDataSet;
    EXPECT_FLOAT_EQ(gOEM_SWC_C1_1UVehStatus_OutDataSet.mConc.V_x_SurroundFusionInput.V_x_vehicle_status.V_kph_VDCVehicleSpeed, -340282346638528897590636046441678635008);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_OutDataSet.mConc.V_x_SurroundFusionInput.V_x_vehicle_status.V_kph_VDCVehicleSpeed, -340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionInput_SurroundFusion_9 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionInput tmp_SurroundFusionInput;
            Rte_Read_V_x_SurroundFusionInput_V_x_SurroundFusionInput(&tmp_SurroundFusionInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionInput.V_x_vehicle_status.V_kph_VDCVehicleSpeed, -340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionInput_SurroundFusion_9;
    func_V_x_SurroundFusionInput_SurroundFusion_9.verify();

    extern UVehStatus_OutDataSet gOEM_SWC_C2_1UVehStatus_OutDataSet;
    EXPECT_FLOAT_EQ(gOEM_SWC_C1_1UVehStatus_OutDataSet.mConc.V_x_SurroundFusionInput.V_x_vehicle_status.V_mps_VehSpeed_Est, -340282346638528897590636046441678635008);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_OutDataSet.mConc.V_x_SurroundFusionInput.V_x_vehicle_status.V_mps_VehSpeed_Est, -340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionInput_SurroundFusion_10 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionInput tmp_SurroundFusionInput;
            Rte_Read_V_x_SurroundFusionInput_V_x_SurroundFusionInput(&tmp_SurroundFusionInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionInput.V_x_vehicle_status.V_mps_VehSpeed_Est, -340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionInput_SurroundFusion_10;
    func_V_x_SurroundFusionInput_SurroundFusion_10.verify();

    extern UVehStatus_OutDataSet gOEM_SWC_C2_1UVehStatus_OutDataSet;
    EXPECT_EQ(gOEM_SWC_C1_1UVehStatus_OutDataSet.mConc.V_x_SurroundFusionInput.V_x_vehicle_status.V_x_TURN_IND_Filter, 0);
    EXPECT_EQ(gOEM_SWC_C2_1UVehStatus_OutDataSet.mConc.V_x_SurroundFusionInput.V_x_vehicle_status.V_x_TURN_IND_Filter, 0);
    struct _func_V_x_SurroundFusionInput_SurroundFusion_11 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionInput tmp_SurroundFusionInput;
            Rte_Read_V_x_SurroundFusionInput_V_x_SurroundFusionInput(&tmp_SurroundFusionInput);
            EXPECT_EQ(tmp_SurroundFusionInput.V_x_vehicle_status.V_x_TURN_IND_Filter, 0);
        }
    } func_V_x_SurroundFusionInput_SurroundFusion_11;
    func_V_x_SurroundFusionInput_SurroundFusion_11.verify();

    extern UVehStatus_OutDataSet gOEM_SWC_C2_1UVehStatus_OutDataSet;
    EXPECT_EQ(gOEM_SWC_C1_1UVehStatus_OutDataSet.mConc.V_x_SurroundFusionInput.V_x_vehicle_status.V_x_Turn_Signal_Com, 0);
    EXPECT_EQ(gOEM_SWC_C2_1UVehStatus_OutDataSet.mConc.V_x_SurroundFusionInput.V_x_vehicle_status.V_x_Turn_Signal_Com, 0);
    struct _func_V_x_SurroundFusionInput_SurroundFusion_12 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionInput tmp_SurroundFusionInput;
            Rte_Read_V_x_SurroundFusionInput_V_x_SurroundFusionInput(&tmp_SurroundFusionInput);
            EXPECT_EQ(tmp_SurroundFusionInput.V_x_vehicle_status.V_x_Turn_Signal_Com, 0);
        }
    } func_V_x_SurroundFusionInput_SurroundFusion_12;
    func_V_x_SurroundFusionInput_SurroundFusion_12.verify();

    extern UVehStatus_OutDataSet gOEM_SWC_C2_1UVehStatus_OutDataSet;
    EXPECT_FLOAT_EQ(gOEM_SWC_C1_1UVehStatus_OutDataSet.mConc.V_x_SurroundFusionInput.V_x_vehicle_status.V_m_ycr_l, -340282346638528897590636046441678635008);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_OutDataSet.mConc.V_x_SurroundFusionInput.V_x_vehicle_status.V_m_ycr_l, -340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionInput_SurroundFusion_13 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionInput tmp_SurroundFusionInput;
            Rte_Read_V_x_SurroundFusionInput_V_x_SurroundFusionInput(&tmp_SurroundFusionInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionInput.V_x_vehicle_status.V_m_ycr_l, -340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionInput_SurroundFusion_13;
    func_V_x_SurroundFusionInput_SurroundFusion_13.verify();

    extern UVehStatus_OutDataSet gOEM_SWC_C2_1UVehStatus_OutDataSet;
    EXPECT_FLOAT_EQ(gOEM_SWC_C1_1UVehStatus_OutDataSet.mConc.V_x_SurroundFusionInput.V_x_vehicle_status.V_rad_phi_l, -340282346638528897590636046441678635008);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_OutDataSet.mConc.V_x_SurroundFusionInput.V_x_vehicle_status.V_rad_phi_l, -340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionInput_SurroundFusion_14 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionInput tmp_SurroundFusionInput;
            Rte_Read_V_x_SurroundFusionInput_V_x_SurroundFusionInput(&tmp_SurroundFusionInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionInput.V_x_vehicle_status.V_rad_phi_l, -340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionInput_SurroundFusion_14;
    func_V_x_SurroundFusionInput_SurroundFusion_14.verify();

    extern UVehStatus_OutDataSet gOEM_SWC_C2_1UVehStatus_OutDataSet;
    EXPECT_FLOAT_EQ(gOEM_SWC_C1_1UVehStatus_OutDataSet.mConc.V_x_SurroundFusionInput.V_x_vehicle_status.V_pm_rho_l, -340282346638528897590636046441678635008);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_OutDataSet.mConc.V_x_SurroundFusionInput.V_x_vehicle_status.V_pm_rho_l, -340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionInput_SurroundFusion_15 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionInput tmp_SurroundFusionInput;
            Rte_Read_V_x_SurroundFusionInput_V_x_SurroundFusionInput(&tmp_SurroundFusionInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionInput.V_x_vehicle_status.V_pm_rho_l, -340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionInput_SurroundFusion_15;
    func_V_x_SurroundFusionInput_SurroundFusion_15.verify();

    extern UVehStatus_OutDataSet gOEM_SWC_C2_1UVehStatus_OutDataSet;
    EXPECT_FLOAT_EQ(gOEM_SWC_C1_1UVehStatus_OutDataSet.mConc.V_x_SurroundFusionInput.V_x_vehicle_status.V_degps_YawRateCorrected, -340282346638528897590636046441678635008);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_OutDataSet.mConc.V_x_SurroundFusionInput.V_x_vehicle_status.V_degps_YawRateCorrected, -340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionInput_SurroundFusion_16 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionInput tmp_SurroundFusionInput;
            Rte_Read_V_x_SurroundFusionInput_V_x_SurroundFusionInput(&tmp_SurroundFusionInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionInput.V_x_vehicle_status.V_degps_YawRateCorrected, -340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionInput_SurroundFusion_16;
    func_V_x_SurroundFusionInput_SurroundFusion_16.verify();

    extern UVehStatus_OutDataSet gOEM_SWC_C2_1UVehStatus_OutDataSet;
    EXPECT_EQ(gOEM_SWC_C1_1UVehStatus_OutDataSet.mConc.V_x_SurroundFusionInput.V_x_ctrl_flag.V_x_InternalACCStatus, 0);
    EXPECT_EQ(gOEM_SWC_C2_1UVehStatus_OutDataSet.mConc.V_x_SurroundFusionInput.V_x_ctrl_flag.V_x_InternalACCStatus, 0);
    struct _func_V_x_SurroundFusionInput_SurroundFusion_17 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionInput tmp_SurroundFusionInput;
            Rte_Read_V_x_SurroundFusionInput_V_x_SurroundFusionInput(&tmp_SurroundFusionInput);
            EXPECT_EQ(tmp_SurroundFusionInput.V_x_ctrl_flag.V_x_InternalACCStatus, 0);
        }
    } func_V_x_SurroundFusionInput_SurroundFusion_17;
    func_V_x_SurroundFusionInput_SurroundFusion_17.verify();

    extern UVehStatus_OutDataSet gOEM_SWC_C2_1UVehStatus_OutDataSet;
    EXPECT_EQ(gOEM_SWC_C1_1UVehStatus_OutDataSet.mConc.V_x_SurroundFusionInput.V_x_ctrl_flag.F_x_Lch_on, 0);
    EXPECT_EQ(gOEM_SWC_C2_1UVehStatus_OutDataSet.mConc.V_x_SurroundFusionInput.V_x_ctrl_flag.F_x_Lch_on, 0);
    struct _func_V_x_SurroundFusionInput_SurroundFusion_18 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionInput tmp_SurroundFusionInput;
            Rte_Read_V_x_SurroundFusionInput_V_x_SurroundFusionInput(&tmp_SurroundFusionInput);
            EXPECT_EQ(tmp_SurroundFusionInput.V_x_ctrl_flag.F_x_Lch_on, 0);
        }
    } func_V_x_SurroundFusionInput_SurroundFusion_18;
    func_V_x_SurroundFusionInput_SurroundFusion_18.verify();

    extern UVehStatus_OutDataSet gOEM_SWC_C2_1UVehStatus_OutDataSet;
    EXPECT_EQ(gOEM_SWC_C1_1UVehStatus_OutDataSet.mConc.V_x_SurroundFusionInput.V_x_ctrl_flag.V_x_Lch_dir_fix, -128);
    EXPECT_EQ(gOEM_SWC_C2_1UVehStatus_OutDataSet.mConc.V_x_SurroundFusionInput.V_x_ctrl_flag.V_x_Lch_dir_fix, -128);
    struct _func_V_x_SurroundFusionInput_SurroundFusion_19 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionInput tmp_SurroundFusionInput;
            Rte_Read_V_x_SurroundFusionInput_V_x_SurroundFusionInput(&tmp_SurroundFusionInput);
            EXPECT_EQ(tmp_SurroundFusionInput.V_x_ctrl_flag.V_x_Lch_dir_fix, -128);
        }
    } func_V_x_SurroundFusionInput_SurroundFusion_19;
    func_V_x_SurroundFusionInput_SurroundFusion_19.verify();

    extern UVehStatus_OutDataSet gOEM_SWC_C2_1UVehStatus_OutDataSet;
    EXPECT_EQ(gOEM_SWC_C1_1UVehStatus_OutDataSet.mConc.V_x_SurroundFusionInput.V_x_ctrl_flag.F_x_DriverSteer, 0);
    EXPECT_EQ(gOEM_SWC_C2_1UVehStatus_OutDataSet.mConc.V_x_SurroundFusionInput.V_x_ctrl_flag.F_x_DriverSteer, 0);
    struct _func_V_x_SurroundFusionInput_SurroundFusion_20 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionInput tmp_SurroundFusionInput;
            Rte_Read_V_x_SurroundFusionInput_V_x_SurroundFusionInput(&tmp_SurroundFusionInput);
            EXPECT_EQ(tmp_SurroundFusionInput.V_x_ctrl_flag.F_x_DriverSteer, 0);
        }
    } func_V_x_SurroundFusionInput_SurroundFusion_20;
    func_V_x_SurroundFusionInput_SurroundFusion_20.verify();

    extern UVehStatus_OutDataSet gOEM_SWC_C2_1UVehStatus_OutDataSet;
    EXPECT_EQ(gOEM_SWC_C1_1UVehStatus_OutDataSet.mConc.V_x_SurroundFusionInput.V_x_ctrl_flag.F_x_Lanechange_abort, 0);
    EXPECT_EQ(gOEM_SWC_C2_1UVehStatus_OutDataSet.mConc.V_x_SurroundFusionInput.V_x_ctrl_flag.F_x_Lanechange_abort, 0);
    struct _func_V_x_SurroundFusionInput_SurroundFusion_21 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionInput tmp_SurroundFusionInput;
            Rte_Read_V_x_SurroundFusionInput_V_x_SurroundFusionInput(&tmp_SurroundFusionInput);
            EXPECT_EQ(tmp_SurroundFusionInput.V_x_ctrl_flag.F_x_Lanechange_abort, 0);
        }
    } func_V_x_SurroundFusionInput_SurroundFusion_21;
    func_V_x_SurroundFusionInput_SurroundFusion_21.verify();

    extern UVehStatus_OutDataSet gOEM_SWC_C2_1UVehStatus_OutDataSet;
    EXPECT_EQ(gOEM_SWC_C1_1UVehStatus_OutDataSet.mConc.V_x_SurroundFusionInput.V_x_ctrl_flag.V_x_LatControlModeSel, 0);
    EXPECT_EQ(gOEM_SWC_C2_1UVehStatus_OutDataSet.mConc.V_x_SurroundFusionInput.V_x_ctrl_flag.V_x_LatControlModeSel, 0);
    struct _func_V_x_SurroundFusionInput_SurroundFusion_22 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionInput tmp_SurroundFusionInput;
            Rte_Read_V_x_SurroundFusionInput_V_x_SurroundFusionInput(&tmp_SurroundFusionInput);
            EXPECT_EQ(tmp_SurroundFusionInput.V_x_ctrl_flag.V_x_LatControlModeSel, 0);
        }
    } func_V_x_SurroundFusionInput_SurroundFusion_22;
    func_V_x_SurroundFusionInput_SurroundFusion_22.verify();

    extern UVehStatus_OutDataSet gOEM_SWC_C2_1UVehStatus_OutDataSet;
    EXPECT_EQ(gOEM_SWC_C1_1UVehStatus_OutDataSet.mConc.V_x_SurroundFusionInput.V_x_ctrl_flag.F_x_Lch_pass_announce_toRight, 0);
    EXPECT_EQ(gOEM_SWC_C2_1UVehStatus_OutDataSet.mConc.V_x_SurroundFusionInput.V_x_ctrl_flag.F_x_Lch_pass_announce_toRight, 0);
    struct _func_V_x_SurroundFusionInput_SurroundFusion_23 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionInput tmp_SurroundFusionInput;
            Rte_Read_V_x_SurroundFusionInput_V_x_SurroundFusionInput(&tmp_SurroundFusionInput);
            EXPECT_EQ(tmp_SurroundFusionInput.V_x_ctrl_flag.F_x_Lch_pass_announce_toRight, 0);
        }
    } func_V_x_SurroundFusionInput_SurroundFusion_23;
    func_V_x_SurroundFusionInput_SurroundFusion_23.verify();

    extern UVehStatus_OutDataSet gOEM_SWC_C2_1UVehStatus_OutDataSet;
    EXPECT_EQ(gOEM_SWC_C1_1UVehStatus_OutDataSet.mConc.V_x_SurroundFusionInput.V_x_ctrl_flag.F_x_Lch_return_announce_toLeft, 0);
    EXPECT_EQ(gOEM_SWC_C2_1UVehStatus_OutDataSet.mConc.V_x_SurroundFusionInput.V_x_ctrl_flag.F_x_Lch_return_announce_toLeft, 0);
    struct _func_V_x_SurroundFusionInput_SurroundFusion_24 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionInput tmp_SurroundFusionInput;
            Rte_Read_V_x_SurroundFusionInput_V_x_SurroundFusionInput(&tmp_SurroundFusionInput);
            EXPECT_EQ(tmp_SurroundFusionInput.V_x_ctrl_flag.F_x_Lch_return_announce_toLeft, 0);
        }
    } func_V_x_SurroundFusionInput_SurroundFusion_24;
    func_V_x_SurroundFusionInput_SurroundFusion_24.verify();

    extern UVehStatus_OutDataSet gOEM_SWC_C2_1UVehStatus_OutDataSet;
    EXPECT_EQ(gOEM_SWC_C1_1UVehStatus_OutDataSet.mConc.V_x_SurroundFusionInput.V_x_ctrl_flag.V_x_HandsOnJdg, 0);
    EXPECT_EQ(gOEM_SWC_C2_1UVehStatus_OutDataSet.mConc.V_x_SurroundFusionInput.V_x_ctrl_flag.V_x_HandsOnJdg, 0);
    struct _func_V_x_SurroundFusionInput_SurroundFusion_25 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionInput tmp_SurroundFusionInput;
            Rte_Read_V_x_SurroundFusionInput_V_x_SurroundFusionInput(&tmp_SurroundFusionInput);
            EXPECT_EQ(tmp_SurroundFusionInput.V_x_ctrl_flag.V_x_HandsOnJdg, 0);
        }
    } func_V_x_SurroundFusionInput_SurroundFusion_25;
    func_V_x_SurroundFusionInput_SurroundFusion_25.verify();

    extern UVehStatus_OutDataSet gOEM_SWC_C2_1UVehStatus_OutDataSet;
    EXPECT_EQ(gOEM_SWC_C1_1UVehStatus_OutDataSet.mConc.V_x_SurroundFusionInput.V_x_ctrl_flag.V_x_ADCtrlStat, 0);
    EXPECT_EQ(gOEM_SWC_C2_1UVehStatus_OutDataSet.mConc.V_x_SurroundFusionInput.V_x_ctrl_flag.V_x_ADCtrlStat, 0);
    struct _func_V_x_SurroundFusionInput_SurroundFusion_26 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionInput tmp_SurroundFusionInput;
            Rte_Read_V_x_SurroundFusionInput_V_x_SurroundFusionInput(&tmp_SurroundFusionInput);
            EXPECT_EQ(tmp_SurroundFusionInput.V_x_ctrl_flag.V_x_ADCtrlStat, 0);
        }
    } func_V_x_SurroundFusionInput_SurroundFusion_26;
    func_V_x_SurroundFusionInput_SurroundFusion_26.verify();

    extern UVehStatus_OutDataSet gOEM_SWC_C2_1UVehStatus_OutDataSet;
    EXPECT_EQ(gOEM_SWC_C1_1UVehStatus_OutDataSet.mConc.V_x_SurroundFusionInput.V_x_ctrl_flag.V_x_NumOfSystemAutoLC_Right, 0);
    EXPECT_EQ(gOEM_SWC_C2_1UVehStatus_OutDataSet.mConc.V_x_SurroundFusionInput.V_x_ctrl_flag.V_x_NumOfSystemAutoLC_Right, 0);
    struct _func_V_x_SurroundFusionInput_SurroundFusion_27 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionInput tmp_SurroundFusionInput;
            Rte_Read_V_x_SurroundFusionInput_V_x_SurroundFusionInput(&tmp_SurroundFusionInput);
            EXPECT_EQ(tmp_SurroundFusionInput.V_x_ctrl_flag.V_x_NumOfSystemAutoLC_Right, 0);
        }
    } func_V_x_SurroundFusionInput_SurroundFusion_27;
    func_V_x_SurroundFusionInput_SurroundFusion_27.verify();

    extern UVehStatus_OutDataSet gOEM_SWC_C2_1UVehStatus_OutDataSet;
    EXPECT_EQ(gOEM_SWC_C1_1UVehStatus_OutDataSet.mConc.V_x_SurroundFusionInput.V_x_ctrl_flag.V_x_LaneChangeType, 0);
    EXPECT_EQ(gOEM_SWC_C2_1UVehStatus_OutDataSet.mConc.V_x_SurroundFusionInput.V_x_ctrl_flag.V_x_LaneChangeType, 0);
    struct _func_V_x_SurroundFusionInput_SurroundFusion_28 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionInput tmp_SurroundFusionInput;
            Rte_Read_V_x_SurroundFusionInput_V_x_SurroundFusionInput(&tmp_SurroundFusionInput);
            EXPECT_EQ(tmp_SurroundFusionInput.V_x_ctrl_flag.V_x_LaneChangeType, 0);
        }
    } func_V_x_SurroundFusionInput_SurroundFusion_28;
    func_V_x_SurroundFusionInput_SurroundFusion_28.verify();

    extern UVehStatus_OutDataSet gOEM_SWC_C2_1UVehStatus_OutDataSet;
    EXPECT_EQ(gOEM_SWC_C1_1UVehStatus_OutDataSet.mConc.V_x_SurroundFusionInput.V_x_ctrl_flag.V_x_ALC_InternalState, 0);
    EXPECT_EQ(gOEM_SWC_C2_1UVehStatus_OutDataSet.mConc.V_x_SurroundFusionInput.V_x_ctrl_flag.V_x_ALC_InternalState, 0);
    struct _func_V_x_SurroundFusionInput_SurroundFusion_29 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionInput tmp_SurroundFusionInput;
            Rte_Read_V_x_SurroundFusionInput_V_x_SurroundFusionInput(&tmp_SurroundFusionInput);
            EXPECT_EQ(tmp_SurroundFusionInput.V_x_ctrl_flag.V_x_ALC_InternalState, 0);
        }
    } func_V_x_SurroundFusionInput_SurroundFusion_29;
    func_V_x_SurroundFusionInput_SurroundFusion_29.verify();

    extern UVehStatus_OutDataSet gOEM_SWC_C2_1UVehStatus_OutDataSet;
    EXPECT_EQ(gOEM_SWC_C1_1UVehStatus_OutDataSet.mConc.V_x_SurroundFusionInput.V_x_ctrl_flag.V_x_AutoLCDirection_HMI, 0);
    EXPECT_EQ(gOEM_SWC_C2_1UVehStatus_OutDataSet.mConc.V_x_SurroundFusionInput.V_x_ctrl_flag.V_x_AutoLCDirection_HMI, 0);
    struct _func_V_x_SurroundFusionInput_SurroundFusion_30 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionInput tmp_SurroundFusionInput;
            Rte_Read_V_x_SurroundFusionInput_V_x_SurroundFusionInput(&tmp_SurroundFusionInput);
            EXPECT_EQ(tmp_SurroundFusionInput.V_x_ctrl_flag.V_x_AutoLCDirection_HMI, 0);
        }
    } func_V_x_SurroundFusionInput_SurroundFusion_30;
    func_V_x_SurroundFusionInput_SurroundFusion_30.verify();

    extern UVehStatus_OutDataSet gOEM_SWC_C2_1UVehStatus_OutDataSet;
    EXPECT_EQ(gOEM_SWC_C1_1UVehStatus_OutDataSet.mConc.V_x_SurroundFusionInput.V_x_ctrl_flag.V_x_FS_ALCState, 0);
    EXPECT_EQ(gOEM_SWC_C2_1UVehStatus_OutDataSet.mConc.V_x_SurroundFusionInput.V_x_ctrl_flag.V_x_FS_ALCState, 0);
    struct _func_V_x_SurroundFusionInput_SurroundFusion_31 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionInput tmp_SurroundFusionInput;
            Rte_Read_V_x_SurroundFusionInput_V_x_SurroundFusionInput(&tmp_SurroundFusionInput);
            EXPECT_EQ(tmp_SurroundFusionInput.V_x_ctrl_flag.V_x_FS_ALCState, 0);
        }
    } func_V_x_SurroundFusionInput_SurroundFusion_31;
    func_V_x_SurroundFusionInput_SurroundFusion_31.verify();

    extern UVehStatus_OutDataSet gOEM_SWC_C2_1UVehStatus_OutDataSet;
    EXPECT_EQ(gOEM_SWC_C1_1UVehStatus_OutDataSet.mConc.V_x_SurroundFusionInput.V_x_ctrl_flag.F_x_InitLane, 0);
    EXPECT_EQ(gOEM_SWC_C2_1UVehStatus_OutDataSet.mConc.V_x_SurroundFusionInput.V_x_ctrl_flag.F_x_InitLane, 0);
    struct _func_V_x_SurroundFusionInput_SurroundFusion_32 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionInput tmp_SurroundFusionInput;
            Rte_Read_V_x_SurroundFusionInput_V_x_SurroundFusionInput(&tmp_SurroundFusionInput);
            EXPECT_EQ(tmp_SurroundFusionInput.V_x_ctrl_flag.F_x_InitLane, 0);
        }
    } func_V_x_SurroundFusionInput_SurroundFusion_32;
    func_V_x_SurroundFusionInput_SurroundFusion_32.verify();

    extern UVehStatus_OutDataSet gOEM_SWC_C2_1UVehStatus_OutDataSet;
    EXPECT_EQ(gOEM_SWC_C1_1UVehStatus_OutDataSet.mConc.V_x_SurroundFusionInput.V_x_ctrl_flag.F_x_IniSteer, 0);
    EXPECT_EQ(gOEM_SWC_C2_1UVehStatus_OutDataSet.mConc.V_x_SurroundFusionInput.V_x_ctrl_flag.F_x_IniSteer, 0);
    struct _func_V_x_SurroundFusionInput_SurroundFusion_33 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionInput tmp_SurroundFusionInput;
            Rte_Read_V_x_SurroundFusionInput_V_x_SurroundFusionInput(&tmp_SurroundFusionInput);
            EXPECT_EQ(tmp_SurroundFusionInput.V_x_ctrl_flag.F_x_IniSteer, 0);
        }
    } func_V_x_SurroundFusionInput_SurroundFusion_33;
    func_V_x_SurroundFusionInput_SurroundFusion_33.verify();

    extern UVehStatus_OutDataSet gOEM_SWC_C2_1UVehStatus_OutDataSet;
    EXPECT_EQ(gOEM_SWC_C1_1UVehStatus_OutDataSet.mConc.V_x_SurroundFusionInput.V_x_ctrl_flag.F_x_SteerCntrl2, 0);
    EXPECT_EQ(gOEM_SWC_C2_1UVehStatus_OutDataSet.mConc.V_x_SurroundFusionInput.V_x_ctrl_flag.F_x_SteerCntrl2, 0);
    struct _func_V_x_SurroundFusionInput_SurroundFusion_34 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionInput tmp_SurroundFusionInput;
            Rte_Read_V_x_SurroundFusionInput_V_x_SurroundFusionInput(&tmp_SurroundFusionInput);
            EXPECT_EQ(tmp_SurroundFusionInput.V_x_ctrl_flag.F_x_SteerCntrl2, 0);
        }
    } func_V_x_SurroundFusionInput_SurroundFusion_34;
    func_V_x_SurroundFusionInput_SurroundFusion_34.verify();

    extern UVehStatus_OutDataSet gOEM_SWC_C2_1UVehStatus_OutDataSet;
    EXPECT_EQ(gOEM_SWC_C1_1UVehStatus_OutDataSet.mConc.V_x_SurroundFusionInput.V_x_ctrl_flag.F_x_TurnIndLeftValid, 0);
    EXPECT_EQ(gOEM_SWC_C2_1UVehStatus_OutDataSet.mConc.V_x_SurroundFusionInput.V_x_ctrl_flag.F_x_TurnIndLeftValid, 0);
    struct _func_V_x_SurroundFusionInput_SurroundFusion_35 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionInput tmp_SurroundFusionInput;
            Rte_Read_V_x_SurroundFusionInput_V_x_SurroundFusionInput(&tmp_SurroundFusionInput);
            EXPECT_EQ(tmp_SurroundFusionInput.V_x_ctrl_flag.F_x_TurnIndLeftValid, 0);
        }
    } func_V_x_SurroundFusionInput_SurroundFusion_35;
    func_V_x_SurroundFusionInput_SurroundFusion_35.verify();

    extern UVehStatus_OutDataSet gOEM_SWC_C2_1UVehStatus_OutDataSet;
    EXPECT_EQ(gOEM_SWC_C1_1UVehStatus_OutDataSet.mConc.V_x_SurroundFusionInput.V_x_ctrl_flag.F_x_TurnIndRightValid, 0);
    EXPECT_EQ(gOEM_SWC_C2_1UVehStatus_OutDataSet.mConc.V_x_SurroundFusionInput.V_x_ctrl_flag.F_x_TurnIndRightValid, 0);
    struct _func_V_x_SurroundFusionInput_SurroundFusion_36 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionInput tmp_SurroundFusionInput;
            Rte_Read_V_x_SurroundFusionInput_V_x_SurroundFusionInput(&tmp_SurroundFusionInput);
            EXPECT_EQ(tmp_SurroundFusionInput.V_x_ctrl_flag.F_x_TurnIndRightValid, 0);
        }
    } func_V_x_SurroundFusionInput_SurroundFusion_36;
    func_V_x_SurroundFusionInput_SurroundFusion_36.verify();

    extern UVehStatus_OutDataSet gOEM_SWC_C2_1UVehStatus_OutDataSet;
    EXPECT_EQ(gOEM_SWC_C1_1UVehStatus_OutDataSet.mConc.V_x_SurroundFusionInput.V_x_ctrl_flag.V_x_Lch_dir_pre, -128);
    EXPECT_EQ(gOEM_SWC_C2_1UVehStatus_OutDataSet.mConc.V_x_SurroundFusionInput.V_x_ctrl_flag.V_x_Lch_dir_pre, -128);
    struct _func_V_x_SurroundFusionInput_SurroundFusion_37 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionInput tmp_SurroundFusionInput;
            Rte_Read_V_x_SurroundFusionInput_V_x_SurroundFusionInput(&tmp_SurroundFusionInput);
            EXPECT_EQ(tmp_SurroundFusionInput.V_x_ctrl_flag.V_x_Lch_dir_pre, -128);
        }
    } func_V_x_SurroundFusionInput_SurroundFusion_37;
    func_V_x_SurroundFusionInput_SurroundFusion_37.verify();

}

void C1_1_o2o_noncache_min_verify_BRK_ENG(void)
{
    boolean tmp_B;
    sint32 tmp_S32;
    float32 tmp_Fl32;
    sint16 tmp_S16;
    uint8 tmp_U8;

}

void C1_1_o2o_noncache_min_verify_YAW(void)
{
    boolean tmp_B;
    sint16 tmp_S16;
    sint32 tmp_S32;
    float32 tmp_Fl32;

}

void C1_1_o2o_noncache_min_verify_HMI(void)
{
    boolean tmp_B;
    uint8 tmp_U8;
    float32 tmp_Fl32;

}

void C1_1_o2o_noncache_min_verify_CAM_RAD(void)
{
    boolean tmp_B;
    uint16 tmp_U16;
    sint8 tmp_S8;
    sint16 tmp_S16;
    float32 tmp_Fl32;
    sint32 tmp_S32;
    uint8 tmp_U8;
    uint32 tmp_U32;
    V_x_VectorLaneCameraObjects tmp_VectorLaneCameraObjects;

    /* F_x_fCamPedBrake*/
    extern UCAM_RADDataSet gOEM_SWC_C0_SMUCAM_RADDataSet;
    EXPECT_EQ(gOEM_SWC_C1_1UCAM_RADDataSet.mConc.F_x_fCamPedBrake, 0);
    EXPECT_EQ(gOEM_SWC_C0_SMUCAM_RADDataSet.mConc.F_x_fCamPedBrake, 0);
    struct _func_F_x_fCamPedBrake_SafetyModule {
        static void verify(void) {
#include "Rte_Wrapper_SafetyModule.h"
            boolean tmp_B;
            Rte_Read_F_x_fCamPedBrake_F_x_fCamPedBrake(&tmp_B);
            EXPECT_EQ(tmp_B, 0);
        }
    } func_F_x_fCamPedBrake_SafetyModule;
    func_F_x_fCamPedBrake_SafetyModule.verify();

    /* F_x_fCamPedCrossBrake*/
    extern UCAM_RADDataSet gOEM_SWC_C0_SMUCAM_RADDataSet;
    EXPECT_EQ(gOEM_SWC_C1_1UCAM_RADDataSet.mConc.F_x_fCamPedCrossBrake, 0);
    EXPECT_EQ(gOEM_SWC_C0_SMUCAM_RADDataSet.mConc.F_x_fCamPedCrossBrake, 0);
    struct _func_F_x_fCamPedCrossBrake_SafetyModule {
        static void verify(void) {
#include "Rte_Wrapper_SafetyModule.h"
            boolean tmp_B;
            Rte_Read_F_x_fCamPedCrossBrake_F_x_fCamPedCrossBrake(&tmp_B);
            EXPECT_EQ(tmp_B, 0);
        }
    } func_F_x_fCamPedCrossBrake_SafetyModule;
    func_F_x_fCamPedCrossBrake_SafetyModule.verify();

    /* F_x_fCamPedPreBrake*/
    extern UCAM_RADDataSet gOEM_SWC_C0_SMUCAM_RADDataSet;
    EXPECT_EQ(gOEM_SWC_C1_1UCAM_RADDataSet.mConc.F_x_fCamPedPreBrake, 0);
    EXPECT_EQ(gOEM_SWC_C0_SMUCAM_RADDataSet.mConc.F_x_fCamPedPreBrake, 0);
    struct _func_F_x_fCamPedPreBrake_SafetyModule {
        static void verify(void) {
#include "Rte_Wrapper_SafetyModule.h"
            boolean tmp_B;
            Rte_Read_F_x_fCamPedPreBrake_F_x_fCamPedPreBrake(&tmp_B);
            EXPECT_EQ(tmp_B, 0);
        }
    } func_F_x_fCamPedPreBrake_SafetyModule;
    func_F_x_fCamPedPreBrake_SafetyModule.verify();

    /* F_x_fCamPedPreFill*/
    extern UCAM_RADDataSet gOEM_SWC_C0_SMUCAM_RADDataSet;
    EXPECT_EQ(gOEM_SWC_C1_1UCAM_RADDataSet.mConc.F_x_fCamPedPreFill, 0);
    EXPECT_EQ(gOEM_SWC_C0_SMUCAM_RADDataSet.mConc.F_x_fCamPedPreFill, 0);
    struct _func_F_x_fCamPedPreFill_SafetyModule {
        static void verify(void) {
#include "Rte_Wrapper_SafetyModule.h"
            boolean tmp_B;
            Rte_Read_F_x_fCamPedPreFill_F_x_fCamPedPreFill(&tmp_B);
            EXPECT_EQ(tmp_B, 0);
        }
    } func_F_x_fCamPedPreFill_SafetyModule;
    func_F_x_fCamPedPreFill_SafetyModule.verify();

    /* F_x_fRIR_Input_AEBLateValid*/
    extern UCAM_RADDataSet gOEM_SWC_C0_SMUCAM_RADDataSet;
    EXPECT_EQ(gOEM_SWC_C1_1UCAM_RADDataSet.mConc.F_x_fRIR_Input_AEBLateValid, 0);
    EXPECT_EQ(gOEM_SWC_C0_SMUCAM_RADDataSet.mConc.F_x_fRIR_Input_AEBLateValid, 0);
    struct _func_F_x_fRIR_Input_AEBLateValid_SafetyModule {
        static void verify(void) {
#include "Rte_Wrapper_SafetyModule.h"
            boolean tmp_B;
            Rte_Read_F_x_fRIR_Input_AEBLateValid_F_x_fRIR_Input_AEBLateValid(&tmp_B);
            EXPECT_EQ(tmp_B, 0);
        }
    } func_F_x_fRIR_Input_AEBLateValid_SafetyModule;
    func_F_x_fRIR_Input_AEBLateValid_SafetyModule.verify();

    /* F_x_f_ConfPedMatch_CPNC*/
    extern UCAM_RADDataSet gOEM_SWC_C0_SMUCAM_RADDataSet;
    EXPECT_EQ(gOEM_SWC_C1_1UCAM_RADDataSet.mConc.F_x_f_ConfPedMatch_CPNC, 0);
    EXPECT_EQ(gOEM_SWC_C0_SMUCAM_RADDataSet.mConc.F_x_f_ConfPedMatch_CPNC, 0);
    struct _func_F_x_f_ConfPedMatch_CPNC_SafetyModule {
        static void verify(void) {
#include "Rte_Wrapper_SafetyModule.h"
            boolean tmp_B;
            Rte_Read_F_x_f_ConfPedMatch_CPNC_F_x_f_ConfPedMatch_CPNC(&tmp_B);
            EXPECT_EQ(tmp_B, 0);
        }
    } func_F_x_f_ConfPedMatch_CPNC_SafetyModule;
    func_F_x_f_ConfPedMatch_CPNC_SafetyModule.verify();

    /* V_deg_CamPed_Ac*/
    extern UCAM_RADDataSet gOEM_SWC_C0_SMUCAM_RADDataSet;
    EXPECT_FLOAT_EQ(gOEM_SWC_C1_1UCAM_RADDataSet.mConc.V_deg_CamPed_Ac, -340282346638528897590636046441678635008);
    EXPECT_FLOAT_EQ(gOEM_SWC_C0_SMUCAM_RADDataSet.mConc.V_deg_CamPed_Ac, -340282346638528897590636046441678635008);
    struct _func_V_deg_CamPed_Ac_SafetyModule {
        static void verify(void) {
#include "Rte_Wrapper_SafetyModule.h"
            float32 tmp_Fl32;
            Rte_Read_V_deg_CamPed_Ac_V_deg_CamPed_Ac(&tmp_Fl32);
            EXPECT_FLOAT_EQ(tmp_Fl32, -340282346638528897590636046441678635008);
        }
    } func_V_deg_CamPed_Ac_SafetyModule;
    func_V_deg_CamPed_Ac_SafetyModule.verify();

    /* V_deg_RadPed_Ar*/
    extern UCAM_RADDataSet gOEM_SWC_C0_SMUCAM_RADDataSet;
    EXPECT_FLOAT_EQ(gOEM_SWC_C1_1UCAM_RADDataSet.mConc.V_deg_RadPed_Ar, -340282346638528897590636046441678635008);
    EXPECT_FLOAT_EQ(gOEM_SWC_C0_SMUCAM_RADDataSet.mConc.V_deg_RadPed_Ar, -340282346638528897590636046441678635008);
    struct _func_V_deg_RadPed_Ar_SafetyModule {
        static void verify(void) {
#include "Rte_Wrapper_SafetyModule.h"
            float32 tmp_Fl32;
            Rte_Read_V_deg_RadPed_Ar_V_deg_RadPed_Ar(&tmp_Fl32);
            EXPECT_FLOAT_EQ(tmp_Fl32, -340282346638528897590636046441678635008);
        }
    } func_V_deg_RadPed_Ar_SafetyModule;
    func_V_deg_RadPed_Ar_SafetyModule.verify();

    /* V_m_CamCipv_LatDist*/
    extern UCAM_RADDataSet gOEM_SWC_C0_SMUCAM_RADDataSet;
    EXPECT_FLOAT_EQ(gOEM_SWC_C1_1UCAM_RADDataSet.mConc.V_m_CamCipv_LatDist, -340282346638528897590636046441678635008);
    EXPECT_FLOAT_EQ(gOEM_SWC_C0_SMUCAM_RADDataSet.mConc.V_m_CamCipv_LatDist, -340282346638528897590636046441678635008);
    struct _func_V_m_CamCipv_LatDist_SafetyModule {
        static void verify(void) {
#include "Rte_Wrapper_SafetyModule.h"
            float32 tmp_Fl32;
            Rte_Read_V_m_CamCipv_LatDist_V_m_CamCipv_LatDist(&tmp_Fl32);
            EXPECT_FLOAT_EQ(tmp_Fl32, -340282346638528897590636046441678635008);
        }
    } func_V_m_CamCipv_LatDist_SafetyModule;
    func_V_m_CamCipv_LatDist_SafetyModule.verify();

    /* V_m_CamCipv_LongiDist*/
    extern UCAM_RADDataSet gOEM_SWC_C0_SMUCAM_RADDataSet;
    EXPECT_FLOAT_EQ(gOEM_SWC_C1_1UCAM_RADDataSet.mConc.V_m_CamCipv_LongiDist, -340282346638528897590636046441678635008);
    EXPECT_FLOAT_EQ(gOEM_SWC_C0_SMUCAM_RADDataSet.mConc.V_m_CamCipv_LongiDist, -340282346638528897590636046441678635008);
    struct _func_V_m_CamCipv_LongiDist_SafetyModule {
        static void verify(void) {
#include "Rte_Wrapper_SafetyModule.h"
            float32 tmp_Fl32;
            Rte_Read_V_m_CamCipv_LongiDist_V_m_CamCipv_LongiDist(&tmp_Fl32);
            EXPECT_FLOAT_EQ(tmp_Fl32, -340282346638528897590636046441678635008);
        }
    } func_V_m_CamCipv_LongiDist_SafetyModule;
    func_V_m_CamCipv_LongiDist_SafetyModule.verify();

    /* V_m_CamPed_FDT_Dt*/
    extern UCAM_RADDataSet gOEM_SWC_C0_SMUCAM_RADDataSet;
    EXPECT_FLOAT_EQ(gOEM_SWC_C1_1UCAM_RADDataSet.mConc.V_m_CamPed_FDT_Dt, -340282346638528897590636046441678635008);
    EXPECT_FLOAT_EQ(gOEM_SWC_C0_SMUCAM_RADDataSet.mConc.V_m_CamPed_FDT_Dt, -340282346638528897590636046441678635008);
    struct _func_V_m_CamPed_FDT_Dt_SafetyModule {
        static void verify(void) {
#include "Rte_Wrapper_SafetyModule.h"
            float32 tmp_Fl32;
            Rte_Read_V_m_CamPed_FDT_Dt_V_m_CamPed_FDT_Dt(&tmp_Fl32);
            EXPECT_FLOAT_EQ(tmp_Fl32, -340282346638528897590636046441678635008);
        }
    } func_V_m_CamPed_FDT_Dt_SafetyModule;
    func_V_m_CamPed_FDT_Dt_SafetyModule.verify();

    /* V_m_CamPed_LatDist*/
    extern UCAM_RADDataSet gOEM_SWC_C0_SMUCAM_RADDataSet;
    EXPECT_FLOAT_EQ(gOEM_SWC_C1_1UCAM_RADDataSet.mConc.V_m_CamPed_LatDist, -340282346638528897590636046441678635008);
    EXPECT_FLOAT_EQ(gOEM_SWC_C0_SMUCAM_RADDataSet.mConc.V_m_CamPed_LatDist, -340282346638528897590636046441678635008);
    struct _func_V_m_CamPed_LatDist_SafetyModule {
        static void verify(void) {
#include "Rte_Wrapper_SafetyModule.h"
            float32 tmp_Fl32;
            Rte_Read_V_m_CamPed_LatDist_V_m_CamPed_LatDist(&tmp_Fl32);
            EXPECT_FLOAT_EQ(tmp_Fl32, -340282346638528897590636046441678635008);
        }
    } func_V_m_CamPed_LatDist_SafetyModule;
    func_V_m_CamPed_LatDist_SafetyModule.verify();

    /* V_m_CamPed_LongiDist*/
    extern UCAM_RADDataSet gOEM_SWC_C0_SMUCAM_RADDataSet;
    EXPECT_FLOAT_EQ(gOEM_SWC_C1_1UCAM_RADDataSet.mConc.V_m_CamPed_LongiDist, -340282346638528897590636046441678635008);
    EXPECT_FLOAT_EQ(gOEM_SWC_C0_SMUCAM_RADDataSet.mConc.V_m_CamPed_LongiDist, -340282346638528897590636046441678635008);
    struct _func_V_m_CamPed_LongiDist_SafetyModule {
        static void verify(void) {
#include "Rte_Wrapper_SafetyModule.h"
            float32 tmp_Fl32;
            Rte_Read_V_m_CamPed_LongiDist_V_m_CamPed_LongiDist(&tmp_Fl32);
            EXPECT_FLOAT_EQ(tmp_Fl32, -340282346638528897590636046441678635008);
        }
    } func_V_m_CamPed_LongiDist_SafetyModule;
    func_V_m_CamPed_LongiDist_SafetyModule.verify();

    /* V_m_RadFcwa_LatDist*/
    extern UCAM_RADDataSet gOEM_SWC_C0_SMUCAM_RADDataSet;
    EXPECT_FLOAT_EQ(gOEM_SWC_C1_1UCAM_RADDataSet.mConc.V_m_RadFcwa_LatDist, -340282346638528897590636046441678635008);
    EXPECT_FLOAT_EQ(gOEM_SWC_C0_SMUCAM_RADDataSet.mConc.V_m_RadFcwa_LatDist, -340282346638528897590636046441678635008);
    struct _func_V_m_RadFcwa_LatDist_SafetyModule {
        static void verify(void) {
#include "Rte_Wrapper_SafetyModule.h"
            float32 tmp_Fl32;
            Rte_Read_V_m_RadFcwa_LatDist_V_m_RadFcwa_LatDist(&tmp_Fl32);
            EXPECT_FLOAT_EQ(tmp_Fl32, -340282346638528897590636046441678635008);
        }
    } func_V_m_RadFcwa_LatDist_SafetyModule;
    func_V_m_RadFcwa_LatDist_SafetyModule.verify();

    /* V_m_RadFcwa_LongiDist*/
    extern UCAM_RADDataSet gOEM_SWC_C0_SMUCAM_RADDataSet;
    EXPECT_FLOAT_EQ(gOEM_SWC_C1_1UCAM_RADDataSet.mConc.V_m_RadFcwa_LongiDist, -340282346638528897590636046441678635008);
    EXPECT_FLOAT_EQ(gOEM_SWC_C0_SMUCAM_RADDataSet.mConc.V_m_RadFcwa_LongiDist, -340282346638528897590636046441678635008);
    struct _func_V_m_RadFcwa_LongiDist_SafetyModule {
        static void verify(void) {
#include "Rte_Wrapper_SafetyModule.h"
            float32 tmp_Fl32;
            Rte_Read_V_m_RadFcwa_LongiDist_V_m_RadFcwa_LongiDist(&tmp_Fl32);
            EXPECT_FLOAT_EQ(tmp_Fl32, -340282346638528897590636046441678635008);
        }
    } func_V_m_RadFcwa_LongiDist_SafetyModule;
    func_V_m_RadFcwa_LongiDist_SafetyModule.verify();

    /* V_m_RadPed_LatDist*/
    extern UCAM_RADDataSet gOEM_SWC_C0_SMUCAM_RADDataSet;
    EXPECT_FLOAT_EQ(gOEM_SWC_C1_1UCAM_RADDataSet.mConc.V_m_RadPed_LatDist, -340282346638528897590636046441678635008);
    EXPECT_FLOAT_EQ(gOEM_SWC_C0_SMUCAM_RADDataSet.mConc.V_m_RadPed_LatDist, -340282346638528897590636046441678635008);
    struct _func_V_m_RadPed_LatDist_SafetyModule {
        static void verify(void) {
#include "Rte_Wrapper_SafetyModule.h"
            float32 tmp_Fl32;
            Rte_Read_V_m_RadPed_LatDist_V_m_RadPed_LatDist(&tmp_Fl32);
            EXPECT_FLOAT_EQ(tmp_Fl32, -340282346638528897590636046441678635008);
        }
    } func_V_m_RadPed_LatDist_SafetyModule;
    func_V_m_RadPed_LatDist_SafetyModule.verify();

    /* V_m_RadPed_LongiDist*/
    extern UCAM_RADDataSet gOEM_SWC_C0_SMUCAM_RADDataSet;
    EXPECT_FLOAT_EQ(gOEM_SWC_C1_1UCAM_RADDataSet.mConc.V_m_RadPed_LongiDist, -340282346638528897590636046441678635008);
    EXPECT_FLOAT_EQ(gOEM_SWC_C0_SMUCAM_RADDataSet.mConc.V_m_RadPed_LongiDist, -340282346638528897590636046441678635008);
    struct _func_V_m_RadPed_LongiDist_SafetyModule {
        static void verify(void) {
#include "Rte_Wrapper_SafetyModule.h"
            float32 tmp_Fl32;
            Rte_Read_V_m_RadPed_LongiDist_V_m_RadPed_LongiDist(&tmp_Fl32);
            EXPECT_FLOAT_EQ(tmp_Fl32, -340282346638528897590636046441678635008);
        }
    } func_V_m_RadPed_LongiDist_SafetyModule;
    func_V_m_RadPed_LongiDist_SafetyModule.verify();

    /* V_mps_CamCipv_RelSpd*/
    extern UCAM_RADDataSet gOEM_SWC_C0_SMUCAM_RADDataSet;
    EXPECT_FLOAT_EQ(gOEM_SWC_C1_1UCAM_RADDataSet.mConc.V_mps_CamCipv_RelSpd, -340282346638528897590636046441678635008);
    EXPECT_FLOAT_EQ(gOEM_SWC_C0_SMUCAM_RADDataSet.mConc.V_mps_CamCipv_RelSpd, -340282346638528897590636046441678635008);
    struct _func_V_mps_CamCipv_RelSpd_SafetyModule {
        static void verify(void) {
#include "Rte_Wrapper_SafetyModule.h"
            float32 tmp_Fl32;
            Rte_Read_V_mps_CamCipv_RelSpd_V_mps_CamCipv_RelSpd(&tmp_Fl32);
            EXPECT_FLOAT_EQ(tmp_Fl32, -340282346638528897590636046441678635008);
        }
    } func_V_mps_CamCipv_RelSpd_SafetyModule;
    func_V_mps_CamCipv_RelSpd_SafetyModule.verify();

    /* V_mps_RadFcwa_RelSpd*/
    extern UCAM_RADDataSet gOEM_SWC_C0_SMUCAM_RADDataSet;
    EXPECT_FLOAT_EQ(gOEM_SWC_C1_1UCAM_RADDataSet.mConc.V_mps_RadFcwa_RelSpd, -340282346638528897590636046441678635008);
    EXPECT_FLOAT_EQ(gOEM_SWC_C0_SMUCAM_RADDataSet.mConc.V_mps_RadFcwa_RelSpd, -340282346638528897590636046441678635008);
    struct _func_V_mps_RadFcwa_RelSpd_SafetyModule {
        static void verify(void) {
#include "Rte_Wrapper_SafetyModule.h"
            float32 tmp_Fl32;
            Rte_Read_V_mps_RadFcwa_RelSpd_V_mps_RadFcwa_RelSpd(&tmp_Fl32);
            EXPECT_FLOAT_EQ(tmp_Fl32, -340282346638528897590636046441678635008);
        }
    } func_V_mps_RadFcwa_RelSpd_SafetyModule;
    func_V_mps_RadFcwa_RelSpd_SafetyModule.verify();

    /* V_mps_RadPed_RelSpd*/
    extern UCAM_RADDataSet gOEM_SWC_C0_SMUCAM_RADDataSet;
    EXPECT_FLOAT_EQ(gOEM_SWC_C1_1UCAM_RADDataSet.mConc.V_mps_RadPed_RelSpd, -340282346638528897590636046441678635008);
    EXPECT_FLOAT_EQ(gOEM_SWC_C0_SMUCAM_RADDataSet.mConc.V_mps_RadPed_RelSpd, -340282346638528897590636046441678635008);
    struct _func_V_mps_RadPed_RelSpd_SafetyModule {
        static void verify(void) {
#include "Rte_Wrapper_SafetyModule.h"
            float32 tmp_Fl32;
            Rte_Read_V_mps_RadPed_RelSpd_V_mps_RadPed_RelSpd(&tmp_Fl32);
            EXPECT_FLOAT_EQ(tmp_Fl32, -340282346638528897590636046441678635008);
        }
    } func_V_mps_RadPed_RelSpd_SafetyModule;
    func_V_mps_RadPed_RelSpd_SafetyModule.verify();

    /* V_s_CamCipv_TTC*/
    extern UCAM_RADDataSet gOEM_SWC_C0_SMUCAM_RADDataSet;
    EXPECT_FLOAT_EQ(gOEM_SWC_C1_1UCAM_RADDataSet.mConc.V_s_CamCipv_TTC, -340282346638528897590636046441678635008);
    EXPECT_FLOAT_EQ(gOEM_SWC_C0_SMUCAM_RADDataSet.mConc.V_s_CamCipv_TTC, -340282346638528897590636046441678635008);
    struct _func_V_s_CamCipv_TTC_SafetyModule {
        static void verify(void) {
#include "Rte_Wrapper_SafetyModule.h"
            float32 tmp_Fl32;
            Rte_Read_V_s_CamCipv_TTC_V_s_CamCipv_TTC(&tmp_Fl32);
            EXPECT_FLOAT_EQ(tmp_Fl32, -340282346638528897590636046441678635008);
        }
    } func_V_s_CamCipv_TTC_SafetyModule;
    func_V_s_CamCipv_TTC_SafetyModule.verify();

    /* V_x_CamCipv_ID_CIPV*/
    extern UCAM_RADDataSet gOEM_SWC_C0_SMUCAM_RADDataSet;
    EXPECT_EQ(gOEM_SWC_C1_1UCAM_RADDataSet.mConc.V_x_CamCipv_ID_CIPV, 0);
    EXPECT_EQ(gOEM_SWC_C0_SMUCAM_RADDataSet.mConc.V_x_CamCipv_ID_CIPV, 0);
    struct _func_V_x_CamCipv_ID_CIPV_SafetyModule {
        static void verify(void) {
#include "Rte_Wrapper_SafetyModule.h"
            uint32 tmp_U32;
            Rte_Read_V_x_CamCipv_ID_CIPV_V_x_CamCipv_ID_CIPV(&tmp_U32);
            EXPECT_EQ(tmp_U32, 0);
        }
    } func_V_x_CamCipv_ID_CIPV_SafetyModule;
    func_V_x_CamCipv_ID_CIPV_SafetyModule.verify();

    /* V_x_CamCipv_ObjID*/
    extern UCAM_RADDataSet gOEM_SWC_C0_SMUCAM_RADDataSet;
    EXPECT_EQ(gOEM_SWC_C1_1UCAM_RADDataSet.mConc.V_x_CamCipv_ObjID, 0);
    EXPECT_EQ(gOEM_SWC_C0_SMUCAM_RADDataSet.mConc.V_x_CamCipv_ObjID, 0);
    struct _func_V_x_CamCipv_ObjID_SafetyModule {
        static void verify(void) {
#include "Rte_Wrapper_SafetyModule.h"
            uint32 tmp_U32;
            Rte_Read_V_x_CamCipv_ObjID_V_x_CamCipv_ObjID(&tmp_U32);
            EXPECT_EQ(tmp_U32, 0);
        }
    } func_V_x_CamCipv_ObjID_SafetyModule;
    func_V_x_CamCipv_ObjID_SafetyModule.verify();

    /* V_x_CamCipv_ObjStatus*/
    extern UCAM_RADDataSet gOEM_SWC_C0_SMUCAM_RADDataSet;
    EXPECT_EQ(gOEM_SWC_C1_1UCAM_RADDataSet.mConc.V_x_CamCipv_ObjStatus, 0);
    EXPECT_EQ(gOEM_SWC_C0_SMUCAM_RADDataSet.mConc.V_x_CamCipv_ObjStatus, 0);
    struct _func_V_x_CamCipv_ObjStatus_SafetyModule {
        static void verify(void) {
#include "Rte_Wrapper_SafetyModule.h"
            uint32 tmp_U32;
            Rte_Read_V_x_CamCipv_ObjStatus_V_x_CamCipv_ObjStatus(&tmp_U32);
            EXPECT_EQ(tmp_U32, 0);
        }
    } func_V_x_CamCipv_ObjStatus_SafetyModule;
    func_V_x_CamCipv_ObjStatus_SafetyModule.verify();

    /* V_x_CamCipv_Pos*/
    extern UCAM_RADDataSet gOEM_SWC_C0_SMUCAM_RADDataSet;
    EXPECT_EQ(gOEM_SWC_C1_1UCAM_RADDataSet.mConc.V_x_CamCipv_Pos, 0);
    EXPECT_EQ(gOEM_SWC_C0_SMUCAM_RADDataSet.mConc.V_x_CamCipv_Pos, 0);
    struct _func_V_x_CamCipv_Pos_SafetyModule {
        static void verify(void) {
#include "Rte_Wrapper_SafetyModule.h"
            uint32 tmp_U32;
            Rte_Read_V_x_CamCipv_Pos_V_x_CamCipv_Pos(&tmp_U32);
            EXPECT_EQ(tmp_U32, 0);
        }
    } func_V_x_CamCipv_Pos_SafetyModule;
    func_V_x_CamCipv_Pos_SafetyModule.verify();

    /* V_x_CamCipv_TTCflg*/
    extern UCAM_RADDataSet gOEM_SWC_C0_SMUCAM_RADDataSet;
    EXPECT_EQ(gOEM_SWC_C1_1UCAM_RADDataSet.mConc.V_x_CamCipv_TTCflg, 0);
    EXPECT_EQ(gOEM_SWC_C0_SMUCAM_RADDataSet.mConc.V_x_CamCipv_TTCflg, 0);
    struct _func_V_x_CamCipv_TTCflg_SafetyModule {
        static void verify(void) {
#include "Rte_Wrapper_SafetyModule.h"
            uint32 tmp_U32;
            Rte_Read_V_x_CamCipv_TTCflg_V_x_CamCipv_TTCflg(&tmp_U32);
            EXPECT_EQ(tmp_U32, 0);
        }
    } func_V_x_CamCipv_TTCflg_SafetyModule;
    func_V_x_CamCipv_TTCflg_SafetyModule.verify();

    /* V_x_CamMcp_ObjID*/
    extern UCAM_RADDataSet gOEM_SWC_C0_SMUCAM_RADDataSet;
    EXPECT_EQ(gOEM_SWC_C1_1UCAM_RADDataSet.mConc.V_x_CamMcp_ObjID, 0);
    EXPECT_EQ(gOEM_SWC_C0_SMUCAM_RADDataSet.mConc.V_x_CamMcp_ObjID, 0);
    struct _func_V_x_CamMcp_ObjID_SafetyModule {
        static void verify(void) {
#include "Rte_Wrapper_SafetyModule.h"
            uint32 tmp_U32;
            Rte_Read_V_x_CamMcp_ObjID_V_x_CamMcp_ObjID(&tmp_U32);
            EXPECT_EQ(tmp_U32, 0);
        }
    } func_V_x_CamMcp_ObjID_SafetyModule;
    func_V_x_CamMcp_ObjID_SafetyModule.verify();

    /* V_x_CamPed_Num*/
    extern UCAM_RADDataSet gOEM_SWC_C0_SMUCAM_RADDataSet;
    EXPECT_EQ(gOEM_SWC_C1_1UCAM_RADDataSet.mConc.V_x_CamPed_Num, 0);
    EXPECT_EQ(gOEM_SWC_C0_SMUCAM_RADDataSet.mConc.V_x_CamPed_Num, 0);
    struct _func_V_x_CamPed_Num_SafetyModule {
        static void verify(void) {
#include "Rte_Wrapper_SafetyModule.h"
            uint32 tmp_U32;
            Rte_Read_V_x_CamPed_Num_V_x_CamPed_Num(&tmp_U32);
            EXPECT_EQ(tmp_U32, 0);
        }
    } func_V_x_CamPed_Num_SafetyModule;
    func_V_x_CamPed_Num_SafetyModule.verify();

    /* V_x_CamPed_ObjStatus*/
    extern UCAM_RADDataSet gOEM_SWC_C0_SMUCAM_RADDataSet;
    EXPECT_EQ(gOEM_SWC_C1_1UCAM_RADDataSet.mConc.V_x_CamPed_ObjStatus, 0);
    EXPECT_EQ(gOEM_SWC_C0_SMUCAM_RADDataSet.mConc.V_x_CamPed_ObjStatus, 0);
    struct _func_V_x_CamPed_ObjStatus_SafetyModule {
        static void verify(void) {
#include "Rte_Wrapper_SafetyModule.h"
            uint32 tmp_U32;
            Rte_Read_V_x_CamPed_ObjStatus_V_x_CamPed_ObjStatus(&tmp_U32);
            EXPECT_EQ(tmp_U32, 0);
        }
    } func_V_x_CamPed_ObjStatus_SafetyModule;
    func_V_x_CamPed_ObjStatus_SafetyModule.verify();

    /* V_x_CirCamRadMatchCnt*/
    extern UCAM_RADDataSet gOEM_SWC_C0_SMUCAM_RADDataSet;
    EXPECT_EQ(gOEM_SWC_C1_1UCAM_RADDataSet.mConc.V_x_CirCamRadMatchCnt, 0);
    EXPECT_EQ(gOEM_SWC_C0_SMUCAM_RADDataSet.mConc.V_x_CirCamRadMatchCnt, 0);
    struct _func_V_x_CirCamRadMatchCnt_SafetyModule {
        static void verify(void) {
#include "Rte_Wrapper_SafetyModule.h"
            uint32 tmp_U32;
            Rte_Read_V_x_CirCamRadMatchCnt_V_x_CirCamRadMatchCnt(&tmp_U32);
            EXPECT_EQ(tmp_U32, 0);
        }
    } func_V_x_CirCamRadMatchCnt_SafetyModule;
    func_V_x_CirCamRadMatchCnt_SafetyModule.verify();

    /* V_x_RadFcwa_Obj0ID*/
    extern UCAM_RADDataSet gOEM_SWC_C0_SMUCAM_RADDataSet;
    EXPECT_EQ(gOEM_SWC_C1_1UCAM_RADDataSet.mConc.V_x_RadFcwa_Obj0ID, 0);
    EXPECT_EQ(gOEM_SWC_C0_SMUCAM_RADDataSet.mConc.V_x_RadFcwa_Obj0ID, 0);
    struct _func_V_x_RadFcwa_Obj0ID_SafetyModule {
        static void verify(void) {
#include "Rte_Wrapper_SafetyModule.h"
            uint32 tmp_U32;
            Rte_Read_V_x_RadFcwa_Obj0ID_V_x_RadFcwa_Obj0ID(&tmp_U32);
            EXPECT_EQ(tmp_U32, 0);
        }
    } func_V_x_RadFcwa_Obj0ID_SafetyModule;
    func_V_x_RadFcwa_Obj0ID_SafetyModule.verify();

    /* V_x_RadFcwa_ObjID*/
    extern UCAM_RADDataSet gOEM_SWC_C0_SMUCAM_RADDataSet;
    EXPECT_EQ(gOEM_SWC_C1_1UCAM_RADDataSet.mConc.V_x_RadFcwa_ObjID, 0);
    EXPECT_EQ(gOEM_SWC_C0_SMUCAM_RADDataSet.mConc.V_x_RadFcwa_ObjID, 0);
    struct _func_V_x_RadFcwa_ObjID_SafetyModule {
        static void verify(void) {
#include "Rte_Wrapper_SafetyModule.h"
            uint32 tmp_U32;
            Rte_Read_V_x_RadFcwa_ObjID_V_x_RadFcwa_ObjID(&tmp_U32);
            EXPECT_EQ(tmp_U32, 0);
        }
    } func_V_x_RadFcwa_ObjID_SafetyModule;
    func_V_x_RadFcwa_ObjID_SafetyModule.verify();

    /* V_x_RadFcwa_ObjValid*/
    extern UCAM_RADDataSet gOEM_SWC_C0_SMUCAM_RADDataSet;
    EXPECT_EQ(gOEM_SWC_C1_1UCAM_RADDataSet.mConc.V_x_RadFcwa_ObjValid, 0);
    EXPECT_EQ(gOEM_SWC_C0_SMUCAM_RADDataSet.mConc.V_x_RadFcwa_ObjValid, 0);
    struct _func_V_x_RadFcwa_ObjValid_SafetyModule {
        static void verify(void) {
#include "Rte_Wrapper_SafetyModule.h"
            uint32 tmp_U32;
            Rte_Read_V_x_RadFcwa_ObjValid_V_x_RadFcwa_ObjValid(&tmp_U32);
            EXPECT_EQ(tmp_U32, 0);
        }
    } func_V_x_RadFcwa_ObjValid_SafetyModule;
    func_V_x_RadFcwa_ObjValid_SafetyModule.verify();

    /* V_x_RadFcwa_Pos*/
    extern UCAM_RADDataSet gOEM_SWC_C0_SMUCAM_RADDataSet;
    EXPECT_EQ(gOEM_SWC_C1_1UCAM_RADDataSet.mConc.V_x_RadFcwa_Pos, 0);
    EXPECT_EQ(gOEM_SWC_C0_SMUCAM_RADDataSet.mConc.V_x_RadFcwa_Pos, 0);
    struct _func_V_x_RadFcwa_Pos_SafetyModule {
        static void verify(void) {
#include "Rte_Wrapper_SafetyModule.h"
            uint32 tmp_U32;
            Rte_Read_V_x_RadFcwa_Pos_V_x_RadFcwa_Pos(&tmp_U32);
            EXPECT_EQ(tmp_U32, 0);
        }
    } func_V_x_RadFcwa_Pos_SafetyModule;
    func_V_x_RadFcwa_Pos_SafetyModule.verify();

    /* V_x_RadPed_Num*/
    extern UCAM_RADDataSet gOEM_SWC_C0_SMUCAM_RADDataSet;
    EXPECT_EQ(gOEM_SWC_C1_1UCAM_RADDataSet.mConc.V_x_RadPed_Num, 0);
    EXPECT_EQ(gOEM_SWC_C0_SMUCAM_RADDataSet.mConc.V_x_RadPed_Num, 0);
    struct _func_V_x_RadPed_Num_SafetyModule {
        static void verify(void) {
#include "Rte_Wrapper_SafetyModule.h"
            uint32 tmp_U32;
            Rte_Read_V_x_RadPed_Num_V_x_RadPed_Num(&tmp_U32);
            EXPECT_EQ(tmp_U32, 0);
        }
    } func_V_x_RadPed_Num_SafetyModule;
    func_V_x_RadPed_Num_SafetyModule.verify();

    /* V_x_vRIR_Input_AEBLateCDL*/
    extern UCAM_RADDataSet gOEM_SWC_C0_SMUCAM_RADDataSet;
    EXPECT_EQ(gOEM_SWC_C1_1UCAM_RADDataSet.mConc.V_x_vRIR_Input_AEBLateCDL, 0);
    EXPECT_EQ(gOEM_SWC_C0_SMUCAM_RADDataSet.mConc.V_x_vRIR_Input_AEBLateCDL, 0);
    struct _func_V_x_vRIR_Input_AEBLateCDL_SafetyModule {
        static void verify(void) {
#include "Rte_Wrapper_SafetyModule.h"
            uint8 tmp_U8;
            Rte_Read_V_x_vRIR_Input_AEBLateCDL_V_x_vRIR_Input_AEBLateCDL(&tmp_U8);
            EXPECT_EQ(tmp_U8, 0);
        }
    } func_V_x_vRIR_Input_AEBLateCDL_SafetyModule;
    func_V_x_vRIR_Input_AEBLateCDL_SafetyModule.verify();

}

void C1_1_o2o_noncache_min_verify_Fusion(void)
{
    boolean tmp_B;
    float32 tmp_Fl32;
    uint8 tmp_U8;
    float32 tmp_Fl32_10[10];
    V_x_VectorCameraObjects tmp_VectorCameraObjects;

}

void C1_1_o2o_noncache_min_verify_FS_ACT(void)
{
    boolean tmp_B;
    uint32 tmp_U32;
    uint16 tmp_U16;
    uint8 tmp_U8;

}

void C1_1_o2o_noncache_min_verify_FEBFCWDBA(void)
{
    boolean tmp_B;
    sint32 tmp_S32;
    sint16 tmp_S16;
    uint8 tmp_U8;
    uint16 tmp_U16;
    uint8 tmp_U8_60[60];

    /* V_Mpa_vVC_PBRK_COM_FEB*/
    extern UFEBFCWDBADataSet gOEM_SWC_C0_SMUFEBFCWDBADataSet;
    EXPECT_EQ(gOEM_SWC_C1_1UFEBFCWDBADataSet.mConc.V_Mpa_vVC_PBRK_COM_FEB, -2147483648);
    EXPECT_EQ(gOEM_SWC_C0_SMUFEBFCWDBADataSet.mConc.V_Mpa_vVC_PBRK_COM_FEB, -2147483648);
    struct _func_V_Mpa_vVC_PBRK_COM_FEB_SafetyModule {
        static void verify(void) {
#include "Rte_Wrapper_SafetyModule.h"
            sint32 tmp_S32;
            Rte_Read_V_Mpa_vVC_PBRK_COM_FEB_V_Mpa_vVC_PBRK_COM_FEB(&tmp_S32);
            EXPECT_EQ(tmp_S32, -2147483648);
        }
    } func_V_Mpa_vVC_PBRK_COM_FEB_SafetyModule;
    func_V_Mpa_vVC_PBRK_COM_FEB_SafetyModule.verify();

}

void C1_1_o2o_noncache_min_verify_LDPLDW(void)
{
    boolean tmp_B;
    sint16 tmp_S16;
    sint32 tmp_S32;
    uint16 tmp_U16;
    uint8 tmp_U8;
    float32 tmp_Fl32;

}

void C1_1_o2o_noncache_min_verify_BSI(void)
{
    boolean tmp_B;
    sint32 tmp_S32;
    float32 tmp_Fl32;
    uint8 tmp_U8;

}

void C1_1_o2o_noncache_min_verify_DAA(void)
{
    boolean tmp_B;
    uint8 tmp_U8;

}

void C1_1_o2o_noncache_min_verify_EAP(void)
{
    boolean tmp_B;
    sint32 tmp_S32;
    float32 tmp_Fl32;
    uint8 tmp_U8;
    uint8 tmp_U8_47[47];
    uint16 tmp_U16;
    uint8 tmp_U8_5[5];

    /* V_bar_PmsBrkVal*/
    extern UEAPDataSet gOEM_SWC_C0_SMUEAPDataSet;
    EXPECT_EQ(gOEM_SWC_C1_1UEAPDataSet.mConc.V_bar_PmsBrkVal, -2147483648);
    EXPECT_EQ(gOEM_SWC_C0_SMUEAPDataSet.mConc.V_bar_PmsBrkVal, -2147483648);
    struct _func_V_bar_PmsBrkVal_SafetyModule {
        static void verify(void) {
#include "Rte_Wrapper_SafetyModule.h"
            sint32 tmp_S32;
            Rte_Read_V_bar_PmsBrkVal_V_bar_PmsBrkVal(&tmp_S32);
            EXPECT_EQ(tmp_S32, -2147483648);
        }
    } func_V_bar_PmsBrkVal_SafetyModule;
    func_V_bar_PmsBrkVal_SafetyModule.verify();

}

void C1_1_o2o_noncache_min_verify_Control_Longi(void)
{
    boolean tmp_B;
    float32 tmp_Fl32;
    uint8 tmp_U8;
    float32 tmp_Fl32_10[10];

}

void C1_1_o2o_noncache_min_verify_Control_Lat(void)
{
    boolean tmp_B;
    float32 tmp_Fl32;
    uint8 tmp_U8;
    uint32 tmp_U32;
    float32 tmp_Fl32_10[10];
    sint8 tmp_S8;

}

void C1_1_o2o_noncache_min_verify_EDR(void)
{
    boolean tmp_B;
    uint8 tmp_U8;
    uint8 tmp_U8_44[44];

}

void C1_1_o2o_noncache_min_verify_HOD(void)
{
    boolean tmp_B;
    uint16 tmp_U16;
    float32 tmp_Fl32;
    uint8 tmp_U8;
    float32 tmp_Fl32_10[10];

}

void C1_1_o2o_noncache_min_verify_EHR(void)
{
    boolean tmp_B;
    float32 tmp_Fl32;
    sint16 tmp_S16_10[10];
    float32 tmp_Fl32_10[10];
    uint8 tmp_U8_10[10];
    sint32 tmp_S32;
    V_x_Curve20_t tmp_Curve20_t;
    V_x_CurveRaw_out_t tmp_CurveRaw_out_t;
    uint8 tmp_U8;
    V_x_Detect_Context_out tmp_Detect_Context_out;
    V_x_FunctionalRoadClass_bus tmp_FunctionalRoadClass_bus;
    V_x_POS_DATA_out_t tmp_POS_DATA_out_t;
    V_x_SEG_DATA_out_t tmp_SEG_DATA_out_t;
    V_x_STUB_DATA_out_t tmp_STUB_DATA_out_t;

}

void C1_1_o2o_noncache_min_verify_CASP(void)
{
    boolean tmp_B;
    float32 tmp_Fl32;
    V_x_CASPToAD1Enh tmp_CASPToAD1Enh;
    float32 tmp_Fl32_10[10];
    uint8 tmp_U8;
    uint16 tmp_U16;
    sint8 tmp_S8;

}

void C1_1_o2o_noncache_min_verify_APA(void)
{
    boolean tmp_B;
    float32 tmp_Fl32;
    uint8 tmp_U8;

}

void C1_1_o2o_noncache_min_verify_NoEntry(void)
{
    boolean tmp_B;

}

void C1_1_o2o_noncache_min_verify_LCDN(void)
{
    uint8 tmp_U8;

}
