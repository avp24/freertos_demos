#include "gtest/gtest.h"

#ifdef __cplusplus
extern "C" {
#endif
extern void OEM_SWC_C1_1_input_From_SUP(void);
extern void OEM_SWC_C1_1_output(void);
extern void OEM_SWC_C0_SM_input_From_OEM(void);
extern void OEM_SWC_C2_1_input_From_OEM(void);
extern void OEM_SWC_C2_2_input_From_OEM(void);
extern void OEM_SWC_C2_3_input_From_OEM(void);
#ifdef __cplusplus
}
#endif

extern void C1_1_o2o_noncache_prepare_DiagControl(void);
extern void C1_1_o2o_noncache_prepare_OEM_DIAG(void);
extern void C1_1_o2o_noncache_prepare_ActivationManagement(void);
extern void C1_1_o2o_noncache_prepare_VehStatus_In(void);
extern void C1_1_o2o_noncache_prepare_VehStatus_Out(void);
extern void C1_1_o2o_noncache_prepare_BRK_ENG(void);
extern void C1_1_o2o_noncache_prepare_YAW(void);
extern void C1_1_o2o_noncache_prepare_HMI(void);
extern void C1_1_o2o_noncache_prepare_CAM_RAD(void);
extern void C1_1_o2o_noncache_prepare_Fusion(void);
extern void C1_1_o2o_noncache_prepare_FS_ACT(void);
extern void C1_1_o2o_noncache_prepare_FEBFCWDBA(void);
extern void C1_1_o2o_noncache_prepare_LDPLDW(void);
extern void C1_1_o2o_noncache_prepare_BSI(void);
extern void C1_1_o2o_noncache_prepare_DAA(void);
extern void C1_1_o2o_noncache_prepare_EAP(void);
extern void C1_1_o2o_noncache_prepare_Control_Longi(void);
extern void C1_1_o2o_noncache_prepare_Control_Lat(void);
extern void C1_1_o2o_noncache_prepare_EDR(void);
extern void C1_1_o2o_noncache_prepare_HOD(void);
extern void C1_1_o2o_noncache_prepare_EHR(void);
extern void C1_1_o2o_noncache_prepare_CASP(void);
extern void C1_1_o2o_noncache_prepare_APA(void);
extern void C1_1_o2o_noncache_prepare_NoEntry(void);
extern void C1_1_o2o_noncache_prepare_LCDN(void);
extern void C1_1_o2o_noncache_verify_DiagControl(void);
extern void C1_1_o2o_noncache_verify_OEM_DIAG(void);
extern void C1_1_o2o_noncache_verify_ActivationManagement(void);
extern void C1_1_o2o_noncache_verify_VehStatus_In(void);
extern void C1_1_o2o_noncache_verify_VehStatus_Out(void);
extern void C1_1_o2o_noncache_verify_BRK_ENG(void);
extern void C1_1_o2o_noncache_verify_YAW(void);
extern void C1_1_o2o_noncache_verify_HMI(void);
extern void C1_1_o2o_noncache_verify_CAM_RAD(void);
extern void C1_1_o2o_noncache_verify_Fusion(void);
extern void C1_1_o2o_noncache_verify_FS_ACT(void);
extern void C1_1_o2o_noncache_verify_FEBFCWDBA(void);
extern void C1_1_o2o_noncache_verify_LDPLDW(void);
extern void C1_1_o2o_noncache_verify_BSI(void);
extern void C1_1_o2o_noncache_verify_DAA(void);
extern void C1_1_o2o_noncache_verify_EAP(void);
extern void C1_1_o2o_noncache_verify_Control_Longi(void);
extern void C1_1_o2o_noncache_verify_Control_Lat(void);
extern void C1_1_o2o_noncache_verify_EDR(void);
extern void C1_1_o2o_noncache_verify_HOD(void);
extern void C1_1_o2o_noncache_verify_EHR(void);
extern void C1_1_o2o_noncache_verify_CASP(void);
extern void C1_1_o2o_noncache_verify_APA(void);
extern void C1_1_o2o_noncache_verify_NoEntry(void);
extern void C1_1_o2o_noncache_verify_LCDN(void);
void C1_1_o2o_noncache_prepare(void)
{
    C1_1_o2o_noncache_prepare_DiagControl();
    C1_1_o2o_noncache_prepare_OEM_DIAG();
    C1_1_o2o_noncache_prepare_ActivationManagement();
    C1_1_o2o_noncache_prepare_VehStatus_In();
    C1_1_o2o_noncache_prepare_VehStatus_Out();
    C1_1_o2o_noncache_prepare_BRK_ENG();
    C1_1_o2o_noncache_prepare_YAW();
    C1_1_o2o_noncache_prepare_HMI();
    C1_1_o2o_noncache_prepare_CAM_RAD();
    C1_1_o2o_noncache_prepare_Fusion();
    C1_1_o2o_noncache_prepare_FS_ACT();
    C1_1_o2o_noncache_prepare_FEBFCWDBA();
    C1_1_o2o_noncache_prepare_LDPLDW();
    C1_1_o2o_noncache_prepare_BSI();
    C1_1_o2o_noncache_prepare_DAA();
    C1_1_o2o_noncache_prepare_EAP();
    C1_1_o2o_noncache_prepare_Control_Longi();
    C1_1_o2o_noncache_prepare_Control_Lat();
    C1_1_o2o_noncache_prepare_EDR();
    C1_1_o2o_noncache_prepare_HOD();
    C1_1_o2o_noncache_prepare_EHR();
    C1_1_o2o_noncache_prepare_CASP();
    C1_1_o2o_noncache_prepare_APA();
    C1_1_o2o_noncache_prepare_NoEntry();
    C1_1_o2o_noncache_prepare_LCDN();
}

void C1_1_o2o_noncache_verify(void)
{
    C1_1_o2o_noncache_verify_DiagControl();
    C1_1_o2o_noncache_verify_OEM_DIAG();
    C1_1_o2o_noncache_verify_ActivationManagement();
    C1_1_o2o_noncache_verify_VehStatus_In();
    C1_1_o2o_noncache_verify_VehStatus_Out();
    C1_1_o2o_noncache_verify_BRK_ENG();
    C1_1_o2o_noncache_verify_YAW();
    C1_1_o2o_noncache_verify_HMI();
    C1_1_o2o_noncache_verify_CAM_RAD();
    C1_1_o2o_noncache_verify_Fusion();
    C1_1_o2o_noncache_verify_FS_ACT();
    C1_1_o2o_noncache_verify_FEBFCWDBA();
    C1_1_o2o_noncache_verify_LDPLDW();
    C1_1_o2o_noncache_verify_BSI();
    C1_1_o2o_noncache_verify_DAA();
    C1_1_o2o_noncache_verify_EAP();
    C1_1_o2o_noncache_verify_Control_Longi();
    C1_1_o2o_noncache_verify_Control_Lat();
    C1_1_o2o_noncache_verify_EDR();
    C1_1_o2o_noncache_verify_HOD();
    C1_1_o2o_noncache_verify_EHR();
    C1_1_o2o_noncache_verify_CASP();
    C1_1_o2o_noncache_verify_APA();
    C1_1_o2o_noncache_verify_NoEntry();
    C1_1_o2o_noncache_verify_LCDN();
}

TEST(IOTest, C1_1_o2o_noncache_test)
{
    C1_1_o2o_noncache_prepare();
    OEM_SWC_C1_1_output();
    OEM_SWC_C0_SM_input_From_OEM();
    OEM_SWC_C2_1_input_From_OEM();
    OEM_SWC_C2_2_input_From_OEM();
    OEM_SWC_C2_3_input_From_OEM();
    C1_1_o2o_noncache_verify();
}
