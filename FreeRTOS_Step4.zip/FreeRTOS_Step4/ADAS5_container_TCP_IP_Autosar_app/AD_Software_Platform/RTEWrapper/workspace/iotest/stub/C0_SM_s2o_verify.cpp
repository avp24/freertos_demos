#include <limits.h>
#include <float.h>
#include "gtest/gtest.h"
#include "Platform_Types.h"



extern uint8 gOEM_SWC_C0_SMV_x_VARIANTCODE;


extern boolean gOEM_SWC_C0_SMF_x_CAN_HW_Fail;
extern boolean gOEM_SWC_C0_SMF_x_Ethernet_HW_Fail;



extern boolean gOEM_SWC_C0_SMF_x_FS_BusOff_JT1;
extern boolean gOEM_SWC_C0_SMF_x_FS_BusOff_JT2;
extern boolean gOEM_SWC_C0_SMF_x_FS_ChkSumVDC;
extern boolean gOEM_SWC_C0_SMF_x_FS_MsgCntVDC;
extern boolean gOEM_SWC_C0_SMF_x_FS_UnRcvVDC_JT1;
extern boolean gOEM_SWC_C0_SMF_x_FS_UnRcvVDC_JT2;
extern boolean gOEM_SWC_C0_SMF_x_IgnitionSupplyConfirmation_CAN;
extern sint16 gOEM_SWC_C0_SMV_deg_SteerRackPinionAngleCorrect_CAN;
extern sint16 gOEM_SWC_C0_SMV_degps_YawRateRaw_BasicSW;
extern uint16 gOEM_SWC_C0_SMV_rpm_WheelSpeedFL_BasicSW;
extern uint16 gOEM_SWC_C0_SMV_rpm_WheelSpeedFR_BasicSW;
extern uint16 gOEM_SWC_C0_SMV_rpm_WheelSpeedRL_BasicSW;
extern uint16 gOEM_SWC_C0_SMV_rpm_WheelSpeedRR_BasicSW;
extern uint8 gOEM_SWC_C0_SMV_x_GADE_v2_BasicSW;

extern boolean gOEM_SWC_C0_SMF_x_FS_CRCCAM_ETH;
extern boolean gOEM_SWC_C0_SMF_x_FS_CRCRADAR_ETH;
extern boolean gOEM_SWC_C0_SMF_x_FS_ClockCAM_ETH;
extern boolean gOEM_SWC_C0_SMF_x_FS_ClockRADAR_ETH;
extern boolean gOEM_SWC_C0_SMF_x_FS_ETHUnRcvFrCamera_JT2;
extern boolean gOEM_SWC_C0_SMF_x_FS_ETHUnRcvRADAR_JT2;
extern boolean gOEM_SWC_C0_SMF_x_FS_UnRcvCamera_JT1_ETH;
extern boolean gOEM_SWC_C0_SMF_x_FS_UnRcvCamera_JT2_ETH;
extern boolean gOEM_SWC_C0_SMF_x_FS_UnRcvRADAR_JT1_ETH;
extern boolean gOEM_SWC_C0_SMF_x_FS_UnRcvRADAR_JT2_ETH;

extern boolean gOEM_SWC_C0_SMF_x_FOTA_ReIgnON;

void C0_SM_s2o_verify_ADC(void)
{
}

void C0_SM_s2o_verify_DIO(void)
{
}

void C0_SM_s2o_verify_EEPROM(void)
{
    EXPECT_EQ(gOEM_SWC_C0_SMV_x_VARIANTCODE, 81);
}

void C0_SM_s2o_verify_PWM(void)
{
}

void C0_SM_s2o_verify_SUP_DIAG(void)
{
    EXPECT_EQ(gOEM_SWC_C0_SMF_x_CAN_HW_Fail, 161);
    EXPECT_EQ(gOEM_SWC_C0_SMF_x_Ethernet_HW_Fail, 100);
}

void C0_SM_s2o_verify_UDSCOM(void)
{
}

void C0_SM_s2o_verify_LINIF(void)
{
}

void C0_SM_s2o_verify_CANIF(void)
{
    EXPECT_EQ(gOEM_SWC_C0_SMF_x_FS_BusOff_JT1, 81);
    EXPECT_EQ(gOEM_SWC_C0_SMF_x_FS_BusOff_JT2, 225);
    EXPECT_EQ(gOEM_SWC_C0_SMF_x_FS_ChkSumVDC, 61);
    EXPECT_EQ(gOEM_SWC_C0_SMF_x_FS_MsgCntVDC, 87);
    EXPECT_EQ(gOEM_SWC_C0_SMF_x_FS_UnRcvVDC_JT1, 224);
    EXPECT_EQ(gOEM_SWC_C0_SMF_x_FS_UnRcvVDC_JT2, 30);
    EXPECT_EQ(gOEM_SWC_C0_SMF_x_IgnitionSupplyConfirmation_CAN, 134);
    EXPECT_EQ(gOEM_SWC_C0_SMV_deg_SteerRackPinionAngleCorrect_CAN, -2108);
    EXPECT_EQ(gOEM_SWC_C0_SMV_degps_YawRateRaw_BasicSW, -16221);
    EXPECT_EQ(gOEM_SWC_C0_SMV_rpm_WheelSpeedFL_BasicSW, 23497);
    EXPECT_EQ(gOEM_SWC_C0_SMV_rpm_WheelSpeedFR_BasicSW, 56380);
    EXPECT_EQ(gOEM_SWC_C0_SMV_rpm_WheelSpeedRL_BasicSW, 8839);
    EXPECT_EQ(gOEM_SWC_C0_SMV_rpm_WheelSpeedRR_BasicSW, 14628);
    EXPECT_EQ(gOEM_SWC_C0_SMV_x_GADE_v2_BasicSW, 30);
}

void C0_SM_s2o_verify_EthIF(void)
{
    EXPECT_EQ(gOEM_SWC_C0_SMF_x_FS_CRCCAM_ETH, 206);
    EXPECT_EQ(gOEM_SWC_C0_SMF_x_FS_CRCRADAR_ETH, 154);
    EXPECT_EQ(gOEM_SWC_C0_SMF_x_FS_ClockCAM_ETH, 184);
    EXPECT_EQ(gOEM_SWC_C0_SMF_x_FS_ClockRADAR_ETH, 84);
    EXPECT_EQ(gOEM_SWC_C0_SMF_x_FS_ETHUnRcvFrCamera_JT2, 33);
    EXPECT_EQ(gOEM_SWC_C0_SMF_x_FS_ETHUnRcvRADAR_JT2, 190);
    EXPECT_EQ(gOEM_SWC_C0_SMF_x_FS_UnRcvCamera_JT1_ETH, 168);
    EXPECT_EQ(gOEM_SWC_C0_SMF_x_FS_UnRcvCamera_JT2_ETH, 80);
    EXPECT_EQ(gOEM_SWC_C0_SMF_x_FS_UnRcvRADAR_JT1_ETH, 163);
    EXPECT_EQ(gOEM_SWC_C0_SMF_x_FS_UnRcvRADAR_JT2_ETH, 199);
}

void C0_SM_s2o_verify_OEMRAMClear(void)
{
    EXPECT_EQ(gOEM_SWC_C0_SMF_x_FOTA_ReIgnON, 86);
}
