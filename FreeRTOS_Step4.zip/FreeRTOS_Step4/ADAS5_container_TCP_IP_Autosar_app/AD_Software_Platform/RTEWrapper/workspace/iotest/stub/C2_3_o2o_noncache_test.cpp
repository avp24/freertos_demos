#include "gtest/gtest.h"

#ifdef __cplusplus
extern "C" {
#endif
extern void OEM_SWC_C2_3_input_From_SUP(void);
extern void OEM_SWC_C2_3_output(void);
extern void OEM_SWC_C0_SM_input_From_OEM(void);
extern void OEM_SWC_C1_1_input_From_OEM(void);
extern void OEM_SWC_C2_1_input_From_OEM(void);
extern void OEM_SWC_C2_2_input_From_OEM(void);
#ifdef __cplusplus
}
#endif

extern void C2_3_o2o_noncache_prepare_RCarHMIManagement(void);
extern void C2_3_o2o_noncache_prepare_ObjectSelectionAVM(void);
extern void C2_3_o2o_noncache_prepare_VehStatus_In_100(void);
extern void C2_3_o2o_noncache_verify_RCarHMIManagement(void);
extern void C2_3_o2o_noncache_verify_ObjectSelectionAVM(void);
extern void C2_3_o2o_noncache_verify_VehStatus_In_100(void);
void C2_3_o2o_noncache_prepare(void)
{
    C2_3_o2o_noncache_prepare_RCarHMIManagement();
    C2_3_o2o_noncache_prepare_ObjectSelectionAVM();
    C2_3_o2o_noncache_prepare_VehStatus_In_100();
}

void C2_3_o2o_noncache_verify(void)
{
    C2_3_o2o_noncache_verify_RCarHMIManagement();
    C2_3_o2o_noncache_verify_ObjectSelectionAVM();
    C2_3_o2o_noncache_verify_VehStatus_In_100();
}

TEST(IOTest, C2_3_o2o_noncache_test)
{
    C2_3_o2o_noncache_prepare();
    OEM_SWC_C2_3_output();
    OEM_SWC_C0_SM_input_From_OEM();
    OEM_SWC_C1_1_input_From_OEM();
    OEM_SWC_C2_1_input_From_OEM();
    OEM_SWC_C2_2_input_From_OEM();
    C2_3_o2o_noncache_verify();
}
