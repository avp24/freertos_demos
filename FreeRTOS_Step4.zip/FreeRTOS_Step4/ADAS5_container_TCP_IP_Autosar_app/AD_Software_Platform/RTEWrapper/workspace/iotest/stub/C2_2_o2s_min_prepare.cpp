#include <limits.h>
#include <float.h>
#define DUMMY_RTE_INCLUDE_MULTI_SWC_HEADER
#include "Platform_Types.h"
#ifdef __cplusplus
extern "C" {
#endif
#ifdef __cplusplus
}
#endif

#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
void C2_2_o2s_min_prepare_AutoLCPossibilityJdg(void)
{
    V_x_AutoLCPossibilityJdgOutput tmp_AutoLCPossibilityJdgOutput;

}

#include "Rte_Wrapper_ObjectSelectionDM.h"
void C2_2_o2s_min_prepare_ObjectSelectionDM(void)
{
    V_x_ObjectSelectionDMOutput tmp_ObjectSelectionDMOutput;

}

#include "Rte_Wrapper_VehStatus_In_50.h"
void C2_2_o2s_min_prepare_VehStatus_In_50(void)
{
    V_x_surround_obj_left_t tmp_surround_obj_left_t;
    V_x_surround_obj_rearcenter_t tmp_surround_obj_rearcenter_t;
    V_x_surround_obj_right_t tmp_surround_obj_right_t;

}
