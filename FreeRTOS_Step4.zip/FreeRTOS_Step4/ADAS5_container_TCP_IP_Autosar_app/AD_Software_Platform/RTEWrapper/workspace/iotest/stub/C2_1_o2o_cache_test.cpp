#include "gtest/gtest.h"

#ifdef __cplusplus
extern "C" {
#endif
extern void OEM_SWC_C2_1_input_From_SUP(void);
extern void OEM_SWC_C2_1_output(void);
#ifdef __cplusplus
}
#endif

extern void C2_1_o2o_cache_prepare_SurroundFusion(void);
extern void C2_1_o2o_cache_prepare_VehStatus_In_10(void);
extern void C2_1_o2o_cache_verify_SurroundFusion(void);
extern void C2_1_o2o_cache_verify_VehStatus_In_10(void);
void C2_1_o2o_cache_prepare(void)
{
    C2_1_o2o_cache_prepare_SurroundFusion();
    C2_1_o2o_cache_prepare_VehStatus_In_10();
}

void C2_1_o2o_cache_verify(void)
{
    C2_1_o2o_cache_verify_SurroundFusion();
    C2_1_o2o_cache_verify_VehStatus_In_10();
}

TEST(IOTest, C2_1_o2o_cache_test)
{
    C2_1_o2o_cache_prepare();
    C2_1_o2o_cache_verify();
}
