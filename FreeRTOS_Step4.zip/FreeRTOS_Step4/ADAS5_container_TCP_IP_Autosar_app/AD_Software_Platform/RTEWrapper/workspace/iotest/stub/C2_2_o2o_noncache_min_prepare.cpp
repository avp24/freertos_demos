#include <limits.h>
#include <float.h>
#define DUMMY_RTE_INCLUDE_MULTI_SWC_HEADER
#include "Platform_Types.h"

#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
void C2_2_o2o_noncache_min_prepare_AutoLCPossibilityJdg(void)
{
    V_x_AutoLCPossibilityJdgOutput tmp_AutoLCPossibilityJdgOutput;

    tmp_AutoLCPossibilityJdgOutput.V_x_st_Output_DynamicConflJdgDiag.F_x_Dcj_ObjLeft = 0;
    tmp_AutoLCPossibilityJdgOutput.V_x_st_Output_DynamicConflJdgDiag.V_m_Dcj_ObjLeftPosX = -340282346638528897590636046441678635008;
    tmp_AutoLCPossibilityJdgOutput.V_x_st_Output_DynamicConflJdgDiag.V_m_Dcj_ObjLeftPosY = -340282346638528897590636046441678635008;
    tmp_AutoLCPossibilityJdgOutput.V_x_st_Output_DynamicConflJdgDiag.V_mps_Dcj_ObjLeftVelX = -340282346638528897590636046441678635008;
    tmp_AutoLCPossibilityJdgOutput.V_x_st_Output_DynamicConflJdgDiag.V_mps_Dcj_ObjLeftVelY = -340282346638528897590636046441678635008;
    tmp_AutoLCPossibilityJdgOutput.V_x_st_Output_DynamicConflJdgDiag.V_m_Dcj_ObjLeftGapF = -340282346638528897590636046441678635008;
    tmp_AutoLCPossibilityJdgOutput.V_x_st_Output_DynamicConflJdgDiag.V_m_Dcj_ObjLeftGapR = -340282346638528897590636046441678635008;
    tmp_AutoLCPossibilityJdgOutput.V_x_st_Output_DynamicConflJdgDiag.V_x_Dcj_ObjLeftNum = 0;
    tmp_AutoLCPossibilityJdgOutput.V_x_st_Output_DynamicConflJdgDiag.V_x_Dcj_ObjRight = 0;
    tmp_AutoLCPossibilityJdgOutput.V_x_st_Output_DynamicConflJdgDiag.V_m_Dcj_ObjRightPosX = -340282346638528897590636046441678635008;
    tmp_AutoLCPossibilityJdgOutput.V_x_st_Output_DynamicConflJdgDiag.V_m_Dcj_ObjRightPosY = -340282346638528897590636046441678635008;
    tmp_AutoLCPossibilityJdgOutput.V_x_st_Output_DynamicConflJdgDiag.V_mps_Dcj_ObjRightVelX = -340282346638528897590636046441678635008;
    tmp_AutoLCPossibilityJdgOutput.V_x_st_Output_DynamicConflJdgDiag.V_mps_Dcj_ObjRightVelY = -340282346638528897590636046441678635008;
    tmp_AutoLCPossibilityJdgOutput.V_x_st_Output_DynamicConflJdgDiag.V_m_Dcj_ObjRightGapF = -340282346638528897590636046441678635008;
    tmp_AutoLCPossibilityJdgOutput.V_x_st_Output_DynamicConflJdgDiag.V_m_Dcj_ObjRightGapR = -340282346638528897590636046441678635008;
    tmp_AutoLCPossibilityJdgOutput.V_x_st_Output_DynamicConflJdgDiag.V_x_Dcj_ObjRightNum = 0;
    tmp_AutoLCPossibilityJdgOutput.V_x_st_Output_Alc.V_x_lane_change_possible_left = 0;
    tmp_AutoLCPossibilityJdgOutput.V_x_st_Output_Alc.V_x_lane_change_possible_right = 0;
    tmp_AutoLCPossibilityJdgOutput.V_x_st_Output_Alc.V_x_lane_change_pass_right = 0;
    tmp_AutoLCPossibilityJdgOutput.V_x_st_Output_Alc.V_x_lane_change_return_left = 0;
    tmp_AutoLCPossibilityJdgOutput.V_x_st_Output_Alc.F_x_next_lane_free_left = 0;
    tmp_AutoLCPossibilityJdgOutput.V_x_st_Output_Alc.F_x_next_lane_free_right = 0;
    Rte_Write_V_x_AutoLCPossibilityJdgOutput_V_x_AutoLCPossibilityJdgOutput(&tmp_AutoLCPossibilityJdgOutput);
}

#include "Rte_Wrapper_ObjectSelectionDM.h"
void C2_2_o2o_noncache_min_prepare_ObjectSelectionDM(void)
{
    V_x_ObjectSelectionDMOutput tmp_ObjectSelectionDMOutput;

    tmp_ObjectSelectionDMOutput.V_m_FL_SideRadarPosX_DMS = -340282346638528897590636046441678635008;
    tmp_ObjectSelectionDMOutput.V_m_FL_SideRadarPosY_DMS = -340282346638528897590636046441678635008;
    tmp_ObjectSelectionDMOutput.V_mps_FL_SideRadarRelVelX_DMS = -340282346638528897590636046441678635008;
    tmp_ObjectSelectionDMOutput.V_m_FR_SideRadarPosX_DMS = -340282346638528897590636046441678635008;
    tmp_ObjectSelectionDMOutput.V_m_FR_SideRadarPosY_DMS = -340282346638528897590636046441678635008;
    tmp_ObjectSelectionDMOutput.V_mps_FR_SideRadarRelVelX_DMS = -340282346638528897590636046441678635008;
    tmp_ObjectSelectionDMOutput.V_m_RL_SideRadarPosX_DMS = -340282346638528897590636046441678635008;
    tmp_ObjectSelectionDMOutput.V_m_RL_SideRadarPosY_DMS = -340282346638528897590636046441678635008;
    tmp_ObjectSelectionDMOutput.V_mps_RL_SideRadarRelVelX_DMS = -340282346638528897590636046441678635008;
    tmp_ObjectSelectionDMOutput.V_m_RR_SideRadarPosX_DMS = -340282346638528897590636046441678635008;
    tmp_ObjectSelectionDMOutput.V_m_RR_SideRadarPosY_DMS = -340282346638528897590636046441678635008;
    tmp_ObjectSelectionDMOutput.V_mps_RR_SideRadarRelVelX_DMS = -340282346638528897590636046441678635008;
    Rte_Write_V_x_ObjectSelectionDMOutput_V_x_ObjectSelectionDMOutput(&tmp_ObjectSelectionDMOutput);
}

#include "Rte_Wrapper_VehStatus_In_50.h"
void C2_2_o2o_noncache_min_prepare_VehStatus_In_50(void)
{
    V_x_surround_obj_left_t tmp_surround_obj_left_t;
    V_x_surround_obj_rearcenter_t tmp_surround_obj_rearcenter_t;
    V_x_surround_obj_right_t tmp_surround_obj_right_t;

}
