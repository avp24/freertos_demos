#include <limits.h>
#include <float.h>
#define DUMMY_RTE_INCLUDE_MULTI_SWC_HEADER
#include "Platform_Types.h"
#ifdef __cplusplus
extern "C" {
#endif
#include "Rte_ADC.h"
#include "Rte_DIO.h"
#include "Rte_EEPROM.h"
#include "Rte_PWM.h"
#include "Rte_SUP_DIAG.h"
#include "Rte_UDSCOM.h"
#include "Rte_LINIF.h"
#include "Rte_CANIF.h"
#include "Rte_EthIF.h"
#include "Rte_OEMRAMClear.h"
#ifdef __cplusplus
}
#endif

void C0_SM_s2o_max_prepare_ADC(void)
{
    uint16 tmp_U16;

}

void C0_SM_s2o_max_prepare_DIO(void)
{
    boolean tmp_B;

}

void C0_SM_s2o_max_prepare_EEPROM(void)
{
    boolean tmp_B;
    uint8 tmp_U8;
    float32 tmp_Fl32;
    uint32 tmp_U32;
    uint16 tmp_U16;
    uint8 tmp_U8_5[5];
    sint8 tmp_S8;
    uint8 tmp_U8_40[40];
    uint8 tmp_U8_48[48];

    tmp_U8 = 255;
    Rte_Write_V_x_VARIANTCODE_V_x_VARIANTCODE(tmp_U8);
}

void C0_SM_s2o_max_prepare_PWM(void)
{

}

void C0_SM_s2o_max_prepare_SUP_DIAG(void)
{
    boolean tmp_B;
    uint8 tmp_U8;

    tmp_B = 255;
    Rte_Write_F_x_CAN_HW_Fail_F_x_CAN_HW_Fail(tmp_B);
    tmp_B = 255;
    Rte_Write_F_x_Ethernet_HW_Fail_F_x_Ethernet_HW_Fail(tmp_B);
}

void C0_SM_s2o_max_prepare_UDSCOM(void)
{
    boolean tmp_B;
    uint16 tmp_U16;
    uint8 tmp_U8;

}

void C0_SM_s2o_max_prepare_LINIF(void)
{
    boolean tmp_B;
    uint8 tmp_U8;

}

void C0_SM_s2o_max_prepare_CANIF(void)
{
    boolean tmp_B;
    uint8 tmp_U8;
    sint16 tmp_S16;
    uint16 tmp_U16;
    float32 tmp_Fl32;
    sint32 tmp_S32;
    uint32 tmp_U32;
    uint8 tmp_U8_8[8];
    sint8 tmp_S8;

    tmp_B = 255;
    Rte_Write_F_x_FS_BusOff_JT1_F_x_FS_BusOff_JT1(tmp_B);
    tmp_B = 255;
    Rte_Write_F_x_FS_BusOff_JT2_F_x_FS_BusOff_JT2(tmp_B);
    tmp_B = 255;
    Rte_Write_F_x_FS_ChkSumVDC_F_x_FS_ChkSumVDC(tmp_B);
    tmp_B = 255;
    Rte_Write_F_x_FS_MsgCntVDC_F_x_FS_MsgCntVDC(tmp_B);
    tmp_B = 255;
    Rte_Write_F_x_FS_UnRcvVDC_JT1_F_x_FS_UnRcvVDC_JT1(tmp_B);
    tmp_B = 255;
    Rte_Write_F_x_FS_UnRcvVDC_JT2_F_x_FS_UnRcvVDC_JT2(tmp_B);
    tmp_B = 255;
    Rte_Write_F_x_IgnitionSupplyConfirmation_CAN_F_x_IgnitionSupplyConfirmation_CAN(tmp_B);
    tmp_S16 = 32767;
    Rte_Write_V_deg_SteerRackPinionAngleCorrect_CAN_V_deg_SteerRackPinionAngleCorrect_CAN(tmp_S16);
    tmp_S16 = 32767;
    Rte_Write_V_degps_YawRateRaw_BasicSW_V_degps_YawRateRaw_BasicSW(tmp_S16);
    tmp_U16 = 65535;
    Rte_Write_V_rpm_WheelSpeedFL_BasicSW_V_rpm_WheelSpeedFL_BasicSW(tmp_U16);
    tmp_U16 = 65535;
    Rte_Write_V_rpm_WheelSpeedFR_BasicSW_V_rpm_WheelSpeedFR_BasicSW(tmp_U16);
    tmp_U16 = 65535;
    Rte_Write_V_rpm_WheelSpeedRL_BasicSW_V_rpm_WheelSpeedRL_BasicSW(tmp_U16);
    tmp_U16 = 65535;
    Rte_Write_V_rpm_WheelSpeedRR_BasicSW_V_rpm_WheelSpeedRR_BasicSW(tmp_U16);
    tmp_U8 = 255;
    Rte_Write_V_x_GADE_v2_BasicSW_V_x_GADE_v2_BasicSW(tmp_U8);
}

void C0_SM_s2o_max_prepare_EthIF(void)
{
    boolean tmp_B;
    float32 tmp_Fl32;
    uint32 tmp_U32;
    uint8 tmp_U8;
    uint16 tmp_U16;

    tmp_B = 255;
    Rte_Write_F_x_FS_CRCCAM_ETH_F_x_FS_CRCCAM_ETH(tmp_B);
    tmp_B = 255;
    Rte_Write_F_x_FS_CRCRADAR_ETH_F_x_FS_CRCRADAR_ETH(tmp_B);
    tmp_B = 255;
    Rte_Write_F_x_FS_ClockCAM_ETH_F_x_FS_ClockCAM_ETH(tmp_B);
    tmp_B = 255;
    Rte_Write_F_x_FS_ClockRADAR_ETH_F_x_FS_ClockRADAR_ETH(tmp_B);
    tmp_B = 255;
    Rte_Write_F_x_FS_ETHUnRcvFrCamera_JT2_F_x_FS_ETHUnRcvFrCamera_JT2(tmp_B);
    tmp_B = 255;
    Rte_Write_F_x_FS_ETHUnRcvRADAR_JT2_F_x_FS_ETHUnRcvRADAR_JT2(tmp_B);
    tmp_B = 255;
    Rte_Write_F_x_FS_UnRcvCamera_JT1_ETH_F_x_FS_UnRcvCamera_JT1_ETH(tmp_B);
    tmp_B = 255;
    Rte_Write_F_x_FS_UnRcvCamera_JT2_ETH_F_x_FS_UnRcvCamera_JT2_ETH(tmp_B);
    tmp_B = 255;
    Rte_Write_F_x_FS_UnRcvRADAR_JT1_ETH_F_x_FS_UnRcvRADAR_JT1_ETH(tmp_B);
    tmp_B = 255;
    Rte_Write_F_x_FS_UnRcvRADAR_JT2_ETH_F_x_FS_UnRcvRADAR_JT2_ETH(tmp_B);
}

void C0_SM_s2o_max_prepare_OEMRAMClear(void)
{
    boolean tmp_B;
    uint8 tmp_U8;

    tmp_B = 255;
    Rte_Write_F_x_FOTA_ReIgnON_F_x_FOTA_ReIgnON(tmp_B);
}
