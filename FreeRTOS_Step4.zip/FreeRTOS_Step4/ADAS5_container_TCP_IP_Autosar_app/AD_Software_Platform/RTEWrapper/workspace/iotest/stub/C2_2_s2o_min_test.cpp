#include "gtest/gtest.h"

#ifdef __cplusplus
extern "C" {
#endif
extern void OEM_SWC_C2_2_input_From_SUP(void);
extern void OEM_SWC_C2_2_output(void);
#ifdef __cplusplus
}
#endif

extern void C2_2_s2o_min_prepare_ADC(void);
extern void C2_2_s2o_min_prepare_DIO(void);
extern void C2_2_s2o_min_prepare_EEPROM(void);
extern void C2_2_s2o_min_prepare_PWM(void);
extern void C2_2_s2o_min_prepare_SUP_DIAG(void);
extern void C2_2_s2o_min_prepare_UDSCOM(void);
extern void C2_2_s2o_min_prepare_LINIF(void);
extern void C2_2_s2o_min_prepare_CANIF(void);
extern void C2_2_s2o_min_prepare_EthIF(void);
extern void C2_2_s2o_min_prepare_OEMRAMClear(void);
extern void C2_2_s2o_min_verify_ADC(void);
extern void C2_2_s2o_min_verify_DIO(void);
extern void C2_2_s2o_min_verify_EEPROM(void);
extern void C2_2_s2o_min_verify_PWM(void);
extern void C2_2_s2o_min_verify_SUP_DIAG(void);
extern void C2_2_s2o_min_verify_UDSCOM(void);
extern void C2_2_s2o_min_verify_LINIF(void);
extern void C2_2_s2o_min_verify_CANIF(void);
extern void C2_2_s2o_min_verify_EthIF(void);
extern void C2_2_s2o_min_verify_OEMRAMClear(void);
void C2_2_s2o_min_prepare(void)
{
    C2_2_s2o_min_prepare_ADC();
    C2_2_s2o_min_prepare_DIO();
    C2_2_s2o_min_prepare_EEPROM();
    C2_2_s2o_min_prepare_PWM();
    C2_2_s2o_min_prepare_SUP_DIAG();
    C2_2_s2o_min_prepare_UDSCOM();
    C2_2_s2o_min_prepare_LINIF();
    C2_2_s2o_min_prepare_CANIF();
    C2_2_s2o_min_prepare_EthIF();
    C2_2_s2o_min_prepare_OEMRAMClear();
}

void C2_2_s2o_min_verify(void)
{
    C2_2_s2o_min_verify_ADC();
    C2_2_s2o_min_verify_DIO();
    C2_2_s2o_min_verify_EEPROM();
    C2_2_s2o_min_verify_PWM();
    C2_2_s2o_min_verify_SUP_DIAG();
    C2_2_s2o_min_verify_UDSCOM();
    C2_2_s2o_min_verify_LINIF();
    C2_2_s2o_min_verify_CANIF();
    C2_2_s2o_min_verify_EthIF();
    C2_2_s2o_min_verify_OEMRAMClear();
}

TEST(IOTest, C2_2_s2o_min_test)
{
    C2_2_s2o_min_prepare();
    OEM_SWC_C2_2_input_From_SUP();
    C2_2_s2o_min_verify();
}
