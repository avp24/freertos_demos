#include <limits.h>
#include <float.h>
#define DUMMY_RTE_INCLUDE_MULTI_SWC_HEADER
#include "Platform_Types.h"

#include "Rte_Wrapper_SafetyModule.h"
void C0_SM_o2o_noncache_prepare_SafetyModule(void)
{
    uint16 tmp_U16;
    sint16 tmp_S16;
    sint8 tmp_S8;
    uint8 tmp_U8;

}
