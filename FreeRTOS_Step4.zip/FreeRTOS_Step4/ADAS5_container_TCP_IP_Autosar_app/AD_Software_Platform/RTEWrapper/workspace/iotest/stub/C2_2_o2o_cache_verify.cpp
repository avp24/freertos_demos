#include <limits.h>
#include <float.h>
#include "gtest/gtest.h"
#include "Rte_Union.h"
#include "Platform_Types.h"

extern UAutoLCPossibilityJdgDataSet gOEM_SWC_C2_2UAutoLCPossibilityJdgDataSet;
void C2_2_o2o_cache_verify_AutoLCPossibilityJdg(void)
{
    V_x_AutoLCPossibilityJdgOutput tmp_AutoLCPossibilityJdgOutput;

}

extern UObjectSelectionDMDataSet gOEM_SWC_C2_2UObjectSelectionDMDataSet;
void C2_2_o2o_cache_verify_ObjectSelectionDM(void)
{
    V_x_ObjectSelectionDMOutput tmp_ObjectSelectionDMOutput;

}

extern UVehStatus_In_50DataSet gOEM_SWC_C2_2UVehStatus_In_50DataSet;
void C2_2_o2o_cache_verify_VehStatus_In_50(void)
{
    V_x_surround_obj_left_t tmp_surround_obj_left_t;
    V_x_surround_obj_rearcenter_t tmp_surround_obj_rearcenter_t;
    V_x_surround_obj_right_t tmp_surround_obj_right_t;

    /* V_x_surround_obj_left_t */
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[0].V_x_pos.V_m_X, -689.14);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_0 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[0].V_x_pos.V_m_X, -689.14);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_0;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_0.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_0 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[0].V_x_pos.V_m_X, -689.14);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_0;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_0.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[0].V_x_pos.V_m_Y, -24.1);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_1 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[0].V_x_pos.V_m_Y, -24.1);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_1;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_1.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_1 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[0].V_x_pos.V_m_Y, -24.1);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_1;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_1.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[0].V_x_vel.V_m_X, 956.03);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_2 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[0].V_x_vel.V_m_X, 956.03);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_2;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_2.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_2 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[0].V_x_vel.V_m_X, 956.03);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_2;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_2.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[0].V_x_vel.V_m_Y, -8.34);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_3 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[0].V_x_vel.V_m_Y, -8.34);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_3;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_3.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_3 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[0].V_x_vel.V_m_Y, -8.34);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_3;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_3.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[0].V_m_lat_pos_in_lane[0], -349.28);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[0].V_m_lat_pos_in_lane[1], -711.19);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[0].V_m_lat_pos_in_lane[2], 479.84);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[0].V_m_lat_pos_in_lane[3], -87.7);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[0].V_m_lat_pos_in_lane[4], -91.3);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_4 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[0].V_m_lat_pos_in_lane[0], -349.28);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[0].V_m_lat_pos_in_lane[1], -711.19);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[0].V_m_lat_pos_in_lane[2], 479.84);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[0].V_m_lat_pos_in_lane[3], -87.7);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[0].V_m_lat_pos_in_lane[4], -91.3);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_4;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_4.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_4 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[0].V_m_lat_pos_in_lane[0], -349.28);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[0].V_m_lat_pos_in_lane[1], -711.19);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[0].V_m_lat_pos_in_lane[2], 479.84);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[0].V_m_lat_pos_in_lane[3], -87.7);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[0].V_m_lat_pos_in_lane[4], -91.3);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_4;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_4.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[0].V_m_lat_vel_in_lane, 914.11);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_5 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[0].V_m_lat_vel_in_lane, 914.11);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_5;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_5.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_5 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[0].V_m_lat_vel_in_lane, 914.11);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_5;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_5.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[0].V_m_width, -419.82);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_6 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[0].V_m_width, -419.82);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_6;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_6.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_6 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[0].V_m_width, -419.82);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_6;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_6.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[0].V_x_ID, 1857326156);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_7 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[0].V_x_ID, 1857326156);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_7;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_7.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_7 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[0].V_x_ID, 1857326156);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_7;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_7.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[0].V_x_type, 3096200440);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_8 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[0].V_x_type, 3096200440);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_8;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_8.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_8 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[0].V_x_type, 3096200440);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_8;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_8.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[0].V_x_lane, 226);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_9 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[0].V_x_lane, 226);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_9;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_9.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_9 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[0].V_x_lane, 226);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_9;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_9.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[0].V_x_is_valid, 84);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_10 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[0].V_x_is_valid, 84);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_10;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_10.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_10 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[0].V_x_is_valid, 84);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_10;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_10.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[0].V_x_is_usable, 101);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_11 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[0].V_x_is_usable, 101);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_11;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_11.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_11 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[0].V_x_is_usable, 101);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_11;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_11.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[0].V_x_border, 3614120333);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_12 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[0].V_x_border, 3614120333);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_12;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_12.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_12 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[0].V_x_border, 3614120333);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_12;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_12.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[0].V_x_lost, 132);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_13 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[0].V_x_lost, 132);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_13;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_13.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_13 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[0].V_x_lost, 132);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_13;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_13.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[1].V_x_pos.V_m_X, 658.93);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_14 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[1].V_x_pos.V_m_X, 658.93);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_14;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_14.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_14 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[1].V_x_pos.V_m_X, 658.93);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_14;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_14.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[1].V_x_pos.V_m_Y, 932.77);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_15 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[1].V_x_pos.V_m_Y, 932.77);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_15;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_15.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_15 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[1].V_x_pos.V_m_Y, 932.77);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_15;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_15.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[1].V_x_vel.V_m_X, 135.86);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_16 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[1].V_x_vel.V_m_X, 135.86);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_16;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_16.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_16 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[1].V_x_vel.V_m_X, 135.86);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_16;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_16.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[1].V_x_vel.V_m_Y, -431.24);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_17 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[1].V_x_vel.V_m_Y, -431.24);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_17;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_17.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_17 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[1].V_x_vel.V_m_Y, -431.24);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_17;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_17.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[1].V_m_lat_pos_in_lane[0], 588.46);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[1].V_m_lat_pos_in_lane[1], 154.02);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[1].V_m_lat_pos_in_lane[2], 917.87);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[1].V_m_lat_pos_in_lane[3], -319.65);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[1].V_m_lat_pos_in_lane[4], -774.21);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_18 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[1].V_m_lat_pos_in_lane[0], 588.46);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[1].V_m_lat_pos_in_lane[1], 154.02);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[1].V_m_lat_pos_in_lane[2], 917.87);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[1].V_m_lat_pos_in_lane[3], -319.65);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[1].V_m_lat_pos_in_lane[4], -774.21);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_18;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_18.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_18 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[1].V_m_lat_pos_in_lane[0], 588.46);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[1].V_m_lat_pos_in_lane[1], 154.02);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[1].V_m_lat_pos_in_lane[2], 917.87);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[1].V_m_lat_pos_in_lane[3], -319.65);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[1].V_m_lat_pos_in_lane[4], -774.21);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_18;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_18.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[1].V_m_lat_vel_in_lane, 461.56);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_19 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[1].V_m_lat_vel_in_lane, 461.56);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_19;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_19.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_19 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[1].V_m_lat_vel_in_lane, 461.56);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_19;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_19.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[1].V_m_width, 557.31);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_20 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[1].V_m_width, 557.31);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_20;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_20.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_20 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[1].V_m_width, 557.31);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_20;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_20.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[1].V_x_ID, 3885784944);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_21 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[1].V_x_ID, 3885784944);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_21;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_21.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_21 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[1].V_x_ID, 3885784944);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_21;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_21.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[1].V_x_type, 3845617030);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_22 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[1].V_x_type, 3845617030);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_22;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_22.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_22 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[1].V_x_type, 3845617030);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_22;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_22.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[1].V_x_lane, 20);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_23 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[1].V_x_lane, 20);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_23;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_23.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_23 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[1].V_x_lane, 20);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_23;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_23.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[1].V_x_is_valid, 186);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_24 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[1].V_x_is_valid, 186);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_24;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_24.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_24 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[1].V_x_is_valid, 186);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_24;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_24.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[1].V_x_is_usable, 198);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_25 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[1].V_x_is_usable, 198);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_25;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_25.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_25 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[1].V_x_is_usable, 198);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_25;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_25.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[1].V_x_border, 912469609);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_26 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[1].V_x_border, 912469609);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_26;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_26.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_26 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[1].V_x_border, 912469609);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_26;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_26.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[1].V_x_lost, 27);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_27 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[1].V_x_lost, 27);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_27;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_27.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_27 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[1].V_x_lost, 27);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_27;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_27.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[2].V_x_pos.V_m_X, 944.24);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_28 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[2].V_x_pos.V_m_X, 944.24);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_28;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_28.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_28 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[2].V_x_pos.V_m_X, 944.24);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_28;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_28.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[2].V_x_pos.V_m_Y, 3.66);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_29 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[2].V_x_pos.V_m_Y, 3.66);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_29;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_29.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_29 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[2].V_x_pos.V_m_Y, 3.66);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_29;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_29.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[2].V_x_vel.V_m_X, -891.76);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_30 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[2].V_x_vel.V_m_X, -891.76);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_30;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_30.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_30 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[2].V_x_vel.V_m_X, -891.76);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_30;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_30.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[2].V_x_vel.V_m_Y, 588.28);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_31 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[2].V_x_vel.V_m_Y, 588.28);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_31;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_31.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_31 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[2].V_x_vel.V_m_Y, 588.28);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_31;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_31.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[2].V_m_lat_pos_in_lane[0], -841.76);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[2].V_m_lat_pos_in_lane[1], 171.58);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[2].V_m_lat_pos_in_lane[2], -928.12);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[2].V_m_lat_pos_in_lane[3], 248.08);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[2].V_m_lat_pos_in_lane[4], 357.78);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_32 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[2].V_m_lat_pos_in_lane[0], -841.76);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[2].V_m_lat_pos_in_lane[1], 171.58);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[2].V_m_lat_pos_in_lane[2], -928.12);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[2].V_m_lat_pos_in_lane[3], 248.08);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[2].V_m_lat_pos_in_lane[4], 357.78);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_32;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_32.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_32 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[2].V_m_lat_pos_in_lane[0], -841.76);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[2].V_m_lat_pos_in_lane[1], 171.58);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[2].V_m_lat_pos_in_lane[2], -928.12);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[2].V_m_lat_pos_in_lane[3], 248.08);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[2].V_m_lat_pos_in_lane[4], 357.78);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_32;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_32.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[2].V_m_lat_vel_in_lane, -764.4);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_33 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[2].V_m_lat_vel_in_lane, -764.4);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_33;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_33.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_33 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[2].V_m_lat_vel_in_lane, -764.4);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_33;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_33.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[2].V_m_width, -708.85);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_34 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[2].V_m_width, -708.85);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_34;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_34.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_34 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[2].V_m_width, -708.85);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_34;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_34.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[2].V_x_ID, 2454574746);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_35 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[2].V_x_ID, 2454574746);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_35;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_35.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_35 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[2].V_x_ID, 2454574746);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_35;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_35.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[2].V_x_type, 2540483620);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_36 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[2].V_x_type, 2540483620);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_36;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_36.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_36 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[2].V_x_type, 2540483620);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_36;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_36.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[2].V_x_lane, 167);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_37 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[2].V_x_lane, 167);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_37;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_37.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_37 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[2].V_x_lane, 167);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_37;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_37.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[2].V_x_is_valid, 58);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_38 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[2].V_x_is_valid, 58);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_38;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_38.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_38 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[2].V_x_is_valid, 58);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_38;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_38.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[2].V_x_is_usable, 107);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_39 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[2].V_x_is_usable, 107);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_39;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_39.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_39 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[2].V_x_is_usable, 107);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_39;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_39.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[2].V_x_border, 2366690813);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_40 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[2].V_x_border, 2366690813);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_40;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_40.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_40 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[2].V_x_border, 2366690813);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_40;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_40.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[2].V_x_lost, 11);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_41 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[2].V_x_lost, 11);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_41;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_41.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_41 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[2].V_x_lost, 11);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_41;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_41.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[3].V_x_pos.V_m_X, -834.04);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_42 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[3].V_x_pos.V_m_X, -834.04);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_42;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_42.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_42 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[3].V_x_pos.V_m_X, -834.04);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_42;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_42.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[3].V_x_pos.V_m_Y, 312.43);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_43 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[3].V_x_pos.V_m_Y, 312.43);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_43;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_43.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_43 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[3].V_x_pos.V_m_Y, 312.43);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_43;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_43.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[3].V_x_vel.V_m_X, -797.97);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_44 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[3].V_x_vel.V_m_X, -797.97);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_44;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_44.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_44 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[3].V_x_vel.V_m_X, -797.97);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_44;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_44.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[3].V_x_vel.V_m_Y, 678.16);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_45 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[3].V_x_vel.V_m_Y, 678.16);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_45;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_45.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_45 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[3].V_x_vel.V_m_Y, 678.16);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_45;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_45.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[3].V_m_lat_pos_in_lane[0], 439.96);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[3].V_m_lat_pos_in_lane[1], -555.85);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[3].V_m_lat_pos_in_lane[2], 486.87);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[3].V_m_lat_pos_in_lane[3], -740.42);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[3].V_m_lat_pos_in_lane[4], -566.18);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_46 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[3].V_m_lat_pos_in_lane[0], 439.96);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[3].V_m_lat_pos_in_lane[1], -555.85);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[3].V_m_lat_pos_in_lane[2], 486.87);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[3].V_m_lat_pos_in_lane[3], -740.42);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[3].V_m_lat_pos_in_lane[4], -566.18);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_46;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_46.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_46 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[3].V_m_lat_pos_in_lane[0], 439.96);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[3].V_m_lat_pos_in_lane[1], -555.85);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[3].V_m_lat_pos_in_lane[2], 486.87);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[3].V_m_lat_pos_in_lane[3], -740.42);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[3].V_m_lat_pos_in_lane[4], -566.18);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_46;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_46.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[3].V_m_lat_vel_in_lane, -865.74);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_47 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[3].V_m_lat_vel_in_lane, -865.74);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_47;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_47.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_47 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[3].V_m_lat_vel_in_lane, -865.74);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_47;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_47.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[3].V_m_width, 453.19);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_48 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[3].V_m_width, 453.19);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_48;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_48.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_48 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[3].V_m_width, 453.19);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_48;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_48.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[3].V_x_ID, 1429544522);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_49 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[3].V_x_ID, 1429544522);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_49;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_49.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_49 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[3].V_x_ID, 1429544522);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_49;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_49.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[3].V_x_type, 1995831349);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_50 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[3].V_x_type, 1995831349);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_50;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_50.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_50 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[3].V_x_type, 1995831349);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_50;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_50.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[3].V_x_lane, 166);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_51 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[3].V_x_lane, 166);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_51;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_51.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_51 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[3].V_x_lane, 166);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_51;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_51.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[3].V_x_is_valid, 17);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_52 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[3].V_x_is_valid, 17);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_52;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_52.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_52 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[3].V_x_is_valid, 17);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_52;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_52.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[3].V_x_is_usable, 151);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_53 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[3].V_x_is_usable, 151);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_53;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_53.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_53 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[3].V_x_is_usable, 151);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_53;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_53.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[3].V_x_border, 962353550);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_54 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[3].V_x_border, 962353550);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_54;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_54.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_54 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[3].V_x_border, 962353550);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_54;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_54.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[3].V_x_lost, 5);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_55 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[3].V_x_lost, 5);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_55;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_55.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_55 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[3].V_x_lost, 5);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_55;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_55.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[4].V_x_pos.V_m_X, -19.94);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_56 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[4].V_x_pos.V_m_X, -19.94);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_56;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_56.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_56 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[4].V_x_pos.V_m_X, -19.94);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_56;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_56.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[4].V_x_pos.V_m_Y, 936.78);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_57 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[4].V_x_pos.V_m_Y, 936.78);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_57;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_57.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_57 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[4].V_x_pos.V_m_Y, 936.78);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_57;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_57.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[4].V_x_vel.V_m_X, -36.44);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_58 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[4].V_x_vel.V_m_X, -36.44);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_58;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_58.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_58 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[4].V_x_vel.V_m_X, -36.44);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_58;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_58.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[4].V_x_vel.V_m_Y, 12.88);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_59 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[4].V_x_vel.V_m_Y, 12.88);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_59;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_59.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_59 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[4].V_x_vel.V_m_Y, 12.88);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_59;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_59.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[4].V_m_lat_pos_in_lane[0], -156.21);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[4].V_m_lat_pos_in_lane[1], 938.66);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[4].V_m_lat_pos_in_lane[2], 493.12);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[4].V_m_lat_pos_in_lane[3], 817.63);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[4].V_m_lat_pos_in_lane[4], -303.89);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_60 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[4].V_m_lat_pos_in_lane[0], -156.21);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[4].V_m_lat_pos_in_lane[1], 938.66);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[4].V_m_lat_pos_in_lane[2], 493.12);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[4].V_m_lat_pos_in_lane[3], 817.63);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[4].V_m_lat_pos_in_lane[4], -303.89);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_60;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_60.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_60 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[4].V_m_lat_pos_in_lane[0], -156.21);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[4].V_m_lat_pos_in_lane[1], 938.66);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[4].V_m_lat_pos_in_lane[2], 493.12);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[4].V_m_lat_pos_in_lane[3], 817.63);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[4].V_m_lat_pos_in_lane[4], -303.89);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_60;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_60.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[4].V_m_lat_vel_in_lane, -171.55);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_61 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[4].V_m_lat_vel_in_lane, -171.55);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_61;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_61.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_61 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[4].V_m_lat_vel_in_lane, -171.55);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_61;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_61.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[4].V_m_width, -244.2);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_62 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[4].V_m_width, -244.2);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_62;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_62.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_62 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[4].V_m_width, -244.2);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_62;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_62.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[4].V_x_ID, 956511279);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_63 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[4].V_x_ID, 956511279);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_63;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_63.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_63 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[4].V_x_ID, 956511279);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_63;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_63.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[4].V_x_type, 3328173484);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_64 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[4].V_x_type, 3328173484);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_64;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_64.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_64 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[4].V_x_type, 3328173484);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_64;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_64.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[4].V_x_lane, 213);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_65 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[4].V_x_lane, 213);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_65;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_65.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_65 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[4].V_x_lane, 213);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_65;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_65.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[4].V_x_is_valid, 248);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_66 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[4].V_x_is_valid, 248);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_66;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_66.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_66 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[4].V_x_is_valid, 248);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_66;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_66.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[4].V_x_is_usable, 180);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_67 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[4].V_x_is_usable, 180);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_67;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_67.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_67 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[4].V_x_is_usable, 180);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_67;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_67.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[4].V_x_border, 951717690);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_68 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[4].V_x_border, 951717690);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_68;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_68.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_68 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[4].V_x_border, 951717690);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_68;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_68.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[4].V_x_lost, 225);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_69 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[4].V_x_lost, 225);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_69;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_69.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_69 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[4].V_x_lost, 225);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_69;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_69.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[5].V_x_pos.V_m_X, 757.54);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_70 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[5].V_x_pos.V_m_X, 757.54);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_70;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_70.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_70 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[5].V_x_pos.V_m_X, 757.54);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_70;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_70.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[5].V_x_pos.V_m_Y, 438.06);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_71 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[5].V_x_pos.V_m_Y, 438.06);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_71;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_71.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_71 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[5].V_x_pos.V_m_Y, 438.06);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_71;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_71.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[5].V_x_vel.V_m_X, -583.65);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_72 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[5].V_x_vel.V_m_X, -583.65);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_72;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_72.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_72 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[5].V_x_vel.V_m_X, -583.65);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_72;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_72.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[5].V_x_vel.V_m_Y, 595.91);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_73 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[5].V_x_vel.V_m_Y, 595.91);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_73;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_73.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_73 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[5].V_x_vel.V_m_Y, 595.91);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_73;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_73.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[5].V_m_lat_pos_in_lane[0], 558.02);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[5].V_m_lat_pos_in_lane[1], -766.75);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[5].V_m_lat_pos_in_lane[2], -214.09);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[5].V_m_lat_pos_in_lane[3], 261.74);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[5].V_m_lat_pos_in_lane[4], -37.26);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_74 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[5].V_m_lat_pos_in_lane[0], 558.02);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[5].V_m_lat_pos_in_lane[1], -766.75);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[5].V_m_lat_pos_in_lane[2], -214.09);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[5].V_m_lat_pos_in_lane[3], 261.74);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[5].V_m_lat_pos_in_lane[4], -37.26);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_74;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_74.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_74 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[5].V_m_lat_pos_in_lane[0], 558.02);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[5].V_m_lat_pos_in_lane[1], -766.75);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[5].V_m_lat_pos_in_lane[2], -214.09);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[5].V_m_lat_pos_in_lane[3], 261.74);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[5].V_m_lat_pos_in_lane[4], -37.26);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_74;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_74.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[5].V_m_lat_vel_in_lane, 97.71);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_75 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[5].V_m_lat_vel_in_lane, 97.71);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_75;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_75.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_75 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[5].V_m_lat_vel_in_lane, 97.71);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_75;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_75.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[5].V_m_width, -95.6);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_76 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[5].V_m_width, -95.6);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_76;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_76.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_76 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[5].V_m_width, -95.6);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_76;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_76.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[5].V_x_ID, 3571308273);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_77 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[5].V_x_ID, 3571308273);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_77;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_77.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_77 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[5].V_x_ID, 3571308273);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_77;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_77.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[5].V_x_type, 4137685688);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_78 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[5].V_x_type, 4137685688);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_78;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_78.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_78 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[5].V_x_type, 4137685688);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_78;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_78.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[5].V_x_lane, 102);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_79 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[5].V_x_lane, 102);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_79;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_79.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_79 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[5].V_x_lane, 102);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_79;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_79.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[5].V_x_is_valid, 234);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_80 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[5].V_x_is_valid, 234);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_80;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_80.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_80 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[5].V_x_is_valid, 234);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_80;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_80.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[5].V_x_is_usable, 200);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_81 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[5].V_x_is_usable, 200);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_81;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_81.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_81 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[5].V_x_is_usable, 200);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_81;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_81.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[5].V_x_border, 744109249);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_82 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[5].V_x_border, 744109249);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_82;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_82.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_82 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[5].V_x_border, 744109249);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_82;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_82.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[5].V_x_lost, 48);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_83 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[5].V_x_lost, 48);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_83;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_83.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_83 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[5].V_x_lost, 48);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_83;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_83.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[6].V_x_pos.V_m_X, 222.12);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_84 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[6].V_x_pos.V_m_X, 222.12);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_84;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_84.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_84 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[6].V_x_pos.V_m_X, 222.12);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_84;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_84.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[6].V_x_pos.V_m_Y, 271.43);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_85 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[6].V_x_pos.V_m_Y, 271.43);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_85;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_85.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_85 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[6].V_x_pos.V_m_Y, 271.43);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_85;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_85.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[6].V_x_vel.V_m_X, 163.98);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_86 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[6].V_x_vel.V_m_X, 163.98);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_86;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_86.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_86 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[6].V_x_vel.V_m_X, 163.98);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_86;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_86.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[6].V_x_vel.V_m_Y, 74.06);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_87 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[6].V_x_vel.V_m_Y, 74.06);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_87;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_87.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_87 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[6].V_x_vel.V_m_Y, 74.06);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_87;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_87.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[6].V_m_lat_pos_in_lane[0], -182.78);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[6].V_m_lat_pos_in_lane[1], -104.56);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[6].V_m_lat_pos_in_lane[2], 641.42);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[6].V_m_lat_pos_in_lane[3], 467.78);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[6].V_m_lat_pos_in_lane[4], 105.8);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_88 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[6].V_m_lat_pos_in_lane[0], -182.78);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[6].V_m_lat_pos_in_lane[1], -104.56);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[6].V_m_lat_pos_in_lane[2], 641.42);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[6].V_m_lat_pos_in_lane[3], 467.78);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[6].V_m_lat_pos_in_lane[4], 105.8);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_88;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_88.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_88 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[6].V_m_lat_pos_in_lane[0], -182.78);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[6].V_m_lat_pos_in_lane[1], -104.56);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[6].V_m_lat_pos_in_lane[2], 641.42);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[6].V_m_lat_pos_in_lane[3], 467.78);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[6].V_m_lat_pos_in_lane[4], 105.8);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_88;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_88.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[6].V_m_lat_vel_in_lane, 876.6);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_89 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[6].V_m_lat_vel_in_lane, 876.6);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_89;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_89.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_89 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[6].V_m_lat_vel_in_lane, 876.6);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_89;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_89.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[6].V_m_width, -924.41);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_90 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[6].V_m_width, -924.41);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_90;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_90.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_90 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[6].V_m_width, -924.41);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_90;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_90.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[6].V_x_ID, 4060870713);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_91 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[6].V_x_ID, 4060870713);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_91;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_91.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_91 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[6].V_x_ID, 4060870713);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_91;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_91.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[6].V_x_type, 179635450);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_92 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[6].V_x_type, 179635450);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_92;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_92.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_92 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[6].V_x_type, 179635450);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_92;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_92.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[6].V_x_lane, 186);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_93 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[6].V_x_lane, 186);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_93;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_93.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_93 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[6].V_x_lane, 186);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_93;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_93.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[6].V_x_is_valid, 153);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_94 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[6].V_x_is_valid, 153);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_94;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_94.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_94 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[6].V_x_is_valid, 153);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_94;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_94.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[6].V_x_is_usable, 118);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_95 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[6].V_x_is_usable, 118);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_95;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_95.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_95 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[6].V_x_is_usable, 118);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_95;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_95.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[6].V_x_border, 2626332789);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_96 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[6].V_x_border, 2626332789);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_96;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_96.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_96 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[6].V_x_border, 2626332789);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_96;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_96.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[6].V_x_lost, 86);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_97 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[6].V_x_lost, 86);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_97;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_97.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_97 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[6].V_x_lost, 86);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_97;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_97.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[7].V_x_pos.V_m_X, -200.37);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_98 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[7].V_x_pos.V_m_X, -200.37);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_98;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_98.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_98 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[7].V_x_pos.V_m_X, -200.37);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_98;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_98.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[7].V_x_pos.V_m_Y, -444.75);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_99 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[7].V_x_pos.V_m_Y, -444.75);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_99;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_99.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_99 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[7].V_x_pos.V_m_Y, -444.75);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_99;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_99.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[7].V_x_vel.V_m_X, -769.94);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_100 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[7].V_x_vel.V_m_X, -769.94);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_100;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_100.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_100 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[7].V_x_vel.V_m_X, -769.94);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_100;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_100.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[7].V_x_vel.V_m_Y, 366.4);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_101 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[7].V_x_vel.V_m_Y, 366.4);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_101;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_101.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_101 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[7].V_x_vel.V_m_Y, 366.4);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_101;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_101.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[7].V_m_lat_pos_in_lane[0], -800.02);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[7].V_m_lat_pos_in_lane[1], -240.46);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[7].V_m_lat_pos_in_lane[2], -958.83);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[7].V_m_lat_pos_in_lane[3], -823.4);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[7].V_m_lat_pos_in_lane[4], -745.24);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_102 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[7].V_m_lat_pos_in_lane[0], -800.02);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[7].V_m_lat_pos_in_lane[1], -240.46);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[7].V_m_lat_pos_in_lane[2], -958.83);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[7].V_m_lat_pos_in_lane[3], -823.4);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[7].V_m_lat_pos_in_lane[4], -745.24);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_102;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_102.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_102 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[7].V_m_lat_pos_in_lane[0], -800.02);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[7].V_m_lat_pos_in_lane[1], -240.46);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[7].V_m_lat_pos_in_lane[2], -958.83);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[7].V_m_lat_pos_in_lane[3], -823.4);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[7].V_m_lat_pos_in_lane[4], -745.24);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_102;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_102.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[7].V_m_lat_vel_in_lane, -247.31);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_103 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[7].V_m_lat_vel_in_lane, -247.31);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_103;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_103.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_103 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[7].V_m_lat_vel_in_lane, -247.31);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_103;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_103.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[7].V_m_width, 272.94);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_104 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[7].V_m_width, 272.94);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_104;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_104.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_104 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[7].V_m_width, 272.94);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_104;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_104.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[7].V_x_ID, 1264232183);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_105 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[7].V_x_ID, 1264232183);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_105;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_105.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_105 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[7].V_x_ID, 1264232183);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_105;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_105.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[7].V_x_type, 2350941747);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_106 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[7].V_x_type, 2350941747);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_106;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_106.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_106 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[7].V_x_type, 2350941747);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_106;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_106.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[7].V_x_lane, 107);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_107 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[7].V_x_lane, 107);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_107;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_107.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_107 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[7].V_x_lane, 107);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_107;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_107.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[7].V_x_is_valid, 138);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_108 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[7].V_x_is_valid, 138);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_108;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_108.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_108 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[7].V_x_is_valid, 138);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_108;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_108.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[7].V_x_is_usable, 191);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_109 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[7].V_x_is_usable, 191);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_109;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_109.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_109 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[7].V_x_is_usable, 191);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_109;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_109.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[7].V_x_border, 2389781317);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_110 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[7].V_x_border, 2389781317);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_110;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_110.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_110 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[7].V_x_border, 2389781317);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_110;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_110.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[7].V_x_lost, 253);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_111 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[7].V_x_lost, 253);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_111;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_111.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_111 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[7].V_x_lost, 253);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_111;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_111.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[8].V_x_pos.V_m_X, -962.97);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_112 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[8].V_x_pos.V_m_X, -962.97);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_112;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_112.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_112 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[8].V_x_pos.V_m_X, -962.97);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_112;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_112.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[8].V_x_pos.V_m_Y, 840.18);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_113 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[8].V_x_pos.V_m_Y, 840.18);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_113;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_113.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_113 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[8].V_x_pos.V_m_Y, 840.18);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_113;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_113.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[8].V_x_vel.V_m_X, 394.79);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_114 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[8].V_x_vel.V_m_X, 394.79);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_114;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_114.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_114 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[8].V_x_vel.V_m_X, 394.79);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_114;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_114.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[8].V_x_vel.V_m_Y, 758.68);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_115 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[8].V_x_vel.V_m_Y, 758.68);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_115;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_115.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_115 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[8].V_x_vel.V_m_Y, 758.68);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_115;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_115.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[8].V_m_lat_pos_in_lane[0], -976.1);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[8].V_m_lat_pos_in_lane[1], 170.52);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[8].V_m_lat_pos_in_lane[2], 931.11);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[8].V_m_lat_pos_in_lane[3], 154.86);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[8].V_m_lat_pos_in_lane[4], 102.44);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_116 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[8].V_m_lat_pos_in_lane[0], -976.1);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[8].V_m_lat_pos_in_lane[1], 170.52);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[8].V_m_lat_pos_in_lane[2], 931.11);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[8].V_m_lat_pos_in_lane[3], 154.86);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[8].V_m_lat_pos_in_lane[4], 102.44);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_116;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_116.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_116 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[8].V_m_lat_pos_in_lane[0], -976.1);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[8].V_m_lat_pos_in_lane[1], 170.52);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[8].V_m_lat_pos_in_lane[2], 931.11);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[8].V_m_lat_pos_in_lane[3], 154.86);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[8].V_m_lat_pos_in_lane[4], 102.44);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_116;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_116.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[8].V_m_lat_vel_in_lane, 24.23);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_117 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[8].V_m_lat_vel_in_lane, 24.23);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_117;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_117.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_117 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[8].V_m_lat_vel_in_lane, 24.23);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_117;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_117.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[8].V_m_width, -498.74);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_118 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[8].V_m_width, -498.74);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_118;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_118.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_118 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[8].V_m_width, -498.74);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_118;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_118.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[8].V_x_ID, 616197303);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_119 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[8].V_x_ID, 616197303);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_119;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_119.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_119 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[8].V_x_ID, 616197303);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_119;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_119.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[8].V_x_type, 3416708246);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_120 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[8].V_x_type, 3416708246);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_120;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_120.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_120 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[8].V_x_type, 3416708246);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_120;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_120.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[8].V_x_lane, 123);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_121 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[8].V_x_lane, 123);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_121;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_121.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_121 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[8].V_x_lane, 123);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_121;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_121.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[8].V_x_is_valid, 159);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_122 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[8].V_x_is_valid, 159);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_122;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_122.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_122 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[8].V_x_is_valid, 159);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_122;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_122.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[8].V_x_is_usable, 86);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_123 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[8].V_x_is_usable, 86);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_123;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_123.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_123 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[8].V_x_is_usable, 86);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_123;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_123.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[8].V_x_border, 3914652893);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_124 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[8].V_x_border, 3914652893);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_124;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_124.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_124 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[8].V_x_border, 3914652893);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_124;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_124.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[8].V_x_lost, 6);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_125 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[8].V_x_lost, 6);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_125;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_125.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_125 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[8].V_x_lost, 6);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_125;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_125.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[9].V_x_pos.V_m_X, 464.09);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_126 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[9].V_x_pos.V_m_X, 464.09);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_126;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_126.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_126 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[9].V_x_pos.V_m_X, 464.09);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_126;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_126.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[9].V_x_pos.V_m_Y, -470.1);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_127 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[9].V_x_pos.V_m_Y, -470.1);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_127;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_127.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_127 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[9].V_x_pos.V_m_Y, -470.1);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_127;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_127.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[9].V_x_vel.V_m_X, 195.34);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_128 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[9].V_x_vel.V_m_X, 195.34);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_128;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_128.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_128 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[9].V_x_vel.V_m_X, 195.34);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_128;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_128.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[9].V_x_vel.V_m_Y, 242.89);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_129 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[9].V_x_vel.V_m_Y, 242.89);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_129;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_129.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_129 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[9].V_x_vel.V_m_Y, 242.89);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_129;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_129.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[9].V_m_lat_pos_in_lane[0], 266.92);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[9].V_m_lat_pos_in_lane[1], -629.23);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[9].V_m_lat_pos_in_lane[2], 536.54);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[9].V_m_lat_pos_in_lane[3], -328.03);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[9].V_m_lat_pos_in_lane[4], 118.05);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_130 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[9].V_m_lat_pos_in_lane[0], 266.92);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[9].V_m_lat_pos_in_lane[1], -629.23);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[9].V_m_lat_pos_in_lane[2], 536.54);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[9].V_m_lat_pos_in_lane[3], -328.03);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[9].V_m_lat_pos_in_lane[4], 118.05);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_130;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_130.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_130 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[9].V_m_lat_pos_in_lane[0], 266.92);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[9].V_m_lat_pos_in_lane[1], -629.23);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[9].V_m_lat_pos_in_lane[2], 536.54);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[9].V_m_lat_pos_in_lane[3], -328.03);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[9].V_m_lat_pos_in_lane[4], 118.05);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_130;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_130.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[9].V_m_lat_vel_in_lane, 910.82);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_131 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[9].V_m_lat_vel_in_lane, 910.82);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_131;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_131.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_131 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[9].V_m_lat_vel_in_lane, 910.82);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_131;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_131.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[9].V_m_width, 219.18);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_132 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[9].V_m_width, 219.18);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_132;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_132.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_132 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[9].V_m_width, 219.18);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_132;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_132.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[9].V_x_ID, 3346625158);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_133 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[9].V_x_ID, 3346625158);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_133;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_133.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_133 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[9].V_x_ID, 3346625158);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_133;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_133.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[9].V_x_type, 2794176508);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_134 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[9].V_x_type, 2794176508);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_134;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_134.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_134 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[9].V_x_type, 2794176508);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_134;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_134.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[9].V_x_lane, 236);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_135 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[9].V_x_lane, 236);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_135;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_135.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_135 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[9].V_x_lane, 236);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_135;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_135.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[9].V_x_is_valid, 247);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_136 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[9].V_x_is_valid, 247);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_136;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_136.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_136 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[9].V_x_is_valid, 247);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_136;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_136.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[9].V_x_is_usable, 213);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_137 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[9].V_x_is_usable, 213);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_137;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_137.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_137 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[9].V_x_is_usable, 213);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_137;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_137.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[9].V_x_border, 2488490644);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_138 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[9].V_x_border, 2488490644);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_138;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_138.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_138 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[9].V_x_border, 2488490644);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_138;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_138.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[9].V_x_lost, 222);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_139 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[9].V_x_lost, 222);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_139;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_139.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_139 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[9].V_x_lost, 222);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_139;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_139.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[10].V_x_pos.V_m_X, 380.96);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_140 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[10].V_x_pos.V_m_X, 380.96);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_140;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_140.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_140 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[10].V_x_pos.V_m_X, 380.96);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_140;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_140.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[10].V_x_pos.V_m_Y, -730.98);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_141 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[10].V_x_pos.V_m_Y, -730.98);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_141;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_141.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_141 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[10].V_x_pos.V_m_Y, -730.98);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_141;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_141.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[10].V_x_vel.V_m_X, -336.68);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_142 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[10].V_x_vel.V_m_X, -336.68);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_142;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_142.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_142 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[10].V_x_vel.V_m_X, -336.68);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_142;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_142.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[10].V_x_vel.V_m_Y, -483.51);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_143 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[10].V_x_vel.V_m_Y, -483.51);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_143;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_143.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_143 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[10].V_x_vel.V_m_Y, -483.51);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_143;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_143.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[10].V_m_lat_pos_in_lane[0], 146.79);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[10].V_m_lat_pos_in_lane[1], 314.03);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[10].V_m_lat_pos_in_lane[2], -387.78);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[10].V_m_lat_pos_in_lane[3], 107.97);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[10].V_m_lat_pos_in_lane[4], 45.41);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_144 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[10].V_m_lat_pos_in_lane[0], 146.79);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[10].V_m_lat_pos_in_lane[1], 314.03);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[10].V_m_lat_pos_in_lane[2], -387.78);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[10].V_m_lat_pos_in_lane[3], 107.97);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[10].V_m_lat_pos_in_lane[4], 45.41);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_144;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_144.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_144 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[10].V_m_lat_pos_in_lane[0], 146.79);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[10].V_m_lat_pos_in_lane[1], 314.03);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[10].V_m_lat_pos_in_lane[2], -387.78);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[10].V_m_lat_pos_in_lane[3], 107.97);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[10].V_m_lat_pos_in_lane[4], 45.41);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_144;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_144.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[10].V_m_lat_vel_in_lane, 336.17);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_145 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[10].V_m_lat_vel_in_lane, 336.17);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_145;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_145.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_145 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[10].V_m_lat_vel_in_lane, 336.17);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_145;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_145.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[10].V_m_width, 23.22);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_146 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[10].V_m_width, 23.22);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_146;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_146.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_146 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[10].V_m_width, 23.22);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_146;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_146.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[10].V_x_ID, 2242788144);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_147 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[10].V_x_ID, 2242788144);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_147;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_147.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_147 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[10].V_x_ID, 2242788144);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_147;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_147.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[10].V_x_type, 3345176046);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_148 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[10].V_x_type, 3345176046);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_148;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_148.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_148 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[10].V_x_type, 3345176046);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_148;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_148.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[10].V_x_lane, 80);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_149 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[10].V_x_lane, 80);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_149;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_149.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_149 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[10].V_x_lane, 80);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_149;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_149.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[10].V_x_is_valid, 110);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_150 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[10].V_x_is_valid, 110);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_150;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_150.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_150 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[10].V_x_is_valid, 110);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_150;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_150.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[10].V_x_is_usable, 161);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_151 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[10].V_x_is_usable, 161);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_151;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_151.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_151 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[10].V_x_is_usable, 161);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_151;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_151.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[10].V_x_border, 2745778973);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_152 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[10].V_x_border, 2745778973);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_152;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_152.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_152 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[10].V_x_border, 2745778973);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_152;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_152.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[10].V_x_lost, 158);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_153 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[10].V_x_lost, 158);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_153;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_153.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_153 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[10].V_x_lost, 158);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_153;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_153.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[11].V_x_pos.V_m_X, -864.6);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_154 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[11].V_x_pos.V_m_X, -864.6);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_154;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_154.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_154 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[11].V_x_pos.V_m_X, -864.6);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_154;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_154.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[11].V_x_pos.V_m_Y, -410.36);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_155 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[11].V_x_pos.V_m_Y, -410.36);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_155;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_155.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_155 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[11].V_x_pos.V_m_Y, -410.36);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_155;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_155.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[11].V_x_vel.V_m_X, 890.49);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_156 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[11].V_x_vel.V_m_X, 890.49);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_156;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_156.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_156 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[11].V_x_vel.V_m_X, 890.49);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_156;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_156.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[11].V_x_vel.V_m_Y, -100.99);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_157 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[11].V_x_vel.V_m_Y, -100.99);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_157;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_157.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_157 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[11].V_x_vel.V_m_Y, -100.99);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_157;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_157.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[11].V_m_lat_pos_in_lane[0], -407.14);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[11].V_m_lat_pos_in_lane[1], 215.58);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[11].V_m_lat_pos_in_lane[2], -159.76);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[11].V_m_lat_pos_in_lane[3], -309.36);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[11].V_m_lat_pos_in_lane[4], 276.46);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_158 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[11].V_m_lat_pos_in_lane[0], -407.14);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[11].V_m_lat_pos_in_lane[1], 215.58);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[11].V_m_lat_pos_in_lane[2], -159.76);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[11].V_m_lat_pos_in_lane[3], -309.36);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[11].V_m_lat_pos_in_lane[4], 276.46);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_158;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_158.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_158 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[11].V_m_lat_pos_in_lane[0], -407.14);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[11].V_m_lat_pos_in_lane[1], 215.58);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[11].V_m_lat_pos_in_lane[2], -159.76);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[11].V_m_lat_pos_in_lane[3], -309.36);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[11].V_m_lat_pos_in_lane[4], 276.46);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_158;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_158.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[11].V_m_lat_vel_in_lane, -702.12);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_159 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[11].V_m_lat_vel_in_lane, -702.12);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_159;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_159.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_159 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[11].V_m_lat_vel_in_lane, -702.12);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_159;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_159.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[11].V_m_width, -486.63);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_160 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[11].V_m_width, -486.63);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_160;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_160.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_160 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[11].V_m_width, -486.63);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_160;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_160.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[11].V_x_ID, 3163244610);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_161 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[11].V_x_ID, 3163244610);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_161;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_161.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_161 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[11].V_x_ID, 3163244610);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_161;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_161.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[11].V_x_type, 2671690457);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_162 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[11].V_x_type, 2671690457);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_162;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_162.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_162 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[11].V_x_type, 2671690457);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_162;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_162.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[11].V_x_lane, 215);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_163 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[11].V_x_lane, 215);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_163;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_163.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_163 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[11].V_x_lane, 215);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_163;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_163.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[11].V_x_is_valid, 50);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_164 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[11].V_x_is_valid, 50);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_164;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_164.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_164 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[11].V_x_is_valid, 50);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_164;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_164.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[11].V_x_is_usable, 30);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_165 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[11].V_x_is_usable, 30);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_165;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_165.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_165 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[11].V_x_is_usable, 30);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_165;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_165.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[11].V_x_border, 397224172);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_166 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[11].V_x_border, 397224172);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_166;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_166.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_166 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[11].V_x_border, 397224172);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_166;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_166.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[11].V_x_lost, 194);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_167 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[11].V_x_lost, 194);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_167;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_167.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_167 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[11].V_x_lost, 194);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_167;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_167.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[12].V_x_pos.V_m_X, -668.13);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_168 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[12].V_x_pos.V_m_X, -668.13);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_168;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_168.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_168 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[12].V_x_pos.V_m_X, -668.13);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_168;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_168.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[12].V_x_pos.V_m_Y, -74.23);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_169 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[12].V_x_pos.V_m_Y, -74.23);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_169;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_169.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_169 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[12].V_x_pos.V_m_Y, -74.23);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_169;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_169.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[12].V_x_vel.V_m_X, -921.15);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_170 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[12].V_x_vel.V_m_X, -921.15);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_170;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_170.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_170 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[12].V_x_vel.V_m_X, -921.15);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_170;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_170.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[12].V_x_vel.V_m_Y, 44.75);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_171 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[12].V_x_vel.V_m_Y, 44.75);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_171;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_171.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_171 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[12].V_x_vel.V_m_Y, 44.75);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_171;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_171.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[12].V_m_lat_pos_in_lane[0], 287.7);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[12].V_m_lat_pos_in_lane[1], 467.2);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[12].V_m_lat_pos_in_lane[2], -329.95);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[12].V_m_lat_pos_in_lane[3], 614.15);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[12].V_m_lat_pos_in_lane[4], 465.47);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_172 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[12].V_m_lat_pos_in_lane[0], 287.7);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[12].V_m_lat_pos_in_lane[1], 467.2);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[12].V_m_lat_pos_in_lane[2], -329.95);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[12].V_m_lat_pos_in_lane[3], 614.15);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[12].V_m_lat_pos_in_lane[4], 465.47);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_172;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_172.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_172 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[12].V_m_lat_pos_in_lane[0], 287.7);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[12].V_m_lat_pos_in_lane[1], 467.2);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[12].V_m_lat_pos_in_lane[2], -329.95);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[12].V_m_lat_pos_in_lane[3], 614.15);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[12].V_m_lat_pos_in_lane[4], 465.47);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_172;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_172.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[12].V_m_lat_vel_in_lane, 454.11);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_173 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[12].V_m_lat_vel_in_lane, 454.11);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_173;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_173.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_173 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[12].V_m_lat_vel_in_lane, 454.11);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_173;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_173.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[12].V_m_width, -117.37);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_174 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[12].V_m_width, -117.37);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_174;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_174.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_174 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[12].V_m_width, -117.37);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_174;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_174.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[12].V_x_ID, 2753372935);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_175 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[12].V_x_ID, 2753372935);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_175;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_175.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_175 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[12].V_x_ID, 2753372935);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_175;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_175.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[12].V_x_type, 92894772);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_176 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[12].V_x_type, 92894772);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_176;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_176.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_176 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[12].V_x_type, 92894772);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_176;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_176.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[12].V_x_lane, 148);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_177 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[12].V_x_lane, 148);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_177;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_177.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_177 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[12].V_x_lane, 148);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_177;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_177.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[12].V_x_is_valid, 226);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_178 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[12].V_x_is_valid, 226);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_178;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_178.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_178 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[12].V_x_is_valid, 226);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_178;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_178.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[12].V_x_is_usable, 86);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_179 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[12].V_x_is_usable, 86);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_179;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_179.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_179 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[12].V_x_is_usable, 86);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_179;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_179.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[12].V_x_border, 2161052033);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_180 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[12].V_x_border, 2161052033);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_180;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_180.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_180 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[12].V_x_border, 2161052033);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_180;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_180.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[12].V_x_lost, 249);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_181 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[12].V_x_lost, 249);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_181;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_181.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_181 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[12].V_x_lost, 249);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_181;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_181.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[13].V_x_pos.V_m_X, -436.07);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_182 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[13].V_x_pos.V_m_X, -436.07);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_182;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_182.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_182 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[13].V_x_pos.V_m_X, -436.07);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_182;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_182.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[13].V_x_pos.V_m_Y, 376.92);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_183 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[13].V_x_pos.V_m_Y, 376.92);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_183;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_183.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_183 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[13].V_x_pos.V_m_Y, 376.92);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_183;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_183.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[13].V_x_vel.V_m_X, -535.05);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_184 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[13].V_x_vel.V_m_X, -535.05);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_184;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_184.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_184 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[13].V_x_vel.V_m_X, -535.05);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_184;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_184.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[13].V_x_vel.V_m_Y, -522.86);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_185 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[13].V_x_vel.V_m_Y, -522.86);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_185;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_185.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_185 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[13].V_x_vel.V_m_Y, -522.86);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_185;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_185.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[13].V_m_lat_pos_in_lane[0], -37.97);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[13].V_m_lat_pos_in_lane[1], -929.53);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[13].V_m_lat_pos_in_lane[2], 718.53);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[13].V_m_lat_pos_in_lane[3], -874.74);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[13].V_m_lat_pos_in_lane[4], -587.29);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_186 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[13].V_m_lat_pos_in_lane[0], -37.97);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[13].V_m_lat_pos_in_lane[1], -929.53);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[13].V_m_lat_pos_in_lane[2], 718.53);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[13].V_m_lat_pos_in_lane[3], -874.74);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[13].V_m_lat_pos_in_lane[4], -587.29);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_186;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_186.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_186 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[13].V_m_lat_pos_in_lane[0], -37.97);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[13].V_m_lat_pos_in_lane[1], -929.53);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[13].V_m_lat_pos_in_lane[2], 718.53);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[13].V_m_lat_pos_in_lane[3], -874.74);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[13].V_m_lat_pos_in_lane[4], -587.29);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_186;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_186.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[13].V_m_lat_vel_in_lane, 128.3);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_187 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[13].V_m_lat_vel_in_lane, 128.3);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_187;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_187.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_187 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[13].V_m_lat_vel_in_lane, 128.3);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_187;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_187.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[13].V_m_width, 536.83);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_188 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[13].V_m_width, 536.83);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_188;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_188.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_188 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[13].V_m_width, 536.83);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_188;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_188.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[13].V_x_ID, 2407183420);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_189 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[13].V_x_ID, 2407183420);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_189;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_189.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_189 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[13].V_x_ID, 2407183420);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_189;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_189.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[13].V_x_type, 1053559200);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_190 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[13].V_x_type, 1053559200);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_190;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_190.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_190 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[13].V_x_type, 1053559200);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_190;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_190.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[13].V_x_lane, 245);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_191 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[13].V_x_lane, 245);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_191;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_191.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_191 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[13].V_x_lane, 245);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_191;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_191.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[13].V_x_is_valid, 49);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_192 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[13].V_x_is_valid, 49);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_192;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_192.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_192 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[13].V_x_is_valid, 49);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_192;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_192.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[13].V_x_is_usable, 54);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_193 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[13].V_x_is_usable, 54);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_193;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_193.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_193 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[13].V_x_is_usable, 54);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_193;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_193.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[13].V_x_border, 1629266713);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_194 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[13].V_x_border, 1629266713);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_194;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_194.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_194 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[13].V_x_border, 1629266713);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_194;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_194.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[13].V_x_lost, 30);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_195 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[13].V_x_lost, 30);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_195;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_195.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_195 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[13].V_x_lost, 30);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_195;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_195.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[14].V_x_pos.V_m_X, -887.24);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_196 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[14].V_x_pos.V_m_X, -887.24);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_196;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_196.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_196 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[14].V_x_pos.V_m_X, -887.24);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_196;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_196.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[14].V_x_pos.V_m_Y, 901.41);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_197 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[14].V_x_pos.V_m_Y, 901.41);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_197;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_197.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_197 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[14].V_x_pos.V_m_Y, 901.41);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_197;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_197.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[14].V_x_vel.V_m_X, -734.15);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_198 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[14].V_x_vel.V_m_X, -734.15);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_198;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_198.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_198 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[14].V_x_vel.V_m_X, -734.15);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_198;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_198.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[14].V_x_vel.V_m_Y, 666.44);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_199 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[14].V_x_vel.V_m_Y, 666.44);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_199;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_199.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_199 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[14].V_x_vel.V_m_Y, 666.44);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_199;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_199.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[14].V_m_lat_pos_in_lane[0], -104.02);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[14].V_m_lat_pos_in_lane[1], 959.49);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[14].V_m_lat_pos_in_lane[2], 675.36);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[14].V_m_lat_pos_in_lane[3], 585.3);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[14].V_m_lat_pos_in_lane[4], 536.25);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_200 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[14].V_m_lat_pos_in_lane[0], -104.02);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[14].V_m_lat_pos_in_lane[1], 959.49);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[14].V_m_lat_pos_in_lane[2], 675.36);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[14].V_m_lat_pos_in_lane[3], 585.3);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[14].V_m_lat_pos_in_lane[4], 536.25);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_200;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_200.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_200 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[14].V_m_lat_pos_in_lane[0], -104.02);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[14].V_m_lat_pos_in_lane[1], 959.49);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[14].V_m_lat_pos_in_lane[2], 675.36);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[14].V_m_lat_pos_in_lane[3], 585.3);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[14].V_m_lat_pos_in_lane[4], 536.25);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_200;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_200.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[14].V_m_lat_vel_in_lane, -417.63);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_201 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[14].V_m_lat_vel_in_lane, -417.63);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_201;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_201.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_201 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[14].V_m_lat_vel_in_lane, -417.63);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_201;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_201.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[14].V_m_width, 627.8);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_202 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[14].V_m_width, 627.8);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_202;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_202.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_202 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[14].V_m_width, 627.8);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_202;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_202.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[14].V_x_ID, 636538282);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_203 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[14].V_x_ID, 636538282);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_203;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_203.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_203 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[14].V_x_ID, 636538282);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_203;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_203.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[14].V_x_type, 2019266396);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_204 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[14].V_x_type, 2019266396);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_204;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_204.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_204 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[14].V_x_type, 2019266396);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_204;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_204.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[14].V_x_lane, 201);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_205 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[14].V_x_lane, 201);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_205;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_205.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_205 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[14].V_x_lane, 201);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_205;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_205.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[14].V_x_is_valid, 81);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_206 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[14].V_x_is_valid, 81);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_206;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_206.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_206 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[14].V_x_is_valid, 81);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_206;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_206.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[14].V_x_is_usable, 5);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_207 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[14].V_x_is_usable, 5);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_207;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_207.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_207 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[14].V_x_is_usable, 5);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_207;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_207.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[14].V_x_border, 2566145940);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_208 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[14].V_x_border, 2566145940);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_208;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_208.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_208 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[14].V_x_border, 2566145940);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_208;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_208.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[14].V_x_lost, 139);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_209 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[14].V_x_lost, 139);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_209;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_209.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_209 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[14].V_x_lost, 139);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_209;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_209.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[15].V_x_pos.V_m_X, -35.6);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_210 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[15].V_x_pos.V_m_X, -35.6);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_210;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_210.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_210 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[15].V_x_pos.V_m_X, -35.6);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_210;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_210.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[15].V_x_pos.V_m_Y, 433.72);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_211 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[15].V_x_pos.V_m_Y, 433.72);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_211;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_211.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_211 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[15].V_x_pos.V_m_Y, 433.72);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_211;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_211.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[15].V_x_vel.V_m_X, -437.17);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_212 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[15].V_x_vel.V_m_X, -437.17);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_212;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_212.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_212 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[15].V_x_vel.V_m_X, -437.17);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_212;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_212.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[15].V_x_vel.V_m_Y, 922.6);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_213 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[15].V_x_vel.V_m_Y, 922.6);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_213;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_213.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_213 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[15].V_x_vel.V_m_Y, 922.6);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_213;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_213.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[15].V_m_lat_pos_in_lane[0], 92.07);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[15].V_m_lat_pos_in_lane[1], 589.83);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[15].V_m_lat_pos_in_lane[2], -757.53);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[15].V_m_lat_pos_in_lane[3], 515.2);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[15].V_m_lat_pos_in_lane[4], 987.33);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_214 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[15].V_m_lat_pos_in_lane[0], 92.07);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[15].V_m_lat_pos_in_lane[1], 589.83);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[15].V_m_lat_pos_in_lane[2], -757.53);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[15].V_m_lat_pos_in_lane[3], 515.2);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[15].V_m_lat_pos_in_lane[4], 987.33);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_214;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_214.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_214 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[15].V_m_lat_pos_in_lane[0], 92.07);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[15].V_m_lat_pos_in_lane[1], 589.83);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[15].V_m_lat_pos_in_lane[2], -757.53);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[15].V_m_lat_pos_in_lane[3], 515.2);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[15].V_m_lat_pos_in_lane[4], 987.33);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_214;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_214.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[15].V_m_lat_vel_in_lane, 500.46);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_215 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[15].V_m_lat_vel_in_lane, 500.46);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_215;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_215.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_215 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[15].V_m_lat_vel_in_lane, 500.46);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_215;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_215.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[15].V_m_width, 755.81);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_216 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[15].V_m_width, 755.81);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_216;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_216.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_216 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[15].V_m_width, 755.81);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_216;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_216.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[15].V_x_ID, 954802159);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_217 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[15].V_x_ID, 954802159);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_217;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_217.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_217 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[15].V_x_ID, 954802159);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_217;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_217.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[15].V_x_type, 1032340673);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_218 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[15].V_x_type, 1032340673);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_218;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_218.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_218 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[15].V_x_type, 1032340673);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_218;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_218.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[15].V_x_lane, 190);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_219 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[15].V_x_lane, 190);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_219;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_219.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_219 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[15].V_x_lane, 190);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_219;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_219.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[15].V_x_is_valid, 62);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_220 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[15].V_x_is_valid, 62);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_220;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_220.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_220 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[15].V_x_is_valid, 62);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_220;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_220.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[15].V_x_is_usable, 37);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_221 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[15].V_x_is_usable, 37);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_221;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_221.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_221 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[15].V_x_is_usable, 37);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_221;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_221.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[15].V_x_border, 3080829034);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_222 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[15].V_x_border, 3080829034);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_222;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_222.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_222 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[15].V_x_border, 3080829034);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_222;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_222.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[15].V_x_lost, 206);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_223 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[15].V_x_lost, 206);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_223;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_223.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_223 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[15].V_x_lost, 206);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_223;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_223.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[16].V_x_pos.V_m_X, 200.6);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_224 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[16].V_x_pos.V_m_X, 200.6);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_224;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_224.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_224 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[16].V_x_pos.V_m_X, 200.6);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_224;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_224.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[16].V_x_pos.V_m_Y, 748.84);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_225 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[16].V_x_pos.V_m_Y, 748.84);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_225;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_225.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_225 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[16].V_x_pos.V_m_Y, 748.84);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_225;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_225.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[16].V_x_vel.V_m_X, 42.06);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_226 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[16].V_x_vel.V_m_X, 42.06);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_226;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_226.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_226 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[16].V_x_vel.V_m_X, 42.06);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_226;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_226.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[16].V_x_vel.V_m_Y, -959.98);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_227 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[16].V_x_vel.V_m_Y, -959.98);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_227;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_227.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_227 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[16].V_x_vel.V_m_Y, -959.98);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_227;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_227.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[16].V_m_lat_pos_in_lane[0], 182.69);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[16].V_m_lat_pos_in_lane[1], -190.14);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[16].V_m_lat_pos_in_lane[2], -892.28);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[16].V_m_lat_pos_in_lane[3], 261.92);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[16].V_m_lat_pos_in_lane[4], -146.77);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_228 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[16].V_m_lat_pos_in_lane[0], 182.69);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[16].V_m_lat_pos_in_lane[1], -190.14);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[16].V_m_lat_pos_in_lane[2], -892.28);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[16].V_m_lat_pos_in_lane[3], 261.92);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[16].V_m_lat_pos_in_lane[4], -146.77);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_228;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_228.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_228 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[16].V_m_lat_pos_in_lane[0], 182.69);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[16].V_m_lat_pos_in_lane[1], -190.14);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[16].V_m_lat_pos_in_lane[2], -892.28);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[16].V_m_lat_pos_in_lane[3], 261.92);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[16].V_m_lat_pos_in_lane[4], -146.77);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_228;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_228.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[16].V_m_lat_vel_in_lane, 919.81);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_229 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[16].V_m_lat_vel_in_lane, 919.81);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_229;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_229.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_229 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[16].V_m_lat_vel_in_lane, 919.81);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_229;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_229.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[16].V_m_width, 720.66);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_230 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[16].V_m_width, 720.66);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_230;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_230.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_230 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[16].V_m_width, 720.66);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_230;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_230.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[16].V_x_ID, 165360705);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_231 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[16].V_x_ID, 165360705);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_231;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_231.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_231 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[16].V_x_ID, 165360705);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_231;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_231.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[16].V_x_type, 1318372473);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_232 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[16].V_x_type, 1318372473);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_232;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_232.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_232 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[16].V_x_type, 1318372473);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_232;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_232.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[16].V_x_lane, 127);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_233 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[16].V_x_lane, 127);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_233;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_233.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_233 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[16].V_x_lane, 127);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_233;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_233.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[16].V_x_is_valid, 60);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_234 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[16].V_x_is_valid, 60);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_234;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_234.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_234 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[16].V_x_is_valid, 60);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_234;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_234.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[16].V_x_is_usable, 102);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_235 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[16].V_x_is_usable, 102);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_235;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_235.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_235 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[16].V_x_is_usable, 102);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_235;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_235.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[16].V_x_border, 1505074386);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_236 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[16].V_x_border, 1505074386);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_236;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_236.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_236 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[16].V_x_border, 1505074386);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_236;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_236.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[16].V_x_lost, 191);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_237 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[16].V_x_lost, 191);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_237;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_237.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_237 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[16].V_x_lost, 191);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_237;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_237.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[17].V_x_pos.V_m_X, 19.23);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_238 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[17].V_x_pos.V_m_X, 19.23);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_238;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_238.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_238 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[17].V_x_pos.V_m_X, 19.23);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_238;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_238.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[17].V_x_pos.V_m_Y, 410.67);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_239 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[17].V_x_pos.V_m_Y, 410.67);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_239;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_239.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_239 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[17].V_x_pos.V_m_Y, 410.67);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_239;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_239.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[17].V_x_vel.V_m_X, 271.47);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_240 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[17].V_x_vel.V_m_X, 271.47);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_240;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_240.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_240 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[17].V_x_vel.V_m_X, 271.47);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_240;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_240.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[17].V_x_vel.V_m_Y, 614.66);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_241 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[17].V_x_vel.V_m_Y, 614.66);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_241;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_241.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_241 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[17].V_x_vel.V_m_Y, 614.66);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_241;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_241.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[17].V_m_lat_pos_in_lane[0], -637.87);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[17].V_m_lat_pos_in_lane[1], -689.75);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[17].V_m_lat_pos_in_lane[2], -900.1);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[17].V_m_lat_pos_in_lane[3], -839.93);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[17].V_m_lat_pos_in_lane[4], -590.77);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_242 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[17].V_m_lat_pos_in_lane[0], -637.87);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[17].V_m_lat_pos_in_lane[1], -689.75);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[17].V_m_lat_pos_in_lane[2], -900.1);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[17].V_m_lat_pos_in_lane[3], -839.93);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[17].V_m_lat_pos_in_lane[4], -590.77);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_242;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_242.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_242 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[17].V_m_lat_pos_in_lane[0], -637.87);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[17].V_m_lat_pos_in_lane[1], -689.75);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[17].V_m_lat_pos_in_lane[2], -900.1);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[17].V_m_lat_pos_in_lane[3], -839.93);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[17].V_m_lat_pos_in_lane[4], -590.77);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_242;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_242.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[17].V_m_lat_vel_in_lane, -1.46);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_243 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[17].V_m_lat_vel_in_lane, -1.46);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_243;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_243.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_243 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[17].V_m_lat_vel_in_lane, -1.46);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_243;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_243.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[17].V_m_width, 62.82);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_244 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[17].V_m_width, 62.82);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_244;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_244.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_244 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[17].V_m_width, 62.82);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_244;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_244.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[17].V_x_ID, 426553807);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_245 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[17].V_x_ID, 426553807);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_245;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_245.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_245 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[17].V_x_ID, 426553807);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_245;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_245.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[17].V_x_type, 3008773065);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_246 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[17].V_x_type, 3008773065);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_246;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_246.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_246 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[17].V_x_type, 3008773065);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_246;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_246.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[17].V_x_lane, 234);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_247 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[17].V_x_lane, 234);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_247;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_247.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_247 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[17].V_x_lane, 234);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_247;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_247.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[17].V_x_is_valid, 138);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_248 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[17].V_x_is_valid, 138);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_248;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_248.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_248 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[17].V_x_is_valid, 138);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_248;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_248.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[17].V_x_is_usable, 239);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_249 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[17].V_x_is_usable, 239);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_249;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_249.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_249 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[17].V_x_is_usable, 239);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_249;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_249.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[17].V_x_border, 3122832192);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_250 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[17].V_x_border, 3122832192);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_250;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_250.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_250 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[17].V_x_border, 3122832192);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_250;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_250.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[17].V_x_lost, 178);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_251 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[17].V_x_lost, 178);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_251;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_251.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_251 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[17].V_x_lost, 178);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_251;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_251.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[18].V_x_pos.V_m_X, -925.73);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_252 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[18].V_x_pos.V_m_X, -925.73);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_252;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_252.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_252 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[18].V_x_pos.V_m_X, -925.73);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_252;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_252.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[18].V_x_pos.V_m_Y, -928.05);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_253 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[18].V_x_pos.V_m_Y, -928.05);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_253;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_253.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_253 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[18].V_x_pos.V_m_Y, -928.05);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_253;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_253.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[18].V_x_vel.V_m_X, 780.69);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_254 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[18].V_x_vel.V_m_X, 780.69);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_254;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_254.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_254 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[18].V_x_vel.V_m_X, 780.69);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_254;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_254.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[18].V_x_vel.V_m_Y, 746.52);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_255 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[18].V_x_vel.V_m_Y, 746.52);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_255;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_255.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_255 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[18].V_x_vel.V_m_Y, 746.52);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_255;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_255.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[18].V_m_lat_pos_in_lane[0], -697.1);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[18].V_m_lat_pos_in_lane[1], 913.38);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[18].V_m_lat_pos_in_lane[2], 58.83);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[18].V_m_lat_pos_in_lane[3], -686.95);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[18].V_m_lat_pos_in_lane[4], 625.41);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_256 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[18].V_m_lat_pos_in_lane[0], -697.1);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[18].V_m_lat_pos_in_lane[1], 913.38);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[18].V_m_lat_pos_in_lane[2], 58.83);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[18].V_m_lat_pos_in_lane[3], -686.95);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[18].V_m_lat_pos_in_lane[4], 625.41);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_256;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_256.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_256 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[18].V_m_lat_pos_in_lane[0], -697.1);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[18].V_m_lat_pos_in_lane[1], 913.38);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[18].V_m_lat_pos_in_lane[2], 58.83);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[18].V_m_lat_pos_in_lane[3], -686.95);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[18].V_m_lat_pos_in_lane[4], 625.41);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_256;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_256.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[18].V_m_lat_vel_in_lane, 787.7);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_257 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[18].V_m_lat_vel_in_lane, 787.7);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_257;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_257.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_257 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[18].V_m_lat_vel_in_lane, 787.7);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_257;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_257.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[18].V_m_width, 650.32);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_258 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[18].V_m_width, 650.32);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_258;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_258.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_258 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[18].V_m_width, 650.32);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_258;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_258.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[18].V_x_ID, 1582760361);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_259 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[18].V_x_ID, 1582760361);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_259;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_259.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_259 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[18].V_x_ID, 1582760361);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_259;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_259.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[18].V_x_type, 1369629486);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_260 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[18].V_x_type, 1369629486);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_260;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_260.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_260 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[18].V_x_type, 1369629486);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_260;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_260.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[18].V_x_lane, 108);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_261 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[18].V_x_lane, 108);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_261;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_261.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_261 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[18].V_x_lane, 108);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_261;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_261.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[18].V_x_is_valid, 28);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_262 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[18].V_x_is_valid, 28);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_262;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_262.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_262 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[18].V_x_is_valid, 28);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_262;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_262.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[18].V_x_is_usable, 213);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_263 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[18].V_x_is_usable, 213);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_263;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_263.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_263 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[18].V_x_is_usable, 213);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_263;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_263.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[18].V_x_border, 622614253);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_264 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[18].V_x_border, 622614253);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_264;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_264.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_264 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[18].V_x_border, 622614253);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_264;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_264.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[18].V_x_lost, 205);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_265 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[18].V_x_lost, 205);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_265;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_265.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_265 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[18].V_x_lost, 205);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_265;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_265.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[19].V_x_pos.V_m_X, 408.15);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_266 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[19].V_x_pos.V_m_X, 408.15);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_266;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_266.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_266 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[19].V_x_pos.V_m_X, 408.15);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_266;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_266.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[19].V_x_pos.V_m_Y, 643.28);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_267 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[19].V_x_pos.V_m_Y, 643.28);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_267;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_267.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_267 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[19].V_x_pos.V_m_Y, 643.28);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_267;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_267.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[19].V_x_vel.V_m_X, -727.67);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_268 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[19].V_x_vel.V_m_X, -727.67);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_268;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_268.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_268 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[19].V_x_vel.V_m_X, -727.67);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_268;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_268.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[19].V_x_vel.V_m_Y, -790.08);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_269 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[19].V_x_vel.V_m_Y, -790.08);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_269;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_269.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_269 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[19].V_x_vel.V_m_Y, -790.08);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_269;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_269.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[19].V_m_lat_pos_in_lane[0], 745.52);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[19].V_m_lat_pos_in_lane[1], -290.08);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[19].V_m_lat_pos_in_lane[2], -2.19);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[19].V_m_lat_pos_in_lane[3], -106.41);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[19].V_m_lat_pos_in_lane[4], 934.04);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_270 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[19].V_m_lat_pos_in_lane[0], 745.52);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[19].V_m_lat_pos_in_lane[1], -290.08);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[19].V_m_lat_pos_in_lane[2], -2.19);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[19].V_m_lat_pos_in_lane[3], -106.41);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[19].V_m_lat_pos_in_lane[4], 934.04);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_270;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_270.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_270 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[19].V_m_lat_pos_in_lane[0], 745.52);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[19].V_m_lat_pos_in_lane[1], -290.08);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[19].V_m_lat_pos_in_lane[2], -2.19);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[19].V_m_lat_pos_in_lane[3], -106.41);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[19].V_m_lat_pos_in_lane[4], 934.04);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_270;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_270.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[19].V_m_lat_vel_in_lane, -987.01);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_271 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[19].V_m_lat_vel_in_lane, -987.01);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_271;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_271.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_271 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[19].V_m_lat_vel_in_lane, -987.01);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_271;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_271.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[19].V_m_width, 703.31);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_272 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[19].V_m_width, 703.31);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_272;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_272.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_272 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[19].V_m_width, 703.31);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_272;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_272.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[19].V_x_ID, 1399037278);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_273 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[19].V_x_ID, 1399037278);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_273;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_273.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_273 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[19].V_x_ID, 1399037278);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_273;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_273.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[19].V_x_type, 3878765029);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_274 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[19].V_x_type, 3878765029);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_274;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_274.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_274 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[19].V_x_type, 3878765029);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_274;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_274.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[19].V_x_lane, 160);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_275 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[19].V_x_lane, 160);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_275;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_275.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_275 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[19].V_x_lane, 160);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_275;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_275.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[19].V_x_is_valid, 111);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_276 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[19].V_x_is_valid, 111);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_276;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_276.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_276 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[19].V_x_is_valid, 111);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_276;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_276.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[19].V_x_is_usable, 182);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_277 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[19].V_x_is_usable, 182);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_277;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_277.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_277 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[19].V_x_is_usable, 182);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_277;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_277.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[19].V_x_border, 2023711562);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_278 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[19].V_x_border, 2023711562);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_278;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_278.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_278 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[19].V_x_border, 2023711562);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_278;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_278.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_left_t.V_x_surround_obj_left[19].V_x_lost, 79);
    struct _func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_279 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[19].V_x_lost, 79);
        }
    } func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_279;
    func_V_x_surround_obj_left_t_AutoLCPossibilityJdg_279.verify();
    struct _func_V_x_surround_obj_left_t_ObjectSelectionDM_279 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_left_t tmp_surround_obj_left_t;
            Rte_Read_V_x_surround_obj_left_t_V_x_surround_obj_left_t(&tmp_surround_obj_left_t);
            EXPECT_EQ(tmp_surround_obj_left_t.V_x_surround_obj_left[19].V_x_lost, 79);
        }
    } func_V_x_surround_obj_left_t_ObjectSelectionDM_279;
    func_V_x_surround_obj_left_t_ObjectSelectionDM_279.verify();

    /* V_x_surround_obj_rearcenter_t */
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_rearcenter_t.V_x_surround_obj_rearcenter[0].V_x_pos.V_m_X, 384.48);
    struct _func_V_x_surround_obj_rearcenter_t_AutoLCPossibilityJdg_0 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_rearcenter_t tmp_surround_obj_rearcenter_t;
            Rte_Read_V_x_surround_obj_rearcenter_t_V_x_surround_obj_rearcenter_t(&tmp_surround_obj_rearcenter_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_rearcenter_t.V_x_surround_obj_rearcenter[0].V_x_pos.V_m_X, 384.48);
        }
    } func_V_x_surround_obj_rearcenter_t_AutoLCPossibilityJdg_0;
    func_V_x_surround_obj_rearcenter_t_AutoLCPossibilityJdg_0.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_rearcenter_t.V_x_surround_obj_rearcenter[0].V_x_pos.V_m_Y, 817.13);
    struct _func_V_x_surround_obj_rearcenter_t_AutoLCPossibilityJdg_1 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_rearcenter_t tmp_surround_obj_rearcenter_t;
            Rte_Read_V_x_surround_obj_rearcenter_t_V_x_surround_obj_rearcenter_t(&tmp_surround_obj_rearcenter_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_rearcenter_t.V_x_surround_obj_rearcenter[0].V_x_pos.V_m_Y, 817.13);
        }
    } func_V_x_surround_obj_rearcenter_t_AutoLCPossibilityJdg_1;
    func_V_x_surround_obj_rearcenter_t_AutoLCPossibilityJdg_1.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_rearcenter_t.V_x_surround_obj_rearcenter[0].V_x_vel.V_m_X, -916.12);
    struct _func_V_x_surround_obj_rearcenter_t_AutoLCPossibilityJdg_2 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_rearcenter_t tmp_surround_obj_rearcenter_t;
            Rte_Read_V_x_surround_obj_rearcenter_t_V_x_surround_obj_rearcenter_t(&tmp_surround_obj_rearcenter_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_rearcenter_t.V_x_surround_obj_rearcenter[0].V_x_vel.V_m_X, -916.12);
        }
    } func_V_x_surround_obj_rearcenter_t_AutoLCPossibilityJdg_2;
    func_V_x_surround_obj_rearcenter_t_AutoLCPossibilityJdg_2.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_rearcenter_t.V_x_surround_obj_rearcenter[0].V_x_vel.V_m_Y, 440.16);
    struct _func_V_x_surround_obj_rearcenter_t_AutoLCPossibilityJdg_3 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_rearcenter_t tmp_surround_obj_rearcenter_t;
            Rte_Read_V_x_surround_obj_rearcenter_t_V_x_surround_obj_rearcenter_t(&tmp_surround_obj_rearcenter_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_rearcenter_t.V_x_surround_obj_rearcenter[0].V_x_vel.V_m_Y, 440.16);
        }
    } func_V_x_surround_obj_rearcenter_t_AutoLCPossibilityJdg_3;
    func_V_x_surround_obj_rearcenter_t_AutoLCPossibilityJdg_3.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_rearcenter_t.V_x_surround_obj_rearcenter[0].V_m_lat_pos_in_lane[0], 568.7);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_rearcenter_t.V_x_surround_obj_rearcenter[0].V_m_lat_pos_in_lane[1], -171.96);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_rearcenter_t.V_x_surround_obj_rearcenter[0].V_m_lat_pos_in_lane[2], 399.18);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_rearcenter_t.V_x_surround_obj_rearcenter[0].V_m_lat_pos_in_lane[3], 428.63);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_rearcenter_t.V_x_surround_obj_rearcenter[0].V_m_lat_pos_in_lane[4], -736.47);
    struct _func_V_x_surround_obj_rearcenter_t_AutoLCPossibilityJdg_4 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_rearcenter_t tmp_surround_obj_rearcenter_t;
            Rte_Read_V_x_surround_obj_rearcenter_t_V_x_surround_obj_rearcenter_t(&tmp_surround_obj_rearcenter_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_rearcenter_t.V_x_surround_obj_rearcenter[0].V_m_lat_pos_in_lane[0], 568.7);
            EXPECT_FLOAT_EQ(tmp_surround_obj_rearcenter_t.V_x_surround_obj_rearcenter[0].V_m_lat_pos_in_lane[1], -171.96);
            EXPECT_FLOAT_EQ(tmp_surround_obj_rearcenter_t.V_x_surround_obj_rearcenter[0].V_m_lat_pos_in_lane[2], 399.18);
            EXPECT_FLOAT_EQ(tmp_surround_obj_rearcenter_t.V_x_surround_obj_rearcenter[0].V_m_lat_pos_in_lane[3], 428.63);
            EXPECT_FLOAT_EQ(tmp_surround_obj_rearcenter_t.V_x_surround_obj_rearcenter[0].V_m_lat_pos_in_lane[4], -736.47);
        }
    } func_V_x_surround_obj_rearcenter_t_AutoLCPossibilityJdg_4;
    func_V_x_surround_obj_rearcenter_t_AutoLCPossibilityJdg_4.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_rearcenter_t.V_x_surround_obj_rearcenter[0].V_m_lat_vel_in_lane, -942.59);
    struct _func_V_x_surround_obj_rearcenter_t_AutoLCPossibilityJdg_5 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_rearcenter_t tmp_surround_obj_rearcenter_t;
            Rte_Read_V_x_surround_obj_rearcenter_t_V_x_surround_obj_rearcenter_t(&tmp_surround_obj_rearcenter_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_rearcenter_t.V_x_surround_obj_rearcenter[0].V_m_lat_vel_in_lane, -942.59);
        }
    } func_V_x_surround_obj_rearcenter_t_AutoLCPossibilityJdg_5;
    func_V_x_surround_obj_rearcenter_t_AutoLCPossibilityJdg_5.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_rearcenter_t.V_x_surround_obj_rearcenter[0].V_m_width, 457.88);
    struct _func_V_x_surround_obj_rearcenter_t_AutoLCPossibilityJdg_6 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_rearcenter_t tmp_surround_obj_rearcenter_t;
            Rte_Read_V_x_surround_obj_rearcenter_t_V_x_surround_obj_rearcenter_t(&tmp_surround_obj_rearcenter_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_rearcenter_t.V_x_surround_obj_rearcenter[0].V_m_width, 457.88);
        }
    } func_V_x_surround_obj_rearcenter_t_AutoLCPossibilityJdg_6;
    func_V_x_surround_obj_rearcenter_t_AutoLCPossibilityJdg_6.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_rearcenter_t.V_x_surround_obj_rearcenter[0].V_x_ID, 476725424);
    struct _func_V_x_surround_obj_rearcenter_t_AutoLCPossibilityJdg_7 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_rearcenter_t tmp_surround_obj_rearcenter_t;
            Rte_Read_V_x_surround_obj_rearcenter_t_V_x_surround_obj_rearcenter_t(&tmp_surround_obj_rearcenter_t);
            EXPECT_EQ(tmp_surround_obj_rearcenter_t.V_x_surround_obj_rearcenter[0].V_x_ID, 476725424);
        }
    } func_V_x_surround_obj_rearcenter_t_AutoLCPossibilityJdg_7;
    func_V_x_surround_obj_rearcenter_t_AutoLCPossibilityJdg_7.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_rearcenter_t.V_x_surround_obj_rearcenter[0].V_x_type, 433047553);
    struct _func_V_x_surround_obj_rearcenter_t_AutoLCPossibilityJdg_8 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_rearcenter_t tmp_surround_obj_rearcenter_t;
            Rte_Read_V_x_surround_obj_rearcenter_t_V_x_surround_obj_rearcenter_t(&tmp_surround_obj_rearcenter_t);
            EXPECT_EQ(tmp_surround_obj_rearcenter_t.V_x_surround_obj_rearcenter[0].V_x_type, 433047553);
        }
    } func_V_x_surround_obj_rearcenter_t_AutoLCPossibilityJdg_8;
    func_V_x_surround_obj_rearcenter_t_AutoLCPossibilityJdg_8.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_rearcenter_t.V_x_surround_obj_rearcenter[0].V_x_lane, 180);
    struct _func_V_x_surround_obj_rearcenter_t_AutoLCPossibilityJdg_9 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_rearcenter_t tmp_surround_obj_rearcenter_t;
            Rte_Read_V_x_surround_obj_rearcenter_t_V_x_surround_obj_rearcenter_t(&tmp_surround_obj_rearcenter_t);
            EXPECT_EQ(tmp_surround_obj_rearcenter_t.V_x_surround_obj_rearcenter[0].V_x_lane, 180);
        }
    } func_V_x_surround_obj_rearcenter_t_AutoLCPossibilityJdg_9;
    func_V_x_surround_obj_rearcenter_t_AutoLCPossibilityJdg_9.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_rearcenter_t.V_x_surround_obj_rearcenter[0].V_x_is_valid, 194);
    struct _func_V_x_surround_obj_rearcenter_t_AutoLCPossibilityJdg_10 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_rearcenter_t tmp_surround_obj_rearcenter_t;
            Rte_Read_V_x_surround_obj_rearcenter_t_V_x_surround_obj_rearcenter_t(&tmp_surround_obj_rearcenter_t);
            EXPECT_EQ(tmp_surround_obj_rearcenter_t.V_x_surround_obj_rearcenter[0].V_x_is_valid, 194);
        }
    } func_V_x_surround_obj_rearcenter_t_AutoLCPossibilityJdg_10;
    func_V_x_surround_obj_rearcenter_t_AutoLCPossibilityJdg_10.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_rearcenter_t.V_x_surround_obj_rearcenter[0].V_x_is_usable, 153);
    struct _func_V_x_surround_obj_rearcenter_t_AutoLCPossibilityJdg_11 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_rearcenter_t tmp_surround_obj_rearcenter_t;
            Rte_Read_V_x_surround_obj_rearcenter_t_V_x_surround_obj_rearcenter_t(&tmp_surround_obj_rearcenter_t);
            EXPECT_EQ(tmp_surround_obj_rearcenter_t.V_x_surround_obj_rearcenter[0].V_x_is_usable, 153);
        }
    } func_V_x_surround_obj_rearcenter_t_AutoLCPossibilityJdg_11;
    func_V_x_surround_obj_rearcenter_t_AutoLCPossibilityJdg_11.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_rearcenter_t.V_x_surround_obj_rearcenter[0].V_x_border, 3702659728);
    struct _func_V_x_surround_obj_rearcenter_t_AutoLCPossibilityJdg_12 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_rearcenter_t tmp_surround_obj_rearcenter_t;
            Rte_Read_V_x_surround_obj_rearcenter_t_V_x_surround_obj_rearcenter_t(&tmp_surround_obj_rearcenter_t);
            EXPECT_EQ(tmp_surround_obj_rearcenter_t.V_x_surround_obj_rearcenter[0].V_x_border, 3702659728);
        }
    } func_V_x_surround_obj_rearcenter_t_AutoLCPossibilityJdg_12;
    func_V_x_surround_obj_rearcenter_t_AutoLCPossibilityJdg_12.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_rearcenter_t.V_x_surround_obj_rearcenter[0].V_x_lost, 232);
    struct _func_V_x_surround_obj_rearcenter_t_AutoLCPossibilityJdg_13 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_rearcenter_t tmp_surround_obj_rearcenter_t;
            Rte_Read_V_x_surround_obj_rearcenter_t_V_x_surround_obj_rearcenter_t(&tmp_surround_obj_rearcenter_t);
            EXPECT_EQ(tmp_surround_obj_rearcenter_t.V_x_surround_obj_rearcenter[0].V_x_lost, 232);
        }
    } func_V_x_surround_obj_rearcenter_t_AutoLCPossibilityJdg_13;
    func_V_x_surround_obj_rearcenter_t_AutoLCPossibilityJdg_13.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_rearcenter_t.V_x_surround_obj_rearcenter[1].V_x_pos.V_m_X, -689.04);
    struct _func_V_x_surround_obj_rearcenter_t_AutoLCPossibilityJdg_14 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_rearcenter_t tmp_surround_obj_rearcenter_t;
            Rte_Read_V_x_surround_obj_rearcenter_t_V_x_surround_obj_rearcenter_t(&tmp_surround_obj_rearcenter_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_rearcenter_t.V_x_surround_obj_rearcenter[1].V_x_pos.V_m_X, -689.04);
        }
    } func_V_x_surround_obj_rearcenter_t_AutoLCPossibilityJdg_14;
    func_V_x_surround_obj_rearcenter_t_AutoLCPossibilityJdg_14.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_rearcenter_t.V_x_surround_obj_rearcenter[1].V_x_pos.V_m_Y, -35.22);
    struct _func_V_x_surround_obj_rearcenter_t_AutoLCPossibilityJdg_15 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_rearcenter_t tmp_surround_obj_rearcenter_t;
            Rte_Read_V_x_surround_obj_rearcenter_t_V_x_surround_obj_rearcenter_t(&tmp_surround_obj_rearcenter_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_rearcenter_t.V_x_surround_obj_rearcenter[1].V_x_pos.V_m_Y, -35.22);
        }
    } func_V_x_surround_obj_rearcenter_t_AutoLCPossibilityJdg_15;
    func_V_x_surround_obj_rearcenter_t_AutoLCPossibilityJdg_15.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_rearcenter_t.V_x_surround_obj_rearcenter[1].V_x_vel.V_m_X, 291.73);
    struct _func_V_x_surround_obj_rearcenter_t_AutoLCPossibilityJdg_16 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_rearcenter_t tmp_surround_obj_rearcenter_t;
            Rte_Read_V_x_surround_obj_rearcenter_t_V_x_surround_obj_rearcenter_t(&tmp_surround_obj_rearcenter_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_rearcenter_t.V_x_surround_obj_rearcenter[1].V_x_vel.V_m_X, 291.73);
        }
    } func_V_x_surround_obj_rearcenter_t_AutoLCPossibilityJdg_16;
    func_V_x_surround_obj_rearcenter_t_AutoLCPossibilityJdg_16.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_rearcenter_t.V_x_surround_obj_rearcenter[1].V_x_vel.V_m_Y, 79.62);
    struct _func_V_x_surround_obj_rearcenter_t_AutoLCPossibilityJdg_17 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_rearcenter_t tmp_surround_obj_rearcenter_t;
            Rte_Read_V_x_surround_obj_rearcenter_t_V_x_surround_obj_rearcenter_t(&tmp_surround_obj_rearcenter_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_rearcenter_t.V_x_surround_obj_rearcenter[1].V_x_vel.V_m_Y, 79.62);
        }
    } func_V_x_surround_obj_rearcenter_t_AutoLCPossibilityJdg_17;
    func_V_x_surround_obj_rearcenter_t_AutoLCPossibilityJdg_17.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_rearcenter_t.V_x_surround_obj_rearcenter[1].V_m_lat_pos_in_lane[0], -834.23);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_rearcenter_t.V_x_surround_obj_rearcenter[1].V_m_lat_pos_in_lane[1], 30.63);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_rearcenter_t.V_x_surround_obj_rearcenter[1].V_m_lat_pos_in_lane[2], 878.74);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_rearcenter_t.V_x_surround_obj_rearcenter[1].V_m_lat_pos_in_lane[3], -343.33);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_rearcenter_t.V_x_surround_obj_rearcenter[1].V_m_lat_pos_in_lane[4], 308.75);
    struct _func_V_x_surround_obj_rearcenter_t_AutoLCPossibilityJdg_18 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_rearcenter_t tmp_surround_obj_rearcenter_t;
            Rte_Read_V_x_surround_obj_rearcenter_t_V_x_surround_obj_rearcenter_t(&tmp_surround_obj_rearcenter_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_rearcenter_t.V_x_surround_obj_rearcenter[1].V_m_lat_pos_in_lane[0], -834.23);
            EXPECT_FLOAT_EQ(tmp_surround_obj_rearcenter_t.V_x_surround_obj_rearcenter[1].V_m_lat_pos_in_lane[1], 30.63);
            EXPECT_FLOAT_EQ(tmp_surround_obj_rearcenter_t.V_x_surround_obj_rearcenter[1].V_m_lat_pos_in_lane[2], 878.74);
            EXPECT_FLOAT_EQ(tmp_surround_obj_rearcenter_t.V_x_surround_obj_rearcenter[1].V_m_lat_pos_in_lane[3], -343.33);
            EXPECT_FLOAT_EQ(tmp_surround_obj_rearcenter_t.V_x_surround_obj_rearcenter[1].V_m_lat_pos_in_lane[4], 308.75);
        }
    } func_V_x_surround_obj_rearcenter_t_AutoLCPossibilityJdg_18;
    func_V_x_surround_obj_rearcenter_t_AutoLCPossibilityJdg_18.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_rearcenter_t.V_x_surround_obj_rearcenter[1].V_m_lat_vel_in_lane, -206.07);
    struct _func_V_x_surround_obj_rearcenter_t_AutoLCPossibilityJdg_19 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_rearcenter_t tmp_surround_obj_rearcenter_t;
            Rte_Read_V_x_surround_obj_rearcenter_t_V_x_surround_obj_rearcenter_t(&tmp_surround_obj_rearcenter_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_rearcenter_t.V_x_surround_obj_rearcenter[1].V_m_lat_vel_in_lane, -206.07);
        }
    } func_V_x_surround_obj_rearcenter_t_AutoLCPossibilityJdg_19;
    func_V_x_surround_obj_rearcenter_t_AutoLCPossibilityJdg_19.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_rearcenter_t.V_x_surround_obj_rearcenter[1].V_m_width, -893.72);
    struct _func_V_x_surround_obj_rearcenter_t_AutoLCPossibilityJdg_20 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_rearcenter_t tmp_surround_obj_rearcenter_t;
            Rte_Read_V_x_surround_obj_rearcenter_t_V_x_surround_obj_rearcenter_t(&tmp_surround_obj_rearcenter_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_rearcenter_t.V_x_surround_obj_rearcenter[1].V_m_width, -893.72);
        }
    } func_V_x_surround_obj_rearcenter_t_AutoLCPossibilityJdg_20;
    func_V_x_surround_obj_rearcenter_t_AutoLCPossibilityJdg_20.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_rearcenter_t.V_x_surround_obj_rearcenter[1].V_x_ID, 534663925);
    struct _func_V_x_surround_obj_rearcenter_t_AutoLCPossibilityJdg_21 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_rearcenter_t tmp_surround_obj_rearcenter_t;
            Rte_Read_V_x_surround_obj_rearcenter_t_V_x_surround_obj_rearcenter_t(&tmp_surround_obj_rearcenter_t);
            EXPECT_EQ(tmp_surround_obj_rearcenter_t.V_x_surround_obj_rearcenter[1].V_x_ID, 534663925);
        }
    } func_V_x_surround_obj_rearcenter_t_AutoLCPossibilityJdg_21;
    func_V_x_surround_obj_rearcenter_t_AutoLCPossibilityJdg_21.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_rearcenter_t.V_x_surround_obj_rearcenter[1].V_x_type, 1989985411);
    struct _func_V_x_surround_obj_rearcenter_t_AutoLCPossibilityJdg_22 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_rearcenter_t tmp_surround_obj_rearcenter_t;
            Rte_Read_V_x_surround_obj_rearcenter_t_V_x_surround_obj_rearcenter_t(&tmp_surround_obj_rearcenter_t);
            EXPECT_EQ(tmp_surround_obj_rearcenter_t.V_x_surround_obj_rearcenter[1].V_x_type, 1989985411);
        }
    } func_V_x_surround_obj_rearcenter_t_AutoLCPossibilityJdg_22;
    func_V_x_surround_obj_rearcenter_t_AutoLCPossibilityJdg_22.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_rearcenter_t.V_x_surround_obj_rearcenter[1].V_x_lane, 152);
    struct _func_V_x_surround_obj_rearcenter_t_AutoLCPossibilityJdg_23 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_rearcenter_t tmp_surround_obj_rearcenter_t;
            Rte_Read_V_x_surround_obj_rearcenter_t_V_x_surround_obj_rearcenter_t(&tmp_surround_obj_rearcenter_t);
            EXPECT_EQ(tmp_surround_obj_rearcenter_t.V_x_surround_obj_rearcenter[1].V_x_lane, 152);
        }
    } func_V_x_surround_obj_rearcenter_t_AutoLCPossibilityJdg_23;
    func_V_x_surround_obj_rearcenter_t_AutoLCPossibilityJdg_23.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_rearcenter_t.V_x_surround_obj_rearcenter[1].V_x_is_valid, 95);
    struct _func_V_x_surround_obj_rearcenter_t_AutoLCPossibilityJdg_24 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_rearcenter_t tmp_surround_obj_rearcenter_t;
            Rte_Read_V_x_surround_obj_rearcenter_t_V_x_surround_obj_rearcenter_t(&tmp_surround_obj_rearcenter_t);
            EXPECT_EQ(tmp_surround_obj_rearcenter_t.V_x_surround_obj_rearcenter[1].V_x_is_valid, 95);
        }
    } func_V_x_surround_obj_rearcenter_t_AutoLCPossibilityJdg_24;
    func_V_x_surround_obj_rearcenter_t_AutoLCPossibilityJdg_24.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_rearcenter_t.V_x_surround_obj_rearcenter[1].V_x_is_usable, 52);
    struct _func_V_x_surround_obj_rearcenter_t_AutoLCPossibilityJdg_25 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_rearcenter_t tmp_surround_obj_rearcenter_t;
            Rte_Read_V_x_surround_obj_rearcenter_t_V_x_surround_obj_rearcenter_t(&tmp_surround_obj_rearcenter_t);
            EXPECT_EQ(tmp_surround_obj_rearcenter_t.V_x_surround_obj_rearcenter[1].V_x_is_usable, 52);
        }
    } func_V_x_surround_obj_rearcenter_t_AutoLCPossibilityJdg_25;
    func_V_x_surround_obj_rearcenter_t_AutoLCPossibilityJdg_25.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_rearcenter_t.V_x_surround_obj_rearcenter[1].V_x_border, 2854917827);
    struct _func_V_x_surround_obj_rearcenter_t_AutoLCPossibilityJdg_26 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_rearcenter_t tmp_surround_obj_rearcenter_t;
            Rte_Read_V_x_surround_obj_rearcenter_t_V_x_surround_obj_rearcenter_t(&tmp_surround_obj_rearcenter_t);
            EXPECT_EQ(tmp_surround_obj_rearcenter_t.V_x_surround_obj_rearcenter[1].V_x_border, 2854917827);
        }
    } func_V_x_surround_obj_rearcenter_t_AutoLCPossibilityJdg_26;
    func_V_x_surround_obj_rearcenter_t_AutoLCPossibilityJdg_26.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_rearcenter_t.V_x_surround_obj_rearcenter[1].V_x_lost, 123);
    struct _func_V_x_surround_obj_rearcenter_t_AutoLCPossibilityJdg_27 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_rearcenter_t tmp_surround_obj_rearcenter_t;
            Rte_Read_V_x_surround_obj_rearcenter_t_V_x_surround_obj_rearcenter_t(&tmp_surround_obj_rearcenter_t);
            EXPECT_EQ(tmp_surround_obj_rearcenter_t.V_x_surround_obj_rearcenter[1].V_x_lost, 123);
        }
    } func_V_x_surround_obj_rearcenter_t_AutoLCPossibilityJdg_27;
    func_V_x_surround_obj_rearcenter_t_AutoLCPossibilityJdg_27.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_rearcenter_t.V_x_surround_obj_rearcenter[2].V_x_pos.V_m_X, -636.24);
    struct _func_V_x_surround_obj_rearcenter_t_AutoLCPossibilityJdg_28 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_rearcenter_t tmp_surround_obj_rearcenter_t;
            Rte_Read_V_x_surround_obj_rearcenter_t_V_x_surround_obj_rearcenter_t(&tmp_surround_obj_rearcenter_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_rearcenter_t.V_x_surround_obj_rearcenter[2].V_x_pos.V_m_X, -636.24);
        }
    } func_V_x_surround_obj_rearcenter_t_AutoLCPossibilityJdg_28;
    func_V_x_surround_obj_rearcenter_t_AutoLCPossibilityJdg_28.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_rearcenter_t.V_x_surround_obj_rearcenter[2].V_x_pos.V_m_Y, 957.2);
    struct _func_V_x_surround_obj_rearcenter_t_AutoLCPossibilityJdg_29 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_rearcenter_t tmp_surround_obj_rearcenter_t;
            Rte_Read_V_x_surround_obj_rearcenter_t_V_x_surround_obj_rearcenter_t(&tmp_surround_obj_rearcenter_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_rearcenter_t.V_x_surround_obj_rearcenter[2].V_x_pos.V_m_Y, 957.2);
        }
    } func_V_x_surround_obj_rearcenter_t_AutoLCPossibilityJdg_29;
    func_V_x_surround_obj_rearcenter_t_AutoLCPossibilityJdg_29.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_rearcenter_t.V_x_surround_obj_rearcenter[2].V_x_vel.V_m_X, -405.82);
    struct _func_V_x_surround_obj_rearcenter_t_AutoLCPossibilityJdg_30 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_rearcenter_t tmp_surround_obj_rearcenter_t;
            Rte_Read_V_x_surround_obj_rearcenter_t_V_x_surround_obj_rearcenter_t(&tmp_surround_obj_rearcenter_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_rearcenter_t.V_x_surround_obj_rearcenter[2].V_x_vel.V_m_X, -405.82);
        }
    } func_V_x_surround_obj_rearcenter_t_AutoLCPossibilityJdg_30;
    func_V_x_surround_obj_rearcenter_t_AutoLCPossibilityJdg_30.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_rearcenter_t.V_x_surround_obj_rearcenter[2].V_x_vel.V_m_Y, -391.84);
    struct _func_V_x_surround_obj_rearcenter_t_AutoLCPossibilityJdg_31 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_rearcenter_t tmp_surround_obj_rearcenter_t;
            Rte_Read_V_x_surround_obj_rearcenter_t_V_x_surround_obj_rearcenter_t(&tmp_surround_obj_rearcenter_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_rearcenter_t.V_x_surround_obj_rearcenter[2].V_x_vel.V_m_Y, -391.84);
        }
    } func_V_x_surround_obj_rearcenter_t_AutoLCPossibilityJdg_31;
    func_V_x_surround_obj_rearcenter_t_AutoLCPossibilityJdg_31.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_rearcenter_t.V_x_surround_obj_rearcenter[2].V_m_lat_pos_in_lane[0], -339.2);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_rearcenter_t.V_x_surround_obj_rearcenter[2].V_m_lat_pos_in_lane[1], 89.53);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_rearcenter_t.V_x_surround_obj_rearcenter[2].V_m_lat_pos_in_lane[2], -162.56);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_rearcenter_t.V_x_surround_obj_rearcenter[2].V_m_lat_pos_in_lane[3], 727.4);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_rearcenter_t.V_x_surround_obj_rearcenter[2].V_m_lat_pos_in_lane[4], 275.08);
    struct _func_V_x_surround_obj_rearcenter_t_AutoLCPossibilityJdg_32 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_rearcenter_t tmp_surround_obj_rearcenter_t;
            Rte_Read_V_x_surround_obj_rearcenter_t_V_x_surround_obj_rearcenter_t(&tmp_surround_obj_rearcenter_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_rearcenter_t.V_x_surround_obj_rearcenter[2].V_m_lat_pos_in_lane[0], -339.2);
            EXPECT_FLOAT_EQ(tmp_surround_obj_rearcenter_t.V_x_surround_obj_rearcenter[2].V_m_lat_pos_in_lane[1], 89.53);
            EXPECT_FLOAT_EQ(tmp_surround_obj_rearcenter_t.V_x_surround_obj_rearcenter[2].V_m_lat_pos_in_lane[2], -162.56);
            EXPECT_FLOAT_EQ(tmp_surround_obj_rearcenter_t.V_x_surround_obj_rearcenter[2].V_m_lat_pos_in_lane[3], 727.4);
            EXPECT_FLOAT_EQ(tmp_surround_obj_rearcenter_t.V_x_surround_obj_rearcenter[2].V_m_lat_pos_in_lane[4], 275.08);
        }
    } func_V_x_surround_obj_rearcenter_t_AutoLCPossibilityJdg_32;
    func_V_x_surround_obj_rearcenter_t_AutoLCPossibilityJdg_32.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_rearcenter_t.V_x_surround_obj_rearcenter[2].V_m_lat_vel_in_lane, -850.7);
    struct _func_V_x_surround_obj_rearcenter_t_AutoLCPossibilityJdg_33 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_rearcenter_t tmp_surround_obj_rearcenter_t;
            Rte_Read_V_x_surround_obj_rearcenter_t_V_x_surround_obj_rearcenter_t(&tmp_surround_obj_rearcenter_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_rearcenter_t.V_x_surround_obj_rearcenter[2].V_m_lat_vel_in_lane, -850.7);
        }
    } func_V_x_surround_obj_rearcenter_t_AutoLCPossibilityJdg_33;
    func_V_x_surround_obj_rearcenter_t_AutoLCPossibilityJdg_33.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_rearcenter_t.V_x_surround_obj_rearcenter[2].V_m_width, 858.28);
    struct _func_V_x_surround_obj_rearcenter_t_AutoLCPossibilityJdg_34 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_rearcenter_t tmp_surround_obj_rearcenter_t;
            Rte_Read_V_x_surround_obj_rearcenter_t_V_x_surround_obj_rearcenter_t(&tmp_surround_obj_rearcenter_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_rearcenter_t.V_x_surround_obj_rearcenter[2].V_m_width, 858.28);
        }
    } func_V_x_surround_obj_rearcenter_t_AutoLCPossibilityJdg_34;
    func_V_x_surround_obj_rearcenter_t_AutoLCPossibilityJdg_34.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_rearcenter_t.V_x_surround_obj_rearcenter[2].V_x_ID, 2271083887);
    struct _func_V_x_surround_obj_rearcenter_t_AutoLCPossibilityJdg_35 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_rearcenter_t tmp_surround_obj_rearcenter_t;
            Rte_Read_V_x_surround_obj_rearcenter_t_V_x_surround_obj_rearcenter_t(&tmp_surround_obj_rearcenter_t);
            EXPECT_EQ(tmp_surround_obj_rearcenter_t.V_x_surround_obj_rearcenter[2].V_x_ID, 2271083887);
        }
    } func_V_x_surround_obj_rearcenter_t_AutoLCPossibilityJdg_35;
    func_V_x_surround_obj_rearcenter_t_AutoLCPossibilityJdg_35.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_rearcenter_t.V_x_surround_obj_rearcenter[2].V_x_type, 2637825369);
    struct _func_V_x_surround_obj_rearcenter_t_AutoLCPossibilityJdg_36 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_rearcenter_t tmp_surround_obj_rearcenter_t;
            Rte_Read_V_x_surround_obj_rearcenter_t_V_x_surround_obj_rearcenter_t(&tmp_surround_obj_rearcenter_t);
            EXPECT_EQ(tmp_surround_obj_rearcenter_t.V_x_surround_obj_rearcenter[2].V_x_type, 2637825369);
        }
    } func_V_x_surround_obj_rearcenter_t_AutoLCPossibilityJdg_36;
    func_V_x_surround_obj_rearcenter_t_AutoLCPossibilityJdg_36.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_rearcenter_t.V_x_surround_obj_rearcenter[2].V_x_lane, 217);
    struct _func_V_x_surround_obj_rearcenter_t_AutoLCPossibilityJdg_37 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_rearcenter_t tmp_surround_obj_rearcenter_t;
            Rte_Read_V_x_surround_obj_rearcenter_t_V_x_surround_obj_rearcenter_t(&tmp_surround_obj_rearcenter_t);
            EXPECT_EQ(tmp_surround_obj_rearcenter_t.V_x_surround_obj_rearcenter[2].V_x_lane, 217);
        }
    } func_V_x_surround_obj_rearcenter_t_AutoLCPossibilityJdg_37;
    func_V_x_surround_obj_rearcenter_t_AutoLCPossibilityJdg_37.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_rearcenter_t.V_x_surround_obj_rearcenter[2].V_x_is_valid, 191);
    struct _func_V_x_surround_obj_rearcenter_t_AutoLCPossibilityJdg_38 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_rearcenter_t tmp_surround_obj_rearcenter_t;
            Rte_Read_V_x_surround_obj_rearcenter_t_V_x_surround_obj_rearcenter_t(&tmp_surround_obj_rearcenter_t);
            EXPECT_EQ(tmp_surround_obj_rearcenter_t.V_x_surround_obj_rearcenter[2].V_x_is_valid, 191);
        }
    } func_V_x_surround_obj_rearcenter_t_AutoLCPossibilityJdg_38;
    func_V_x_surround_obj_rearcenter_t_AutoLCPossibilityJdg_38.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_rearcenter_t.V_x_surround_obj_rearcenter[2].V_x_is_usable, 117);
    struct _func_V_x_surround_obj_rearcenter_t_AutoLCPossibilityJdg_39 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_rearcenter_t tmp_surround_obj_rearcenter_t;
            Rte_Read_V_x_surround_obj_rearcenter_t_V_x_surround_obj_rearcenter_t(&tmp_surround_obj_rearcenter_t);
            EXPECT_EQ(tmp_surround_obj_rearcenter_t.V_x_surround_obj_rearcenter[2].V_x_is_usable, 117);
        }
    } func_V_x_surround_obj_rearcenter_t_AutoLCPossibilityJdg_39;
    func_V_x_surround_obj_rearcenter_t_AutoLCPossibilityJdg_39.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_rearcenter_t.V_x_surround_obj_rearcenter[2].V_x_border, 1822045538);
    struct _func_V_x_surround_obj_rearcenter_t_AutoLCPossibilityJdg_40 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_rearcenter_t tmp_surround_obj_rearcenter_t;
            Rte_Read_V_x_surround_obj_rearcenter_t_V_x_surround_obj_rearcenter_t(&tmp_surround_obj_rearcenter_t);
            EXPECT_EQ(tmp_surround_obj_rearcenter_t.V_x_surround_obj_rearcenter[2].V_x_border, 1822045538);
        }
    } func_V_x_surround_obj_rearcenter_t_AutoLCPossibilityJdg_40;
    func_V_x_surround_obj_rearcenter_t_AutoLCPossibilityJdg_40.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_rearcenter_t.V_x_surround_obj_rearcenter[2].V_x_lost, 76);
    struct _func_V_x_surround_obj_rearcenter_t_AutoLCPossibilityJdg_41 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_rearcenter_t tmp_surround_obj_rearcenter_t;
            Rte_Read_V_x_surround_obj_rearcenter_t_V_x_surround_obj_rearcenter_t(&tmp_surround_obj_rearcenter_t);
            EXPECT_EQ(tmp_surround_obj_rearcenter_t.V_x_surround_obj_rearcenter[2].V_x_lost, 76);
        }
    } func_V_x_surround_obj_rearcenter_t_AutoLCPossibilityJdg_41;
    func_V_x_surround_obj_rearcenter_t_AutoLCPossibilityJdg_41.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_rearcenter_t.V_x_surround_obj_rearcenter[3].V_x_pos.V_m_X, -134.66);
    struct _func_V_x_surround_obj_rearcenter_t_AutoLCPossibilityJdg_42 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_rearcenter_t tmp_surround_obj_rearcenter_t;
            Rte_Read_V_x_surround_obj_rearcenter_t_V_x_surround_obj_rearcenter_t(&tmp_surround_obj_rearcenter_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_rearcenter_t.V_x_surround_obj_rearcenter[3].V_x_pos.V_m_X, -134.66);
        }
    } func_V_x_surround_obj_rearcenter_t_AutoLCPossibilityJdg_42;
    func_V_x_surround_obj_rearcenter_t_AutoLCPossibilityJdg_42.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_rearcenter_t.V_x_surround_obj_rearcenter[3].V_x_pos.V_m_Y, 201.87);
    struct _func_V_x_surround_obj_rearcenter_t_AutoLCPossibilityJdg_43 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_rearcenter_t tmp_surround_obj_rearcenter_t;
            Rte_Read_V_x_surround_obj_rearcenter_t_V_x_surround_obj_rearcenter_t(&tmp_surround_obj_rearcenter_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_rearcenter_t.V_x_surround_obj_rearcenter[3].V_x_pos.V_m_Y, 201.87);
        }
    } func_V_x_surround_obj_rearcenter_t_AutoLCPossibilityJdg_43;
    func_V_x_surround_obj_rearcenter_t_AutoLCPossibilityJdg_43.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_rearcenter_t.V_x_surround_obj_rearcenter[3].V_x_vel.V_m_X, 569.4);
    struct _func_V_x_surround_obj_rearcenter_t_AutoLCPossibilityJdg_44 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_rearcenter_t tmp_surround_obj_rearcenter_t;
            Rte_Read_V_x_surround_obj_rearcenter_t_V_x_surround_obj_rearcenter_t(&tmp_surround_obj_rearcenter_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_rearcenter_t.V_x_surround_obj_rearcenter[3].V_x_vel.V_m_X, 569.4);
        }
    } func_V_x_surround_obj_rearcenter_t_AutoLCPossibilityJdg_44;
    func_V_x_surround_obj_rearcenter_t_AutoLCPossibilityJdg_44.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_rearcenter_t.V_x_surround_obj_rearcenter[3].V_x_vel.V_m_Y, 19.67);
    struct _func_V_x_surround_obj_rearcenter_t_AutoLCPossibilityJdg_45 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_rearcenter_t tmp_surround_obj_rearcenter_t;
            Rte_Read_V_x_surround_obj_rearcenter_t_V_x_surround_obj_rearcenter_t(&tmp_surround_obj_rearcenter_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_rearcenter_t.V_x_surround_obj_rearcenter[3].V_x_vel.V_m_Y, 19.67);
        }
    } func_V_x_surround_obj_rearcenter_t_AutoLCPossibilityJdg_45;
    func_V_x_surround_obj_rearcenter_t_AutoLCPossibilityJdg_45.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_rearcenter_t.V_x_surround_obj_rearcenter[3].V_m_lat_pos_in_lane[0], -856.42);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_rearcenter_t.V_x_surround_obj_rearcenter[3].V_m_lat_pos_in_lane[1], 372.93);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_rearcenter_t.V_x_surround_obj_rearcenter[3].V_m_lat_pos_in_lane[2], 743.99);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_rearcenter_t.V_x_surround_obj_rearcenter[3].V_m_lat_pos_in_lane[3], -828.68);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_rearcenter_t.V_x_surround_obj_rearcenter[3].V_m_lat_pos_in_lane[4], -468.17);
    struct _func_V_x_surround_obj_rearcenter_t_AutoLCPossibilityJdg_46 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_rearcenter_t tmp_surround_obj_rearcenter_t;
            Rte_Read_V_x_surround_obj_rearcenter_t_V_x_surround_obj_rearcenter_t(&tmp_surround_obj_rearcenter_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_rearcenter_t.V_x_surround_obj_rearcenter[3].V_m_lat_pos_in_lane[0], -856.42);
            EXPECT_FLOAT_EQ(tmp_surround_obj_rearcenter_t.V_x_surround_obj_rearcenter[3].V_m_lat_pos_in_lane[1], 372.93);
            EXPECT_FLOAT_EQ(tmp_surround_obj_rearcenter_t.V_x_surround_obj_rearcenter[3].V_m_lat_pos_in_lane[2], 743.99);
            EXPECT_FLOAT_EQ(tmp_surround_obj_rearcenter_t.V_x_surround_obj_rearcenter[3].V_m_lat_pos_in_lane[3], -828.68);
            EXPECT_FLOAT_EQ(tmp_surround_obj_rearcenter_t.V_x_surround_obj_rearcenter[3].V_m_lat_pos_in_lane[4], -468.17);
        }
    } func_V_x_surround_obj_rearcenter_t_AutoLCPossibilityJdg_46;
    func_V_x_surround_obj_rearcenter_t_AutoLCPossibilityJdg_46.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_rearcenter_t.V_x_surround_obj_rearcenter[3].V_m_lat_vel_in_lane, 956.6);
    struct _func_V_x_surround_obj_rearcenter_t_AutoLCPossibilityJdg_47 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_rearcenter_t tmp_surround_obj_rearcenter_t;
            Rte_Read_V_x_surround_obj_rearcenter_t_V_x_surround_obj_rearcenter_t(&tmp_surround_obj_rearcenter_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_rearcenter_t.V_x_surround_obj_rearcenter[3].V_m_lat_vel_in_lane, 956.6);
        }
    } func_V_x_surround_obj_rearcenter_t_AutoLCPossibilityJdg_47;
    func_V_x_surround_obj_rearcenter_t_AutoLCPossibilityJdg_47.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_rearcenter_t.V_x_surround_obj_rearcenter[3].V_m_width, 389);
    struct _func_V_x_surround_obj_rearcenter_t_AutoLCPossibilityJdg_48 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_rearcenter_t tmp_surround_obj_rearcenter_t;
            Rte_Read_V_x_surround_obj_rearcenter_t_V_x_surround_obj_rearcenter_t(&tmp_surround_obj_rearcenter_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_rearcenter_t.V_x_surround_obj_rearcenter[3].V_m_width, 389);
        }
    } func_V_x_surround_obj_rearcenter_t_AutoLCPossibilityJdg_48;
    func_V_x_surround_obj_rearcenter_t_AutoLCPossibilityJdg_48.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_rearcenter_t.V_x_surround_obj_rearcenter[3].V_x_ID, 4051022035);
    struct _func_V_x_surround_obj_rearcenter_t_AutoLCPossibilityJdg_49 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_rearcenter_t tmp_surround_obj_rearcenter_t;
            Rte_Read_V_x_surround_obj_rearcenter_t_V_x_surround_obj_rearcenter_t(&tmp_surround_obj_rearcenter_t);
            EXPECT_EQ(tmp_surround_obj_rearcenter_t.V_x_surround_obj_rearcenter[3].V_x_ID, 4051022035);
        }
    } func_V_x_surround_obj_rearcenter_t_AutoLCPossibilityJdg_49;
    func_V_x_surround_obj_rearcenter_t_AutoLCPossibilityJdg_49.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_rearcenter_t.V_x_surround_obj_rearcenter[3].V_x_type, 570389342);
    struct _func_V_x_surround_obj_rearcenter_t_AutoLCPossibilityJdg_50 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_rearcenter_t tmp_surround_obj_rearcenter_t;
            Rte_Read_V_x_surround_obj_rearcenter_t_V_x_surround_obj_rearcenter_t(&tmp_surround_obj_rearcenter_t);
            EXPECT_EQ(tmp_surround_obj_rearcenter_t.V_x_surround_obj_rearcenter[3].V_x_type, 570389342);
        }
    } func_V_x_surround_obj_rearcenter_t_AutoLCPossibilityJdg_50;
    func_V_x_surround_obj_rearcenter_t_AutoLCPossibilityJdg_50.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_rearcenter_t.V_x_surround_obj_rearcenter[3].V_x_lane, 157);
    struct _func_V_x_surround_obj_rearcenter_t_AutoLCPossibilityJdg_51 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_rearcenter_t tmp_surround_obj_rearcenter_t;
            Rte_Read_V_x_surround_obj_rearcenter_t_V_x_surround_obj_rearcenter_t(&tmp_surround_obj_rearcenter_t);
            EXPECT_EQ(tmp_surround_obj_rearcenter_t.V_x_surround_obj_rearcenter[3].V_x_lane, 157);
        }
    } func_V_x_surround_obj_rearcenter_t_AutoLCPossibilityJdg_51;
    func_V_x_surround_obj_rearcenter_t_AutoLCPossibilityJdg_51.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_rearcenter_t.V_x_surround_obj_rearcenter[3].V_x_is_valid, 80);
    struct _func_V_x_surround_obj_rearcenter_t_AutoLCPossibilityJdg_52 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_rearcenter_t tmp_surround_obj_rearcenter_t;
            Rte_Read_V_x_surround_obj_rearcenter_t_V_x_surround_obj_rearcenter_t(&tmp_surround_obj_rearcenter_t);
            EXPECT_EQ(tmp_surround_obj_rearcenter_t.V_x_surround_obj_rearcenter[3].V_x_is_valid, 80);
        }
    } func_V_x_surround_obj_rearcenter_t_AutoLCPossibilityJdg_52;
    func_V_x_surround_obj_rearcenter_t_AutoLCPossibilityJdg_52.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_rearcenter_t.V_x_surround_obj_rearcenter[3].V_x_is_usable, 36);
    struct _func_V_x_surround_obj_rearcenter_t_AutoLCPossibilityJdg_53 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_rearcenter_t tmp_surround_obj_rearcenter_t;
            Rte_Read_V_x_surround_obj_rearcenter_t_V_x_surround_obj_rearcenter_t(&tmp_surround_obj_rearcenter_t);
            EXPECT_EQ(tmp_surround_obj_rearcenter_t.V_x_surround_obj_rearcenter[3].V_x_is_usable, 36);
        }
    } func_V_x_surround_obj_rearcenter_t_AutoLCPossibilityJdg_53;
    func_V_x_surround_obj_rearcenter_t_AutoLCPossibilityJdg_53.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_rearcenter_t.V_x_surround_obj_rearcenter[3].V_x_border, 4231801332);
    struct _func_V_x_surround_obj_rearcenter_t_AutoLCPossibilityJdg_54 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_rearcenter_t tmp_surround_obj_rearcenter_t;
            Rte_Read_V_x_surround_obj_rearcenter_t_V_x_surround_obj_rearcenter_t(&tmp_surround_obj_rearcenter_t);
            EXPECT_EQ(tmp_surround_obj_rearcenter_t.V_x_surround_obj_rearcenter[3].V_x_border, 4231801332);
        }
    } func_V_x_surround_obj_rearcenter_t_AutoLCPossibilityJdg_54;
    func_V_x_surround_obj_rearcenter_t_AutoLCPossibilityJdg_54.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_rearcenter_t.V_x_surround_obj_rearcenter[3].V_x_lost, 59);
    struct _func_V_x_surround_obj_rearcenter_t_AutoLCPossibilityJdg_55 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_rearcenter_t tmp_surround_obj_rearcenter_t;
            Rte_Read_V_x_surround_obj_rearcenter_t_V_x_surround_obj_rearcenter_t(&tmp_surround_obj_rearcenter_t);
            EXPECT_EQ(tmp_surround_obj_rearcenter_t.V_x_surround_obj_rearcenter[3].V_x_lost, 59);
        }
    } func_V_x_surround_obj_rearcenter_t_AutoLCPossibilityJdg_55;
    func_V_x_surround_obj_rearcenter_t_AutoLCPossibilityJdg_55.verify();

    /* V_x_surround_obj_right_t */
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[0].V_x_pos.V_m_X, 538.62);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_0 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[0].V_x_pos.V_m_X, 538.62);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_0;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_0.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_0 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[0].V_x_pos.V_m_X, 538.62);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_0;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_0.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[0].V_x_pos.V_m_Y, 330.31);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_1 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[0].V_x_pos.V_m_Y, 330.31);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_1;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_1.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_1 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[0].V_x_pos.V_m_Y, 330.31);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_1;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_1.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[0].V_x_vel.V_m_X, 674.96);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_2 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[0].V_x_vel.V_m_X, 674.96);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_2;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_2.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_2 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[0].V_x_vel.V_m_X, 674.96);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_2;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_2.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[0].V_x_vel.V_m_Y, 365.91);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_3 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[0].V_x_vel.V_m_Y, 365.91);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_3;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_3.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_3 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[0].V_x_vel.V_m_Y, 365.91);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_3;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_3.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[0].V_m_lat_pos_in_lane[0], 658.95);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[0].V_m_lat_pos_in_lane[1], 475.02);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[0].V_m_lat_pos_in_lane[2], 94.62);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[0].V_m_lat_pos_in_lane[3], -615.14);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[0].V_m_lat_pos_in_lane[4], -241.07);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_4 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[0].V_m_lat_pos_in_lane[0], 658.95);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[0].V_m_lat_pos_in_lane[1], 475.02);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[0].V_m_lat_pos_in_lane[2], 94.62);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[0].V_m_lat_pos_in_lane[3], -615.14);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[0].V_m_lat_pos_in_lane[4], -241.07);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_4;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_4.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_4 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[0].V_m_lat_pos_in_lane[0], 658.95);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[0].V_m_lat_pos_in_lane[1], 475.02);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[0].V_m_lat_pos_in_lane[2], 94.62);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[0].V_m_lat_pos_in_lane[3], -615.14);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[0].V_m_lat_pos_in_lane[4], -241.07);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_4;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_4.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[0].V_m_lat_vel_in_lane, -146.01);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_5 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[0].V_m_lat_vel_in_lane, -146.01);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_5;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_5.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_5 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[0].V_m_lat_vel_in_lane, -146.01);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_5;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_5.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[0].V_m_width, 830.8);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_6 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[0].V_m_width, 830.8);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_6;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_6.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_6 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[0].V_m_width, 830.8);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_6;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_6.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[0].V_x_ID, 2611715691);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_7 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[0].V_x_ID, 2611715691);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_7;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_7.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_7 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[0].V_x_ID, 2611715691);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_7;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_7.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[0].V_x_type, 2826056815);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_8 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[0].V_x_type, 2826056815);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_8;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_8.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_8 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[0].V_x_type, 2826056815);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_8;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_8.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[0].V_x_lane, 81);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_9 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[0].V_x_lane, 81);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_9;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_9.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_9 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[0].V_x_lane, 81);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_9;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_9.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[0].V_x_is_valid, 110);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_10 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[0].V_x_is_valid, 110);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_10;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_10.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_10 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[0].V_x_is_valid, 110);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_10;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_10.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[0].V_x_is_usable, 83);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_11 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[0].V_x_is_usable, 83);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_11;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_11.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_11 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[0].V_x_is_usable, 83);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_11;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_11.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[0].V_x_border, 1669197762);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_12 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[0].V_x_border, 1669197762);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_12;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_12.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_12 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[0].V_x_border, 1669197762);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_12;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_12.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[0].V_x_lost, 46);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_13 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[0].V_x_lost, 46);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_13;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_13.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_13 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[0].V_x_lost, 46);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_13;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_13.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[1].V_x_pos.V_m_X, -232.51);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_14 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[1].V_x_pos.V_m_X, -232.51);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_14;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_14.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_14 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[1].V_x_pos.V_m_X, -232.51);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_14;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_14.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[1].V_x_pos.V_m_Y, -498.23);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_15 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[1].V_x_pos.V_m_Y, -498.23);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_15;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_15.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_15 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[1].V_x_pos.V_m_Y, -498.23);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_15;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_15.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[1].V_x_vel.V_m_X, 18.36);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_16 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[1].V_x_vel.V_m_X, 18.36);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_16;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_16.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_16 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[1].V_x_vel.V_m_X, 18.36);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_16;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_16.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[1].V_x_vel.V_m_Y, -948.3);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_17 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[1].V_x_vel.V_m_Y, -948.3);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_17;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_17.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_17 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[1].V_x_vel.V_m_Y, -948.3);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_17;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_17.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[1].V_m_lat_pos_in_lane[0], 246.31);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[1].V_m_lat_pos_in_lane[1], 950.23);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[1].V_m_lat_pos_in_lane[2], -933.9);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[1].V_m_lat_pos_in_lane[3], -85.5);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[1].V_m_lat_pos_in_lane[4], 443.62);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_18 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[1].V_m_lat_pos_in_lane[0], 246.31);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[1].V_m_lat_pos_in_lane[1], 950.23);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[1].V_m_lat_pos_in_lane[2], -933.9);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[1].V_m_lat_pos_in_lane[3], -85.5);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[1].V_m_lat_pos_in_lane[4], 443.62);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_18;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_18.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_18 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[1].V_m_lat_pos_in_lane[0], 246.31);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[1].V_m_lat_pos_in_lane[1], 950.23);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[1].V_m_lat_pos_in_lane[2], -933.9);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[1].V_m_lat_pos_in_lane[3], -85.5);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[1].V_m_lat_pos_in_lane[4], 443.62);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_18;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_18.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[1].V_m_lat_vel_in_lane, 803.52);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_19 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[1].V_m_lat_vel_in_lane, 803.52);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_19;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_19.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_19 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[1].V_m_lat_vel_in_lane, 803.52);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_19;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_19.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[1].V_m_width, -379.02);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_20 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[1].V_m_width, -379.02);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_20;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_20.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_20 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[1].V_m_width, -379.02);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_20;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_20.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[1].V_x_ID, 1982677187);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_21 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[1].V_x_ID, 1982677187);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_21;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_21.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_21 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[1].V_x_ID, 1982677187);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_21;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_21.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[1].V_x_type, 3916031104);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_22 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[1].V_x_type, 3916031104);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_22;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_22.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_22 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[1].V_x_type, 3916031104);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_22;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_22.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[1].V_x_lane, 18);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_23 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[1].V_x_lane, 18);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_23;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_23.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_23 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[1].V_x_lane, 18);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_23;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_23.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[1].V_x_is_valid, 59);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_24 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[1].V_x_is_valid, 59);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_24;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_24.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_24 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[1].V_x_is_valid, 59);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_24;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_24.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[1].V_x_is_usable, 31);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_25 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[1].V_x_is_usable, 31);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_25;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_25.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_25 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[1].V_x_is_usable, 31);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_25;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_25.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[1].V_x_border, 1447194684);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_26 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[1].V_x_border, 1447194684);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_26;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_26.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_26 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[1].V_x_border, 1447194684);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_26;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_26.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[1].V_x_lost, 71);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_27 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[1].V_x_lost, 71);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_27;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_27.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_27 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[1].V_x_lost, 71);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_27;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_27.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[2].V_x_pos.V_m_X, -877.18);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_28 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[2].V_x_pos.V_m_X, -877.18);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_28;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_28.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_28 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[2].V_x_pos.V_m_X, -877.18);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_28;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_28.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[2].V_x_pos.V_m_Y, 541.18);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_29 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[2].V_x_pos.V_m_Y, 541.18);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_29;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_29.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_29 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[2].V_x_pos.V_m_Y, 541.18);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_29;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_29.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[2].V_x_vel.V_m_X, 293.49);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_30 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[2].V_x_vel.V_m_X, 293.49);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_30;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_30.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_30 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[2].V_x_vel.V_m_X, 293.49);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_30;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_30.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[2].V_x_vel.V_m_Y, -599.27);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_31 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[2].V_x_vel.V_m_Y, -599.27);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_31;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_31.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_31 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[2].V_x_vel.V_m_Y, -599.27);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_31;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_31.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[2].V_m_lat_pos_in_lane[0], 433.01);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[2].V_m_lat_pos_in_lane[1], 596.8);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[2].V_m_lat_pos_in_lane[2], -257.25);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[2].V_m_lat_pos_in_lane[3], -511.15);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[2].V_m_lat_pos_in_lane[4], 445.27);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_32 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[2].V_m_lat_pos_in_lane[0], 433.01);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[2].V_m_lat_pos_in_lane[1], 596.8);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[2].V_m_lat_pos_in_lane[2], -257.25);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[2].V_m_lat_pos_in_lane[3], -511.15);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[2].V_m_lat_pos_in_lane[4], 445.27);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_32;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_32.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_32 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[2].V_m_lat_pos_in_lane[0], 433.01);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[2].V_m_lat_pos_in_lane[1], 596.8);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[2].V_m_lat_pos_in_lane[2], -257.25);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[2].V_m_lat_pos_in_lane[3], -511.15);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[2].V_m_lat_pos_in_lane[4], 445.27);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_32;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_32.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[2].V_m_lat_vel_in_lane, -832.76);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_33 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[2].V_m_lat_vel_in_lane, -832.76);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_33;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_33.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_33 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[2].V_m_lat_vel_in_lane, -832.76);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_33;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_33.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[2].V_m_width, -690.96);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_34 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[2].V_m_width, -690.96);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_34;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_34.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_34 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[2].V_m_width, -690.96);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_34;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_34.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[2].V_x_ID, 2432851821);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_35 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[2].V_x_ID, 2432851821);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_35;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_35.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_35 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[2].V_x_ID, 2432851821);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_35;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_35.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[2].V_x_type, 1064773403);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_36 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[2].V_x_type, 1064773403);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_36;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_36.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_36 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[2].V_x_type, 1064773403);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_36;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_36.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[2].V_x_lane, 117);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_37 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[2].V_x_lane, 117);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_37;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_37.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_37 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[2].V_x_lane, 117);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_37;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_37.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[2].V_x_is_valid, 131);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_38 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[2].V_x_is_valid, 131);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_38;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_38.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_38 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[2].V_x_is_valid, 131);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_38;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_38.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[2].V_x_is_usable, 230);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_39 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[2].V_x_is_usable, 230);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_39;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_39.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_39 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[2].V_x_is_usable, 230);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_39;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_39.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[2].V_x_border, 1051941053);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_40 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[2].V_x_border, 1051941053);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_40;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_40.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_40 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[2].V_x_border, 1051941053);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_40;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_40.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[2].V_x_lost, 32);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_41 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[2].V_x_lost, 32);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_41;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_41.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_41 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[2].V_x_lost, 32);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_41;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_41.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[3].V_x_pos.V_m_X, 253.04);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_42 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[3].V_x_pos.V_m_X, 253.04);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_42;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_42.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_42 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[3].V_x_pos.V_m_X, 253.04);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_42;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_42.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[3].V_x_pos.V_m_Y, -958.65);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_43 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[3].V_x_pos.V_m_Y, -958.65);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_43;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_43.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_43 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[3].V_x_pos.V_m_Y, -958.65);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_43;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_43.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[3].V_x_vel.V_m_X, -16.98);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_44 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[3].V_x_vel.V_m_X, -16.98);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_44;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_44.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_44 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[3].V_x_vel.V_m_X, -16.98);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_44;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_44.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[3].V_x_vel.V_m_Y, 772.52);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_45 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[3].V_x_vel.V_m_Y, 772.52);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_45;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_45.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_45 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[3].V_x_vel.V_m_Y, 772.52);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_45;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_45.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[3].V_m_lat_pos_in_lane[0], -9.81);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[3].V_m_lat_pos_in_lane[1], -292.48);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[3].V_m_lat_pos_in_lane[2], -964.58);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[3].V_m_lat_pos_in_lane[3], -875.08);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[3].V_m_lat_pos_in_lane[4], 14.1);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_46 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[3].V_m_lat_pos_in_lane[0], -9.81);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[3].V_m_lat_pos_in_lane[1], -292.48);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[3].V_m_lat_pos_in_lane[2], -964.58);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[3].V_m_lat_pos_in_lane[3], -875.08);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[3].V_m_lat_pos_in_lane[4], 14.1);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_46;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_46.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_46 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[3].V_m_lat_pos_in_lane[0], -9.81);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[3].V_m_lat_pos_in_lane[1], -292.48);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[3].V_m_lat_pos_in_lane[2], -964.58);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[3].V_m_lat_pos_in_lane[3], -875.08);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[3].V_m_lat_pos_in_lane[4], 14.1);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_46;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_46.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[3].V_m_lat_vel_in_lane, 34.44);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_47 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[3].V_m_lat_vel_in_lane, 34.44);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_47;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_47.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_47 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[3].V_m_lat_vel_in_lane, 34.44);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_47;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_47.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[3].V_m_width, 575.58);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_48 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[3].V_m_width, 575.58);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_48;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_48.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_48 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[3].V_m_width, 575.58);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_48;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_48.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[3].V_x_ID, 3548747396);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_49 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[3].V_x_ID, 3548747396);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_49;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_49.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_49 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[3].V_x_ID, 3548747396);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_49;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_49.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[3].V_x_type, 475708371);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_50 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[3].V_x_type, 475708371);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_50;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_50.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_50 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[3].V_x_type, 475708371);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_50;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_50.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[3].V_x_lane, 143);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_51 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[3].V_x_lane, 143);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_51;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_51.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_51 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[3].V_x_lane, 143);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_51;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_51.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[3].V_x_is_valid, 137);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_52 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[3].V_x_is_valid, 137);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_52;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_52.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_52 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[3].V_x_is_valid, 137);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_52;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_52.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[3].V_x_is_usable, 219);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_53 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[3].V_x_is_usable, 219);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_53;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_53.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_53 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[3].V_x_is_usable, 219);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_53;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_53.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[3].V_x_border, 3793367023);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_54 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[3].V_x_border, 3793367023);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_54;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_54.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_54 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[3].V_x_border, 3793367023);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_54;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_54.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[3].V_x_lost, 196);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_55 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[3].V_x_lost, 196);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_55;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_55.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_55 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[3].V_x_lost, 196);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_55;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_55.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[4].V_x_pos.V_m_X, -999.91);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_56 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[4].V_x_pos.V_m_X, -999.91);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_56;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_56.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_56 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[4].V_x_pos.V_m_X, -999.91);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_56;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_56.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[4].V_x_pos.V_m_Y, -661.62);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_57 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[4].V_x_pos.V_m_Y, -661.62);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_57;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_57.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_57 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[4].V_x_pos.V_m_Y, -661.62);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_57;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_57.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[4].V_x_vel.V_m_X, -66.37);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_58 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[4].V_x_vel.V_m_X, -66.37);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_58;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_58.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_58 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[4].V_x_vel.V_m_X, -66.37);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_58;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_58.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[4].V_x_vel.V_m_Y, -513.85);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_59 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[4].V_x_vel.V_m_Y, -513.85);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_59;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_59.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_59 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[4].V_x_vel.V_m_Y, -513.85);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_59;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_59.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[4].V_m_lat_pos_in_lane[0], 11.54);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[4].V_m_lat_pos_in_lane[1], -719.62);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[4].V_m_lat_pos_in_lane[2], 973.46);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[4].V_m_lat_pos_in_lane[3], -685.1);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[4].V_m_lat_pos_in_lane[4], 199.1);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_60 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[4].V_m_lat_pos_in_lane[0], 11.54);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[4].V_m_lat_pos_in_lane[1], -719.62);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[4].V_m_lat_pos_in_lane[2], 973.46);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[4].V_m_lat_pos_in_lane[3], -685.1);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[4].V_m_lat_pos_in_lane[4], 199.1);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_60;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_60.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_60 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[4].V_m_lat_pos_in_lane[0], 11.54);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[4].V_m_lat_pos_in_lane[1], -719.62);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[4].V_m_lat_pos_in_lane[2], 973.46);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[4].V_m_lat_pos_in_lane[3], -685.1);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[4].V_m_lat_pos_in_lane[4], 199.1);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_60;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_60.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[4].V_m_lat_vel_in_lane, 733.75);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_61 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[4].V_m_lat_vel_in_lane, 733.75);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_61;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_61.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_61 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[4].V_m_lat_vel_in_lane, 733.75);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_61;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_61.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[4].V_m_width, 847.2);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_62 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[4].V_m_width, 847.2);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_62;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_62.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_62 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[4].V_m_width, 847.2);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_62;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_62.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[4].V_x_ID, 2057275361);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_63 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[4].V_x_ID, 2057275361);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_63;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_63.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_63 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[4].V_x_ID, 2057275361);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_63;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_63.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[4].V_x_type, 1961318752);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_64 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[4].V_x_type, 1961318752);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_64;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_64.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_64 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[4].V_x_type, 1961318752);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_64;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_64.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[4].V_x_lane, 97);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_65 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[4].V_x_lane, 97);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_65;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_65.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_65 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[4].V_x_lane, 97);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_65;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_65.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[4].V_x_is_valid, 89);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_66 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[4].V_x_is_valid, 89);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_66;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_66.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_66 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[4].V_x_is_valid, 89);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_66;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_66.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[4].V_x_is_usable, 70);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_67 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[4].V_x_is_usable, 70);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_67;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_67.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_67 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[4].V_x_is_usable, 70);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_67;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_67.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[4].V_x_border, 2893582487);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_68 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[4].V_x_border, 2893582487);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_68;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_68.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_68 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[4].V_x_border, 2893582487);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_68;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_68.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[4].V_x_lost, 234);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_69 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[4].V_x_lost, 234);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_69;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_69.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_69 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[4].V_x_lost, 234);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_69;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_69.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[5].V_x_pos.V_m_X, 875.07);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_70 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[5].V_x_pos.V_m_X, 875.07);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_70;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_70.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_70 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[5].V_x_pos.V_m_X, 875.07);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_70;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_70.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[5].V_x_pos.V_m_Y, -223.98);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_71 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[5].V_x_pos.V_m_Y, -223.98);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_71;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_71.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_71 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[5].V_x_pos.V_m_Y, -223.98);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_71;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_71.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[5].V_x_vel.V_m_X, 220.13);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_72 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[5].V_x_vel.V_m_X, 220.13);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_72;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_72.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_72 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[5].V_x_vel.V_m_X, 220.13);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_72;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_72.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[5].V_x_vel.V_m_Y, -40.36);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_73 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[5].V_x_vel.V_m_Y, -40.36);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_73;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_73.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_73 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[5].V_x_vel.V_m_Y, -40.36);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_73;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_73.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[5].V_m_lat_pos_in_lane[0], 834.47);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[5].V_m_lat_pos_in_lane[1], -247.62);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[5].V_m_lat_pos_in_lane[2], 576.49);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[5].V_m_lat_pos_in_lane[3], 795.8);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[5].V_m_lat_pos_in_lane[4], -64.13);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_74 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[5].V_m_lat_pos_in_lane[0], 834.47);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[5].V_m_lat_pos_in_lane[1], -247.62);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[5].V_m_lat_pos_in_lane[2], 576.49);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[5].V_m_lat_pos_in_lane[3], 795.8);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[5].V_m_lat_pos_in_lane[4], -64.13);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_74;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_74.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_74 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[5].V_m_lat_pos_in_lane[0], 834.47);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[5].V_m_lat_pos_in_lane[1], -247.62);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[5].V_m_lat_pos_in_lane[2], 576.49);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[5].V_m_lat_pos_in_lane[3], 795.8);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[5].V_m_lat_pos_in_lane[4], -64.13);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_74;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_74.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[5].V_m_lat_vel_in_lane, 833.59);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_75 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[5].V_m_lat_vel_in_lane, 833.59);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_75;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_75.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_75 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[5].V_m_lat_vel_in_lane, 833.59);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_75;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_75.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[5].V_m_width, 280.17);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_76 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[5].V_m_width, 280.17);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_76;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_76.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_76 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[5].V_m_width, 280.17);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_76;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_76.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[5].V_x_ID, 1929722558);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_77 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[5].V_x_ID, 1929722558);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_77;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_77.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_77 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[5].V_x_ID, 1929722558);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_77;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_77.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[5].V_x_type, 1322969472);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_78 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[5].V_x_type, 1322969472);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_78;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_78.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_78 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[5].V_x_type, 1322969472);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_78;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_78.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[5].V_x_lane, 219);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_79 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[5].V_x_lane, 219);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_79;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_79.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_79 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[5].V_x_lane, 219);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_79;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_79.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[5].V_x_is_valid, 176);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_80 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[5].V_x_is_valid, 176);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_80;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_80.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_80 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[5].V_x_is_valid, 176);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_80;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_80.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[5].V_x_is_usable, 242);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_81 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[5].V_x_is_usable, 242);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_81;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_81.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_81 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[5].V_x_is_usable, 242);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_81;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_81.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[5].V_x_border, 3137827131);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_82 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[5].V_x_border, 3137827131);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_82;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_82.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_82 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[5].V_x_border, 3137827131);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_82;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_82.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[5].V_x_lost, 84);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_83 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[5].V_x_lost, 84);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_83;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_83.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_83 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[5].V_x_lost, 84);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_83;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_83.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[6].V_x_pos.V_m_X, -748.43);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_84 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[6].V_x_pos.V_m_X, -748.43);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_84;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_84.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_84 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[6].V_x_pos.V_m_X, -748.43);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_84;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_84.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[6].V_x_pos.V_m_Y, -835.73);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_85 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[6].V_x_pos.V_m_Y, -835.73);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_85;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_85.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_85 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[6].V_x_pos.V_m_Y, -835.73);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_85;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_85.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[6].V_x_vel.V_m_X, -803.33);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_86 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[6].V_x_vel.V_m_X, -803.33);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_86;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_86.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_86 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[6].V_x_vel.V_m_X, -803.33);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_86;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_86.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[6].V_x_vel.V_m_Y, -533.74);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_87 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[6].V_x_vel.V_m_Y, -533.74);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_87;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_87.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_87 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[6].V_x_vel.V_m_Y, -533.74);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_87;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_87.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[6].V_m_lat_pos_in_lane[0], -799.97);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[6].V_m_lat_pos_in_lane[1], 686.37);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[6].V_m_lat_pos_in_lane[2], -469.07);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[6].V_m_lat_pos_in_lane[3], -515.02);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[6].V_m_lat_pos_in_lane[4], -140.39);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_88 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[6].V_m_lat_pos_in_lane[0], -799.97);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[6].V_m_lat_pos_in_lane[1], 686.37);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[6].V_m_lat_pos_in_lane[2], -469.07);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[6].V_m_lat_pos_in_lane[3], -515.02);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[6].V_m_lat_pos_in_lane[4], -140.39);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_88;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_88.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_88 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[6].V_m_lat_pos_in_lane[0], -799.97);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[6].V_m_lat_pos_in_lane[1], 686.37);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[6].V_m_lat_pos_in_lane[2], -469.07);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[6].V_m_lat_pos_in_lane[3], -515.02);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[6].V_m_lat_pos_in_lane[4], -140.39);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_88;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_88.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[6].V_m_lat_vel_in_lane, -723.22);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_89 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[6].V_m_lat_vel_in_lane, -723.22);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_89;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_89.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_89 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[6].V_m_lat_vel_in_lane, -723.22);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_89;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_89.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[6].V_m_width, 926.11);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_90 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[6].V_m_width, 926.11);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_90;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_90.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_90 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[6].V_m_width, 926.11);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_90;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_90.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[6].V_x_ID, 2182512469);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_91 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[6].V_x_ID, 2182512469);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_91;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_91.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_91 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[6].V_x_ID, 2182512469);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_91;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_91.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[6].V_x_type, 3173985540);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_92 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[6].V_x_type, 3173985540);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_92;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_92.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_92 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[6].V_x_type, 3173985540);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_92;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_92.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[6].V_x_lane, 180);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_93 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[6].V_x_lane, 180);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_93;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_93.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_93 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[6].V_x_lane, 180);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_93;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_93.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[6].V_x_is_valid, 36);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_94 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[6].V_x_is_valid, 36);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_94;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_94.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_94 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[6].V_x_is_valid, 36);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_94;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_94.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[6].V_x_is_usable, 189);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_95 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[6].V_x_is_usable, 189);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_95;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_95.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_95 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[6].V_x_is_usable, 189);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_95;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_95.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[6].V_x_border, 2051482510);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_96 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[6].V_x_border, 2051482510);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_96;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_96.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_96 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[6].V_x_border, 2051482510);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_96;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_96.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[6].V_x_lost, 84);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_97 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[6].V_x_lost, 84);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_97;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_97.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_97 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[6].V_x_lost, 84);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_97;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_97.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[7].V_x_pos.V_m_X, -288.93);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_98 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[7].V_x_pos.V_m_X, -288.93);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_98;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_98.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_98 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[7].V_x_pos.V_m_X, -288.93);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_98;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_98.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[7].V_x_pos.V_m_Y, 228.53);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_99 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[7].V_x_pos.V_m_Y, 228.53);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_99;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_99.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_99 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[7].V_x_pos.V_m_Y, 228.53);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_99;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_99.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[7].V_x_vel.V_m_X, 837.15);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_100 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[7].V_x_vel.V_m_X, 837.15);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_100;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_100.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_100 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[7].V_x_vel.V_m_X, 837.15);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_100;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_100.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[7].V_x_vel.V_m_Y, 189.73);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_101 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[7].V_x_vel.V_m_Y, 189.73);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_101;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_101.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_101 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[7].V_x_vel.V_m_Y, 189.73);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_101;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_101.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[7].V_m_lat_pos_in_lane[0], 246.76);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[7].V_m_lat_pos_in_lane[1], -737.82);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[7].V_m_lat_pos_in_lane[2], 472.89);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[7].V_m_lat_pos_in_lane[3], 892.39);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[7].V_m_lat_pos_in_lane[4], -946.23);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_102 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[7].V_m_lat_pos_in_lane[0], 246.76);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[7].V_m_lat_pos_in_lane[1], -737.82);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[7].V_m_lat_pos_in_lane[2], 472.89);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[7].V_m_lat_pos_in_lane[3], 892.39);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[7].V_m_lat_pos_in_lane[4], -946.23);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_102;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_102.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_102 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[7].V_m_lat_pos_in_lane[0], 246.76);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[7].V_m_lat_pos_in_lane[1], -737.82);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[7].V_m_lat_pos_in_lane[2], 472.89);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[7].V_m_lat_pos_in_lane[3], 892.39);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[7].V_m_lat_pos_in_lane[4], -946.23);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_102;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_102.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[7].V_m_lat_vel_in_lane, -638.01);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_103 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[7].V_m_lat_vel_in_lane, -638.01);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_103;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_103.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_103 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[7].V_m_lat_vel_in_lane, -638.01);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_103;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_103.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[7].V_m_width, 532.06);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_104 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[7].V_m_width, 532.06);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_104;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_104.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_104 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[7].V_m_width, 532.06);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_104;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_104.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[7].V_x_ID, 930083114);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_105 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[7].V_x_ID, 930083114);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_105;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_105.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_105 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[7].V_x_ID, 930083114);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_105;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_105.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[7].V_x_type, 2274093727);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_106 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[7].V_x_type, 2274093727);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_106;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_106.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_106 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[7].V_x_type, 2274093727);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_106;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_106.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[7].V_x_lane, 175);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_107 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[7].V_x_lane, 175);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_107;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_107.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_107 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[7].V_x_lane, 175);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_107;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_107.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[7].V_x_is_valid, 214);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_108 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[7].V_x_is_valid, 214);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_108;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_108.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_108 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[7].V_x_is_valid, 214);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_108;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_108.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[7].V_x_is_usable, 149);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_109 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[7].V_x_is_usable, 149);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_109;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_109.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_109 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[7].V_x_is_usable, 149);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_109;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_109.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[7].V_x_border, 1197070587);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_110 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[7].V_x_border, 1197070587);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_110;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_110.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_110 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[7].V_x_border, 1197070587);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_110;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_110.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[7].V_x_lost, 170);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_111 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[7].V_x_lost, 170);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_111;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_111.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_111 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[7].V_x_lost, 170);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_111;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_111.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[8].V_x_pos.V_m_X, -934.02);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_112 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[8].V_x_pos.V_m_X, -934.02);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_112;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_112.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_112 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[8].V_x_pos.V_m_X, -934.02);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_112;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_112.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[8].V_x_pos.V_m_Y, 194.14);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_113 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[8].V_x_pos.V_m_Y, 194.14);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_113;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_113.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_113 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[8].V_x_pos.V_m_Y, 194.14);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_113;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_113.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[8].V_x_vel.V_m_X, 71.8);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_114 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[8].V_x_vel.V_m_X, 71.8);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_114;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_114.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_114 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[8].V_x_vel.V_m_X, 71.8);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_114;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_114.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[8].V_x_vel.V_m_Y, 456.67);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_115 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[8].V_x_vel.V_m_Y, 456.67);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_115;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_115.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_115 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[8].V_x_vel.V_m_Y, 456.67);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_115;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_115.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[8].V_m_lat_pos_in_lane[0], -891.79);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[8].V_m_lat_pos_in_lane[1], 905.25);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[8].V_m_lat_pos_in_lane[2], 366.02);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[8].V_m_lat_pos_in_lane[3], -719.46);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[8].V_m_lat_pos_in_lane[4], -554.53);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_116 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[8].V_m_lat_pos_in_lane[0], -891.79);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[8].V_m_lat_pos_in_lane[1], 905.25);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[8].V_m_lat_pos_in_lane[2], 366.02);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[8].V_m_lat_pos_in_lane[3], -719.46);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[8].V_m_lat_pos_in_lane[4], -554.53);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_116;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_116.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_116 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[8].V_m_lat_pos_in_lane[0], -891.79);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[8].V_m_lat_pos_in_lane[1], 905.25);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[8].V_m_lat_pos_in_lane[2], 366.02);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[8].V_m_lat_pos_in_lane[3], -719.46);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[8].V_m_lat_pos_in_lane[4], -554.53);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_116;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_116.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[8].V_m_lat_vel_in_lane, -684.33);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_117 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[8].V_m_lat_vel_in_lane, -684.33);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_117;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_117.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_117 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[8].V_m_lat_vel_in_lane, -684.33);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_117;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_117.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[8].V_m_width, -544.61);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_118 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[8].V_m_width, -544.61);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_118;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_118.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_118 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[8].V_m_width, -544.61);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_118;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_118.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[8].V_x_ID, 1354826019);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_119 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[8].V_x_ID, 1354826019);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_119;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_119.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_119 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[8].V_x_ID, 1354826019);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_119;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_119.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[8].V_x_type, 147123191);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_120 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[8].V_x_type, 147123191);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_120;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_120.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_120 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[8].V_x_type, 147123191);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_120;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_120.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[8].V_x_lane, 37);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_121 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[8].V_x_lane, 37);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_121;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_121.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_121 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[8].V_x_lane, 37);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_121;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_121.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[8].V_x_is_valid, 238);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_122 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[8].V_x_is_valid, 238);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_122;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_122.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_122 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[8].V_x_is_valid, 238);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_122;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_122.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[8].V_x_is_usable, 37);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_123 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[8].V_x_is_usable, 37);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_123;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_123.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_123 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[8].V_x_is_usable, 37);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_123;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_123.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[8].V_x_border, 333497959);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_124 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[8].V_x_border, 333497959);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_124;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_124.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_124 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[8].V_x_border, 333497959);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_124;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_124.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[8].V_x_lost, 7);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_125 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[8].V_x_lost, 7);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_125;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_125.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_125 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[8].V_x_lost, 7);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_125;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_125.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[9].V_x_pos.V_m_X, 588.23);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_126 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[9].V_x_pos.V_m_X, 588.23);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_126;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_126.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_126 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[9].V_x_pos.V_m_X, 588.23);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_126;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_126.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[9].V_x_pos.V_m_Y, 751.45);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_127 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[9].V_x_pos.V_m_Y, 751.45);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_127;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_127.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_127 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[9].V_x_pos.V_m_Y, 751.45);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_127;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_127.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[9].V_x_vel.V_m_X, -807.94);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_128 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[9].V_x_vel.V_m_X, -807.94);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_128;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_128.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_128 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[9].V_x_vel.V_m_X, -807.94);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_128;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_128.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[9].V_x_vel.V_m_Y, 653.1);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_129 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[9].V_x_vel.V_m_Y, 653.1);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_129;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_129.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_129 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[9].V_x_vel.V_m_Y, 653.1);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_129;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_129.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[9].V_m_lat_pos_in_lane[0], -103.35);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[9].V_m_lat_pos_in_lane[1], 793.89);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[9].V_m_lat_pos_in_lane[2], -621.87);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[9].V_m_lat_pos_in_lane[3], -88.46);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[9].V_m_lat_pos_in_lane[4], -341.42);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_130 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[9].V_m_lat_pos_in_lane[0], -103.35);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[9].V_m_lat_pos_in_lane[1], 793.89);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[9].V_m_lat_pos_in_lane[2], -621.87);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[9].V_m_lat_pos_in_lane[3], -88.46);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[9].V_m_lat_pos_in_lane[4], -341.42);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_130;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_130.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_130 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[9].V_m_lat_pos_in_lane[0], -103.35);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[9].V_m_lat_pos_in_lane[1], 793.89);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[9].V_m_lat_pos_in_lane[2], -621.87);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[9].V_m_lat_pos_in_lane[3], -88.46);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[9].V_m_lat_pos_in_lane[4], -341.42);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_130;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_130.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[9].V_m_lat_vel_in_lane, 17.58);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_131 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[9].V_m_lat_vel_in_lane, 17.58);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_131;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_131.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_131 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[9].V_m_lat_vel_in_lane, 17.58);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_131;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_131.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[9].V_m_width, -939.59);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_132 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[9].V_m_width, -939.59);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_132;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_132.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_132 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[9].V_m_width, -939.59);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_132;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_132.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[9].V_x_ID, 4231987900);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_133 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[9].V_x_ID, 4231987900);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_133;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_133.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_133 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[9].V_x_ID, 4231987900);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_133;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_133.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[9].V_x_type, 1622692978);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_134 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[9].V_x_type, 1622692978);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_134;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_134.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_134 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[9].V_x_type, 1622692978);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_134;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_134.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[9].V_x_lane, 223);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_135 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[9].V_x_lane, 223);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_135;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_135.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_135 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[9].V_x_lane, 223);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_135;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_135.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[9].V_x_is_valid, 76);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_136 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[9].V_x_is_valid, 76);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_136;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_136.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_136 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[9].V_x_is_valid, 76);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_136;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_136.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[9].V_x_is_usable, 245);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_137 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[9].V_x_is_usable, 245);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_137;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_137.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_137 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[9].V_x_is_usable, 245);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_137;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_137.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[9].V_x_border, 2088204382);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_138 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[9].V_x_border, 2088204382);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_138;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_138.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_138 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[9].V_x_border, 2088204382);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_138;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_138.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[9].V_x_lost, 102);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_139 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[9].V_x_lost, 102);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_139;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_139.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_139 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[9].V_x_lost, 102);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_139;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_139.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[10].V_x_pos.V_m_X, -326.54);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_140 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[10].V_x_pos.V_m_X, -326.54);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_140;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_140.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_140 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[10].V_x_pos.V_m_X, -326.54);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_140;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_140.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[10].V_x_pos.V_m_Y, 162.23);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_141 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[10].V_x_pos.V_m_Y, 162.23);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_141;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_141.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_141 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[10].V_x_pos.V_m_Y, 162.23);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_141;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_141.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[10].V_x_vel.V_m_X, 609.12);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_142 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[10].V_x_vel.V_m_X, 609.12);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_142;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_142.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_142 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[10].V_x_vel.V_m_X, 609.12);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_142;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_142.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[10].V_x_vel.V_m_Y, -478.4);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_143 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[10].V_x_vel.V_m_Y, -478.4);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_143;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_143.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_143 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[10].V_x_vel.V_m_Y, -478.4);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_143;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_143.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[10].V_m_lat_pos_in_lane[0], -581.32);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[10].V_m_lat_pos_in_lane[1], -156.6);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[10].V_m_lat_pos_in_lane[2], 395.32);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[10].V_m_lat_pos_in_lane[3], -490.74);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[10].V_m_lat_pos_in_lane[4], 572.65);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_144 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[10].V_m_lat_pos_in_lane[0], -581.32);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[10].V_m_lat_pos_in_lane[1], -156.6);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[10].V_m_lat_pos_in_lane[2], 395.32);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[10].V_m_lat_pos_in_lane[3], -490.74);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[10].V_m_lat_pos_in_lane[4], 572.65);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_144;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_144.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_144 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[10].V_m_lat_pos_in_lane[0], -581.32);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[10].V_m_lat_pos_in_lane[1], -156.6);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[10].V_m_lat_pos_in_lane[2], 395.32);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[10].V_m_lat_pos_in_lane[3], -490.74);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[10].V_m_lat_pos_in_lane[4], 572.65);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_144;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_144.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[10].V_m_lat_vel_in_lane, -711.57);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_145 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[10].V_m_lat_vel_in_lane, -711.57);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_145;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_145.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_145 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[10].V_m_lat_vel_in_lane, -711.57);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_145;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_145.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[10].V_m_width, -73.5);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_146 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[10].V_m_width, -73.5);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_146;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_146.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_146 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[10].V_m_width, -73.5);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_146;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_146.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[10].V_x_ID, 100384238);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_147 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[10].V_x_ID, 100384238);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_147;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_147.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_147 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[10].V_x_ID, 100384238);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_147;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_147.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[10].V_x_type, 233267534);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_148 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[10].V_x_type, 233267534);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_148;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_148.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_148 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[10].V_x_type, 233267534);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_148;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_148.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[10].V_x_lane, 160);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_149 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[10].V_x_lane, 160);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_149;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_149.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_149 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[10].V_x_lane, 160);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_149;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_149.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[10].V_x_is_valid, 225);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_150 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[10].V_x_is_valid, 225);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_150;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_150.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_150 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[10].V_x_is_valid, 225);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_150;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_150.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[10].V_x_is_usable, 95);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_151 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[10].V_x_is_usable, 95);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_151;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_151.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_151 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[10].V_x_is_usable, 95);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_151;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_151.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[10].V_x_border, 764364523);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_152 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[10].V_x_border, 764364523);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_152;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_152.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_152 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[10].V_x_border, 764364523);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_152;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_152.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[10].V_x_lost, 14);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_153 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[10].V_x_lost, 14);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_153;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_153.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_153 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[10].V_x_lost, 14);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_153;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_153.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[11].V_x_pos.V_m_X, -68.51);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_154 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[11].V_x_pos.V_m_X, -68.51);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_154;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_154.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_154 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[11].V_x_pos.V_m_X, -68.51);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_154;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_154.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[11].V_x_pos.V_m_Y, -421.97);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_155 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[11].V_x_pos.V_m_Y, -421.97);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_155;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_155.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_155 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[11].V_x_pos.V_m_Y, -421.97);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_155;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_155.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[11].V_x_vel.V_m_X, 120.22);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_156 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[11].V_x_vel.V_m_X, 120.22);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_156;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_156.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_156 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[11].V_x_vel.V_m_X, 120.22);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_156;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_156.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[11].V_x_vel.V_m_Y, 278.57);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_157 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[11].V_x_vel.V_m_Y, 278.57);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_157;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_157.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_157 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[11].V_x_vel.V_m_Y, 278.57);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_157;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_157.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[11].V_m_lat_pos_in_lane[0], 814.79);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[11].V_m_lat_pos_in_lane[1], -219.33);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[11].V_m_lat_pos_in_lane[2], 572.96);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[11].V_m_lat_pos_in_lane[3], -885.75);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[11].V_m_lat_pos_in_lane[4], -154.62);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_158 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[11].V_m_lat_pos_in_lane[0], 814.79);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[11].V_m_lat_pos_in_lane[1], -219.33);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[11].V_m_lat_pos_in_lane[2], 572.96);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[11].V_m_lat_pos_in_lane[3], -885.75);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[11].V_m_lat_pos_in_lane[4], -154.62);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_158;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_158.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_158 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[11].V_m_lat_pos_in_lane[0], 814.79);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[11].V_m_lat_pos_in_lane[1], -219.33);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[11].V_m_lat_pos_in_lane[2], 572.96);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[11].V_m_lat_pos_in_lane[3], -885.75);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[11].V_m_lat_pos_in_lane[4], -154.62);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_158;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_158.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[11].V_m_lat_vel_in_lane, 286.51);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_159 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[11].V_m_lat_vel_in_lane, 286.51);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_159;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_159.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_159 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[11].V_m_lat_vel_in_lane, 286.51);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_159;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_159.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[11].V_m_width, 747.64);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_160 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[11].V_m_width, 747.64);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_160;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_160.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_160 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[11].V_m_width, 747.64);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_160;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_160.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[11].V_x_ID, 1289070446);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_161 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[11].V_x_ID, 1289070446);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_161;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_161.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_161 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[11].V_x_ID, 1289070446);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_161;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_161.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[11].V_x_type, 1220285122);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_162 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[11].V_x_type, 1220285122);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_162;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_162.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_162 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[11].V_x_type, 1220285122);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_162;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_162.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[11].V_x_lane, 98);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_163 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[11].V_x_lane, 98);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_163;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_163.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_163 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[11].V_x_lane, 98);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_163;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_163.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[11].V_x_is_valid, 252);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_164 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[11].V_x_is_valid, 252);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_164;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_164.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_164 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[11].V_x_is_valid, 252);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_164;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_164.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[11].V_x_is_usable, 24);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_165 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[11].V_x_is_usable, 24);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_165;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_165.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_165 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[11].V_x_is_usable, 24);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_165;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_165.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[11].V_x_border, 1657483007);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_166 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[11].V_x_border, 1657483007);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_166;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_166.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_166 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[11].V_x_border, 1657483007);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_166;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_166.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[11].V_x_lost, 248);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_167 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[11].V_x_lost, 248);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_167;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_167.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_167 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[11].V_x_lost, 248);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_167;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_167.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[12].V_x_pos.V_m_X, 12.76);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_168 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[12].V_x_pos.V_m_X, 12.76);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_168;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_168.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_168 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[12].V_x_pos.V_m_X, 12.76);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_168;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_168.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[12].V_x_pos.V_m_Y, -551.06);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_169 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[12].V_x_pos.V_m_Y, -551.06);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_169;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_169.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_169 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[12].V_x_pos.V_m_Y, -551.06);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_169;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_169.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[12].V_x_vel.V_m_X, -371.38);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_170 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[12].V_x_vel.V_m_X, -371.38);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_170;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_170.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_170 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[12].V_x_vel.V_m_X, -371.38);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_170;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_170.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[12].V_x_vel.V_m_Y, 426.89);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_171 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[12].V_x_vel.V_m_Y, 426.89);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_171;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_171.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_171 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[12].V_x_vel.V_m_Y, 426.89);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_171;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_171.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[12].V_m_lat_pos_in_lane[0], -958.18);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[12].V_m_lat_pos_in_lane[1], -333.93);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[12].V_m_lat_pos_in_lane[2], 588.93);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[12].V_m_lat_pos_in_lane[3], -453.19);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[12].V_m_lat_pos_in_lane[4], -230.17);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_172 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[12].V_m_lat_pos_in_lane[0], -958.18);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[12].V_m_lat_pos_in_lane[1], -333.93);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[12].V_m_lat_pos_in_lane[2], 588.93);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[12].V_m_lat_pos_in_lane[3], -453.19);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[12].V_m_lat_pos_in_lane[4], -230.17);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_172;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_172.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_172 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[12].V_m_lat_pos_in_lane[0], -958.18);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[12].V_m_lat_pos_in_lane[1], -333.93);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[12].V_m_lat_pos_in_lane[2], 588.93);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[12].V_m_lat_pos_in_lane[3], -453.19);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[12].V_m_lat_pos_in_lane[4], -230.17);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_172;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_172.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[12].V_m_lat_vel_in_lane, 977.33);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_173 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[12].V_m_lat_vel_in_lane, 977.33);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_173;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_173.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_173 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[12].V_m_lat_vel_in_lane, 977.33);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_173;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_173.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[12].V_m_width, -68.26);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_174 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[12].V_m_width, -68.26);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_174;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_174.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_174 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[12].V_m_width, -68.26);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_174;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_174.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[12].V_x_ID, 31885301);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_175 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[12].V_x_ID, 31885301);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_175;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_175.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_175 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[12].V_x_ID, 31885301);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_175;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_175.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[12].V_x_type, 578733301);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_176 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[12].V_x_type, 578733301);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_176;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_176.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_176 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[12].V_x_type, 578733301);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_176;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_176.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[12].V_x_lane, 144);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_177 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[12].V_x_lane, 144);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_177;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_177.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_177 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[12].V_x_lane, 144);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_177;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_177.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[12].V_x_is_valid, 189);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_178 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[12].V_x_is_valid, 189);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_178;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_178.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_178 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[12].V_x_is_valid, 189);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_178;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_178.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[12].V_x_is_usable, 111);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_179 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[12].V_x_is_usable, 111);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_179;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_179.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_179 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[12].V_x_is_usable, 111);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_179;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_179.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[12].V_x_border, 1059966556);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_180 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[12].V_x_border, 1059966556);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_180;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_180.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_180 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[12].V_x_border, 1059966556);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_180;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_180.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[12].V_x_lost, 45);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_181 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[12].V_x_lost, 45);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_181;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_181.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_181 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[12].V_x_lost, 45);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_181;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_181.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[13].V_x_pos.V_m_X, 489.96);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_182 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[13].V_x_pos.V_m_X, 489.96);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_182;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_182.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_182 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[13].V_x_pos.V_m_X, 489.96);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_182;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_182.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[13].V_x_pos.V_m_Y, -596.12);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_183 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[13].V_x_pos.V_m_Y, -596.12);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_183;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_183.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_183 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[13].V_x_pos.V_m_Y, -596.12);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_183;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_183.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[13].V_x_vel.V_m_X, 650.87);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_184 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[13].V_x_vel.V_m_X, 650.87);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_184;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_184.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_184 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[13].V_x_vel.V_m_X, 650.87);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_184;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_184.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[13].V_x_vel.V_m_Y, -430.64);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_185 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[13].V_x_vel.V_m_Y, -430.64);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_185;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_185.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_185 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[13].V_x_vel.V_m_Y, -430.64);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_185;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_185.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[13].V_m_lat_pos_in_lane[0], 370.01);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[13].V_m_lat_pos_in_lane[1], 799.9);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[13].V_m_lat_pos_in_lane[2], 91.18);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[13].V_m_lat_pos_in_lane[3], -527.28);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[13].V_m_lat_pos_in_lane[4], 594.52);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_186 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[13].V_m_lat_pos_in_lane[0], 370.01);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[13].V_m_lat_pos_in_lane[1], 799.9);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[13].V_m_lat_pos_in_lane[2], 91.18);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[13].V_m_lat_pos_in_lane[3], -527.28);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[13].V_m_lat_pos_in_lane[4], 594.52);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_186;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_186.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_186 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[13].V_m_lat_pos_in_lane[0], 370.01);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[13].V_m_lat_pos_in_lane[1], 799.9);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[13].V_m_lat_pos_in_lane[2], 91.18);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[13].V_m_lat_pos_in_lane[3], -527.28);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[13].V_m_lat_pos_in_lane[4], 594.52);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_186;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_186.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[13].V_m_lat_vel_in_lane, 169.64);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_187 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[13].V_m_lat_vel_in_lane, 169.64);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_187;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_187.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_187 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[13].V_m_lat_vel_in_lane, 169.64);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_187;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_187.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[13].V_m_width, -736.75);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_188 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[13].V_m_width, -736.75);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_188;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_188.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_188 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[13].V_m_width, -736.75);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_188;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_188.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[13].V_x_ID, 2083935159);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_189 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[13].V_x_ID, 2083935159);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_189;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_189.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_189 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[13].V_x_ID, 2083935159);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_189;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_189.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[13].V_x_type, 927303419);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_190 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[13].V_x_type, 927303419);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_190;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_190.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_190 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[13].V_x_type, 927303419);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_190;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_190.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[13].V_x_lane, 185);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_191 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[13].V_x_lane, 185);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_191;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_191.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_191 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[13].V_x_lane, 185);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_191;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_191.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[13].V_x_is_valid, 173);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_192 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[13].V_x_is_valid, 173);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_192;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_192.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_192 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[13].V_x_is_valid, 173);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_192;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_192.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[13].V_x_is_usable, 134);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_193 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[13].V_x_is_usable, 134);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_193;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_193.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_193 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[13].V_x_is_usable, 134);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_193;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_193.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[13].V_x_border, 1205223620);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_194 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[13].V_x_border, 1205223620);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_194;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_194.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_194 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[13].V_x_border, 1205223620);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_194;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_194.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[13].V_x_lost, 42);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_195 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[13].V_x_lost, 42);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_195;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_195.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_195 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[13].V_x_lost, 42);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_195;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_195.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[14].V_x_pos.V_m_X, -459.74);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_196 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[14].V_x_pos.V_m_X, -459.74);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_196;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_196.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_196 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[14].V_x_pos.V_m_X, -459.74);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_196;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_196.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[14].V_x_pos.V_m_Y, -358.92);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_197 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[14].V_x_pos.V_m_Y, -358.92);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_197;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_197.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_197 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[14].V_x_pos.V_m_Y, -358.92);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_197;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_197.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[14].V_x_vel.V_m_X, 74.25);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_198 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[14].V_x_vel.V_m_X, 74.25);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_198;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_198.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_198 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[14].V_x_vel.V_m_X, 74.25);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_198;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_198.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[14].V_x_vel.V_m_Y, 717.34);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_199 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[14].V_x_vel.V_m_Y, 717.34);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_199;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_199.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_199 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[14].V_x_vel.V_m_Y, 717.34);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_199;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_199.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[14].V_m_lat_pos_in_lane[0], 324.36);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[14].V_m_lat_pos_in_lane[1], 737.51);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[14].V_m_lat_pos_in_lane[2], -482.83);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[14].V_m_lat_pos_in_lane[3], -460.01);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[14].V_m_lat_pos_in_lane[4], -196.16);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_200 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[14].V_m_lat_pos_in_lane[0], 324.36);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[14].V_m_lat_pos_in_lane[1], 737.51);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[14].V_m_lat_pos_in_lane[2], -482.83);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[14].V_m_lat_pos_in_lane[3], -460.01);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[14].V_m_lat_pos_in_lane[4], -196.16);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_200;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_200.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_200 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[14].V_m_lat_pos_in_lane[0], 324.36);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[14].V_m_lat_pos_in_lane[1], 737.51);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[14].V_m_lat_pos_in_lane[2], -482.83);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[14].V_m_lat_pos_in_lane[3], -460.01);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[14].V_m_lat_pos_in_lane[4], -196.16);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_200;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_200.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[14].V_m_lat_vel_in_lane, -268.02);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_201 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[14].V_m_lat_vel_in_lane, -268.02);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_201;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_201.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_201 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[14].V_m_lat_vel_in_lane, -268.02);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_201;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_201.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[14].V_m_width, 358.19);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_202 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[14].V_m_width, 358.19);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_202;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_202.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_202 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[14].V_m_width, 358.19);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_202;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_202.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[14].V_x_ID, 1983822218);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_203 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[14].V_x_ID, 1983822218);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_203;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_203.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_203 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[14].V_x_ID, 1983822218);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_203;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_203.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[14].V_x_type, 413556308);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_204 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[14].V_x_type, 413556308);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_204;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_204.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_204 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[14].V_x_type, 413556308);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_204;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_204.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[14].V_x_lane, 247);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_205 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[14].V_x_lane, 247);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_205;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_205.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_205 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[14].V_x_lane, 247);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_205;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_205.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[14].V_x_is_valid, 96);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_206 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[14].V_x_is_valid, 96);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_206;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_206.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_206 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[14].V_x_is_valid, 96);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_206;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_206.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[14].V_x_is_usable, 233);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_207 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[14].V_x_is_usable, 233);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_207;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_207.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_207 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[14].V_x_is_usable, 233);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_207;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_207.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[14].V_x_border, 3005629142);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_208 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[14].V_x_border, 3005629142);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_208;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_208.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_208 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[14].V_x_border, 3005629142);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_208;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_208.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[14].V_x_lost, 20);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_209 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[14].V_x_lost, 20);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_209;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_209.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_209 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[14].V_x_lost, 20);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_209;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_209.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[15].V_x_pos.V_m_X, 252.19);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_210 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[15].V_x_pos.V_m_X, 252.19);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_210;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_210.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_210 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[15].V_x_pos.V_m_X, 252.19);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_210;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_210.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[15].V_x_pos.V_m_Y, 423.37);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_211 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[15].V_x_pos.V_m_Y, 423.37);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_211;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_211.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_211 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[15].V_x_pos.V_m_Y, 423.37);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_211;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_211.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[15].V_x_vel.V_m_X, 476.46);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_212 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[15].V_x_vel.V_m_X, 476.46);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_212;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_212.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_212 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[15].V_x_vel.V_m_X, 476.46);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_212;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_212.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[15].V_x_vel.V_m_Y, 654.41);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_213 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[15].V_x_vel.V_m_Y, 654.41);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_213;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_213.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_213 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[15].V_x_vel.V_m_Y, 654.41);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_213;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_213.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[15].V_m_lat_pos_in_lane[0], -517.97);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[15].V_m_lat_pos_in_lane[1], -557.26);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[15].V_m_lat_pos_in_lane[2], -987.14);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[15].V_m_lat_pos_in_lane[3], 107.71);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[15].V_m_lat_pos_in_lane[4], 684.15);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_214 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[15].V_m_lat_pos_in_lane[0], -517.97);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[15].V_m_lat_pos_in_lane[1], -557.26);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[15].V_m_lat_pos_in_lane[2], -987.14);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[15].V_m_lat_pos_in_lane[3], 107.71);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[15].V_m_lat_pos_in_lane[4], 684.15);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_214;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_214.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_214 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[15].V_m_lat_pos_in_lane[0], -517.97);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[15].V_m_lat_pos_in_lane[1], -557.26);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[15].V_m_lat_pos_in_lane[2], -987.14);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[15].V_m_lat_pos_in_lane[3], 107.71);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[15].V_m_lat_pos_in_lane[4], 684.15);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_214;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_214.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[15].V_m_lat_vel_in_lane, -906.59);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_215 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[15].V_m_lat_vel_in_lane, -906.59);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_215;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_215.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_215 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[15].V_m_lat_vel_in_lane, -906.59);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_215;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_215.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[15].V_m_width, 601.37);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_216 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[15].V_m_width, 601.37);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_216;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_216.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_216 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[15].V_m_width, 601.37);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_216;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_216.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[15].V_x_ID, 2066943281);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_217 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[15].V_x_ID, 2066943281);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_217;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_217.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_217 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[15].V_x_ID, 2066943281);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_217;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_217.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[15].V_x_type, 474486799);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_218 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[15].V_x_type, 474486799);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_218;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_218.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_218 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[15].V_x_type, 474486799);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_218;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_218.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[15].V_x_lane, 8);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_219 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[15].V_x_lane, 8);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_219;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_219.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_219 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[15].V_x_lane, 8);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_219;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_219.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[15].V_x_is_valid, 220);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_220 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[15].V_x_is_valid, 220);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_220;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_220.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_220 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[15].V_x_is_valid, 220);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_220;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_220.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[15].V_x_is_usable, 218);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_221 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[15].V_x_is_usable, 218);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_221;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_221.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_221 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[15].V_x_is_usable, 218);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_221;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_221.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[15].V_x_border, 4262029909);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_222 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[15].V_x_border, 4262029909);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_222;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_222.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_222 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[15].V_x_border, 4262029909);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_222;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_222.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[15].V_x_lost, 94);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_223 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[15].V_x_lost, 94);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_223;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_223.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_223 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[15].V_x_lost, 94);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_223;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_223.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[16].V_x_pos.V_m_X, 585.23);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_224 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[16].V_x_pos.V_m_X, 585.23);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_224;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_224.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_224 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[16].V_x_pos.V_m_X, 585.23);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_224;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_224.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[16].V_x_pos.V_m_Y, -789.11);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_225 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[16].V_x_pos.V_m_Y, -789.11);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_225;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_225.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_225 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[16].V_x_pos.V_m_Y, -789.11);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_225;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_225.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[16].V_x_vel.V_m_X, 742.36);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_226 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[16].V_x_vel.V_m_X, 742.36);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_226;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_226.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_226 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[16].V_x_vel.V_m_X, 742.36);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_226;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_226.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[16].V_x_vel.V_m_Y, 230.34);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_227 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[16].V_x_vel.V_m_Y, 230.34);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_227;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_227.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_227 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[16].V_x_vel.V_m_Y, 230.34);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_227;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_227.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[16].V_m_lat_pos_in_lane[0], -732.03);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[16].V_m_lat_pos_in_lane[1], 274.48);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[16].V_m_lat_pos_in_lane[2], 859.69);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[16].V_m_lat_pos_in_lane[3], 551.26);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[16].V_m_lat_pos_in_lane[4], -865.22);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_228 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[16].V_m_lat_pos_in_lane[0], -732.03);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[16].V_m_lat_pos_in_lane[1], 274.48);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[16].V_m_lat_pos_in_lane[2], 859.69);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[16].V_m_lat_pos_in_lane[3], 551.26);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[16].V_m_lat_pos_in_lane[4], -865.22);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_228;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_228.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_228 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[16].V_m_lat_pos_in_lane[0], -732.03);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[16].V_m_lat_pos_in_lane[1], 274.48);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[16].V_m_lat_pos_in_lane[2], 859.69);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[16].V_m_lat_pos_in_lane[3], 551.26);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[16].V_m_lat_pos_in_lane[4], -865.22);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_228;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_228.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[16].V_m_lat_vel_in_lane, -342.04);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_229 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[16].V_m_lat_vel_in_lane, -342.04);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_229;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_229.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_229 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[16].V_m_lat_vel_in_lane, -342.04);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_229;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_229.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[16].V_m_width, 500.51);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_230 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[16].V_m_width, 500.51);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_230;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_230.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_230 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[16].V_m_width, 500.51);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_230;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_230.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[16].V_x_ID, 1465255324);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_231 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[16].V_x_ID, 1465255324);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_231;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_231.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_231 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[16].V_x_ID, 1465255324);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_231;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_231.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[16].V_x_type, 53307803);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_232 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[16].V_x_type, 53307803);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_232;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_232.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_232 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[16].V_x_type, 53307803);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_232;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_232.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[16].V_x_lane, 112);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_233 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[16].V_x_lane, 112);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_233;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_233.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_233 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[16].V_x_lane, 112);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_233;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_233.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[16].V_x_is_valid, 100);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_234 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[16].V_x_is_valid, 100);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_234;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_234.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_234 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[16].V_x_is_valid, 100);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_234;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_234.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[16].V_x_is_usable, 253);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_235 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[16].V_x_is_usable, 253);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_235;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_235.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_235 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[16].V_x_is_usable, 253);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_235;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_235.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[16].V_x_border, 3608941256);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_236 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[16].V_x_border, 3608941256);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_236;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_236.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_236 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[16].V_x_border, 3608941256);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_236;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_236.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[16].V_x_lost, 61);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_237 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[16].V_x_lost, 61);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_237;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_237.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_237 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[16].V_x_lost, 61);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_237;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_237.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[17].V_x_pos.V_m_X, -917.14);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_238 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[17].V_x_pos.V_m_X, -917.14);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_238;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_238.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_238 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[17].V_x_pos.V_m_X, -917.14);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_238;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_238.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[17].V_x_pos.V_m_Y, 467.92);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_239 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[17].V_x_pos.V_m_Y, 467.92);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_239;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_239.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_239 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[17].V_x_pos.V_m_Y, 467.92);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_239;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_239.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[17].V_x_vel.V_m_X, -527.99);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_240 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[17].V_x_vel.V_m_X, -527.99);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_240;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_240.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_240 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[17].V_x_vel.V_m_X, -527.99);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_240;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_240.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[17].V_x_vel.V_m_Y, -66.34);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_241 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[17].V_x_vel.V_m_Y, -66.34);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_241;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_241.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_241 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[17].V_x_vel.V_m_Y, -66.34);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_241;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_241.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[17].V_m_lat_pos_in_lane[0], -412.29);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[17].V_m_lat_pos_in_lane[1], 715.82);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[17].V_m_lat_pos_in_lane[2], 397.75);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[17].V_m_lat_pos_in_lane[3], -651.36);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[17].V_m_lat_pos_in_lane[4], 743.62);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_242 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[17].V_m_lat_pos_in_lane[0], -412.29);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[17].V_m_lat_pos_in_lane[1], 715.82);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[17].V_m_lat_pos_in_lane[2], 397.75);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[17].V_m_lat_pos_in_lane[3], -651.36);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[17].V_m_lat_pos_in_lane[4], 743.62);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_242;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_242.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_242 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[17].V_m_lat_pos_in_lane[0], -412.29);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[17].V_m_lat_pos_in_lane[1], 715.82);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[17].V_m_lat_pos_in_lane[2], 397.75);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[17].V_m_lat_pos_in_lane[3], -651.36);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[17].V_m_lat_pos_in_lane[4], 743.62);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_242;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_242.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[17].V_m_lat_vel_in_lane, 276.54);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_243 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[17].V_m_lat_vel_in_lane, 276.54);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_243;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_243.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_243 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[17].V_m_lat_vel_in_lane, 276.54);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_243;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_243.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[17].V_m_width, -129.19);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_244 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[17].V_m_width, -129.19);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_244;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_244.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_244 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[17].V_m_width, -129.19);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_244;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_244.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[17].V_x_ID, 3080427889);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_245 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[17].V_x_ID, 3080427889);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_245;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_245.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_245 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[17].V_x_ID, 3080427889);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_245;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_245.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[17].V_x_type, 2753983265);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_246 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[17].V_x_type, 2753983265);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_246;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_246.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_246 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[17].V_x_type, 2753983265);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_246;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_246.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[17].V_x_lane, 162);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_247 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[17].V_x_lane, 162);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_247;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_247.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_247 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[17].V_x_lane, 162);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_247;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_247.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[17].V_x_is_valid, 150);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_248 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[17].V_x_is_valid, 150);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_248;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_248.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_248 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[17].V_x_is_valid, 150);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_248;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_248.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[17].V_x_is_usable, 100);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_249 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[17].V_x_is_usable, 100);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_249;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_249.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_249 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[17].V_x_is_usable, 100);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_249;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_249.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[17].V_x_border, 2545248974);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_250 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[17].V_x_border, 2545248974);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_250;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_250.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_250 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[17].V_x_border, 2545248974);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_250;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_250.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[17].V_x_lost, 161);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_251 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[17].V_x_lost, 161);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_251;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_251.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_251 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[17].V_x_lost, 161);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_251;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_251.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[18].V_x_pos.V_m_X, -963.37);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_252 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[18].V_x_pos.V_m_X, -963.37);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_252;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_252.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_252 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[18].V_x_pos.V_m_X, -963.37);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_252;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_252.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[18].V_x_pos.V_m_Y, 43.27);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_253 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[18].V_x_pos.V_m_Y, 43.27);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_253;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_253.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_253 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[18].V_x_pos.V_m_Y, 43.27);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_253;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_253.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[18].V_x_vel.V_m_X, 126.22);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_254 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[18].V_x_vel.V_m_X, 126.22);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_254;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_254.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_254 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[18].V_x_vel.V_m_X, 126.22);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_254;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_254.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[18].V_x_vel.V_m_Y, -296.3);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_255 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[18].V_x_vel.V_m_Y, -296.3);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_255;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_255.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_255 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[18].V_x_vel.V_m_Y, -296.3);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_255;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_255.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[18].V_m_lat_pos_in_lane[0], 461.4);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[18].V_m_lat_pos_in_lane[1], -7.61);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[18].V_m_lat_pos_in_lane[2], -890.54);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[18].V_m_lat_pos_in_lane[3], 939.85);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[18].V_m_lat_pos_in_lane[4], -819.21);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_256 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[18].V_m_lat_pos_in_lane[0], 461.4);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[18].V_m_lat_pos_in_lane[1], -7.61);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[18].V_m_lat_pos_in_lane[2], -890.54);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[18].V_m_lat_pos_in_lane[3], 939.85);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[18].V_m_lat_pos_in_lane[4], -819.21);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_256;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_256.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_256 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[18].V_m_lat_pos_in_lane[0], 461.4);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[18].V_m_lat_pos_in_lane[1], -7.61);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[18].V_m_lat_pos_in_lane[2], -890.54);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[18].V_m_lat_pos_in_lane[3], 939.85);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[18].V_m_lat_pos_in_lane[4], -819.21);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_256;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_256.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[18].V_m_lat_vel_in_lane, 964.86);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_257 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[18].V_m_lat_vel_in_lane, 964.86);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_257;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_257.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_257 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[18].V_m_lat_vel_in_lane, 964.86);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_257;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_257.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[18].V_m_width, 449.1);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_258 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[18].V_m_width, 449.1);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_258;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_258.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_258 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[18].V_m_width, 449.1);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_258;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_258.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[18].V_x_ID, 3479662021);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_259 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[18].V_x_ID, 3479662021);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_259;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_259.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_259 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[18].V_x_ID, 3479662021);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_259;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_259.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[18].V_x_type, 4121488970);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_260 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[18].V_x_type, 4121488970);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_260;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_260.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_260 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[18].V_x_type, 4121488970);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_260;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_260.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[18].V_x_lane, 78);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_261 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[18].V_x_lane, 78);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_261;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_261.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_261 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[18].V_x_lane, 78);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_261;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_261.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[18].V_x_is_valid, 69);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_262 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[18].V_x_is_valid, 69);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_262;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_262.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_262 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[18].V_x_is_valid, 69);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_262;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_262.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[18].V_x_is_usable, 50);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_263 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[18].V_x_is_usable, 50);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_263;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_263.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_263 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[18].V_x_is_usable, 50);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_263;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_263.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[18].V_x_border, 70770191);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_264 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[18].V_x_border, 70770191);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_264;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_264.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_264 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[18].V_x_border, 70770191);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_264;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_264.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[18].V_x_lost, 70);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_265 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[18].V_x_lost, 70);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_265;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_265.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_265 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[18].V_x_lost, 70);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_265;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_265.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[19].V_x_pos.V_m_X, 31.7);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_266 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[19].V_x_pos.V_m_X, 31.7);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_266;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_266.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_266 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[19].V_x_pos.V_m_X, 31.7);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_266;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_266.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[19].V_x_pos.V_m_Y, 878.3);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_267 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[19].V_x_pos.V_m_Y, 878.3);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_267;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_267.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_267 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[19].V_x_pos.V_m_Y, 878.3);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_267;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_267.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[19].V_x_vel.V_m_X, -821.51);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_268 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[19].V_x_vel.V_m_X, -821.51);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_268;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_268.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_268 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[19].V_x_vel.V_m_X, -821.51);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_268;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_268.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[19].V_x_vel.V_m_Y, -664.71);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_269 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[19].V_x_vel.V_m_Y, -664.71);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_269;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_269.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_269 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[19].V_x_vel.V_m_Y, -664.71);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_269;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_269.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[19].V_m_lat_pos_in_lane[0], 144.85);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[19].V_m_lat_pos_in_lane[1], -4.73);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[19].V_m_lat_pos_in_lane[2], -951.04);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[19].V_m_lat_pos_in_lane[3], 841.57);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[19].V_m_lat_pos_in_lane[4], -12.1);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_270 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[19].V_m_lat_pos_in_lane[0], 144.85);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[19].V_m_lat_pos_in_lane[1], -4.73);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[19].V_m_lat_pos_in_lane[2], -951.04);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[19].V_m_lat_pos_in_lane[3], 841.57);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[19].V_m_lat_pos_in_lane[4], -12.1);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_270;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_270.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_270 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[19].V_m_lat_pos_in_lane[0], 144.85);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[19].V_m_lat_pos_in_lane[1], -4.73);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[19].V_m_lat_pos_in_lane[2], -951.04);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[19].V_m_lat_pos_in_lane[3], 841.57);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[19].V_m_lat_pos_in_lane[4], -12.1);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_270;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_270.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[19].V_m_lat_vel_in_lane, 213.85);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_271 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[19].V_m_lat_vel_in_lane, 213.85);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_271;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_271.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_271 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[19].V_m_lat_vel_in_lane, 213.85);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_271;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_271.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[19].V_m_width, 458.15);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_272 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[19].V_m_width, 458.15);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_272;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_272.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_272 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_FLOAT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[19].V_m_width, 458.15);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_272;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_272.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[19].V_x_ID, 3064053841);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_273 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[19].V_x_ID, 3064053841);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_273;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_273.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_273 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[19].V_x_ID, 3064053841);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_273;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_273.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[19].V_x_type, 1037871109);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_274 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[19].V_x_type, 1037871109);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_274;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_274.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_274 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[19].V_x_type, 1037871109);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_274;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_274.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[19].V_x_lane, 196);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_275 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[19].V_x_lane, 196);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_275;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_275.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_275 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[19].V_x_lane, 196);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_275;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_275.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[19].V_x_is_valid, 234);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_276 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[19].V_x_is_valid, 234);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_276;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_276.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_276 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[19].V_x_is_valid, 234);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_276;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_276.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[19].V_x_is_usable, 196);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_277 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[19].V_x_is_usable, 196);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_277;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_277.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_277 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[19].V_x_is_usable, 196);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_277;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_277.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[19].V_x_border, 23988715);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_278 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[19].V_x_border, 23988715);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_278;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_278.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_278 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[19].V_x_border, 23988715);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_278;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_278.verify();

    EXPECT_EQ(gOEM_SWC_C2_2UVehStatus_In_50DataSet.mConc.V_x_surround_obj_right_t.V_x_surround_obj_right[19].V_x_lost, 158);
    struct _func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_279 {
        static void verify(void) {
#include "Rte_Wrapper_AutoLCPossibilityJdg.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[19].V_x_lost, 158);
        }
    } func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_279;
    func_V_x_surround_obj_right_t_AutoLCPossibilityJdg_279.verify();
    struct _func_V_x_surround_obj_right_t_ObjectSelectionDM_279 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionDM.h"
            V_x_surround_obj_right_t tmp_surround_obj_right_t;
            Rte_Read_V_x_surround_obj_right_t_V_x_surround_obj_right_t(&tmp_surround_obj_right_t);
            EXPECT_EQ(tmp_surround_obj_right_t.V_x_surround_obj_right[19].V_x_lost, 158);
        }
    } func_V_x_surround_obj_right_t_ObjectSelectionDM_279;
    func_V_x_surround_obj_right_t_ObjectSelectionDM_279.verify();

}
