#include <limits.h>
#include <float.h>
#include "gtest/gtest.h"
#include "Rte_Union.h"
#include "Platform_Types.h"

extern UAutoLCPossibilityJdgDataSet gOEM_SWC_C2_2UAutoLCPossibilityJdgDataSet;
extern UObjectSelectionDMDataSet gOEM_SWC_C2_2UObjectSelectionDMDataSet;
extern UVehStatus_In_50DataSet gOEM_SWC_C2_2UVehStatus_In_50DataSet;

void C2_2_o2o_noncache_max_verify_AutoLCPossibilityJdg(void)
{
    V_x_AutoLCPossibilityJdgOutput tmp_AutoLCPossibilityJdgOutput;

    /* V_x_AutoLCPossibilityJdgOutput*/
    extern UAutoLCPossibilityJdgDataSet gOEM_SWC_C1_1UAutoLCPossibilityJdgDataSet;
    EXPECT_EQ(gOEM_SWC_C2_2UAutoLCPossibilityJdgDataSet.mConc.V_x_AutoLCPossibilityJdgOutput.V_x_st_Output_DynamicConflJdgDiag.F_x_Dcj_ObjLeft, 255);
    EXPECT_EQ(gOEM_SWC_C1_1UAutoLCPossibilityJdgDataSet.mConc.V_x_AutoLCPossibilityJdgOutput.V_x_st_Output_DynamicConflJdgDiag.F_x_Dcj_ObjLeft, 255);
    struct _func_V_x_AutoLCPossibilityJdgOutput_VehStatus_In_0 {
        static void verify(void) {
#include "Rte_Wrapper_VehStatus_In.h"
            V_x_AutoLCPossibilityJdgOutput tmp_AutoLCPossibilityJdgOutput;
            Rte_Read_V_x_AutoLCPossibilityJdgOutput_V_x_AutoLCPossibilityJdgOutput(&tmp_AutoLCPossibilityJdgOutput);
            EXPECT_EQ(tmp_AutoLCPossibilityJdgOutput.V_x_st_Output_DynamicConflJdgDiag.F_x_Dcj_ObjLeft, 255);
        }
    } func_V_x_AutoLCPossibilityJdgOutput_VehStatus_In_0;
    func_V_x_AutoLCPossibilityJdgOutput_VehStatus_In_0.verify();

    extern UAutoLCPossibilityJdgDataSet gOEM_SWC_C1_1UAutoLCPossibilityJdgDataSet;
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UAutoLCPossibilityJdgDataSet.mConc.V_x_AutoLCPossibilityJdgOutput.V_x_st_Output_DynamicConflJdgDiag.V_m_Dcj_ObjLeftPosX, 340282346638528897590636046441678635008);
    EXPECT_FLOAT_EQ(gOEM_SWC_C1_1UAutoLCPossibilityJdgDataSet.mConc.V_x_AutoLCPossibilityJdgOutput.V_x_st_Output_DynamicConflJdgDiag.V_m_Dcj_ObjLeftPosX, 340282346638528897590636046441678635008);
    struct _func_V_x_AutoLCPossibilityJdgOutput_VehStatus_In_1 {
        static void verify(void) {
#include "Rte_Wrapper_VehStatus_In.h"
            V_x_AutoLCPossibilityJdgOutput tmp_AutoLCPossibilityJdgOutput;
            Rte_Read_V_x_AutoLCPossibilityJdgOutput_V_x_AutoLCPossibilityJdgOutput(&tmp_AutoLCPossibilityJdgOutput);
            EXPECT_FLOAT_EQ(tmp_AutoLCPossibilityJdgOutput.V_x_st_Output_DynamicConflJdgDiag.V_m_Dcj_ObjLeftPosX, 340282346638528897590636046441678635008);
        }
    } func_V_x_AutoLCPossibilityJdgOutput_VehStatus_In_1;
    func_V_x_AutoLCPossibilityJdgOutput_VehStatus_In_1.verify();

    extern UAutoLCPossibilityJdgDataSet gOEM_SWC_C1_1UAutoLCPossibilityJdgDataSet;
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UAutoLCPossibilityJdgDataSet.mConc.V_x_AutoLCPossibilityJdgOutput.V_x_st_Output_DynamicConflJdgDiag.V_m_Dcj_ObjLeftPosY, 340282346638528897590636046441678635008);
    EXPECT_FLOAT_EQ(gOEM_SWC_C1_1UAutoLCPossibilityJdgDataSet.mConc.V_x_AutoLCPossibilityJdgOutput.V_x_st_Output_DynamicConflJdgDiag.V_m_Dcj_ObjLeftPosY, 340282346638528897590636046441678635008);
    struct _func_V_x_AutoLCPossibilityJdgOutput_VehStatus_In_2 {
        static void verify(void) {
#include "Rte_Wrapper_VehStatus_In.h"
            V_x_AutoLCPossibilityJdgOutput tmp_AutoLCPossibilityJdgOutput;
            Rte_Read_V_x_AutoLCPossibilityJdgOutput_V_x_AutoLCPossibilityJdgOutput(&tmp_AutoLCPossibilityJdgOutput);
            EXPECT_FLOAT_EQ(tmp_AutoLCPossibilityJdgOutput.V_x_st_Output_DynamicConflJdgDiag.V_m_Dcj_ObjLeftPosY, 340282346638528897590636046441678635008);
        }
    } func_V_x_AutoLCPossibilityJdgOutput_VehStatus_In_2;
    func_V_x_AutoLCPossibilityJdgOutput_VehStatus_In_2.verify();

    extern UAutoLCPossibilityJdgDataSet gOEM_SWC_C1_1UAutoLCPossibilityJdgDataSet;
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UAutoLCPossibilityJdgDataSet.mConc.V_x_AutoLCPossibilityJdgOutput.V_x_st_Output_DynamicConflJdgDiag.V_mps_Dcj_ObjLeftVelX, 340282346638528897590636046441678635008);
    EXPECT_FLOAT_EQ(gOEM_SWC_C1_1UAutoLCPossibilityJdgDataSet.mConc.V_x_AutoLCPossibilityJdgOutput.V_x_st_Output_DynamicConflJdgDiag.V_mps_Dcj_ObjLeftVelX, 340282346638528897590636046441678635008);
    struct _func_V_x_AutoLCPossibilityJdgOutput_VehStatus_In_3 {
        static void verify(void) {
#include "Rte_Wrapper_VehStatus_In.h"
            V_x_AutoLCPossibilityJdgOutput tmp_AutoLCPossibilityJdgOutput;
            Rte_Read_V_x_AutoLCPossibilityJdgOutput_V_x_AutoLCPossibilityJdgOutput(&tmp_AutoLCPossibilityJdgOutput);
            EXPECT_FLOAT_EQ(tmp_AutoLCPossibilityJdgOutput.V_x_st_Output_DynamicConflJdgDiag.V_mps_Dcj_ObjLeftVelX, 340282346638528897590636046441678635008);
        }
    } func_V_x_AutoLCPossibilityJdgOutput_VehStatus_In_3;
    func_V_x_AutoLCPossibilityJdgOutput_VehStatus_In_3.verify();

    extern UAutoLCPossibilityJdgDataSet gOEM_SWC_C1_1UAutoLCPossibilityJdgDataSet;
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UAutoLCPossibilityJdgDataSet.mConc.V_x_AutoLCPossibilityJdgOutput.V_x_st_Output_DynamicConflJdgDiag.V_mps_Dcj_ObjLeftVelY, 340282346638528897590636046441678635008);
    EXPECT_FLOAT_EQ(gOEM_SWC_C1_1UAutoLCPossibilityJdgDataSet.mConc.V_x_AutoLCPossibilityJdgOutput.V_x_st_Output_DynamicConflJdgDiag.V_mps_Dcj_ObjLeftVelY, 340282346638528897590636046441678635008);
    struct _func_V_x_AutoLCPossibilityJdgOutput_VehStatus_In_4 {
        static void verify(void) {
#include "Rte_Wrapper_VehStatus_In.h"
            V_x_AutoLCPossibilityJdgOutput tmp_AutoLCPossibilityJdgOutput;
            Rte_Read_V_x_AutoLCPossibilityJdgOutput_V_x_AutoLCPossibilityJdgOutput(&tmp_AutoLCPossibilityJdgOutput);
            EXPECT_FLOAT_EQ(tmp_AutoLCPossibilityJdgOutput.V_x_st_Output_DynamicConflJdgDiag.V_mps_Dcj_ObjLeftVelY, 340282346638528897590636046441678635008);
        }
    } func_V_x_AutoLCPossibilityJdgOutput_VehStatus_In_4;
    func_V_x_AutoLCPossibilityJdgOutput_VehStatus_In_4.verify();

    extern UAutoLCPossibilityJdgDataSet gOEM_SWC_C1_1UAutoLCPossibilityJdgDataSet;
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UAutoLCPossibilityJdgDataSet.mConc.V_x_AutoLCPossibilityJdgOutput.V_x_st_Output_DynamicConflJdgDiag.V_m_Dcj_ObjLeftGapF, 340282346638528897590636046441678635008);
    EXPECT_FLOAT_EQ(gOEM_SWC_C1_1UAutoLCPossibilityJdgDataSet.mConc.V_x_AutoLCPossibilityJdgOutput.V_x_st_Output_DynamicConflJdgDiag.V_m_Dcj_ObjLeftGapF, 340282346638528897590636046441678635008);
    struct _func_V_x_AutoLCPossibilityJdgOutput_VehStatus_In_5 {
        static void verify(void) {
#include "Rte_Wrapper_VehStatus_In.h"
            V_x_AutoLCPossibilityJdgOutput tmp_AutoLCPossibilityJdgOutput;
            Rte_Read_V_x_AutoLCPossibilityJdgOutput_V_x_AutoLCPossibilityJdgOutput(&tmp_AutoLCPossibilityJdgOutput);
            EXPECT_FLOAT_EQ(tmp_AutoLCPossibilityJdgOutput.V_x_st_Output_DynamicConflJdgDiag.V_m_Dcj_ObjLeftGapF, 340282346638528897590636046441678635008);
        }
    } func_V_x_AutoLCPossibilityJdgOutput_VehStatus_In_5;
    func_V_x_AutoLCPossibilityJdgOutput_VehStatus_In_5.verify();

    extern UAutoLCPossibilityJdgDataSet gOEM_SWC_C1_1UAutoLCPossibilityJdgDataSet;
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UAutoLCPossibilityJdgDataSet.mConc.V_x_AutoLCPossibilityJdgOutput.V_x_st_Output_DynamicConflJdgDiag.V_m_Dcj_ObjLeftGapR, 340282346638528897590636046441678635008);
    EXPECT_FLOAT_EQ(gOEM_SWC_C1_1UAutoLCPossibilityJdgDataSet.mConc.V_x_AutoLCPossibilityJdgOutput.V_x_st_Output_DynamicConflJdgDiag.V_m_Dcj_ObjLeftGapR, 340282346638528897590636046441678635008);
    struct _func_V_x_AutoLCPossibilityJdgOutput_VehStatus_In_6 {
        static void verify(void) {
#include "Rte_Wrapper_VehStatus_In.h"
            V_x_AutoLCPossibilityJdgOutput tmp_AutoLCPossibilityJdgOutput;
            Rte_Read_V_x_AutoLCPossibilityJdgOutput_V_x_AutoLCPossibilityJdgOutput(&tmp_AutoLCPossibilityJdgOutput);
            EXPECT_FLOAT_EQ(tmp_AutoLCPossibilityJdgOutput.V_x_st_Output_DynamicConflJdgDiag.V_m_Dcj_ObjLeftGapR, 340282346638528897590636046441678635008);
        }
    } func_V_x_AutoLCPossibilityJdgOutput_VehStatus_In_6;
    func_V_x_AutoLCPossibilityJdgOutput_VehStatus_In_6.verify();

    extern UAutoLCPossibilityJdgDataSet gOEM_SWC_C1_1UAutoLCPossibilityJdgDataSet;
    EXPECT_EQ(gOEM_SWC_C2_2UAutoLCPossibilityJdgDataSet.mConc.V_x_AutoLCPossibilityJdgOutput.V_x_st_Output_DynamicConflJdgDiag.V_x_Dcj_ObjLeftNum, 255);
    EXPECT_EQ(gOEM_SWC_C1_1UAutoLCPossibilityJdgDataSet.mConc.V_x_AutoLCPossibilityJdgOutput.V_x_st_Output_DynamicConflJdgDiag.V_x_Dcj_ObjLeftNum, 255);
    struct _func_V_x_AutoLCPossibilityJdgOutput_VehStatus_In_7 {
        static void verify(void) {
#include "Rte_Wrapper_VehStatus_In.h"
            V_x_AutoLCPossibilityJdgOutput tmp_AutoLCPossibilityJdgOutput;
            Rte_Read_V_x_AutoLCPossibilityJdgOutput_V_x_AutoLCPossibilityJdgOutput(&tmp_AutoLCPossibilityJdgOutput);
            EXPECT_EQ(tmp_AutoLCPossibilityJdgOutput.V_x_st_Output_DynamicConflJdgDiag.V_x_Dcj_ObjLeftNum, 255);
        }
    } func_V_x_AutoLCPossibilityJdgOutput_VehStatus_In_7;
    func_V_x_AutoLCPossibilityJdgOutput_VehStatus_In_7.verify();

    extern UAutoLCPossibilityJdgDataSet gOEM_SWC_C1_1UAutoLCPossibilityJdgDataSet;
    EXPECT_EQ(gOEM_SWC_C2_2UAutoLCPossibilityJdgDataSet.mConc.V_x_AutoLCPossibilityJdgOutput.V_x_st_Output_DynamicConflJdgDiag.V_x_Dcj_ObjRight, 255);
    EXPECT_EQ(gOEM_SWC_C1_1UAutoLCPossibilityJdgDataSet.mConc.V_x_AutoLCPossibilityJdgOutput.V_x_st_Output_DynamicConflJdgDiag.V_x_Dcj_ObjRight, 255);
    struct _func_V_x_AutoLCPossibilityJdgOutput_VehStatus_In_8 {
        static void verify(void) {
#include "Rte_Wrapper_VehStatus_In.h"
            V_x_AutoLCPossibilityJdgOutput tmp_AutoLCPossibilityJdgOutput;
            Rte_Read_V_x_AutoLCPossibilityJdgOutput_V_x_AutoLCPossibilityJdgOutput(&tmp_AutoLCPossibilityJdgOutput);
            EXPECT_EQ(tmp_AutoLCPossibilityJdgOutput.V_x_st_Output_DynamicConflJdgDiag.V_x_Dcj_ObjRight, 255);
        }
    } func_V_x_AutoLCPossibilityJdgOutput_VehStatus_In_8;
    func_V_x_AutoLCPossibilityJdgOutput_VehStatus_In_8.verify();

    extern UAutoLCPossibilityJdgDataSet gOEM_SWC_C1_1UAutoLCPossibilityJdgDataSet;
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UAutoLCPossibilityJdgDataSet.mConc.V_x_AutoLCPossibilityJdgOutput.V_x_st_Output_DynamicConflJdgDiag.V_m_Dcj_ObjRightPosX, 340282346638528897590636046441678635008);
    EXPECT_FLOAT_EQ(gOEM_SWC_C1_1UAutoLCPossibilityJdgDataSet.mConc.V_x_AutoLCPossibilityJdgOutput.V_x_st_Output_DynamicConflJdgDiag.V_m_Dcj_ObjRightPosX, 340282346638528897590636046441678635008);
    struct _func_V_x_AutoLCPossibilityJdgOutput_VehStatus_In_9 {
        static void verify(void) {
#include "Rte_Wrapper_VehStatus_In.h"
            V_x_AutoLCPossibilityJdgOutput tmp_AutoLCPossibilityJdgOutput;
            Rte_Read_V_x_AutoLCPossibilityJdgOutput_V_x_AutoLCPossibilityJdgOutput(&tmp_AutoLCPossibilityJdgOutput);
            EXPECT_FLOAT_EQ(tmp_AutoLCPossibilityJdgOutput.V_x_st_Output_DynamicConflJdgDiag.V_m_Dcj_ObjRightPosX, 340282346638528897590636046441678635008);
        }
    } func_V_x_AutoLCPossibilityJdgOutput_VehStatus_In_9;
    func_V_x_AutoLCPossibilityJdgOutput_VehStatus_In_9.verify();

    extern UAutoLCPossibilityJdgDataSet gOEM_SWC_C1_1UAutoLCPossibilityJdgDataSet;
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UAutoLCPossibilityJdgDataSet.mConc.V_x_AutoLCPossibilityJdgOutput.V_x_st_Output_DynamicConflJdgDiag.V_m_Dcj_ObjRightPosY, 340282346638528897590636046441678635008);
    EXPECT_FLOAT_EQ(gOEM_SWC_C1_1UAutoLCPossibilityJdgDataSet.mConc.V_x_AutoLCPossibilityJdgOutput.V_x_st_Output_DynamicConflJdgDiag.V_m_Dcj_ObjRightPosY, 340282346638528897590636046441678635008);
    struct _func_V_x_AutoLCPossibilityJdgOutput_VehStatus_In_10 {
        static void verify(void) {
#include "Rte_Wrapper_VehStatus_In.h"
            V_x_AutoLCPossibilityJdgOutput tmp_AutoLCPossibilityJdgOutput;
            Rte_Read_V_x_AutoLCPossibilityJdgOutput_V_x_AutoLCPossibilityJdgOutput(&tmp_AutoLCPossibilityJdgOutput);
            EXPECT_FLOAT_EQ(tmp_AutoLCPossibilityJdgOutput.V_x_st_Output_DynamicConflJdgDiag.V_m_Dcj_ObjRightPosY, 340282346638528897590636046441678635008);
        }
    } func_V_x_AutoLCPossibilityJdgOutput_VehStatus_In_10;
    func_V_x_AutoLCPossibilityJdgOutput_VehStatus_In_10.verify();

    extern UAutoLCPossibilityJdgDataSet gOEM_SWC_C1_1UAutoLCPossibilityJdgDataSet;
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UAutoLCPossibilityJdgDataSet.mConc.V_x_AutoLCPossibilityJdgOutput.V_x_st_Output_DynamicConflJdgDiag.V_mps_Dcj_ObjRightVelX, 340282346638528897590636046441678635008);
    EXPECT_FLOAT_EQ(gOEM_SWC_C1_1UAutoLCPossibilityJdgDataSet.mConc.V_x_AutoLCPossibilityJdgOutput.V_x_st_Output_DynamicConflJdgDiag.V_mps_Dcj_ObjRightVelX, 340282346638528897590636046441678635008);
    struct _func_V_x_AutoLCPossibilityJdgOutput_VehStatus_In_11 {
        static void verify(void) {
#include "Rte_Wrapper_VehStatus_In.h"
            V_x_AutoLCPossibilityJdgOutput tmp_AutoLCPossibilityJdgOutput;
            Rte_Read_V_x_AutoLCPossibilityJdgOutput_V_x_AutoLCPossibilityJdgOutput(&tmp_AutoLCPossibilityJdgOutput);
            EXPECT_FLOAT_EQ(tmp_AutoLCPossibilityJdgOutput.V_x_st_Output_DynamicConflJdgDiag.V_mps_Dcj_ObjRightVelX, 340282346638528897590636046441678635008);
        }
    } func_V_x_AutoLCPossibilityJdgOutput_VehStatus_In_11;
    func_V_x_AutoLCPossibilityJdgOutput_VehStatus_In_11.verify();

    extern UAutoLCPossibilityJdgDataSet gOEM_SWC_C1_1UAutoLCPossibilityJdgDataSet;
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UAutoLCPossibilityJdgDataSet.mConc.V_x_AutoLCPossibilityJdgOutput.V_x_st_Output_DynamicConflJdgDiag.V_mps_Dcj_ObjRightVelY, 340282346638528897590636046441678635008);
    EXPECT_FLOAT_EQ(gOEM_SWC_C1_1UAutoLCPossibilityJdgDataSet.mConc.V_x_AutoLCPossibilityJdgOutput.V_x_st_Output_DynamicConflJdgDiag.V_mps_Dcj_ObjRightVelY, 340282346638528897590636046441678635008);
    struct _func_V_x_AutoLCPossibilityJdgOutput_VehStatus_In_12 {
        static void verify(void) {
#include "Rte_Wrapper_VehStatus_In.h"
            V_x_AutoLCPossibilityJdgOutput tmp_AutoLCPossibilityJdgOutput;
            Rte_Read_V_x_AutoLCPossibilityJdgOutput_V_x_AutoLCPossibilityJdgOutput(&tmp_AutoLCPossibilityJdgOutput);
            EXPECT_FLOAT_EQ(tmp_AutoLCPossibilityJdgOutput.V_x_st_Output_DynamicConflJdgDiag.V_mps_Dcj_ObjRightVelY, 340282346638528897590636046441678635008);
        }
    } func_V_x_AutoLCPossibilityJdgOutput_VehStatus_In_12;
    func_V_x_AutoLCPossibilityJdgOutput_VehStatus_In_12.verify();

    extern UAutoLCPossibilityJdgDataSet gOEM_SWC_C1_1UAutoLCPossibilityJdgDataSet;
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UAutoLCPossibilityJdgDataSet.mConc.V_x_AutoLCPossibilityJdgOutput.V_x_st_Output_DynamicConflJdgDiag.V_m_Dcj_ObjRightGapF, 340282346638528897590636046441678635008);
    EXPECT_FLOAT_EQ(gOEM_SWC_C1_1UAutoLCPossibilityJdgDataSet.mConc.V_x_AutoLCPossibilityJdgOutput.V_x_st_Output_DynamicConflJdgDiag.V_m_Dcj_ObjRightGapF, 340282346638528897590636046441678635008);
    struct _func_V_x_AutoLCPossibilityJdgOutput_VehStatus_In_13 {
        static void verify(void) {
#include "Rte_Wrapper_VehStatus_In.h"
            V_x_AutoLCPossibilityJdgOutput tmp_AutoLCPossibilityJdgOutput;
            Rte_Read_V_x_AutoLCPossibilityJdgOutput_V_x_AutoLCPossibilityJdgOutput(&tmp_AutoLCPossibilityJdgOutput);
            EXPECT_FLOAT_EQ(tmp_AutoLCPossibilityJdgOutput.V_x_st_Output_DynamicConflJdgDiag.V_m_Dcj_ObjRightGapF, 340282346638528897590636046441678635008);
        }
    } func_V_x_AutoLCPossibilityJdgOutput_VehStatus_In_13;
    func_V_x_AutoLCPossibilityJdgOutput_VehStatus_In_13.verify();

    extern UAutoLCPossibilityJdgDataSet gOEM_SWC_C1_1UAutoLCPossibilityJdgDataSet;
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UAutoLCPossibilityJdgDataSet.mConc.V_x_AutoLCPossibilityJdgOutput.V_x_st_Output_DynamicConflJdgDiag.V_m_Dcj_ObjRightGapR, 340282346638528897590636046441678635008);
    EXPECT_FLOAT_EQ(gOEM_SWC_C1_1UAutoLCPossibilityJdgDataSet.mConc.V_x_AutoLCPossibilityJdgOutput.V_x_st_Output_DynamicConflJdgDiag.V_m_Dcj_ObjRightGapR, 340282346638528897590636046441678635008);
    struct _func_V_x_AutoLCPossibilityJdgOutput_VehStatus_In_14 {
        static void verify(void) {
#include "Rte_Wrapper_VehStatus_In.h"
            V_x_AutoLCPossibilityJdgOutput tmp_AutoLCPossibilityJdgOutput;
            Rte_Read_V_x_AutoLCPossibilityJdgOutput_V_x_AutoLCPossibilityJdgOutput(&tmp_AutoLCPossibilityJdgOutput);
            EXPECT_FLOAT_EQ(tmp_AutoLCPossibilityJdgOutput.V_x_st_Output_DynamicConflJdgDiag.V_m_Dcj_ObjRightGapR, 340282346638528897590636046441678635008);
        }
    } func_V_x_AutoLCPossibilityJdgOutput_VehStatus_In_14;
    func_V_x_AutoLCPossibilityJdgOutput_VehStatus_In_14.verify();

    extern UAutoLCPossibilityJdgDataSet gOEM_SWC_C1_1UAutoLCPossibilityJdgDataSet;
    EXPECT_EQ(gOEM_SWC_C2_2UAutoLCPossibilityJdgDataSet.mConc.V_x_AutoLCPossibilityJdgOutput.V_x_st_Output_DynamicConflJdgDiag.V_x_Dcj_ObjRightNum, 255);
    EXPECT_EQ(gOEM_SWC_C1_1UAutoLCPossibilityJdgDataSet.mConc.V_x_AutoLCPossibilityJdgOutput.V_x_st_Output_DynamicConflJdgDiag.V_x_Dcj_ObjRightNum, 255);
    struct _func_V_x_AutoLCPossibilityJdgOutput_VehStatus_In_15 {
        static void verify(void) {
#include "Rte_Wrapper_VehStatus_In.h"
            V_x_AutoLCPossibilityJdgOutput tmp_AutoLCPossibilityJdgOutput;
            Rte_Read_V_x_AutoLCPossibilityJdgOutput_V_x_AutoLCPossibilityJdgOutput(&tmp_AutoLCPossibilityJdgOutput);
            EXPECT_EQ(tmp_AutoLCPossibilityJdgOutput.V_x_st_Output_DynamicConflJdgDiag.V_x_Dcj_ObjRightNum, 255);
        }
    } func_V_x_AutoLCPossibilityJdgOutput_VehStatus_In_15;
    func_V_x_AutoLCPossibilityJdgOutput_VehStatus_In_15.verify();

    extern UAutoLCPossibilityJdgDataSet gOEM_SWC_C1_1UAutoLCPossibilityJdgDataSet;
    EXPECT_EQ(gOEM_SWC_C2_2UAutoLCPossibilityJdgDataSet.mConc.V_x_AutoLCPossibilityJdgOutput.V_x_st_Output_Alc.V_x_lane_change_possible_left, 255);
    EXPECT_EQ(gOEM_SWC_C1_1UAutoLCPossibilityJdgDataSet.mConc.V_x_AutoLCPossibilityJdgOutput.V_x_st_Output_Alc.V_x_lane_change_possible_left, 255);
    struct _func_V_x_AutoLCPossibilityJdgOutput_VehStatus_In_16 {
        static void verify(void) {
#include "Rte_Wrapper_VehStatus_In.h"
            V_x_AutoLCPossibilityJdgOutput tmp_AutoLCPossibilityJdgOutput;
            Rte_Read_V_x_AutoLCPossibilityJdgOutput_V_x_AutoLCPossibilityJdgOutput(&tmp_AutoLCPossibilityJdgOutput);
            EXPECT_EQ(tmp_AutoLCPossibilityJdgOutput.V_x_st_Output_Alc.V_x_lane_change_possible_left, 255);
        }
    } func_V_x_AutoLCPossibilityJdgOutput_VehStatus_In_16;
    func_V_x_AutoLCPossibilityJdgOutput_VehStatus_In_16.verify();

    extern UAutoLCPossibilityJdgDataSet gOEM_SWC_C1_1UAutoLCPossibilityJdgDataSet;
    EXPECT_EQ(gOEM_SWC_C2_2UAutoLCPossibilityJdgDataSet.mConc.V_x_AutoLCPossibilityJdgOutput.V_x_st_Output_Alc.V_x_lane_change_possible_right, 255);
    EXPECT_EQ(gOEM_SWC_C1_1UAutoLCPossibilityJdgDataSet.mConc.V_x_AutoLCPossibilityJdgOutput.V_x_st_Output_Alc.V_x_lane_change_possible_right, 255);
    struct _func_V_x_AutoLCPossibilityJdgOutput_VehStatus_In_17 {
        static void verify(void) {
#include "Rte_Wrapper_VehStatus_In.h"
            V_x_AutoLCPossibilityJdgOutput tmp_AutoLCPossibilityJdgOutput;
            Rte_Read_V_x_AutoLCPossibilityJdgOutput_V_x_AutoLCPossibilityJdgOutput(&tmp_AutoLCPossibilityJdgOutput);
            EXPECT_EQ(tmp_AutoLCPossibilityJdgOutput.V_x_st_Output_Alc.V_x_lane_change_possible_right, 255);
        }
    } func_V_x_AutoLCPossibilityJdgOutput_VehStatus_In_17;
    func_V_x_AutoLCPossibilityJdgOutput_VehStatus_In_17.verify();

    extern UAutoLCPossibilityJdgDataSet gOEM_SWC_C1_1UAutoLCPossibilityJdgDataSet;
    EXPECT_EQ(gOEM_SWC_C2_2UAutoLCPossibilityJdgDataSet.mConc.V_x_AutoLCPossibilityJdgOutput.V_x_st_Output_Alc.V_x_lane_change_pass_right, 255);
    EXPECT_EQ(gOEM_SWC_C1_1UAutoLCPossibilityJdgDataSet.mConc.V_x_AutoLCPossibilityJdgOutput.V_x_st_Output_Alc.V_x_lane_change_pass_right, 255);
    struct _func_V_x_AutoLCPossibilityJdgOutput_VehStatus_In_18 {
        static void verify(void) {
#include "Rte_Wrapper_VehStatus_In.h"
            V_x_AutoLCPossibilityJdgOutput tmp_AutoLCPossibilityJdgOutput;
            Rte_Read_V_x_AutoLCPossibilityJdgOutput_V_x_AutoLCPossibilityJdgOutput(&tmp_AutoLCPossibilityJdgOutput);
            EXPECT_EQ(tmp_AutoLCPossibilityJdgOutput.V_x_st_Output_Alc.V_x_lane_change_pass_right, 255);
        }
    } func_V_x_AutoLCPossibilityJdgOutput_VehStatus_In_18;
    func_V_x_AutoLCPossibilityJdgOutput_VehStatus_In_18.verify();

    extern UAutoLCPossibilityJdgDataSet gOEM_SWC_C1_1UAutoLCPossibilityJdgDataSet;
    EXPECT_EQ(gOEM_SWC_C2_2UAutoLCPossibilityJdgDataSet.mConc.V_x_AutoLCPossibilityJdgOutput.V_x_st_Output_Alc.V_x_lane_change_return_left, 255);
    EXPECT_EQ(gOEM_SWC_C1_1UAutoLCPossibilityJdgDataSet.mConc.V_x_AutoLCPossibilityJdgOutput.V_x_st_Output_Alc.V_x_lane_change_return_left, 255);
    struct _func_V_x_AutoLCPossibilityJdgOutput_VehStatus_In_19 {
        static void verify(void) {
#include "Rte_Wrapper_VehStatus_In.h"
            V_x_AutoLCPossibilityJdgOutput tmp_AutoLCPossibilityJdgOutput;
            Rte_Read_V_x_AutoLCPossibilityJdgOutput_V_x_AutoLCPossibilityJdgOutput(&tmp_AutoLCPossibilityJdgOutput);
            EXPECT_EQ(tmp_AutoLCPossibilityJdgOutput.V_x_st_Output_Alc.V_x_lane_change_return_left, 255);
        }
    } func_V_x_AutoLCPossibilityJdgOutput_VehStatus_In_19;
    func_V_x_AutoLCPossibilityJdgOutput_VehStatus_In_19.verify();

    extern UAutoLCPossibilityJdgDataSet gOEM_SWC_C1_1UAutoLCPossibilityJdgDataSet;
    EXPECT_EQ(gOEM_SWC_C2_2UAutoLCPossibilityJdgDataSet.mConc.V_x_AutoLCPossibilityJdgOutput.V_x_st_Output_Alc.F_x_next_lane_free_left, 255);
    EXPECT_EQ(gOEM_SWC_C1_1UAutoLCPossibilityJdgDataSet.mConc.V_x_AutoLCPossibilityJdgOutput.V_x_st_Output_Alc.F_x_next_lane_free_left, 255);
    struct _func_V_x_AutoLCPossibilityJdgOutput_VehStatus_In_20 {
        static void verify(void) {
#include "Rte_Wrapper_VehStatus_In.h"
            V_x_AutoLCPossibilityJdgOutput tmp_AutoLCPossibilityJdgOutput;
            Rte_Read_V_x_AutoLCPossibilityJdgOutput_V_x_AutoLCPossibilityJdgOutput(&tmp_AutoLCPossibilityJdgOutput);
            EXPECT_EQ(tmp_AutoLCPossibilityJdgOutput.V_x_st_Output_Alc.F_x_next_lane_free_left, 255);
        }
    } func_V_x_AutoLCPossibilityJdgOutput_VehStatus_In_20;
    func_V_x_AutoLCPossibilityJdgOutput_VehStatus_In_20.verify();

    extern UAutoLCPossibilityJdgDataSet gOEM_SWC_C1_1UAutoLCPossibilityJdgDataSet;
    EXPECT_EQ(gOEM_SWC_C2_2UAutoLCPossibilityJdgDataSet.mConc.V_x_AutoLCPossibilityJdgOutput.V_x_st_Output_Alc.F_x_next_lane_free_right, 255);
    EXPECT_EQ(gOEM_SWC_C1_1UAutoLCPossibilityJdgDataSet.mConc.V_x_AutoLCPossibilityJdgOutput.V_x_st_Output_Alc.F_x_next_lane_free_right, 255);
    struct _func_V_x_AutoLCPossibilityJdgOutput_VehStatus_In_21 {
        static void verify(void) {
#include "Rte_Wrapper_VehStatus_In.h"
            V_x_AutoLCPossibilityJdgOutput tmp_AutoLCPossibilityJdgOutput;
            Rte_Read_V_x_AutoLCPossibilityJdgOutput_V_x_AutoLCPossibilityJdgOutput(&tmp_AutoLCPossibilityJdgOutput);
            EXPECT_EQ(tmp_AutoLCPossibilityJdgOutput.V_x_st_Output_Alc.F_x_next_lane_free_right, 255);
        }
    } func_V_x_AutoLCPossibilityJdgOutput_VehStatus_In_21;
    func_V_x_AutoLCPossibilityJdgOutput_VehStatus_In_21.verify();

}

void C2_2_o2o_noncache_max_verify_ObjectSelectionDM(void)
{
    V_x_ObjectSelectionDMOutput tmp_ObjectSelectionDMOutput;

    /* V_x_ObjectSelectionDMOutput*/
    extern UObjectSelectionDMDataSet gOEM_SWC_C1_1UObjectSelectionDMDataSet;
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UObjectSelectionDMDataSet.mConc.V_x_ObjectSelectionDMOutput.V_m_FL_SideRadarPosX_DMS, 340282346638528897590636046441678635008);
    EXPECT_FLOAT_EQ(gOEM_SWC_C1_1UObjectSelectionDMDataSet.mConc.V_x_ObjectSelectionDMOutput.V_m_FL_SideRadarPosX_DMS, 340282346638528897590636046441678635008);
    struct _func_V_x_ObjectSelectionDMOutput_VehStatus_In_0 {
        static void verify(void) {
#include "Rte_Wrapper_VehStatus_In.h"
            V_x_ObjectSelectionDMOutput tmp_ObjectSelectionDMOutput;
            Rte_Read_V_x_ObjectSelectionDMOutput_V_x_ObjectSelectionDMOutput(&tmp_ObjectSelectionDMOutput);
            EXPECT_FLOAT_EQ(tmp_ObjectSelectionDMOutput.V_m_FL_SideRadarPosX_DMS, 340282346638528897590636046441678635008);
        }
    } func_V_x_ObjectSelectionDMOutput_VehStatus_In_0;
    func_V_x_ObjectSelectionDMOutput_VehStatus_In_0.verify();

    extern UObjectSelectionDMDataSet gOEM_SWC_C1_1UObjectSelectionDMDataSet;
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UObjectSelectionDMDataSet.mConc.V_x_ObjectSelectionDMOutput.V_m_FL_SideRadarPosY_DMS, 340282346638528897590636046441678635008);
    EXPECT_FLOAT_EQ(gOEM_SWC_C1_1UObjectSelectionDMDataSet.mConc.V_x_ObjectSelectionDMOutput.V_m_FL_SideRadarPosY_DMS, 340282346638528897590636046441678635008);
    struct _func_V_x_ObjectSelectionDMOutput_VehStatus_In_1 {
        static void verify(void) {
#include "Rte_Wrapper_VehStatus_In.h"
            V_x_ObjectSelectionDMOutput tmp_ObjectSelectionDMOutput;
            Rte_Read_V_x_ObjectSelectionDMOutput_V_x_ObjectSelectionDMOutput(&tmp_ObjectSelectionDMOutput);
            EXPECT_FLOAT_EQ(tmp_ObjectSelectionDMOutput.V_m_FL_SideRadarPosY_DMS, 340282346638528897590636046441678635008);
        }
    } func_V_x_ObjectSelectionDMOutput_VehStatus_In_1;
    func_V_x_ObjectSelectionDMOutput_VehStatus_In_1.verify();

    extern UObjectSelectionDMDataSet gOEM_SWC_C1_1UObjectSelectionDMDataSet;
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UObjectSelectionDMDataSet.mConc.V_x_ObjectSelectionDMOutput.V_mps_FL_SideRadarRelVelX_DMS, 340282346638528897590636046441678635008);
    EXPECT_FLOAT_EQ(gOEM_SWC_C1_1UObjectSelectionDMDataSet.mConc.V_x_ObjectSelectionDMOutput.V_mps_FL_SideRadarRelVelX_DMS, 340282346638528897590636046441678635008);
    struct _func_V_x_ObjectSelectionDMOutput_VehStatus_In_2 {
        static void verify(void) {
#include "Rte_Wrapper_VehStatus_In.h"
            V_x_ObjectSelectionDMOutput tmp_ObjectSelectionDMOutput;
            Rte_Read_V_x_ObjectSelectionDMOutput_V_x_ObjectSelectionDMOutput(&tmp_ObjectSelectionDMOutput);
            EXPECT_FLOAT_EQ(tmp_ObjectSelectionDMOutput.V_mps_FL_SideRadarRelVelX_DMS, 340282346638528897590636046441678635008);
        }
    } func_V_x_ObjectSelectionDMOutput_VehStatus_In_2;
    func_V_x_ObjectSelectionDMOutput_VehStatus_In_2.verify();

    extern UObjectSelectionDMDataSet gOEM_SWC_C1_1UObjectSelectionDMDataSet;
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UObjectSelectionDMDataSet.mConc.V_x_ObjectSelectionDMOutput.V_m_FR_SideRadarPosX_DMS, 340282346638528897590636046441678635008);
    EXPECT_FLOAT_EQ(gOEM_SWC_C1_1UObjectSelectionDMDataSet.mConc.V_x_ObjectSelectionDMOutput.V_m_FR_SideRadarPosX_DMS, 340282346638528897590636046441678635008);
    struct _func_V_x_ObjectSelectionDMOutput_VehStatus_In_3 {
        static void verify(void) {
#include "Rte_Wrapper_VehStatus_In.h"
            V_x_ObjectSelectionDMOutput tmp_ObjectSelectionDMOutput;
            Rte_Read_V_x_ObjectSelectionDMOutput_V_x_ObjectSelectionDMOutput(&tmp_ObjectSelectionDMOutput);
            EXPECT_FLOAT_EQ(tmp_ObjectSelectionDMOutput.V_m_FR_SideRadarPosX_DMS, 340282346638528897590636046441678635008);
        }
    } func_V_x_ObjectSelectionDMOutput_VehStatus_In_3;
    func_V_x_ObjectSelectionDMOutput_VehStatus_In_3.verify();

    extern UObjectSelectionDMDataSet gOEM_SWC_C1_1UObjectSelectionDMDataSet;
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UObjectSelectionDMDataSet.mConc.V_x_ObjectSelectionDMOutput.V_m_FR_SideRadarPosY_DMS, 340282346638528897590636046441678635008);
    EXPECT_FLOAT_EQ(gOEM_SWC_C1_1UObjectSelectionDMDataSet.mConc.V_x_ObjectSelectionDMOutput.V_m_FR_SideRadarPosY_DMS, 340282346638528897590636046441678635008);
    struct _func_V_x_ObjectSelectionDMOutput_VehStatus_In_4 {
        static void verify(void) {
#include "Rte_Wrapper_VehStatus_In.h"
            V_x_ObjectSelectionDMOutput tmp_ObjectSelectionDMOutput;
            Rte_Read_V_x_ObjectSelectionDMOutput_V_x_ObjectSelectionDMOutput(&tmp_ObjectSelectionDMOutput);
            EXPECT_FLOAT_EQ(tmp_ObjectSelectionDMOutput.V_m_FR_SideRadarPosY_DMS, 340282346638528897590636046441678635008);
        }
    } func_V_x_ObjectSelectionDMOutput_VehStatus_In_4;
    func_V_x_ObjectSelectionDMOutput_VehStatus_In_4.verify();

    extern UObjectSelectionDMDataSet gOEM_SWC_C1_1UObjectSelectionDMDataSet;
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UObjectSelectionDMDataSet.mConc.V_x_ObjectSelectionDMOutput.V_mps_FR_SideRadarRelVelX_DMS, 340282346638528897590636046441678635008);
    EXPECT_FLOAT_EQ(gOEM_SWC_C1_1UObjectSelectionDMDataSet.mConc.V_x_ObjectSelectionDMOutput.V_mps_FR_SideRadarRelVelX_DMS, 340282346638528897590636046441678635008);
    struct _func_V_x_ObjectSelectionDMOutput_VehStatus_In_5 {
        static void verify(void) {
#include "Rte_Wrapper_VehStatus_In.h"
            V_x_ObjectSelectionDMOutput tmp_ObjectSelectionDMOutput;
            Rte_Read_V_x_ObjectSelectionDMOutput_V_x_ObjectSelectionDMOutput(&tmp_ObjectSelectionDMOutput);
            EXPECT_FLOAT_EQ(tmp_ObjectSelectionDMOutput.V_mps_FR_SideRadarRelVelX_DMS, 340282346638528897590636046441678635008);
        }
    } func_V_x_ObjectSelectionDMOutput_VehStatus_In_5;
    func_V_x_ObjectSelectionDMOutput_VehStatus_In_5.verify();

    extern UObjectSelectionDMDataSet gOEM_SWC_C1_1UObjectSelectionDMDataSet;
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UObjectSelectionDMDataSet.mConc.V_x_ObjectSelectionDMOutput.V_m_RL_SideRadarPosX_DMS, 340282346638528897590636046441678635008);
    EXPECT_FLOAT_EQ(gOEM_SWC_C1_1UObjectSelectionDMDataSet.mConc.V_x_ObjectSelectionDMOutput.V_m_RL_SideRadarPosX_DMS, 340282346638528897590636046441678635008);
    struct _func_V_x_ObjectSelectionDMOutput_VehStatus_In_6 {
        static void verify(void) {
#include "Rte_Wrapper_VehStatus_In.h"
            V_x_ObjectSelectionDMOutput tmp_ObjectSelectionDMOutput;
            Rte_Read_V_x_ObjectSelectionDMOutput_V_x_ObjectSelectionDMOutput(&tmp_ObjectSelectionDMOutput);
            EXPECT_FLOAT_EQ(tmp_ObjectSelectionDMOutput.V_m_RL_SideRadarPosX_DMS, 340282346638528897590636046441678635008);
        }
    } func_V_x_ObjectSelectionDMOutput_VehStatus_In_6;
    func_V_x_ObjectSelectionDMOutput_VehStatus_In_6.verify();

    extern UObjectSelectionDMDataSet gOEM_SWC_C1_1UObjectSelectionDMDataSet;
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UObjectSelectionDMDataSet.mConc.V_x_ObjectSelectionDMOutput.V_m_RL_SideRadarPosY_DMS, 340282346638528897590636046441678635008);
    EXPECT_FLOAT_EQ(gOEM_SWC_C1_1UObjectSelectionDMDataSet.mConc.V_x_ObjectSelectionDMOutput.V_m_RL_SideRadarPosY_DMS, 340282346638528897590636046441678635008);
    struct _func_V_x_ObjectSelectionDMOutput_VehStatus_In_7 {
        static void verify(void) {
#include "Rte_Wrapper_VehStatus_In.h"
            V_x_ObjectSelectionDMOutput tmp_ObjectSelectionDMOutput;
            Rte_Read_V_x_ObjectSelectionDMOutput_V_x_ObjectSelectionDMOutput(&tmp_ObjectSelectionDMOutput);
            EXPECT_FLOAT_EQ(tmp_ObjectSelectionDMOutput.V_m_RL_SideRadarPosY_DMS, 340282346638528897590636046441678635008);
        }
    } func_V_x_ObjectSelectionDMOutput_VehStatus_In_7;
    func_V_x_ObjectSelectionDMOutput_VehStatus_In_7.verify();

    extern UObjectSelectionDMDataSet gOEM_SWC_C1_1UObjectSelectionDMDataSet;
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UObjectSelectionDMDataSet.mConc.V_x_ObjectSelectionDMOutput.V_mps_RL_SideRadarRelVelX_DMS, 340282346638528897590636046441678635008);
    EXPECT_FLOAT_EQ(gOEM_SWC_C1_1UObjectSelectionDMDataSet.mConc.V_x_ObjectSelectionDMOutput.V_mps_RL_SideRadarRelVelX_DMS, 340282346638528897590636046441678635008);
    struct _func_V_x_ObjectSelectionDMOutput_VehStatus_In_8 {
        static void verify(void) {
#include "Rte_Wrapper_VehStatus_In.h"
            V_x_ObjectSelectionDMOutput tmp_ObjectSelectionDMOutput;
            Rte_Read_V_x_ObjectSelectionDMOutput_V_x_ObjectSelectionDMOutput(&tmp_ObjectSelectionDMOutput);
            EXPECT_FLOAT_EQ(tmp_ObjectSelectionDMOutput.V_mps_RL_SideRadarRelVelX_DMS, 340282346638528897590636046441678635008);
        }
    } func_V_x_ObjectSelectionDMOutput_VehStatus_In_8;
    func_V_x_ObjectSelectionDMOutput_VehStatus_In_8.verify();

    extern UObjectSelectionDMDataSet gOEM_SWC_C1_1UObjectSelectionDMDataSet;
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UObjectSelectionDMDataSet.mConc.V_x_ObjectSelectionDMOutput.V_m_RR_SideRadarPosX_DMS, 340282346638528897590636046441678635008);
    EXPECT_FLOAT_EQ(gOEM_SWC_C1_1UObjectSelectionDMDataSet.mConc.V_x_ObjectSelectionDMOutput.V_m_RR_SideRadarPosX_DMS, 340282346638528897590636046441678635008);
    struct _func_V_x_ObjectSelectionDMOutput_VehStatus_In_9 {
        static void verify(void) {
#include "Rte_Wrapper_VehStatus_In.h"
            V_x_ObjectSelectionDMOutput tmp_ObjectSelectionDMOutput;
            Rte_Read_V_x_ObjectSelectionDMOutput_V_x_ObjectSelectionDMOutput(&tmp_ObjectSelectionDMOutput);
            EXPECT_FLOAT_EQ(tmp_ObjectSelectionDMOutput.V_m_RR_SideRadarPosX_DMS, 340282346638528897590636046441678635008);
        }
    } func_V_x_ObjectSelectionDMOutput_VehStatus_In_9;
    func_V_x_ObjectSelectionDMOutput_VehStatus_In_9.verify();

    extern UObjectSelectionDMDataSet gOEM_SWC_C1_1UObjectSelectionDMDataSet;
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UObjectSelectionDMDataSet.mConc.V_x_ObjectSelectionDMOutput.V_m_RR_SideRadarPosY_DMS, 340282346638528897590636046441678635008);
    EXPECT_FLOAT_EQ(gOEM_SWC_C1_1UObjectSelectionDMDataSet.mConc.V_x_ObjectSelectionDMOutput.V_m_RR_SideRadarPosY_DMS, 340282346638528897590636046441678635008);
    struct _func_V_x_ObjectSelectionDMOutput_VehStatus_In_10 {
        static void verify(void) {
#include "Rte_Wrapper_VehStatus_In.h"
            V_x_ObjectSelectionDMOutput tmp_ObjectSelectionDMOutput;
            Rte_Read_V_x_ObjectSelectionDMOutput_V_x_ObjectSelectionDMOutput(&tmp_ObjectSelectionDMOutput);
            EXPECT_FLOAT_EQ(tmp_ObjectSelectionDMOutput.V_m_RR_SideRadarPosY_DMS, 340282346638528897590636046441678635008);
        }
    } func_V_x_ObjectSelectionDMOutput_VehStatus_In_10;
    func_V_x_ObjectSelectionDMOutput_VehStatus_In_10.verify();

    extern UObjectSelectionDMDataSet gOEM_SWC_C1_1UObjectSelectionDMDataSet;
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_2UObjectSelectionDMDataSet.mConc.V_x_ObjectSelectionDMOutput.V_mps_RR_SideRadarRelVelX_DMS, 340282346638528897590636046441678635008);
    EXPECT_FLOAT_EQ(gOEM_SWC_C1_1UObjectSelectionDMDataSet.mConc.V_x_ObjectSelectionDMOutput.V_mps_RR_SideRadarRelVelX_DMS, 340282346638528897590636046441678635008);
    struct _func_V_x_ObjectSelectionDMOutput_VehStatus_In_11 {
        static void verify(void) {
#include "Rte_Wrapper_VehStatus_In.h"
            V_x_ObjectSelectionDMOutput tmp_ObjectSelectionDMOutput;
            Rte_Read_V_x_ObjectSelectionDMOutput_V_x_ObjectSelectionDMOutput(&tmp_ObjectSelectionDMOutput);
            EXPECT_FLOAT_EQ(tmp_ObjectSelectionDMOutput.V_mps_RR_SideRadarRelVelX_DMS, 340282346638528897590636046441678635008);
        }
    } func_V_x_ObjectSelectionDMOutput_VehStatus_In_11;
    func_V_x_ObjectSelectionDMOutput_VehStatus_In_11.verify();

}

void C2_2_o2o_noncache_max_verify_VehStatus_In_50(void)
{
    V_x_surround_obj_left_t tmp_surround_obj_left_t;
    V_x_surround_obj_rearcenter_t tmp_surround_obj_rearcenter_t;
    V_x_surround_obj_right_t tmp_surround_obj_right_t;

}
