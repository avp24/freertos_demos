#include <limits.h>
#include <float.h>
#include "gtest/gtest.h"
#include "Platform_Types.h"



extern uint8 gOEM_SWC_C0_SMV_x_VARIANTCODE;


extern boolean gOEM_SWC_C0_SMF_x_CAN_HW_Fail;
extern boolean gOEM_SWC_C0_SMF_x_Ethernet_HW_Fail;



extern boolean gOEM_SWC_C0_SMF_x_FS_BusOff_JT1;
extern boolean gOEM_SWC_C0_SMF_x_FS_BusOff_JT2;
extern boolean gOEM_SWC_C0_SMF_x_FS_ChkSumVDC;
extern boolean gOEM_SWC_C0_SMF_x_FS_MsgCntVDC;
extern boolean gOEM_SWC_C0_SMF_x_FS_UnRcvVDC_JT1;
extern boolean gOEM_SWC_C0_SMF_x_FS_UnRcvVDC_JT2;
extern boolean gOEM_SWC_C0_SMF_x_IgnitionSupplyConfirmation_CAN;
extern sint16 gOEM_SWC_C0_SMV_deg_SteerRackPinionAngleCorrect_CAN;
extern sint16 gOEM_SWC_C0_SMV_degps_YawRateRaw_BasicSW;
extern uint16 gOEM_SWC_C0_SMV_rpm_WheelSpeedFL_BasicSW;
extern uint16 gOEM_SWC_C0_SMV_rpm_WheelSpeedFR_BasicSW;
extern uint16 gOEM_SWC_C0_SMV_rpm_WheelSpeedRL_BasicSW;
extern uint16 gOEM_SWC_C0_SMV_rpm_WheelSpeedRR_BasicSW;
extern uint8 gOEM_SWC_C0_SMV_x_GADE_v2_BasicSW;

extern boolean gOEM_SWC_C0_SMF_x_FS_CRCCAM_ETH;
extern boolean gOEM_SWC_C0_SMF_x_FS_CRCRADAR_ETH;
extern boolean gOEM_SWC_C0_SMF_x_FS_ClockCAM_ETH;
extern boolean gOEM_SWC_C0_SMF_x_FS_ClockRADAR_ETH;
extern boolean gOEM_SWC_C0_SMF_x_FS_ETHUnRcvFrCamera_JT2;
extern boolean gOEM_SWC_C0_SMF_x_FS_ETHUnRcvRADAR_JT2;
extern boolean gOEM_SWC_C0_SMF_x_FS_UnRcvCamera_JT1_ETH;
extern boolean gOEM_SWC_C0_SMF_x_FS_UnRcvCamera_JT2_ETH;
extern boolean gOEM_SWC_C0_SMF_x_FS_UnRcvRADAR_JT1_ETH;
extern boolean gOEM_SWC_C0_SMF_x_FS_UnRcvRADAR_JT2_ETH;

extern boolean gOEM_SWC_C0_SMF_x_FOTA_ReIgnON;

void C0_SM_s2o_max_verify_ADC(void)
{
}

void C0_SM_s2o_max_verify_DIO(void)
{
}

void C0_SM_s2o_max_verify_EEPROM(void)
{
    EXPECT_EQ(gOEM_SWC_C0_SMV_x_VARIANTCODE, 255);
}

void C0_SM_s2o_max_verify_PWM(void)
{
}

void C0_SM_s2o_max_verify_SUP_DIAG(void)
{
    EXPECT_EQ(gOEM_SWC_C0_SMF_x_CAN_HW_Fail, 255);
    EXPECT_EQ(gOEM_SWC_C0_SMF_x_Ethernet_HW_Fail, 255);
}

void C0_SM_s2o_max_verify_UDSCOM(void)
{
}

void C0_SM_s2o_max_verify_LINIF(void)
{
}

void C0_SM_s2o_max_verify_CANIF(void)
{
    EXPECT_EQ(gOEM_SWC_C0_SMF_x_FS_BusOff_JT1, 255);
    EXPECT_EQ(gOEM_SWC_C0_SMF_x_FS_BusOff_JT2, 255);
    EXPECT_EQ(gOEM_SWC_C0_SMF_x_FS_ChkSumVDC, 255);
    EXPECT_EQ(gOEM_SWC_C0_SMF_x_FS_MsgCntVDC, 255);
    EXPECT_EQ(gOEM_SWC_C0_SMF_x_FS_UnRcvVDC_JT1, 255);
    EXPECT_EQ(gOEM_SWC_C0_SMF_x_FS_UnRcvVDC_JT2, 255);
    EXPECT_EQ(gOEM_SWC_C0_SMF_x_IgnitionSupplyConfirmation_CAN, 255);
    EXPECT_EQ(gOEM_SWC_C0_SMV_deg_SteerRackPinionAngleCorrect_CAN, 32767);
    EXPECT_EQ(gOEM_SWC_C0_SMV_degps_YawRateRaw_BasicSW, 32767);
    EXPECT_EQ(gOEM_SWC_C0_SMV_rpm_WheelSpeedFL_BasicSW, 65535);
    EXPECT_EQ(gOEM_SWC_C0_SMV_rpm_WheelSpeedFR_BasicSW, 65535);
    EXPECT_EQ(gOEM_SWC_C0_SMV_rpm_WheelSpeedRL_BasicSW, 65535);
    EXPECT_EQ(gOEM_SWC_C0_SMV_rpm_WheelSpeedRR_BasicSW, 65535);
    EXPECT_EQ(gOEM_SWC_C0_SMV_x_GADE_v2_BasicSW, 255);
}

void C0_SM_s2o_max_verify_EthIF(void)
{
    EXPECT_EQ(gOEM_SWC_C0_SMF_x_FS_CRCCAM_ETH, 255);
    EXPECT_EQ(gOEM_SWC_C0_SMF_x_FS_CRCRADAR_ETH, 255);
    EXPECT_EQ(gOEM_SWC_C0_SMF_x_FS_ClockCAM_ETH, 255);
    EXPECT_EQ(gOEM_SWC_C0_SMF_x_FS_ClockRADAR_ETH, 255);
    EXPECT_EQ(gOEM_SWC_C0_SMF_x_FS_ETHUnRcvFrCamera_JT2, 255);
    EXPECT_EQ(gOEM_SWC_C0_SMF_x_FS_ETHUnRcvRADAR_JT2, 255);
    EXPECT_EQ(gOEM_SWC_C0_SMF_x_FS_UnRcvCamera_JT1_ETH, 255);
    EXPECT_EQ(gOEM_SWC_C0_SMF_x_FS_UnRcvCamera_JT2_ETH, 255);
    EXPECT_EQ(gOEM_SWC_C0_SMF_x_FS_UnRcvRADAR_JT1_ETH, 255);
    EXPECT_EQ(gOEM_SWC_C0_SMF_x_FS_UnRcvRADAR_JT2_ETH, 255);
}

void C0_SM_s2o_max_verify_OEMRAMClear(void)
{
    EXPECT_EQ(gOEM_SWC_C0_SMF_x_FOTA_ReIgnON, 255);
}
