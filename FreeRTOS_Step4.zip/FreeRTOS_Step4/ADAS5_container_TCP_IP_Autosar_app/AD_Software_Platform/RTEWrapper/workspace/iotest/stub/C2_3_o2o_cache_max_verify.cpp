#include <limits.h>
#include <float.h>
#include "gtest/gtest.h"
#include "Rte_Union.h"
#include "Platform_Types.h"

extern URCarHMIManagementDataSet gOEM_SWC_C2_3URCarHMIManagementDataSet;
void C2_3_o2o_cache_max_verify_RCarHMIManagement(void)
{
    V_x_RCarHMIManagementOutput tmp_RCarHMIManagementOutput;

}

extern UObjectSelectionAVMDataSet gOEM_SWC_C2_3UObjectSelectionAVMDataSet;
void C2_3_o2o_cache_max_verify_ObjectSelectionAVM(void)
{
    V_x_ObjectSelectionAVMOutput tmp_ObjectSelectionAVMOutput;

}

extern UVehStatus_In_100DataSet gOEM_SWC_C2_3UVehStatus_In_100DataSet;
void C2_3_o2o_cache_max_verify_VehStatus_In_100(void)
{
    V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
    sint32 tmp_S32;
    V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
    V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;

    /* V_x_RCarHMIManagementSensorInput */
    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[0].llTimeStamp, 4294967295);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_0 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[0].llTimeStamp, 4294967295);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_0;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_0.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[0].V_x_ObjectID, 255);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_1 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[0].V_x_ObjectID, 255);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_1;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_1.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[0].F_x_CIPV, 255);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_2 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[0].F_x_CIPV, 255);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_2;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_2.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[0].V_x_ObjectLength, 340282346638528897590636046441678635008);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_3 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[0].V_x_ObjectLength, 340282346638528897590636046441678635008);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_3;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_3.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[0].V_m_ObjectWidth, 340282346638528897590636046441678635008);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_4 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[0].V_m_ObjectWidth, 340282346638528897590636046441678635008);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_4;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_4.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[0].V_m_ObjectPosX, 340282346638528897590636046441678635008);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_5 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[0].V_m_ObjectPosX, 340282346638528897590636046441678635008);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_5;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_5.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[0].V_m_ObjectPosY, 340282346638528897590636046441678635008);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_6 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[0].V_m_ObjectPosY, 340282346638528897590636046441678635008);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_6;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_6.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[0].V_mps_ObjectVelX, 340282346638528897590636046441678635008);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_7 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[0].V_mps_ObjectVelX, 340282346638528897590636046441678635008);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_7;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_7.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[0].V_mps_ObjectVelY, 340282346638528897590636046441678635008);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_8 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[0].V_mps_ObjectVelY, 340282346638528897590636046441678635008);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_8;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_8.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[0].V_x_ObjectType, 255);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_9 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[0].V_x_ObjectType, 255);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_9;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_9.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[0].V_x_ObjectStatus, 255);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_10 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[0].V_x_ObjectStatus, 255);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_10;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_10.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[0].V_x_ObjectValid, 255);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_11 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[0].V_x_ObjectValid, 255);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_11;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_11.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[0].V_x_ObjectLane, 255);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_12 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[0].V_x_ObjectLane, 255);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_12;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_12.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[0].V_s_TTC, 340282346638528897590636046441678635008);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_13 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[0].V_s_TTC, 340282346638528897590636046441678635008);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_13;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_13.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[0].V_mps2_ObjectAccelX, 340282346638528897590636046441678635008);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_14 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[0].V_mps2_ObjectAccelX, 340282346638528897590636046441678635008);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_14;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_14.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[0].V_x_BlinkInfo, 255);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_15 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[0].V_x_BlinkInfo, 255);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_15;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_15.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[0].V_degps_ObjectAngleRate, 340282346638528897590636046441678635008);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_16 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[0].V_degps_ObjectAngleRate, 340282346638528897590636046441678635008);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_16;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_16.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[0].V_deg_ObjectAngle, 340282346638528897590636046441678635008);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_17 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[0].V_deg_ObjectAngle, 340282346638528897590636046441678635008);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_17;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_17.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[0].V_mps_ObejectRelVelocity, 340282346638528897590636046441678635008);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_18 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[0].V_mps_ObejectRelVelocity, 340282346638528897590636046441678635008);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_18;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_18.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[1].llTimeStamp, 4294967295);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_19 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[1].llTimeStamp, 4294967295);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_19;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_19.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[1].V_x_ObjectID, 255);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_20 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[1].V_x_ObjectID, 255);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_20;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_20.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[1].F_x_CIPV, 255);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_21 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[1].F_x_CIPV, 255);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_21;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_21.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[1].V_x_ObjectLength, 340282346638528897590636046441678635008);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_22 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[1].V_x_ObjectLength, 340282346638528897590636046441678635008);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_22;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_22.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[1].V_m_ObjectWidth, 340282346638528897590636046441678635008);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_23 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[1].V_m_ObjectWidth, 340282346638528897590636046441678635008);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_23;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_23.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[1].V_m_ObjectPosX, 340282346638528897590636046441678635008);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_24 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[1].V_m_ObjectPosX, 340282346638528897590636046441678635008);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_24;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_24.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[1].V_m_ObjectPosY, 340282346638528897590636046441678635008);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_25 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[1].V_m_ObjectPosY, 340282346638528897590636046441678635008);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_25;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_25.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[1].V_mps_ObjectVelX, 340282346638528897590636046441678635008);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_26 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[1].V_mps_ObjectVelX, 340282346638528897590636046441678635008);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_26;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_26.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[1].V_mps_ObjectVelY, 340282346638528897590636046441678635008);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_27 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[1].V_mps_ObjectVelY, 340282346638528897590636046441678635008);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_27;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_27.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[1].V_x_ObjectType, 255);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_28 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[1].V_x_ObjectType, 255);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_28;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_28.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[1].V_x_ObjectStatus, 255);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_29 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[1].V_x_ObjectStatus, 255);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_29;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_29.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[1].V_x_ObjectValid, 255);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_30 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[1].V_x_ObjectValid, 255);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_30;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_30.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[1].V_x_ObjectLane, 255);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_31 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[1].V_x_ObjectLane, 255);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_31;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_31.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[1].V_s_TTC, 340282346638528897590636046441678635008);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_32 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[1].V_s_TTC, 340282346638528897590636046441678635008);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_32;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_32.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[1].V_mps2_ObjectAccelX, 340282346638528897590636046441678635008);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_33 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[1].V_mps2_ObjectAccelX, 340282346638528897590636046441678635008);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_33;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_33.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[1].V_x_BlinkInfo, 255);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_34 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[1].V_x_BlinkInfo, 255);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_34;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_34.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[1].V_degps_ObjectAngleRate, 340282346638528897590636046441678635008);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_35 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[1].V_degps_ObjectAngleRate, 340282346638528897590636046441678635008);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_35;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_35.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[1].V_deg_ObjectAngle, 340282346638528897590636046441678635008);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_36 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[1].V_deg_ObjectAngle, 340282346638528897590636046441678635008);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_36;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_36.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[1].V_mps_ObejectRelVelocity, 340282346638528897590636046441678635008);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_37 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[1].V_mps_ObejectRelVelocity, 340282346638528897590636046441678635008);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_37;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_37.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[2].llTimeStamp, 4294967295);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_38 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[2].llTimeStamp, 4294967295);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_38;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_38.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[2].V_x_ObjectID, 255);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_39 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[2].V_x_ObjectID, 255);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_39;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_39.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[2].F_x_CIPV, 255);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_40 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[2].F_x_CIPV, 255);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_40;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_40.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[2].V_x_ObjectLength, 340282346638528897590636046441678635008);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_41 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[2].V_x_ObjectLength, 340282346638528897590636046441678635008);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_41;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_41.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[2].V_m_ObjectWidth, 340282346638528897590636046441678635008);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_42 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[2].V_m_ObjectWidth, 340282346638528897590636046441678635008);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_42;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_42.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[2].V_m_ObjectPosX, 340282346638528897590636046441678635008);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_43 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[2].V_m_ObjectPosX, 340282346638528897590636046441678635008);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_43;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_43.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[2].V_m_ObjectPosY, 340282346638528897590636046441678635008);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_44 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[2].V_m_ObjectPosY, 340282346638528897590636046441678635008);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_44;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_44.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[2].V_mps_ObjectVelX, 340282346638528897590636046441678635008);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_45 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[2].V_mps_ObjectVelX, 340282346638528897590636046441678635008);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_45;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_45.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[2].V_mps_ObjectVelY, 340282346638528897590636046441678635008);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_46 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[2].V_mps_ObjectVelY, 340282346638528897590636046441678635008);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_46;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_46.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[2].V_x_ObjectType, 255);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_47 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[2].V_x_ObjectType, 255);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_47;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_47.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[2].V_x_ObjectStatus, 255);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_48 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[2].V_x_ObjectStatus, 255);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_48;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_48.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[2].V_x_ObjectValid, 255);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_49 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[2].V_x_ObjectValid, 255);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_49;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_49.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[2].V_x_ObjectLane, 255);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_50 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[2].V_x_ObjectLane, 255);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_50;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_50.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[2].V_s_TTC, 340282346638528897590636046441678635008);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_51 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[2].V_s_TTC, 340282346638528897590636046441678635008);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_51;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_51.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[2].V_mps2_ObjectAccelX, 340282346638528897590636046441678635008);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_52 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[2].V_mps2_ObjectAccelX, 340282346638528897590636046441678635008);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_52;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_52.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[2].V_x_BlinkInfo, 255);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_53 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[2].V_x_BlinkInfo, 255);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_53;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_53.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[2].V_degps_ObjectAngleRate, 340282346638528897590636046441678635008);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_54 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[2].V_degps_ObjectAngleRate, 340282346638528897590636046441678635008);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_54;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_54.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[2].V_deg_ObjectAngle, 340282346638528897590636046441678635008);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_55 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[2].V_deg_ObjectAngle, 340282346638528897590636046441678635008);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_55;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_55.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[2].V_mps_ObejectRelVelocity, 340282346638528897590636046441678635008);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_56 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[2].V_mps_ObejectRelVelocity, 340282346638528897590636046441678635008);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_56;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_56.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[3].llTimeStamp, 4294967295);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_57 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[3].llTimeStamp, 4294967295);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_57;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_57.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[3].V_x_ObjectID, 255);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_58 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[3].V_x_ObjectID, 255);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_58;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_58.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[3].F_x_CIPV, 255);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_59 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[3].F_x_CIPV, 255);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_59;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_59.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[3].V_x_ObjectLength, 340282346638528897590636046441678635008);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_60 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[3].V_x_ObjectLength, 340282346638528897590636046441678635008);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_60;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_60.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[3].V_m_ObjectWidth, 340282346638528897590636046441678635008);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_61 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[3].V_m_ObjectWidth, 340282346638528897590636046441678635008);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_61;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_61.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[3].V_m_ObjectPosX, 340282346638528897590636046441678635008);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_62 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[3].V_m_ObjectPosX, 340282346638528897590636046441678635008);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_62;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_62.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[3].V_m_ObjectPosY, 340282346638528897590636046441678635008);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_63 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[3].V_m_ObjectPosY, 340282346638528897590636046441678635008);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_63;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_63.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[3].V_mps_ObjectVelX, 340282346638528897590636046441678635008);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_64 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[3].V_mps_ObjectVelX, 340282346638528897590636046441678635008);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_64;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_64.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[3].V_mps_ObjectVelY, 340282346638528897590636046441678635008);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_65 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[3].V_mps_ObjectVelY, 340282346638528897590636046441678635008);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_65;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_65.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[3].V_x_ObjectType, 255);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_66 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[3].V_x_ObjectType, 255);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_66;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_66.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[3].V_x_ObjectStatus, 255);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_67 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[3].V_x_ObjectStatus, 255);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_67;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_67.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[3].V_x_ObjectValid, 255);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_68 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[3].V_x_ObjectValid, 255);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_68;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_68.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[3].V_x_ObjectLane, 255);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_69 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[3].V_x_ObjectLane, 255);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_69;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_69.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[3].V_s_TTC, 340282346638528897590636046441678635008);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_70 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[3].V_s_TTC, 340282346638528897590636046441678635008);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_70;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_70.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[3].V_mps2_ObjectAccelX, 340282346638528897590636046441678635008);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_71 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[3].V_mps2_ObjectAccelX, 340282346638528897590636046441678635008);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_71;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_71.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[3].V_x_BlinkInfo, 255);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_72 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[3].V_x_BlinkInfo, 255);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_72;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_72.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[3].V_degps_ObjectAngleRate, 340282346638528897590636046441678635008);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_73 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[3].V_degps_ObjectAngleRate, 340282346638528897590636046441678635008);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_73;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_73.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[3].V_deg_ObjectAngle, 340282346638528897590636046441678635008);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_74 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[3].V_deg_ObjectAngle, 340282346638528897590636046441678635008);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_74;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_74.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[3].V_mps_ObejectRelVelocity, 340282346638528897590636046441678635008);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_75 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[3].V_mps_ObejectRelVelocity, 340282346638528897590636046441678635008);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_75;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_75.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[4].llTimeStamp, 4294967295);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_76 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[4].llTimeStamp, 4294967295);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_76;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_76.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[4].V_x_ObjectID, 255);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_77 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[4].V_x_ObjectID, 255);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_77;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_77.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[4].F_x_CIPV, 255);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_78 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[4].F_x_CIPV, 255);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_78;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_78.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[4].V_x_ObjectLength, 340282346638528897590636046441678635008);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_79 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[4].V_x_ObjectLength, 340282346638528897590636046441678635008);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_79;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_79.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[4].V_m_ObjectWidth, 340282346638528897590636046441678635008);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_80 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[4].V_m_ObjectWidth, 340282346638528897590636046441678635008);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_80;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_80.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[4].V_m_ObjectPosX, 340282346638528897590636046441678635008);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_81 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[4].V_m_ObjectPosX, 340282346638528897590636046441678635008);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_81;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_81.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[4].V_m_ObjectPosY, 340282346638528897590636046441678635008);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_82 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[4].V_m_ObjectPosY, 340282346638528897590636046441678635008);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_82;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_82.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[4].V_mps_ObjectVelX, 340282346638528897590636046441678635008);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_83 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[4].V_mps_ObjectVelX, 340282346638528897590636046441678635008);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_83;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_83.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[4].V_mps_ObjectVelY, 340282346638528897590636046441678635008);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_84 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[4].V_mps_ObjectVelY, 340282346638528897590636046441678635008);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_84;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_84.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[4].V_x_ObjectType, 255);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_85 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[4].V_x_ObjectType, 255);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_85;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_85.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[4].V_x_ObjectStatus, 255);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_86 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[4].V_x_ObjectStatus, 255);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_86;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_86.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[4].V_x_ObjectValid, 255);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_87 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[4].V_x_ObjectValid, 255);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_87;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_87.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[4].V_x_ObjectLane, 255);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_88 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[4].V_x_ObjectLane, 255);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_88;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_88.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[4].V_s_TTC, 340282346638528897590636046441678635008);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_89 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[4].V_s_TTC, 340282346638528897590636046441678635008);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_89;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_89.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[4].V_mps2_ObjectAccelX, 340282346638528897590636046441678635008);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_90 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[4].V_mps2_ObjectAccelX, 340282346638528897590636046441678635008);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_90;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_90.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[4].V_x_BlinkInfo, 255);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_91 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[4].V_x_BlinkInfo, 255);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_91;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_91.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[4].V_degps_ObjectAngleRate, 340282346638528897590636046441678635008);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_92 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[4].V_degps_ObjectAngleRate, 340282346638528897590636046441678635008);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_92;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_92.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[4].V_deg_ObjectAngle, 340282346638528897590636046441678635008);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_93 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[4].V_deg_ObjectAngle, 340282346638528897590636046441678635008);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_93;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_93.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[4].V_mps_ObejectRelVelocity, 340282346638528897590636046441678635008);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_94 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[4].V_mps_ObejectRelVelocity, 340282346638528897590636046441678635008);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_94;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_94.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[5].llTimeStamp, 4294967295);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_95 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[5].llTimeStamp, 4294967295);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_95;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_95.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[5].V_x_ObjectID, 255);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_96 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[5].V_x_ObjectID, 255);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_96;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_96.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[5].F_x_CIPV, 255);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_97 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[5].F_x_CIPV, 255);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_97;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_97.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[5].V_x_ObjectLength, 340282346638528897590636046441678635008);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_98 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[5].V_x_ObjectLength, 340282346638528897590636046441678635008);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_98;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_98.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[5].V_m_ObjectWidth, 340282346638528897590636046441678635008);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_99 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[5].V_m_ObjectWidth, 340282346638528897590636046441678635008);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_99;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_99.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[5].V_m_ObjectPosX, 340282346638528897590636046441678635008);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_100 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[5].V_m_ObjectPosX, 340282346638528897590636046441678635008);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_100;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_100.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[5].V_m_ObjectPosY, 340282346638528897590636046441678635008);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_101 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[5].V_m_ObjectPosY, 340282346638528897590636046441678635008);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_101;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_101.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[5].V_mps_ObjectVelX, 340282346638528897590636046441678635008);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_102 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[5].V_mps_ObjectVelX, 340282346638528897590636046441678635008);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_102;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_102.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[5].V_mps_ObjectVelY, 340282346638528897590636046441678635008);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_103 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[5].V_mps_ObjectVelY, 340282346638528897590636046441678635008);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_103;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_103.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[5].V_x_ObjectType, 255);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_104 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[5].V_x_ObjectType, 255);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_104;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_104.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[5].V_x_ObjectStatus, 255);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_105 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[5].V_x_ObjectStatus, 255);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_105;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_105.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[5].V_x_ObjectValid, 255);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_106 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[5].V_x_ObjectValid, 255);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_106;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_106.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[5].V_x_ObjectLane, 255);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_107 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[5].V_x_ObjectLane, 255);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_107;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_107.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[5].V_s_TTC, 340282346638528897590636046441678635008);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_108 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[5].V_s_TTC, 340282346638528897590636046441678635008);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_108;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_108.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[5].V_mps2_ObjectAccelX, 340282346638528897590636046441678635008);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_109 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[5].V_mps2_ObjectAccelX, 340282346638528897590636046441678635008);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_109;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_109.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[5].V_x_BlinkInfo, 255);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_110 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[5].V_x_BlinkInfo, 255);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_110;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_110.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[5].V_degps_ObjectAngleRate, 340282346638528897590636046441678635008);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_111 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[5].V_degps_ObjectAngleRate, 340282346638528897590636046441678635008);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_111;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_111.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[5].V_deg_ObjectAngle, 340282346638528897590636046441678635008);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_112 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[5].V_deg_ObjectAngle, 340282346638528897590636046441678635008);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_112;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_112.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[5].V_mps_ObejectRelVelocity, 340282346638528897590636046441678635008);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_113 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[5].V_mps_ObejectRelVelocity, 340282346638528897590636046441678635008);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_113;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_113.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[6].llTimeStamp, 4294967295);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_114 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[6].llTimeStamp, 4294967295);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_114;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_114.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[6].V_x_ObjectID, 255);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_115 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[6].V_x_ObjectID, 255);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_115;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_115.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[6].F_x_CIPV, 255);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_116 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[6].F_x_CIPV, 255);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_116;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_116.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[6].V_x_ObjectLength, 340282346638528897590636046441678635008);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_117 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[6].V_x_ObjectLength, 340282346638528897590636046441678635008);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_117;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_117.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[6].V_m_ObjectWidth, 340282346638528897590636046441678635008);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_118 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[6].V_m_ObjectWidth, 340282346638528897590636046441678635008);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_118;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_118.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[6].V_m_ObjectPosX, 340282346638528897590636046441678635008);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_119 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[6].V_m_ObjectPosX, 340282346638528897590636046441678635008);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_119;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_119.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[6].V_m_ObjectPosY, 340282346638528897590636046441678635008);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_120 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[6].V_m_ObjectPosY, 340282346638528897590636046441678635008);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_120;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_120.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[6].V_mps_ObjectVelX, 340282346638528897590636046441678635008);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_121 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[6].V_mps_ObjectVelX, 340282346638528897590636046441678635008);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_121;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_121.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[6].V_mps_ObjectVelY, 340282346638528897590636046441678635008);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_122 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[6].V_mps_ObjectVelY, 340282346638528897590636046441678635008);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_122;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_122.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[6].V_x_ObjectType, 255);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_123 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[6].V_x_ObjectType, 255);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_123;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_123.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[6].V_x_ObjectStatus, 255);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_124 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[6].V_x_ObjectStatus, 255);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_124;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_124.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[6].V_x_ObjectValid, 255);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_125 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[6].V_x_ObjectValid, 255);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_125;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_125.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[6].V_x_ObjectLane, 255);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_126 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[6].V_x_ObjectLane, 255);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_126;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_126.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[6].V_s_TTC, 340282346638528897590636046441678635008);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_127 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[6].V_s_TTC, 340282346638528897590636046441678635008);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_127;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_127.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[6].V_mps2_ObjectAccelX, 340282346638528897590636046441678635008);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_128 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[6].V_mps2_ObjectAccelX, 340282346638528897590636046441678635008);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_128;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_128.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[6].V_x_BlinkInfo, 255);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_129 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[6].V_x_BlinkInfo, 255);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_129;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_129.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[6].V_degps_ObjectAngleRate, 340282346638528897590636046441678635008);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_130 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[6].V_degps_ObjectAngleRate, 340282346638528897590636046441678635008);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_130;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_130.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[6].V_deg_ObjectAngle, 340282346638528897590636046441678635008);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_131 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[6].V_deg_ObjectAngle, 340282346638528897590636046441678635008);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_131;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_131.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[6].V_mps_ObejectRelVelocity, 340282346638528897590636046441678635008);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_132 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[6].V_mps_ObejectRelVelocity, 340282346638528897590636046441678635008);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_132;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_132.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[7].llTimeStamp, 4294967295);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_133 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[7].llTimeStamp, 4294967295);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_133;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_133.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[7].V_x_ObjectID, 255);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_134 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[7].V_x_ObjectID, 255);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_134;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_134.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[7].F_x_CIPV, 255);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_135 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[7].F_x_CIPV, 255);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_135;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_135.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[7].V_x_ObjectLength, 340282346638528897590636046441678635008);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_136 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[7].V_x_ObjectLength, 340282346638528897590636046441678635008);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_136;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_136.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[7].V_m_ObjectWidth, 340282346638528897590636046441678635008);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_137 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[7].V_m_ObjectWidth, 340282346638528897590636046441678635008);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_137;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_137.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[7].V_m_ObjectPosX, 340282346638528897590636046441678635008);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_138 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[7].V_m_ObjectPosX, 340282346638528897590636046441678635008);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_138;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_138.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[7].V_m_ObjectPosY, 340282346638528897590636046441678635008);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_139 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[7].V_m_ObjectPosY, 340282346638528897590636046441678635008);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_139;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_139.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[7].V_mps_ObjectVelX, 340282346638528897590636046441678635008);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_140 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[7].V_mps_ObjectVelX, 340282346638528897590636046441678635008);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_140;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_140.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[7].V_mps_ObjectVelY, 340282346638528897590636046441678635008);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_141 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[7].V_mps_ObjectVelY, 340282346638528897590636046441678635008);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_141;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_141.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[7].V_x_ObjectType, 255);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_142 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[7].V_x_ObjectType, 255);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_142;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_142.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[7].V_x_ObjectStatus, 255);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_143 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[7].V_x_ObjectStatus, 255);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_143;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_143.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[7].V_x_ObjectValid, 255);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_144 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[7].V_x_ObjectValid, 255);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_144;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_144.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[7].V_x_ObjectLane, 255);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_145 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[7].V_x_ObjectLane, 255);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_145;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_145.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[7].V_s_TTC, 340282346638528897590636046441678635008);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_146 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[7].V_s_TTC, 340282346638528897590636046441678635008);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_146;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_146.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[7].V_mps2_ObjectAccelX, 340282346638528897590636046441678635008);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_147 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[7].V_mps2_ObjectAccelX, 340282346638528897590636046441678635008);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_147;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_147.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[7].V_x_BlinkInfo, 255);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_148 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[7].V_x_BlinkInfo, 255);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_148;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_148.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[7].V_degps_ObjectAngleRate, 340282346638528897590636046441678635008);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_149 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[7].V_degps_ObjectAngleRate, 340282346638528897590636046441678635008);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_149;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_149.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[7].V_deg_ObjectAngle, 340282346638528897590636046441678635008);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_150 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[7].V_deg_ObjectAngle, 340282346638528897590636046441678635008);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_150;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_150.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[7].V_mps_ObejectRelVelocity, 340282346638528897590636046441678635008);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_151 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[7].V_mps_ObejectRelVelocity, 340282346638528897590636046441678635008);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_151;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_151.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[8].llTimeStamp, 4294967295);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_152 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[8].llTimeStamp, 4294967295);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_152;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_152.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[8].V_x_ObjectID, 255);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_153 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[8].V_x_ObjectID, 255);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_153;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_153.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[8].F_x_CIPV, 255);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_154 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[8].F_x_CIPV, 255);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_154;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_154.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[8].V_x_ObjectLength, 340282346638528897590636046441678635008);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_155 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[8].V_x_ObjectLength, 340282346638528897590636046441678635008);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_155;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_155.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[8].V_m_ObjectWidth, 340282346638528897590636046441678635008);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_156 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[8].V_m_ObjectWidth, 340282346638528897590636046441678635008);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_156;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_156.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[8].V_m_ObjectPosX, 340282346638528897590636046441678635008);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_157 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[8].V_m_ObjectPosX, 340282346638528897590636046441678635008);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_157;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_157.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[8].V_m_ObjectPosY, 340282346638528897590636046441678635008);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_158 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[8].V_m_ObjectPosY, 340282346638528897590636046441678635008);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_158;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_158.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[8].V_mps_ObjectVelX, 340282346638528897590636046441678635008);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_159 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[8].V_mps_ObjectVelX, 340282346638528897590636046441678635008);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_159;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_159.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[8].V_mps_ObjectVelY, 340282346638528897590636046441678635008);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_160 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[8].V_mps_ObjectVelY, 340282346638528897590636046441678635008);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_160;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_160.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[8].V_x_ObjectType, 255);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_161 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[8].V_x_ObjectType, 255);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_161;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_161.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[8].V_x_ObjectStatus, 255);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_162 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[8].V_x_ObjectStatus, 255);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_162;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_162.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[8].V_x_ObjectValid, 255);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_163 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[8].V_x_ObjectValid, 255);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_163;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_163.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[8].V_x_ObjectLane, 255);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_164 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[8].V_x_ObjectLane, 255);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_164;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_164.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[8].V_s_TTC, 340282346638528897590636046441678635008);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_165 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[8].V_s_TTC, 340282346638528897590636046441678635008);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_165;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_165.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[8].V_mps2_ObjectAccelX, 340282346638528897590636046441678635008);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_166 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[8].V_mps2_ObjectAccelX, 340282346638528897590636046441678635008);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_166;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_166.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[8].V_x_BlinkInfo, 255);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_167 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[8].V_x_BlinkInfo, 255);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_167;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_167.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[8].V_degps_ObjectAngleRate, 340282346638528897590636046441678635008);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_168 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[8].V_degps_ObjectAngleRate, 340282346638528897590636046441678635008);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_168;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_168.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[8].V_deg_ObjectAngle, 340282346638528897590636046441678635008);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_169 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[8].V_deg_ObjectAngle, 340282346638528897590636046441678635008);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_169;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_169.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[8].V_mps_ObejectRelVelocity, 340282346638528897590636046441678635008);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_170 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[8].V_mps_ObejectRelVelocity, 340282346638528897590636046441678635008);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_170;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_170.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[9].llTimeStamp, 4294967295);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_171 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[9].llTimeStamp, 4294967295);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_171;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_171.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[9].V_x_ObjectID, 255);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_172 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[9].V_x_ObjectID, 255);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_172;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_172.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[9].F_x_CIPV, 255);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_173 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[9].F_x_CIPV, 255);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_173;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_173.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[9].V_x_ObjectLength, 340282346638528897590636046441678635008);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_174 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[9].V_x_ObjectLength, 340282346638528897590636046441678635008);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_174;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_174.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[9].V_m_ObjectWidth, 340282346638528897590636046441678635008);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_175 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[9].V_m_ObjectWidth, 340282346638528897590636046441678635008);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_175;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_175.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[9].V_m_ObjectPosX, 340282346638528897590636046441678635008);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_176 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[9].V_m_ObjectPosX, 340282346638528897590636046441678635008);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_176;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_176.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[9].V_m_ObjectPosY, 340282346638528897590636046441678635008);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_177 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[9].V_m_ObjectPosY, 340282346638528897590636046441678635008);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_177;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_177.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[9].V_mps_ObjectVelX, 340282346638528897590636046441678635008);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_178 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[9].V_mps_ObjectVelX, 340282346638528897590636046441678635008);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_178;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_178.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[9].V_mps_ObjectVelY, 340282346638528897590636046441678635008);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_179 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[9].V_mps_ObjectVelY, 340282346638528897590636046441678635008);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_179;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_179.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[9].V_x_ObjectType, 255);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_180 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[9].V_x_ObjectType, 255);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_180;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_180.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[9].V_x_ObjectStatus, 255);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_181 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[9].V_x_ObjectStatus, 255);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_181;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_181.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[9].V_x_ObjectValid, 255);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_182 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[9].V_x_ObjectValid, 255);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_182;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_182.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[9].V_x_ObjectLane, 255);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_183 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[9].V_x_ObjectLane, 255);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_183;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_183.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[9].V_s_TTC, 340282346638528897590636046441678635008);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_184 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[9].V_s_TTC, 340282346638528897590636046441678635008);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_184;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_184.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[9].V_mps2_ObjectAccelX, 340282346638528897590636046441678635008);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_185 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[9].V_mps2_ObjectAccelX, 340282346638528897590636046441678635008);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_185;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_185.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[9].V_x_BlinkInfo, 255);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_186 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[9].V_x_BlinkInfo, 255);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_186;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_186.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[9].V_degps_ObjectAngleRate, 340282346638528897590636046441678635008);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_187 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[9].V_degps_ObjectAngleRate, 340282346638528897590636046441678635008);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_187;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_187.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[9].V_deg_ObjectAngle, 340282346638528897590636046441678635008);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_188 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[9].V_deg_ObjectAngle, 340282346638528897590636046441678635008);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_188;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_188.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[9].V_mps_ObejectRelVelocity, 340282346638528897590636046441678635008);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_189 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_MasterObjDataModified[9].V_mps_ObejectRelVelocity, 340282346638528897590636046441678635008);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_189;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_189.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_front_cam_lane_2[0].llTimeStamp, 4294967295);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_190 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_EQ(tmp_RCarHMIManagementSensorInput.V_x_front_cam_lane_2[0].llTimeStamp, 4294967295);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_190;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_190.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_front_cam_lane_2[0].V_x_LaneType, 255);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_191 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_EQ(tmp_RCarHMIManagementSensorInput.V_x_front_cam_lane_2[0].V_x_LaneType, 255);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_191;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_191.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_front_cam_lane_2[0].V_x_LaneQuality, 255);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_192 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_EQ(tmp_RCarHMIManagementSensorInput.V_x_front_cam_lane_2[0].V_x_LaneQuality, 255);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_192;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_192.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_front_cam_lane_2[0].V_m_LanePosition, 340282346638528897590636046441678635008);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_193 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_front_cam_lane_2[0].V_m_LanePosition, 340282346638528897590636046441678635008);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_193;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_193.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_front_cam_lane_2[0].V_pm_LineCurv, 340282346638528897590636046441678635008);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_194 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_front_cam_lane_2[0].V_pm_LineCurv, 340282346638528897590636046441678635008);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_194;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_194.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_front_cam_lane_2[0].V_pm2_LineCurvaRate, 340282346638528897590636046441678635008);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_195 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_front_cam_lane_2[0].V_pm2_LineCurvaRate, 340282346638528897590636046441678635008);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_195;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_195.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_front_cam_lane_2[0].V_m_Lane_Mark_Width, 340282346638528897590636046441678635008);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_196 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_front_cam_lane_2[0].V_m_Lane_Mark_Width, 340282346638528897590636046441678635008);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_196;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_196.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_front_cam_lane_2[0].V_rad_LineYawAng, 340282346638528897590636046441678635008);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_197 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_front_cam_lane_2[0].V_rad_LineYawAng, 340282346638528897590636046441678635008);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_197;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_197.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_front_cam_lane_2[0].V_m_ViewRange_Start, 340282346638528897590636046441678635008);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_198 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_front_cam_lane_2[0].V_m_ViewRange_Start, 340282346638528897590636046441678635008);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_198;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_198.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_front_cam_lane_2[0].V_m_ViewRange_End, 340282346638528897590636046441678635008);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_199 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_front_cam_lane_2[0].V_m_ViewRange_End, 340282346638528897590636046441678635008);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_199;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_199.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_front_cam_lane_2[0].V_x_Lane_Crossing, 255);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_200 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_EQ(tmp_RCarHMIManagementSensorInput.V_x_front_cam_lane_2[0].V_x_Lane_Crossing, 255);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_200;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_200.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_front_cam_lane_2[0].V_x_Confidence_HWE, 255);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_201 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_EQ(tmp_RCarHMIManagementSensorInput.V_x_front_cam_lane_2[0].V_x_Confidence_HWE, 255);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_201;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_201.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_front_cam_lane_2[1].llTimeStamp, 4294967295);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_202 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_EQ(tmp_RCarHMIManagementSensorInput.V_x_front_cam_lane_2[1].llTimeStamp, 4294967295);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_202;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_202.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_front_cam_lane_2[1].V_x_LaneType, 255);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_203 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_EQ(tmp_RCarHMIManagementSensorInput.V_x_front_cam_lane_2[1].V_x_LaneType, 255);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_203;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_203.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_front_cam_lane_2[1].V_x_LaneQuality, 255);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_204 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_EQ(tmp_RCarHMIManagementSensorInput.V_x_front_cam_lane_2[1].V_x_LaneQuality, 255);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_204;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_204.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_front_cam_lane_2[1].V_m_LanePosition, 340282346638528897590636046441678635008);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_205 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_front_cam_lane_2[1].V_m_LanePosition, 340282346638528897590636046441678635008);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_205;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_205.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_front_cam_lane_2[1].V_pm_LineCurv, 340282346638528897590636046441678635008);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_206 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_front_cam_lane_2[1].V_pm_LineCurv, 340282346638528897590636046441678635008);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_206;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_206.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_front_cam_lane_2[1].V_pm2_LineCurvaRate, 340282346638528897590636046441678635008);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_207 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_front_cam_lane_2[1].V_pm2_LineCurvaRate, 340282346638528897590636046441678635008);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_207;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_207.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_front_cam_lane_2[1].V_m_Lane_Mark_Width, 340282346638528897590636046441678635008);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_208 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_front_cam_lane_2[1].V_m_Lane_Mark_Width, 340282346638528897590636046441678635008);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_208;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_208.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_front_cam_lane_2[1].V_rad_LineYawAng, 340282346638528897590636046441678635008);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_209 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_front_cam_lane_2[1].V_rad_LineYawAng, 340282346638528897590636046441678635008);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_209;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_209.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_front_cam_lane_2[1].V_m_ViewRange_Start, 340282346638528897590636046441678635008);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_210 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_front_cam_lane_2[1].V_m_ViewRange_Start, 340282346638528897590636046441678635008);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_210;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_210.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_front_cam_lane_2[1].V_m_ViewRange_End, 340282346638528897590636046441678635008);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_211 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_front_cam_lane_2[1].V_m_ViewRange_End, 340282346638528897590636046441678635008);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_211;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_211.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_front_cam_lane_2[1].V_x_Lane_Crossing, 255);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_212 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_EQ(tmp_RCarHMIManagementSensorInput.V_x_front_cam_lane_2[1].V_x_Lane_Crossing, 255);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_212;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_212.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_front_cam_lane_2[1].V_x_Confidence_HWE, 255);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_213 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_EQ(tmp_RCarHMIManagementSensorInput.V_x_front_cam_lane_2[1].V_x_Confidence_HWE, 255);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_213;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_213.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_front_cam_nextlane_2[0].V_x_NextLaneType, 255);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_214 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_EQ(tmp_RCarHMIManagementSensorInput.V_x_front_cam_nextlane_2[0].V_x_NextLaneType, 255);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_214;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_214.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_front_cam_nextlane_2[0].V_x_NextLaneQuality, 255);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_215 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_EQ(tmp_RCarHMIManagementSensorInput.V_x_front_cam_nextlane_2[0].V_x_NextLaneQuality, 255);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_215;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_215.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_front_cam_nextlane_2[0].V_m_NextLanePosition, 340282346638528897590636046441678635008);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_216 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_front_cam_nextlane_2[0].V_m_NextLanePosition, 340282346638528897590636046441678635008);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_216;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_216.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_front_cam_nextlane_2[0].V_pm_NextLineCurv, 340282346638528897590636046441678635008);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_217 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_front_cam_nextlane_2[0].V_pm_NextLineCurv, 340282346638528897590636046441678635008);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_217;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_217.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_front_cam_nextlane_2[0].V_pm2_NextLineCurvaRate, 340282346638528897590636046441678635008);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_218 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_front_cam_nextlane_2[0].V_pm2_NextLineCurvaRate, 340282346638528897590636046441678635008);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_218;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_218.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_front_cam_nextlane_2[0].V_m_NextLane_Mark_Width, 340282346638528897590636046441678635008);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_219 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_front_cam_nextlane_2[0].V_m_NextLane_Mark_Width, 340282346638528897590636046441678635008);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_219;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_219.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_front_cam_nextlane_2[0].V_rad_NextLineYawAng, 340282346638528897590636046441678635008);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_220 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_front_cam_nextlane_2[0].V_rad_NextLineYawAng, 340282346638528897590636046441678635008);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_220;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_220.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_front_cam_nextlane_2[0].V_m_NextViewRange_Start, 340282346638528897590636046441678635008);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_221 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_front_cam_nextlane_2[0].V_m_NextViewRange_Start, 340282346638528897590636046441678635008);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_221;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_221.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_front_cam_nextlane_2[0].V_m_NextViewRange_End, 340282346638528897590636046441678635008);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_222 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_front_cam_nextlane_2[0].V_m_NextViewRange_End, 340282346638528897590636046441678635008);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_222;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_222.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_front_cam_nextlane_2[0].V_x_ConfMeasure, 340282346638528897590636046441678635008);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_223 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_front_cam_nextlane_2[0].V_x_ConfMeasure, 340282346638528897590636046441678635008);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_223;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_223.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_front_cam_nextlane_2[1].V_x_NextLaneType, 255);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_224 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_EQ(tmp_RCarHMIManagementSensorInput.V_x_front_cam_nextlane_2[1].V_x_NextLaneType, 255);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_224;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_224.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_front_cam_nextlane_2[1].V_x_NextLaneQuality, 255);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_225 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_EQ(tmp_RCarHMIManagementSensorInput.V_x_front_cam_nextlane_2[1].V_x_NextLaneQuality, 255);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_225;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_225.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_front_cam_nextlane_2[1].V_m_NextLanePosition, 340282346638528897590636046441678635008);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_226 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_front_cam_nextlane_2[1].V_m_NextLanePosition, 340282346638528897590636046441678635008);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_226;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_226.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_front_cam_nextlane_2[1].V_pm_NextLineCurv, 340282346638528897590636046441678635008);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_227 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_front_cam_nextlane_2[1].V_pm_NextLineCurv, 340282346638528897590636046441678635008);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_227;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_227.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_front_cam_nextlane_2[1].V_pm2_NextLineCurvaRate, 340282346638528897590636046441678635008);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_228 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_front_cam_nextlane_2[1].V_pm2_NextLineCurvaRate, 340282346638528897590636046441678635008);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_228;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_228.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_front_cam_nextlane_2[1].V_m_NextLane_Mark_Width, 340282346638528897590636046441678635008);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_229 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_front_cam_nextlane_2[1].V_m_NextLane_Mark_Width, 340282346638528897590636046441678635008);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_229;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_229.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_front_cam_nextlane_2[1].V_rad_NextLineYawAng, 340282346638528897590636046441678635008);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_230 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_front_cam_nextlane_2[1].V_rad_NextLineYawAng, 340282346638528897590636046441678635008);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_230;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_230.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_front_cam_nextlane_2[1].V_m_NextViewRange_Start, 340282346638528897590636046441678635008);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_231 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_front_cam_nextlane_2[1].V_m_NextViewRange_Start, 340282346638528897590636046441678635008);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_231;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_231.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_front_cam_nextlane_2[1].V_m_NextViewRange_End, 340282346638528897590636046441678635008);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_232 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_front_cam_nextlane_2[1].V_m_NextViewRange_End, 340282346638528897590636046441678635008);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_232;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_232.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_RCarHMIManagementSensorInput.V_x_front_cam_nextlane_2[1].V_x_ConfMeasure, 340282346638528897590636046441678635008);
    struct _func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_233 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
            Rte_Read_V_x_RCarHMIManagementSensorInput_V_x_RCarHMIManagementSensorInput(&tmp_RCarHMIManagementSensorInput);
            EXPECT_FLOAT_EQ(tmp_RCarHMIManagementSensorInput.V_x_front_cam_nextlane_2[1].V_x_ConfMeasure, 340282346638528897590636046441678635008);
        }
    } func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_233;
    func_V_x_RCarHMIManagementSensorInput_RCarHMIManagement_233.verify();

    /* V_x_clustered_side_radar_obj_num */
    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_num, 2147483647);
    struct _func_V_x_clustered_side_radar_obj_num_RCarHMIManagement {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            sint32 tmp_S32;
            Rte_Read_V_x_clustered_side_radar_obj_num_V_x_clustered_side_radar_obj_num(&tmp_S32);
            EXPECT_EQ(tmp_S32, 2147483647);
        }
    } func_V_x_clustered_side_radar_obj_num_RCarHMIManagement;
    func_V_x_clustered_side_radar_obj_num_RCarHMIManagement.verify();

    /* V_x_clustered_side_radar_obj_t */
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[0].V_x_pos.V_m_X, 340282346638528897590636046441678635008);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_0 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[0].V_x_pos.V_m_X, 340282346638528897590636046441678635008);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_0;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_0.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[0].V_x_pos.V_m_Y, 340282346638528897590636046441678635008);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_1 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[0].V_x_pos.V_m_Y, 340282346638528897590636046441678635008);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_1;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_1.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[0].V_x_vel.V_m_X, 340282346638528897590636046441678635008);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_2 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[0].V_x_vel.V_m_X, 340282346638528897590636046441678635008);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_2;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_2.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[0].V_x_vel.V_m_Y, 340282346638528897590636046441678635008);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_3 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[0].V_x_vel.V_m_Y, 340282346638528897590636046441678635008);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_3;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_3.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[0].V_m_lat_pos_in_lane[0], 3.4028235e+38);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[0].V_m_lat_pos_in_lane[1], 3.4028235e+38);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[0].V_m_lat_pos_in_lane[2], 3.4028235e+38);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[0].V_m_lat_pos_in_lane[3], 3.4028235e+38);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[0].V_m_lat_pos_in_lane[4], 3.4028235e+38);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_4 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[0].V_m_lat_pos_in_lane[0], 3.4028235e+38);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[0].V_m_lat_pos_in_lane[1], 3.4028235e+38);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[0].V_m_lat_pos_in_lane[2], 3.4028235e+38);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[0].V_m_lat_pos_in_lane[3], 3.4028235e+38);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[0].V_m_lat_pos_in_lane[4], 3.4028235e+38);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_4;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_4.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[0].V_m_lat_vel_in_lane, 340282346638528897590636046441678635008);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_5 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[0].V_m_lat_vel_in_lane, 340282346638528897590636046441678635008);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_5;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_5.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[0].V_m_width, 340282346638528897590636046441678635008);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_6 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[0].V_m_width, 340282346638528897590636046441678635008);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_6;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_6.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[0].V_x_ID, 4294967295);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_7 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[0].V_x_ID, 4294967295);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_7;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_7.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[0].V_x_type, 4294967295);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_8 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[0].V_x_type, 4294967295);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_8;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_8.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[0].V_x_lane, 255);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_9 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[0].V_x_lane, 255);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_9;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_9.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[0].V_x_is_valid, 255);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_10 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[0].V_x_is_valid, 255);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_10;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_10.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[0].V_x_is_usable, 255);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_11 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[0].V_x_is_usable, 255);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_11;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_11.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[0].V_x_border, 4294967295);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_12 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[0].V_x_border, 4294967295);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_12;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_12.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[0].V_x_lost, 255);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_13 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[0].V_x_lost, 255);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_13;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_13.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[1].V_x_pos.V_m_X, 340282346638528897590636046441678635008);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_14 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[1].V_x_pos.V_m_X, 340282346638528897590636046441678635008);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_14;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_14.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[1].V_x_pos.V_m_Y, 340282346638528897590636046441678635008);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_15 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[1].V_x_pos.V_m_Y, 340282346638528897590636046441678635008);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_15;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_15.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[1].V_x_vel.V_m_X, 340282346638528897590636046441678635008);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_16 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[1].V_x_vel.V_m_X, 340282346638528897590636046441678635008);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_16;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_16.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[1].V_x_vel.V_m_Y, 340282346638528897590636046441678635008);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_17 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[1].V_x_vel.V_m_Y, 340282346638528897590636046441678635008);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_17;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_17.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[1].V_m_lat_pos_in_lane[0], 3.4028235e+38);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[1].V_m_lat_pos_in_lane[1], 3.4028235e+38);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[1].V_m_lat_pos_in_lane[2], 3.4028235e+38);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[1].V_m_lat_pos_in_lane[3], 3.4028235e+38);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[1].V_m_lat_pos_in_lane[4], 3.4028235e+38);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_18 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[1].V_m_lat_pos_in_lane[0], 3.4028235e+38);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[1].V_m_lat_pos_in_lane[1], 3.4028235e+38);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[1].V_m_lat_pos_in_lane[2], 3.4028235e+38);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[1].V_m_lat_pos_in_lane[3], 3.4028235e+38);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[1].V_m_lat_pos_in_lane[4], 3.4028235e+38);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_18;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_18.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[1].V_m_lat_vel_in_lane, 340282346638528897590636046441678635008);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_19 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[1].V_m_lat_vel_in_lane, 340282346638528897590636046441678635008);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_19;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_19.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[1].V_m_width, 340282346638528897590636046441678635008);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_20 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[1].V_m_width, 340282346638528897590636046441678635008);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_20;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_20.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[1].V_x_ID, 4294967295);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_21 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[1].V_x_ID, 4294967295);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_21;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_21.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[1].V_x_type, 4294967295);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_22 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[1].V_x_type, 4294967295);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_22;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_22.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[1].V_x_lane, 255);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_23 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[1].V_x_lane, 255);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_23;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_23.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[1].V_x_is_valid, 255);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_24 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[1].V_x_is_valid, 255);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_24;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_24.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[1].V_x_is_usable, 255);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_25 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[1].V_x_is_usable, 255);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_25;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_25.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[1].V_x_border, 4294967295);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_26 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[1].V_x_border, 4294967295);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_26;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_26.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[1].V_x_lost, 255);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_27 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[1].V_x_lost, 255);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_27;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_27.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[2].V_x_pos.V_m_X, 340282346638528897590636046441678635008);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_28 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[2].V_x_pos.V_m_X, 340282346638528897590636046441678635008);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_28;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_28.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[2].V_x_pos.V_m_Y, 340282346638528897590636046441678635008);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_29 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[2].V_x_pos.V_m_Y, 340282346638528897590636046441678635008);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_29;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_29.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[2].V_x_vel.V_m_X, 340282346638528897590636046441678635008);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_30 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[2].V_x_vel.V_m_X, 340282346638528897590636046441678635008);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_30;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_30.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[2].V_x_vel.V_m_Y, 340282346638528897590636046441678635008);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_31 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[2].V_x_vel.V_m_Y, 340282346638528897590636046441678635008);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_31;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_31.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[2].V_m_lat_pos_in_lane[0], 3.4028235e+38);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[2].V_m_lat_pos_in_lane[1], 3.4028235e+38);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[2].V_m_lat_pos_in_lane[2], 3.4028235e+38);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[2].V_m_lat_pos_in_lane[3], 3.4028235e+38);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[2].V_m_lat_pos_in_lane[4], 3.4028235e+38);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_32 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[2].V_m_lat_pos_in_lane[0], 3.4028235e+38);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[2].V_m_lat_pos_in_lane[1], 3.4028235e+38);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[2].V_m_lat_pos_in_lane[2], 3.4028235e+38);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[2].V_m_lat_pos_in_lane[3], 3.4028235e+38);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[2].V_m_lat_pos_in_lane[4], 3.4028235e+38);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_32;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_32.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[2].V_m_lat_vel_in_lane, 340282346638528897590636046441678635008);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_33 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[2].V_m_lat_vel_in_lane, 340282346638528897590636046441678635008);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_33;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_33.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[2].V_m_width, 340282346638528897590636046441678635008);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_34 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[2].V_m_width, 340282346638528897590636046441678635008);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_34;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_34.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[2].V_x_ID, 4294967295);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_35 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[2].V_x_ID, 4294967295);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_35;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_35.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[2].V_x_type, 4294967295);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_36 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[2].V_x_type, 4294967295);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_36;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_36.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[2].V_x_lane, 255);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_37 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[2].V_x_lane, 255);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_37;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_37.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[2].V_x_is_valid, 255);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_38 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[2].V_x_is_valid, 255);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_38;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_38.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[2].V_x_is_usable, 255);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_39 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[2].V_x_is_usable, 255);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_39;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_39.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[2].V_x_border, 4294967295);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_40 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[2].V_x_border, 4294967295);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_40;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_40.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[2].V_x_lost, 255);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_41 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[2].V_x_lost, 255);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_41;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_41.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[3].V_x_pos.V_m_X, 340282346638528897590636046441678635008);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_42 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[3].V_x_pos.V_m_X, 340282346638528897590636046441678635008);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_42;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_42.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[3].V_x_pos.V_m_Y, 340282346638528897590636046441678635008);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_43 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[3].V_x_pos.V_m_Y, 340282346638528897590636046441678635008);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_43;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_43.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[3].V_x_vel.V_m_X, 340282346638528897590636046441678635008);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_44 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[3].V_x_vel.V_m_X, 340282346638528897590636046441678635008);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_44;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_44.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[3].V_x_vel.V_m_Y, 340282346638528897590636046441678635008);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_45 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[3].V_x_vel.V_m_Y, 340282346638528897590636046441678635008);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_45;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_45.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[3].V_m_lat_pos_in_lane[0], 3.4028235e+38);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[3].V_m_lat_pos_in_lane[1], 3.4028235e+38);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[3].V_m_lat_pos_in_lane[2], 3.4028235e+38);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[3].V_m_lat_pos_in_lane[3], 3.4028235e+38);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[3].V_m_lat_pos_in_lane[4], 3.4028235e+38);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_46 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[3].V_m_lat_pos_in_lane[0], 3.4028235e+38);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[3].V_m_lat_pos_in_lane[1], 3.4028235e+38);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[3].V_m_lat_pos_in_lane[2], 3.4028235e+38);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[3].V_m_lat_pos_in_lane[3], 3.4028235e+38);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[3].V_m_lat_pos_in_lane[4], 3.4028235e+38);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_46;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_46.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[3].V_m_lat_vel_in_lane, 340282346638528897590636046441678635008);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_47 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[3].V_m_lat_vel_in_lane, 340282346638528897590636046441678635008);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_47;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_47.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[3].V_m_width, 340282346638528897590636046441678635008);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_48 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[3].V_m_width, 340282346638528897590636046441678635008);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_48;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_48.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[3].V_x_ID, 4294967295);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_49 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[3].V_x_ID, 4294967295);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_49;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_49.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[3].V_x_type, 4294967295);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_50 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[3].V_x_type, 4294967295);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_50;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_50.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[3].V_x_lane, 255);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_51 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[3].V_x_lane, 255);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_51;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_51.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[3].V_x_is_valid, 255);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_52 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[3].V_x_is_valid, 255);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_52;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_52.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[3].V_x_is_usable, 255);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_53 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[3].V_x_is_usable, 255);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_53;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_53.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[3].V_x_border, 4294967295);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_54 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[3].V_x_border, 4294967295);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_54;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_54.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[3].V_x_lost, 255);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_55 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[3].V_x_lost, 255);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_55;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_55.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[4].V_x_pos.V_m_X, 340282346638528897590636046441678635008);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_56 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[4].V_x_pos.V_m_X, 340282346638528897590636046441678635008);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_56;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_56.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[4].V_x_pos.V_m_Y, 340282346638528897590636046441678635008);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_57 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[4].V_x_pos.V_m_Y, 340282346638528897590636046441678635008);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_57;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_57.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[4].V_x_vel.V_m_X, 340282346638528897590636046441678635008);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_58 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[4].V_x_vel.V_m_X, 340282346638528897590636046441678635008);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_58;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_58.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[4].V_x_vel.V_m_Y, 340282346638528897590636046441678635008);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_59 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[4].V_x_vel.V_m_Y, 340282346638528897590636046441678635008);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_59;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_59.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[4].V_m_lat_pos_in_lane[0], 3.4028235e+38);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[4].V_m_lat_pos_in_lane[1], 3.4028235e+38);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[4].V_m_lat_pos_in_lane[2], 3.4028235e+38);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[4].V_m_lat_pos_in_lane[3], 3.4028235e+38);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[4].V_m_lat_pos_in_lane[4], 3.4028235e+38);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_60 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[4].V_m_lat_pos_in_lane[0], 3.4028235e+38);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[4].V_m_lat_pos_in_lane[1], 3.4028235e+38);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[4].V_m_lat_pos_in_lane[2], 3.4028235e+38);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[4].V_m_lat_pos_in_lane[3], 3.4028235e+38);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[4].V_m_lat_pos_in_lane[4], 3.4028235e+38);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_60;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_60.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[4].V_m_lat_vel_in_lane, 340282346638528897590636046441678635008);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_61 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[4].V_m_lat_vel_in_lane, 340282346638528897590636046441678635008);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_61;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_61.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[4].V_m_width, 340282346638528897590636046441678635008);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_62 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[4].V_m_width, 340282346638528897590636046441678635008);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_62;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_62.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[4].V_x_ID, 4294967295);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_63 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[4].V_x_ID, 4294967295);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_63;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_63.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[4].V_x_type, 4294967295);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_64 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[4].V_x_type, 4294967295);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_64;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_64.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[4].V_x_lane, 255);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_65 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[4].V_x_lane, 255);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_65;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_65.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[4].V_x_is_valid, 255);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_66 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[4].V_x_is_valid, 255);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_66;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_66.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[4].V_x_is_usable, 255);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_67 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[4].V_x_is_usable, 255);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_67;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_67.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[4].V_x_border, 4294967295);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_68 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[4].V_x_border, 4294967295);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_68;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_68.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[4].V_x_lost, 255);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_69 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[4].V_x_lost, 255);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_69;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_69.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[5].V_x_pos.V_m_X, 340282346638528897590636046441678635008);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_70 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[5].V_x_pos.V_m_X, 340282346638528897590636046441678635008);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_70;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_70.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[5].V_x_pos.V_m_Y, 340282346638528897590636046441678635008);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_71 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[5].V_x_pos.V_m_Y, 340282346638528897590636046441678635008);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_71;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_71.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[5].V_x_vel.V_m_X, 340282346638528897590636046441678635008);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_72 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[5].V_x_vel.V_m_X, 340282346638528897590636046441678635008);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_72;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_72.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[5].V_x_vel.V_m_Y, 340282346638528897590636046441678635008);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_73 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[5].V_x_vel.V_m_Y, 340282346638528897590636046441678635008);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_73;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_73.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[5].V_m_lat_pos_in_lane[0], 3.4028235e+38);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[5].V_m_lat_pos_in_lane[1], 3.4028235e+38);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[5].V_m_lat_pos_in_lane[2], 3.4028235e+38);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[5].V_m_lat_pos_in_lane[3], 3.4028235e+38);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[5].V_m_lat_pos_in_lane[4], 3.4028235e+38);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_74 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[5].V_m_lat_pos_in_lane[0], 3.4028235e+38);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[5].V_m_lat_pos_in_lane[1], 3.4028235e+38);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[5].V_m_lat_pos_in_lane[2], 3.4028235e+38);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[5].V_m_lat_pos_in_lane[3], 3.4028235e+38);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[5].V_m_lat_pos_in_lane[4], 3.4028235e+38);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_74;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_74.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[5].V_m_lat_vel_in_lane, 340282346638528897590636046441678635008);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_75 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[5].V_m_lat_vel_in_lane, 340282346638528897590636046441678635008);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_75;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_75.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[5].V_m_width, 340282346638528897590636046441678635008);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_76 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[5].V_m_width, 340282346638528897590636046441678635008);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_76;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_76.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[5].V_x_ID, 4294967295);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_77 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[5].V_x_ID, 4294967295);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_77;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_77.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[5].V_x_type, 4294967295);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_78 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[5].V_x_type, 4294967295);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_78;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_78.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[5].V_x_lane, 255);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_79 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[5].V_x_lane, 255);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_79;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_79.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[5].V_x_is_valid, 255);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_80 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[5].V_x_is_valid, 255);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_80;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_80.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[5].V_x_is_usable, 255);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_81 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[5].V_x_is_usable, 255);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_81;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_81.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[5].V_x_border, 4294967295);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_82 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[5].V_x_border, 4294967295);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_82;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_82.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[5].V_x_lost, 255);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_83 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[5].V_x_lost, 255);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_83;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_83.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[6].V_x_pos.V_m_X, 340282346638528897590636046441678635008);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_84 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[6].V_x_pos.V_m_X, 340282346638528897590636046441678635008);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_84;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_84.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[6].V_x_pos.V_m_Y, 340282346638528897590636046441678635008);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_85 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[6].V_x_pos.V_m_Y, 340282346638528897590636046441678635008);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_85;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_85.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[6].V_x_vel.V_m_X, 340282346638528897590636046441678635008);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_86 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[6].V_x_vel.V_m_X, 340282346638528897590636046441678635008);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_86;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_86.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[6].V_x_vel.V_m_Y, 340282346638528897590636046441678635008);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_87 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[6].V_x_vel.V_m_Y, 340282346638528897590636046441678635008);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_87;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_87.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[6].V_m_lat_pos_in_lane[0], 3.4028235e+38);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[6].V_m_lat_pos_in_lane[1], 3.4028235e+38);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[6].V_m_lat_pos_in_lane[2], 3.4028235e+38);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[6].V_m_lat_pos_in_lane[3], 3.4028235e+38);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[6].V_m_lat_pos_in_lane[4], 3.4028235e+38);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_88 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[6].V_m_lat_pos_in_lane[0], 3.4028235e+38);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[6].V_m_lat_pos_in_lane[1], 3.4028235e+38);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[6].V_m_lat_pos_in_lane[2], 3.4028235e+38);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[6].V_m_lat_pos_in_lane[3], 3.4028235e+38);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[6].V_m_lat_pos_in_lane[4], 3.4028235e+38);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_88;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_88.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[6].V_m_lat_vel_in_lane, 340282346638528897590636046441678635008);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_89 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[6].V_m_lat_vel_in_lane, 340282346638528897590636046441678635008);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_89;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_89.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[6].V_m_width, 340282346638528897590636046441678635008);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_90 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[6].V_m_width, 340282346638528897590636046441678635008);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_90;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_90.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[6].V_x_ID, 4294967295);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_91 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[6].V_x_ID, 4294967295);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_91;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_91.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[6].V_x_type, 4294967295);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_92 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[6].V_x_type, 4294967295);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_92;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_92.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[6].V_x_lane, 255);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_93 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[6].V_x_lane, 255);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_93;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_93.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[6].V_x_is_valid, 255);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_94 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[6].V_x_is_valid, 255);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_94;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_94.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[6].V_x_is_usable, 255);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_95 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[6].V_x_is_usable, 255);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_95;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_95.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[6].V_x_border, 4294967295);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_96 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[6].V_x_border, 4294967295);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_96;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_96.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[6].V_x_lost, 255);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_97 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[6].V_x_lost, 255);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_97;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_97.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[7].V_x_pos.V_m_X, 340282346638528897590636046441678635008);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_98 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[7].V_x_pos.V_m_X, 340282346638528897590636046441678635008);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_98;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_98.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[7].V_x_pos.V_m_Y, 340282346638528897590636046441678635008);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_99 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[7].V_x_pos.V_m_Y, 340282346638528897590636046441678635008);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_99;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_99.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[7].V_x_vel.V_m_X, 340282346638528897590636046441678635008);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_100 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[7].V_x_vel.V_m_X, 340282346638528897590636046441678635008);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_100;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_100.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[7].V_x_vel.V_m_Y, 340282346638528897590636046441678635008);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_101 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[7].V_x_vel.V_m_Y, 340282346638528897590636046441678635008);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_101;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_101.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[7].V_m_lat_pos_in_lane[0], 3.4028235e+38);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[7].V_m_lat_pos_in_lane[1], 3.4028235e+38);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[7].V_m_lat_pos_in_lane[2], 3.4028235e+38);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[7].V_m_lat_pos_in_lane[3], 3.4028235e+38);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[7].V_m_lat_pos_in_lane[4], 3.4028235e+38);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_102 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[7].V_m_lat_pos_in_lane[0], 3.4028235e+38);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[7].V_m_lat_pos_in_lane[1], 3.4028235e+38);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[7].V_m_lat_pos_in_lane[2], 3.4028235e+38);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[7].V_m_lat_pos_in_lane[3], 3.4028235e+38);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[7].V_m_lat_pos_in_lane[4], 3.4028235e+38);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_102;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_102.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[7].V_m_lat_vel_in_lane, 340282346638528897590636046441678635008);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_103 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[7].V_m_lat_vel_in_lane, 340282346638528897590636046441678635008);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_103;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_103.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[7].V_m_width, 340282346638528897590636046441678635008);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_104 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[7].V_m_width, 340282346638528897590636046441678635008);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_104;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_104.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[7].V_x_ID, 4294967295);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_105 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[7].V_x_ID, 4294967295);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_105;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_105.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[7].V_x_type, 4294967295);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_106 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[7].V_x_type, 4294967295);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_106;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_106.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[7].V_x_lane, 255);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_107 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[7].V_x_lane, 255);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_107;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_107.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[7].V_x_is_valid, 255);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_108 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[7].V_x_is_valid, 255);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_108;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_108.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[7].V_x_is_usable, 255);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_109 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[7].V_x_is_usable, 255);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_109;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_109.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[7].V_x_border, 4294967295);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_110 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[7].V_x_border, 4294967295);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_110;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_110.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[7].V_x_lost, 255);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_111 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[7].V_x_lost, 255);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_111;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_111.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[8].V_x_pos.V_m_X, 340282346638528897590636046441678635008);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_112 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[8].V_x_pos.V_m_X, 340282346638528897590636046441678635008);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_112;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_112.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[8].V_x_pos.V_m_Y, 340282346638528897590636046441678635008);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_113 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[8].V_x_pos.V_m_Y, 340282346638528897590636046441678635008);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_113;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_113.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[8].V_x_vel.V_m_X, 340282346638528897590636046441678635008);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_114 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[8].V_x_vel.V_m_X, 340282346638528897590636046441678635008);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_114;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_114.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[8].V_x_vel.V_m_Y, 340282346638528897590636046441678635008);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_115 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[8].V_x_vel.V_m_Y, 340282346638528897590636046441678635008);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_115;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_115.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[8].V_m_lat_pos_in_lane[0], 3.4028235e+38);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[8].V_m_lat_pos_in_lane[1], 3.4028235e+38);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[8].V_m_lat_pos_in_lane[2], 3.4028235e+38);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[8].V_m_lat_pos_in_lane[3], 3.4028235e+38);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[8].V_m_lat_pos_in_lane[4], 3.4028235e+38);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_116 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[8].V_m_lat_pos_in_lane[0], 3.4028235e+38);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[8].V_m_lat_pos_in_lane[1], 3.4028235e+38);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[8].V_m_lat_pos_in_lane[2], 3.4028235e+38);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[8].V_m_lat_pos_in_lane[3], 3.4028235e+38);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[8].V_m_lat_pos_in_lane[4], 3.4028235e+38);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_116;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_116.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[8].V_m_lat_vel_in_lane, 340282346638528897590636046441678635008);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_117 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[8].V_m_lat_vel_in_lane, 340282346638528897590636046441678635008);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_117;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_117.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[8].V_m_width, 340282346638528897590636046441678635008);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_118 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[8].V_m_width, 340282346638528897590636046441678635008);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_118;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_118.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[8].V_x_ID, 4294967295);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_119 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[8].V_x_ID, 4294967295);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_119;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_119.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[8].V_x_type, 4294967295);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_120 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[8].V_x_type, 4294967295);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_120;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_120.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[8].V_x_lane, 255);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_121 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[8].V_x_lane, 255);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_121;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_121.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[8].V_x_is_valid, 255);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_122 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[8].V_x_is_valid, 255);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_122;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_122.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[8].V_x_is_usable, 255);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_123 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[8].V_x_is_usable, 255);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_123;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_123.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[8].V_x_border, 4294967295);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_124 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[8].V_x_border, 4294967295);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_124;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_124.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[8].V_x_lost, 255);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_125 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[8].V_x_lost, 255);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_125;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_125.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[9].V_x_pos.V_m_X, 340282346638528897590636046441678635008);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_126 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[9].V_x_pos.V_m_X, 340282346638528897590636046441678635008);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_126;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_126.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[9].V_x_pos.V_m_Y, 340282346638528897590636046441678635008);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_127 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[9].V_x_pos.V_m_Y, 340282346638528897590636046441678635008);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_127;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_127.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[9].V_x_vel.V_m_X, 340282346638528897590636046441678635008);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_128 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[9].V_x_vel.V_m_X, 340282346638528897590636046441678635008);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_128;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_128.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[9].V_x_vel.V_m_Y, 340282346638528897590636046441678635008);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_129 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[9].V_x_vel.V_m_Y, 340282346638528897590636046441678635008);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_129;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_129.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[9].V_m_lat_pos_in_lane[0], 3.4028235e+38);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[9].V_m_lat_pos_in_lane[1], 3.4028235e+38);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[9].V_m_lat_pos_in_lane[2], 3.4028235e+38);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[9].V_m_lat_pos_in_lane[3], 3.4028235e+38);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[9].V_m_lat_pos_in_lane[4], 3.4028235e+38);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_130 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[9].V_m_lat_pos_in_lane[0], 3.4028235e+38);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[9].V_m_lat_pos_in_lane[1], 3.4028235e+38);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[9].V_m_lat_pos_in_lane[2], 3.4028235e+38);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[9].V_m_lat_pos_in_lane[3], 3.4028235e+38);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[9].V_m_lat_pos_in_lane[4], 3.4028235e+38);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_130;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_130.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[9].V_m_lat_vel_in_lane, 340282346638528897590636046441678635008);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_131 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[9].V_m_lat_vel_in_lane, 340282346638528897590636046441678635008);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_131;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_131.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[9].V_m_width, 340282346638528897590636046441678635008);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_132 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[9].V_m_width, 340282346638528897590636046441678635008);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_132;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_132.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[9].V_x_ID, 4294967295);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_133 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[9].V_x_ID, 4294967295);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_133;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_133.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[9].V_x_type, 4294967295);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_134 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[9].V_x_type, 4294967295);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_134;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_134.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[9].V_x_lane, 255);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_135 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[9].V_x_lane, 255);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_135;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_135.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[9].V_x_is_valid, 255);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_136 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[9].V_x_is_valid, 255);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_136;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_136.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[9].V_x_is_usable, 255);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_137 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[9].V_x_is_usable, 255);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_137;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_137.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[9].V_x_border, 4294967295);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_138 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[9].V_x_border, 4294967295);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_138;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_138.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[9].V_x_lost, 255);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_139 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[9].V_x_lost, 255);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_139;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_139.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[10].V_x_pos.V_m_X, 340282346638528897590636046441678635008);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_140 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[10].V_x_pos.V_m_X, 340282346638528897590636046441678635008);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_140;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_140.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[10].V_x_pos.V_m_Y, 340282346638528897590636046441678635008);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_141 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[10].V_x_pos.V_m_Y, 340282346638528897590636046441678635008);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_141;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_141.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[10].V_x_vel.V_m_X, 340282346638528897590636046441678635008);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_142 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[10].V_x_vel.V_m_X, 340282346638528897590636046441678635008);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_142;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_142.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[10].V_x_vel.V_m_Y, 340282346638528897590636046441678635008);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_143 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[10].V_x_vel.V_m_Y, 340282346638528897590636046441678635008);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_143;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_143.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[10].V_m_lat_pos_in_lane[0], 3.4028235e+38);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[10].V_m_lat_pos_in_lane[1], 3.4028235e+38);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[10].V_m_lat_pos_in_lane[2], 3.4028235e+38);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[10].V_m_lat_pos_in_lane[3], 3.4028235e+38);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[10].V_m_lat_pos_in_lane[4], 3.4028235e+38);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_144 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[10].V_m_lat_pos_in_lane[0], 3.4028235e+38);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[10].V_m_lat_pos_in_lane[1], 3.4028235e+38);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[10].V_m_lat_pos_in_lane[2], 3.4028235e+38);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[10].V_m_lat_pos_in_lane[3], 3.4028235e+38);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[10].V_m_lat_pos_in_lane[4], 3.4028235e+38);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_144;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_144.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[10].V_m_lat_vel_in_lane, 340282346638528897590636046441678635008);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_145 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[10].V_m_lat_vel_in_lane, 340282346638528897590636046441678635008);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_145;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_145.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[10].V_m_width, 340282346638528897590636046441678635008);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_146 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[10].V_m_width, 340282346638528897590636046441678635008);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_146;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_146.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[10].V_x_ID, 4294967295);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_147 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[10].V_x_ID, 4294967295);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_147;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_147.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[10].V_x_type, 4294967295);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_148 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[10].V_x_type, 4294967295);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_148;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_148.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[10].V_x_lane, 255);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_149 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[10].V_x_lane, 255);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_149;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_149.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[10].V_x_is_valid, 255);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_150 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[10].V_x_is_valid, 255);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_150;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_150.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[10].V_x_is_usable, 255);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_151 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[10].V_x_is_usable, 255);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_151;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_151.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[10].V_x_border, 4294967295);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_152 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[10].V_x_border, 4294967295);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_152;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_152.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[10].V_x_lost, 255);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_153 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[10].V_x_lost, 255);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_153;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_153.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[11].V_x_pos.V_m_X, 340282346638528897590636046441678635008);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_154 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[11].V_x_pos.V_m_X, 340282346638528897590636046441678635008);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_154;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_154.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[11].V_x_pos.V_m_Y, 340282346638528897590636046441678635008);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_155 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[11].V_x_pos.V_m_Y, 340282346638528897590636046441678635008);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_155;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_155.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[11].V_x_vel.V_m_X, 340282346638528897590636046441678635008);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_156 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[11].V_x_vel.V_m_X, 340282346638528897590636046441678635008);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_156;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_156.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[11].V_x_vel.V_m_Y, 340282346638528897590636046441678635008);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_157 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[11].V_x_vel.V_m_Y, 340282346638528897590636046441678635008);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_157;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_157.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[11].V_m_lat_pos_in_lane[0], 3.4028235e+38);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[11].V_m_lat_pos_in_lane[1], 3.4028235e+38);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[11].V_m_lat_pos_in_lane[2], 3.4028235e+38);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[11].V_m_lat_pos_in_lane[3], 3.4028235e+38);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[11].V_m_lat_pos_in_lane[4], 3.4028235e+38);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_158 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[11].V_m_lat_pos_in_lane[0], 3.4028235e+38);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[11].V_m_lat_pos_in_lane[1], 3.4028235e+38);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[11].V_m_lat_pos_in_lane[2], 3.4028235e+38);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[11].V_m_lat_pos_in_lane[3], 3.4028235e+38);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[11].V_m_lat_pos_in_lane[4], 3.4028235e+38);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_158;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_158.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[11].V_m_lat_vel_in_lane, 340282346638528897590636046441678635008);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_159 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[11].V_m_lat_vel_in_lane, 340282346638528897590636046441678635008);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_159;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_159.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[11].V_m_width, 340282346638528897590636046441678635008);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_160 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[11].V_m_width, 340282346638528897590636046441678635008);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_160;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_160.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[11].V_x_ID, 4294967295);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_161 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[11].V_x_ID, 4294967295);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_161;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_161.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[11].V_x_type, 4294967295);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_162 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[11].V_x_type, 4294967295);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_162;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_162.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[11].V_x_lane, 255);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_163 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[11].V_x_lane, 255);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_163;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_163.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[11].V_x_is_valid, 255);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_164 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[11].V_x_is_valid, 255);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_164;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_164.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[11].V_x_is_usable, 255);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_165 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[11].V_x_is_usable, 255);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_165;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_165.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[11].V_x_border, 4294967295);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_166 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[11].V_x_border, 4294967295);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_166;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_166.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[11].V_x_lost, 255);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_167 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[11].V_x_lost, 255);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_167;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_167.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[12].V_x_pos.V_m_X, 340282346638528897590636046441678635008);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_168 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[12].V_x_pos.V_m_X, 340282346638528897590636046441678635008);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_168;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_168.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[12].V_x_pos.V_m_Y, 340282346638528897590636046441678635008);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_169 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[12].V_x_pos.V_m_Y, 340282346638528897590636046441678635008);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_169;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_169.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[12].V_x_vel.V_m_X, 340282346638528897590636046441678635008);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_170 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[12].V_x_vel.V_m_X, 340282346638528897590636046441678635008);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_170;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_170.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[12].V_x_vel.V_m_Y, 340282346638528897590636046441678635008);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_171 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[12].V_x_vel.V_m_Y, 340282346638528897590636046441678635008);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_171;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_171.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[12].V_m_lat_pos_in_lane[0], 3.4028235e+38);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[12].V_m_lat_pos_in_lane[1], 3.4028235e+38);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[12].V_m_lat_pos_in_lane[2], 3.4028235e+38);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[12].V_m_lat_pos_in_lane[3], 3.4028235e+38);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[12].V_m_lat_pos_in_lane[4], 3.4028235e+38);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_172 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[12].V_m_lat_pos_in_lane[0], 3.4028235e+38);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[12].V_m_lat_pos_in_lane[1], 3.4028235e+38);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[12].V_m_lat_pos_in_lane[2], 3.4028235e+38);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[12].V_m_lat_pos_in_lane[3], 3.4028235e+38);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[12].V_m_lat_pos_in_lane[4], 3.4028235e+38);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_172;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_172.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[12].V_m_lat_vel_in_lane, 340282346638528897590636046441678635008);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_173 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[12].V_m_lat_vel_in_lane, 340282346638528897590636046441678635008);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_173;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_173.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[12].V_m_width, 340282346638528897590636046441678635008);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_174 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[12].V_m_width, 340282346638528897590636046441678635008);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_174;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_174.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[12].V_x_ID, 4294967295);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_175 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[12].V_x_ID, 4294967295);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_175;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_175.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[12].V_x_type, 4294967295);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_176 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[12].V_x_type, 4294967295);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_176;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_176.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[12].V_x_lane, 255);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_177 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[12].V_x_lane, 255);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_177;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_177.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[12].V_x_is_valid, 255);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_178 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[12].V_x_is_valid, 255);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_178;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_178.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[12].V_x_is_usable, 255);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_179 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[12].V_x_is_usable, 255);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_179;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_179.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[12].V_x_border, 4294967295);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_180 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[12].V_x_border, 4294967295);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_180;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_180.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[12].V_x_lost, 255);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_181 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[12].V_x_lost, 255);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_181;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_181.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[13].V_x_pos.V_m_X, 340282346638528897590636046441678635008);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_182 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[13].V_x_pos.V_m_X, 340282346638528897590636046441678635008);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_182;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_182.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[13].V_x_pos.V_m_Y, 340282346638528897590636046441678635008);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_183 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[13].V_x_pos.V_m_Y, 340282346638528897590636046441678635008);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_183;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_183.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[13].V_x_vel.V_m_X, 340282346638528897590636046441678635008);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_184 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[13].V_x_vel.V_m_X, 340282346638528897590636046441678635008);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_184;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_184.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[13].V_x_vel.V_m_Y, 340282346638528897590636046441678635008);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_185 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[13].V_x_vel.V_m_Y, 340282346638528897590636046441678635008);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_185;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_185.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[13].V_m_lat_pos_in_lane[0], 3.4028235e+38);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[13].V_m_lat_pos_in_lane[1], 3.4028235e+38);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[13].V_m_lat_pos_in_lane[2], 3.4028235e+38);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[13].V_m_lat_pos_in_lane[3], 3.4028235e+38);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[13].V_m_lat_pos_in_lane[4], 3.4028235e+38);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_186 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[13].V_m_lat_pos_in_lane[0], 3.4028235e+38);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[13].V_m_lat_pos_in_lane[1], 3.4028235e+38);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[13].V_m_lat_pos_in_lane[2], 3.4028235e+38);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[13].V_m_lat_pos_in_lane[3], 3.4028235e+38);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[13].V_m_lat_pos_in_lane[4], 3.4028235e+38);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_186;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_186.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[13].V_m_lat_vel_in_lane, 340282346638528897590636046441678635008);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_187 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[13].V_m_lat_vel_in_lane, 340282346638528897590636046441678635008);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_187;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_187.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[13].V_m_width, 340282346638528897590636046441678635008);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_188 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[13].V_m_width, 340282346638528897590636046441678635008);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_188;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_188.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[13].V_x_ID, 4294967295);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_189 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[13].V_x_ID, 4294967295);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_189;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_189.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[13].V_x_type, 4294967295);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_190 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[13].V_x_type, 4294967295);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_190;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_190.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[13].V_x_lane, 255);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_191 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[13].V_x_lane, 255);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_191;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_191.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[13].V_x_is_valid, 255);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_192 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[13].V_x_is_valid, 255);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_192;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_192.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[13].V_x_is_usable, 255);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_193 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[13].V_x_is_usable, 255);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_193;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_193.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[13].V_x_border, 4294967295);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_194 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[13].V_x_border, 4294967295);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_194;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_194.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[13].V_x_lost, 255);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_195 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[13].V_x_lost, 255);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_195;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_195.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[14].V_x_pos.V_m_X, 340282346638528897590636046441678635008);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_196 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[14].V_x_pos.V_m_X, 340282346638528897590636046441678635008);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_196;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_196.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[14].V_x_pos.V_m_Y, 340282346638528897590636046441678635008);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_197 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[14].V_x_pos.V_m_Y, 340282346638528897590636046441678635008);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_197;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_197.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[14].V_x_vel.V_m_X, 340282346638528897590636046441678635008);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_198 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[14].V_x_vel.V_m_X, 340282346638528897590636046441678635008);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_198;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_198.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[14].V_x_vel.V_m_Y, 340282346638528897590636046441678635008);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_199 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[14].V_x_vel.V_m_Y, 340282346638528897590636046441678635008);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_199;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_199.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[14].V_m_lat_pos_in_lane[0], 3.4028235e+38);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[14].V_m_lat_pos_in_lane[1], 3.4028235e+38);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[14].V_m_lat_pos_in_lane[2], 3.4028235e+38);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[14].V_m_lat_pos_in_lane[3], 3.4028235e+38);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[14].V_m_lat_pos_in_lane[4], 3.4028235e+38);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_200 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[14].V_m_lat_pos_in_lane[0], 3.4028235e+38);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[14].V_m_lat_pos_in_lane[1], 3.4028235e+38);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[14].V_m_lat_pos_in_lane[2], 3.4028235e+38);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[14].V_m_lat_pos_in_lane[3], 3.4028235e+38);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[14].V_m_lat_pos_in_lane[4], 3.4028235e+38);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_200;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_200.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[14].V_m_lat_vel_in_lane, 340282346638528897590636046441678635008);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_201 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[14].V_m_lat_vel_in_lane, 340282346638528897590636046441678635008);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_201;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_201.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[14].V_m_width, 340282346638528897590636046441678635008);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_202 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[14].V_m_width, 340282346638528897590636046441678635008);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_202;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_202.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[14].V_x_ID, 4294967295);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_203 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[14].V_x_ID, 4294967295);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_203;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_203.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[14].V_x_type, 4294967295);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_204 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[14].V_x_type, 4294967295);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_204;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_204.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[14].V_x_lane, 255);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_205 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[14].V_x_lane, 255);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_205;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_205.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[14].V_x_is_valid, 255);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_206 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[14].V_x_is_valid, 255);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_206;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_206.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[14].V_x_is_usable, 255);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_207 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[14].V_x_is_usable, 255);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_207;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_207.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[14].V_x_border, 4294967295);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_208 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[14].V_x_border, 4294967295);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_208;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_208.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[14].V_x_lost, 255);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_209 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[14].V_x_lost, 255);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_209;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_209.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[15].V_x_pos.V_m_X, 340282346638528897590636046441678635008);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_210 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[15].V_x_pos.V_m_X, 340282346638528897590636046441678635008);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_210;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_210.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[15].V_x_pos.V_m_Y, 340282346638528897590636046441678635008);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_211 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[15].V_x_pos.V_m_Y, 340282346638528897590636046441678635008);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_211;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_211.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[15].V_x_vel.V_m_X, 340282346638528897590636046441678635008);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_212 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[15].V_x_vel.V_m_X, 340282346638528897590636046441678635008);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_212;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_212.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[15].V_x_vel.V_m_Y, 340282346638528897590636046441678635008);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_213 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[15].V_x_vel.V_m_Y, 340282346638528897590636046441678635008);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_213;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_213.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[15].V_m_lat_pos_in_lane[0], 3.4028235e+38);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[15].V_m_lat_pos_in_lane[1], 3.4028235e+38);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[15].V_m_lat_pos_in_lane[2], 3.4028235e+38);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[15].V_m_lat_pos_in_lane[3], 3.4028235e+38);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[15].V_m_lat_pos_in_lane[4], 3.4028235e+38);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_214 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[15].V_m_lat_pos_in_lane[0], 3.4028235e+38);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[15].V_m_lat_pos_in_lane[1], 3.4028235e+38);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[15].V_m_lat_pos_in_lane[2], 3.4028235e+38);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[15].V_m_lat_pos_in_lane[3], 3.4028235e+38);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[15].V_m_lat_pos_in_lane[4], 3.4028235e+38);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_214;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_214.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[15].V_m_lat_vel_in_lane, 340282346638528897590636046441678635008);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_215 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[15].V_m_lat_vel_in_lane, 340282346638528897590636046441678635008);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_215;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_215.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[15].V_m_width, 340282346638528897590636046441678635008);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_216 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[15].V_m_width, 340282346638528897590636046441678635008);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_216;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_216.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[15].V_x_ID, 4294967295);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_217 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[15].V_x_ID, 4294967295);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_217;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_217.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[15].V_x_type, 4294967295);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_218 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[15].V_x_type, 4294967295);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_218;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_218.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[15].V_x_lane, 255);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_219 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[15].V_x_lane, 255);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_219;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_219.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[15].V_x_is_valid, 255);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_220 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[15].V_x_is_valid, 255);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_220;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_220.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[15].V_x_is_usable, 255);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_221 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[15].V_x_is_usable, 255);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_221;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_221.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[15].V_x_border, 4294967295);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_222 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[15].V_x_border, 4294967295);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_222;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_222.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[15].V_x_lost, 255);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_223 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[15].V_x_lost, 255);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_223;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_223.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[16].V_x_pos.V_m_X, 340282346638528897590636046441678635008);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_224 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[16].V_x_pos.V_m_X, 340282346638528897590636046441678635008);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_224;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_224.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[16].V_x_pos.V_m_Y, 340282346638528897590636046441678635008);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_225 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[16].V_x_pos.V_m_Y, 340282346638528897590636046441678635008);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_225;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_225.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[16].V_x_vel.V_m_X, 340282346638528897590636046441678635008);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_226 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[16].V_x_vel.V_m_X, 340282346638528897590636046441678635008);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_226;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_226.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[16].V_x_vel.V_m_Y, 340282346638528897590636046441678635008);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_227 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[16].V_x_vel.V_m_Y, 340282346638528897590636046441678635008);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_227;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_227.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[16].V_m_lat_pos_in_lane[0], 3.4028235e+38);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[16].V_m_lat_pos_in_lane[1], 3.4028235e+38);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[16].V_m_lat_pos_in_lane[2], 3.4028235e+38);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[16].V_m_lat_pos_in_lane[3], 3.4028235e+38);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[16].V_m_lat_pos_in_lane[4], 3.4028235e+38);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_228 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[16].V_m_lat_pos_in_lane[0], 3.4028235e+38);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[16].V_m_lat_pos_in_lane[1], 3.4028235e+38);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[16].V_m_lat_pos_in_lane[2], 3.4028235e+38);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[16].V_m_lat_pos_in_lane[3], 3.4028235e+38);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[16].V_m_lat_pos_in_lane[4], 3.4028235e+38);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_228;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_228.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[16].V_m_lat_vel_in_lane, 340282346638528897590636046441678635008);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_229 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[16].V_m_lat_vel_in_lane, 340282346638528897590636046441678635008);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_229;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_229.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[16].V_m_width, 340282346638528897590636046441678635008);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_230 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[16].V_m_width, 340282346638528897590636046441678635008);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_230;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_230.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[16].V_x_ID, 4294967295);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_231 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[16].V_x_ID, 4294967295);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_231;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_231.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[16].V_x_type, 4294967295);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_232 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[16].V_x_type, 4294967295);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_232;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_232.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[16].V_x_lane, 255);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_233 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[16].V_x_lane, 255);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_233;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_233.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[16].V_x_is_valid, 255);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_234 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[16].V_x_is_valid, 255);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_234;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_234.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[16].V_x_is_usable, 255);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_235 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[16].V_x_is_usable, 255);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_235;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_235.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[16].V_x_border, 4294967295);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_236 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[16].V_x_border, 4294967295);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_236;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_236.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[16].V_x_lost, 255);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_237 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[16].V_x_lost, 255);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_237;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_237.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[17].V_x_pos.V_m_X, 340282346638528897590636046441678635008);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_238 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[17].V_x_pos.V_m_X, 340282346638528897590636046441678635008);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_238;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_238.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[17].V_x_pos.V_m_Y, 340282346638528897590636046441678635008);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_239 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[17].V_x_pos.V_m_Y, 340282346638528897590636046441678635008);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_239;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_239.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[17].V_x_vel.V_m_X, 340282346638528897590636046441678635008);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_240 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[17].V_x_vel.V_m_X, 340282346638528897590636046441678635008);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_240;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_240.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[17].V_x_vel.V_m_Y, 340282346638528897590636046441678635008);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_241 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[17].V_x_vel.V_m_Y, 340282346638528897590636046441678635008);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_241;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_241.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[17].V_m_lat_pos_in_lane[0], 3.4028235e+38);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[17].V_m_lat_pos_in_lane[1], 3.4028235e+38);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[17].V_m_lat_pos_in_lane[2], 3.4028235e+38);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[17].V_m_lat_pos_in_lane[3], 3.4028235e+38);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[17].V_m_lat_pos_in_lane[4], 3.4028235e+38);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_242 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[17].V_m_lat_pos_in_lane[0], 3.4028235e+38);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[17].V_m_lat_pos_in_lane[1], 3.4028235e+38);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[17].V_m_lat_pos_in_lane[2], 3.4028235e+38);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[17].V_m_lat_pos_in_lane[3], 3.4028235e+38);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[17].V_m_lat_pos_in_lane[4], 3.4028235e+38);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_242;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_242.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[17].V_m_lat_vel_in_lane, 340282346638528897590636046441678635008);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_243 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[17].V_m_lat_vel_in_lane, 340282346638528897590636046441678635008);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_243;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_243.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[17].V_m_width, 340282346638528897590636046441678635008);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_244 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[17].V_m_width, 340282346638528897590636046441678635008);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_244;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_244.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[17].V_x_ID, 4294967295);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_245 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[17].V_x_ID, 4294967295);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_245;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_245.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[17].V_x_type, 4294967295);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_246 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[17].V_x_type, 4294967295);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_246;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_246.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[17].V_x_lane, 255);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_247 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[17].V_x_lane, 255);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_247;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_247.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[17].V_x_is_valid, 255);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_248 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[17].V_x_is_valid, 255);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_248;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_248.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[17].V_x_is_usable, 255);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_249 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[17].V_x_is_usable, 255);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_249;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_249.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[17].V_x_border, 4294967295);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_250 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[17].V_x_border, 4294967295);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_250;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_250.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[17].V_x_lost, 255);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_251 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[17].V_x_lost, 255);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_251;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_251.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[18].V_x_pos.V_m_X, 340282346638528897590636046441678635008);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_252 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[18].V_x_pos.V_m_X, 340282346638528897590636046441678635008);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_252;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_252.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[18].V_x_pos.V_m_Y, 340282346638528897590636046441678635008);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_253 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[18].V_x_pos.V_m_Y, 340282346638528897590636046441678635008);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_253;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_253.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[18].V_x_vel.V_m_X, 340282346638528897590636046441678635008);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_254 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[18].V_x_vel.V_m_X, 340282346638528897590636046441678635008);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_254;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_254.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[18].V_x_vel.V_m_Y, 340282346638528897590636046441678635008);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_255 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[18].V_x_vel.V_m_Y, 340282346638528897590636046441678635008);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_255;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_255.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[18].V_m_lat_pos_in_lane[0], 3.4028235e+38);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[18].V_m_lat_pos_in_lane[1], 3.4028235e+38);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[18].V_m_lat_pos_in_lane[2], 3.4028235e+38);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[18].V_m_lat_pos_in_lane[3], 3.4028235e+38);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[18].V_m_lat_pos_in_lane[4], 3.4028235e+38);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_256 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[18].V_m_lat_pos_in_lane[0], 3.4028235e+38);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[18].V_m_lat_pos_in_lane[1], 3.4028235e+38);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[18].V_m_lat_pos_in_lane[2], 3.4028235e+38);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[18].V_m_lat_pos_in_lane[3], 3.4028235e+38);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[18].V_m_lat_pos_in_lane[4], 3.4028235e+38);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_256;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_256.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[18].V_m_lat_vel_in_lane, 340282346638528897590636046441678635008);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_257 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[18].V_m_lat_vel_in_lane, 340282346638528897590636046441678635008);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_257;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_257.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[18].V_m_width, 340282346638528897590636046441678635008);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_258 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[18].V_m_width, 340282346638528897590636046441678635008);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_258;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_258.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[18].V_x_ID, 4294967295);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_259 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[18].V_x_ID, 4294967295);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_259;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_259.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[18].V_x_type, 4294967295);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_260 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[18].V_x_type, 4294967295);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_260;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_260.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[18].V_x_lane, 255);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_261 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[18].V_x_lane, 255);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_261;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_261.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[18].V_x_is_valid, 255);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_262 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[18].V_x_is_valid, 255);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_262;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_262.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[18].V_x_is_usable, 255);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_263 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[18].V_x_is_usable, 255);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_263;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_263.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[18].V_x_border, 4294967295);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_264 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[18].V_x_border, 4294967295);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_264;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_264.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[18].V_x_lost, 255);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_265 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[18].V_x_lost, 255);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_265;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_265.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[19].V_x_pos.V_m_X, 340282346638528897590636046441678635008);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_266 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[19].V_x_pos.V_m_X, 340282346638528897590636046441678635008);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_266;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_266.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[19].V_x_pos.V_m_Y, 340282346638528897590636046441678635008);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_267 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[19].V_x_pos.V_m_Y, 340282346638528897590636046441678635008);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_267;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_267.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[19].V_x_vel.V_m_X, 340282346638528897590636046441678635008);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_268 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[19].V_x_vel.V_m_X, 340282346638528897590636046441678635008);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_268;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_268.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[19].V_x_vel.V_m_Y, 340282346638528897590636046441678635008);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_269 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[19].V_x_vel.V_m_Y, 340282346638528897590636046441678635008);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_269;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_269.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[19].V_m_lat_pos_in_lane[0], 3.4028235e+38);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[19].V_m_lat_pos_in_lane[1], 3.4028235e+38);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[19].V_m_lat_pos_in_lane[2], 3.4028235e+38);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[19].V_m_lat_pos_in_lane[3], 3.4028235e+38);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[19].V_m_lat_pos_in_lane[4], 3.4028235e+38);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_270 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[19].V_m_lat_pos_in_lane[0], 3.4028235e+38);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[19].V_m_lat_pos_in_lane[1], 3.4028235e+38);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[19].V_m_lat_pos_in_lane[2], 3.4028235e+38);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[19].V_m_lat_pos_in_lane[3], 3.4028235e+38);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[19].V_m_lat_pos_in_lane[4], 3.4028235e+38);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_270;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_270.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[19].V_m_lat_vel_in_lane, 340282346638528897590636046441678635008);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_271 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[19].V_m_lat_vel_in_lane, 340282346638528897590636046441678635008);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_271;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_271.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[19].V_m_width, 340282346638528897590636046441678635008);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_272 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[19].V_m_width, 340282346638528897590636046441678635008);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_272;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_272.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[19].V_x_ID, 4294967295);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_273 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[19].V_x_ID, 4294967295);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_273;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_273.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[19].V_x_type, 4294967295);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_274 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[19].V_x_type, 4294967295);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_274;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_274.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[19].V_x_lane, 255);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_275 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[19].V_x_lane, 255);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_275;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_275.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[19].V_x_is_valid, 255);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_276 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[19].V_x_is_valid, 255);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_276;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_276.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[19].V_x_is_usable, 255);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_277 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[19].V_x_is_usable, 255);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_277;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_277.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[19].V_x_border, 4294967295);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_278 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[19].V_x_border, 4294967295);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_278;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_278.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[19].V_x_lost, 255);
    struct _func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_279 {
        static void verify(void) {
#include "Rte_Wrapper_RCarHMIManagement.h"
            V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
            Rte_Read_V_x_clustered_side_radar_obj_t_V_x_clustered_side_radar_obj_t(&tmp_clustered_side_radar_obj_t);
            EXPECT_EQ(tmp_clustered_side_radar_obj_t.V_x_clustered_side_radar_obj[19].V_x_lost, 255);
        }
    } func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_279;
    func_V_x_clustered_side_radar_obj_t_RCarHMIManagement_279.verify();

    /* V_x_sorted_side_radar_obj_t */
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[0].V_x_pos.V_m_X, 340282346638528897590636046441678635008);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_0 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[0].V_x_pos.V_m_X, 340282346638528897590636046441678635008);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_0;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_0.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[0].V_x_pos.V_m_Y, 340282346638528897590636046441678635008);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_1 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[0].V_x_pos.V_m_Y, 340282346638528897590636046441678635008);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_1;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_1.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[0].V_x_vel.V_m_X, 340282346638528897590636046441678635008);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_2 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[0].V_x_vel.V_m_X, 340282346638528897590636046441678635008);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_2;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_2.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[0].V_x_vel.V_m_Y, 340282346638528897590636046441678635008);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_3 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[0].V_x_vel.V_m_Y, 340282346638528897590636046441678635008);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_3;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_3.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[0].V_m_lat_pos_in_lane[0], 3.4028235e+38);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[0].V_m_lat_pos_in_lane[1], 3.4028235e+38);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[0].V_m_lat_pos_in_lane[2], 3.4028235e+38);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[0].V_m_lat_pos_in_lane[3], 3.4028235e+38);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[0].V_m_lat_pos_in_lane[4], 3.4028235e+38);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_4 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[0].V_m_lat_pos_in_lane[0], 3.4028235e+38);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[0].V_m_lat_pos_in_lane[1], 3.4028235e+38);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[0].V_m_lat_pos_in_lane[2], 3.4028235e+38);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[0].V_m_lat_pos_in_lane[3], 3.4028235e+38);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[0].V_m_lat_pos_in_lane[4], 3.4028235e+38);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_4;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_4.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[0].V_m_lat_vel_in_lane, 340282346638528897590636046441678635008);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_5 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[0].V_m_lat_vel_in_lane, 340282346638528897590636046441678635008);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_5;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_5.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[0].V_m_width, 340282346638528897590636046441678635008);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_6 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[0].V_m_width, 340282346638528897590636046441678635008);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_6;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_6.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[0].V_x_ID, 4294967295);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_7 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[0].V_x_ID, 4294967295);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_7;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_7.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[0].V_x_type, 4294967295);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_8 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[0].V_x_type, 4294967295);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_8;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_8.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[0].V_x_lane, 255);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_9 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[0].V_x_lane, 255);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_9;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_9.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[0].V_x_is_valid, 255);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_10 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[0].V_x_is_valid, 255);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_10;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_10.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[0].V_x_is_usable, 255);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_11 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[0].V_x_is_usable, 255);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_11;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_11.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[0].V_x_border, 4294967295);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_12 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[0].V_x_border, 4294967295);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_12;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_12.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[0].V_x_lost, 255);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_13 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[0].V_x_lost, 255);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_13;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_13.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[1].V_x_pos.V_m_X, 340282346638528897590636046441678635008);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_14 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[1].V_x_pos.V_m_X, 340282346638528897590636046441678635008);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_14;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_14.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[1].V_x_pos.V_m_Y, 340282346638528897590636046441678635008);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_15 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[1].V_x_pos.V_m_Y, 340282346638528897590636046441678635008);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_15;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_15.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[1].V_x_vel.V_m_X, 340282346638528897590636046441678635008);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_16 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[1].V_x_vel.V_m_X, 340282346638528897590636046441678635008);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_16;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_16.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[1].V_x_vel.V_m_Y, 340282346638528897590636046441678635008);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_17 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[1].V_x_vel.V_m_Y, 340282346638528897590636046441678635008);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_17;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_17.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[1].V_m_lat_pos_in_lane[0], 3.4028235e+38);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[1].V_m_lat_pos_in_lane[1], 3.4028235e+38);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[1].V_m_lat_pos_in_lane[2], 3.4028235e+38);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[1].V_m_lat_pos_in_lane[3], 3.4028235e+38);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[1].V_m_lat_pos_in_lane[4], 3.4028235e+38);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_18 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[1].V_m_lat_pos_in_lane[0], 3.4028235e+38);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[1].V_m_lat_pos_in_lane[1], 3.4028235e+38);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[1].V_m_lat_pos_in_lane[2], 3.4028235e+38);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[1].V_m_lat_pos_in_lane[3], 3.4028235e+38);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[1].V_m_lat_pos_in_lane[4], 3.4028235e+38);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_18;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_18.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[1].V_m_lat_vel_in_lane, 340282346638528897590636046441678635008);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_19 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[1].V_m_lat_vel_in_lane, 340282346638528897590636046441678635008);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_19;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_19.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[1].V_m_width, 340282346638528897590636046441678635008);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_20 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[1].V_m_width, 340282346638528897590636046441678635008);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_20;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_20.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[1].V_x_ID, 4294967295);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_21 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[1].V_x_ID, 4294967295);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_21;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_21.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[1].V_x_type, 4294967295);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_22 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[1].V_x_type, 4294967295);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_22;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_22.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[1].V_x_lane, 255);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_23 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[1].V_x_lane, 255);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_23;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_23.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[1].V_x_is_valid, 255);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_24 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[1].V_x_is_valid, 255);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_24;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_24.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[1].V_x_is_usable, 255);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_25 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[1].V_x_is_usable, 255);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_25;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_25.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[1].V_x_border, 4294967295);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_26 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[1].V_x_border, 4294967295);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_26;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_26.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[1].V_x_lost, 255);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_27 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[1].V_x_lost, 255);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_27;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_27.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[2].V_x_pos.V_m_X, 340282346638528897590636046441678635008);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_28 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[2].V_x_pos.V_m_X, 340282346638528897590636046441678635008);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_28;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_28.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[2].V_x_pos.V_m_Y, 340282346638528897590636046441678635008);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_29 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[2].V_x_pos.V_m_Y, 340282346638528897590636046441678635008);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_29;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_29.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[2].V_x_vel.V_m_X, 340282346638528897590636046441678635008);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_30 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[2].V_x_vel.V_m_X, 340282346638528897590636046441678635008);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_30;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_30.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[2].V_x_vel.V_m_Y, 340282346638528897590636046441678635008);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_31 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[2].V_x_vel.V_m_Y, 340282346638528897590636046441678635008);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_31;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_31.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[2].V_m_lat_pos_in_lane[0], 3.4028235e+38);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[2].V_m_lat_pos_in_lane[1], 3.4028235e+38);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[2].V_m_lat_pos_in_lane[2], 3.4028235e+38);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[2].V_m_lat_pos_in_lane[3], 3.4028235e+38);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[2].V_m_lat_pos_in_lane[4], 3.4028235e+38);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_32 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[2].V_m_lat_pos_in_lane[0], 3.4028235e+38);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[2].V_m_lat_pos_in_lane[1], 3.4028235e+38);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[2].V_m_lat_pos_in_lane[2], 3.4028235e+38);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[2].V_m_lat_pos_in_lane[3], 3.4028235e+38);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[2].V_m_lat_pos_in_lane[4], 3.4028235e+38);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_32;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_32.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[2].V_m_lat_vel_in_lane, 340282346638528897590636046441678635008);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_33 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[2].V_m_lat_vel_in_lane, 340282346638528897590636046441678635008);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_33;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_33.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[2].V_m_width, 340282346638528897590636046441678635008);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_34 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[2].V_m_width, 340282346638528897590636046441678635008);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_34;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_34.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[2].V_x_ID, 4294967295);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_35 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[2].V_x_ID, 4294967295);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_35;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_35.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[2].V_x_type, 4294967295);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_36 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[2].V_x_type, 4294967295);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_36;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_36.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[2].V_x_lane, 255);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_37 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[2].V_x_lane, 255);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_37;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_37.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[2].V_x_is_valid, 255);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_38 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[2].V_x_is_valid, 255);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_38;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_38.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[2].V_x_is_usable, 255);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_39 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[2].V_x_is_usable, 255);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_39;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_39.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[2].V_x_border, 4294967295);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_40 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[2].V_x_border, 4294967295);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_40;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_40.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[2].V_x_lost, 255);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_41 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[2].V_x_lost, 255);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_41;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_41.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[3].V_x_pos.V_m_X, 340282346638528897590636046441678635008);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_42 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[3].V_x_pos.V_m_X, 340282346638528897590636046441678635008);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_42;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_42.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[3].V_x_pos.V_m_Y, 340282346638528897590636046441678635008);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_43 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[3].V_x_pos.V_m_Y, 340282346638528897590636046441678635008);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_43;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_43.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[3].V_x_vel.V_m_X, 340282346638528897590636046441678635008);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_44 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[3].V_x_vel.V_m_X, 340282346638528897590636046441678635008);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_44;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_44.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[3].V_x_vel.V_m_Y, 340282346638528897590636046441678635008);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_45 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[3].V_x_vel.V_m_Y, 340282346638528897590636046441678635008);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_45;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_45.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[3].V_m_lat_pos_in_lane[0], 3.4028235e+38);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[3].V_m_lat_pos_in_lane[1], 3.4028235e+38);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[3].V_m_lat_pos_in_lane[2], 3.4028235e+38);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[3].V_m_lat_pos_in_lane[3], 3.4028235e+38);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[3].V_m_lat_pos_in_lane[4], 3.4028235e+38);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_46 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[3].V_m_lat_pos_in_lane[0], 3.4028235e+38);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[3].V_m_lat_pos_in_lane[1], 3.4028235e+38);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[3].V_m_lat_pos_in_lane[2], 3.4028235e+38);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[3].V_m_lat_pos_in_lane[3], 3.4028235e+38);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[3].V_m_lat_pos_in_lane[4], 3.4028235e+38);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_46;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_46.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[3].V_m_lat_vel_in_lane, 340282346638528897590636046441678635008);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_47 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[3].V_m_lat_vel_in_lane, 340282346638528897590636046441678635008);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_47;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_47.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[3].V_m_width, 340282346638528897590636046441678635008);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_48 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[3].V_m_width, 340282346638528897590636046441678635008);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_48;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_48.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[3].V_x_ID, 4294967295);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_49 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[3].V_x_ID, 4294967295);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_49;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_49.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[3].V_x_type, 4294967295);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_50 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[3].V_x_type, 4294967295);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_50;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_50.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[3].V_x_lane, 255);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_51 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[3].V_x_lane, 255);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_51;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_51.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[3].V_x_is_valid, 255);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_52 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[3].V_x_is_valid, 255);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_52;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_52.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[3].V_x_is_usable, 255);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_53 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[3].V_x_is_usable, 255);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_53;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_53.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[3].V_x_border, 4294967295);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_54 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[3].V_x_border, 4294967295);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_54;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_54.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[3].V_x_lost, 255);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_55 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[3].V_x_lost, 255);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_55;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_55.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[4].V_x_pos.V_m_X, 340282346638528897590636046441678635008);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_56 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[4].V_x_pos.V_m_X, 340282346638528897590636046441678635008);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_56;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_56.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[4].V_x_pos.V_m_Y, 340282346638528897590636046441678635008);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_57 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[4].V_x_pos.V_m_Y, 340282346638528897590636046441678635008);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_57;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_57.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[4].V_x_vel.V_m_X, 340282346638528897590636046441678635008);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_58 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[4].V_x_vel.V_m_X, 340282346638528897590636046441678635008);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_58;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_58.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[4].V_x_vel.V_m_Y, 340282346638528897590636046441678635008);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_59 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[4].V_x_vel.V_m_Y, 340282346638528897590636046441678635008);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_59;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_59.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[4].V_m_lat_pos_in_lane[0], 3.4028235e+38);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[4].V_m_lat_pos_in_lane[1], 3.4028235e+38);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[4].V_m_lat_pos_in_lane[2], 3.4028235e+38);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[4].V_m_lat_pos_in_lane[3], 3.4028235e+38);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[4].V_m_lat_pos_in_lane[4], 3.4028235e+38);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_60 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[4].V_m_lat_pos_in_lane[0], 3.4028235e+38);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[4].V_m_lat_pos_in_lane[1], 3.4028235e+38);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[4].V_m_lat_pos_in_lane[2], 3.4028235e+38);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[4].V_m_lat_pos_in_lane[3], 3.4028235e+38);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[4].V_m_lat_pos_in_lane[4], 3.4028235e+38);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_60;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_60.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[4].V_m_lat_vel_in_lane, 340282346638528897590636046441678635008);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_61 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[4].V_m_lat_vel_in_lane, 340282346638528897590636046441678635008);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_61;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_61.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[4].V_m_width, 340282346638528897590636046441678635008);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_62 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[4].V_m_width, 340282346638528897590636046441678635008);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_62;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_62.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[4].V_x_ID, 4294967295);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_63 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[4].V_x_ID, 4294967295);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_63;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_63.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[4].V_x_type, 4294967295);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_64 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[4].V_x_type, 4294967295);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_64;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_64.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[4].V_x_lane, 255);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_65 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[4].V_x_lane, 255);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_65;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_65.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[4].V_x_is_valid, 255);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_66 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[4].V_x_is_valid, 255);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_66;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_66.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[4].V_x_is_usable, 255);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_67 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[4].V_x_is_usable, 255);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_67;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_67.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[4].V_x_border, 4294967295);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_68 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[4].V_x_border, 4294967295);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_68;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_68.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[4].V_x_lost, 255);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_69 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[4].V_x_lost, 255);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_69;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_69.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[5].V_x_pos.V_m_X, 340282346638528897590636046441678635008);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_70 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[5].V_x_pos.V_m_X, 340282346638528897590636046441678635008);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_70;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_70.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[5].V_x_pos.V_m_Y, 340282346638528897590636046441678635008);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_71 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[5].V_x_pos.V_m_Y, 340282346638528897590636046441678635008);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_71;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_71.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[5].V_x_vel.V_m_X, 340282346638528897590636046441678635008);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_72 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[5].V_x_vel.V_m_X, 340282346638528897590636046441678635008);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_72;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_72.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[5].V_x_vel.V_m_Y, 340282346638528897590636046441678635008);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_73 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[5].V_x_vel.V_m_Y, 340282346638528897590636046441678635008);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_73;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_73.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[5].V_m_lat_pos_in_lane[0], 3.4028235e+38);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[5].V_m_lat_pos_in_lane[1], 3.4028235e+38);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[5].V_m_lat_pos_in_lane[2], 3.4028235e+38);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[5].V_m_lat_pos_in_lane[3], 3.4028235e+38);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[5].V_m_lat_pos_in_lane[4], 3.4028235e+38);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_74 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[5].V_m_lat_pos_in_lane[0], 3.4028235e+38);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[5].V_m_lat_pos_in_lane[1], 3.4028235e+38);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[5].V_m_lat_pos_in_lane[2], 3.4028235e+38);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[5].V_m_lat_pos_in_lane[3], 3.4028235e+38);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[5].V_m_lat_pos_in_lane[4], 3.4028235e+38);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_74;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_74.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[5].V_m_lat_vel_in_lane, 340282346638528897590636046441678635008);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_75 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[5].V_m_lat_vel_in_lane, 340282346638528897590636046441678635008);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_75;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_75.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[5].V_m_width, 340282346638528897590636046441678635008);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_76 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[5].V_m_width, 340282346638528897590636046441678635008);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_76;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_76.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[5].V_x_ID, 4294967295);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_77 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[5].V_x_ID, 4294967295);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_77;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_77.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[5].V_x_type, 4294967295);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_78 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[5].V_x_type, 4294967295);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_78;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_78.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[5].V_x_lane, 255);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_79 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[5].V_x_lane, 255);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_79;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_79.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[5].V_x_is_valid, 255);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_80 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[5].V_x_is_valid, 255);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_80;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_80.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[5].V_x_is_usable, 255);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_81 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[5].V_x_is_usable, 255);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_81;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_81.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[5].V_x_border, 4294967295);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_82 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[5].V_x_border, 4294967295);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_82;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_82.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[5].V_x_lost, 255);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_83 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[5].V_x_lost, 255);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_83;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_83.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[6].V_x_pos.V_m_X, 340282346638528897590636046441678635008);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_84 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[6].V_x_pos.V_m_X, 340282346638528897590636046441678635008);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_84;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_84.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[6].V_x_pos.V_m_Y, 340282346638528897590636046441678635008);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_85 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[6].V_x_pos.V_m_Y, 340282346638528897590636046441678635008);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_85;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_85.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[6].V_x_vel.V_m_X, 340282346638528897590636046441678635008);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_86 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[6].V_x_vel.V_m_X, 340282346638528897590636046441678635008);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_86;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_86.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[6].V_x_vel.V_m_Y, 340282346638528897590636046441678635008);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_87 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[6].V_x_vel.V_m_Y, 340282346638528897590636046441678635008);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_87;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_87.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[6].V_m_lat_pos_in_lane[0], 3.4028235e+38);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[6].V_m_lat_pos_in_lane[1], 3.4028235e+38);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[6].V_m_lat_pos_in_lane[2], 3.4028235e+38);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[6].V_m_lat_pos_in_lane[3], 3.4028235e+38);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[6].V_m_lat_pos_in_lane[4], 3.4028235e+38);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_88 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[6].V_m_lat_pos_in_lane[0], 3.4028235e+38);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[6].V_m_lat_pos_in_lane[1], 3.4028235e+38);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[6].V_m_lat_pos_in_lane[2], 3.4028235e+38);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[6].V_m_lat_pos_in_lane[3], 3.4028235e+38);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[6].V_m_lat_pos_in_lane[4], 3.4028235e+38);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_88;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_88.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[6].V_m_lat_vel_in_lane, 340282346638528897590636046441678635008);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_89 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[6].V_m_lat_vel_in_lane, 340282346638528897590636046441678635008);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_89;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_89.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[6].V_m_width, 340282346638528897590636046441678635008);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_90 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[6].V_m_width, 340282346638528897590636046441678635008);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_90;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_90.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[6].V_x_ID, 4294967295);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_91 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[6].V_x_ID, 4294967295);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_91;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_91.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[6].V_x_type, 4294967295);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_92 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[6].V_x_type, 4294967295);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_92;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_92.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[6].V_x_lane, 255);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_93 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[6].V_x_lane, 255);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_93;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_93.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[6].V_x_is_valid, 255);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_94 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[6].V_x_is_valid, 255);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_94;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_94.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[6].V_x_is_usable, 255);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_95 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[6].V_x_is_usable, 255);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_95;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_95.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[6].V_x_border, 4294967295);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_96 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[6].V_x_border, 4294967295);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_96;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_96.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[6].V_x_lost, 255);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_97 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[6].V_x_lost, 255);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_97;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_97.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[7].V_x_pos.V_m_X, 340282346638528897590636046441678635008);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_98 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[7].V_x_pos.V_m_X, 340282346638528897590636046441678635008);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_98;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_98.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[7].V_x_pos.V_m_Y, 340282346638528897590636046441678635008);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_99 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[7].V_x_pos.V_m_Y, 340282346638528897590636046441678635008);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_99;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_99.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[7].V_x_vel.V_m_X, 340282346638528897590636046441678635008);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_100 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[7].V_x_vel.V_m_X, 340282346638528897590636046441678635008);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_100;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_100.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[7].V_x_vel.V_m_Y, 340282346638528897590636046441678635008);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_101 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[7].V_x_vel.V_m_Y, 340282346638528897590636046441678635008);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_101;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_101.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[7].V_m_lat_pos_in_lane[0], 3.4028235e+38);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[7].V_m_lat_pos_in_lane[1], 3.4028235e+38);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[7].V_m_lat_pos_in_lane[2], 3.4028235e+38);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[7].V_m_lat_pos_in_lane[3], 3.4028235e+38);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[7].V_m_lat_pos_in_lane[4], 3.4028235e+38);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_102 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[7].V_m_lat_pos_in_lane[0], 3.4028235e+38);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[7].V_m_lat_pos_in_lane[1], 3.4028235e+38);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[7].V_m_lat_pos_in_lane[2], 3.4028235e+38);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[7].V_m_lat_pos_in_lane[3], 3.4028235e+38);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[7].V_m_lat_pos_in_lane[4], 3.4028235e+38);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_102;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_102.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[7].V_m_lat_vel_in_lane, 340282346638528897590636046441678635008);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_103 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[7].V_m_lat_vel_in_lane, 340282346638528897590636046441678635008);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_103;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_103.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[7].V_m_width, 340282346638528897590636046441678635008);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_104 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[7].V_m_width, 340282346638528897590636046441678635008);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_104;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_104.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[7].V_x_ID, 4294967295);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_105 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[7].V_x_ID, 4294967295);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_105;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_105.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[7].V_x_type, 4294967295);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_106 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[7].V_x_type, 4294967295);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_106;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_106.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[7].V_x_lane, 255);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_107 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[7].V_x_lane, 255);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_107;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_107.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[7].V_x_is_valid, 255);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_108 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[7].V_x_is_valid, 255);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_108;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_108.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[7].V_x_is_usable, 255);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_109 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[7].V_x_is_usable, 255);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_109;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_109.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[7].V_x_border, 4294967295);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_110 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[7].V_x_border, 4294967295);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_110;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_110.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[7].V_x_lost, 255);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_111 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[7].V_x_lost, 255);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_111;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_111.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[8].V_x_pos.V_m_X, 340282346638528897590636046441678635008);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_112 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[8].V_x_pos.V_m_X, 340282346638528897590636046441678635008);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_112;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_112.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[8].V_x_pos.V_m_Y, 340282346638528897590636046441678635008);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_113 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[8].V_x_pos.V_m_Y, 340282346638528897590636046441678635008);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_113;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_113.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[8].V_x_vel.V_m_X, 340282346638528897590636046441678635008);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_114 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[8].V_x_vel.V_m_X, 340282346638528897590636046441678635008);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_114;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_114.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[8].V_x_vel.V_m_Y, 340282346638528897590636046441678635008);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_115 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[8].V_x_vel.V_m_Y, 340282346638528897590636046441678635008);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_115;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_115.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[8].V_m_lat_pos_in_lane[0], 3.4028235e+38);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[8].V_m_lat_pos_in_lane[1], 3.4028235e+38);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[8].V_m_lat_pos_in_lane[2], 3.4028235e+38);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[8].V_m_lat_pos_in_lane[3], 3.4028235e+38);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[8].V_m_lat_pos_in_lane[4], 3.4028235e+38);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_116 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[8].V_m_lat_pos_in_lane[0], 3.4028235e+38);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[8].V_m_lat_pos_in_lane[1], 3.4028235e+38);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[8].V_m_lat_pos_in_lane[2], 3.4028235e+38);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[8].V_m_lat_pos_in_lane[3], 3.4028235e+38);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[8].V_m_lat_pos_in_lane[4], 3.4028235e+38);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_116;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_116.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[8].V_m_lat_vel_in_lane, 340282346638528897590636046441678635008);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_117 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[8].V_m_lat_vel_in_lane, 340282346638528897590636046441678635008);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_117;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_117.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[8].V_m_width, 340282346638528897590636046441678635008);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_118 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[8].V_m_width, 340282346638528897590636046441678635008);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_118;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_118.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[8].V_x_ID, 4294967295);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_119 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[8].V_x_ID, 4294967295);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_119;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_119.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[8].V_x_type, 4294967295);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_120 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[8].V_x_type, 4294967295);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_120;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_120.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[8].V_x_lane, 255);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_121 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[8].V_x_lane, 255);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_121;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_121.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[8].V_x_is_valid, 255);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_122 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[8].V_x_is_valid, 255);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_122;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_122.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[8].V_x_is_usable, 255);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_123 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[8].V_x_is_usable, 255);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_123;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_123.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[8].V_x_border, 4294967295);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_124 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[8].V_x_border, 4294967295);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_124;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_124.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[8].V_x_lost, 255);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_125 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[8].V_x_lost, 255);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_125;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_125.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[9].V_x_pos.V_m_X, 340282346638528897590636046441678635008);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_126 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[9].V_x_pos.V_m_X, 340282346638528897590636046441678635008);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_126;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_126.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[9].V_x_pos.V_m_Y, 340282346638528897590636046441678635008);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_127 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[9].V_x_pos.V_m_Y, 340282346638528897590636046441678635008);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_127;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_127.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[9].V_x_vel.V_m_X, 340282346638528897590636046441678635008);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_128 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[9].V_x_vel.V_m_X, 340282346638528897590636046441678635008);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_128;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_128.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[9].V_x_vel.V_m_Y, 340282346638528897590636046441678635008);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_129 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[9].V_x_vel.V_m_Y, 340282346638528897590636046441678635008);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_129;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_129.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[9].V_m_lat_pos_in_lane[0], 3.4028235e+38);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[9].V_m_lat_pos_in_lane[1], 3.4028235e+38);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[9].V_m_lat_pos_in_lane[2], 3.4028235e+38);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[9].V_m_lat_pos_in_lane[3], 3.4028235e+38);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[9].V_m_lat_pos_in_lane[4], 3.4028235e+38);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_130 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[9].V_m_lat_pos_in_lane[0], 3.4028235e+38);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[9].V_m_lat_pos_in_lane[1], 3.4028235e+38);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[9].V_m_lat_pos_in_lane[2], 3.4028235e+38);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[9].V_m_lat_pos_in_lane[3], 3.4028235e+38);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[9].V_m_lat_pos_in_lane[4], 3.4028235e+38);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_130;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_130.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[9].V_m_lat_vel_in_lane, 340282346638528897590636046441678635008);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_131 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[9].V_m_lat_vel_in_lane, 340282346638528897590636046441678635008);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_131;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_131.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[9].V_m_width, 340282346638528897590636046441678635008);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_132 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[9].V_m_width, 340282346638528897590636046441678635008);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_132;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_132.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[9].V_x_ID, 4294967295);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_133 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[9].V_x_ID, 4294967295);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_133;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_133.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[9].V_x_type, 4294967295);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_134 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[9].V_x_type, 4294967295);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_134;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_134.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[9].V_x_lane, 255);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_135 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[9].V_x_lane, 255);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_135;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_135.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[9].V_x_is_valid, 255);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_136 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[9].V_x_is_valid, 255);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_136;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_136.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[9].V_x_is_usable, 255);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_137 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[9].V_x_is_usable, 255);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_137;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_137.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[9].V_x_border, 4294967295);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_138 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[9].V_x_border, 4294967295);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_138;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_138.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[9].V_x_lost, 255);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_139 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[9].V_x_lost, 255);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_139;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_139.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[10].V_x_pos.V_m_X, 340282346638528897590636046441678635008);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_140 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[10].V_x_pos.V_m_X, 340282346638528897590636046441678635008);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_140;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_140.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[10].V_x_pos.V_m_Y, 340282346638528897590636046441678635008);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_141 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[10].V_x_pos.V_m_Y, 340282346638528897590636046441678635008);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_141;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_141.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[10].V_x_vel.V_m_X, 340282346638528897590636046441678635008);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_142 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[10].V_x_vel.V_m_X, 340282346638528897590636046441678635008);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_142;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_142.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[10].V_x_vel.V_m_Y, 340282346638528897590636046441678635008);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_143 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[10].V_x_vel.V_m_Y, 340282346638528897590636046441678635008);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_143;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_143.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[10].V_m_lat_pos_in_lane[0], 3.4028235e+38);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[10].V_m_lat_pos_in_lane[1], 3.4028235e+38);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[10].V_m_lat_pos_in_lane[2], 3.4028235e+38);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[10].V_m_lat_pos_in_lane[3], 3.4028235e+38);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[10].V_m_lat_pos_in_lane[4], 3.4028235e+38);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_144 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[10].V_m_lat_pos_in_lane[0], 3.4028235e+38);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[10].V_m_lat_pos_in_lane[1], 3.4028235e+38);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[10].V_m_lat_pos_in_lane[2], 3.4028235e+38);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[10].V_m_lat_pos_in_lane[3], 3.4028235e+38);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[10].V_m_lat_pos_in_lane[4], 3.4028235e+38);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_144;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_144.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[10].V_m_lat_vel_in_lane, 340282346638528897590636046441678635008);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_145 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[10].V_m_lat_vel_in_lane, 340282346638528897590636046441678635008);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_145;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_145.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[10].V_m_width, 340282346638528897590636046441678635008);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_146 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[10].V_m_width, 340282346638528897590636046441678635008);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_146;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_146.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[10].V_x_ID, 4294967295);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_147 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[10].V_x_ID, 4294967295);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_147;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_147.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[10].V_x_type, 4294967295);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_148 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[10].V_x_type, 4294967295);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_148;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_148.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[10].V_x_lane, 255);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_149 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[10].V_x_lane, 255);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_149;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_149.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[10].V_x_is_valid, 255);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_150 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[10].V_x_is_valid, 255);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_150;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_150.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[10].V_x_is_usable, 255);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_151 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[10].V_x_is_usable, 255);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_151;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_151.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[10].V_x_border, 4294967295);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_152 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[10].V_x_border, 4294967295);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_152;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_152.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[10].V_x_lost, 255);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_153 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[10].V_x_lost, 255);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_153;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_153.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[11].V_x_pos.V_m_X, 340282346638528897590636046441678635008);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_154 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[11].V_x_pos.V_m_X, 340282346638528897590636046441678635008);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_154;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_154.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[11].V_x_pos.V_m_Y, 340282346638528897590636046441678635008);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_155 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[11].V_x_pos.V_m_Y, 340282346638528897590636046441678635008);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_155;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_155.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[11].V_x_vel.V_m_X, 340282346638528897590636046441678635008);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_156 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[11].V_x_vel.V_m_X, 340282346638528897590636046441678635008);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_156;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_156.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[11].V_x_vel.V_m_Y, 340282346638528897590636046441678635008);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_157 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[11].V_x_vel.V_m_Y, 340282346638528897590636046441678635008);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_157;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_157.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[11].V_m_lat_pos_in_lane[0], 3.4028235e+38);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[11].V_m_lat_pos_in_lane[1], 3.4028235e+38);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[11].V_m_lat_pos_in_lane[2], 3.4028235e+38);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[11].V_m_lat_pos_in_lane[3], 3.4028235e+38);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[11].V_m_lat_pos_in_lane[4], 3.4028235e+38);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_158 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[11].V_m_lat_pos_in_lane[0], 3.4028235e+38);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[11].V_m_lat_pos_in_lane[1], 3.4028235e+38);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[11].V_m_lat_pos_in_lane[2], 3.4028235e+38);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[11].V_m_lat_pos_in_lane[3], 3.4028235e+38);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[11].V_m_lat_pos_in_lane[4], 3.4028235e+38);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_158;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_158.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[11].V_m_lat_vel_in_lane, 340282346638528897590636046441678635008);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_159 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[11].V_m_lat_vel_in_lane, 340282346638528897590636046441678635008);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_159;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_159.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[11].V_m_width, 340282346638528897590636046441678635008);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_160 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[11].V_m_width, 340282346638528897590636046441678635008);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_160;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_160.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[11].V_x_ID, 4294967295);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_161 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[11].V_x_ID, 4294967295);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_161;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_161.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[11].V_x_type, 4294967295);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_162 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[11].V_x_type, 4294967295);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_162;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_162.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[11].V_x_lane, 255);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_163 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[11].V_x_lane, 255);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_163;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_163.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[11].V_x_is_valid, 255);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_164 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[11].V_x_is_valid, 255);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_164;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_164.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[11].V_x_is_usable, 255);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_165 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[11].V_x_is_usable, 255);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_165;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_165.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[11].V_x_border, 4294967295);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_166 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[11].V_x_border, 4294967295);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_166;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_166.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[11].V_x_lost, 255);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_167 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[11].V_x_lost, 255);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_167;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_167.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[12].V_x_pos.V_m_X, 340282346638528897590636046441678635008);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_168 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[12].V_x_pos.V_m_X, 340282346638528897590636046441678635008);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_168;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_168.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[12].V_x_pos.V_m_Y, 340282346638528897590636046441678635008);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_169 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[12].V_x_pos.V_m_Y, 340282346638528897590636046441678635008);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_169;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_169.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[12].V_x_vel.V_m_X, 340282346638528897590636046441678635008);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_170 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[12].V_x_vel.V_m_X, 340282346638528897590636046441678635008);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_170;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_170.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[12].V_x_vel.V_m_Y, 340282346638528897590636046441678635008);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_171 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[12].V_x_vel.V_m_Y, 340282346638528897590636046441678635008);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_171;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_171.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[12].V_m_lat_pos_in_lane[0], 3.4028235e+38);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[12].V_m_lat_pos_in_lane[1], 3.4028235e+38);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[12].V_m_lat_pos_in_lane[2], 3.4028235e+38);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[12].V_m_lat_pos_in_lane[3], 3.4028235e+38);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[12].V_m_lat_pos_in_lane[4], 3.4028235e+38);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_172 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[12].V_m_lat_pos_in_lane[0], 3.4028235e+38);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[12].V_m_lat_pos_in_lane[1], 3.4028235e+38);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[12].V_m_lat_pos_in_lane[2], 3.4028235e+38);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[12].V_m_lat_pos_in_lane[3], 3.4028235e+38);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[12].V_m_lat_pos_in_lane[4], 3.4028235e+38);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_172;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_172.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[12].V_m_lat_vel_in_lane, 340282346638528897590636046441678635008);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_173 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[12].V_m_lat_vel_in_lane, 340282346638528897590636046441678635008);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_173;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_173.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[12].V_m_width, 340282346638528897590636046441678635008);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_174 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[12].V_m_width, 340282346638528897590636046441678635008);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_174;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_174.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[12].V_x_ID, 4294967295);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_175 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[12].V_x_ID, 4294967295);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_175;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_175.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[12].V_x_type, 4294967295);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_176 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[12].V_x_type, 4294967295);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_176;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_176.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[12].V_x_lane, 255);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_177 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[12].V_x_lane, 255);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_177;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_177.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[12].V_x_is_valid, 255);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_178 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[12].V_x_is_valid, 255);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_178;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_178.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[12].V_x_is_usable, 255);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_179 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[12].V_x_is_usable, 255);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_179;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_179.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[12].V_x_border, 4294967295);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_180 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[12].V_x_border, 4294967295);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_180;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_180.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[12].V_x_lost, 255);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_181 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[12].V_x_lost, 255);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_181;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_181.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[13].V_x_pos.V_m_X, 340282346638528897590636046441678635008);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_182 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[13].V_x_pos.V_m_X, 340282346638528897590636046441678635008);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_182;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_182.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[13].V_x_pos.V_m_Y, 340282346638528897590636046441678635008);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_183 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[13].V_x_pos.V_m_Y, 340282346638528897590636046441678635008);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_183;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_183.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[13].V_x_vel.V_m_X, 340282346638528897590636046441678635008);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_184 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[13].V_x_vel.V_m_X, 340282346638528897590636046441678635008);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_184;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_184.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[13].V_x_vel.V_m_Y, 340282346638528897590636046441678635008);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_185 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[13].V_x_vel.V_m_Y, 340282346638528897590636046441678635008);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_185;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_185.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[13].V_m_lat_pos_in_lane[0], 3.4028235e+38);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[13].V_m_lat_pos_in_lane[1], 3.4028235e+38);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[13].V_m_lat_pos_in_lane[2], 3.4028235e+38);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[13].V_m_lat_pos_in_lane[3], 3.4028235e+38);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[13].V_m_lat_pos_in_lane[4], 3.4028235e+38);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_186 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[13].V_m_lat_pos_in_lane[0], 3.4028235e+38);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[13].V_m_lat_pos_in_lane[1], 3.4028235e+38);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[13].V_m_lat_pos_in_lane[2], 3.4028235e+38);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[13].V_m_lat_pos_in_lane[3], 3.4028235e+38);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[13].V_m_lat_pos_in_lane[4], 3.4028235e+38);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_186;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_186.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[13].V_m_lat_vel_in_lane, 340282346638528897590636046441678635008);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_187 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[13].V_m_lat_vel_in_lane, 340282346638528897590636046441678635008);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_187;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_187.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[13].V_m_width, 340282346638528897590636046441678635008);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_188 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[13].V_m_width, 340282346638528897590636046441678635008);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_188;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_188.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[13].V_x_ID, 4294967295);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_189 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[13].V_x_ID, 4294967295);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_189;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_189.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[13].V_x_type, 4294967295);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_190 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[13].V_x_type, 4294967295);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_190;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_190.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[13].V_x_lane, 255);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_191 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[13].V_x_lane, 255);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_191;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_191.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[13].V_x_is_valid, 255);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_192 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[13].V_x_is_valid, 255);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_192;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_192.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[13].V_x_is_usable, 255);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_193 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[13].V_x_is_usable, 255);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_193;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_193.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[13].V_x_border, 4294967295);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_194 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[13].V_x_border, 4294967295);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_194;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_194.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[13].V_x_lost, 255);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_195 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[13].V_x_lost, 255);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_195;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_195.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[14].V_x_pos.V_m_X, 340282346638528897590636046441678635008);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_196 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[14].V_x_pos.V_m_X, 340282346638528897590636046441678635008);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_196;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_196.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[14].V_x_pos.V_m_Y, 340282346638528897590636046441678635008);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_197 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[14].V_x_pos.V_m_Y, 340282346638528897590636046441678635008);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_197;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_197.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[14].V_x_vel.V_m_X, 340282346638528897590636046441678635008);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_198 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[14].V_x_vel.V_m_X, 340282346638528897590636046441678635008);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_198;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_198.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[14].V_x_vel.V_m_Y, 340282346638528897590636046441678635008);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_199 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[14].V_x_vel.V_m_Y, 340282346638528897590636046441678635008);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_199;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_199.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[14].V_m_lat_pos_in_lane[0], 3.4028235e+38);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[14].V_m_lat_pos_in_lane[1], 3.4028235e+38);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[14].V_m_lat_pos_in_lane[2], 3.4028235e+38);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[14].V_m_lat_pos_in_lane[3], 3.4028235e+38);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[14].V_m_lat_pos_in_lane[4], 3.4028235e+38);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_200 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[14].V_m_lat_pos_in_lane[0], 3.4028235e+38);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[14].V_m_lat_pos_in_lane[1], 3.4028235e+38);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[14].V_m_lat_pos_in_lane[2], 3.4028235e+38);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[14].V_m_lat_pos_in_lane[3], 3.4028235e+38);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[14].V_m_lat_pos_in_lane[4], 3.4028235e+38);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_200;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_200.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[14].V_m_lat_vel_in_lane, 340282346638528897590636046441678635008);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_201 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[14].V_m_lat_vel_in_lane, 340282346638528897590636046441678635008);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_201;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_201.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[14].V_m_width, 340282346638528897590636046441678635008);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_202 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[14].V_m_width, 340282346638528897590636046441678635008);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_202;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_202.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[14].V_x_ID, 4294967295);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_203 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[14].V_x_ID, 4294967295);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_203;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_203.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[14].V_x_type, 4294967295);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_204 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[14].V_x_type, 4294967295);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_204;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_204.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[14].V_x_lane, 255);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_205 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[14].V_x_lane, 255);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_205;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_205.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[14].V_x_is_valid, 255);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_206 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[14].V_x_is_valid, 255);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_206;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_206.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[14].V_x_is_usable, 255);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_207 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[14].V_x_is_usable, 255);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_207;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_207.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[14].V_x_border, 4294967295);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_208 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[14].V_x_border, 4294967295);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_208;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_208.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[14].V_x_lost, 255);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_209 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[14].V_x_lost, 255);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_209;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_209.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[15].V_x_pos.V_m_X, 340282346638528897590636046441678635008);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_210 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[15].V_x_pos.V_m_X, 340282346638528897590636046441678635008);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_210;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_210.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[15].V_x_pos.V_m_Y, 340282346638528897590636046441678635008);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_211 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[15].V_x_pos.V_m_Y, 340282346638528897590636046441678635008);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_211;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_211.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[15].V_x_vel.V_m_X, 340282346638528897590636046441678635008);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_212 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[15].V_x_vel.V_m_X, 340282346638528897590636046441678635008);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_212;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_212.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[15].V_x_vel.V_m_Y, 340282346638528897590636046441678635008);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_213 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[15].V_x_vel.V_m_Y, 340282346638528897590636046441678635008);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_213;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_213.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[15].V_m_lat_pos_in_lane[0], 3.4028235e+38);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[15].V_m_lat_pos_in_lane[1], 3.4028235e+38);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[15].V_m_lat_pos_in_lane[2], 3.4028235e+38);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[15].V_m_lat_pos_in_lane[3], 3.4028235e+38);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[15].V_m_lat_pos_in_lane[4], 3.4028235e+38);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_214 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[15].V_m_lat_pos_in_lane[0], 3.4028235e+38);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[15].V_m_lat_pos_in_lane[1], 3.4028235e+38);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[15].V_m_lat_pos_in_lane[2], 3.4028235e+38);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[15].V_m_lat_pos_in_lane[3], 3.4028235e+38);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[15].V_m_lat_pos_in_lane[4], 3.4028235e+38);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_214;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_214.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[15].V_m_lat_vel_in_lane, 340282346638528897590636046441678635008);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_215 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[15].V_m_lat_vel_in_lane, 340282346638528897590636046441678635008);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_215;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_215.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[15].V_m_width, 340282346638528897590636046441678635008);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_216 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[15].V_m_width, 340282346638528897590636046441678635008);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_216;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_216.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[15].V_x_ID, 4294967295);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_217 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[15].V_x_ID, 4294967295);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_217;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_217.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[15].V_x_type, 4294967295);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_218 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[15].V_x_type, 4294967295);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_218;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_218.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[15].V_x_lane, 255);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_219 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[15].V_x_lane, 255);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_219;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_219.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[15].V_x_is_valid, 255);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_220 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[15].V_x_is_valid, 255);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_220;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_220.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[15].V_x_is_usable, 255);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_221 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[15].V_x_is_usable, 255);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_221;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_221.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[15].V_x_border, 4294967295);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_222 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[15].V_x_border, 4294967295);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_222;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_222.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[15].V_x_lost, 255);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_223 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[15].V_x_lost, 255);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_223;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_223.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[16].V_x_pos.V_m_X, 340282346638528897590636046441678635008);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_224 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[16].V_x_pos.V_m_X, 340282346638528897590636046441678635008);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_224;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_224.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[16].V_x_pos.V_m_Y, 340282346638528897590636046441678635008);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_225 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[16].V_x_pos.V_m_Y, 340282346638528897590636046441678635008);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_225;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_225.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[16].V_x_vel.V_m_X, 340282346638528897590636046441678635008);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_226 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[16].V_x_vel.V_m_X, 340282346638528897590636046441678635008);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_226;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_226.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[16].V_x_vel.V_m_Y, 340282346638528897590636046441678635008);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_227 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[16].V_x_vel.V_m_Y, 340282346638528897590636046441678635008);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_227;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_227.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[16].V_m_lat_pos_in_lane[0], 3.4028235e+38);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[16].V_m_lat_pos_in_lane[1], 3.4028235e+38);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[16].V_m_lat_pos_in_lane[2], 3.4028235e+38);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[16].V_m_lat_pos_in_lane[3], 3.4028235e+38);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[16].V_m_lat_pos_in_lane[4], 3.4028235e+38);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_228 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[16].V_m_lat_pos_in_lane[0], 3.4028235e+38);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[16].V_m_lat_pos_in_lane[1], 3.4028235e+38);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[16].V_m_lat_pos_in_lane[2], 3.4028235e+38);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[16].V_m_lat_pos_in_lane[3], 3.4028235e+38);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[16].V_m_lat_pos_in_lane[4], 3.4028235e+38);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_228;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_228.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[16].V_m_lat_vel_in_lane, 340282346638528897590636046441678635008);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_229 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[16].V_m_lat_vel_in_lane, 340282346638528897590636046441678635008);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_229;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_229.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[16].V_m_width, 340282346638528897590636046441678635008);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_230 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[16].V_m_width, 340282346638528897590636046441678635008);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_230;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_230.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[16].V_x_ID, 4294967295);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_231 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[16].V_x_ID, 4294967295);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_231;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_231.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[16].V_x_type, 4294967295);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_232 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[16].V_x_type, 4294967295);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_232;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_232.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[16].V_x_lane, 255);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_233 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[16].V_x_lane, 255);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_233;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_233.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[16].V_x_is_valid, 255);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_234 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[16].V_x_is_valid, 255);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_234;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_234.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[16].V_x_is_usable, 255);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_235 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[16].V_x_is_usable, 255);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_235;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_235.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[16].V_x_border, 4294967295);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_236 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[16].V_x_border, 4294967295);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_236;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_236.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[16].V_x_lost, 255);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_237 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[16].V_x_lost, 255);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_237;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_237.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[17].V_x_pos.V_m_X, 340282346638528897590636046441678635008);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_238 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[17].V_x_pos.V_m_X, 340282346638528897590636046441678635008);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_238;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_238.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[17].V_x_pos.V_m_Y, 340282346638528897590636046441678635008);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_239 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[17].V_x_pos.V_m_Y, 340282346638528897590636046441678635008);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_239;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_239.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[17].V_x_vel.V_m_X, 340282346638528897590636046441678635008);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_240 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[17].V_x_vel.V_m_X, 340282346638528897590636046441678635008);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_240;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_240.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[17].V_x_vel.V_m_Y, 340282346638528897590636046441678635008);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_241 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[17].V_x_vel.V_m_Y, 340282346638528897590636046441678635008);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_241;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_241.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[17].V_m_lat_pos_in_lane[0], 3.4028235e+38);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[17].V_m_lat_pos_in_lane[1], 3.4028235e+38);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[17].V_m_lat_pos_in_lane[2], 3.4028235e+38);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[17].V_m_lat_pos_in_lane[3], 3.4028235e+38);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[17].V_m_lat_pos_in_lane[4], 3.4028235e+38);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_242 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[17].V_m_lat_pos_in_lane[0], 3.4028235e+38);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[17].V_m_lat_pos_in_lane[1], 3.4028235e+38);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[17].V_m_lat_pos_in_lane[2], 3.4028235e+38);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[17].V_m_lat_pos_in_lane[3], 3.4028235e+38);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[17].V_m_lat_pos_in_lane[4], 3.4028235e+38);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_242;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_242.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[17].V_m_lat_vel_in_lane, 340282346638528897590636046441678635008);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_243 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[17].V_m_lat_vel_in_lane, 340282346638528897590636046441678635008);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_243;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_243.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[17].V_m_width, 340282346638528897590636046441678635008);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_244 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[17].V_m_width, 340282346638528897590636046441678635008);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_244;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_244.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[17].V_x_ID, 4294967295);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_245 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[17].V_x_ID, 4294967295);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_245;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_245.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[17].V_x_type, 4294967295);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_246 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[17].V_x_type, 4294967295);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_246;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_246.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[17].V_x_lane, 255);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_247 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[17].V_x_lane, 255);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_247;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_247.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[17].V_x_is_valid, 255);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_248 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[17].V_x_is_valid, 255);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_248;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_248.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[17].V_x_is_usable, 255);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_249 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[17].V_x_is_usable, 255);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_249;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_249.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[17].V_x_border, 4294967295);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_250 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[17].V_x_border, 4294967295);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_250;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_250.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[17].V_x_lost, 255);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_251 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[17].V_x_lost, 255);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_251;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_251.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[18].V_x_pos.V_m_X, 340282346638528897590636046441678635008);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_252 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[18].V_x_pos.V_m_X, 340282346638528897590636046441678635008);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_252;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_252.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[18].V_x_pos.V_m_Y, 340282346638528897590636046441678635008);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_253 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[18].V_x_pos.V_m_Y, 340282346638528897590636046441678635008);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_253;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_253.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[18].V_x_vel.V_m_X, 340282346638528897590636046441678635008);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_254 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[18].V_x_vel.V_m_X, 340282346638528897590636046441678635008);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_254;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_254.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[18].V_x_vel.V_m_Y, 340282346638528897590636046441678635008);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_255 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[18].V_x_vel.V_m_Y, 340282346638528897590636046441678635008);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_255;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_255.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[18].V_m_lat_pos_in_lane[0], 3.4028235e+38);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[18].V_m_lat_pos_in_lane[1], 3.4028235e+38);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[18].V_m_lat_pos_in_lane[2], 3.4028235e+38);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[18].V_m_lat_pos_in_lane[3], 3.4028235e+38);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[18].V_m_lat_pos_in_lane[4], 3.4028235e+38);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_256 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[18].V_m_lat_pos_in_lane[0], 3.4028235e+38);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[18].V_m_lat_pos_in_lane[1], 3.4028235e+38);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[18].V_m_lat_pos_in_lane[2], 3.4028235e+38);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[18].V_m_lat_pos_in_lane[3], 3.4028235e+38);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[18].V_m_lat_pos_in_lane[4], 3.4028235e+38);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_256;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_256.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[18].V_m_lat_vel_in_lane, 340282346638528897590636046441678635008);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_257 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[18].V_m_lat_vel_in_lane, 340282346638528897590636046441678635008);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_257;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_257.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[18].V_m_width, 340282346638528897590636046441678635008);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_258 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[18].V_m_width, 340282346638528897590636046441678635008);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_258;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_258.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[18].V_x_ID, 4294967295);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_259 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[18].V_x_ID, 4294967295);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_259;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_259.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[18].V_x_type, 4294967295);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_260 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[18].V_x_type, 4294967295);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_260;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_260.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[18].V_x_lane, 255);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_261 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[18].V_x_lane, 255);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_261;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_261.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[18].V_x_is_valid, 255);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_262 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[18].V_x_is_valid, 255);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_262;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_262.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[18].V_x_is_usable, 255);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_263 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[18].V_x_is_usable, 255);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_263;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_263.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[18].V_x_border, 4294967295);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_264 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[18].V_x_border, 4294967295);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_264;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_264.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[18].V_x_lost, 255);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_265 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[18].V_x_lost, 255);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_265;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_265.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[19].V_x_pos.V_m_X, 340282346638528897590636046441678635008);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_266 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[19].V_x_pos.V_m_X, 340282346638528897590636046441678635008);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_266;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_266.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[19].V_x_pos.V_m_Y, 340282346638528897590636046441678635008);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_267 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[19].V_x_pos.V_m_Y, 340282346638528897590636046441678635008);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_267;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_267.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[19].V_x_vel.V_m_X, 340282346638528897590636046441678635008);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_268 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[19].V_x_vel.V_m_X, 340282346638528897590636046441678635008);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_268;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_268.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[19].V_x_vel.V_m_Y, 340282346638528897590636046441678635008);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_269 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[19].V_x_vel.V_m_Y, 340282346638528897590636046441678635008);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_269;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_269.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[19].V_m_lat_pos_in_lane[0], 3.4028235e+38);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[19].V_m_lat_pos_in_lane[1], 3.4028235e+38);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[19].V_m_lat_pos_in_lane[2], 3.4028235e+38);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[19].V_m_lat_pos_in_lane[3], 3.4028235e+38);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[19].V_m_lat_pos_in_lane[4], 3.4028235e+38);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_270 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[19].V_m_lat_pos_in_lane[0], 3.4028235e+38);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[19].V_m_lat_pos_in_lane[1], 3.4028235e+38);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[19].V_m_lat_pos_in_lane[2], 3.4028235e+38);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[19].V_m_lat_pos_in_lane[3], 3.4028235e+38);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[19].V_m_lat_pos_in_lane[4], 3.4028235e+38);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_270;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_270.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[19].V_m_lat_vel_in_lane, 340282346638528897590636046441678635008);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_271 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[19].V_m_lat_vel_in_lane, 340282346638528897590636046441678635008);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_271;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_271.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[19].V_m_width, 340282346638528897590636046441678635008);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_272 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[19].V_m_width, 340282346638528897590636046441678635008);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_272;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_272.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[19].V_x_ID, 4294967295);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_273 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[19].V_x_ID, 4294967295);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_273;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_273.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[19].V_x_type, 4294967295);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_274 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[19].V_x_type, 4294967295);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_274;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_274.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[19].V_x_lane, 255);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_275 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[19].V_x_lane, 255);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_275;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_275.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[19].V_x_is_valid, 255);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_276 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[19].V_x_is_valid, 255);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_276;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_276.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[19].V_x_is_usable, 255);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_277 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[19].V_x_is_usable, 255);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_277;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_277.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[19].V_x_border, 4294967295);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_278 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[19].V_x_border, 4294967295);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_278;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_278.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[19].V_x_lost, 255);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_279 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[19].V_x_lost, 255);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_279;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_279.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[20].V_x_pos.V_m_X, 340282346638528897590636046441678635008);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_280 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[20].V_x_pos.V_m_X, 340282346638528897590636046441678635008);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_280;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_280.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[20].V_x_pos.V_m_Y, 340282346638528897590636046441678635008);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_281 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[20].V_x_pos.V_m_Y, 340282346638528897590636046441678635008);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_281;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_281.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[20].V_x_vel.V_m_X, 340282346638528897590636046441678635008);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_282 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[20].V_x_vel.V_m_X, 340282346638528897590636046441678635008);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_282;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_282.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[20].V_x_vel.V_m_Y, 340282346638528897590636046441678635008);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_283 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[20].V_x_vel.V_m_Y, 340282346638528897590636046441678635008);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_283;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_283.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[20].V_m_lat_pos_in_lane[0], 3.4028235e+38);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[20].V_m_lat_pos_in_lane[1], 3.4028235e+38);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[20].V_m_lat_pos_in_lane[2], 3.4028235e+38);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[20].V_m_lat_pos_in_lane[3], 3.4028235e+38);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[20].V_m_lat_pos_in_lane[4], 3.4028235e+38);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_284 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[20].V_m_lat_pos_in_lane[0], 3.4028235e+38);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[20].V_m_lat_pos_in_lane[1], 3.4028235e+38);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[20].V_m_lat_pos_in_lane[2], 3.4028235e+38);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[20].V_m_lat_pos_in_lane[3], 3.4028235e+38);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[20].V_m_lat_pos_in_lane[4], 3.4028235e+38);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_284;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_284.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[20].V_m_lat_vel_in_lane, 340282346638528897590636046441678635008);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_285 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[20].V_m_lat_vel_in_lane, 340282346638528897590636046441678635008);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_285;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_285.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[20].V_m_width, 340282346638528897590636046441678635008);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_286 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[20].V_m_width, 340282346638528897590636046441678635008);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_286;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_286.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[20].V_x_ID, 4294967295);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_287 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[20].V_x_ID, 4294967295);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_287;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_287.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[20].V_x_type, 4294967295);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_288 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[20].V_x_type, 4294967295);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_288;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_288.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[20].V_x_lane, 255);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_289 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[20].V_x_lane, 255);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_289;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_289.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[20].V_x_is_valid, 255);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_290 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[20].V_x_is_valid, 255);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_290;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_290.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[20].V_x_is_usable, 255);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_291 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[20].V_x_is_usable, 255);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_291;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_291.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[20].V_x_border, 4294967295);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_292 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[20].V_x_border, 4294967295);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_292;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_292.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[20].V_x_lost, 255);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_293 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[20].V_x_lost, 255);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_293;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_293.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[21].V_x_pos.V_m_X, 340282346638528897590636046441678635008);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_294 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[21].V_x_pos.V_m_X, 340282346638528897590636046441678635008);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_294;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_294.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[21].V_x_pos.V_m_Y, 340282346638528897590636046441678635008);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_295 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[21].V_x_pos.V_m_Y, 340282346638528897590636046441678635008);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_295;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_295.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[21].V_x_vel.V_m_X, 340282346638528897590636046441678635008);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_296 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[21].V_x_vel.V_m_X, 340282346638528897590636046441678635008);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_296;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_296.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[21].V_x_vel.V_m_Y, 340282346638528897590636046441678635008);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_297 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[21].V_x_vel.V_m_Y, 340282346638528897590636046441678635008);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_297;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_297.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[21].V_m_lat_pos_in_lane[0], 3.4028235e+38);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[21].V_m_lat_pos_in_lane[1], 3.4028235e+38);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[21].V_m_lat_pos_in_lane[2], 3.4028235e+38);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[21].V_m_lat_pos_in_lane[3], 3.4028235e+38);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[21].V_m_lat_pos_in_lane[4], 3.4028235e+38);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_298 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[21].V_m_lat_pos_in_lane[0], 3.4028235e+38);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[21].V_m_lat_pos_in_lane[1], 3.4028235e+38);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[21].V_m_lat_pos_in_lane[2], 3.4028235e+38);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[21].V_m_lat_pos_in_lane[3], 3.4028235e+38);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[21].V_m_lat_pos_in_lane[4], 3.4028235e+38);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_298;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_298.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[21].V_m_lat_vel_in_lane, 340282346638528897590636046441678635008);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_299 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[21].V_m_lat_vel_in_lane, 340282346638528897590636046441678635008);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_299;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_299.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[21].V_m_width, 340282346638528897590636046441678635008);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_300 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[21].V_m_width, 340282346638528897590636046441678635008);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_300;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_300.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[21].V_x_ID, 4294967295);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_301 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[21].V_x_ID, 4294967295);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_301;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_301.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[21].V_x_type, 4294967295);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_302 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[21].V_x_type, 4294967295);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_302;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_302.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[21].V_x_lane, 255);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_303 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[21].V_x_lane, 255);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_303;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_303.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[21].V_x_is_valid, 255);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_304 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[21].V_x_is_valid, 255);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_304;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_304.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[21].V_x_is_usable, 255);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_305 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[21].V_x_is_usable, 255);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_305;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_305.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[21].V_x_border, 4294967295);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_306 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[21].V_x_border, 4294967295);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_306;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_306.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[21].V_x_lost, 255);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_307 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[21].V_x_lost, 255);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_307;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_307.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[22].V_x_pos.V_m_X, 340282346638528897590636046441678635008);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_308 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[22].V_x_pos.V_m_X, 340282346638528897590636046441678635008);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_308;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_308.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[22].V_x_pos.V_m_Y, 340282346638528897590636046441678635008);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_309 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[22].V_x_pos.V_m_Y, 340282346638528897590636046441678635008);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_309;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_309.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[22].V_x_vel.V_m_X, 340282346638528897590636046441678635008);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_310 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[22].V_x_vel.V_m_X, 340282346638528897590636046441678635008);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_310;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_310.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[22].V_x_vel.V_m_Y, 340282346638528897590636046441678635008);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_311 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[22].V_x_vel.V_m_Y, 340282346638528897590636046441678635008);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_311;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_311.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[22].V_m_lat_pos_in_lane[0], 3.4028235e+38);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[22].V_m_lat_pos_in_lane[1], 3.4028235e+38);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[22].V_m_lat_pos_in_lane[2], 3.4028235e+38);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[22].V_m_lat_pos_in_lane[3], 3.4028235e+38);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[22].V_m_lat_pos_in_lane[4], 3.4028235e+38);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_312 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[22].V_m_lat_pos_in_lane[0], 3.4028235e+38);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[22].V_m_lat_pos_in_lane[1], 3.4028235e+38);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[22].V_m_lat_pos_in_lane[2], 3.4028235e+38);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[22].V_m_lat_pos_in_lane[3], 3.4028235e+38);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[22].V_m_lat_pos_in_lane[4], 3.4028235e+38);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_312;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_312.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[22].V_m_lat_vel_in_lane, 340282346638528897590636046441678635008);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_313 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[22].V_m_lat_vel_in_lane, 340282346638528897590636046441678635008);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_313;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_313.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[22].V_m_width, 340282346638528897590636046441678635008);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_314 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[22].V_m_width, 340282346638528897590636046441678635008);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_314;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_314.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[22].V_x_ID, 4294967295);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_315 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[22].V_x_ID, 4294967295);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_315;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_315.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[22].V_x_type, 4294967295);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_316 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[22].V_x_type, 4294967295);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_316;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_316.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[22].V_x_lane, 255);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_317 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[22].V_x_lane, 255);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_317;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_317.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[22].V_x_is_valid, 255);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_318 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[22].V_x_is_valid, 255);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_318;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_318.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[22].V_x_is_usable, 255);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_319 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[22].V_x_is_usable, 255);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_319;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_319.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[22].V_x_border, 4294967295);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_320 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[22].V_x_border, 4294967295);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_320;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_320.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[22].V_x_lost, 255);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_321 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[22].V_x_lost, 255);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_321;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_321.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[23].V_x_pos.V_m_X, 340282346638528897590636046441678635008);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_322 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[23].V_x_pos.V_m_X, 340282346638528897590636046441678635008);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_322;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_322.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[23].V_x_pos.V_m_Y, 340282346638528897590636046441678635008);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_323 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[23].V_x_pos.V_m_Y, 340282346638528897590636046441678635008);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_323;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_323.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[23].V_x_vel.V_m_X, 340282346638528897590636046441678635008);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_324 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[23].V_x_vel.V_m_X, 340282346638528897590636046441678635008);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_324;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_324.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[23].V_x_vel.V_m_Y, 340282346638528897590636046441678635008);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_325 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[23].V_x_vel.V_m_Y, 340282346638528897590636046441678635008);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_325;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_325.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[23].V_m_lat_pos_in_lane[0], 3.4028235e+38);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[23].V_m_lat_pos_in_lane[1], 3.4028235e+38);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[23].V_m_lat_pos_in_lane[2], 3.4028235e+38);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[23].V_m_lat_pos_in_lane[3], 3.4028235e+38);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[23].V_m_lat_pos_in_lane[4], 3.4028235e+38);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_326 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[23].V_m_lat_pos_in_lane[0], 3.4028235e+38);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[23].V_m_lat_pos_in_lane[1], 3.4028235e+38);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[23].V_m_lat_pos_in_lane[2], 3.4028235e+38);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[23].V_m_lat_pos_in_lane[3], 3.4028235e+38);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[23].V_m_lat_pos_in_lane[4], 3.4028235e+38);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_326;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_326.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[23].V_m_lat_vel_in_lane, 340282346638528897590636046441678635008);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_327 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[23].V_m_lat_vel_in_lane, 340282346638528897590636046441678635008);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_327;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_327.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[23].V_m_width, 340282346638528897590636046441678635008);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_328 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[23].V_m_width, 340282346638528897590636046441678635008);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_328;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_328.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[23].V_x_ID, 4294967295);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_329 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[23].V_x_ID, 4294967295);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_329;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_329.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[23].V_x_type, 4294967295);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_330 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[23].V_x_type, 4294967295);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_330;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_330.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[23].V_x_lane, 255);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_331 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[23].V_x_lane, 255);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_331;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_331.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[23].V_x_is_valid, 255);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_332 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[23].V_x_is_valid, 255);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_332;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_332.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[23].V_x_is_usable, 255);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_333 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[23].V_x_is_usable, 255);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_333;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_333.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[23].V_x_border, 4294967295);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_334 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[23].V_x_border, 4294967295);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_334;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_334.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[23].V_x_lost, 255);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_335 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[23].V_x_lost, 255);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_335;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_335.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[24].V_x_pos.V_m_X, 340282346638528897590636046441678635008);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_336 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[24].V_x_pos.V_m_X, 340282346638528897590636046441678635008);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_336;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_336.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[24].V_x_pos.V_m_Y, 340282346638528897590636046441678635008);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_337 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[24].V_x_pos.V_m_Y, 340282346638528897590636046441678635008);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_337;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_337.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[24].V_x_vel.V_m_X, 340282346638528897590636046441678635008);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_338 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[24].V_x_vel.V_m_X, 340282346638528897590636046441678635008);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_338;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_338.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[24].V_x_vel.V_m_Y, 340282346638528897590636046441678635008);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_339 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[24].V_x_vel.V_m_Y, 340282346638528897590636046441678635008);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_339;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_339.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[24].V_m_lat_pos_in_lane[0], 3.4028235e+38);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[24].V_m_lat_pos_in_lane[1], 3.4028235e+38);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[24].V_m_lat_pos_in_lane[2], 3.4028235e+38);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[24].V_m_lat_pos_in_lane[3], 3.4028235e+38);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[24].V_m_lat_pos_in_lane[4], 3.4028235e+38);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_340 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[24].V_m_lat_pos_in_lane[0], 3.4028235e+38);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[24].V_m_lat_pos_in_lane[1], 3.4028235e+38);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[24].V_m_lat_pos_in_lane[2], 3.4028235e+38);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[24].V_m_lat_pos_in_lane[3], 3.4028235e+38);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[24].V_m_lat_pos_in_lane[4], 3.4028235e+38);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_340;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_340.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[24].V_m_lat_vel_in_lane, 340282346638528897590636046441678635008);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_341 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[24].V_m_lat_vel_in_lane, 340282346638528897590636046441678635008);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_341;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_341.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[24].V_m_width, 340282346638528897590636046441678635008);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_342 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[24].V_m_width, 340282346638528897590636046441678635008);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_342;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_342.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[24].V_x_ID, 4294967295);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_343 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[24].V_x_ID, 4294967295);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_343;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_343.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[24].V_x_type, 4294967295);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_344 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[24].V_x_type, 4294967295);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_344;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_344.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[24].V_x_lane, 255);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_345 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[24].V_x_lane, 255);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_345;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_345.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[24].V_x_is_valid, 255);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_346 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[24].V_x_is_valid, 255);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_346;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_346.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[24].V_x_is_usable, 255);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_347 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[24].V_x_is_usable, 255);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_347;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_347.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[24].V_x_border, 4294967295);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_348 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[24].V_x_border, 4294967295);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_348;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_348.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[24].V_x_lost, 255);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_349 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[24].V_x_lost, 255);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_349;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_349.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[25].V_x_pos.V_m_X, 340282346638528897590636046441678635008);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_350 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[25].V_x_pos.V_m_X, 340282346638528897590636046441678635008);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_350;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_350.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[25].V_x_pos.V_m_Y, 340282346638528897590636046441678635008);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_351 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[25].V_x_pos.V_m_Y, 340282346638528897590636046441678635008);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_351;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_351.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[25].V_x_vel.V_m_X, 340282346638528897590636046441678635008);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_352 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[25].V_x_vel.V_m_X, 340282346638528897590636046441678635008);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_352;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_352.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[25].V_x_vel.V_m_Y, 340282346638528897590636046441678635008);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_353 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[25].V_x_vel.V_m_Y, 340282346638528897590636046441678635008);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_353;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_353.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[25].V_m_lat_pos_in_lane[0], 3.4028235e+38);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[25].V_m_lat_pos_in_lane[1], 3.4028235e+38);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[25].V_m_lat_pos_in_lane[2], 3.4028235e+38);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[25].V_m_lat_pos_in_lane[3], 3.4028235e+38);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[25].V_m_lat_pos_in_lane[4], 3.4028235e+38);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_354 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[25].V_m_lat_pos_in_lane[0], 3.4028235e+38);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[25].V_m_lat_pos_in_lane[1], 3.4028235e+38);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[25].V_m_lat_pos_in_lane[2], 3.4028235e+38);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[25].V_m_lat_pos_in_lane[3], 3.4028235e+38);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[25].V_m_lat_pos_in_lane[4], 3.4028235e+38);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_354;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_354.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[25].V_m_lat_vel_in_lane, 340282346638528897590636046441678635008);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_355 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[25].V_m_lat_vel_in_lane, 340282346638528897590636046441678635008);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_355;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_355.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[25].V_m_width, 340282346638528897590636046441678635008);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_356 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[25].V_m_width, 340282346638528897590636046441678635008);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_356;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_356.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[25].V_x_ID, 4294967295);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_357 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[25].V_x_ID, 4294967295);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_357;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_357.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[25].V_x_type, 4294967295);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_358 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[25].V_x_type, 4294967295);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_358;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_358.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[25].V_x_lane, 255);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_359 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[25].V_x_lane, 255);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_359;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_359.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[25].V_x_is_valid, 255);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_360 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[25].V_x_is_valid, 255);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_360;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_360.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[25].V_x_is_usable, 255);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_361 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[25].V_x_is_usable, 255);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_361;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_361.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[25].V_x_border, 4294967295);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_362 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[25].V_x_border, 4294967295);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_362;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_362.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[25].V_x_lost, 255);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_363 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[25].V_x_lost, 255);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_363;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_363.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[26].V_x_pos.V_m_X, 340282346638528897590636046441678635008);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_364 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[26].V_x_pos.V_m_X, 340282346638528897590636046441678635008);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_364;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_364.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[26].V_x_pos.V_m_Y, 340282346638528897590636046441678635008);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_365 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[26].V_x_pos.V_m_Y, 340282346638528897590636046441678635008);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_365;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_365.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[26].V_x_vel.V_m_X, 340282346638528897590636046441678635008);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_366 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[26].V_x_vel.V_m_X, 340282346638528897590636046441678635008);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_366;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_366.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[26].V_x_vel.V_m_Y, 340282346638528897590636046441678635008);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_367 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[26].V_x_vel.V_m_Y, 340282346638528897590636046441678635008);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_367;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_367.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[26].V_m_lat_pos_in_lane[0], 3.4028235e+38);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[26].V_m_lat_pos_in_lane[1], 3.4028235e+38);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[26].V_m_lat_pos_in_lane[2], 3.4028235e+38);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[26].V_m_lat_pos_in_lane[3], 3.4028235e+38);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[26].V_m_lat_pos_in_lane[4], 3.4028235e+38);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_368 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[26].V_m_lat_pos_in_lane[0], 3.4028235e+38);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[26].V_m_lat_pos_in_lane[1], 3.4028235e+38);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[26].V_m_lat_pos_in_lane[2], 3.4028235e+38);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[26].V_m_lat_pos_in_lane[3], 3.4028235e+38);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[26].V_m_lat_pos_in_lane[4], 3.4028235e+38);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_368;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_368.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[26].V_m_lat_vel_in_lane, 340282346638528897590636046441678635008);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_369 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[26].V_m_lat_vel_in_lane, 340282346638528897590636046441678635008);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_369;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_369.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[26].V_m_width, 340282346638528897590636046441678635008);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_370 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[26].V_m_width, 340282346638528897590636046441678635008);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_370;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_370.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[26].V_x_ID, 4294967295);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_371 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[26].V_x_ID, 4294967295);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_371;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_371.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[26].V_x_type, 4294967295);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_372 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[26].V_x_type, 4294967295);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_372;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_372.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[26].V_x_lane, 255);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_373 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[26].V_x_lane, 255);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_373;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_373.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[26].V_x_is_valid, 255);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_374 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[26].V_x_is_valid, 255);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_374;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_374.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[26].V_x_is_usable, 255);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_375 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[26].V_x_is_usable, 255);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_375;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_375.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[26].V_x_border, 4294967295);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_376 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[26].V_x_border, 4294967295);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_376;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_376.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[26].V_x_lost, 255);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_377 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[26].V_x_lost, 255);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_377;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_377.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[27].V_x_pos.V_m_X, 340282346638528897590636046441678635008);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_378 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[27].V_x_pos.V_m_X, 340282346638528897590636046441678635008);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_378;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_378.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[27].V_x_pos.V_m_Y, 340282346638528897590636046441678635008);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_379 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[27].V_x_pos.V_m_Y, 340282346638528897590636046441678635008);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_379;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_379.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[27].V_x_vel.V_m_X, 340282346638528897590636046441678635008);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_380 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[27].V_x_vel.V_m_X, 340282346638528897590636046441678635008);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_380;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_380.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[27].V_x_vel.V_m_Y, 340282346638528897590636046441678635008);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_381 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[27].V_x_vel.V_m_Y, 340282346638528897590636046441678635008);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_381;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_381.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[27].V_m_lat_pos_in_lane[0], 3.4028235e+38);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[27].V_m_lat_pos_in_lane[1], 3.4028235e+38);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[27].V_m_lat_pos_in_lane[2], 3.4028235e+38);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[27].V_m_lat_pos_in_lane[3], 3.4028235e+38);
    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[27].V_m_lat_pos_in_lane[4], 3.4028235e+38);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_382 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[27].V_m_lat_pos_in_lane[0], 3.4028235e+38);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[27].V_m_lat_pos_in_lane[1], 3.4028235e+38);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[27].V_m_lat_pos_in_lane[2], 3.4028235e+38);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[27].V_m_lat_pos_in_lane[3], 3.4028235e+38);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[27].V_m_lat_pos_in_lane[4], 3.4028235e+38);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_382;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_382.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[27].V_m_lat_vel_in_lane, 340282346638528897590636046441678635008);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_383 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[27].V_m_lat_vel_in_lane, 340282346638528897590636046441678635008);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_383;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_383.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[27].V_m_width, 340282346638528897590636046441678635008);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_384 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_FLOAT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[27].V_m_width, 340282346638528897590636046441678635008);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_384;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_384.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[27].V_x_ID, 4294967295);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_385 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[27].V_x_ID, 4294967295);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_385;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_385.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[27].V_x_type, 4294967295);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_386 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[27].V_x_type, 4294967295);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_386;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_386.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[27].V_x_lane, 255);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_387 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[27].V_x_lane, 255);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_387;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_387.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[27].V_x_is_valid, 255);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_388 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[27].V_x_is_valid, 255);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_388;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_388.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[27].V_x_is_usable, 255);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_389 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[27].V_x_is_usable, 255);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_389;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_389.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[27].V_x_border, 4294967295);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_390 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[27].V_x_border, 4294967295);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_390;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_390.verify();

    EXPECT_EQ(gOEM_SWC_C2_3UVehStatus_In_100DataSet.mConc.V_x_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[27].V_x_lost, 255);
    struct _func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_391 {
        static void verify(void) {
#include "Rte_Wrapper_ObjectSelectionAVM.h"
            V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;
            Rte_Read_V_x_sorted_side_radar_obj_t_V_x_sorted_side_radar_obj_t(&tmp_sorted_side_radar_obj_t);
            EXPECT_EQ(tmp_sorted_side_radar_obj_t.V_x_sorted_side_radar_obj[27].V_x_lost, 255);
        }
    } func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_391;
    func_V_x_sorted_side_radar_obj_t_ObjectSelectionAVM_391.verify();

}
