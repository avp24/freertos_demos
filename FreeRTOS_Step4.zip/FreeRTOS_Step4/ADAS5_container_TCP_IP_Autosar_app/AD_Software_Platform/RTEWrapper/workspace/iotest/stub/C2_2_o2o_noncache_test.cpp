#include "gtest/gtest.h"

#ifdef __cplusplus
extern "C" {
#endif
extern void OEM_SWC_C2_2_input_From_SUP(void);
extern void OEM_SWC_C2_2_output(void);
extern void OEM_SWC_C0_SM_input_From_OEM(void);
extern void OEM_SWC_C1_1_input_From_OEM(void);
extern void OEM_SWC_C2_1_input_From_OEM(void);
extern void OEM_SWC_C2_3_input_From_OEM(void);
#ifdef __cplusplus
}
#endif

extern void C2_2_o2o_noncache_prepare_AutoLCPossibilityJdg(void);
extern void C2_2_o2o_noncache_prepare_ObjectSelectionDM(void);
extern void C2_2_o2o_noncache_prepare_VehStatus_In_50(void);
extern void C2_2_o2o_noncache_verify_AutoLCPossibilityJdg(void);
extern void C2_2_o2o_noncache_verify_ObjectSelectionDM(void);
extern void C2_2_o2o_noncache_verify_VehStatus_In_50(void);
void C2_2_o2o_noncache_prepare(void)
{
    C2_2_o2o_noncache_prepare_AutoLCPossibilityJdg();
    C2_2_o2o_noncache_prepare_ObjectSelectionDM();
    C2_2_o2o_noncache_prepare_VehStatus_In_50();
}

void C2_2_o2o_noncache_verify(void)
{
    C2_2_o2o_noncache_verify_AutoLCPossibilityJdg();
    C2_2_o2o_noncache_verify_ObjectSelectionDM();
    C2_2_o2o_noncache_verify_VehStatus_In_50();
}

TEST(IOTest, C2_2_o2o_noncache_test)
{
    C2_2_o2o_noncache_prepare();
    OEM_SWC_C2_2_output();
    OEM_SWC_C0_SM_input_From_OEM();
    OEM_SWC_C1_1_input_From_OEM();
    OEM_SWC_C2_1_input_From_OEM();
    OEM_SWC_C2_3_input_From_OEM();
    C2_2_o2o_noncache_verify();
}
