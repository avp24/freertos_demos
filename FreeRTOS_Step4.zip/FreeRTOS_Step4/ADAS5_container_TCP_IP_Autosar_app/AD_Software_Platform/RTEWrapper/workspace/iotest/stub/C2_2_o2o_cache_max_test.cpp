#include "gtest/gtest.h"

#ifdef __cplusplus
extern "C" {
#endif
extern void OEM_SWC_C2_2_input_From_SUP(void);
extern void OEM_SWC_C2_2_output(void);
#ifdef __cplusplus
}
#endif

extern void C2_2_o2o_cache_max_prepare_AutoLCPossibilityJdg(void);
extern void C2_2_o2o_cache_max_prepare_ObjectSelectionDM(void);
extern void C2_2_o2o_cache_max_prepare_VehStatus_In_50(void);
extern void C2_2_o2o_cache_max_verify_AutoLCPossibilityJdg(void);
extern void C2_2_o2o_cache_max_verify_ObjectSelectionDM(void);
extern void C2_2_o2o_cache_max_verify_VehStatus_In_50(void);
void C2_2_o2o_cache_max_prepare(void)
{
    C2_2_o2o_cache_max_prepare_AutoLCPossibilityJdg();
    C2_2_o2o_cache_max_prepare_ObjectSelectionDM();
    C2_2_o2o_cache_max_prepare_VehStatus_In_50();
}

void C2_2_o2o_cache_max_verify(void)
{
    C2_2_o2o_cache_max_verify_AutoLCPossibilityJdg();
    C2_2_o2o_cache_max_verify_ObjectSelectionDM();
    C2_2_o2o_cache_max_verify_VehStatus_In_50();
}

TEST(IOTest, C2_2_o2o_cache_max_test)
{
    C2_2_o2o_cache_max_prepare();
    C2_2_o2o_cache_max_verify();
}
