#include <limits.h>
#include <float.h>
#define DUMMY_RTE_INCLUDE_MULTI_SWC_HEADER
#include "Platform_Types.h"
#ifdef __cplusplus
extern "C" {
#endif
#ifdef __cplusplus
}
#endif

#include "Rte_Wrapper_SafetyModule.h"
void C0_SM_o2s_prepare_SafetyModule(void)
{
    uint16 tmp_U16;
    sint16 tmp_S16;
    sint8 tmp_S8;
    uint8 tmp_U8;

    tmp_U16 = 31123;
    Rte_Write_V_Nm_AEB_BrakeWheelTorqueRequest2_CAN_V_Nm_AEB_BrakeWheelTorqueRequest2_CAN(tmp_U16);
    tmp_U16 = 9355;
    Rte_Write_V_Nm_AEB_BrakeWheelTorqueRequest3_CAN_V_Nm_AEB_BrakeWheelTorqueRequest3_CAN(tmp_U16);
    tmp_S16 = 18173;
    Rte_Write_V_Nm_Global_PWTWheelTorqueRequest_V_Nm_Global_PWTWheelTorqueRequest(tmp_S16);
    tmp_S16 = -1681;
    Rte_Write_V_Nm_PWTWheelTorqueLimitationRequest_CAN_V_Nm_PWTWheelTorqueLimitationRequest_CAN(tmp_S16);
    tmp_S8 = -47;
    Rte_Write_V_x_ADmodeStatus_CAN_V_x_ADmodeStatus_CAN(tmp_S8);
    tmp_U8 = 206;
    Rte_Write_V_x_Global_PWTWheelTorqueOrder_V_x_Global_PWTWheelTorqueOrder(tmp_U8);
    tmp_U8 = 41;
    Rte_Write_V_x_PWTWheelTorqueLimitationOrder_CAN_V_x_PWTWheelTorqueLimitationOrder_CAN(tmp_U8);
}
