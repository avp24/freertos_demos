#include <limits.h>
#include <float.h>
#include "gtest/gtest.h"
#include "Platform_Types.h"




void C2_3_o2s_verify_RCarHMIManagement(void)
{
}

void C2_3_o2s_verify_ObjectSelectionAVM(void)
{
}

void C2_3_o2s_verify_VehStatus_In_100(void)
{
}
