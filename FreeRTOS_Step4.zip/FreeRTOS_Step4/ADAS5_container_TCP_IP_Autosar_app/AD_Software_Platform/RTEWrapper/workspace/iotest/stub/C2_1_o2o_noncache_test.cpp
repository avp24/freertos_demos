#include "gtest/gtest.h"

#ifdef __cplusplus
extern "C" {
#endif
extern void OEM_SWC_C2_1_input_From_SUP(void);
extern void OEM_SWC_C2_1_output(void);
extern void OEM_SWC_C0_SM_input_From_OEM(void);
extern void OEM_SWC_C1_1_input_From_OEM(void);
extern void OEM_SWC_C2_2_input_From_OEM(void);
extern void OEM_SWC_C2_3_input_From_OEM(void);
#ifdef __cplusplus
}
#endif

extern void C2_1_o2o_noncache_prepare_SurroundFusion(void);
extern void C2_1_o2o_noncache_prepare_VehStatus_In_10(void);
extern void C2_1_o2o_noncache_verify_SurroundFusion(void);
extern void C2_1_o2o_noncache_verify_VehStatus_In_10(void);
void C2_1_o2o_noncache_prepare(void)
{
    C2_1_o2o_noncache_prepare_SurroundFusion();
    C2_1_o2o_noncache_prepare_VehStatus_In_10();
}

void C2_1_o2o_noncache_verify(void)
{
    C2_1_o2o_noncache_verify_SurroundFusion();
    C2_1_o2o_noncache_verify_VehStatus_In_10();
}

TEST(IOTest, C2_1_o2o_noncache_test)
{
    C2_1_o2o_noncache_prepare();
    OEM_SWC_C2_1_output();
    OEM_SWC_C0_SM_input_From_OEM();
    OEM_SWC_C1_1_input_From_OEM();
    OEM_SWC_C2_2_input_From_OEM();
    OEM_SWC_C2_3_input_From_OEM();
    C2_1_o2o_noncache_verify();
}
