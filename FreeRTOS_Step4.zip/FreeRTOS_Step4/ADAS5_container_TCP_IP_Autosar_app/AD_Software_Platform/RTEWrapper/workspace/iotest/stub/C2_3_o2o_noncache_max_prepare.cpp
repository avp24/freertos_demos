#include <limits.h>
#include <float.h>
#define DUMMY_RTE_INCLUDE_MULTI_SWC_HEADER
#include "Platform_Types.h"

#include "Rte_Wrapper_RCarHMIManagement.h"
void C2_3_o2o_noncache_max_prepare_RCarHMIManagement(void)
{
    V_x_RCarHMIManagementOutput tmp_RCarHMIManagementOutput;

    tmp_RCarHMIManagementOutput.V_x_PeriVehRecog_MetVecX[0] = 255;
    tmp_RCarHMIManagementOutput.V_x_PeriVehRecog_MetVecX[1] = 255;
    tmp_RCarHMIManagementOutput.V_x_PeriVehRecog_MetVecX[2] = 255;
    tmp_RCarHMIManagementOutput.V_x_PeriVehRecog_MetVecX[3] = 255;
    tmp_RCarHMIManagementOutput.V_x_PeriVehRecog_MetVecX[4] = 255;
    tmp_RCarHMIManagementOutput.V_x_PeriVehRecog_MetVecX[5] = 255;
    tmp_RCarHMIManagementOutput.V_x_PeriVehRecog_MetVecX[6] = 255;
    tmp_RCarHMIManagementOutput.V_x_PeriVehRecog_MetVecX[7] = 255;
    tmp_RCarHMIManagementOutput.V_x_PeriVehRecog_MetVecX[8] = 255;
    tmp_RCarHMIManagementOutput.V_x_PeriVehRecog_MetVecY[0] = 127;
    tmp_RCarHMIManagementOutput.V_x_PeriVehRecog_MetVecY[1] = 127;
    tmp_RCarHMIManagementOutput.V_x_PeriVehRecog_MetVecY[2] = 127;
    tmp_RCarHMIManagementOutput.V_x_PeriVehRecog_MetVecY[3] = 127;
    tmp_RCarHMIManagementOutput.V_x_PeriVehRecog_MetVecY[4] = 127;
    tmp_RCarHMIManagementOutput.V_x_PeriVehRecog_MetVecY[5] = 127;
    tmp_RCarHMIManagementOutput.V_x_PeriVehRecog_MetVecY[6] = 127;
    tmp_RCarHMIManagementOutput.V_x_PeriVehRecog_MetVecY[7] = 127;
    tmp_RCarHMIManagementOutput.V_x_PeriVehRecog_MetVecY[8] = 127;
    tmp_RCarHMIManagementOutput.V_x_PeriVehRecog_MetVecType[0] = 255;
    tmp_RCarHMIManagementOutput.V_x_PeriVehRecog_MetVecType[1] = 255;
    tmp_RCarHMIManagementOutput.V_x_PeriVehRecog_MetVecType[2] = 255;
    tmp_RCarHMIManagementOutput.V_x_PeriVehRecog_MetVecType[3] = 255;
    tmp_RCarHMIManagementOutput.V_x_PeriVehRecog_MetVecType[4] = 255;
    tmp_RCarHMIManagementOutput.V_x_PeriVehRecog_MetVecType[5] = 255;
    tmp_RCarHMIManagementOutput.V_x_PeriVehRecog_MetVecType[6] = 255;
    tmp_RCarHMIManagementOutput.V_x_PeriVehRecog_MetVecType[7] = 255;
    tmp_RCarHMIManagementOutput.V_x_PeriVehRecog_MetVecType[8] = 255;
    Rte_Write_V_x_RCarHMIManagementOutput_V_x_RCarHMIManagementOutput(&tmp_RCarHMIManagementOutput);
}

#include "Rte_Wrapper_ObjectSelectionAVM.h"
void C2_3_o2o_noncache_max_prepare_ObjectSelectionAVM(void)
{
    V_x_ObjectSelectionAVMOutput tmp_ObjectSelectionAVMOutput;

    tmp_ObjectSelectionAVMOutput.V_cm_Object1_X = 340282346638528897590636046441678635008;
    tmp_ObjectSelectionAVMOutput.V_cm_Object1_Y = 340282346638528897590636046441678635008;
    tmp_ObjectSelectionAVMOutput.V_mps_Object1_Xspeed = 340282346638528897590636046441678635008;
    tmp_ObjectSelectionAVMOutput.V_mps_Object1_Yspeed = 340282346638528897590636046441678635008;
    tmp_ObjectSelectionAVMOutput.V_x_Object1_ID = 255;
    tmp_ObjectSelectionAVMOutput.V_cm_Object2_X = 340282346638528897590636046441678635008;
    tmp_ObjectSelectionAVMOutput.V_cm_Object2_Y = 340282346638528897590636046441678635008;
    tmp_ObjectSelectionAVMOutput.V_mps_Object2_Xspeed = 340282346638528897590636046441678635008;
    tmp_ObjectSelectionAVMOutput.V_mps_Object2_Yspeed = 340282346638528897590636046441678635008;
    tmp_ObjectSelectionAVMOutput.V_x_Object2_ID = 255;
    tmp_ObjectSelectionAVMOutput.V_cm_Object3_X = 340282346638528897590636046441678635008;
    tmp_ObjectSelectionAVMOutput.V_cm_Object3_Y = 340282346638528897590636046441678635008;
    tmp_ObjectSelectionAVMOutput.V_mps_Object3_Xspeed = 340282346638528897590636046441678635008;
    tmp_ObjectSelectionAVMOutput.V_mps_Object3_Yspeed = 340282346638528897590636046441678635008;
    tmp_ObjectSelectionAVMOutput.V_x_Object3_ID = 255;
    tmp_ObjectSelectionAVMOutput.V_cm_Object4_X = 340282346638528897590636046441678635008;
    tmp_ObjectSelectionAVMOutput.V_cm_Object4_Y = 340282346638528897590636046441678635008;
    tmp_ObjectSelectionAVMOutput.V_mps_Object4_Xspeed = 340282346638528897590636046441678635008;
    tmp_ObjectSelectionAVMOutput.V_mps_Object4_Yspeed = 340282346638528897590636046441678635008;
    tmp_ObjectSelectionAVMOutput.V_x_Object4_ID = 255;
    tmp_ObjectSelectionAVMOutput.V_cm_Object5_X = 340282346638528897590636046441678635008;
    tmp_ObjectSelectionAVMOutput.V_cm_Object5_Y = 340282346638528897590636046441678635008;
    tmp_ObjectSelectionAVMOutput.V_mps_Object5_Xspeed = 340282346638528897590636046441678635008;
    tmp_ObjectSelectionAVMOutput.V_mps_Object5_Yspeed = 340282346638528897590636046441678635008;
    tmp_ObjectSelectionAVMOutput.V_x_Object5_ID = 255;
    tmp_ObjectSelectionAVMOutput.V_x_DetectionDirection = 255;
    Rte_Write_V_x_ObjectSelectionAVMOutput_V_x_ObjectSelectionAVMOutput(&tmp_ObjectSelectionAVMOutput);
}

#include "Rte_Wrapper_VehStatus_In_100.h"
void C2_3_o2o_noncache_max_prepare_VehStatus_In_100(void)
{
    V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
    sint32 tmp_S32;
    V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
    V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;

}
