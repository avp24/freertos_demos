#include <limits.h>
#include <float.h>
#include "gtest/gtest.h"
#include "Rte_Union.h"
#include "Platform_Types.h"

extern USurroundFusionDataSet gOEM_SWC_C2_1USurroundFusionDataSet;
void C2_1_o2o_cache_max_verify_SurroundFusion(void)
{
    V_x_SurroundFusionOutput tmp_SurroundFusionOutput;
    sint32 tmp_S32;
    V_x_clustered_side_radar_obj_t_inter tmp_clustered_side_radar_obj_t_inter;
    V_x_sorted_side_radar_obj_t_inter tmp_sorted_side_radar_obj_t_inter;
    V_x_surround_obj_left_t_inter tmp_surround_obj_left_t_inter;
    V_x_surround_obj_rearcenter_t_inter tmp_surround_obj_rearcenter_t_inter;
    V_x_surround_obj_right_t_inter tmp_surround_obj_right_t_inter;

}

extern UVehStatus_In_10DataSet gOEM_SWC_C2_1UVehStatus_In_10DataSet;
void C2_1_o2o_cache_max_verify_VehStatus_In_10(void)
{
    uint8 tmp_U8;
    V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;

    /* V_x_SurroundFusionSensorInput */
    EXPECT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_left_radar_obj[0].V_x_Id, 255);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_0 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_EQ(tmp_SurroundFusionSensorInput.V_x_front_left_radar_obj[0].V_x_Id, 255);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_0;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_0.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_left_radar_obj[0].V_m_Dist_X, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_1 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_front_left_radar_obj[0].V_m_Dist_X, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_1;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_1.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_left_radar_obj[0].V_m_Dist_Y, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_2 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_front_left_radar_obj[0].V_m_Dist_Y, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_2;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_2.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_left_radar_obj[0].V_mps_Relspd_X, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_3 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_front_left_radar_obj[0].V_mps_Relspd_X, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_3;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_3.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_left_radar_obj[0].V_mps_Relspd_Y, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_4 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_front_left_radar_obj[0].V_mps_Relspd_Y, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_4;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_4.verify();

    EXPECT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_left_radar_obj[0].V_x_RelPos_Frspc, 255);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_5 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_EQ(tmp_SurroundFusionSensorInput.V_x_front_left_radar_obj[0].V_x_RelPos_Frspc, 255);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_5;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_5.verify();

    EXPECT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_left_radar_obj[0].V_x_MtnClass, 255);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_6 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_EQ(tmp_SurroundFusionSensorInput.V_x_front_left_radar_obj[0].V_x_MtnClass, 255);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_6;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_6.verify();

    EXPECT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_left_radar_obj[1].V_x_Id, 255);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_7 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_EQ(tmp_SurroundFusionSensorInput.V_x_front_left_radar_obj[1].V_x_Id, 255);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_7;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_7.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_left_radar_obj[1].V_m_Dist_X, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_8 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_front_left_radar_obj[1].V_m_Dist_X, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_8;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_8.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_left_radar_obj[1].V_m_Dist_Y, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_9 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_front_left_radar_obj[1].V_m_Dist_Y, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_9;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_9.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_left_radar_obj[1].V_mps_Relspd_X, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_10 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_front_left_radar_obj[1].V_mps_Relspd_X, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_10;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_10.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_left_radar_obj[1].V_mps_Relspd_Y, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_11 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_front_left_radar_obj[1].V_mps_Relspd_Y, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_11;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_11.verify();

    EXPECT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_left_radar_obj[1].V_x_RelPos_Frspc, 255);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_12 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_EQ(tmp_SurroundFusionSensorInput.V_x_front_left_radar_obj[1].V_x_RelPos_Frspc, 255);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_12;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_12.verify();

    EXPECT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_left_radar_obj[1].V_x_MtnClass, 255);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_13 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_EQ(tmp_SurroundFusionSensorInput.V_x_front_left_radar_obj[1].V_x_MtnClass, 255);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_13;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_13.verify();

    EXPECT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_left_radar_obj[2].V_x_Id, 255);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_14 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_EQ(tmp_SurroundFusionSensorInput.V_x_front_left_radar_obj[2].V_x_Id, 255);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_14;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_14.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_left_radar_obj[2].V_m_Dist_X, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_15 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_front_left_radar_obj[2].V_m_Dist_X, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_15;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_15.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_left_radar_obj[2].V_m_Dist_Y, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_16 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_front_left_radar_obj[2].V_m_Dist_Y, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_16;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_16.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_left_radar_obj[2].V_mps_Relspd_X, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_17 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_front_left_radar_obj[2].V_mps_Relspd_X, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_17;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_17.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_left_radar_obj[2].V_mps_Relspd_Y, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_18 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_front_left_radar_obj[2].V_mps_Relspd_Y, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_18;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_18.verify();

    EXPECT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_left_radar_obj[2].V_x_RelPos_Frspc, 255);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_19 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_EQ(tmp_SurroundFusionSensorInput.V_x_front_left_radar_obj[2].V_x_RelPos_Frspc, 255);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_19;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_19.verify();

    EXPECT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_left_radar_obj[2].V_x_MtnClass, 255);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_20 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_EQ(tmp_SurroundFusionSensorInput.V_x_front_left_radar_obj[2].V_x_MtnClass, 255);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_20;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_20.verify();

    EXPECT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_left_radar_obj[3].V_x_Id, 255);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_21 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_EQ(tmp_SurroundFusionSensorInput.V_x_front_left_radar_obj[3].V_x_Id, 255);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_21;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_21.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_left_radar_obj[3].V_m_Dist_X, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_22 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_front_left_radar_obj[3].V_m_Dist_X, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_22;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_22.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_left_radar_obj[3].V_m_Dist_Y, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_23 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_front_left_radar_obj[3].V_m_Dist_Y, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_23;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_23.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_left_radar_obj[3].V_mps_Relspd_X, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_24 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_front_left_radar_obj[3].V_mps_Relspd_X, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_24;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_24.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_left_radar_obj[3].V_mps_Relspd_Y, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_25 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_front_left_radar_obj[3].V_mps_Relspd_Y, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_25;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_25.verify();

    EXPECT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_left_radar_obj[3].V_x_RelPos_Frspc, 255);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_26 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_EQ(tmp_SurroundFusionSensorInput.V_x_front_left_radar_obj[3].V_x_RelPos_Frspc, 255);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_26;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_26.verify();

    EXPECT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_left_radar_obj[3].V_x_MtnClass, 255);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_27 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_EQ(tmp_SurroundFusionSensorInput.V_x_front_left_radar_obj[3].V_x_MtnClass, 255);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_27;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_27.verify();

    EXPECT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_left_radar_obj[4].V_x_Id, 255);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_28 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_EQ(tmp_SurroundFusionSensorInput.V_x_front_left_radar_obj[4].V_x_Id, 255);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_28;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_28.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_left_radar_obj[4].V_m_Dist_X, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_29 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_front_left_radar_obj[4].V_m_Dist_X, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_29;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_29.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_left_radar_obj[4].V_m_Dist_Y, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_30 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_front_left_radar_obj[4].V_m_Dist_Y, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_30;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_30.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_left_radar_obj[4].V_mps_Relspd_X, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_31 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_front_left_radar_obj[4].V_mps_Relspd_X, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_31;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_31.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_left_radar_obj[4].V_mps_Relspd_Y, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_32 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_front_left_radar_obj[4].V_mps_Relspd_Y, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_32;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_32.verify();

    EXPECT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_left_radar_obj[4].V_x_RelPos_Frspc, 255);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_33 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_EQ(tmp_SurroundFusionSensorInput.V_x_front_left_radar_obj[4].V_x_RelPos_Frspc, 255);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_33;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_33.verify();

    EXPECT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_left_radar_obj[4].V_x_MtnClass, 255);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_34 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_EQ(tmp_SurroundFusionSensorInput.V_x_front_left_radar_obj[4].V_x_MtnClass, 255);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_34;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_34.verify();

    EXPECT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_left_radar_obj[5].V_x_Id, 255);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_35 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_EQ(tmp_SurroundFusionSensorInput.V_x_front_left_radar_obj[5].V_x_Id, 255);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_35;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_35.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_left_radar_obj[5].V_m_Dist_X, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_36 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_front_left_radar_obj[5].V_m_Dist_X, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_36;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_36.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_left_radar_obj[5].V_m_Dist_Y, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_37 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_front_left_radar_obj[5].V_m_Dist_Y, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_37;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_37.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_left_radar_obj[5].V_mps_Relspd_X, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_38 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_front_left_radar_obj[5].V_mps_Relspd_X, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_38;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_38.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_left_radar_obj[5].V_mps_Relspd_Y, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_39 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_front_left_radar_obj[5].V_mps_Relspd_Y, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_39;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_39.verify();

    EXPECT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_left_radar_obj[5].V_x_RelPos_Frspc, 255);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_40 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_EQ(tmp_SurroundFusionSensorInput.V_x_front_left_radar_obj[5].V_x_RelPos_Frspc, 255);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_40;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_40.verify();

    EXPECT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_left_radar_obj[5].V_x_MtnClass, 255);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_41 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_EQ(tmp_SurroundFusionSensorInput.V_x_front_left_radar_obj[5].V_x_MtnClass, 255);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_41;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_41.verify();

    EXPECT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_right_radar_obj[0].V_x_Id, 255);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_42 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_EQ(tmp_SurroundFusionSensorInput.V_x_front_right_radar_obj[0].V_x_Id, 255);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_42;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_42.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_right_radar_obj[0].V_m_Dist_X, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_43 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_front_right_radar_obj[0].V_m_Dist_X, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_43;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_43.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_right_radar_obj[0].V_m_Dist_Y, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_44 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_front_right_radar_obj[0].V_m_Dist_Y, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_44;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_44.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_right_radar_obj[0].V_mps_Relspd_X, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_45 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_front_right_radar_obj[0].V_mps_Relspd_X, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_45;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_45.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_right_radar_obj[0].V_mps_Relspd_Y, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_46 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_front_right_radar_obj[0].V_mps_Relspd_Y, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_46;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_46.verify();

    EXPECT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_right_radar_obj[0].V_x_RelPos_Frspc, 255);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_47 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_EQ(tmp_SurroundFusionSensorInput.V_x_front_right_radar_obj[0].V_x_RelPos_Frspc, 255);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_47;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_47.verify();

    EXPECT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_right_radar_obj[0].V_x_MtnClass, 255);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_48 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_EQ(tmp_SurroundFusionSensorInput.V_x_front_right_radar_obj[0].V_x_MtnClass, 255);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_48;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_48.verify();

    EXPECT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_right_radar_obj[1].V_x_Id, 255);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_49 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_EQ(tmp_SurroundFusionSensorInput.V_x_front_right_radar_obj[1].V_x_Id, 255);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_49;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_49.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_right_radar_obj[1].V_m_Dist_X, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_50 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_front_right_radar_obj[1].V_m_Dist_X, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_50;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_50.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_right_radar_obj[1].V_m_Dist_Y, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_51 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_front_right_radar_obj[1].V_m_Dist_Y, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_51;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_51.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_right_radar_obj[1].V_mps_Relspd_X, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_52 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_front_right_radar_obj[1].V_mps_Relspd_X, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_52;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_52.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_right_radar_obj[1].V_mps_Relspd_Y, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_53 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_front_right_radar_obj[1].V_mps_Relspd_Y, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_53;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_53.verify();

    EXPECT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_right_radar_obj[1].V_x_RelPos_Frspc, 255);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_54 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_EQ(tmp_SurroundFusionSensorInput.V_x_front_right_radar_obj[1].V_x_RelPos_Frspc, 255);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_54;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_54.verify();

    EXPECT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_right_radar_obj[1].V_x_MtnClass, 255);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_55 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_EQ(tmp_SurroundFusionSensorInput.V_x_front_right_radar_obj[1].V_x_MtnClass, 255);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_55;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_55.verify();

    EXPECT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_right_radar_obj[2].V_x_Id, 255);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_56 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_EQ(tmp_SurroundFusionSensorInput.V_x_front_right_radar_obj[2].V_x_Id, 255);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_56;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_56.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_right_radar_obj[2].V_m_Dist_X, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_57 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_front_right_radar_obj[2].V_m_Dist_X, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_57;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_57.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_right_radar_obj[2].V_m_Dist_Y, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_58 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_front_right_radar_obj[2].V_m_Dist_Y, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_58;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_58.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_right_radar_obj[2].V_mps_Relspd_X, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_59 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_front_right_radar_obj[2].V_mps_Relspd_X, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_59;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_59.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_right_radar_obj[2].V_mps_Relspd_Y, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_60 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_front_right_radar_obj[2].V_mps_Relspd_Y, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_60;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_60.verify();

    EXPECT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_right_radar_obj[2].V_x_RelPos_Frspc, 255);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_61 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_EQ(tmp_SurroundFusionSensorInput.V_x_front_right_radar_obj[2].V_x_RelPos_Frspc, 255);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_61;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_61.verify();

    EXPECT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_right_radar_obj[2].V_x_MtnClass, 255);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_62 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_EQ(tmp_SurroundFusionSensorInput.V_x_front_right_radar_obj[2].V_x_MtnClass, 255);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_62;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_62.verify();

    EXPECT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_right_radar_obj[3].V_x_Id, 255);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_63 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_EQ(tmp_SurroundFusionSensorInput.V_x_front_right_radar_obj[3].V_x_Id, 255);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_63;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_63.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_right_radar_obj[3].V_m_Dist_X, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_64 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_front_right_radar_obj[3].V_m_Dist_X, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_64;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_64.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_right_radar_obj[3].V_m_Dist_Y, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_65 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_front_right_radar_obj[3].V_m_Dist_Y, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_65;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_65.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_right_radar_obj[3].V_mps_Relspd_X, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_66 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_front_right_radar_obj[3].V_mps_Relspd_X, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_66;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_66.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_right_radar_obj[3].V_mps_Relspd_Y, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_67 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_front_right_radar_obj[3].V_mps_Relspd_Y, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_67;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_67.verify();

    EXPECT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_right_radar_obj[3].V_x_RelPos_Frspc, 255);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_68 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_EQ(tmp_SurroundFusionSensorInput.V_x_front_right_radar_obj[3].V_x_RelPos_Frspc, 255);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_68;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_68.verify();

    EXPECT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_right_radar_obj[3].V_x_MtnClass, 255);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_69 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_EQ(tmp_SurroundFusionSensorInput.V_x_front_right_radar_obj[3].V_x_MtnClass, 255);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_69;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_69.verify();

    EXPECT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_right_radar_obj[4].V_x_Id, 255);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_70 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_EQ(tmp_SurroundFusionSensorInput.V_x_front_right_radar_obj[4].V_x_Id, 255);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_70;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_70.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_right_radar_obj[4].V_m_Dist_X, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_71 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_front_right_radar_obj[4].V_m_Dist_X, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_71;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_71.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_right_radar_obj[4].V_m_Dist_Y, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_72 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_front_right_radar_obj[4].V_m_Dist_Y, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_72;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_72.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_right_radar_obj[4].V_mps_Relspd_X, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_73 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_front_right_radar_obj[4].V_mps_Relspd_X, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_73;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_73.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_right_radar_obj[4].V_mps_Relspd_Y, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_74 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_front_right_radar_obj[4].V_mps_Relspd_Y, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_74;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_74.verify();

    EXPECT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_right_radar_obj[4].V_x_RelPos_Frspc, 255);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_75 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_EQ(tmp_SurroundFusionSensorInput.V_x_front_right_radar_obj[4].V_x_RelPos_Frspc, 255);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_75;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_75.verify();

    EXPECT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_right_radar_obj[4].V_x_MtnClass, 255);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_76 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_EQ(tmp_SurroundFusionSensorInput.V_x_front_right_radar_obj[4].V_x_MtnClass, 255);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_76;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_76.verify();

    EXPECT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_right_radar_obj[5].V_x_Id, 255);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_77 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_EQ(tmp_SurroundFusionSensorInput.V_x_front_right_radar_obj[5].V_x_Id, 255);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_77;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_77.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_right_radar_obj[5].V_m_Dist_X, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_78 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_front_right_radar_obj[5].V_m_Dist_X, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_78;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_78.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_right_radar_obj[5].V_m_Dist_Y, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_79 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_front_right_radar_obj[5].V_m_Dist_Y, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_79;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_79.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_right_radar_obj[5].V_mps_Relspd_X, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_80 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_front_right_radar_obj[5].V_mps_Relspd_X, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_80;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_80.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_right_radar_obj[5].V_mps_Relspd_Y, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_81 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_front_right_radar_obj[5].V_mps_Relspd_Y, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_81;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_81.verify();

    EXPECT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_right_radar_obj[5].V_x_RelPos_Frspc, 255);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_82 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_EQ(tmp_SurroundFusionSensorInput.V_x_front_right_radar_obj[5].V_x_RelPos_Frspc, 255);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_82;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_82.verify();

    EXPECT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_right_radar_obj[5].V_x_MtnClass, 255);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_83 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_EQ(tmp_SurroundFusionSensorInput.V_x_front_right_radar_obj[5].V_x_MtnClass, 255);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_83;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_83.verify();

    EXPECT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_rear_left_radar_obj[0].V_x_Id, 255);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_84 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_EQ(tmp_SurroundFusionSensorInput.V_x_rear_left_radar_obj[0].V_x_Id, 255);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_84;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_84.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_rear_left_radar_obj[0].V_m_Dist_X, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_85 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_rear_left_radar_obj[0].V_m_Dist_X, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_85;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_85.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_rear_left_radar_obj[0].V_m_Dist_Y, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_86 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_rear_left_radar_obj[0].V_m_Dist_Y, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_86;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_86.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_rear_left_radar_obj[0].V_mps_Relspd_X, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_87 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_rear_left_radar_obj[0].V_mps_Relspd_X, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_87;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_87.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_rear_left_radar_obj[0].V_mps_Relspd_Y, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_88 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_rear_left_radar_obj[0].V_mps_Relspd_Y, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_88;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_88.verify();

    EXPECT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_rear_left_radar_obj[0].V_x_RelPos_RdBrdr, 255);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_89 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_EQ(tmp_SurroundFusionSensorInput.V_x_rear_left_radar_obj[0].V_x_RelPos_RdBrdr, 255);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_89;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_89.verify();

    EXPECT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_rear_left_radar_obj[0].V_x_MtnClass, 255);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_90 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_EQ(tmp_SurroundFusionSensorInput.V_x_rear_left_radar_obj[0].V_x_MtnClass, 255);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_90;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_90.verify();

    EXPECT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_rear_left_radar_obj[1].V_x_Id, 255);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_91 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_EQ(tmp_SurroundFusionSensorInput.V_x_rear_left_radar_obj[1].V_x_Id, 255);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_91;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_91.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_rear_left_radar_obj[1].V_m_Dist_X, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_92 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_rear_left_radar_obj[1].V_m_Dist_X, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_92;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_92.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_rear_left_radar_obj[1].V_m_Dist_Y, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_93 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_rear_left_radar_obj[1].V_m_Dist_Y, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_93;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_93.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_rear_left_radar_obj[1].V_mps_Relspd_X, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_94 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_rear_left_radar_obj[1].V_mps_Relspd_X, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_94;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_94.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_rear_left_radar_obj[1].V_mps_Relspd_Y, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_95 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_rear_left_radar_obj[1].V_mps_Relspd_Y, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_95;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_95.verify();

    EXPECT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_rear_left_radar_obj[1].V_x_RelPos_RdBrdr, 255);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_96 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_EQ(tmp_SurroundFusionSensorInput.V_x_rear_left_radar_obj[1].V_x_RelPos_RdBrdr, 255);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_96;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_96.verify();

    EXPECT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_rear_left_radar_obj[1].V_x_MtnClass, 255);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_97 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_EQ(tmp_SurroundFusionSensorInput.V_x_rear_left_radar_obj[1].V_x_MtnClass, 255);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_97;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_97.verify();

    EXPECT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_rear_left_radar_obj[2].V_x_Id, 255);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_98 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_EQ(tmp_SurroundFusionSensorInput.V_x_rear_left_radar_obj[2].V_x_Id, 255);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_98;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_98.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_rear_left_radar_obj[2].V_m_Dist_X, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_99 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_rear_left_radar_obj[2].V_m_Dist_X, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_99;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_99.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_rear_left_radar_obj[2].V_m_Dist_Y, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_100 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_rear_left_radar_obj[2].V_m_Dist_Y, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_100;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_100.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_rear_left_radar_obj[2].V_mps_Relspd_X, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_101 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_rear_left_radar_obj[2].V_mps_Relspd_X, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_101;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_101.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_rear_left_radar_obj[2].V_mps_Relspd_Y, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_102 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_rear_left_radar_obj[2].V_mps_Relspd_Y, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_102;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_102.verify();

    EXPECT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_rear_left_radar_obj[2].V_x_RelPos_RdBrdr, 255);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_103 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_EQ(tmp_SurroundFusionSensorInput.V_x_rear_left_radar_obj[2].V_x_RelPos_RdBrdr, 255);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_103;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_103.verify();

    EXPECT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_rear_left_radar_obj[2].V_x_MtnClass, 255);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_104 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_EQ(tmp_SurroundFusionSensorInput.V_x_rear_left_radar_obj[2].V_x_MtnClass, 255);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_104;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_104.verify();

    EXPECT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_rear_left_radar_obj[3].V_x_Id, 255);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_105 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_EQ(tmp_SurroundFusionSensorInput.V_x_rear_left_radar_obj[3].V_x_Id, 255);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_105;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_105.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_rear_left_radar_obj[3].V_m_Dist_X, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_106 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_rear_left_radar_obj[3].V_m_Dist_X, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_106;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_106.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_rear_left_radar_obj[3].V_m_Dist_Y, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_107 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_rear_left_radar_obj[3].V_m_Dist_Y, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_107;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_107.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_rear_left_radar_obj[3].V_mps_Relspd_X, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_108 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_rear_left_radar_obj[3].V_mps_Relspd_X, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_108;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_108.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_rear_left_radar_obj[3].V_mps_Relspd_Y, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_109 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_rear_left_radar_obj[3].V_mps_Relspd_Y, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_109;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_109.verify();

    EXPECT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_rear_left_radar_obj[3].V_x_RelPos_RdBrdr, 255);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_110 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_EQ(tmp_SurroundFusionSensorInput.V_x_rear_left_radar_obj[3].V_x_RelPos_RdBrdr, 255);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_110;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_110.verify();

    EXPECT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_rear_left_radar_obj[3].V_x_MtnClass, 255);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_111 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_EQ(tmp_SurroundFusionSensorInput.V_x_rear_left_radar_obj[3].V_x_MtnClass, 255);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_111;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_111.verify();

    EXPECT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_rear_left_radar_obj[4].V_x_Id, 255);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_112 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_EQ(tmp_SurroundFusionSensorInput.V_x_rear_left_radar_obj[4].V_x_Id, 255);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_112;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_112.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_rear_left_radar_obj[4].V_m_Dist_X, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_113 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_rear_left_radar_obj[4].V_m_Dist_X, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_113;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_113.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_rear_left_radar_obj[4].V_m_Dist_Y, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_114 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_rear_left_radar_obj[4].V_m_Dist_Y, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_114;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_114.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_rear_left_radar_obj[4].V_mps_Relspd_X, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_115 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_rear_left_radar_obj[4].V_mps_Relspd_X, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_115;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_115.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_rear_left_radar_obj[4].V_mps_Relspd_Y, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_116 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_rear_left_radar_obj[4].V_mps_Relspd_Y, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_116;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_116.verify();

    EXPECT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_rear_left_radar_obj[4].V_x_RelPos_RdBrdr, 255);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_117 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_EQ(tmp_SurroundFusionSensorInput.V_x_rear_left_radar_obj[4].V_x_RelPos_RdBrdr, 255);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_117;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_117.verify();

    EXPECT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_rear_left_radar_obj[4].V_x_MtnClass, 255);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_118 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_EQ(tmp_SurroundFusionSensorInput.V_x_rear_left_radar_obj[4].V_x_MtnClass, 255);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_118;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_118.verify();

    EXPECT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_rear_left_radar_obj[5].V_x_Id, 255);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_119 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_EQ(tmp_SurroundFusionSensorInput.V_x_rear_left_radar_obj[5].V_x_Id, 255);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_119;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_119.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_rear_left_radar_obj[5].V_m_Dist_X, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_120 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_rear_left_radar_obj[5].V_m_Dist_X, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_120;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_120.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_rear_left_radar_obj[5].V_m_Dist_Y, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_121 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_rear_left_radar_obj[5].V_m_Dist_Y, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_121;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_121.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_rear_left_radar_obj[5].V_mps_Relspd_X, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_122 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_rear_left_radar_obj[5].V_mps_Relspd_X, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_122;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_122.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_rear_left_radar_obj[5].V_mps_Relspd_Y, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_123 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_rear_left_radar_obj[5].V_mps_Relspd_Y, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_123;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_123.verify();

    EXPECT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_rear_left_radar_obj[5].V_x_RelPos_RdBrdr, 255);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_124 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_EQ(tmp_SurroundFusionSensorInput.V_x_rear_left_radar_obj[5].V_x_RelPos_RdBrdr, 255);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_124;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_124.verify();

    EXPECT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_rear_left_radar_obj[5].V_x_MtnClass, 255);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_125 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_EQ(tmp_SurroundFusionSensorInput.V_x_rear_left_radar_obj[5].V_x_MtnClass, 255);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_125;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_125.verify();

    EXPECT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_rear_left_radar_obj[6].V_x_Id, 255);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_126 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_EQ(tmp_SurroundFusionSensorInput.V_x_rear_left_radar_obj[6].V_x_Id, 255);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_126;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_126.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_rear_left_radar_obj[6].V_m_Dist_X, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_127 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_rear_left_radar_obj[6].V_m_Dist_X, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_127;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_127.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_rear_left_radar_obj[6].V_m_Dist_Y, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_128 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_rear_left_radar_obj[6].V_m_Dist_Y, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_128;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_128.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_rear_left_radar_obj[6].V_mps_Relspd_X, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_129 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_rear_left_radar_obj[6].V_mps_Relspd_X, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_129;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_129.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_rear_left_radar_obj[6].V_mps_Relspd_Y, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_130 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_rear_left_radar_obj[6].V_mps_Relspd_Y, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_130;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_130.verify();

    EXPECT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_rear_left_radar_obj[6].V_x_RelPos_RdBrdr, 255);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_131 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_EQ(tmp_SurroundFusionSensorInput.V_x_rear_left_radar_obj[6].V_x_RelPos_RdBrdr, 255);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_131;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_131.verify();

    EXPECT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_rear_left_radar_obj[6].V_x_MtnClass, 255);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_132 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_EQ(tmp_SurroundFusionSensorInput.V_x_rear_left_radar_obj[6].V_x_MtnClass, 255);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_132;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_132.verify();

    EXPECT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_rear_left_radar_obj[7].V_x_Id, 255);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_133 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_EQ(tmp_SurroundFusionSensorInput.V_x_rear_left_radar_obj[7].V_x_Id, 255);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_133;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_133.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_rear_left_radar_obj[7].V_m_Dist_X, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_134 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_rear_left_radar_obj[7].V_m_Dist_X, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_134;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_134.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_rear_left_radar_obj[7].V_m_Dist_Y, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_135 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_rear_left_radar_obj[7].V_m_Dist_Y, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_135;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_135.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_rear_left_radar_obj[7].V_mps_Relspd_X, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_136 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_rear_left_radar_obj[7].V_mps_Relspd_X, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_136;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_136.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_rear_left_radar_obj[7].V_mps_Relspd_Y, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_137 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_rear_left_radar_obj[7].V_mps_Relspd_Y, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_137;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_137.verify();

    EXPECT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_rear_left_radar_obj[7].V_x_RelPos_RdBrdr, 255);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_138 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_EQ(tmp_SurroundFusionSensorInput.V_x_rear_left_radar_obj[7].V_x_RelPos_RdBrdr, 255);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_138;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_138.verify();

    EXPECT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_rear_left_radar_obj[7].V_x_MtnClass, 255);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_139 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_EQ(tmp_SurroundFusionSensorInput.V_x_rear_left_radar_obj[7].V_x_MtnClass, 255);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_139;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_139.verify();

    EXPECT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_rear_right_radar_obj[0].V_x_Id, 255);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_140 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_EQ(tmp_SurroundFusionSensorInput.V_x_rear_right_radar_obj[0].V_x_Id, 255);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_140;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_140.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_rear_right_radar_obj[0].V_m_Dist_X, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_141 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_rear_right_radar_obj[0].V_m_Dist_X, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_141;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_141.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_rear_right_radar_obj[0].V_m_Dist_Y, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_142 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_rear_right_radar_obj[0].V_m_Dist_Y, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_142;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_142.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_rear_right_radar_obj[0].V_mps_Relspd_X, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_143 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_rear_right_radar_obj[0].V_mps_Relspd_X, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_143;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_143.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_rear_right_radar_obj[0].V_mps_Relspd_Y, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_144 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_rear_right_radar_obj[0].V_mps_Relspd_Y, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_144;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_144.verify();

    EXPECT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_rear_right_radar_obj[0].V_x_RelPos_RdBrdr, 255);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_145 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_EQ(tmp_SurroundFusionSensorInput.V_x_rear_right_radar_obj[0].V_x_RelPos_RdBrdr, 255);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_145;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_145.verify();

    EXPECT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_rear_right_radar_obj[0].V_x_MtnClass, 255);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_146 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_EQ(tmp_SurroundFusionSensorInput.V_x_rear_right_radar_obj[0].V_x_MtnClass, 255);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_146;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_146.verify();

    EXPECT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_rear_right_radar_obj[1].V_x_Id, 255);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_147 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_EQ(tmp_SurroundFusionSensorInput.V_x_rear_right_radar_obj[1].V_x_Id, 255);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_147;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_147.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_rear_right_radar_obj[1].V_m_Dist_X, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_148 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_rear_right_radar_obj[1].V_m_Dist_X, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_148;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_148.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_rear_right_radar_obj[1].V_m_Dist_Y, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_149 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_rear_right_radar_obj[1].V_m_Dist_Y, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_149;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_149.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_rear_right_radar_obj[1].V_mps_Relspd_X, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_150 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_rear_right_radar_obj[1].V_mps_Relspd_X, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_150;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_150.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_rear_right_radar_obj[1].V_mps_Relspd_Y, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_151 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_rear_right_radar_obj[1].V_mps_Relspd_Y, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_151;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_151.verify();

    EXPECT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_rear_right_radar_obj[1].V_x_RelPos_RdBrdr, 255);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_152 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_EQ(tmp_SurroundFusionSensorInput.V_x_rear_right_radar_obj[1].V_x_RelPos_RdBrdr, 255);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_152;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_152.verify();

    EXPECT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_rear_right_radar_obj[1].V_x_MtnClass, 255);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_153 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_EQ(tmp_SurroundFusionSensorInput.V_x_rear_right_radar_obj[1].V_x_MtnClass, 255);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_153;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_153.verify();

    EXPECT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_rear_right_radar_obj[2].V_x_Id, 255);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_154 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_EQ(tmp_SurroundFusionSensorInput.V_x_rear_right_radar_obj[2].V_x_Id, 255);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_154;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_154.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_rear_right_radar_obj[2].V_m_Dist_X, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_155 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_rear_right_radar_obj[2].V_m_Dist_X, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_155;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_155.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_rear_right_radar_obj[2].V_m_Dist_Y, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_156 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_rear_right_radar_obj[2].V_m_Dist_Y, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_156;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_156.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_rear_right_radar_obj[2].V_mps_Relspd_X, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_157 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_rear_right_radar_obj[2].V_mps_Relspd_X, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_157;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_157.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_rear_right_radar_obj[2].V_mps_Relspd_Y, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_158 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_rear_right_radar_obj[2].V_mps_Relspd_Y, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_158;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_158.verify();

    EXPECT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_rear_right_radar_obj[2].V_x_RelPos_RdBrdr, 255);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_159 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_EQ(tmp_SurroundFusionSensorInput.V_x_rear_right_radar_obj[2].V_x_RelPos_RdBrdr, 255);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_159;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_159.verify();

    EXPECT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_rear_right_radar_obj[2].V_x_MtnClass, 255);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_160 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_EQ(tmp_SurroundFusionSensorInput.V_x_rear_right_radar_obj[2].V_x_MtnClass, 255);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_160;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_160.verify();

    EXPECT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_rear_right_radar_obj[3].V_x_Id, 255);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_161 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_EQ(tmp_SurroundFusionSensorInput.V_x_rear_right_radar_obj[3].V_x_Id, 255);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_161;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_161.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_rear_right_radar_obj[3].V_m_Dist_X, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_162 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_rear_right_radar_obj[3].V_m_Dist_X, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_162;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_162.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_rear_right_radar_obj[3].V_m_Dist_Y, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_163 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_rear_right_radar_obj[3].V_m_Dist_Y, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_163;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_163.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_rear_right_radar_obj[3].V_mps_Relspd_X, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_164 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_rear_right_radar_obj[3].V_mps_Relspd_X, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_164;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_164.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_rear_right_radar_obj[3].V_mps_Relspd_Y, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_165 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_rear_right_radar_obj[3].V_mps_Relspd_Y, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_165;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_165.verify();

    EXPECT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_rear_right_radar_obj[3].V_x_RelPos_RdBrdr, 255);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_166 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_EQ(tmp_SurroundFusionSensorInput.V_x_rear_right_radar_obj[3].V_x_RelPos_RdBrdr, 255);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_166;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_166.verify();

    EXPECT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_rear_right_radar_obj[3].V_x_MtnClass, 255);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_167 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_EQ(tmp_SurroundFusionSensorInput.V_x_rear_right_radar_obj[3].V_x_MtnClass, 255);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_167;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_167.verify();

    EXPECT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_rear_right_radar_obj[4].V_x_Id, 255);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_168 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_EQ(tmp_SurroundFusionSensorInput.V_x_rear_right_radar_obj[4].V_x_Id, 255);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_168;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_168.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_rear_right_radar_obj[4].V_m_Dist_X, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_169 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_rear_right_radar_obj[4].V_m_Dist_X, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_169;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_169.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_rear_right_radar_obj[4].V_m_Dist_Y, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_170 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_rear_right_radar_obj[4].V_m_Dist_Y, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_170;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_170.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_rear_right_radar_obj[4].V_mps_Relspd_X, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_171 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_rear_right_radar_obj[4].V_mps_Relspd_X, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_171;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_171.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_rear_right_radar_obj[4].V_mps_Relspd_Y, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_172 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_rear_right_radar_obj[4].V_mps_Relspd_Y, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_172;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_172.verify();

    EXPECT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_rear_right_radar_obj[4].V_x_RelPos_RdBrdr, 255);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_173 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_EQ(tmp_SurroundFusionSensorInput.V_x_rear_right_radar_obj[4].V_x_RelPos_RdBrdr, 255);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_173;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_173.verify();

    EXPECT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_rear_right_radar_obj[4].V_x_MtnClass, 255);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_174 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_EQ(tmp_SurroundFusionSensorInput.V_x_rear_right_radar_obj[4].V_x_MtnClass, 255);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_174;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_174.verify();

    EXPECT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_rear_right_radar_obj[5].V_x_Id, 255);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_175 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_EQ(tmp_SurroundFusionSensorInput.V_x_rear_right_radar_obj[5].V_x_Id, 255);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_175;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_175.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_rear_right_radar_obj[5].V_m_Dist_X, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_176 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_rear_right_radar_obj[5].V_m_Dist_X, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_176;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_176.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_rear_right_radar_obj[5].V_m_Dist_Y, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_177 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_rear_right_radar_obj[5].V_m_Dist_Y, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_177;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_177.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_rear_right_radar_obj[5].V_mps_Relspd_X, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_178 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_rear_right_radar_obj[5].V_mps_Relspd_X, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_178;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_178.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_rear_right_radar_obj[5].V_mps_Relspd_Y, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_179 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_rear_right_radar_obj[5].V_mps_Relspd_Y, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_179;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_179.verify();

    EXPECT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_rear_right_radar_obj[5].V_x_RelPos_RdBrdr, 255);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_180 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_EQ(tmp_SurroundFusionSensorInput.V_x_rear_right_radar_obj[5].V_x_RelPos_RdBrdr, 255);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_180;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_180.verify();

    EXPECT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_rear_right_radar_obj[5].V_x_MtnClass, 255);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_181 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_EQ(tmp_SurroundFusionSensorInput.V_x_rear_right_radar_obj[5].V_x_MtnClass, 255);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_181;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_181.verify();

    EXPECT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_rear_right_radar_obj[6].V_x_Id, 255);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_182 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_EQ(tmp_SurroundFusionSensorInput.V_x_rear_right_radar_obj[6].V_x_Id, 255);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_182;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_182.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_rear_right_radar_obj[6].V_m_Dist_X, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_183 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_rear_right_radar_obj[6].V_m_Dist_X, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_183;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_183.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_rear_right_radar_obj[6].V_m_Dist_Y, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_184 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_rear_right_radar_obj[6].V_m_Dist_Y, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_184;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_184.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_rear_right_radar_obj[6].V_mps_Relspd_X, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_185 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_rear_right_radar_obj[6].V_mps_Relspd_X, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_185;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_185.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_rear_right_radar_obj[6].V_mps_Relspd_Y, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_186 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_rear_right_radar_obj[6].V_mps_Relspd_Y, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_186;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_186.verify();

    EXPECT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_rear_right_radar_obj[6].V_x_RelPos_RdBrdr, 255);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_187 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_EQ(tmp_SurroundFusionSensorInput.V_x_rear_right_radar_obj[6].V_x_RelPos_RdBrdr, 255);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_187;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_187.verify();

    EXPECT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_rear_right_radar_obj[6].V_x_MtnClass, 255);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_188 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_EQ(tmp_SurroundFusionSensorInput.V_x_rear_right_radar_obj[6].V_x_MtnClass, 255);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_188;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_188.verify();

    EXPECT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_rear_right_radar_obj[7].V_x_Id, 255);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_189 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_EQ(tmp_SurroundFusionSensorInput.V_x_rear_right_radar_obj[7].V_x_Id, 255);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_189;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_189.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_rear_right_radar_obj[7].V_m_Dist_X, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_190 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_rear_right_radar_obj[7].V_m_Dist_X, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_190;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_190.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_rear_right_radar_obj[7].V_m_Dist_Y, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_191 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_rear_right_radar_obj[7].V_m_Dist_Y, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_191;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_191.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_rear_right_radar_obj[7].V_mps_Relspd_X, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_192 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_rear_right_radar_obj[7].V_mps_Relspd_X, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_192;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_192.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_rear_right_radar_obj[7].V_mps_Relspd_Y, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_193 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_rear_right_radar_obj[7].V_mps_Relspd_Y, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_193;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_193.verify();

    EXPECT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_rear_right_radar_obj[7].V_x_RelPos_RdBrdr, 255);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_194 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_EQ(tmp_SurroundFusionSensorInput.V_x_rear_right_radar_obj[7].V_x_RelPos_RdBrdr, 255);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_194;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_194.verify();

    EXPECT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_rear_right_radar_obj[7].V_x_MtnClass, 255);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_195 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_EQ(tmp_SurroundFusionSensorInput.V_x_rear_right_radar_obj[7].V_x_MtnClass, 255);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_195;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_195.verify();

    EXPECT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_obj[0].llTimeStamp, 4294967295);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_196 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_obj[0].llTimeStamp, 4294967295);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_196;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_196.verify();

    EXPECT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_obj[0].V_x_ObjectID, 255);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_197 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_obj[0].V_x_ObjectID, 255);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_197;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_197.verify();

    EXPECT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_obj[0].F_x_CIPV, 255);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_198 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_obj[0].F_x_CIPV, 255);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_198;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_198.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_obj[0].V_x_ObjectLength, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_199 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_obj[0].V_x_ObjectLength, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_199;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_199.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_obj[0].V_m_ObjectWidth, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_200 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_obj[0].V_m_ObjectWidth, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_200;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_200.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_obj[0].V_m_ObjectPosX, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_201 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_obj[0].V_m_ObjectPosX, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_201;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_201.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_obj[0].V_m_ObjectPosY, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_202 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_obj[0].V_m_ObjectPosY, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_202;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_202.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_obj[0].V_mps_ObjectVelX, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_203 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_obj[0].V_mps_ObjectVelX, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_203;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_203.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_obj[0].V_mps_ObjectVelY, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_204 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_obj[0].V_mps_ObjectVelY, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_204;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_204.verify();

    EXPECT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_obj[0].V_x_ObjectType, 255);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_205 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_obj[0].V_x_ObjectType, 255);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_205;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_205.verify();

    EXPECT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_obj[0].V_x_ObjectStatus, 255);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_206 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_obj[0].V_x_ObjectStatus, 255);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_206;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_206.verify();

    EXPECT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_obj[0].V_x_ObjectValid, 255);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_207 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_obj[0].V_x_ObjectValid, 255);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_207;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_207.verify();

    EXPECT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_obj[0].V_x_ObjectLane, 255);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_208 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_obj[0].V_x_ObjectLane, 255);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_208;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_208.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_obj[0].V_s_TTC, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_209 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_obj[0].V_s_TTC, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_209;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_209.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_obj[0].V_mps2_ObjectAccelX, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_210 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_obj[0].V_mps2_ObjectAccelX, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_210;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_210.verify();

    EXPECT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_obj[0].V_x_BlinkInfo, 255);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_211 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_obj[0].V_x_BlinkInfo, 255);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_211;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_211.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_obj[0].V_degps_ObjectAngleRate, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_212 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_obj[0].V_degps_ObjectAngleRate, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_212;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_212.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_obj[0].V_deg_ObjectAngle, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_213 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_obj[0].V_deg_ObjectAngle, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_213;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_213.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_obj[0].V_mps_ObejectRelVelocity, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_214 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_obj[0].V_mps_ObejectRelVelocity, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_214;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_214.verify();

    EXPECT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_obj[1].llTimeStamp, 4294967295);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_215 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_obj[1].llTimeStamp, 4294967295);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_215;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_215.verify();

    EXPECT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_obj[1].V_x_ObjectID, 255);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_216 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_obj[1].V_x_ObjectID, 255);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_216;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_216.verify();

    EXPECT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_obj[1].F_x_CIPV, 255);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_217 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_obj[1].F_x_CIPV, 255);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_217;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_217.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_obj[1].V_x_ObjectLength, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_218 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_obj[1].V_x_ObjectLength, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_218;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_218.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_obj[1].V_m_ObjectWidth, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_219 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_obj[1].V_m_ObjectWidth, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_219;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_219.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_obj[1].V_m_ObjectPosX, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_220 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_obj[1].V_m_ObjectPosX, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_220;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_220.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_obj[1].V_m_ObjectPosY, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_221 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_obj[1].V_m_ObjectPosY, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_221;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_221.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_obj[1].V_mps_ObjectVelX, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_222 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_obj[1].V_mps_ObjectVelX, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_222;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_222.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_obj[1].V_mps_ObjectVelY, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_223 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_obj[1].V_mps_ObjectVelY, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_223;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_223.verify();

    EXPECT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_obj[1].V_x_ObjectType, 255);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_224 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_obj[1].V_x_ObjectType, 255);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_224;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_224.verify();

    EXPECT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_obj[1].V_x_ObjectStatus, 255);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_225 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_obj[1].V_x_ObjectStatus, 255);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_225;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_225.verify();

    EXPECT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_obj[1].V_x_ObjectValid, 255);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_226 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_obj[1].V_x_ObjectValid, 255);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_226;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_226.verify();

    EXPECT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_obj[1].V_x_ObjectLane, 255);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_227 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_obj[1].V_x_ObjectLane, 255);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_227;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_227.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_obj[1].V_s_TTC, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_228 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_obj[1].V_s_TTC, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_228;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_228.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_obj[1].V_mps2_ObjectAccelX, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_229 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_obj[1].V_mps2_ObjectAccelX, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_229;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_229.verify();

    EXPECT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_obj[1].V_x_BlinkInfo, 255);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_230 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_obj[1].V_x_BlinkInfo, 255);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_230;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_230.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_obj[1].V_degps_ObjectAngleRate, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_231 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_obj[1].V_degps_ObjectAngleRate, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_231;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_231.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_obj[1].V_deg_ObjectAngle, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_232 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_obj[1].V_deg_ObjectAngle, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_232;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_232.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_obj[1].V_mps_ObejectRelVelocity, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_233 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_obj[1].V_mps_ObejectRelVelocity, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_233;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_233.verify();

    EXPECT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_obj[2].llTimeStamp, 4294967295);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_234 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_obj[2].llTimeStamp, 4294967295);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_234;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_234.verify();

    EXPECT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_obj[2].V_x_ObjectID, 255);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_235 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_obj[2].V_x_ObjectID, 255);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_235;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_235.verify();

    EXPECT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_obj[2].F_x_CIPV, 255);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_236 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_obj[2].F_x_CIPV, 255);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_236;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_236.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_obj[2].V_x_ObjectLength, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_237 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_obj[2].V_x_ObjectLength, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_237;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_237.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_obj[2].V_m_ObjectWidth, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_238 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_obj[2].V_m_ObjectWidth, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_238;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_238.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_obj[2].V_m_ObjectPosX, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_239 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_obj[2].V_m_ObjectPosX, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_239;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_239.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_obj[2].V_m_ObjectPosY, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_240 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_obj[2].V_m_ObjectPosY, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_240;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_240.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_obj[2].V_mps_ObjectVelX, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_241 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_obj[2].V_mps_ObjectVelX, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_241;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_241.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_obj[2].V_mps_ObjectVelY, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_242 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_obj[2].V_mps_ObjectVelY, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_242;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_242.verify();

    EXPECT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_obj[2].V_x_ObjectType, 255);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_243 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_obj[2].V_x_ObjectType, 255);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_243;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_243.verify();

    EXPECT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_obj[2].V_x_ObjectStatus, 255);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_244 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_obj[2].V_x_ObjectStatus, 255);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_244;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_244.verify();

    EXPECT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_obj[2].V_x_ObjectValid, 255);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_245 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_obj[2].V_x_ObjectValid, 255);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_245;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_245.verify();

    EXPECT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_obj[2].V_x_ObjectLane, 255);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_246 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_obj[2].V_x_ObjectLane, 255);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_246;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_246.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_obj[2].V_s_TTC, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_247 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_obj[2].V_s_TTC, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_247;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_247.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_obj[2].V_mps2_ObjectAccelX, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_248 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_obj[2].V_mps2_ObjectAccelX, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_248;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_248.verify();

    EXPECT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_obj[2].V_x_BlinkInfo, 255);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_249 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_obj[2].V_x_BlinkInfo, 255);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_249;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_249.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_obj[2].V_degps_ObjectAngleRate, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_250 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_obj[2].V_degps_ObjectAngleRate, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_250;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_250.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_obj[2].V_deg_ObjectAngle, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_251 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_obj[2].V_deg_ObjectAngle, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_251;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_251.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_obj[2].V_mps_ObejectRelVelocity, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_252 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_obj[2].V_mps_ObejectRelVelocity, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_252;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_252.verify();

    EXPECT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_obj[3].llTimeStamp, 4294967295);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_253 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_obj[3].llTimeStamp, 4294967295);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_253;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_253.verify();

    EXPECT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_obj[3].V_x_ObjectID, 255);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_254 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_obj[3].V_x_ObjectID, 255);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_254;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_254.verify();

    EXPECT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_obj[3].F_x_CIPV, 255);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_255 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_obj[3].F_x_CIPV, 255);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_255;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_255.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_obj[3].V_x_ObjectLength, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_256 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_obj[3].V_x_ObjectLength, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_256;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_256.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_obj[3].V_m_ObjectWidth, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_257 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_obj[3].V_m_ObjectWidth, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_257;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_257.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_obj[3].V_m_ObjectPosX, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_258 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_obj[3].V_m_ObjectPosX, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_258;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_258.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_obj[3].V_m_ObjectPosY, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_259 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_obj[3].V_m_ObjectPosY, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_259;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_259.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_obj[3].V_mps_ObjectVelX, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_260 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_obj[3].V_mps_ObjectVelX, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_260;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_260.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_obj[3].V_mps_ObjectVelY, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_261 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_obj[3].V_mps_ObjectVelY, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_261;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_261.verify();

    EXPECT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_obj[3].V_x_ObjectType, 255);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_262 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_obj[3].V_x_ObjectType, 255);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_262;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_262.verify();

    EXPECT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_obj[3].V_x_ObjectStatus, 255);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_263 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_obj[3].V_x_ObjectStatus, 255);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_263;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_263.verify();

    EXPECT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_obj[3].V_x_ObjectValid, 255);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_264 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_obj[3].V_x_ObjectValid, 255);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_264;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_264.verify();

    EXPECT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_obj[3].V_x_ObjectLane, 255);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_265 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_obj[3].V_x_ObjectLane, 255);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_265;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_265.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_obj[3].V_s_TTC, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_266 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_obj[3].V_s_TTC, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_266;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_266.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_obj[3].V_mps2_ObjectAccelX, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_267 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_obj[3].V_mps2_ObjectAccelX, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_267;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_267.verify();

    EXPECT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_obj[3].V_x_BlinkInfo, 255);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_268 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_obj[3].V_x_BlinkInfo, 255);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_268;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_268.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_obj[3].V_degps_ObjectAngleRate, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_269 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_obj[3].V_degps_ObjectAngleRate, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_269;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_269.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_obj[3].V_deg_ObjectAngle, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_270 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_obj[3].V_deg_ObjectAngle, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_270;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_270.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_obj[3].V_mps_ObejectRelVelocity, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_271 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_obj[3].V_mps_ObejectRelVelocity, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_271;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_271.verify();

    EXPECT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_obj[4].llTimeStamp, 4294967295);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_272 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_obj[4].llTimeStamp, 4294967295);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_272;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_272.verify();

    EXPECT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_obj[4].V_x_ObjectID, 255);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_273 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_obj[4].V_x_ObjectID, 255);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_273;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_273.verify();

    EXPECT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_obj[4].F_x_CIPV, 255);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_274 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_obj[4].F_x_CIPV, 255);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_274;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_274.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_obj[4].V_x_ObjectLength, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_275 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_obj[4].V_x_ObjectLength, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_275;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_275.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_obj[4].V_m_ObjectWidth, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_276 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_obj[4].V_m_ObjectWidth, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_276;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_276.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_obj[4].V_m_ObjectPosX, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_277 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_obj[4].V_m_ObjectPosX, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_277;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_277.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_obj[4].V_m_ObjectPosY, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_278 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_obj[4].V_m_ObjectPosY, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_278;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_278.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_obj[4].V_mps_ObjectVelX, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_279 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_obj[4].V_mps_ObjectVelX, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_279;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_279.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_obj[4].V_mps_ObjectVelY, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_280 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_obj[4].V_mps_ObjectVelY, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_280;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_280.verify();

    EXPECT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_obj[4].V_x_ObjectType, 255);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_281 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_obj[4].V_x_ObjectType, 255);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_281;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_281.verify();

    EXPECT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_obj[4].V_x_ObjectStatus, 255);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_282 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_obj[4].V_x_ObjectStatus, 255);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_282;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_282.verify();

    EXPECT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_obj[4].V_x_ObjectValid, 255);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_283 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_obj[4].V_x_ObjectValid, 255);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_283;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_283.verify();

    EXPECT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_obj[4].V_x_ObjectLane, 255);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_284 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_obj[4].V_x_ObjectLane, 255);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_284;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_284.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_obj[4].V_s_TTC, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_285 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_obj[4].V_s_TTC, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_285;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_285.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_obj[4].V_mps2_ObjectAccelX, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_286 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_obj[4].V_mps2_ObjectAccelX, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_286;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_286.verify();

    EXPECT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_obj[4].V_x_BlinkInfo, 255);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_287 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_obj[4].V_x_BlinkInfo, 255);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_287;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_287.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_obj[4].V_degps_ObjectAngleRate, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_288 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_obj[4].V_degps_ObjectAngleRate, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_288;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_288.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_obj[4].V_deg_ObjectAngle, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_289 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_obj[4].V_deg_ObjectAngle, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_289;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_289.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_obj[4].V_mps_ObejectRelVelocity, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_290 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_obj[4].V_mps_ObejectRelVelocity, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_290;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_290.verify();

    EXPECT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_obj[5].llTimeStamp, 4294967295);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_291 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_obj[5].llTimeStamp, 4294967295);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_291;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_291.verify();

    EXPECT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_obj[5].V_x_ObjectID, 255);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_292 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_obj[5].V_x_ObjectID, 255);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_292;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_292.verify();

    EXPECT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_obj[5].F_x_CIPV, 255);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_293 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_obj[5].F_x_CIPV, 255);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_293;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_293.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_obj[5].V_x_ObjectLength, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_294 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_obj[5].V_x_ObjectLength, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_294;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_294.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_obj[5].V_m_ObjectWidth, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_295 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_obj[5].V_m_ObjectWidth, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_295;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_295.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_obj[5].V_m_ObjectPosX, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_296 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_obj[5].V_m_ObjectPosX, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_296;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_296.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_obj[5].V_m_ObjectPosY, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_297 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_obj[5].V_m_ObjectPosY, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_297;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_297.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_obj[5].V_mps_ObjectVelX, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_298 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_obj[5].V_mps_ObjectVelX, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_298;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_298.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_obj[5].V_mps_ObjectVelY, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_299 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_obj[5].V_mps_ObjectVelY, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_299;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_299.verify();

    EXPECT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_obj[5].V_x_ObjectType, 255);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_300 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_obj[5].V_x_ObjectType, 255);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_300;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_300.verify();

    EXPECT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_obj[5].V_x_ObjectStatus, 255);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_301 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_obj[5].V_x_ObjectStatus, 255);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_301;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_301.verify();

    EXPECT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_obj[5].V_x_ObjectValid, 255);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_302 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_obj[5].V_x_ObjectValid, 255);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_302;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_302.verify();

    EXPECT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_obj[5].V_x_ObjectLane, 255);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_303 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_obj[5].V_x_ObjectLane, 255);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_303;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_303.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_obj[5].V_s_TTC, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_304 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_obj[5].V_s_TTC, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_304;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_304.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_obj[5].V_mps2_ObjectAccelX, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_305 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_obj[5].V_mps2_ObjectAccelX, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_305;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_305.verify();

    EXPECT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_obj[5].V_x_BlinkInfo, 255);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_306 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_obj[5].V_x_BlinkInfo, 255);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_306;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_306.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_obj[5].V_degps_ObjectAngleRate, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_307 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_obj[5].V_degps_ObjectAngleRate, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_307;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_307.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_obj[5].V_deg_ObjectAngle, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_308 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_obj[5].V_deg_ObjectAngle, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_308;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_308.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_obj[5].V_mps_ObejectRelVelocity, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_309 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_obj[5].V_mps_ObejectRelVelocity, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_309;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_309.verify();

    EXPECT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_obj[6].llTimeStamp, 4294967295);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_310 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_obj[6].llTimeStamp, 4294967295);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_310;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_310.verify();

    EXPECT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_obj[6].V_x_ObjectID, 255);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_311 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_obj[6].V_x_ObjectID, 255);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_311;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_311.verify();

    EXPECT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_obj[6].F_x_CIPV, 255);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_312 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_obj[6].F_x_CIPV, 255);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_312;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_312.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_obj[6].V_x_ObjectLength, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_313 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_obj[6].V_x_ObjectLength, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_313;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_313.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_obj[6].V_m_ObjectWidth, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_314 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_obj[6].V_m_ObjectWidth, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_314;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_314.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_obj[6].V_m_ObjectPosX, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_315 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_obj[6].V_m_ObjectPosX, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_315;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_315.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_obj[6].V_m_ObjectPosY, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_316 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_obj[6].V_m_ObjectPosY, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_316;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_316.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_obj[6].V_mps_ObjectVelX, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_317 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_obj[6].V_mps_ObjectVelX, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_317;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_317.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_obj[6].V_mps_ObjectVelY, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_318 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_obj[6].V_mps_ObjectVelY, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_318;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_318.verify();

    EXPECT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_obj[6].V_x_ObjectType, 255);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_319 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_obj[6].V_x_ObjectType, 255);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_319;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_319.verify();

    EXPECT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_obj[6].V_x_ObjectStatus, 255);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_320 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_obj[6].V_x_ObjectStatus, 255);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_320;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_320.verify();

    EXPECT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_obj[6].V_x_ObjectValid, 255);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_321 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_obj[6].V_x_ObjectValid, 255);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_321;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_321.verify();

    EXPECT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_obj[6].V_x_ObjectLane, 255);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_322 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_obj[6].V_x_ObjectLane, 255);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_322;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_322.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_obj[6].V_s_TTC, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_323 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_obj[6].V_s_TTC, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_323;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_323.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_obj[6].V_mps2_ObjectAccelX, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_324 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_obj[6].V_mps2_ObjectAccelX, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_324;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_324.verify();

    EXPECT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_obj[6].V_x_BlinkInfo, 255);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_325 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_obj[6].V_x_BlinkInfo, 255);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_325;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_325.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_obj[6].V_degps_ObjectAngleRate, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_326 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_obj[6].V_degps_ObjectAngleRate, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_326;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_326.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_obj[6].V_deg_ObjectAngle, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_327 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_obj[6].V_deg_ObjectAngle, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_327;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_327.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_obj[6].V_mps_ObejectRelVelocity, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_328 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_obj[6].V_mps_ObejectRelVelocity, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_328;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_328.verify();

    EXPECT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_obj[7].llTimeStamp, 4294967295);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_329 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_obj[7].llTimeStamp, 4294967295);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_329;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_329.verify();

    EXPECT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_obj[7].V_x_ObjectID, 255);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_330 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_obj[7].V_x_ObjectID, 255);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_330;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_330.verify();

    EXPECT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_obj[7].F_x_CIPV, 255);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_331 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_obj[7].F_x_CIPV, 255);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_331;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_331.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_obj[7].V_x_ObjectLength, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_332 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_obj[7].V_x_ObjectLength, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_332;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_332.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_obj[7].V_m_ObjectWidth, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_333 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_obj[7].V_m_ObjectWidth, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_333;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_333.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_obj[7].V_m_ObjectPosX, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_334 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_obj[7].V_m_ObjectPosX, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_334;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_334.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_obj[7].V_m_ObjectPosY, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_335 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_obj[7].V_m_ObjectPosY, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_335;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_335.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_obj[7].V_mps_ObjectVelX, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_336 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_obj[7].V_mps_ObjectVelX, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_336;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_336.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_obj[7].V_mps_ObjectVelY, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_337 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_obj[7].V_mps_ObjectVelY, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_337;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_337.verify();

    EXPECT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_obj[7].V_x_ObjectType, 255);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_338 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_obj[7].V_x_ObjectType, 255);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_338;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_338.verify();

    EXPECT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_obj[7].V_x_ObjectStatus, 255);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_339 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_obj[7].V_x_ObjectStatus, 255);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_339;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_339.verify();

    EXPECT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_obj[7].V_x_ObjectValid, 255);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_340 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_obj[7].V_x_ObjectValid, 255);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_340;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_340.verify();

    EXPECT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_obj[7].V_x_ObjectLane, 255);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_341 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_obj[7].V_x_ObjectLane, 255);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_341;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_341.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_obj[7].V_s_TTC, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_342 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_obj[7].V_s_TTC, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_342;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_342.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_obj[7].V_mps2_ObjectAccelX, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_343 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_obj[7].V_mps2_ObjectAccelX, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_343;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_343.verify();

    EXPECT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_obj[7].V_x_BlinkInfo, 255);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_344 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_obj[7].V_x_BlinkInfo, 255);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_344;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_344.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_obj[7].V_degps_ObjectAngleRate, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_345 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_obj[7].V_degps_ObjectAngleRate, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_345;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_345.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_obj[7].V_deg_ObjectAngle, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_346 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_obj[7].V_deg_ObjectAngle, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_346;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_346.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_obj[7].V_mps_ObejectRelVelocity, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_347 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_obj[7].V_mps_ObejectRelVelocity, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_347;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_347.verify();

    EXPECT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_obj[8].llTimeStamp, 4294967295);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_348 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_obj[8].llTimeStamp, 4294967295);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_348;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_348.verify();

    EXPECT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_obj[8].V_x_ObjectID, 255);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_349 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_obj[8].V_x_ObjectID, 255);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_349;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_349.verify();

    EXPECT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_obj[8].F_x_CIPV, 255);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_350 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_obj[8].F_x_CIPV, 255);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_350;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_350.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_obj[8].V_x_ObjectLength, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_351 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_obj[8].V_x_ObjectLength, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_351;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_351.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_obj[8].V_m_ObjectWidth, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_352 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_obj[8].V_m_ObjectWidth, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_352;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_352.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_obj[8].V_m_ObjectPosX, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_353 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_obj[8].V_m_ObjectPosX, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_353;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_353.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_obj[8].V_m_ObjectPosY, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_354 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_obj[8].V_m_ObjectPosY, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_354;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_354.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_obj[8].V_mps_ObjectVelX, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_355 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_obj[8].V_mps_ObjectVelX, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_355;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_355.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_obj[8].V_mps_ObjectVelY, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_356 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_obj[8].V_mps_ObjectVelY, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_356;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_356.verify();

    EXPECT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_obj[8].V_x_ObjectType, 255);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_357 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_obj[8].V_x_ObjectType, 255);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_357;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_357.verify();

    EXPECT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_obj[8].V_x_ObjectStatus, 255);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_358 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_obj[8].V_x_ObjectStatus, 255);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_358;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_358.verify();

    EXPECT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_obj[8].V_x_ObjectValid, 255);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_359 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_obj[8].V_x_ObjectValid, 255);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_359;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_359.verify();

    EXPECT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_obj[8].V_x_ObjectLane, 255);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_360 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_obj[8].V_x_ObjectLane, 255);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_360;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_360.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_obj[8].V_s_TTC, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_361 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_obj[8].V_s_TTC, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_361;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_361.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_obj[8].V_mps2_ObjectAccelX, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_362 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_obj[8].V_mps2_ObjectAccelX, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_362;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_362.verify();

    EXPECT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_obj[8].V_x_BlinkInfo, 255);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_363 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_obj[8].V_x_BlinkInfo, 255);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_363;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_363.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_obj[8].V_degps_ObjectAngleRate, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_364 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_obj[8].V_degps_ObjectAngleRate, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_364;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_364.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_obj[8].V_deg_ObjectAngle, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_365 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_obj[8].V_deg_ObjectAngle, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_365;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_365.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_obj[8].V_mps_ObejectRelVelocity, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_366 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_obj[8].V_mps_ObejectRelVelocity, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_366;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_366.verify();

    EXPECT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_obj[9].llTimeStamp, 4294967295);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_367 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_obj[9].llTimeStamp, 4294967295);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_367;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_367.verify();

    EXPECT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_obj[9].V_x_ObjectID, 255);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_368 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_obj[9].V_x_ObjectID, 255);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_368;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_368.verify();

    EXPECT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_obj[9].F_x_CIPV, 255);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_369 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_obj[9].F_x_CIPV, 255);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_369;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_369.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_obj[9].V_x_ObjectLength, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_370 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_obj[9].V_x_ObjectLength, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_370;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_370.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_obj[9].V_m_ObjectWidth, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_371 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_obj[9].V_m_ObjectWidth, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_371;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_371.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_obj[9].V_m_ObjectPosX, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_372 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_obj[9].V_m_ObjectPosX, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_372;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_372.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_obj[9].V_m_ObjectPosY, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_373 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_obj[9].V_m_ObjectPosY, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_373;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_373.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_obj[9].V_mps_ObjectVelX, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_374 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_obj[9].V_mps_ObjectVelX, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_374;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_374.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_obj[9].V_mps_ObjectVelY, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_375 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_obj[9].V_mps_ObjectVelY, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_375;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_375.verify();

    EXPECT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_obj[9].V_x_ObjectType, 255);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_376 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_obj[9].V_x_ObjectType, 255);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_376;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_376.verify();

    EXPECT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_obj[9].V_x_ObjectStatus, 255);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_377 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_obj[9].V_x_ObjectStatus, 255);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_377;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_377.verify();

    EXPECT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_obj[9].V_x_ObjectValid, 255);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_378 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_obj[9].V_x_ObjectValid, 255);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_378;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_378.verify();

    EXPECT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_obj[9].V_x_ObjectLane, 255);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_379 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_obj[9].V_x_ObjectLane, 255);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_379;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_379.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_obj[9].V_s_TTC, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_380 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_obj[9].V_s_TTC, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_380;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_380.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_obj[9].V_mps2_ObjectAccelX, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_381 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_obj[9].V_mps2_ObjectAccelX, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_381;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_381.verify();

    EXPECT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_obj[9].V_x_BlinkInfo, 255);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_382 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_obj[9].V_x_BlinkInfo, 255);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_382;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_382.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_obj[9].V_degps_ObjectAngleRate, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_383 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_obj[9].V_degps_ObjectAngleRate, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_383;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_383.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_obj[9].V_deg_ObjectAngle, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_384 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_obj[9].V_deg_ObjectAngle, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_384;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_384.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_obj[9].V_mps_ObejectRelVelocity, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_385 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_obj[9].V_mps_ObejectRelVelocity, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_385;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_385.verify();

    EXPECT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_lane[0].llTimeStamp, 4294967295);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_386 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_lane[0].llTimeStamp, 4294967295);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_386;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_386.verify();

    EXPECT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_lane[0].V_x_LaneType, 255);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_387 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_lane[0].V_x_LaneType, 255);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_387;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_387.verify();

    EXPECT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_lane[0].V_x_LaneQuality, 255);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_388 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_lane[0].V_x_LaneQuality, 255);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_388;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_388.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_lane[0].V_m_LanePosition, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_389 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_lane[0].V_m_LanePosition, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_389;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_389.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_lane[0].V_pm_LineCurv, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_390 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_lane[0].V_pm_LineCurv, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_390;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_390.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_lane[0].V_pm2_LineCurvaRate, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_391 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_lane[0].V_pm2_LineCurvaRate, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_391;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_391.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_lane[0].V_m_Lane_Mark_Width, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_392 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_lane[0].V_m_Lane_Mark_Width, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_392;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_392.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_lane[0].V_rad_LineYawAng, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_393 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_lane[0].V_rad_LineYawAng, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_393;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_393.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_lane[0].V_m_ViewRange_Start, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_394 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_lane[0].V_m_ViewRange_Start, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_394;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_394.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_lane[0].V_m_ViewRange_End, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_395 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_lane[0].V_m_ViewRange_End, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_395;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_395.verify();

    EXPECT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_lane[0].V_x_Lane_Crossing, 255);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_396 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_lane[0].V_x_Lane_Crossing, 255);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_396;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_396.verify();

    EXPECT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_lane[0].V_x_Confidence_HWE, 255);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_397 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_lane[0].V_x_Confidence_HWE, 255);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_397;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_397.verify();

    EXPECT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_lane[1].llTimeStamp, 4294967295);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_398 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_lane[1].llTimeStamp, 4294967295);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_398;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_398.verify();

    EXPECT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_lane[1].V_x_LaneType, 255);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_399 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_lane[1].V_x_LaneType, 255);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_399;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_399.verify();

    EXPECT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_lane[1].V_x_LaneQuality, 255);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_400 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_lane[1].V_x_LaneQuality, 255);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_400;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_400.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_lane[1].V_m_LanePosition, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_401 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_lane[1].V_m_LanePosition, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_401;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_401.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_lane[1].V_pm_LineCurv, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_402 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_lane[1].V_pm_LineCurv, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_402;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_402.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_lane[1].V_pm2_LineCurvaRate, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_403 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_lane[1].V_pm2_LineCurvaRate, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_403;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_403.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_lane[1].V_m_Lane_Mark_Width, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_404 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_lane[1].V_m_Lane_Mark_Width, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_404;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_404.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_lane[1].V_rad_LineYawAng, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_405 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_lane[1].V_rad_LineYawAng, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_405;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_405.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_lane[1].V_m_ViewRange_Start, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_406 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_lane[1].V_m_ViewRange_Start, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_406;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_406.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_lane[1].V_m_ViewRange_End, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_407 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_lane[1].V_m_ViewRange_End, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_407;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_407.verify();

    EXPECT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_lane[1].V_x_Lane_Crossing, 255);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_408 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_lane[1].V_x_Lane_Crossing, 255);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_408;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_408.verify();

    EXPECT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_lane[1].V_x_Confidence_HWE, 255);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_409 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_lane[1].V_x_Confidence_HWE, 255);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_409;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_409.verify();

    EXPECT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_nextlane[0].V_x_NextLaneType, 255);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_410 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_nextlane[0].V_x_NextLaneType, 255);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_410;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_410.verify();

    EXPECT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_nextlane[0].V_x_NextLaneQuality, 255);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_411 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_nextlane[0].V_x_NextLaneQuality, 255);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_411;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_411.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_nextlane[0].V_m_NextLanePosition, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_412 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_nextlane[0].V_m_NextLanePosition, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_412;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_412.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_nextlane[0].V_pm_NextLineCurv, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_413 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_nextlane[0].V_pm_NextLineCurv, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_413;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_413.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_nextlane[0].V_pm2_NextLineCurvaRate, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_414 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_nextlane[0].V_pm2_NextLineCurvaRate, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_414;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_414.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_nextlane[0].V_m_NextLane_Mark_Width, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_415 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_nextlane[0].V_m_NextLane_Mark_Width, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_415;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_415.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_nextlane[0].V_rad_NextLineYawAng, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_416 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_nextlane[0].V_rad_NextLineYawAng, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_416;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_416.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_nextlane[0].V_m_NextViewRange_Start, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_417 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_nextlane[0].V_m_NextViewRange_Start, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_417;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_417.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_nextlane[0].V_m_NextViewRange_End, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_418 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_nextlane[0].V_m_NextViewRange_End, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_418;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_418.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_nextlane[0].V_x_ConfMeasure, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_419 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_nextlane[0].V_x_ConfMeasure, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_419;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_419.verify();

    EXPECT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_nextlane[1].V_x_NextLaneType, 255);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_420 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_nextlane[1].V_x_NextLaneType, 255);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_420;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_420.verify();

    EXPECT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_nextlane[1].V_x_NextLaneQuality, 255);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_421 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_nextlane[1].V_x_NextLaneQuality, 255);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_421;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_421.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_nextlane[1].V_m_NextLanePosition, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_422 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_nextlane[1].V_m_NextLanePosition, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_422;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_422.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_nextlane[1].V_pm_NextLineCurv, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_423 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_nextlane[1].V_pm_NextLineCurv, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_423;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_423.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_nextlane[1].V_pm2_NextLineCurvaRate, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_424 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_nextlane[1].V_pm2_NextLineCurvaRate, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_424;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_424.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_nextlane[1].V_m_NextLane_Mark_Width, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_425 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_nextlane[1].V_m_NextLane_Mark_Width, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_425;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_425.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_nextlane[1].V_rad_NextLineYawAng, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_426 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_nextlane[1].V_rad_NextLineYawAng, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_426;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_426.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_nextlane[1].V_m_NextViewRange_Start, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_427 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_nextlane[1].V_m_NextViewRange_Start, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_427;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_427.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_nextlane[1].V_m_NextViewRange_End, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_428 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_nextlane[1].V_m_NextViewRange_End, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_428;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_428.verify();

    EXPECT_FLOAT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_nextlane[1].V_x_ConfMeasure, 340282346638528897590636046441678635008);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_429 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_FLOAT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_nextlane[1].V_x_ConfMeasure, 340282346638528897590636046441678635008);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_429;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_429.verify();

    EXPECT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_roadinfo.V_x_Lane_Assignment_Host_Index_0m, 255);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_430 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_roadinfo.V_x_Lane_Assignment_Host_Index_0m, 255);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_430;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_430.verify();

    EXPECT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_roadinfo.V_x_NumOfLanes_near, 255);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_431 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_roadinfo.V_x_NumOfLanes_near, 255);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_431;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_431.verify();

    EXPECT_EQ(gOEM_SWC_C2_1UVehStatus_In_10DataSet.mConc.V_x_SurroundFusionSensorInput.V_x_front_cam_roadinfo.V_x_Number_Of_Lanes, 255);
    struct _func_V_x_SurroundFusionSensorInput_SurroundFusion_432 {
        static void verify(void) {
#include "Rte_Wrapper_SurroundFusion.h"
            V_x_SurroundFusionSensorInput tmp_SurroundFusionSensorInput;
            Rte_Read_V_x_SurroundFusionSensorInput_V_x_SurroundFusionSensorInput(&tmp_SurroundFusionSensorInput);
            EXPECT_EQ(tmp_SurroundFusionSensorInput.V_x_front_cam_roadinfo.V_x_Number_Of_Lanes, 255);
        }
    } func_V_x_SurroundFusionSensorInput_SurroundFusion_432;
    func_V_x_SurroundFusionSensorInput_SurroundFusion_432.verify();

}
