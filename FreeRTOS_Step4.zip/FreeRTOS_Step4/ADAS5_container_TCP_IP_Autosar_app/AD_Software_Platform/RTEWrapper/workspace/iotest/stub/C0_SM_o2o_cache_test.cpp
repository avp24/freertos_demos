#include "gtest/gtest.h"

#ifdef __cplusplus
extern "C" {
#endif
extern void OEM_SWC_C0_SM_input_From_SUP(void);
extern void OEM_SWC_C0_SM_output(void);
#ifdef __cplusplus
}
#endif

extern void C0_SM_o2o_cache_prepare_SafetyModule(void);
extern void C0_SM_o2o_cache_verify_SafetyModule(void);
void C0_SM_o2o_cache_prepare(void)
{
    C0_SM_o2o_cache_prepare_SafetyModule();
}

void C0_SM_o2o_cache_verify(void)
{
    C0_SM_o2o_cache_verify_SafetyModule();
}

TEST(IOTest, C0_SM_o2o_cache_test)
{
    C0_SM_o2o_cache_prepare();
    C0_SM_o2o_cache_verify();
}
