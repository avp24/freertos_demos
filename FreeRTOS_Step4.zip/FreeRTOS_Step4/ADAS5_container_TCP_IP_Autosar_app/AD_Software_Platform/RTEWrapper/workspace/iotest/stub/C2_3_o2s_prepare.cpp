#include <limits.h>
#include <float.h>
#define DUMMY_RTE_INCLUDE_MULTI_SWC_HEADER
#include "Platform_Types.h"
#ifdef __cplusplus
extern "C" {
#endif
#ifdef __cplusplus
}
#endif

#include "Rte_Wrapper_RCarHMIManagement.h"
void C2_3_o2s_prepare_RCarHMIManagement(void)
{
    V_x_RCarHMIManagementOutput tmp_RCarHMIManagementOutput;

}

#include "Rte_Wrapper_ObjectSelectionAVM.h"
void C2_3_o2s_prepare_ObjectSelectionAVM(void)
{
    V_x_ObjectSelectionAVMOutput tmp_ObjectSelectionAVMOutput;

}

#include "Rte_Wrapper_VehStatus_In_100.h"
void C2_3_o2s_prepare_VehStatus_In_100(void)
{
    V_x_RCarHMIManagementSensorInput tmp_RCarHMIManagementSensorInput;
    sint32 tmp_S32;
    V_x_clustered_side_radar_obj_t tmp_clustered_side_radar_obj_t;
    V_x_sorted_side_radar_obj_t tmp_sorted_side_radar_obj_t;

}
