#include "gtest/gtest.h"

#ifdef __cplusplus
extern "C" {
#endif
extern void OEM_SWC_C1_1_input_From_SUP(void);
extern void OEM_SWC_C1_1_output(void);
#ifdef __cplusplus
}
#endif

extern void C1_1_s2o_min_prepare_ADC(void);
extern void C1_1_s2o_min_prepare_DIO(void);
extern void C1_1_s2o_min_prepare_EEPROM(void);
extern void C1_1_s2o_min_prepare_PWM(void);
extern void C1_1_s2o_min_prepare_SUP_DIAG(void);
extern void C1_1_s2o_min_prepare_UDSCOM(void);
extern void C1_1_s2o_min_prepare_LINIF(void);
extern void C1_1_s2o_min_prepare_CANIF(void);
extern void C1_1_s2o_min_prepare_EthIF(void);
extern void C1_1_s2o_min_prepare_OEMRAMClear(void);
extern void C1_1_s2o_min_verify_ADC(void);
extern void C1_1_s2o_min_verify_DIO(void);
extern void C1_1_s2o_min_verify_EEPROM(void);
extern void C1_1_s2o_min_verify_PWM(void);
extern void C1_1_s2o_min_verify_SUP_DIAG(void);
extern void C1_1_s2o_min_verify_UDSCOM(void);
extern void C1_1_s2o_min_verify_LINIF(void);
extern void C1_1_s2o_min_verify_CANIF(void);
extern void C1_1_s2o_min_verify_EthIF(void);
extern void C1_1_s2o_min_verify_OEMRAMClear(void);
void C1_1_s2o_min_prepare(void)
{
    C1_1_s2o_min_prepare_ADC();
    C1_1_s2o_min_prepare_DIO();
    C1_1_s2o_min_prepare_EEPROM();
    C1_1_s2o_min_prepare_PWM();
    C1_1_s2o_min_prepare_SUP_DIAG();
    C1_1_s2o_min_prepare_UDSCOM();
    C1_1_s2o_min_prepare_LINIF();
    C1_1_s2o_min_prepare_CANIF();
    C1_1_s2o_min_prepare_EthIF();
    C1_1_s2o_min_prepare_OEMRAMClear();
}

void C1_1_s2o_min_verify(void)
{
    C1_1_s2o_min_verify_ADC();
    C1_1_s2o_min_verify_DIO();
    C1_1_s2o_min_verify_EEPROM();
    C1_1_s2o_min_verify_PWM();
    C1_1_s2o_min_verify_SUP_DIAG();
    C1_1_s2o_min_verify_UDSCOM();
    C1_1_s2o_min_verify_LINIF();
    C1_1_s2o_min_verify_CANIF();
    C1_1_s2o_min_verify_EthIF();
    C1_1_s2o_min_verify_OEMRAMClear();
}

TEST(IOTest, C1_1_s2o_min_test)
{
    C1_1_s2o_min_prepare();
    OEM_SWC_C1_1_input_From_SUP();
    C1_1_s2o_min_verify();
}
