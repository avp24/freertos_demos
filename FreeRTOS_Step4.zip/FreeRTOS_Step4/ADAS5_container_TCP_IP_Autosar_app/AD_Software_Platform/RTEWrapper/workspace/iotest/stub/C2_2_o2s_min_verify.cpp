#include <limits.h>
#include <float.h>
#include "gtest/gtest.h"
#include "Platform_Types.h"




void C2_2_o2s_min_verify_AutoLCPossibilityJdg(void)
{
}

void C2_2_o2s_min_verify_ObjectSelectionDM(void)
{
}

void C2_2_o2s_min_verify_VehStatus_In_50(void)
{
}
