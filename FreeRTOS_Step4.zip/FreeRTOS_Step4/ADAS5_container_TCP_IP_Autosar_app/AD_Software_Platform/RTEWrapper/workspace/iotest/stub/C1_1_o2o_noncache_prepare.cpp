#include <limits.h>
#include <float.h>
#define DUMMY_RTE_INCLUDE_MULTI_SWC_HEADER
#include "Platform_Types.h"

#include "Rte_Wrapper_DiagControl.h"
void C1_1_o2o_noncache_prepare_DiagControl(void)
{
    boolean tmp_B;

}

#include "Rte_Wrapper_OEM_DIAG.h"
void C1_1_o2o_noncache_prepare_OEM_DIAG(void)
{
    boolean tmp_B;
    uint16 tmp_U16;

}

#include "Rte_Wrapper_ActivationManagement.h"
void C1_1_o2o_noncache_prepare_ActivationManagement(void)
{
    boolean tmp_B;
    uint8 tmp_U8;
    sint8 tmp_S8;
    uint8 tmp_U8_16[16];
    uint8 tmp_U8_148[148];
    V_x_VariantManagement tmp_VariantManagement;

}

#include "Rte_Wrapper_VehStatus_In.h"
void C1_1_o2o_noncache_prepare_VehStatus_In(void)
{
    boolean tmp_B;
    float32 tmp_Fl32;
    sint16 tmp_S16;
    sint32 tmp_S32;
    uint16 tmp_U16;
    uint8 tmp_U8;
    sint8 tmp_S8;
    uint32 tmp_U32;
    float32 tmp_Fl32_20[20];
    uint8 tmp_U8_8[8];
    uint8 tmp_U8_20[20];
    uint8 tmp_U8_9[9];
    sint8 tmp_S8_9[9];

}

#include "Rte_Wrapper_VehStatus_Out.h"
void C1_1_o2o_noncache_prepare_VehStatus_Out(void)
{
    boolean tmp_B;
    sint16 tmp_S16;
    uint16 tmp_U16;
    float32 tmp_Fl32;
    uint8 tmp_U8;
    sint8 tmp_S8;
    uint64 tmp_U64;
    V_x_AutoLCPossibilityJdgInput tmp_AutoLCPossibilityJdgInput;
    V_x_ObjectSelectionAVMInput tmp_ObjectSelectionAVMInput;
    V_x_RCarHMIManagementInput tmp_RCarHMIManagementInput;
    uint32 tmp_U32;
    V_x_SurroundFusionInput tmp_SurroundFusionInput;

    tmp_U16 = 26959;
    Rte_Write_V_Nm_AEB_BrakeWheelTorqueRequest2_VSO_V_Nm_AEB_BrakeWheelTorqueRequest2_VSO(tmp_U16);
    tmp_U16 = 64162;
    Rte_Write_V_Nm_AEB_BrakeWheelTorqueRequest3_VSO_V_Nm_AEB_BrakeWheelTorqueRequest3_VSO(tmp_U16);
    tmp_S16 = -12215;
    Rte_Write_V_Nm_Global_PWTWheelTorqueRequest_VSO_V_Nm_Global_PWTWheelTorqueRequest_VSO(tmp_S16);
    tmp_S16 = -16587;
    Rte_Write_V_Nm_PWTWheelTorqueLimitationRequest_VSO_V_Nm_PWTWheelTorqueLimitationRequest_VSO(tmp_S16);
    tmp_S8 = 57;
    Rte_Write_V_x_ADmodeStatus_VSO_V_x_ADmodeStatus_VSO(tmp_S8);
    tmp_AutoLCPossibilityJdgInput.V_x_vehicle_status.V_mps_VSP_LPF = 875.44;
    tmp_AutoLCPossibilityJdgInput.V_x_vehicle_status.V_mps_AVE_VSP = -643.43;
    tmp_AutoLCPossibilityJdgInput.V_x_vehicle_status.V_x_RangeIndication = 209;
    tmp_AutoLCPossibilityJdgInput.V_x_vehicle_status.F_x_CancelButton = 148;
    tmp_AutoLCPossibilityJdgInput.V_x_vehicle_status.F_x_MainSwOn4 = 57;
    tmp_AutoLCPossibilityJdgInput.V_x_vehicle_status.V_deg_EPS_AngleSensor = 180.94;
    tmp_AutoLCPossibilityJdgInput.V_x_vehicle_status.V_deg_SteeringWheelAngleRaw = -494.74;
    tmp_AutoLCPossibilityJdgInput.V_x_vehicle_status.V_degps_YawRateRaw = -529.18;
    tmp_AutoLCPossibilityJdgInput.V_x_vehicle_status.V_x_TurnInd = 29;
    tmp_AutoLCPossibilityJdgInput.V_x_vehicle_status.V_kph_VDCVehicleSpeed = 942.61;
    tmp_AutoLCPossibilityJdgInput.V_x_vehicle_status.V_mps_VehSpeed_Est = 752.28;
    tmp_AutoLCPossibilityJdgInput.V_x_vehicle_status.V_x_TURN_IND_Filter = 6;
    tmp_AutoLCPossibilityJdgInput.V_x_vehicle_status.V_x_Turn_Signal_Com = 119;
    tmp_AutoLCPossibilityJdgInput.V_x_vehicle_status.V_m_ycr_l = 128.22;
    tmp_AutoLCPossibilityJdgInput.V_x_vehicle_status.V_rad_phi_l = -178.28;
    tmp_AutoLCPossibilityJdgInput.V_x_vehicle_status.V_pm_rho_l = 899.41;
    tmp_AutoLCPossibilityJdgInput.V_x_vehicle_status.V_degps_YawRateCorrected = 642.81;
    tmp_AutoLCPossibilityJdgInput.V_x_ctrl_flag.V_x_InternalACCStatus = 8;
    tmp_AutoLCPossibilityJdgInput.V_x_ctrl_flag.F_x_Lch_on = 177;
    tmp_AutoLCPossibilityJdgInput.V_x_ctrl_flag.V_x_Lch_dir_fix = 15;
    tmp_AutoLCPossibilityJdgInput.V_x_ctrl_flag.F_x_DriverSteer = 173;
    tmp_AutoLCPossibilityJdgInput.V_x_ctrl_flag.F_x_Lanechange_abort = 202;
    tmp_AutoLCPossibilityJdgInput.V_x_ctrl_flag.V_x_LatControlModeSel = 133;
    tmp_AutoLCPossibilityJdgInput.V_x_ctrl_flag.F_x_Lch_pass_announce_toRight = 126;
    tmp_AutoLCPossibilityJdgInput.V_x_ctrl_flag.F_x_Lch_return_announce_toLeft = 117;
    tmp_AutoLCPossibilityJdgInput.V_x_ctrl_flag.V_x_HandsOnJdg = 6;
    tmp_AutoLCPossibilityJdgInput.V_x_ctrl_flag.V_x_ADCtrlStat = 93;
    tmp_AutoLCPossibilityJdgInput.V_x_ctrl_flag.V_x_NumOfSystemAutoLC_Right = 9;
    tmp_AutoLCPossibilityJdgInput.V_x_ctrl_flag.V_x_LaneChangeType = 174;
    tmp_AutoLCPossibilityJdgInput.V_x_ctrl_flag.V_x_ALC_InternalState = 168;
    tmp_AutoLCPossibilityJdgInput.V_x_ctrl_flag.V_x_AutoLCDirection_HMI = 140;
    tmp_AutoLCPossibilityJdgInput.V_x_ctrl_flag.V_x_FS_ALCState = 1663;
    tmp_AutoLCPossibilityJdgInput.V_x_ctrl_flag.F_x_InitLane = 109;
    tmp_AutoLCPossibilityJdgInput.V_x_ctrl_flag.F_x_IniSteer = 99;
    tmp_AutoLCPossibilityJdgInput.V_x_ctrl_flag.F_x_SteerCntrl2 = 8;
    tmp_AutoLCPossibilityJdgInput.V_x_ctrl_flag.F_x_TurnIndLeftValid = 73;
    tmp_AutoLCPossibilityJdgInput.V_x_ctrl_flag.F_x_TurnIndRightValid = 252;
    tmp_AutoLCPossibilityJdgInput.V_x_ctrl_flag.V_x_Lch_dir_pre = -111;
    tmp_AutoLCPossibilityJdgInput.V_x_prec_vehicle_info.V_x_SENSOR_SEL = 106;
    tmp_AutoLCPossibilityJdgInput.V_x_prec_vehicle_info.V_x_SensorSelEgo = 27;
    tmp_AutoLCPossibilityJdgInput.V_x_prec_vehicle_info.V_mps2_DecelerationEgo = -107.25;
    tmp_AutoLCPossibilityJdgInput.V_x_prec_vehicle_info.V_m_Distance = 317.76;
    tmp_AutoLCPossibilityJdgInput.V_x_prec_vehicle_info.V_m_PrecVehicleLatDistance = 582.17;
    tmp_AutoLCPossibilityJdgInput.V_x_prec_vehicle_info.V_mps_RelativeSpeed = 647.28;
    tmp_AutoLCPossibilityJdgInput.V_x_SigSetSpeed = 176;
    Rte_Write_V_x_AutoLCPossibilityJdgInput_V_x_AutoLCPossibilityJdgInput(&tmp_AutoLCPossibilityJdgInput);
    tmp_U8 = 74;
    Rte_Write_V_x_Global_PWTWheelTorqueOrder_VSO_V_x_Global_PWTWheelTorqueOrder_VSO(tmp_U8);
    tmp_ObjectSelectionAVMInput.V_x_vehicle_status.V_mps_VSP_LPF = 337.09;
    tmp_ObjectSelectionAVMInput.V_x_vehicle_status.V_mps_AVE_VSP = -215.54;
    tmp_ObjectSelectionAVMInput.V_x_vehicle_status.V_x_RangeIndication = 139;
    tmp_ObjectSelectionAVMInput.V_x_vehicle_status.F_x_CancelButton = 101;
    tmp_ObjectSelectionAVMInput.V_x_vehicle_status.F_x_MainSwOn4 = 57;
    tmp_ObjectSelectionAVMInput.V_x_vehicle_status.V_deg_EPS_AngleSensor = 429.44;
    tmp_ObjectSelectionAVMInput.V_x_vehicle_status.V_deg_SteeringWheelAngleRaw = -982.81;
    tmp_ObjectSelectionAVMInput.V_x_vehicle_status.V_degps_YawRateRaw = -59.91;
    tmp_ObjectSelectionAVMInput.V_x_vehicle_status.V_x_TurnInd = 66;
    tmp_ObjectSelectionAVMInput.V_x_vehicle_status.V_kph_VDCVehicleSpeed = -69.37;
    tmp_ObjectSelectionAVMInput.V_x_vehicle_status.V_mps_VehSpeed_Est = -322.46;
    tmp_ObjectSelectionAVMInput.V_x_vehicle_status.V_x_TURN_IND_Filter = 150;
    tmp_ObjectSelectionAVMInput.V_x_vehicle_status.V_x_Turn_Signal_Com = 114;
    tmp_ObjectSelectionAVMInput.V_x_vehicle_status.V_m_ycr_l = -608.92;
    tmp_ObjectSelectionAVMInput.V_x_vehicle_status.V_rad_phi_l = -711.56;
    tmp_ObjectSelectionAVMInput.V_x_vehicle_status.V_pm_rho_l = 728.19;
    tmp_ObjectSelectionAVMInput.V_x_vehicle_status.V_degps_YawRateCorrected = -410.06;
    Rte_Write_V_x_ObjectSelectionAVMInput_V_x_ObjectSelectionAVMInput(&tmp_ObjectSelectionAVMInput);
    tmp_U8 = 181;
    Rte_Write_V_x_PWTWheelTorqueLimitationOrder_VSO_V_x_PWTWheelTorqueLimitationOrder_VSO(tmp_U8);
    tmp_RCarHMIManagementInput.V_x_vehicle_status.V_mps_VSP_LPF = 62.59;
    tmp_RCarHMIManagementInput.V_x_vehicle_status.V_mps_AVE_VSP = 731.95;
    tmp_RCarHMIManagementInput.V_x_vehicle_status.V_x_RangeIndication = 215;
    tmp_RCarHMIManagementInput.V_x_vehicle_status.F_x_CancelButton = 150;
    tmp_RCarHMIManagementInput.V_x_vehicle_status.F_x_MainSwOn4 = 45;
    tmp_RCarHMIManagementInput.V_x_vehicle_status.V_deg_EPS_AngleSensor = 861.34;
    tmp_RCarHMIManagementInput.V_x_vehicle_status.V_deg_SteeringWheelAngleRaw = 483.92;
    tmp_RCarHMIManagementInput.V_x_vehicle_status.V_degps_YawRateRaw = 203.97;
    tmp_RCarHMIManagementInput.V_x_vehicle_status.V_x_TurnInd = 174;
    tmp_RCarHMIManagementInput.V_x_vehicle_status.V_kph_VDCVehicleSpeed = -224.98;
    tmp_RCarHMIManagementInput.V_x_vehicle_status.V_mps_VehSpeed_Est = -894.57;
    tmp_RCarHMIManagementInput.V_x_vehicle_status.V_x_TURN_IND_Filter = 75;
    tmp_RCarHMIManagementInput.V_x_vehicle_status.V_x_Turn_Signal_Com = 54;
    tmp_RCarHMIManagementInput.V_x_vehicle_status.V_m_ycr_l = 168.74;
    tmp_RCarHMIManagementInput.V_x_vehicle_status.V_rad_phi_l = 800.13;
    tmp_RCarHMIManagementInput.V_x_vehicle_status.V_pm_rho_l = -799.83;
    tmp_RCarHMIManagementInput.V_x_vehicle_status.V_degps_YawRateCorrected = 718.99;
    tmp_RCarHMIManagementInput.V_x_ctrl_flag.V_x_InternalACCStatus = 86;
    tmp_RCarHMIManagementInput.V_x_ctrl_flag.F_x_Lch_on = 78;
    tmp_RCarHMIManagementInput.V_x_ctrl_flag.V_x_Lch_dir_fix = -16;
    tmp_RCarHMIManagementInput.V_x_ctrl_flag.F_x_DriverSteer = 163;
    tmp_RCarHMIManagementInput.V_x_ctrl_flag.F_x_Lanechange_abort = 217;
    tmp_RCarHMIManagementInput.V_x_ctrl_flag.V_x_LatControlModeSel = 242;
    tmp_RCarHMIManagementInput.V_x_ctrl_flag.F_x_Lch_pass_announce_toRight = 32;
    tmp_RCarHMIManagementInput.V_x_ctrl_flag.F_x_Lch_return_announce_toLeft = 244;
    tmp_RCarHMIManagementInput.V_x_ctrl_flag.V_x_HandsOnJdg = 15;
    tmp_RCarHMIManagementInput.V_x_ctrl_flag.V_x_ADCtrlStat = 221;
    tmp_RCarHMIManagementInput.V_x_ctrl_flag.V_x_NumOfSystemAutoLC_Right = 27;
    tmp_RCarHMIManagementInput.V_x_ctrl_flag.V_x_LaneChangeType = 70;
    tmp_RCarHMIManagementInput.V_x_ctrl_flag.V_x_ALC_InternalState = 70;
    tmp_RCarHMIManagementInput.V_x_ctrl_flag.V_x_AutoLCDirection_HMI = 54;
    tmp_RCarHMIManagementInput.V_x_ctrl_flag.V_x_FS_ALCState = 29083;
    tmp_RCarHMIManagementInput.V_x_ctrl_flag.F_x_InitLane = 28;
    tmp_RCarHMIManagementInput.V_x_ctrl_flag.F_x_IniSteer = 204;
    tmp_RCarHMIManagementInput.V_x_ctrl_flag.F_x_SteerCntrl2 = 138;
    tmp_RCarHMIManagementInput.V_x_ctrl_flag.F_x_TurnIndLeftValid = 110;
    tmp_RCarHMIManagementInput.V_x_ctrl_flag.F_x_TurnIndRightValid = 161;
    tmp_RCarHMIManagementInput.V_x_ctrl_flag.V_x_Lch_dir_pre = 9;
    tmp_RCarHMIManagementInput.V_x_prec_vehicle_info.V_x_SENSOR_SEL = 204;
    tmp_RCarHMIManagementInput.V_x_prec_vehicle_info.V_x_SensorSelEgo = 231;
    tmp_RCarHMIManagementInput.V_x_prec_vehicle_info.V_mps2_DecelerationEgo = 966.72;
    tmp_RCarHMIManagementInput.V_x_prec_vehicle_info.V_m_Distance = -145.33;
    tmp_RCarHMIManagementInput.V_x_prec_vehicle_info.V_m_PrecVehicleLatDistance = -165.87;
    tmp_RCarHMIManagementInput.V_x_prec_vehicle_info.V_mps_RelativeSpeed = -237.69;
    tmp_RCarHMIManagementInput.V_x_front_cam_lane_sel.V_m_Position_LKA_SEL_LANE = -772.48;
    tmp_RCarHMIManagementInput.V_x_front_cam_lane_sel.V_rad_Heading_LKA_SEL_LANE = 881.54;
    tmp_RCarHMIManagementInput.V_x_front_cam_lane_sel.V_x_Quality_LKA_SEL_LANE = 131;
    tmp_RCarHMIManagementInput.V_x_front_cam_lane_sel.V_pm_Curvature_LKA_SEL = -19.09;
    tmp_RCarHMIManagementInput.V_x_front_cam_lane_sel.V_pm2_Curvature_derivative_LKA_SEL = -773.42;
    tmp_RCarHMIManagementInput.V_x_front_cam_lane_sel.V_m_Lane_Width = 577.4;
    tmp_RCarHMIManagementInput.V_x_front_cam_lane_sel.V_pm_Curvature_LKA_SEL_hokan = -25.34;
    tmp_RCarHMIManagementInput.V_x_front_cam_lane_sel.V_rad_Heading_LKA_SEL_hokan = 37.9;
    tmp_RCarHMIManagementInput.V_x_front_cam_lane_sel.V_m_offset_from_1st_lane = 47.9;
    tmp_RCarHMIManagementInput.V_x_front_cam_lane_sel.V_m_Position_SEL_LANE_Offset = -750.27;
    tmp_RCarHMIManagementInput.V_x_front_cam_lane_sel.V_x_LINE_SEL_HOKAN = 49;
    tmp_RCarHMIManagementInput.V_x_front_cam_lane_sel.F_x_LineCross = 103;
    Rte_Write_V_x_RCarHMIManagementInput_V_x_RCarHMIManagementInput(&tmp_RCarHMIManagementInput);
    tmp_SurroundFusionInput.V_x_vehicle_status.V_mps_VSP_LPF = -891.31;
    tmp_SurroundFusionInput.V_x_vehicle_status.V_mps_AVE_VSP = -721.02;
    tmp_SurroundFusionInput.V_x_vehicle_status.V_x_RangeIndication = 196;
    tmp_SurroundFusionInput.V_x_vehicle_status.F_x_CancelButton = 68;
    tmp_SurroundFusionInput.V_x_vehicle_status.F_x_MainSwOn4 = 79;
    tmp_SurroundFusionInput.V_x_vehicle_status.V_deg_EPS_AngleSensor = -87.32;
    tmp_SurroundFusionInput.V_x_vehicle_status.V_deg_SteeringWheelAngleRaw = -66.64;
    tmp_SurroundFusionInput.V_x_vehicle_status.V_degps_YawRateRaw = -367.94;
    tmp_SurroundFusionInput.V_x_vehicle_status.V_x_TurnInd = 180;
    tmp_SurroundFusionInput.V_x_vehicle_status.V_kph_VDCVehicleSpeed = 910.7;
    tmp_SurroundFusionInput.V_x_vehicle_status.V_mps_VehSpeed_Est = 6.18;
    tmp_SurroundFusionInput.V_x_vehicle_status.V_x_TURN_IND_Filter = 217;
    tmp_SurroundFusionInput.V_x_vehicle_status.V_x_Turn_Signal_Com = 93;
    tmp_SurroundFusionInput.V_x_vehicle_status.V_m_ycr_l = -19.68;
    tmp_SurroundFusionInput.V_x_vehicle_status.V_rad_phi_l = -495.55;
    tmp_SurroundFusionInput.V_x_vehicle_status.V_pm_rho_l = 562.31;
    tmp_SurroundFusionInput.V_x_vehicle_status.V_degps_YawRateCorrected = 442.06;
    tmp_SurroundFusionInput.V_x_ctrl_flag.V_x_InternalACCStatus = 246;
    tmp_SurroundFusionInput.V_x_ctrl_flag.F_x_Lch_on = 25;
    tmp_SurroundFusionInput.V_x_ctrl_flag.V_x_Lch_dir_fix = -41;
    tmp_SurroundFusionInput.V_x_ctrl_flag.F_x_DriverSteer = 226;
    tmp_SurroundFusionInput.V_x_ctrl_flag.F_x_Lanechange_abort = 64;
    tmp_SurroundFusionInput.V_x_ctrl_flag.V_x_LatControlModeSel = 168;
    tmp_SurroundFusionInput.V_x_ctrl_flag.F_x_Lch_pass_announce_toRight = 67;
    tmp_SurroundFusionInput.V_x_ctrl_flag.F_x_Lch_return_announce_toLeft = 79;
    tmp_SurroundFusionInput.V_x_ctrl_flag.V_x_HandsOnJdg = 135;
    tmp_SurroundFusionInput.V_x_ctrl_flag.V_x_ADCtrlStat = 161;
    tmp_SurroundFusionInput.V_x_ctrl_flag.V_x_NumOfSystemAutoLC_Right = 44;
    tmp_SurroundFusionInput.V_x_ctrl_flag.V_x_LaneChangeType = 92;
    tmp_SurroundFusionInput.V_x_ctrl_flag.V_x_ALC_InternalState = 110;
    tmp_SurroundFusionInput.V_x_ctrl_flag.V_x_AutoLCDirection_HMI = 76;
    tmp_SurroundFusionInput.V_x_ctrl_flag.V_x_FS_ALCState = 5327;
    tmp_SurroundFusionInput.V_x_ctrl_flag.F_x_InitLane = 133;
    tmp_SurroundFusionInput.V_x_ctrl_flag.F_x_IniSteer = 237;
    tmp_SurroundFusionInput.V_x_ctrl_flag.F_x_SteerCntrl2 = 93;
    tmp_SurroundFusionInput.V_x_ctrl_flag.F_x_TurnIndLeftValid = 88;
    tmp_SurroundFusionInput.V_x_ctrl_flag.F_x_TurnIndRightValid = 206;
    tmp_SurroundFusionInput.V_x_ctrl_flag.V_x_Lch_dir_pre = -28;
    Rte_Write_V_x_SurroundFusionInput_V_x_SurroundFusionInput(&tmp_SurroundFusionInput);
}

#include "Rte_Wrapper_BRK_ENG.h"
void C1_1_o2o_noncache_prepare_BRK_ENG(void)
{
    boolean tmp_B;
    sint32 tmp_S32;
    float32 tmp_Fl32;
    sint16 tmp_S16;
    uint8 tmp_U8;

}

#include "Rte_Wrapper_YAW.h"
void C1_1_o2o_noncache_prepare_YAW(void)
{
    boolean tmp_B;
    sint16 tmp_S16;
    sint32 tmp_S32;
    float32 tmp_Fl32;

}

#include "Rte_Wrapper_HMI.h"
void C1_1_o2o_noncache_prepare_HMI(void)
{
    boolean tmp_B;
    uint8 tmp_U8;
    float32 tmp_Fl32;

}

#include "Rte_Wrapper_CAM_RAD.h"
void C1_1_o2o_noncache_prepare_CAM_RAD(void)
{
    boolean tmp_B;
    uint16 tmp_U16;
    sint8 tmp_S8;
    sint16 tmp_S16;
    float32 tmp_Fl32;
    sint32 tmp_S32;
    uint8 tmp_U8;
    uint32 tmp_U32;
    V_x_VectorLaneCameraObjects tmp_VectorLaneCameraObjects;

    tmp_B = 203;
    Rte_Write_F_x_fCamPedBrake_F_x_fCamPedBrake(tmp_B);
    tmp_B = 246;
    Rte_Write_F_x_fCamPedCrossBrake_F_x_fCamPedCrossBrake(tmp_B);
    tmp_B = 29;
    Rte_Write_F_x_fCamPedPreBrake_F_x_fCamPedPreBrake(tmp_B);
    tmp_B = 167;
    Rte_Write_F_x_fCamPedPreFill_F_x_fCamPedPreFill(tmp_B);
    tmp_B = 73;
    Rte_Write_F_x_fRIR_Input_AEBLateValid_F_x_fRIR_Input_AEBLateValid(tmp_B);
    tmp_B = 243;
    Rte_Write_F_x_f_ConfPedMatch_CPNC_F_x_f_ConfPedMatch_CPNC(tmp_B);
    tmp_Fl32 = 577.96;
    Rte_Write_V_deg_CamPed_Ac_V_deg_CamPed_Ac(tmp_Fl32);
    tmp_Fl32 = -277.39;
    Rte_Write_V_deg_RadPed_Ar_V_deg_RadPed_Ar(tmp_Fl32);
    tmp_Fl32 = 861.35;
    Rte_Write_V_m_CamCipv_LatDist_V_m_CamCipv_LatDist(tmp_Fl32);
    tmp_Fl32 = -67.73;
    Rte_Write_V_m_CamCipv_LongiDist_V_m_CamCipv_LongiDist(tmp_Fl32);
    tmp_Fl32 = 813.69;
    Rte_Write_V_m_CamPed_FDT_Dt_V_m_CamPed_FDT_Dt(tmp_Fl32);
    tmp_Fl32 = -782.73;
    Rte_Write_V_m_CamPed_LatDist_V_m_CamPed_LatDist(tmp_Fl32);
    tmp_Fl32 = -66.89;
    Rte_Write_V_m_CamPed_LongiDist_V_m_CamPed_LongiDist(tmp_Fl32);
    tmp_Fl32 = -28.9;
    Rte_Write_V_m_RadFcwa_LatDist_V_m_RadFcwa_LatDist(tmp_Fl32);
    tmp_Fl32 = 703.84;
    Rte_Write_V_m_RadFcwa_LongiDist_V_m_RadFcwa_LongiDist(tmp_Fl32);
    tmp_Fl32 = -189.55;
    Rte_Write_V_m_RadPed_LatDist_V_m_RadPed_LatDist(tmp_Fl32);
    tmp_Fl32 = -825.14;
    Rte_Write_V_m_RadPed_LongiDist_V_m_RadPed_LongiDist(tmp_Fl32);
    tmp_Fl32 = -855.21;
    Rte_Write_V_mps_CamCipv_RelSpd_V_mps_CamCipv_RelSpd(tmp_Fl32);
    tmp_Fl32 = -458.34;
    Rte_Write_V_mps_RadFcwa_RelSpd_V_mps_RadFcwa_RelSpd(tmp_Fl32);
    tmp_Fl32 = -563.14;
    Rte_Write_V_mps_RadPed_RelSpd_V_mps_RadPed_RelSpd(tmp_Fl32);
    tmp_Fl32 = 430.84;
    Rte_Write_V_s_CamCipv_TTC_V_s_CamCipv_TTC(tmp_Fl32);
    tmp_U32 = 2935855434;
    Rte_Write_V_x_CamCipv_ID_CIPV_V_x_CamCipv_ID_CIPV(tmp_U32);
    tmp_U32 = 3181324087;
    Rte_Write_V_x_CamCipv_ObjID_V_x_CamCipv_ObjID(tmp_U32);
    tmp_U32 = 1879904891;
    Rte_Write_V_x_CamCipv_ObjStatus_V_x_CamCipv_ObjStatus(tmp_U32);
    tmp_U32 = 4171200218;
    Rte_Write_V_x_CamCipv_Pos_V_x_CamCipv_Pos(tmp_U32);
    tmp_U32 = 1510091953;
    Rte_Write_V_x_CamCipv_TTCflg_V_x_CamCipv_TTCflg(tmp_U32);
    tmp_U32 = 399736239;
    Rte_Write_V_x_CamMcp_ObjID_V_x_CamMcp_ObjID(tmp_U32);
    tmp_U32 = 2219032895;
    Rte_Write_V_x_CamPed_Num_V_x_CamPed_Num(tmp_U32);
    tmp_U32 = 1588212553;
    Rte_Write_V_x_CamPed_ObjStatus_V_x_CamPed_ObjStatus(tmp_U32);
    tmp_U32 = 3116841816;
    Rte_Write_V_x_CirCamRadMatchCnt_V_x_CirCamRadMatchCnt(tmp_U32);
    tmp_U32 = 3886192555;
    Rte_Write_V_x_RadFcwa_Obj0ID_V_x_RadFcwa_Obj0ID(tmp_U32);
    tmp_U32 = 2537957601;
    Rte_Write_V_x_RadFcwa_ObjID_V_x_RadFcwa_ObjID(tmp_U32);
    tmp_U32 = 3984517071;
    Rte_Write_V_x_RadFcwa_ObjValid_V_x_RadFcwa_ObjValid(tmp_U32);
    tmp_U32 = 2488652531;
    Rte_Write_V_x_RadFcwa_Pos_V_x_RadFcwa_Pos(tmp_U32);
    tmp_U32 = 633324764;
    Rte_Write_V_x_RadPed_Num_V_x_RadPed_Num(tmp_U32);
    tmp_U8 = 64;
    Rte_Write_V_x_vRIR_Input_AEBLateCDL_V_x_vRIR_Input_AEBLateCDL(tmp_U8);
}

#include "Rte_Wrapper_Fusion.h"
void C1_1_o2o_noncache_prepare_Fusion(void)
{
    boolean tmp_B;
    float32 tmp_Fl32;
    uint8 tmp_U8;
    float32 tmp_Fl32_10[10];
    V_x_VectorCameraObjects tmp_VectorCameraObjects;

}

#include "Rte_Wrapper_FS_ACT.h"
void C1_1_o2o_noncache_prepare_FS_ACT(void)
{
    boolean tmp_B;
    uint32 tmp_U32;
    uint16 tmp_U16;
    uint8 tmp_U8;

}

#include "Rte_Wrapper_FEBFCWDBA.h"
void C1_1_o2o_noncache_prepare_FEBFCWDBA(void)
{
    boolean tmp_B;
    sint32 tmp_S32;
    sint16 tmp_S16;
    uint8 tmp_U8;
    uint16 tmp_U16;
    uint8 tmp_U8_60[60];

    tmp_S32 = -1060166432;
    Rte_Write_V_Mpa_vVC_PBRK_COM_FEB_V_Mpa_vVC_PBRK_COM_FEB(tmp_S32);
}

#include "Rte_Wrapper_LDPLDW.h"
void C1_1_o2o_noncache_prepare_LDPLDW(void)
{
    boolean tmp_B;
    sint16 tmp_S16;
    sint32 tmp_S32;
    uint16 tmp_U16;
    uint8 tmp_U8;
    float32 tmp_Fl32;

}

#include "Rte_Wrapper_BSI.h"
void C1_1_o2o_noncache_prepare_BSI(void)
{
    boolean tmp_B;
    sint32 tmp_S32;
    float32 tmp_Fl32;
    uint8 tmp_U8;

}

#include "Rte_Wrapper_DAA.h"
void C1_1_o2o_noncache_prepare_DAA(void)
{
    boolean tmp_B;
    uint8 tmp_U8;

}

#include "Rte_Wrapper_EAP.h"
void C1_1_o2o_noncache_prepare_EAP(void)
{
    boolean tmp_B;
    sint32 tmp_S32;
    float32 tmp_Fl32;
    uint8 tmp_U8;
    uint8 tmp_U8_47[47];
    uint16 tmp_U16;
    uint8 tmp_U8_5[5];

    tmp_S32 = 981007880;
    Rte_Write_V_bar_PmsBrkVal_V_bar_PmsBrkVal(tmp_S32);
}

#include "Rte_Wrapper_Control_Longi.h"
void C1_1_o2o_noncache_prepare_Control_Longi(void)
{
    boolean tmp_B;
    float32 tmp_Fl32;
    uint8 tmp_U8;
    float32 tmp_Fl32_10[10];

}

#include "Rte_Wrapper_Control_Lat.h"
void C1_1_o2o_noncache_prepare_Control_Lat(void)
{
    boolean tmp_B;
    float32 tmp_Fl32;
    uint8 tmp_U8;
    uint32 tmp_U32;
    float32 tmp_Fl32_10[10];
    sint8 tmp_S8;

}

#include "Rte_Wrapper_EDR.h"
void C1_1_o2o_noncache_prepare_EDR(void)
{
    boolean tmp_B;
    uint8 tmp_U8;
    uint8 tmp_U8_44[44];

}

#include "Rte_Wrapper_HOD.h"
void C1_1_o2o_noncache_prepare_HOD(void)
{
    boolean tmp_B;
    uint16 tmp_U16;
    float32 tmp_Fl32;
    uint8 tmp_U8;
    float32 tmp_Fl32_10[10];

}

#include "Rte_Wrapper_EHR.h"
void C1_1_o2o_noncache_prepare_EHR(void)
{
    boolean tmp_B;
    float32 tmp_Fl32;
    sint16 tmp_S16_10[10];
    float32 tmp_Fl32_10[10];
    uint8 tmp_U8_10[10];
    sint32 tmp_S32;
    V_x_Curve20_t tmp_Curve20_t;
    V_x_CurveRaw_out_t tmp_CurveRaw_out_t;
    uint8 tmp_U8;
    V_x_Detect_Context_out tmp_Detect_Context_out;
    V_x_FunctionalRoadClass_bus tmp_FunctionalRoadClass_bus;
    V_x_POS_DATA_out_t tmp_POS_DATA_out_t;
    V_x_SEG_DATA_out_t tmp_SEG_DATA_out_t;
    V_x_STUB_DATA_out_t tmp_STUB_DATA_out_t;

}

#include "Rte_Wrapper_CASP.h"
void C1_1_o2o_noncache_prepare_CASP(void)
{
    boolean tmp_B;
    float32 tmp_Fl32;
    V_x_CASPToAD1Enh tmp_CASPToAD1Enh;
    float32 tmp_Fl32_10[10];
    uint8 tmp_U8;
    uint16 tmp_U16;
    sint8 tmp_S8;

}

#include "Rte_Wrapper_APA.h"
void C1_1_o2o_noncache_prepare_APA(void)
{
    boolean tmp_B;
    float32 tmp_Fl32;
    uint8 tmp_U8;

}

#include "Rte_Wrapper_NoEntry.h"
void C1_1_o2o_noncache_prepare_NoEntry(void)
{
    boolean tmp_B;

}

#include "Rte_Wrapper_LCDN.h"
void C1_1_o2o_noncache_prepare_LCDN(void)
{
    uint8 tmp_U8;

}
