### RTE抽象化層単体テスト環境

#### 概要
全信号に対して、Read/Write　IFが開通していることを確認するテスト環境の生成、及び実施を行う。  
設定値は任意の代表値、最小値、最大値の3パターンで実施する。

#### 動作環境
* Python 3.X系
  * 必要モジュール(依存モジュール含む)
    * pandas
    * shutil
    * json
    * argparse
    * logging
	* copy
* GCC
* Google Test
  * 実行環境に事前にGoogle Testのフレームワークをビルドしておく
  * リリースサイト： https://github.com/google/googletest

    > 作業例 (Cygwin上でversion 1.8.1をインストールする場合)  
    > $ cd ~/work/googletest-release-1.8.1  
	> $ mkdir build  
	> $ cd build  
	> $ cmake ..  
	> $ make  

  * インストール先に応じてmakefile_gtest.mkを編集すること
    - GOOGLE_TEST_DIR : Google Testを解凍したトップディレクトリ (絶対パス)
	- GOOGLE_TEST_BUILD_DIR : フレームワークのビルド時に作成した作業ディレクトリ名 (相対パス)

#### 事前準備

以下をコンパイルしておく
* io
* Dummy RTE

各ディレクトリでmake、もしくは下記を実行することでコンパイル可能。

> make libs

#### 使用方法
1. ターミナル(コマンドプロンプト、BASH等)からPythonスクリプトを実行
1. 生成コードをコンパイルしてテスト実行バイナリを生成＆実行

##### スクリプト引数

* -i ファイルパス [必須]
  * RTE Signald DB もしくは RTE_DBツールから出力したテスト仕様書(SW2.0以降はこちら)
* -o 出力先ディレクトリパス [デフォルト = ./stub]
* -g GROUP
  * RTE_group [デフォルト = A]
* -r
  * 入力ファイルがRTE Signal DBかどうか
  * -iで指定するファイルがRTE Signal DBの場合はこのオプションをつけること
* -l ログレベル [デフォルト = INFO]

※-oで出力先ディレクトリを変更した場合は、MakefileのTESTCODE_DIRもそれに合わせて編集、もしくはmakeにTESTCODE_DIRの指定をして実行すること

#### 実行例

- RTE Signal DBからテストコードを生成する場合(SW1.2以前)

> $ python creteIoTest.py -g A400 -r -i ./SignalDB.xlsx  
  -> カレントディレクトリに保存したDBエクセルからテストコード生成。出力先はデフォルト。

> $ make

- テスト仕様書からテストコードを生成する場合(基本的にこちらを使用)

> $ python creteIoTest.py -i ./ADAS5_SWE3_UnitTest_Specification.xlsx -o test_stub  
  -> カレントディレクトリに保存したDBエクセルからテストコード生成。出力先は./test_stub。

> $ make　TESTCODE_DIR=test_stub

- 実行

> $ ./iotest_o2s.exe  
> $ ./iotest_s2o.exe  
> $ ./iotest_o2o_cache.exe  
> $ ./iotest_o2o_noncache.exe

#### 出力ファイル

ソースコードは下記の3種類 (ファイル数＝OEM_SWC数×テストケース)
- OEM_SWC_Cx_y_[s2o, o2s, o2o_cache, o2o_noncache](_min, _max)_prepare.c
  - テスト用変数設定
- OEM_SWC_Cx_y_[s2o, o2s, o2o_cache, o2o_noncache](_min, _max)_verify.c
  - 通信後の値チェック
- OEM_SWC_Cx_y_[s2o, o2s, o2o_cache, o2o_noncache](_min, _max)_test.c
  - テストケース (prepare→通信関数実行→verify)

テストケースの意味 (s2o, o2s, o2o_cache, o2o_noncache)
- s2o : SUP->OEM 通信
- o2s : OEM->SUP 通信
- o2o_cache : OEM->OEM 通信 (同OEM_SWC内)
- o2o_noncache : OEM->OEM 通信 (OEM_SWC間)

テスト時の設定値 (min, max, 代表値)
- min : 型毎の最小値 (limits.h, float.hで定義される最小値マクロを参照)
- max : 型毎の最大値 (limits.h, float.hで定義される最大値マクロを参照)
- 代表値 : 信号毎に1から順次インクリメントされた値。1～型毎の最大値をループさせて設定。  
　　　　booleanは0, 1の2種類しかないが、信号毎に評価できるようuint8相当の値を設定。

例
- C1_1_s2o : OEM_SWC_C1_1がSUPから受信する信号のテスト
- C2_1_o2s : OEM_SWC_C2_1がSUPに送信する信号のテスト (現状、そのような信号は存在しないので中身は空)
- C1_1_o2o_cache : OEM_SWC_C1_1間で送受信する信号のテスト
- C2_2_o2o_noncache : OEM_SWC_C2_2が他OEM_SWCに送信する信号のテスト

テスト実行バイナリは下記4種類
- iotest_s2o.exe, iotest_s2o_min.exe, iotest_s2o_max.exe
- iotest_o2s.exe, iotest_o2s_min.exe, iotest_o2s_max.exe
- iotest_o2o_cache.exe, iotest_o2o_cache_min.exe, iotest_o2o_cache_max.exe
- iotest_o2o_noncache.exe, iotest_o2o_noncache_min.exe, iotest_o2o_noncache_max.exe

#### テストパターン

- SUP->OEM : Dummy RTEに設定された値が抽象化層の変数に設定されていることを確認  
  テスト対象 : OEM_SWC_[C0_SM, C1_1, C2_1, C2_2, C2_3]_input_From_SUP
  - SUP->OEM_SWC_C0_SM
  - SUP->OEM_SWC_C1_1
  - SUP->OEM_SWC_C2_1
  - SUP->OEM_SWC_C2_2
  - SUP->OEM_SWC_C2_3

- OEM->SUP : 抽象化層の変数に設定された値がDummy RTEの変数に設定されていることを確認  
  テスト対象 : OEM_SWC_[C0_SM, C1_1, C2_1, C2_2, C2_3]_output
  - OEM_SWC_C0_SM->SUP
  - OEM_SWC_C1_1->SUP
  - OEM_SWC_C2_1->SUP
  - OEM_SWC_C2_2->SUP
  - OEM_SWC_C2_3->SUP

- OEM->OEM(cache) : Rte_Writeした値が抽象化層のバッファに反映されていること、及びRte_Readで読めることを確認  
  テスト対象 : Rte_Read/Write I/F
  - OEM_SWC_C0_SM->OEM_SWC_C0_SM
  - OEM_SWC_C1_1->OEM_SWC_C1_1
  - OEM_SWC_C2_1->OEM_SWC_C2_1
  - OEM_SWC_C2_2->OEM_SWC_C2_2
  - OEM_SWC_C2_3->OEM_SWC_C2_3

- OEM->OEM(noncache) : Rte_Writeした値が抽象化層のバッファに反映されていること、及びRte_Readで読めることを確認  
  テスト対象 : Rte_Read/Write I/F、OEM_SWC_[C0_SM, C1_1, C2_1, C2_2, C2_3]_input_From_OEM
  - OEM_SWC_C0_SM->他OEM_SWC
  - OEM_SWC_C1_1->他OEM_SWC
  - OEM_SWC_C2_1->他OEM_SWC
  - OEM_SWC_C2_2->他OEM_SWC
  - OEM_SWC_C2_3->他OEM_SWC

#### 処理内容

1. 信号情報取得
   - 対象Groupが"1"となっている信号を対象として、全信号の情報を取得  
     - 送信SWC毎にグルーピング、受信SWCのリストを記憶
2. テスト用コード生成
   - 取得した情報をSWC単位でprepare、verify関数を出力  
     - 受信SWCに応じてテストケースを判別　　
	 - verifyはGoogle Testの評価I/F(EXPECT_EQマクロ)に渡す
   - SWC単位で出力した関数をすべて呼び出すprepare、verify関数を出力  
     - prepare->通信関数->verifyと順次実行するテストケース関数を生成
	 - テストケース関数はGoogle Testのテストケース生成I/F(TESTマクロ)に渡す

#### その他

##### DBとDummy RTEの不整合時

DBとDummy RTEに不整合があり、リンクエラーになる場合は、
下記ファイルにport名の変換を記述することで生成コードを修正可能

- port_rw_replacement.json
  - Rte_Read/Writeに続くポート名を置換
- port_var_replacement.json
  - Dummy RTEの変数名に使われるポート名を置換

上記ファイルを削除、もしくは記述を削除することで本機能は無効化される。
