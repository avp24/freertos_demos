#include "gtest/gtest.h"

#include "Rte_DiagControl.h"

extern "C" {
extern void OEM_SWC_C1_1_output();
}

void prepare_test_write_sup_to_oem_c1()
{
	boolean tmp_B;

	tmp_B = 100;
	Rte_Write_F_x_Exe_SenSonar_B_F_x_Exe_SenSonar_B(tmp_B);
}

extern VAR(Boolean, RTE_VAR_INIT) Rte_OEM_SWC_C1_1_F_x_Exe_SenSonar_B_F_x_Exe_SenSonar_B;
void test_write_sup_to_oem_c1()
{
	EXPECT_EQ(Rte_OEM_SWC_C1_1_F_x_Exe_SenSonar_B_F_x_Exe_SenSonar_B, 100);
}

#if 0
TEST(IOTest, OutputSup)
{
    prepare_test_write_sup_to_oem_c1();
    OEM_SWC_C1_1_output();
    test_write_sup_to_oem_c1();
}
#endif

TEST(IOTest, s2o_c1)
{
    prepare_test_write_sup_to_oem_c1();
    OEM_SWC_C1_1_output();
    test_write_sup_to_oem_c1();
}
