/**********************************************************************************************************************
 *  COPYRIGHT
 *  -------------------------------------------------------------------------------------------------------------------
 *
 *                This software is copyright protected and proprietary to Vector Informatik GmbH.
 *                Vector Informatik GmbH grants to you only those rights as set out in the license conditions.
 *                All other rights remain with Vector Informatik GmbH.
 *  -------------------------------------------------------------------------------------------------------------------
 *  FILE DESCRIPTION
 *  -------------------------------------------------------------------------------------------------------------------
 *          File:  Rte_Type.h
 *        Config:  ADAS31Ms.dpa
 *   ECU-Project:  ADAS
 *
 *     Generator:  MICROSAR RTE Generator Version 4.10.0
 *                 RTE Core Version 1.10.0
 *       License:  Unlimited license CBD1500900 for Panasonic Corporation
 *
 *   Description:  Header file containing user defined AUTOSAR types and RTE structures
 *********************************************************************************************************************/

/* double include prevention */
#ifndef _RTE_TYPE_H
# define _RTE_TYPE_H

# include "Rte.h"

#ifndef _RTE_PRM_H_INCLUDE
# define _RTE_PRM_H_INCLUDE
#include "Rte_Prm.h"
#endif	/* _RTE_PRM_H_INCLUDE

/**********************************************************************************************************************
 * Data type definitions
 *********************************************************************************************************************/

# define Rte_TypeDef_Boolean
typedef boolean Boolean;

# define Rte_TypeDef_Float
typedef float32 Float;

# define Rte_TypeDef_SInt16
typedef sint16 SInt16;

# define Rte_TypeDef_SInt32
typedef sint32 SInt32;

# define Rte_TypeDef_SInt8
typedef sint8 SInt8;

#define Rte_TypeDef_SInt64
typedef sint64 SInt64;

# define Rte_TypeDef_UInt16
typedef uint16 UInt16;

# define Rte_TypeDef_UInt32
typedef uint32 UInt32;

# define Rte_TypeDef_UInt8
typedef uint8 UInt8;

#define Rte_TypeDef_UInt64
typedef uint64 UInt64;

# define Rte_TypeDef_WdgM_CheckpointIdType
typedef uint16 WdgM_CheckpointIdType;

# define Rte_TypeDef_WdgM_ModeType
typedef uint8 WdgM_ModeType;

# define Rte_TypeDef_WdgM_SupervisedEntityIdType
typedef uint16 WdgM_SupervisedEntityIdType;

# define Rte_TypeDef_boolean_NP
typedef boolean boolean_NP;

# define Rte_TypeDef_dtRef_VOID
typedef void * dtRef_VOID;

# define Rte_TypeDef_dtRef_const_VOID
typedef const void * dtRef_const_VOID;

# define Rte_TypeDef_float32_NP
typedef float32 float32_NP;

# define Rte_TypeDef_sint16_NP
typedef sint16 sint16_NP;

# define Rte_TypeDef_sint32_NP
typedef sint32 sint32_NP;

# define Rte_TypeDef_uint16_NP
typedef uint16 uint16_NP;

# define Rte_TypeDef_uint32_NP
typedef uint32 uint32_NP;

# define Rte_TypeDef_uint8_NP
typedef uint8 uint8_NP;

# define Rte_TypeDef_Mcal_FlsStatusType
typedef uint8 Mcal_FlsStatusType;

# define Rte_TypeDef_NvM_RequestResultType
typedef uint8 NvM_RequestResultType;

# define Rte_TypeDef_WdgM_GlobalStatusType
typedef uint8 WdgM_GlobalStatusType;

# define Rte_TypeDef_WdgM_LocalStatusType
typedef uint8 WdgM_LocalStatusType;

# define Rte_TypeDef_DataArray_Type_1
typedef uint8 DataArray_Type_1[1];

# define Rte_TypeDef_Dcm_Data10ByteType
typedef uint8 Dcm_Data10ByteType[10];

# define Rte_TypeDef_Dcm_Data17ByteType
typedef uint8 Dcm_Data17ByteType[17];

# define Rte_TypeDef_Dcm_Data1ByteType
typedef uint8 Dcm_Data1ByteType[1];

# define Rte_TypeDef_Dcm_Data20ByteType
typedef uint8 Dcm_Data20ByteType[20];

# define Rte_TypeDef_Dcm_Data2ByteType
typedef uint8 Dcm_Data2ByteType[2];

# define Rte_TypeDef_Dcm_Data315ByteType
typedef uint8 Dcm_Data315ByteType[315];

# define Rte_TypeDef_Dcm_Data32ByteType
typedef uint8 Dcm_Data32ByteType[32];

# define Rte_TypeDef_Dcm_Data3ByteType
typedef uint8 Dcm_Data3ByteType[3];

# define Rte_TypeDef_Dcm_Data4ByteType
typedef uint8 Dcm_Data4ByteType[4];

# define Rte_TypeDef_Dcm_Data516ByteType
typedef uint8 Dcm_Data516ByteType[516];

# define Rte_TypeDef_Dcm_Data600ByteType
typedef uint8 Dcm_Data600ByteType[600];

# define Rte_TypeDef_Dcm_Data60ByteType
typedef uint8 Dcm_Data60ByteType[60];

# define Rte_TypeDef_Dcm_Data64ByteType
typedef uint8 Dcm_Data64ByteType[64];

# define Rte_TypeDef_Dcm_Data68ByteType
typedef uint8 Dcm_Data68ByteType[68];

# define Rte_TypeDef_Dem_MaxDataValueType
typedef uint8 Dem_MaxDataValueType[3];

# define Rte_TypeDef_UDSCP_SigmaVSsdType
typedef uint8 UDSCP_SigmaVSsdType[63];

# define Rte_TypeDef_UDSCP_SigmaVTddType
typedef uint8 UDSCP_SigmaVTddType[68];

# define Rte_TypeDef_UDSCP_VinType
typedef uint8_NP UDSCP_VinType[17];

# define Rte_TypeDef_rt_Array_SInt16_10
typedef SInt16 rt_Array_SInt16_10[10];

# define Rte_TypeDef_rt_Array_SInt16_11
typedef SInt16 rt_Array_SInt16_11[11];

# define Rte_TypeDef_rt_Array_SInt16_19
typedef SInt16 rt_Array_SInt16_19[19];

# define Rte_TypeDef_rt_Array_SInt16_28
typedef SInt16 rt_Array_SInt16_28[28];

# define Rte_TypeDef_rt_Array_SInt32_16
typedef SInt32 rt_Array_SInt32_16[16];

# define Rte_TypeDef_rt_Array_SInt32_18
typedef SInt32 rt_Array_SInt32_18[18];

# define Rte_TypeDef_rt_Array_SInt32_19
typedef SInt32 rt_Array_SInt32_19[19];

# define Rte_TypeDef_rt_Array_SInt32_2
typedef SInt32 rt_Array_SInt32_2[2];

# define Rte_TypeDef_rt_Array_SInt32_20
typedef SInt32 rt_Array_SInt32_20[20];

# define Rte_TypeDef_rt_Array_SInt32_4
typedef SInt32 rt_Array_SInt32_4[4];

# define Rte_TypeDef_rt_Array_SInt32_46
typedef SInt32 rt_Array_SInt32_46[46];

# define Rte_TypeDef_rt_Array_SInt32_6
typedef SInt32 rt_Array_SInt32_6[6];

# define Rte_TypeDef_rt_Array_UInt16_4
typedef UInt16 rt_Array_UInt16_4[4];

# define Rte_TypeDef_rt_Array_UInt8_10
typedef uint8_NP rt_Array_UInt8_10[10];

# define Rte_TypeDef_rt_Array_UInt8_11
typedef uint8_NP rt_Array_UInt8_11[11];

# define Rte_TypeDef_rt_Array_UInt8_110
typedef UInt8 rt_Array_UInt8_110[110];

# define Rte_TypeDef_rt_Array_UInt8_148
typedef UInt8 rt_Array_UInt8_148[148];

# define Rte_TypeDef_rt_Array_UInt8_16
typedef UInt8 rt_Array_UInt8_16[16];

# define Rte_TypeDef_rt_Array_UInt8_18;
typedef UInt8 rt_Array_UInt8_18[18];

# define Rte_TypeDef_rt_Array_UInt8_20;
typedef UInt8 rt_Array_UInt8_20[20];

# define Rte_TypeDef_rt_Array_UInt8_2
typedef uint8_NP rt_Array_UInt8_2[2];

# define Rte_TypeDef_rt_Array_UInt8_276
typedef uint8_NP rt_Array_UInt8_276[276];

# define Rte_TypeDef_rt_Array_UInt8_300
typedef uint8_NP rt_Array_UInt8_300[300];

# define Rte_TypeDef_rt_Array_UInt8_320
typedef uint8_NP rt_Array_UInt8_320[320];

# define Rte_TypeDef_rt_Array_UInt8_40
typedef UInt8 rt_Array_UInt8_40[40];

# define Rte_TypeDef_rt_Array_UInt8_44
typedef UInt8 rt_Array_UInt8_44[44];

# define Rte_TypeDef_rt_Array_UInt8_47
typedef UInt8 rt_Array_UInt8_47[47];

# define Rte_TypeDef_rt_Array_UInt8_48
typedef uint8_NP rt_Array_UInt8_48[48];

# define Rte_TypeDef_rt_Array_UInt8_5
typedef uint8_NP rt_Array_UInt8_5[5];

# define Rte_TypeDef_rt_Array_UInt8_516
typedef uint8_NP rt_Array_UInt8_516[516];

# define Rte_TypeDef_rt_Array_UInt8_6
typedef uint8_NP rt_Array_UInt8_6[6];

# define Rte_TypeDef_rt_Array_UInt8_60
typedef uint8_NP rt_Array_UInt8_60[60];

# define Rte_TypeDef_rt_Array_UInt8_64
typedef UInt8 rt_Array_UInt8_64[64];

# define Rte_TypeDef_rt_Array_float32_2
typedef float32 rt_Array_float32_2[2];

# define Rte_TypeDef_rt_Array_float32_10
typedef float32 rt_Array_float32_10[10];

# define Rte_TypeDef_rt_Array_UInt8_8
typedef uint8_NP rt_Array_UInt8_8[8];

# define Rte_TypeDef_RecSg020_NP
typedef struct
{
  uint8_NP SrU8020data0Pos;
  uint8_NP SrU8020data1Pos;
  uint8_NP SrU8020data2Pos;
  uint8_NP SrU8020data3Pos;
  uint8_NP SrU8020data4Pos;
  uint8_NP SrU8020data5Pos;
  uint8_NP SrU8020data6Pos;
  uint8_NP SrU8020data7Pos;
} RecSg020_NP;

# define Rte_TypeDef_RecSg09F_NP
typedef struct
{
  uint8_NP SrU809Fdata0Pos;
  uint8_NP SrU809Fdata1Pos;
  uint8_NP SrU809Fdata2Pos;
  uint8_NP SrU809Fdata3Pos;
  uint8_NP SrU809Fdata4Pos;
} RecSg09F_NP;

# define Rte_TypeDef_RecSg0A0_NP
typedef struct
{
  uint8_NP SrU80A0data0Pos;
  uint8_NP SrU80A0data1Pos;
  uint8_NP SrU80A0data2Pos;
  uint8_NP SrU80A0data3Pos;
  uint8_NP SrU80A0data4Pos;
  uint8_NP SrU80A0data5Pos;
  uint8_NP SrU80A0data6Pos;
  uint8_NP SrU80A0data7Pos;
} RecSg0A0_NP;

# define Rte_TypeDef_RecSg0A4_NP
typedef struct
{
  uint8_NP SrU80A4data0Pos;
  uint8_NP SrU80A4data1Pos;
  uint8_NP SrU80A4data2Pos;
  uint8_NP SrU80A4data3Pos;
  uint8_NP SrU80A4data4Pos;
} RecSg0A4_NP;

# define Rte_TypeDef_RecSg0A6_NP
typedef struct
{
  uint8_NP SrU80A6data0Pos;
  uint8_NP SrU80A6data1Pos;
  uint8_NP SrU80A6data2Pos;
  uint8_NP SrU80A6data3Pos;
  uint8_NP SrU80A6data4Pos;
  uint8_NP SrU80A6data5Pos;
  uint8_NP SrU80A6data6Pos;
  uint8_NP SrU80A6data7Pos;
} RecSg0A6_NP;

# define Rte_TypeDef_RecSg0A7_NP
typedef struct
{
  uint8_NP SrU80A7data0Pos;
  uint8_NP SrU80A7data1Pos;
  uint8_NP SrU80A7data2Pos;
  uint8_NP SrU80A7data3Pos;
  uint8_NP SrU80A7data4Pos;
  uint8_NP SrU80A7data5Pos;
  uint8_NP SrU80A7data6Pos;
  uint8_NP SrU80A7data7Pos;
} RecSg0A7_NP;

# define Rte_TypeDef_RecSg0A8_NP
typedef struct
{
  uint8_NP SrU80A8data0Pos;
  uint8_NP SrU80A8data1Pos;
  uint8_NP SrU80A8data2Pos;
  uint8_NP SrU80A8data3Pos;
  uint8_NP SrU80A8data4Pos;
  uint8_NP SrU80A8data5Pos;
  uint8_NP SrU80A8data6Pos;
} RecSg0A8_NP;

# define Rte_TypeDef_RecSg0AA_NP
typedef struct
{
  uint8_NP SrU80AAdata0Pos;
  uint8_NP SrU80AAdata1Pos;
  uint8_NP SrU80AAdata2Pos;
  uint8_NP SrU80AAdata3Pos;
  uint8_NP SrU80AAdata4Pos;
  uint8_NP SrU80AAdata5Pos;
  uint8_NP SrU80AAdata6Pos;
  uint8_NP SrU80AAdata7Pos;
} RecSg0AA_NP;

# define Rte_TypeDef_RecSg0AB_NP
typedef struct
{
  uint8_NP SrU80ABdata0Pos;
  uint8_NP SrU80ABdata1Pos;
  uint8_NP SrU80ABdata2Pos;
  uint8_NP SrU80ABdata3Pos;
  uint8_NP SrU80ABdata4Pos;
  uint8_NP SrU80ABdata5Pos;
  uint8_NP SrU80ABdata6Pos;
  uint8_NP SrU80ABdata7Pos;
} RecSg0AB_NP;

# define Rte_TypeDef_RecSg0AC_NP
typedef struct
{
  uint8_NP SrU80ACdata0Pos;
  uint8_NP SrU80ACdata1Pos;
  uint8_NP SrU80ACdata2Pos;
  uint8_NP SrU80ACdata3Pos;
  uint8_NP SrU80ACdata4Pos;
  uint8_NP SrU80ACdata5Pos;
  uint8_NP SrU80ACdata6Pos;
  uint8_NP SrU80ACdata7Pos;
} RecSg0AC_NP;

# define Rte_TypeDef_RecSg0B1_NP
typedef struct
{
  uint8_NP SrU80B1data0Pos;
  uint8_NP SrU80B1data1Pos;
  uint8_NP SrU80B1data2Pos;
  uint8_NP SrU80B1data3Pos;
  uint8_NP SrU80B1data4Pos;
  uint8_NP SrU80B1data5Pos;
  uint8_NP SrU80B1data6Pos;
} RecSg0B1_NP;

# define Rte_TypeDef_RecSg0B2_NP
typedef struct
{
  uint8_NP SrU80B2data0Pos;
  uint8_NP SrU80B2data1Pos;
  uint8_NP SrU80B2data2Pos;
  uint8_NP SrU80B2data3Pos;
  uint8_NP SrU80B2data4Pos;
  uint8_NP SrU80B2data5Pos;
  uint8_NP SrU80B2data6Pos;
  uint8_NP SrU80B2data7Pos;
} RecSg0B2_NP;

# define Rte_TypeDef_RecSg0B4_NP
typedef struct
{
  uint8_NP SrU80B4data0Pos;
  uint8_NP SrU80B4data1Pos;
  uint8_NP SrU80B4data2Pos;
  uint8_NP SrU80B4data3Pos;
  uint8_NP SrU80B4data4Pos;
  uint8_NP SrU80B4data5Pos;
  uint8_NP SrU80B4data6Pos;
  uint8_NP SrU80B4data7Pos;
} RecSg0B4_NP;

# define Rte_TypeDef_RecSg0B6_NP
typedef struct
{
  uint8_NP SrU80B6data0Pos;
  uint8_NP SrU80B6data1Pos;
  uint8_NP SrU80B6data2Pos;
  uint8_NP SrU80B6data3Pos;
  uint8_NP SrU80B6data4Pos;
  uint8_NP SrU80B6data5Pos;
  uint8_NP SrU80B6data6Pos;
  uint8_NP SrU80B6data7Pos;
} RecSg0B6_NP;

# define Rte_TypeDef_RecSg0B7_NP
typedef struct
{
  uint8_NP SrU80B7data0Pos;
  uint8_NP SrU80B7data1Pos;
  uint8_NP SrU80B7data2Pos;
  uint8_NP SrU80B7data3Pos;
  uint8_NP SrU80B7data4Pos;
  uint8_NP SrU80B7data5Pos;
  uint8_NP SrU80B7data6Pos;
  uint8_NP SrU80B7data7Pos;
} RecSg0B7_NP;

# define Rte_TypeDef_RecSg0FF_NP
typedef struct
{
  uint8_NP SrU80FFdata0Pos;
  uint8_NP SrU80FFdata1Pos;
  uint8_NP SrU80FFdata2Pos;
  uint8_NP SrU80FFdata3Pos;
  uint8_NP SrU80FFdata4Pos;
  uint8_NP SrU80FFdata5Pos;
} RecSg0FF_NP;

# define Rte_TypeDef_RecSg202_NP
typedef struct
{
  uint8_NP SrU8202data0Pos;
  uint8_NP SrU8202data1Pos;
  uint8_NP SrU8202data2Pos;
  uint8_NP SrU8202data3Pos;
  uint8_NP SrU8202data4Pos;
  uint8_NP SrU8202data5Pos;
  uint8_NP SrU8202data6Pos;
  uint8_NP SrU8202data7Pos;
} RecSg202_NP;

# define Rte_TypeDef_RecSg205_NP
typedef struct
{
  uint8_NP SrU8205data0Pos;
  uint8_NP SrU8205data1Pos;
  uint8_NP SrU8205data2Pos;
  uint8_NP SrU8205data3Pos;
  uint8_NP SrU8205data4Pos;
  uint8_NP SrU8205data5Pos;
  uint8_NP SrU8205data6Pos;
  uint8_NP SrU8205data7Pos;
} RecSg205_NP;

# define Rte_TypeDef_RecSg207_NP
typedef struct
{
  uint8_NP SrU8207data0Pos;
  uint8_NP SrU8207data1Pos;
  uint8_NP SrU8207data2Pos;
  uint8_NP SrU8207data3Pos;
  uint8_NP SrU8207data4Pos;
  uint8_NP SrU8207data5Pos;
  uint8_NP SrU8207data6Pos;
  uint8_NP SrU8207data7Pos;
} RecSg207_NP;

# define Rte_TypeDef_RecSg21D_NP
typedef struct
{
  uint8_NP SrU821Ddata0Pos;
  uint8_NP SrU821Ddata1Pos;
  uint8_NP SrU821Ddata2Pos;
  uint8_NP SrU821Ddata3Pos;
  uint8_NP SrU821Ddata4Pos;
  uint8_NP SrU821Ddata5Pos;
  uint8_NP SrU821Ddata6Pos;
  uint8_NP SrU821Ddata7Pos;
} RecSg21D_NP;

# define Rte_TypeDef_RecSg21E_NP
typedef struct
{
  uint8_NP SrU821Edata0Pos;
  uint8_NP SrU821Edata1Pos;
  uint8_NP SrU821Edata2Pos;
  uint8_NP SrU821Edata3Pos;
  uint8_NP SrU821Edata4Pos;
  uint8_NP SrU821Edata5Pos;
  uint8_NP SrU821Edata6Pos;
  uint8_NP SrU821Edata7Pos;
} RecSg21E_NP;

# define Rte_TypeDef_RecSg21F_NP
typedef struct
{
  uint8_NP SrU821Fdata0Pos;
  uint8_NP SrU821Fdata1Pos;
  uint8_NP SrU821Fdata2Pos;
  uint8_NP SrU821Fdata3Pos;
  uint8_NP SrU821Fdata4Pos;
  uint8_NP SrU821Fdata5Pos;
  uint8_NP SrU821Fdata6Pos;
  uint8_NP SrU821Fdata7Pos;
} RecSg21F_NP;

# define Rte_TypeDef_RecSg220_NP
typedef struct
{
  uint8_NP SrU8220data0Pos;
  uint8_NP SrU8220data1Pos;
  uint8_NP SrU8220data2Pos;
  uint8_NP SrU8220data3Pos;
  uint8_NP SrU8220data4Pos;
  uint8_NP SrU8220data5Pos;
  uint8_NP SrU8220data6Pos;
  uint8_NP SrU8220data7Pos;
} RecSg220_NP;

# define Rte_TypeDef_RecSg222_NP
typedef struct
{
  uint8_NP SrU8222data0Pos;
  uint8_NP SrU8222data1Pos;
  uint8_NP SrU8222data2Pos;
  uint8_NP SrU8222data3Pos;
  uint8_NP SrU8222data4Pos;
  uint8_NP SrU8222data5Pos;
  uint8_NP SrU8222data6Pos;
  uint8_NP SrU8222data7Pos;
} RecSg222_NP;

# define Rte_TypeDef_RecSg223_NP
typedef struct
{
  uint8_NP SrU8223data0Pos;
  uint8_NP SrU8223data1Pos;
  uint8_NP SrU8223data2Pos;
  uint8_NP SrU8223data3Pos;
  uint8_NP SrU8223data4Pos;
  uint8_NP SrU8223data5Pos;
  uint8_NP SrU8223data6Pos;
  uint8_NP SrU8223data7Pos;
} RecSg223_NP;

# define Rte_TypeDef_RecSg240_NP
typedef struct
{
  uint8_NP SrU8240data0Pos;
  uint8_NP SrU8240data1Pos;
  uint8_NP SrU8240data2Pos;
  uint8_NP SrU8240data3Pos;
  uint8_NP SrU8240data4Pos;
  uint8_NP SrU8240data5Pos;
  uint8_NP SrU8240data6Pos;
  uint8_NP SrU8240data7Pos;
} RecSg240_NP;

# define Rte_TypeDef_RecSg241_NP
typedef struct
{
  uint8_NP SrU8241data0Pos;
  uint8_NP SrU8241data1Pos;
  uint8_NP SrU8241data2Pos;
  uint8_NP SrU8241data3Pos;
  uint8_NP SrU8241data4Pos;
  uint8_NP SrU8241data5Pos;
  uint8_NP SrU8241data6Pos;
  uint8_NP SrU8241data7Pos;
} RecSg241_NP;

# define Rte_TypeDef_RecSg246_NP
typedef struct
{
  uint8_NP SrU8246data0Pos;
  uint8_NP SrU8246data1Pos;
  uint8_NP SrU8246data2Pos;
  uint8_NP SrU8246data3Pos;
  uint8_NP SrU8246data4Pos;
  uint8_NP SrU8246data5Pos;
  uint8_NP SrU8246data6Pos;
  uint8_NP SrU8246data7Pos;
} RecSg246_NP;

# define Rte_TypeDef_RecSg247_NP
typedef struct
{
  uint8_NP SrU8247data0Pos;
  uint8_NP SrU8247data1Pos;
  uint8_NP SrU8247data2Pos;
  uint8_NP SrU8247data3Pos;
  uint8_NP SrU8247data4Pos;
  uint8_NP SrU8247data5Pos;
  uint8_NP SrU8247data6Pos;
  uint8_NP SrU8247data7Pos;
} RecSg247_NP;

# define Rte_TypeDef_RecSg248_NP
typedef struct
{
  uint8_NP SrU8248data0Pos;
  uint8_NP SrU8248data1Pos;
  uint8_NP SrU8248data2Pos;
  uint8_NP SrU8248data3Pos;
  uint8_NP SrU8248data4Pos;
  uint8_NP SrU8248data5Pos;
  uint8_NP SrU8248data6Pos;
  uint8_NP SrU8248data7Pos;
} RecSg248_NP;

# define Rte_TypeDef_RecSg24A_NP
typedef struct
{
  uint8_NP SrU824Adata0Pos;
  uint8_NP SrU824Adata1Pos;
  uint8_NP SrU824Adata2Pos;
  uint8_NP SrU824Adata3Pos;
  uint8_NP SrU824Adata4Pos;
  uint8_NP SrU824Adata5Pos;
  uint8_NP SrU824Adata6Pos;
  uint8_NP SrU824Adata7Pos;
} RecSg24A_NP;

# define Rte_TypeDef_RecSg24B_NP
typedef struct
{
  uint8_NP SrU824Bdata0Pos;
  uint8_NP SrU824Bdata1Pos;
  uint8_NP SrU824Bdata2Pos;
  uint8_NP SrU824Bdata3Pos;
  uint8_NP SrU824Bdata4Pos;
  uint8_NP SrU824Bdata5Pos;
  uint8_NP SrU824Bdata6Pos;
  uint8_NP SrU824Bdata7Pos;
} RecSg24B_NP;

# define Rte_TypeDef_RecSg24C_NP
typedef struct
{
  uint8_NP SrU824Cdata0Pos;
  uint8_NP SrU824Cdata1Pos;
  uint8_NP SrU824Cdata2Pos;
  uint8_NP SrU824Cdata3Pos;
  uint8_NP SrU824Cdata4Pos;
  uint8_NP SrU824Cdata5Pos;
  uint8_NP SrU824Cdata6Pos;
  uint8_NP SrU824Cdata7Pos;
} RecSg24C_NP;

# define Rte_TypeDef_RecSg24D_NP
typedef struct
{
  uint8_NP SrU824Ddata0Pos;
  uint8_NP SrU824Ddata1Pos;
  uint8_NP SrU824Ddata2Pos;
  uint8_NP SrU824Ddata3Pos;
  uint8_NP SrU824Ddata4Pos;
  uint8_NP SrU824Ddata5Pos;
  uint8_NP SrU824Ddata6Pos;
  uint8_NP SrU824Ddata7Pos;
} RecSg24D_NP;

# define Rte_TypeDef_RecSg24E_NP
typedef struct
{
  uint8_NP SrU824Edata0Pos;
  uint8_NP SrU824Edata1Pos;
  uint8_NP SrU824Edata2Pos;
  uint8_NP SrU824Edata3Pos;
  uint8_NP SrU824Edata4Pos;
  uint8_NP SrU824Edata5Pos;
  uint8_NP SrU824Edata6Pos;
  uint8_NP SrU824Edata7Pos;
} RecSg24E_NP;

# define Rte_TypeDef_RecSg24F_NP
typedef struct
{
  uint8_NP SrU824Fdata0Pos;
  uint8_NP SrU824Fdata1Pos;
  uint8_NP SrU824Fdata2Pos;
  uint8_NP SrU824Fdata3Pos;
  uint8_NP SrU824Fdata4Pos;
  uint8_NP SrU824Fdata5Pos;
  uint8_NP SrU824Fdata6Pos;
  uint8_NP SrU824Fdata7Pos;
} RecSg24F_NP;

# define Rte_TypeDef_RecSg250_NP
typedef struct
{
  uint8_NP SrU8250data0Pos;
  uint8_NP SrU8250data1Pos;
  uint8_NP SrU8250data2Pos;
  uint8_NP SrU8250data3Pos;
  uint8_NP SrU8250data4Pos;
  uint8_NP SrU8250data5Pos;
  uint8_NP SrU8250data6Pos;
  uint8_NP SrU8250data7Pos;
} RecSg250_NP;

# define Rte_TypeDef_RecSg25B_NP
typedef struct
{
  uint8_NP SrU825Bdata0Pos;
  uint8_NP SrU825Bdata1Pos;
  uint8_NP SrU825Bdata2Pos;
  uint8_NP SrU825Bdata3Pos;
  uint8_NP SrU825Bdata4Pos;
  uint8_NP SrU825Bdata5Pos;
} RecSg25B_NP;

# define Rte_TypeDef_RecSg25C_NP
typedef struct
{
  uint8_NP SrU825Cdata0Pos;
  uint8_NP SrU825Cdata1Pos;
  uint8_NP SrU825Cdata2Pos;
  uint8_NP SrU825Cdata3Pos;
} RecSg25C_NP;

# define Rte_TypeDef_RecSg25E_NP
typedef struct
{
  uint8_NP SrU825Edata0Pos;
  uint8_NP SrU825Edata1Pos;
  uint8_NP SrU825Edata2Pos;
  uint8_NP SrU825Edata3Pos;
} RecSg25E_NP;

# define Rte_TypeDef_RecSg262_NP
typedef struct
{
  uint8_NP SrU8262data0Pos;
  uint8_NP SrU8262data1Pos;
  uint8_NP SrU8262data2Pos;
  uint8_NP SrU8262data3Pos;
  uint8_NP SrU8262data4Pos;
  uint8_NP SrU8262data5Pos;
  uint8_NP SrU8262data6Pos;
  uint8_NP SrU8262data7Pos;
} RecSg262_NP;

# define Rte_TypeDef_RecSg263_NP
typedef struct
{
  uint8_NP SrU8263data0Pos;
  uint8_NP SrU8263data1Pos;
  uint8_NP SrU8263data2Pos;
  uint8_NP SrU8263data3Pos;
  uint8_NP SrU8263data4Pos;
  uint8_NP SrU8263data5Pos;
  uint8_NP SrU8263data6Pos;
  uint8_NP SrU8263data7Pos;
} RecSg263_NP;

# define Rte_TypeDef_RecSg264_NP
typedef struct
{
  uint8_NP SrU8264data0Pos;
  uint8_NP SrU8264data1Pos;
  uint8_NP SrU8264data2Pos;
  uint8_NP SrU8264data3Pos;
  uint8_NP SrU8264data4Pos;
  uint8_NP SrU8264data5Pos;
  uint8_NP SrU8264data6Pos;
  uint8_NP SrU8264data7Pos;
} RecSg264_NP;

# define Rte_TypeDef_RecSg266_NP
typedef struct
{
  uint8_NP SrU8266data0Pos;
  uint8_NP SrU8266data1Pos;
  uint8_NP SrU8266data2Pos;
  uint8_NP SrU8266data3Pos;
  uint8_NP SrU8266data4Pos;
  uint8_NP SrU8266data5Pos;
  uint8_NP SrU8266data6Pos;
  uint8_NP SrU8266data7Pos;
} RecSg266_NP;

# define Rte_TypeDef_RecSg267_NP
typedef struct
{
  uint8_NP SrU8267data0Pos;
  uint8_NP SrU8267data1Pos;
  uint8_NP SrU8267data2Pos;
  uint8_NP SrU8267data3Pos;
  uint8_NP SrU8267data4Pos;
  uint8_NP SrU8267data5Pos;
  uint8_NP SrU8267data6Pos;
  uint8_NP SrU8267data7Pos;
} RecSg267_NP;

# define Rte_TypeDef_RecSg268_NP
typedef struct
{
  uint8_NP SrU8268data0Pos;
  uint8_NP SrU8268data1Pos;
  uint8_NP SrU8268data2Pos;
  uint8_NP SrU8268data3Pos;
  uint8_NP SrU8268data4Pos;
  uint8_NP SrU8268data5Pos;
  uint8_NP SrU8268data6Pos;
  uint8_NP SrU8268data7Pos;
} RecSg268_NP;

# define Rte_TypeDef_RecSg269_NP
typedef struct
{
  uint8_NP SrU8269data0Pos;
  uint8_NP SrU8269data1Pos;
  uint8_NP SrU8269data2Pos;
  uint8_NP SrU8269data3Pos;
  uint8_NP SrU8269data4Pos;
  uint8_NP SrU8269data5Pos;
  uint8_NP SrU8269data6Pos;
  uint8_NP SrU8269data7Pos;
} RecSg269_NP;

# define Rte_TypeDef_RecSg26E_NP
typedef struct
{
  uint8_NP SrU826Edata0Pos;
  uint8_NP SrU826Edata1Pos;
  uint8_NP SrU826Edata2Pos;
  uint8_NP SrU826Edata3Pos;
  uint8_NP SrU826Edata4Pos;
  uint8_NP SrU826Edata5Pos;
  uint8_NP SrU826Edata6Pos;
  uint8_NP SrU826Edata7Pos;
} RecSg26E_NP;

# define Rte_TypeDef_RecSg26F_NP
typedef struct
{
  uint8_NP SrU826Fdata0Pos;
  uint8_NP SrU826Fdata1Pos;
  uint8_NP SrU826Fdata2Pos;
  uint8_NP SrU826Fdata3Pos;
  uint8_NP SrU826Fdata4Pos;
  uint8_NP SrU826Fdata5Pos;
  uint8_NP SrU826Fdata6Pos;
  uint8_NP SrU826Fdata7Pos;
} RecSg26F_NP;

# define Rte_TypeDef_RecSg289_NP
typedef struct
{
  uint8_NP SrU8289data0Pos;
  uint8_NP SrU8289data1Pos;
  uint8_NP SrU8289data2Pos;
  uint8_NP SrU8289data3Pos;
  uint8_NP SrU8289data4Pos;
  uint8_NP SrU8289data5Pos;
  uint8_NP SrU8289data6Pos;
  uint8_NP SrU8289data7Pos;
} RecSg289_NP;

# define Rte_TypeDef_RecSg28A_NP
typedef struct
{
  uint8_NP SrU828Adata0Pos;
  uint8_NP SrU828Adata1Pos;
  uint8_NP SrU828Adata2Pos;
  uint8_NP SrU828Adata3Pos;
  uint8_NP SrU828Adata4Pos;
  uint8_NP SrU828Adata5Pos;
  uint8_NP SrU828Adata6Pos;
  uint8_NP SrU828Adata7Pos;
} RecSg28A_NP;

# define Rte_TypeDef_RecSg293_NP
typedef struct
{
  uint8_NP SrU8293data0Pos;
  uint8_NP SrU8293data1Pos;
  uint8_NP SrU8293data2Pos;
  uint8_NP SrU8293data3Pos;
  uint8_NP SrU8293data4Pos;
  uint8_NP SrU8293data5Pos;
  uint8_NP SrU8293data6Pos;
  uint8_NP SrU8293data7Pos;
} RecSg293_NP;

# define Rte_TypeDef_RecSg294_NP
typedef struct
{
  uint8_NP SrU8294data0Pos;
  uint8_NP SrU8294data1Pos;
  uint8_NP SrU8294data2Pos;
  uint8_NP SrU8294data3Pos;
  uint8_NP SrU8294data4Pos;
  uint8_NP SrU8294data5Pos;
  uint8_NP SrU8294data6Pos;
  uint8_NP SrU8294data7Pos;
} RecSg294_NP;

# define Rte_TypeDef_RecSg295_NP
typedef struct
{
  uint8_NP SrU8295data0Pos;
  uint8_NP SrU8295data1Pos;
  uint8_NP SrU8295data2Pos;
  uint8_NP SrU8295data3Pos;
  uint8_NP SrU8295data4Pos;
  uint8_NP SrU8295data5Pos;
  uint8_NP SrU8295data6Pos;
  uint8_NP SrU8295data7Pos;
} RecSg295_NP;

# define Rte_TypeDef_RecSg2A3_NP
typedef struct
{
  uint8_NP SrU82A3data0Pos;
  uint8_NP SrU82A3data1Pos;
  uint8_NP SrU82A3data2Pos;
  uint8_NP SrU82A3data3Pos;
  uint8_NP SrU82A3data4Pos;
  uint8_NP SrU82A3data5Pos;
  uint8_NP SrU82A3data6Pos;
  uint8_NP SrU82A3data7Pos;
} RecSg2A3_NP;

# define Rte_TypeDef_RecSg2A4_NP
typedef struct
{
  uint8_NP SrU82A4data0Pos;
  uint8_NP SrU82A4data1Pos;
  uint8_NP SrU82A4data2Pos;
  uint8_NP SrU82A4data3Pos;
  uint8_NP SrU82A4data4Pos;
  uint8_NP SrU82A4data5Pos;
  uint8_NP SrU82A4data6Pos;
  uint8_NP SrU82A4data7Pos;
} RecSg2A4_NP;

# define Rte_TypeDef_RecSg2AC_NP
typedef struct
{
  uint8_NP SrU82ACdata0Pos;
  uint8_NP SrU82ACdata1Pos;
  uint8_NP SrU82ACdata2Pos;
  uint8_NP SrU82ACdata3Pos;
  uint8_NP SrU82ACdata4Pos;
  uint8_NP SrU82ACdata5Pos;
  uint8_NP SrU82ACdata6Pos;
  uint8_NP SrU82ACdata7Pos;
} RecSg2AC_NP;

# define Rte_TypeDef_RecSg2AD_NP
typedef struct
{
  uint8_NP SrU82ADdata0Pos;
  uint8_NP SrU82ADdata1Pos;
  uint8_NP SrU82ADdata2Pos;
  uint8_NP SrU82ADdata3Pos;
  uint8_NP SrU82ADdata4Pos;
  uint8_NP SrU82ADdata5Pos;
  uint8_NP SrU82ADdata6Pos;
  uint8_NP SrU82ADdata7Pos;
} RecSg2AD_NP;

# define Rte_TypeDef_RecSg2AE_NP
typedef struct
{
  uint8_NP SrU82AEdata0Pos;
  uint8_NP SrU82AEdata1Pos;
  uint8_NP SrU82AEdata2Pos;
  uint8_NP SrU82AEdata3Pos;
  uint8_NP SrU82AEdata4Pos;
  uint8_NP SrU82AEdata5Pos;
  uint8_NP SrU82AEdata6Pos;
  uint8_NP SrU82AEdata7Pos;
} RecSg2AE_NP;

# define Rte_TypeDef_RecSg2AF_NP
typedef struct
{
  uint8_NP SrU82AFdata0Pos;
  uint8_NP SrU82AFdata1Pos;
  uint8_NP SrU82AFdata2Pos;
  uint8_NP SrU82AFdata3Pos;
  uint8_NP SrU82AFdata4Pos;
  uint8_NP SrU82AFdata5Pos;
  uint8_NP SrU82AFdata6Pos;
  uint8_NP SrU82AFdata7Pos;
} RecSg2AF_NP;

# define Rte_TypeDef_RecSg2C4_NP
typedef struct
{
  uint8_NP SrU82C4data0Pos;
  uint8_NP SrU82C4data1Pos;
  uint8_NP SrU82C4data2Pos;
  uint8_NP SrU82C4data3Pos;
  uint8_NP SrU82C4data4Pos;
  uint8_NP SrU82C4data5Pos;
  uint8_NP SrU82C4data6Pos;
  uint8_NP SrU82C4data7Pos;
} RecSg2C4_NP;

# define Rte_TypeDef_RecSg2C5_NP
typedef struct
{
  uint8_NP SrU82C5data0Pos;
  uint8_NP SrU82C5data1Pos;
  uint8_NP SrU82C5data2Pos;
  uint8_NP SrU82C5data3Pos;
  uint8_NP SrU82C5data4Pos;
  uint8_NP SrU82C5data5Pos;
  uint8_NP SrU82C5data6Pos;
  uint8_NP SrU82C5data7Pos;
} RecSg2C5_NP;

# define Rte_TypeDef_RecSg2C7_NP
typedef struct
{
  uint8_NP SrU82C7data0Pos;
  uint8_NP SrU82C7data1Pos;
  uint8_NP SrU82C7data2Pos;
  uint8_NP SrU82C7data3Pos;
  uint8_NP SrU82C7data4Pos;
  uint8_NP SrU82C7data5Pos;
  uint8_NP SrU82C7data6Pos;
  uint8_NP SrU82C7data7Pos;
} RecSg2C7_NP;

# define Rte_TypeDef_RecSg2C8_NP
typedef struct
{
  uint8_NP SrU82C8data0Pos;
  uint8_NP SrU82C8data1Pos;
  uint8_NP SrU82C8data2Pos;
  uint8_NP SrU82C8data3Pos;
  uint8_NP SrU82C8data4Pos;
  uint8_NP SrU82C8data5Pos;
  uint8_NP SrU82C8data6Pos;
  uint8_NP SrU82C8data7Pos;
} RecSg2C8_NP;

# define Rte_TypeDef_RecSg2C9_NP
typedef struct
{
  uint8_NP SrU82C9data0Pos;
  uint8_NP SrU82C9data1Pos;
  uint8_NP SrU82C9data2Pos;
  uint8_NP SrU82C9data3Pos;
  uint8_NP SrU82C9data4Pos;
  uint8_NP SrU82C9data5Pos;
  uint8_NP SrU82C9data6Pos;
  uint8_NP SrU82C9data7Pos;
} RecSg2C9_NP;

# define Rte_TypeDef_RecSg2CA_NP
typedef struct
{
  uint8_NP SrU82CAdata0Pos;
  uint8_NP SrU82CAdata1Pos;
  uint8_NP SrU82CAdata2Pos;
  uint8_NP SrU82CAdata3Pos;
  uint8_NP SrU82CAdata4Pos;
  uint8_NP SrU82CAdata5Pos;
  uint8_NP SrU82CAdata6Pos;
  uint8_NP SrU82CAdata7Pos;
} RecSg2CA_NP;

# define Rte_TypeDef_RecSg2CB_NP
typedef struct
{
  uint8_NP SrU82CBdata0Pos;
  uint8_NP SrU82CBdata1Pos;
  uint8_NP SrU82CBdata2Pos;
  uint8_NP SrU82CBdata3Pos;
  uint8_NP SrU82CBdata4Pos;
  uint8_NP SrU82CBdata5Pos;
  uint8_NP SrU82CBdata6Pos;
  uint8_NP SrU82CBdata7Pos;
} RecSg2CB_NP;

# define Rte_TypeDef_RecSg2CC_NP
typedef struct
{
  uint8_NP SrU82CCdata0Pos;
  uint8_NP SrU82CCdata1Pos;
  uint8_NP SrU82CCdata2Pos;
  uint8_NP SrU82CCdata3Pos;
  uint8_NP SrU82CCdata4Pos;
  uint8_NP SrU82CCdata5Pos;
} RecSg2CC_NP;

# define Rte_TypeDef_RecSg2CD_NP
typedef struct
{
  uint8_NP SrU82CDdata0Pos;
  uint8_NP SrU82CDdata1Pos;
  uint8_NP SrU82CDdata2Pos;
  uint8_NP SrU82CDdata3Pos;
  uint8_NP SrU82CDdata4Pos;
  uint8_NP SrU82CDdata5Pos;
  uint8_NP SrU82CDdata6Pos;
  uint8_NP SrU82CDdata7Pos;
} RecSg2CD_NP;

# define Rte_TypeDef_RecSg2CE_NP
typedef struct
{
  uint8_NP SrU82CEdata0Pos;
  uint8_NP SrU82CEdata1Pos;
  uint8_NP SrU82CEdata2Pos;
  uint8_NP SrU82CEdata3Pos;
  uint8_NP SrU82CEdata4Pos;
  uint8_NP SrU82CEdata5Pos;
  uint8_NP SrU82CEdata6Pos;
  uint8_NP SrU82CEdata7Pos;
} RecSg2CE_NP;

# define Rte_TypeDef_RecSg2CF_NP
typedef struct
{
  uint8_NP SrU82CFdata0Pos;
  uint8_NP SrU82CFdata1Pos;
  uint8_NP SrU82CFdata2Pos;
  uint8_NP SrU82CFdata3Pos;
  uint8_NP SrU82CFdata4Pos;
  uint8_NP SrU82CFdata5Pos;
  uint8_NP SrU82CFdata6Pos;
  uint8_NP SrU82CFdata7Pos;
} RecSg2CF_NP;

# define Rte_TypeDef_RecSg2D0_NP
typedef struct
{
  uint8_NP SrU82D0data0Pos;
  uint8_NP SrU82D0data1Pos;
  uint8_NP SrU82D0data2Pos;
  uint8_NP SrU82D0data3Pos;
  uint8_NP SrU82D0data4Pos;
  uint8_NP SrU82D0data5Pos;
  uint8_NP SrU82D0data6Pos;
  uint8_NP SrU82D0data7Pos;
} RecSg2D0_NP;

# define Rte_TypeDef_RecSg2D2_NP
typedef struct
{
  uint8_NP SrU82D2data0Pos;
  uint8_NP SrU82D2data1Pos;
  uint8_NP SrU82D2data2Pos;
  uint8_NP SrU82D2data3Pos;
  uint8_NP SrU82D2data4Pos;
} RecSg2D2_NP;

# define Rte_TypeDef_RecSg2D6_NP
typedef struct
{
  uint8_NP SrU82D6data0Pos;
  uint8_NP SrU82D6data1Pos;
  uint8_NP SrU82D6data2Pos;
  uint8_NP SrU82D6data3Pos;
  uint8_NP SrU82D6data4Pos;
  uint8_NP SrU82D6data5Pos;
  uint8_NP SrU82D6data6Pos;
  uint8_NP SrU82D6data7Pos;
} RecSg2D6_NP;

# define Rte_TypeDef_RecSg2D7_NP
typedef struct
{
  uint8_NP SrU82D7data0Pos;
  uint8_NP SrU82D7data1Pos;
  uint8_NP SrU82D7data2Pos;
  uint8_NP SrU82D7data3Pos;
  uint8_NP SrU82D7data4Pos;
  uint8_NP SrU82D7data5Pos;
  uint8_NP SrU82D7data6Pos;
  uint8_NP SrU82D7data7Pos;
} RecSg2D7_NP;

# define Rte_TypeDef_RecSg2D8_NP
typedef struct
{
  uint8_NP SrU82D8data0Pos;
  uint8_NP SrU82D8data1Pos;
  uint8_NP SrU82D8data2Pos;
  uint8_NP SrU82D8data3Pos;
  uint8_NP SrU82D8data4Pos;
  uint8_NP SrU82D8data5Pos;
  uint8_NP SrU82D8data6Pos;
  uint8_NP SrU82D8data7Pos;
} RecSg2D8_NP;

# define Rte_TypeDef_RecSg2EC_NP
typedef struct
{
  uint8_NP SrU82ECdata0Pos;
  uint8_NP SrU82ECdata1Pos;
  uint8_NP SrU82ECdata2Pos;
  uint8_NP SrU82ECdata3Pos;
  uint8_NP SrU82ECdata4Pos;
  uint8_NP SrU82ECdata5Pos;
} RecSg2EC_NP;

# define Rte_TypeDef_RecSg2EE_NP
typedef struct
{
  uint8_NP SrU82EEdata0Pos;
  uint8_NP SrU82EEdata1Pos;
  uint8_NP SrU82EEdata2Pos;
  uint8_NP SrU82EEdata3Pos;
  uint8_NP SrU82EEdata4Pos;
  uint8_NP SrU82EEdata5Pos;
  uint8_NP SrU82EEdata6Pos;
  uint8_NP SrU82EEdata7Pos;
} RecSg2EE_NP;

# define Rte_TypeDef_RecSg302_NP
typedef struct
{
  uint8_NP SrU8302data0Pos;
  uint8_NP SrU8302data1Pos;
  uint8_NP SrU8302data2Pos;
  uint8_NP SrU8302data3Pos;
  uint8_NP SrU8302data4Pos;
  uint8_NP SrU8302data5Pos;
  uint8_NP SrU8302data6Pos;
  uint8_NP SrU8302data7Pos;
} RecSg302_NP;

# define Rte_TypeDef_RecSg311_NP
typedef struct
{
  uint8_NP SrU8311data0Pos;
  uint8_NP SrU8311data1Pos;
  uint8_NP SrU8311data2Pos;
  uint8_NP SrU8311data3Pos;
  uint8_NP SrU8311data4Pos;
  uint8_NP SrU8311data5Pos;
  uint8_NP SrU8311data6Pos;
  uint8_NP SrU8311data7Pos;
} RecSg311_NP;

# define Rte_TypeDef_RecSg315_NP
typedef struct
{
  uint8_NP SrU8315data0Pos;
  uint8_NP SrU8315data1Pos;
  uint8_NP SrU8315data2Pos;
  uint8_NP SrU8315data3Pos;
  uint8_NP SrU8315data4Pos;
} RecSg315_NP;

# define Rte_TypeDef_RecSg322_NP
typedef struct
{
  uint8_NP SrU8322data0Pos;
  uint8_NP SrU8322data1Pos;
  uint8_NP SrU8322data2Pos;
  uint8_NP SrU8322data3Pos;
  uint8_NP SrU8322data4Pos;
  uint8_NP SrU8322data5Pos;
  uint8_NP SrU8322data6Pos;
  uint8_NP SrU8322data7Pos;
} RecSg322_NP;

# define Rte_TypeDef_RecSg323_NP
typedef struct
{
  uint8_NP SrU8323data0Pos;
  uint8_NP SrU8323data1Pos;
  uint8_NP SrU8323data2Pos;
  uint8_NP SrU8323data3Pos;
  uint8_NP SrU8323data4Pos;
  uint8_NP SrU8323data5Pos;
  uint8_NP SrU8323data6Pos;
} RecSg323_NP;

# define Rte_TypeDef_RecSg324_NP
typedef struct
{
  uint8_NP SrU8324data0Pos;
  uint8_NP SrU8324data1Pos;
  uint8_NP SrU8324data2Pos;
  uint8_NP SrU8324data3Pos;
  uint8_NP SrU8324data4Pos;
  uint8_NP SrU8324data5Pos;
  uint8_NP SrU8324data6Pos;
} RecSg324_NP;

# define Rte_TypeDef_RecSg325_NP
typedef struct
{
  uint8_NP SrU8325data0Pos;
  uint8_NP SrU8325data1Pos;
  uint8_NP SrU8325data2Pos;
  uint8_NP SrU8325data3Pos;
  uint8_NP SrU8325data4Pos;
  uint8_NP SrU8325data5Pos;
  uint8_NP SrU8325data6Pos;
  uint8_NP SrU8325data7Pos;
} RecSg325_NP;

# define Rte_TypeDef_RecSg32A_NP
typedef struct
{
  uint8_NP SrU832Adata0Pos;
  uint8_NP SrU832Adata1Pos;
  uint8_NP SrU832Adata2Pos;
  uint8_NP SrU832Adata3Pos;
  uint8_NP SrU832Adata4Pos;
  uint8_NP SrU832Adata5Pos;
  uint8_NP SrU832Adata6Pos;
  uint8_NP SrU832Adata7Pos;
} RecSg32A_NP;

# define Rte_TypeDef_RecSg32C_NP
typedef struct
{
  uint8_NP SrU832Cdata0Pos;
  uint8_NP SrU832Cdata1Pos;
  uint8_NP SrU832Cdata2Pos;
  uint8_NP SrU832Cdata3Pos;
  uint8_NP SrU832Cdata4Pos;
  uint8_NP SrU832Cdata5Pos;
  uint8_NP SrU832Cdata6Pos;
  uint8_NP SrU832Cdata7Pos;
} RecSg32C_NP;

# define Rte_TypeDef_RecSg32D_NP
typedef struct
{
  uint8_NP SrU832Ddata0Pos;
  uint8_NP SrU832Ddata1Pos;
  uint8_NP SrU832Ddata2Pos;
  uint8_NP SrU832Ddata3Pos;
  uint8_NP SrU832Ddata4Pos;
  uint8_NP SrU832Ddata5Pos;
  uint8_NP SrU832Ddata6Pos;
  uint8_NP SrU832Ddata7Pos;
} RecSg32D_NP;

# define Rte_TypeDef_RecSg32E_NP
typedef struct
{
  uint8_NP SrU832Edata0Pos;
  uint8_NP SrU832Edata1Pos;
  uint8_NP SrU832Edata2Pos;
  uint8_NP SrU832Edata3Pos;
  uint8_NP SrU832Edata4Pos;
  uint8_NP SrU832Edata5Pos;
  uint8_NP SrU832Edata6Pos;
} RecSg32E_NP;

# define Rte_TypeDef_RecSg32F_NP
typedef struct
{
  uint8_NP SrU832Fdata0Pos;
  uint8_NP SrU832Fdata1Pos;
  uint8_NP SrU832Fdata2Pos;
  uint8_NP SrU832Fdata3Pos;
  uint8_NP SrU832Fdata4Pos;
  uint8_NP SrU832Fdata5Pos;
  uint8_NP SrU832Fdata6Pos;
} RecSg32F_NP;

# define Rte_TypeDef_RecSg331_NP
typedef struct
{
  uint8_NP SrU8331data0Pos;
  uint8_NP SrU8331data1Pos;
  uint8_NP SrU8331data2Pos;
  uint8_NP SrU8331data3Pos;
  uint8_NP SrU8331data4Pos;
  uint8_NP SrU8331data5Pos;
  uint8_NP SrU8331data6Pos;
  uint8_NP SrU8331data7Pos;
} RecSg331_NP;

# define Rte_TypeDef_RecSg332_NP
typedef struct
{
  uint8_NP SrU8332data0Pos;
  uint8_NP SrU8332data1Pos;
  uint8_NP SrU8332data2Pos;
  uint8_NP SrU8332data3Pos;
  uint8_NP SrU8332data4Pos;
  uint8_NP SrU8332data5Pos;
  uint8_NP SrU8332data6Pos;
  uint8_NP SrU8332data7Pos;
} RecSg332_NP;

# define Rte_TypeDef_RecSg333_NP
typedef struct
{
  uint8_NP SrU8333data0Pos;
  uint8_NP SrU8333data1Pos;
  uint8_NP SrU8333data2Pos;
  uint8_NP SrU8333data3Pos;
} RecSg333_NP;

# define Rte_TypeDef_RecSg334_NP
typedef struct
{
  uint8_NP SrU8334data0Pos;
  uint8_NP SrU8334data1Pos;
  uint8_NP SrU8334data2Pos;
  uint8_NP SrU8334data3Pos;
  uint8_NP SrU8334data4Pos;
  uint8_NP SrU8334data5Pos;
  uint8_NP SrU8334data6Pos;
} RecSg334_NP;

# define Rte_TypeDef_RecSg336_NP
typedef struct
{
  uint8_NP SrU8336data0Pos;
  uint8_NP SrU8336data1Pos;
  uint8_NP SrU8336data2Pos;
  uint8_NP SrU8336data3Pos;
  uint8_NP SrU8336data4Pos;
  uint8_NP SrU8336data5Pos;
  uint8_NP SrU8336data6Pos;
} RecSg336_NP;

# define Rte_TypeDef_RecSg340_NP
typedef struct
{
  uint8_NP SrU8340data0Pos;
  uint8_NP SrU8340data1Pos;
  uint8_NP SrU8340data2Pos;
  uint8_NP SrU8340data3Pos;
  uint8_NP SrU8340data4Pos;
  uint8_NP SrU8340data5Pos;
  uint8_NP SrU8340data6Pos;
} RecSg340_NP;

# define Rte_TypeDef_RecSg34B_NP
typedef struct
{
  uint8_NP SrU834Bdata0Pos;
  uint8_NP SrU834Bdata1Pos;
  uint8_NP SrU834Bdata2Pos;
  uint8_NP SrU834Bdata3Pos;
  uint8_NP SrU834Bdata4Pos;
  uint8_NP SrU834Bdata5Pos;
  uint8_NP SrU834Bdata6Pos;
  uint8_NP SrU834Bdata7Pos;
} RecSg34B_NP;

# define Rte_TypeDef_RecSg35C_NP
typedef struct
{
  uint8_NP SrU835Cdata0Pos;
  uint8_NP SrU835Cdata1Pos;
  uint8_NP SrU835Cdata2Pos;
  uint8_NP SrU835Cdata3Pos;
  uint8_NP SrU835Cdata4Pos;
  uint8_NP SrU835Cdata5Pos;
  uint8_NP SrU835Cdata6Pos;
} RecSg35C_NP;

# define Rte_TypeDef_RecSg35D_NP
typedef struct
{
  uint8_NP SrU835Ddata0Pos;
  uint8_NP SrU835Ddata1Pos;
  uint8_NP SrU835Ddata2Pos;
  uint8_NP SrU835Ddata3Pos;
  uint8_NP SrU835Ddata4Pos;
  uint8_NP SrU835Ddata5Pos;
  uint8_NP SrU835Ddata6Pos;
} RecSg35D_NP;

# define Rte_TypeDef_RecSg361_NP
typedef struct
{
  uint8_NP SrU8361data0Pos;
  uint8_NP SrU8361data1Pos;
  uint8_NP SrU8361data2Pos;
  uint8_NP SrU8361data3Pos;
  uint8_NP SrU8361data4Pos;
  uint8_NP SrU8361data5Pos;
} RecSg361_NP;

# define Rte_TypeDef_RecSg362_NP
typedef struct
{
  uint8_NP SrU8362data0Pos;
  uint8_NP SrU8362data1Pos;
  uint8_NP SrU8362data2Pos;
  uint8_NP SrU8362data3Pos;
  uint8_NP SrU8362data4Pos;
  uint8_NP SrU8362data5Pos;
  uint8_NP SrU8362data6Pos;
  uint8_NP SrU8362data7Pos;
} RecSg362_NP;

# define Rte_TypeDef_RecSg363_NP
typedef struct
{
  uint8_NP SrU8363data0Pos;
  uint8_NP SrU8363data1Pos;
  uint8_NP SrU8363data2Pos;
  uint8_NP SrU8363data3Pos;
  uint8_NP SrU8363data4Pos;
  uint8_NP SrU8363data5Pos;
} RecSg363_NP;

# define Rte_TypeDef_RecSg366_NP
typedef struct
{
  uint8_NP SrU8366data0Pos;
  uint8_NP SrU8366data1Pos;
  uint8_NP SrU8366data2Pos;
  uint8_NP SrU8366data3Pos;
  uint8_NP SrU8366data4Pos;
  uint8_NP SrU8366data5Pos;
  uint8_NP SrU8366data6Pos;
} RecSg366_NP;

# define Rte_TypeDef_RecSg36A_NP
typedef struct
{
  uint8_NP SrU836Adata0Pos;
  uint8_NP SrU836Adata1Pos;
  uint8_NP SrU836Adata2Pos;
  uint8_NP SrU836Adata3Pos;
  uint8_NP SrU836Adata4Pos;
  uint8_NP SrU836Adata5Pos;
  uint8_NP SrU836Adata6Pos;
} RecSg36A_NP;

# define Rte_TypeDef_RecSg390_NP
typedef struct
{
  uint8_NP SrU8390data0Pos;
  uint8_NP SrU8390data1Pos;
  uint8_NP SrU8390data2Pos;
  uint8_NP SrU8390data3Pos;
  uint8_NP SrU8390data4Pos;
  uint8_NP SrU8390data5Pos;
  uint8_NP SrU8390data6Pos;
} RecSg390_NP;

# define Rte_TypeDef_RecSg393_NP
typedef struct
{
  uint8_NP SrU8393data0Pos;
  uint8_NP SrU8393data1Pos;
  uint8_NP SrU8393data2Pos;
  uint8_NP SrU8393data3Pos;
  uint8_NP SrU8393data4Pos;
  uint8_NP SrU8393data5Pos;
  uint8_NP SrU8393data6Pos;
} RecSg393_NP;

# define Rte_TypeDef_RecSg394_NP
typedef struct
{
  uint8_NP SrU8394data0Pos;
  uint8_NP SrU8394data1Pos;
  uint8_NP SrU8394data2Pos;
  uint8_NP SrU8394data3Pos;
  uint8_NP SrU8394data4Pos;
  uint8_NP SrU8394data5Pos;
  uint8_NP SrU8394data6Pos;
} RecSg394_NP;

# define Rte_TypeDef_RecSg39E_NP
typedef struct
{
  uint8_NP SrU839Edata0Pos;
  uint8_NP SrU839Edata1Pos;
  uint8_NP SrU839Edata2Pos;
  uint8_NP SrU839Edata3Pos;
  uint8_NP SrU839Edata4Pos;
  uint8_NP SrU839Edata5Pos;
  uint8_NP SrU839Edata6Pos;
} RecSg39E_NP;

# define Rte_TypeDef_RecSg39F_NP
typedef struct
{
  uint8_NP SrU839Fdata0Pos;
  uint8_NP SrU839Fdata1Pos;
  uint8_NP SrU839Fdata2Pos;
} RecSg39F_NP;

# define Rte_TypeDef_RecSg3A9_NP
typedef struct
{
  uint8_NP SrU83A9data0Pos;
  uint8_NP SrU83A9data1Pos;
  uint8_NP SrU83A9data2Pos;
  uint8_NP SrU83A9data3Pos;
  uint8_NP SrU83A9data4Pos;
  uint8_NP SrU83A9data5Pos;
  uint8_NP SrU83A9data6Pos;
} RecSg3A9_NP;

# define Rte_TypeDef_RecSg3AE_NP
typedef struct
{
  uint8_NP SrU83AEdata0Pos;
  uint8_NP SrU83AEdata1Pos;
  uint8_NP SrU83AEdata2Pos;
  uint8_NP SrU83AEdata3Pos;
  uint8_NP SrU83AEdata4Pos;
  uint8_NP SrU83AEdata5Pos;
  uint8_NP SrU83AEdata6Pos;
} RecSg3AE_NP;

# define Rte_TypeDef_RecSg3AF_NP
typedef struct
{
  uint8_NP SrU83AFdata0Pos;
  uint8_NP SrU83AFdata1Pos;
  uint8_NP SrU83AFdata2Pos;
  uint8_NP SrU83AFdata3Pos;
  uint8_NP SrU83AFdata4Pos;
  uint8_NP SrU83AFdata5Pos;
  uint8_NP SrU83AFdata6Pos;
  uint8_NP SrU83AFdata7Pos;
} RecSg3AF_NP;

# define Rte_TypeDef_RecSg3B8_NP
typedef struct
{
  uint8_NP SrU83B8data0Pos;
  uint8_NP SrU83B8data1Pos;
  uint8_NP SrU83B8data2Pos;
  uint8_NP SrU83B8data3Pos;
  uint8_NP SrU83B8data4Pos;
  uint8_NP SrU83B8data5Pos;
  uint8_NP SrU83B8data6Pos;
} RecSg3B8_NP;

# define Rte_TypeDef_RecSg3B9_NP
typedef struct
{
  uint8_NP SrU83B9data0Pos;
  uint8_NP SrU83B9data1Pos;
  uint8_NP SrU83B9data2Pos;
  uint8_NP SrU83B9data3Pos;
  uint8_NP SrU83B9data4Pos;
  uint8_NP SrU83B9data5Pos;
  uint8_NP SrU83B9data6Pos;
} RecSg3B9_NP;

# define Rte_TypeDef_RecSg3BB_NP
typedef struct
{
  uint8_NP SrU83BBdata0Pos;
  uint8_NP SrU83BBdata1Pos;
  uint8_NP SrU83BBdata2Pos;
  uint8_NP SrU83BBdata3Pos;
  uint8_NP SrU83BBdata4Pos;
  uint8_NP SrU83BBdata5Pos;
  uint8_NP SrU83BBdata6Pos;
} RecSg3BB_NP;

# define Rte_TypeDef_RecSg3BC_NP
typedef struct
{
  uint8_NP SrU83BCdata0Pos;
  uint8_NP SrU83BCdata1Pos;
  uint8_NP SrU83BCdata2Pos;
  uint8_NP SrU83BCdata3Pos;
  uint8_NP SrU83BCdata4Pos;
  uint8_NP SrU83BCdata5Pos;
  uint8_NP SrU83BCdata6Pos;
  uint8_NP SrU83BCdata7Pos;
} RecSg3BC_NP;

# define Rte_TypeDef_RecSg3BD_NP
typedef struct
{
  uint8_NP SrU83BDdata0Pos;
  uint8_NP SrU83BDdata1Pos;
  uint8_NP SrU83BDdata2Pos;
  uint8_NP SrU83BDdata3Pos;
  uint8_NP SrU83BDdata4Pos;
  uint8_NP SrU83BDdata5Pos;
  uint8_NP SrU83BDdata6Pos;
  uint8_NP SrU83BDdata7Pos;
} RecSg3BD_NP;

# define Rte_TypeDef_RecSg3C2_NP
typedef struct
{
  uint8_NP SrU83C2data0Pos;
  uint8_NP SrU83C2data1Pos;
  uint8_NP SrU83C2data2Pos;
  uint8_NP SrU83C2data3Pos;
  uint8_NP SrU83C2data4Pos;
  uint8_NP SrU83C2data5Pos;
} RecSg3C2_NP;

# define Rte_TypeDef_RecSg3C4_NP
typedef struct
{
  uint8_NP SrU83C4data0Pos;
  uint8_NP SrU83C4data1Pos;
  uint8_NP SrU83C4data2Pos;
} RecSg3C4_NP;

# define Rte_TypeDef_RecSg3C6_NP
typedef struct
{
  uint8_NP SrU83C6data0Pos;
  uint8_NP SrU83C6data1Pos;
  uint8_NP SrU83C6data2Pos;
  uint8_NP SrU83C6data3Pos;
  uint8_NP SrU83C6data4Pos;
  uint8_NP SrU83C6data5Pos;
  uint8_NP SrU83C6data6Pos;
  uint8_NP SrU83C6data7Pos;
} RecSg3C6_NP;

# define Rte_TypeDef_RecSg3CF_NP
typedef struct
{
  uint8_NP SrU83CFdata0Pos;
  uint8_NP SrU83CFdata1Pos;
  uint8_NP SrU83CFdata2Pos;
  uint8_NP SrU83CFdata3Pos;
  uint8_NP SrU83CFdata4Pos;
  uint8_NP SrU83CFdata5Pos;
} RecSg3CF_NP;

# define Rte_TypeDef_RecSg3DF_NP
typedef struct
{
  uint8_NP SrU83DFdata0Pos;
  uint8_NP SrU83DFdata1Pos;
  uint8_NP SrU83DFdata2Pos;
  uint8_NP SrU83DFdata3Pos;
} RecSg3DF_NP;

# define Rte_TypeDef_RecSg3FF_NP
typedef struct
{
  uint8_NP SrU83FFdata0Pos;
  uint8_NP SrU83FFdata1Pos;
  uint8_NP SrU83FFdata2Pos;
  uint8_NP SrU83FFdata3Pos;
  uint8_NP SrU83FFdata4Pos;
  uint8_NP SrU83FFdata5Pos;
  uint8_NP SrU83FFdata6Pos;
  uint8_NP SrU83FFdata7Pos;
} RecSg3FF_NP;

# define Rte_TypeDef_RecSg40A_NP
typedef struct
{
  uint8_NP SrU840Adata0Pos;
  uint8_NP SrU840Adata1Pos;
  uint8_NP SrU840Adata2Pos;
  uint8_NP SrU840Adata3Pos;
  uint8_NP SrU840Adata4Pos;
  uint8_NP SrU840Adata5Pos;
  uint8_NP SrU840Adata6Pos;
  uint8_NP SrU840Adata7Pos;
} RecSg40A_NP;

# define Rte_TypeDef_RecSg417_NP
typedef struct
{
  uint8_NP SrU8417data0Pos;
  uint8_NP SrU8417data1Pos;
  uint8_NP SrU8417data2Pos;
  uint8_NP SrU8417data3Pos;
  uint8_NP SrU8417data4Pos;
  uint8_NP SrU8417data5Pos;
  uint8_NP SrU8417data6Pos;
  uint8_NP SrU8417data7Pos;
} RecSg417_NP;

# define Rte_TypeDef_RecSg418_NP
typedef struct
{
  uint8_NP SrU8418data0Pos;
  uint8_NP SrU8418data1Pos;
  uint8_NP SrU8418data2Pos;
  uint8_NP SrU8418data3Pos;
  uint8_NP SrU8418data4Pos;
  uint8_NP SrU8418data5Pos;
  uint8_NP SrU8418data6Pos;
} RecSg418_NP;

# define Rte_TypeDef_RecSg41B_NP
typedef struct
{
  uint8_NP SrU841Bdata0Pos;
  uint8_NP SrU841Bdata1Pos;
  uint8_NP SrU841Bdata2Pos;
  uint8_NP SrU841Bdata3Pos;
  uint8_NP SrU841Bdata4Pos;
  uint8_NP SrU841Bdata5Pos;
  uint8_NP SrU841Bdata6Pos;
  uint8_NP SrU841Bdata7Pos;
} RecSg41B_NP;

# define Rte_TypeDef_RecSg41E_NP
typedef struct
{
  uint8_NP SrU841Edata0Pos;
  uint8_NP SrU841Edata1Pos;
  uint8_NP SrU841Edata2Pos;
  uint8_NP SrU841Edata3Pos;
  uint8_NP SrU841Edata4Pos;
  uint8_NP SrU841Edata5Pos;
  uint8_NP SrU841Edata6Pos;
} RecSg41E_NP;

# define Rte_TypeDef_RecSg420_NP
typedef struct
{
  uint8_NP SrU8420data0Pos;
  uint8_NP SrU8420data1Pos;
  uint8_NP SrU8420data2Pos;
  uint8_NP SrU8420data3Pos;
  uint8_NP SrU8420data4Pos;
  uint8_NP SrU8420data5Pos;
  uint8_NP SrU8420data6Pos;
} RecSg420_NP;

# define Rte_TypeDef_RecSg438_NP
typedef struct
{
  uint8_NP SrU8438data0Pos;
  uint8_NP SrU8438data1Pos;
  uint8_NP SrU8438data2Pos;
  uint8_NP SrU8438data3Pos;
  uint8_NP SrU8438data4Pos;
} RecSg438_NP;

# define Rte_TypeDef_RecSg46C_NP
typedef struct
{
  uint8_NP SrU846Cdata0Pos;
  uint8_NP SrU846Cdata1Pos;
  uint8_NP SrU846Cdata2Pos;
  uint8_NP SrU846Cdata3Pos;
  uint8_NP SrU846Cdata4Pos;
  uint8_NP SrU846Cdata5Pos;
  uint8_NP SrU846Cdata6Pos;
  uint8_NP SrU846Cdata7Pos;
} RecSg46C_NP;

# define Rte_TypeDef_RecSg46E_NP
typedef struct
{
  uint8_NP SrU846Edata0Pos;
  uint8_NP SrU846Edata1Pos;
  uint8_NP SrU846Edata2Pos;
} RecSg46E_NP;

# define Rte_TypeDef_RecSg470_NP
typedef struct
{
  uint8_NP SrU8470data0Pos;
  uint8_NP SrU8470data1Pos;
  uint8_NP SrU8470data2Pos;
  uint8_NP SrU8470data3Pos;
  uint8_NP SrU8470data4Pos;
  uint8_NP SrU8470data5Pos;
  uint8_NP SrU8470data6Pos;
  uint8_NP SrU8470data7Pos;
} RecSg470_NP;

# define Rte_TypeDef_RecSg471_NP
typedef struct
{
  uint8_NP SrU8471data0Pos;
  uint8_NP SrU8471data1Pos;
  uint8_NP SrU8471data2Pos;
  uint8_NP SrU8471data3Pos;
  uint8_NP SrU8471data4Pos;
  uint8_NP SrU8471data5Pos;
  uint8_NP SrU8471data6Pos;
  uint8_NP SrU8471data7Pos;
} RecSg471_NP;

# define Rte_TypeDef_RecSg472_NP
typedef struct
{
  uint8_NP SrU8472data0Pos;
  uint8_NP SrU8472data1Pos;
  uint8_NP SrU8472data2Pos;
  uint8_NP SrU8472data3Pos;
  uint8_NP SrU8472data4Pos;
  uint8_NP SrU8472data5Pos;
  uint8_NP SrU8472data6Pos;
  uint8_NP SrU8472data7Pos;
} RecSg472_NP;

# define Rte_TypeDef_RecSg473_NP
typedef struct
{
  uint8_NP SrU8473data0Pos;
  uint8_NP SrU8473data1Pos;
  uint8_NP SrU8473data2Pos;
  uint8_NP SrU8473data3Pos;
  uint8_NP SrU8473data4Pos;
  uint8_NP SrU8473data5Pos;
  uint8_NP SrU8473data6Pos;
  uint8_NP SrU8473data7Pos;
} RecSg473_NP;

# define Rte_TypeDef_RecSg474_NP
typedef struct
{
  uint8_NP SrU8474data0Pos;
  uint8_NP SrU8474data1Pos;
  uint8_NP SrU8474data2Pos;
  uint8_NP SrU8474data3Pos;
  uint8_NP SrU8474data4Pos;
  uint8_NP SrU8474data5Pos;
  uint8_NP SrU8474data6Pos;
  uint8_NP SrU8474data7Pos;
} RecSg474_NP;

# define Rte_TypeDef_RecSg475_NP
typedef struct
{
  uint8_NP SrU8475data0Pos;
  uint8_NP SrU8475data1Pos;
  uint8_NP SrU8475data2Pos;
  uint8_NP SrU8475data3Pos;
  uint8_NP SrU8475data4Pos;
  uint8_NP SrU8475data5Pos;
  uint8_NP SrU8475data6Pos;
  uint8_NP SrU8475data7Pos;
} RecSg475_NP;

# define Rte_TypeDef_RecSg476_NP
typedef struct
{
  uint8_NP SrU8476data0Pos;
  uint8_NP SrU8476data1Pos;
  uint8_NP SrU8476data2Pos;
  uint8_NP SrU8476data3Pos;
  uint8_NP SrU8476data4Pos;
  uint8_NP SrU8476data5Pos;
  uint8_NP SrU8476data6Pos;
  uint8_NP SrU8476data7Pos;
} RecSg476_NP;

# define Rte_TypeDef_RecSg477_NP
typedef struct
{
  uint8_NP SrU8477data0Pos;
  uint8_NP SrU8477data1Pos;
  uint8_NP SrU8477data2Pos;
  uint8_NP SrU8477data3Pos;
  uint8_NP SrU8477data4Pos;
  uint8_NP SrU8477data5Pos;
  uint8_NP SrU8477data6Pos;
  uint8_NP SrU8477data7Pos;
} RecSg477_NP;

# define Rte_TypeDef_RecSg478_NP
typedef struct
{
  uint8_NP SrU8478data0Pos;
  uint8_NP SrU8478data1Pos;
  uint8_NP SrU8478data2Pos;
  uint8_NP SrU8478data3Pos;
  uint8_NP SrU8478data4Pos;
  uint8_NP SrU8478data5Pos;
  uint8_NP SrU8478data6Pos;
  uint8_NP SrU8478data7Pos;
} RecSg478_NP;

# define Rte_TypeDef_RecSg479_NP
typedef struct
{
  uint8_NP SrU8479data0Pos;
  uint8_NP SrU8479data1Pos;
  uint8_NP SrU8479data2Pos;
  uint8_NP SrU8479data3Pos;
  uint8_NP SrU8479data4Pos;
  uint8_NP SrU8479data5Pos;
  uint8_NP SrU8479data6Pos;
  uint8_NP SrU8479data7Pos;
} RecSg479_NP;

# define Rte_TypeDef_RecSg47C_NP
typedef struct
{
  uint8_NP SrU847Cdata0Pos;
  uint8_NP SrU847Cdata1Pos;
  uint8_NP SrU847Cdata2Pos;
  uint8_NP SrU847Cdata3Pos;
  uint8_NP SrU847Cdata4Pos;
  uint8_NP SrU847Cdata5Pos;
  uint8_NP SrU847Cdata6Pos;
  uint8_NP SrU847Cdata7Pos;
} RecSg47C_NP;

# define Rte_TypeDef_RecSg47D_NP
typedef struct
{
  uint8_NP SrU847Ddata0Pos;
  uint8_NP SrU847Ddata1Pos;
  uint8_NP SrU847Ddata2Pos;
  uint8_NP SrU847Ddata3Pos;
  uint8_NP SrU847Ddata4Pos;
  uint8_NP SrU847Ddata5Pos;
  uint8_NP SrU847Ddata6Pos;
  uint8_NP SrU847Ddata7Pos;
} RecSg47D_NP;

# define Rte_TypeDef_RecSg47F_NP
typedef struct
{
  uint8_NP SrU847Fdata0Pos;
  uint8_NP SrU847Fdata1Pos;
  uint8_NP SrU847Fdata2Pos;
  uint8_NP SrU847Fdata3Pos;
  uint8_NP SrU847Fdata4Pos;
  uint8_NP SrU847Fdata5Pos;
  uint8_NP SrU847Fdata6Pos;
  uint8_NP SrU847Fdata7Pos;
} RecSg47F_NP;

# define Rte_TypeDef_RecSg4C3_NP
typedef struct
{
  uint8_NP SrU84C3data0Pos;
  uint8_NP SrU84C3data1Pos;
} RecSg4C3_NP;

# define Rte_TypeDef_RecSg4FC_NP
typedef struct
{
  uint8_NP SrU84FCdata0Pos;
  uint8_NP SrU84FCdata1Pos;
  uint8_NP SrU84FCdata2Pos;
  uint8_NP SrU84FCdata3Pos;
  uint8_NP SrU84FCdata4Pos;
  uint8_NP SrU84FCdata5Pos;
  uint8_NP SrU84FCdata6Pos;
  uint8_NP SrU84FCdata7Pos;
} RecSg4FC_NP;

# define Rte_TypeDef_RecSg517_NP
typedef struct
{
  uint8_NP SrU8517data0Pos;
  uint8_NP SrU8517data1Pos;
  uint8_NP SrU8517data2Pos;
  uint8_NP SrU8517data3Pos;
  uint8_NP SrU8517data4Pos;
  uint8_NP SrU8517data5Pos;
  uint8_NP SrU8517data6Pos;
  uint8_NP SrU8517data7Pos;
} RecSg517_NP;

# define Rte_TypeDef_RecSg522_NP
typedef struct
{
  uint8_NP SrU8522data0Pos;
  uint8_NP SrU8522data1Pos;
  uint8_NP SrU8522data2Pos;
  uint8_NP SrU8522data3Pos;
  uint8_NP SrU8522data4Pos;
  uint8_NP SrU8522data5Pos;
  uint8_NP SrU8522data6Pos;
  uint8_NP SrU8522data7Pos;
} RecSg522_NP;

# define Rte_TypeDef_RecSg52B_NP
typedef struct
{
  uint8_NP SrU852Bdata0Pos;
  uint8_NP SrU852Bdata1Pos;
  uint8_NP SrU852Bdata2Pos;
  uint8_NP SrU852Bdata3Pos;
  uint8_NP SrU852Bdata4Pos;
  uint8_NP SrU852Bdata5Pos;
  uint8_NP SrU852Bdata6Pos;
  uint8_NP SrU852Bdata7Pos;
} RecSg52B_NP;

# define Rte_TypeDef_RecSg52C_NP
typedef struct
{
  uint8_NP SrU852Cdata0Pos;
  uint8_NP SrU852Cdata1Pos;
  uint8_NP SrU852Cdata2Pos;
  uint8_NP SrU852Cdata3Pos;
  uint8_NP SrU852Cdata4Pos;
  uint8_NP SrU852Cdata5Pos;
  uint8_NP SrU852Cdata6Pos;
  uint8_NP SrU852Cdata7Pos;
} RecSg52C_NP;

# define Rte_TypeDef_RecSg52D_NP
typedef struct
{
  uint8_NP SrU852Ddata0Pos;
  uint8_NP SrU852Ddata1Pos;
  uint8_NP SrU852Ddata2Pos;
  uint8_NP SrU852Ddata3Pos;
  uint8_NP SrU852Ddata4Pos;
  uint8_NP SrU852Ddata5Pos;
  uint8_NP SrU852Ddata6Pos;
  uint8_NP SrU852Ddata7Pos;
} RecSg52D_NP;

# define Rte_TypeDef_RecSg52E_NP
typedef struct
{
  uint8_NP SrU852Edata0Pos;
  uint8_NP SrU852Edata1Pos;
  uint8_NP SrU852Edata2Pos;
  uint8_NP SrU852Edata3Pos;
  uint8_NP SrU852Edata4Pos;
  uint8_NP SrU852Edata5Pos;
  uint8_NP SrU852Edata6Pos;
  uint8_NP SrU852Edata7Pos;
} RecSg52E_NP;

# define Rte_TypeDef_RecSg538_NP
typedef struct
{
  uint8_NP SrU8538data0Pos;
  uint8_NP SrU8538data1Pos;
  uint8_NP SrU8538data2Pos;
  uint8_NP SrU8538data3Pos;
  uint8_NP SrU8538data4Pos;
  uint8_NP SrU8538data5Pos;
} RecSg538_NP;

# define Rte_TypeDef_RecSg57B_NP
typedef struct
{
  uint8_NP SrU857Bdata0Pos;
  uint8_NP SrU857Bdata1Pos;
  uint8_NP SrU857Bdata2Pos;
  uint8_NP SrU857Bdata3Pos;
  uint8_NP SrU857Bdata4Pos;
  uint8_NP SrU857Bdata5Pos;
  uint8_NP SrU857Bdata6Pos;
  uint8_NP SrU857Bdata7Pos;
} RecSg57B_NP;

# define Rte_TypeDef_RecSg57C_NP
typedef struct
{
  uint8_NP SrU857Cdata0Pos;
  uint8_NP SrU857Cdata1Pos;
  uint8_NP SrU857Cdata2Pos;
  uint8_NP SrU857Cdata3Pos;
  uint8_NP SrU857Cdata4Pos;
  uint8_NP SrU857Cdata5Pos;
  uint8_NP SrU857Cdata6Pos;
  uint8_NP SrU857Cdata7Pos;
} RecSg57C_NP;

# define Rte_TypeDef_RecSg57D_NP
typedef struct
{
  uint8_NP SrU857Ddata0Pos;
  uint8_NP SrU857Ddata1Pos;
  uint8_NP SrU857Ddata2Pos;
  uint8_NP SrU857Ddata3Pos;
  uint8_NP SrU857Ddata4Pos;
  uint8_NP SrU857Ddata5Pos;
  uint8_NP SrU857Ddata6Pos;
  uint8_NP SrU857Ddata7Pos;
} RecSg57D_NP;

# define Rte_TypeDef_RecSg57E_NP
typedef struct
{
  uint8_NP SrU857Edata0Pos;
  uint8_NP SrU857Edata1Pos;
  uint8_NP SrU857Edata2Pos;
  uint8_NP SrU857Edata3Pos;
  uint8_NP SrU857Edata4Pos;
  uint8_NP SrU857Edata5Pos;
  uint8_NP SrU857Edata6Pos;
  uint8_NP SrU857Edata7Pos;
} RecSg57E_NP;

# define Rte_TypeDef_RecSg5AB_NP
typedef struct
{
  uint8_NP SrU85ABdata0Pos;
  uint8_NP SrU85ABdata1Pos;
  uint8_NP SrU85ABdata2Pos;
  uint8_NP SrU85ABdata3Pos;
  uint8_NP SrU85ABdata4Pos;
  uint8_NP SrU85ABdata5Pos;
  uint8_NP SrU85ABdata6Pos;
  uint8_NP SrU85ABdata7Pos;
} RecSg5AB_NP;

# define Rte_TypeDef_RecSg5AC_NP
typedef struct
{
  uint8_NP SrU85ACdata0Pos;
  uint8_NP SrU85ACdata1Pos;
  uint8_NP SrU85ACdata2Pos;
  uint8_NP SrU85ACdata3Pos;
  uint8_NP SrU85ACdata4Pos;
  uint8_NP SrU85ACdata5Pos;
  uint8_NP SrU85ACdata6Pos;
  uint8_NP SrU85ACdata7Pos;
} RecSg5AC_NP;

# define Rte_TypeDef_RecSg5AD_NP
typedef struct
{
  uint8_NP SrU85ADdata0Pos;
  uint8_NP SrU85ADdata1Pos;
  uint8_NP SrU85ADdata2Pos;
  uint8_NP SrU85ADdata3Pos;
  uint8_NP SrU85ADdata4Pos;
  uint8_NP SrU85ADdata5Pos;
  uint8_NP SrU85ADdata6Pos;
  uint8_NP SrU85ADdata7Pos;
} RecSg5AD_NP;

# define Rte_TypeDef_RecSg5AE_NP
typedef struct
{
  uint8_NP SrU85AEdata0Pos;
  uint8_NP SrU85AEdata1Pos;
  uint8_NP SrU85AEdata2Pos;
  uint8_NP SrU85AEdata3Pos;
  uint8_NP SrU85AEdata4Pos;
  uint8_NP SrU85AEdata5Pos;
  uint8_NP SrU85AEdata6Pos;
  uint8_NP SrU85AEdata7Pos;
} RecSg5AE_NP;

# define Rte_TypeDef_RecSg5C7_NP
typedef struct
{
  uint8_NP SrU85C7data0Pos;
  uint8_NP SrU85C7data1Pos;
  uint8_NP SrU85C7data2Pos;
} RecSg5C7_NP;

# define Rte_TypeDef_RecSg5D3_NP
typedef struct
{
  uint8_NP SrU85D3data0Pos;
  uint8_NP SrU85D3data1Pos;
  uint8_NP SrU85D3data2Pos;
  uint8_NP SrU85D3data3Pos;
  uint8_NP SrU85D3data4Pos;
  uint8_NP SrU85D3data5Pos;
  uint8_NP SrU85D3data6Pos;
  uint8_NP SrU85D3data7Pos;
} RecSg5D3_NP;

# define Rte_TypeDef_RecSg5EC_NP
typedef struct
{
  uint8_NP SrU85ECdata0Pos;
  uint8_NP SrU85ECdata1Pos;
  uint8_NP SrU85ECdata2Pos;
  uint8_NP SrU85ECdata3Pos;
  uint8_NP SrU85ECdata4Pos;
  uint8_NP SrU85ECdata5Pos;
  uint8_NP SrU85ECdata6Pos;
  uint8_NP SrU85ECdata7Pos;
} RecSg5EC_NP;

# define Rte_TypeDef_RecSg5FA_NP
typedef struct
{
  uint8_NP SrU85FAdata0Pos;
  uint8_NP SrU85FAdata1Pos;
  uint8_NP SrU85FAdata2Pos;
  uint8_NP SrU85FAdata3Pos;
  uint8_NP SrU85FAdata4Pos;
  uint8_NP SrU85FAdata5Pos;
  uint8_NP SrU85FAdata6Pos;
} RecSg5FA_NP;

# define Rte_TypeDef_RecSg60D_NP
typedef struct
{
  uint8_NP SrU860Ddata0Pos;
  uint8_NP SrU860Ddata1Pos;
  uint8_NP SrU860Ddata2Pos;
  uint8_NP SrU860Ddata3Pos;
  uint8_NP SrU860Ddata4Pos;
  uint8_NP SrU860Ddata5Pos;
  uint8_NP SrU860Ddata6Pos;
  uint8_NP SrU860Ddata7Pos;
} RecSg60D_NP;

# define Rte_TypeDef_RecSg611_NP
typedef struct
{
  uint8_NP SrU8611data0Pos;
  uint8_NP SrU8611data1Pos;
  uint8_NP SrU8611data2Pos;
  uint8_NP SrU8611data3Pos;
  uint8_NP SrU8611data4Pos;
  uint8_NP SrU8611data5Pos;
  uint8_NP SrU8611data6Pos;
  uint8_NP SrU8611data7Pos;
} RecSg611_NP;

# define Rte_TypeDef_RecSg623_NP
typedef struct
{
  uint8_NP SrU8623data0Pos;
  uint8_NP SrU8623data1Pos;
  uint8_NP SrU8623data2Pos;
  uint8_NP SrU8623data3Pos;
  uint8_NP SrU8623data4Pos;
  uint8_NP SrU8623data5Pos;
} RecSg623_NP;

# define Rte_TypeDef_RecSg643_NP
typedef struct
{
  uint8_NP SrU8643data0Pos;
  uint8_NP SrU8643data1Pos;
  uint8_NP SrU8643data2Pos;
  uint8_NP SrU8643data3Pos;
  uint8_NP SrU8643data4Pos;
  uint8_NP SrU8643data5Pos;
  uint8_NP SrU8643data6Pos;
} RecSg643_NP;

# define Rte_TypeDef_RecSg6CB_NP
typedef struct
{
  uint8_NP SrU86CBdata0Pos;
  uint8_NP SrU86CBdata1Pos;
} RecSg6CB_NP;

# define Rte_TypeDef_RecSg6FF_SP_NP
typedef struct
{
  uint8_NP SrU86FFdata0Pos;
  uint8_NP SrU86FFdata1Pos;
  uint8_NP SrU86FFdata2Pos;
  uint8_NP SrU86FFdata3Pos;
  uint8_NP SrU86FFdata4Pos;
  uint8_NP SrU86FFdata5Pos;
  uint8_NP SrU86FFdata6Pos;
  uint8_NP SrU86FFdata7Pos;
} RecSg6FF_SP_NP;

# define Rte_TypeDef_SigmaTriggerType
typedef struct
{
  uint32 CanId;
  uint32 Dtc;
} SigmaTriggerType;

# define Rte_TypeDef_BswM_BswM_NvmErrorStatus
typedef uint8 BswM_BswM_NvmErrorStatus;

# define Rte_TypeDef_BswM_ESH_Mode
typedef uint8 BswM_ESH_Mode;

# define Rte_TypeDef_BswM_ESH_RunRequest
typedef uint8 BswM_ESH_RunRequest;

# define Rte_TypeDef_BswM_MD_Service22OnOff
typedef uint8 BswM_MD_Service22OnOff;

# define Rte_TypeDef_BswM_Mode_ProgrammingSession
typedef uint8 BswM_Mode_ProgrammingSession;

# define Rte_TypeDef_ComM_InhibitionStatusType
typedef uint8 ComM_InhibitionStatusType;

# define Rte_TypeDef_ComM_ModeType
typedef uint8 ComM_ModeType;

# define Rte_TypeDef_ComM_UserHandleType
typedef uint8 ComM_UserHandleType;

# define Rte_TypeDef_Dcm_CommunicationModeType
typedef uint8 Dcm_CommunicationModeType;

# define Rte_TypeDef_Dcm_ConfirmationStatusType
typedef uint8 Dcm_ConfirmationStatusType;

# define Rte_TypeDef_Dcm_DiagnosticSessionControlType
typedef uint8 Dcm_DiagnosticSessionControlType;

# define Rte_TypeDef_Dcm_EcuResetType
typedef uint8 Dcm_EcuResetType;

# define Rte_TypeDef_Dcm_NegativeResponseCodeType
typedef uint8 Dcm_NegativeResponseCodeType;

# define Rte_TypeDef_Dcm_OpStatusType
typedef uint8 Dcm_OpStatusType;

# define Rte_TypeDef_Dcm_ProtocolType
typedef uint8 Dcm_ProtocolType;

# define Rte_TypeDef_Dcm_RequestKindType
typedef uint8 Dcm_RequestKindType;

# define Rte_TypeDef_Dcm_SecLevelType
typedef uint8 Dcm_SecLevelType;

# define Rte_TypeDef_Dcm_SesCtrlType
typedef uint8 Dcm_SesCtrlType;

# define Rte_TypeDef_Dem_DTCFormatType
typedef uint8 Dem_DTCFormatType;

# define Rte_TypeDef_Dem_DTCGroupType
typedef uint32 Dem_DTCGroupType;

# define Rte_TypeDef_Dem_DTCKindType
typedef uint8 Dem_DTCKindType;

# define Rte_TypeDef_Dem_DTCOriginType
typedef uint8 Dem_DTCOriginType;

# define Rte_TypeDef_Dem_DTCStatusMaskType
typedef uint8 Dem_DTCStatusMaskType;

# define Rte_TypeDef_Dem_DebounceResetStatusType
typedef uint8 Dem_DebounceResetStatusType;

# define Rte_TypeDef_Dem_DebouncingStateType
typedef uint8 Dem_DebouncingStateType;

# define Rte_TypeDef_Dem_EventIdType
typedef uint16 Dem_EventIdType;

# define Rte_TypeDef_Dem_EventStatusExtendedType
typedef uint8 Dem_EventStatusExtendedType;

# define Rte_TypeDef_Dem_EventStatusType
typedef uint8 Dem_EventStatusType;

# define Rte_TypeDef_Dem_IndicatorStatusType
typedef uint8 Dem_IndicatorStatusType;

# define Rte_TypeDef_Dem_InitMonitorReasonType
typedef uint8 Dem_InitMonitorReasonType;

# define Rte_TypeDef_Dem_IumprDenomCondIdType
typedef uint8 Dem_IumprDenomCondIdType;

# define Rte_TypeDef_Dem_IumprDenomCondStatusType
typedef uint8 Dem_IumprDenomCondStatusType;

# define Rte_TypeDef_Dem_OperationCycleIdType
typedef uint8 Dem_OperationCycleIdType;

# define Rte_TypeDef_Dem_OperationCycleStateType
typedef uint8 Dem_OperationCycleStateType;

# define Rte_TypeDef_Dem_RatioIdType
typedef uint16 Dem_RatioIdType;

# define Rte_TypeDef_Dem_UdsStatusByteType
typedef uint8 Dem_UdsStatusByteType;

# define Rte_TypeDef_EcuM_BootTargetType
typedef uint8 EcuM_BootTargetType;

# define Rte_TypeDef_EcuM_ModeType
typedef uint8 EcuM_ModeType;

# define Rte_TypeDef_EcuM_ShutdownCauseType
typedef uint8 EcuM_ShutdownCauseType;

# define Rte_TypeDef_EcuM_StateType
typedef uint8 EcuM_StateType;

# define Rte_TypeDef_EcuM_TimeType
typedef uint32 EcuM_TimeType;

# define Rte_TypeDef_EcuM_UserType
typedef uint8 EcuM_UserType;

# define Rte_TypeDef_NvM_BlockIdType
typedef uint16 NvM_BlockIdType;

# define Rte_TypeDef_NvM_ServiceIdType
typedef uint8 NvM_ServiceIdType;


# ifndef RTE_SUPPRESS_UNUSED_DATATYPES
/**********************************************************************************************************************
 * Unused Data type definitions
 *********************************************************************************************************************/

#  define Rte_TypeDef_Double
typedef float64 Double;

#  define Rte_TypeDef_sint8_NP
typedef sint8 sint8_NP;

#  define Rte_TypeDef_Uint8Ary_CSMEEP
typedef uint8_NP Uint8Ary_CSMEEP[96];

#  define Rte_TypeDef_rt_Array_Boolean_3
typedef Boolean rt_Array_Boolean_3[3];

#  define Rte_TypeDef_rt_Array_Boolean_4
typedef Boolean rt_Array_Boolean_4[4];

#  define Rte_TypeDef_rt_Array_Boolean_6
typedef boolean_NP rt_Array_Boolean_6[6];

#  define Rte_TypeDef_rt_Array_Boolean_7
typedef Boolean rt_Array_Boolean_7[7];

#  define Rte_TypeDef_rt_Array_Boolean_9
typedef Boolean rt_Array_Boolean_9[9];

#  define Rte_TypeDef_rt_Array_SInt16_46
typedef sint16_NP rt_Array_SInt16_46[46];

#  define Rte_TypeDef_rt_Array_UInt8_3
typedef uint8_NP rt_Array_UInt8_3[3];

#  define Rte_TypeDef_rt_Array_UInt8_4
typedef uint8_NP rt_Array_UInt8_4[4];

#  define Rte_TypeDef_rt_Array_UInt8_7
typedef uint8_NP rt_Array_UInt8_7[7];

#  define Rte_TypeDef_rt_Array_UInt8_9
typedef uint8_NP rt_Array_UInt8_9[9];

#  define Rte_TypeDef_rt_Array_UInt8_96
typedef uint8_NP rt_Array_UInt8_96[96];

#  define Rte_TypeDef_RecSg002_NP
typedef struct
{
  uint8_NP SrU8002data0Pos;
  uint8_NP SrU8002data1Pos;
  uint8_NP SrU8002data2Pos;
  uint8_NP SrU8002data3Pos;
  uint8_NP SrU8002data4Pos;
} RecSg002_NP;

#  define Rte_TypeDef_RecSg02A_NP
typedef struct
{
  uint8_NP SrU802Adata0Pos;
  uint8_NP SrU802Adata1Pos;
  uint8_NP SrU802Adata2Pos;
  uint8_NP SrU802Adata3Pos;
  uint8_NP SrU802Adata4Pos;
  uint8_NP SrU802Adata5Pos;
} RecSg02A_NP;

#  define Rte_TypeDef_RecSg15A_NP
typedef struct
{
  uint8_NP SrU815Adata0Pos;
  uint8_NP SrU815Adata1Pos;
  uint8_NP SrU815Adata2Pos;
  uint8_NP SrU815Adata3Pos;
  uint8_NP SrU815Adata4Pos;
  uint8_NP SrU815Adata5Pos;
} RecSg15A_NP;

#  define Rte_TypeDef_RecSg15B_NP
typedef struct
{
  uint8_NP SrU815Bdata0Pos;
  uint8_NP SrU815Bdata1Pos;
  uint8_NP SrU815Bdata2Pos;
  uint8_NP SrU815Bdata3Pos;
  uint8_NP SrU815Bdata4Pos;
} RecSg15B_NP;

#  define Rte_TypeDef_RecSg15C_NP
typedef struct
{
  uint8_NP SrU815Cdata0Pos;
  uint8_NP SrU815Cdata1Pos;
  uint8_NP SrU815Cdata2Pos;
  uint8_NP SrU815Cdata3Pos;
  uint8_NP SrU815Cdata4Pos;
  uint8_NP SrU815Cdata5Pos;
  uint8_NP SrU815Cdata6Pos;
  uint8_NP SrU815Cdata7Pos;
} RecSg15C_NP;

#  define Rte_TypeDef_RecSg15D_NP
typedef struct
{
  uint8_NP SrU815Ddata0Pos;
  uint8_NP SrU815Ddata1Pos;
  uint8_NP SrU815Ddata2Pos;
  uint8_NP SrU815Ddata3Pos;
  uint8_NP SrU815Ddata4Pos;
  uint8_NP SrU815Ddata5Pos;
  uint8_NP SrU815Ddata6Pos;
} RecSg15D_NP;

#  define Rte_TypeDef_RecSg169_NP
typedef struct
{
  uint8_NP SrU8169data0Pos;
  uint8_NP SrU8169data1Pos;
  uint8_NP SrU8169data2Pos;
  uint8_NP SrU8169data3Pos;
  uint8_NP SrU8169data4Pos;
  uint8_NP SrU8169data5Pos;
  uint8_NP SrU8169data6Pos;
  uint8_NP SrU8169data7Pos;
} RecSg169_NP;

#  define Rte_TypeDef_RecSg178_NP
typedef struct
{
  uint8_NP SrU8178data0Pos;
  uint8_NP SrU8178data1Pos;
  uint8_NP SrU8178data2Pos;
  uint8_NP SrU8178data3Pos;
  uint8_NP SrU8178data4Pos;
  uint8_NP SrU8178data5Pos;
} RecSg178_NP;

#  define Rte_TypeDef_RecSg182_NP
typedef struct
{
  uint8_NP SrU8182data0Pos;
  uint8_NP SrU8182data1Pos;
  uint8_NP SrU8182data2Pos;
  uint8_NP SrU8182data3Pos;
  uint8_NP SrU8182data4Pos;
  uint8_NP SrU8182data5Pos;
  uint8_NP SrU8182data6Pos;
  uint8_NP SrU8182data7Pos;
} RecSg182_NP;

#  define Rte_TypeDef_RecSg185_NP
typedef struct
{
  uint8_NP SrU8185data0Pos;
  uint8_NP SrU8185data1Pos;
  uint8_NP SrU8185data2Pos;
  uint8_NP SrU8185data3Pos;
  uint8_NP SrU8185data4Pos;
  uint8_NP SrU8185data5Pos;
  uint8_NP SrU8185data6Pos;
  uint8_NP SrU8185data7Pos;
} RecSg185_NP;

#  define Rte_TypeDef_RecSg18D_NP
typedef struct
{
  uint8_NP SrU818Ddata0Pos;
  uint8_NP SrU818Ddata1Pos;
  uint8_NP SrU818Ddata2Pos;
  uint8_NP SrU818Ddata3Pos;
  uint8_NP SrU818Ddata4Pos;
  uint8_NP SrU818Ddata5Pos;
  uint8_NP SrU818Ddata6Pos;
  uint8_NP SrU818Ddata7Pos;
} RecSg18D_NP;

#  define Rte_TypeDef_RecSg18E_NP
typedef struct
{
  uint8_NP SrU818Edata0Pos;
  uint8_NP SrU818Edata1Pos;
  uint8_NP SrU818Edata2Pos;
  uint8_NP SrU818Edata3Pos;
  uint8_NP SrU818Edata4Pos;
  uint8_NP SrU818Edata5Pos;
  uint8_NP SrU818Edata6Pos;
  uint8_NP SrU818Edata7Pos;
} RecSg18E_NP;

#  define Rte_TypeDef_RecSg193_NP
typedef struct
{
  uint8_NP SrU8193data0Pos;
  uint8_NP SrU8193data1Pos;
  uint8_NP SrU8193data2Pos;
  uint8_NP SrU8193data3Pos;
  uint8_NP SrU8193data4Pos;
  uint8_NP SrU8193data5Pos;
  uint8_NP SrU8193data6Pos;
  uint8_NP SrU8193data7Pos;
} RecSg193_NP;

#  define Rte_TypeDef_RecSg1AE_NP
typedef struct
{
  uint8_NP SrU81AEdata0Pos;
  uint8_NP SrU81AEdata1Pos;
  uint8_NP SrU81AEdata2Pos;
  uint8_NP SrU81AEdata3Pos;
  uint8_NP SrU81AEdata4Pos;
  uint8_NP SrU81AEdata5Pos;
} RecSg1AE_NP;

#  define Rte_TypeDef_RecSg1B3_NP
typedef struct
{
  uint8_NP SrU81B3data0Pos;
  uint8_NP SrU81B3data1Pos;
  uint8_NP SrU81B3data2Pos;
  uint8_NP SrU81B3data3Pos;
  uint8_NP SrU81B3data4Pos;
} RecSg1B3_NP;

#  define Rte_TypeDef_RecSg1B6_NP
typedef struct
{
  uint8_NP SrU81B6data0Pos;
  uint8_NP SrU81B6data1Pos;
  uint8_NP SrU81B6data2Pos;
  uint8_NP SrU81B6data3Pos;
  uint8_NP SrU81B6data4Pos;
  uint8_NP SrU81B6data5Pos;
  uint8_NP SrU81B6data6Pos;
  uint8_NP SrU81B6data7Pos;
} RecSg1B6_NP;

#  define Rte_TypeDef_RecSg1C3_NP
typedef struct
{
  uint8_NP SrU81C3data0Pos;
  uint8_NP SrU81C3data1Pos;
  uint8_NP SrU81C3data2Pos;
  uint8_NP SrU81C3data3Pos;
  uint8_NP SrU81C3data4Pos;
  uint8_NP SrU81C3data5Pos;
  uint8_NP SrU81C3data6Pos;
  uint8_NP SrU81C3data7Pos;
} RecSg1C3_NP;

#  define Rte_TypeDef_RecSg208_NP
typedef struct
{
  uint8_NP SrU8208data0Pos;
  uint8_NP SrU8208data1Pos;
} RecSg208_NP;

#  define Rte_TypeDef_RecSg20A_NP
typedef struct
{
  uint8_NP SrU820Adata0Pos;
  uint8_NP SrU820Adata1Pos;
  uint8_NP SrU820Adata2Pos;
  uint8_NP SrU820Adata3Pos;
  uint8_NP SrU820Adata4Pos;
  uint8_NP SrU820Adata5Pos;
  uint8_NP SrU820Adata6Pos;
  uint8_NP SrU820Adata7Pos;
} RecSg20A_NP;

#  define Rte_TypeDef_RecSg20B_NP
typedef struct
{
  uint8_NP SrU820Bdata0Pos;
  uint8_NP SrU820Bdata1Pos;
  uint8_NP SrU820Bdata2Pos;
  uint8_NP SrU820Bdata3Pos;
  uint8_NP SrU820Bdata4Pos;
  uint8_NP SrU820Bdata5Pos;
} RecSg20B_NP;

#  define Rte_TypeDef_RecSg20F_NP
typedef struct
{
  uint8_NP SrU820Fdata0Pos;
} RecSg20F_NP;

#  define Rte_TypeDef_RecSg21B_NP
typedef struct
{
  uint8_NP SrU821Bdata0Pos;
  uint8_NP SrU821Bdata1Pos;
  uint8_NP SrU821Bdata2Pos;
  uint8_NP SrU821Bdata3Pos;
  uint8_NP SrU821Bdata4Pos;
  uint8_NP SrU821Bdata5Pos;
  uint8_NP SrU821Bdata6Pos;
  uint8_NP SrU821Bdata7Pos;
} RecSg21B_NP;

#  define Rte_TypeDef_RecSg221_NP
typedef struct
{
  uint8_NP SrU8221data0Pos;
  uint8_NP SrU8221data1Pos;
  uint8_NP SrU8221data2Pos;
  uint8_NP SrU8221data3Pos;
  uint8_NP SrU8221data4Pos;
  uint8_NP SrU8221data5Pos;
  uint8_NP SrU8221data6Pos;
  uint8_NP SrU8221data7Pos;
} RecSg221_NP;

#  define Rte_TypeDef_RecSg224_NP
typedef struct
{
  uint8_NP SrU8224data0Pos;
  uint8_NP SrU8224data1Pos;
  uint8_NP SrU8224data2Pos;
  uint8_NP SrU8224data3Pos;
  uint8_NP SrU8224data4Pos;
  uint8_NP SrU8224data5Pos;
  uint8_NP SrU8224data6Pos;
  uint8_NP SrU8224data7Pos;
} RecSg224_NP;

#  define Rte_TypeDef_RecSg23A_NP
typedef struct
{
  uint8_NP SrU823Adata0Pos;
  uint8_NP SrU823Adata1Pos;
  uint8_NP SrU823Adata2Pos;
  uint8_NP SrU823Adata3Pos;
  uint8_NP SrU823Adata4Pos;
  uint8_NP SrU823Adata5Pos;
  uint8_NP SrU823Adata6Pos;
  uint8_NP SrU823Adata7Pos;
} RecSg23A_NP;

#  define Rte_TypeDef_RecSg258_NP
typedef struct
{
  uint8_NP SrU8258data0Pos;
  uint8_NP SrU8258data1Pos;
  uint8_NP SrU8258data2Pos;
  uint8_NP SrU8258data3Pos;
  uint8_NP SrU8258data4Pos;
  uint8_NP SrU8258data5Pos;
  uint8_NP SrU8258data6Pos;
  uint8_NP SrU8258data7Pos;
} RecSg258_NP;

#  define Rte_TypeDef_RecSg259_NP
typedef struct
{
  uint8_NP SrU8259data0Pos;
  uint8_NP SrU8259data1Pos;
  uint8_NP SrU8259data2Pos;
  uint8_NP SrU8259data3Pos;
  uint8_NP SrU8259data4Pos;
  uint8_NP SrU8259data5Pos;
  uint8_NP SrU8259data6Pos;
  uint8_NP SrU8259data7Pos;
} RecSg259_NP;

#  define Rte_TypeDef_RecSg25F_NP
typedef struct
{
  uint8_NP SrU825Fdata0Pos;
  uint8_NP SrU825Fdata1Pos;
  uint8_NP SrU825Fdata2Pos;
  uint8_NP SrU825Fdata3Pos;
  uint8_NP SrU825Fdata4Pos;
  uint8_NP SrU825Fdata5Pos;
  uint8_NP SrU825Fdata6Pos;
} RecSg25F_NP;

#  define Rte_TypeDef_RecSg261_NP
typedef struct
{
  uint8_NP SrU8261data0Pos;
} RecSg261_NP;

#  define Rte_TypeDef_RecSg27A_NP
typedef struct
{
  uint8_NP SrU827Adata0Pos;
  uint8_NP SrU827Adata1Pos;
  uint8_NP SrU827Adata2Pos;
  uint8_NP SrU827Adata3Pos;
  uint8_NP SrU827Adata4Pos;
  uint8_NP SrU827Adata5Pos;
  uint8_NP SrU827Adata6Pos;
} RecSg27A_NP;

#  define Rte_TypeDef_RecSg27E_NP
typedef struct
{
  uint8_NP SrU827Edata0Pos;
  uint8_NP SrU827Edata1Pos;
  uint8_NP SrU827Edata2Pos;
  uint8_NP SrU827Edata3Pos;
  uint8_NP SrU827Edata4Pos;
  uint8_NP SrU827Edata5Pos;
  uint8_NP SrU827Edata6Pos;
  uint8_NP SrU827Edata7Pos;
} RecSg27E_NP;

#  define Rte_TypeDef_RecSg283_NP
typedef struct
{
  uint8_NP SrU8283data0Pos;
  uint8_NP SrU8283data1Pos;
  uint8_NP SrU8283data2Pos;
  uint8_NP SrU8283data3Pos;
  uint8_NP SrU8283data4Pos;
} RecSg283_NP;

#  define Rte_TypeDef_RecSg285_NP
typedef struct
{
  uint8_NP SrU8285data0Pos;
  uint8_NP SrU8285data1Pos;
  uint8_NP SrU8285data2Pos;
  uint8_NP SrU8285data3Pos;
  uint8_NP SrU8285data4Pos;
  uint8_NP SrU8285data5Pos;
  uint8_NP SrU8285data6Pos;
  uint8_NP SrU8285data7Pos;
} RecSg285_NP;

#  define Rte_TypeDef_RecSg288_NP
typedef struct
{
  uint8_NP SrU8288data0Pos;
  uint8_NP SrU8288data1Pos;
  uint8_NP SrU8288data2Pos;
  uint8_NP SrU8288data3Pos;
  uint8_NP SrU8288data4Pos;
} RecSg288_NP;

#  define Rte_TypeDef_RecSg28E_NP
typedef struct
{
  uint8_NP SrU828Edata0Pos;
  uint8_NP SrU828Edata1Pos;
  uint8_NP SrU828Edata2Pos;
  uint8_NP SrU828Edata3Pos;
  uint8_NP SrU828Edata4Pos;
  uint8_NP SrU828Edata5Pos;
} RecSg28E_NP;

#  define Rte_TypeDef_RecSg28F_NP
typedef struct
{
  uint8_NP SrU828Fdata0Pos;
  uint8_NP SrU828Fdata1Pos;
  uint8_NP SrU828Fdata2Pos;
  uint8_NP SrU828Fdata3Pos;
  uint8_NP SrU828Fdata4Pos;
} RecSg28F_NP;

#  define Rte_TypeDef_RecSg292_NP
typedef struct
{
  uint8_NP SrU8292data0Pos;
  uint8_NP SrU8292data1Pos;
  uint8_NP SrU8292data2Pos;
  uint8_NP SrU8292data3Pos;
  uint8_NP SrU8292data4Pos;
  uint8_NP SrU8292data5Pos;
  uint8_NP SrU8292data6Pos;
  uint8_NP SrU8292data7Pos;
} RecSg292_NP;

#  define Rte_TypeDef_RecSg296_NP
typedef struct
{
  uint8_NP SrU8296data0Pos;
  uint8_NP SrU8296data1Pos;
} RecSg296_NP;

#  define Rte_TypeDef_RecSg299_NP
typedef struct
{
  uint8_NP SrU8299data0Pos;
  uint8_NP SrU8299data1Pos;
  uint8_NP SrU8299data2Pos;
  uint8_NP SrU8299data3Pos;
  uint8_NP SrU8299data4Pos;
  uint8_NP SrU8299data5Pos;
  uint8_NP SrU8299data6Pos;
  uint8_NP SrU8299data7Pos;
} RecSg299_NP;

#  define Rte_TypeDef_RecSg29A_NP
typedef struct
{
  uint8_NP SrU829Adata0Pos;
  uint8_NP SrU829Adata1Pos;
  uint8_NP SrU829Adata2Pos;
  uint8_NP SrU829Adata3Pos;
  uint8_NP SrU829Adata4Pos;
  uint8_NP SrU829Adata5Pos;
  uint8_NP SrU829Adata6Pos;
  uint8_NP SrU829Adata7Pos;
} RecSg29A_NP;

#  define Rte_TypeDef_RecSg2A2_NP
typedef struct
{
  uint8_NP SrU82A2data0Pos;
  uint8_NP SrU82A2data1Pos;
} RecSg2A2_NP;

#  define Rte_TypeDef_RecSg2AA_NP
typedef struct
{
  uint8_NP SrU82AAdata0Pos;
  uint8_NP SrU82AAdata1Pos;
  uint8_NP SrU82AAdata2Pos;
  uint8_NP SrU82AAdata3Pos;
  uint8_NP SrU82AAdata4Pos;
  uint8_NP SrU82AAdata5Pos;
  uint8_NP SrU82AAdata6Pos;
  uint8_NP SrU82AAdata7Pos;
} RecSg2AA_NP;

#  define Rte_TypeDef_RecSg2AB_NP
typedef struct
{
  uint8_NP SrU82ABdata0Pos;
  uint8_NP SrU82ABdata1Pos;
  uint8_NP SrU82ABdata2Pos;
  uint8_NP SrU82ABdata3Pos;
  uint8_NP SrU82ABdata4Pos;
  uint8_NP SrU82ABdata5Pos;
  uint8_NP SrU82ABdata6Pos;
  uint8_NP SrU82ABdata7Pos;
} RecSg2AB_NP;

#  define Rte_TypeDef_RecSg2B1_NP
typedef struct
{
  uint8_NP SrU82B1data0Pos;
  uint8_NP SrU82B1data1Pos;
  uint8_NP SrU82B1data2Pos;
  uint8_NP SrU82B1data3Pos;
  uint8_NP SrU82B1data4Pos;
  uint8_NP SrU82B1data5Pos;
  uint8_NP SrU82B1data6Pos;
  uint8_NP SrU82B1data7Pos;
} RecSg2B1_NP;

#  define Rte_TypeDef_RecSg2B2_NP
typedef struct
{
  uint8_NP SrU82B2data0Pos;
  uint8_NP SrU82B2data1Pos;
  uint8_NP SrU82B2data2Pos;
  uint8_NP SrU82B2data3Pos;
  uint8_NP SrU82B2data4Pos;
  uint8_NP SrU82B2data5Pos;
  uint8_NP SrU82B2data6Pos;
  uint8_NP SrU82B2data7Pos;
} RecSg2B2_NP;

#  define Rte_TypeDef_RecSg2BF_NP
typedef struct
{
  uint8_NP SrU82BFdata0Pos;
  uint8_NP SrU82BFdata1Pos;
  uint8_NP SrU82BFdata2Pos;
  uint8_NP SrU82BFdata3Pos;
  uint8_NP SrU82BFdata4Pos;
  uint8_NP SrU82BFdata5Pos;
  uint8_NP SrU82BFdata6Pos;
  uint8_NP SrU82BFdata7Pos;
} RecSg2BF_NP;

#  define Rte_TypeDef_RecSg2CC_6_NP
typedef struct
{
  uint8_NP SrU82CCdata0Pos;
  uint8_NP SrU82CCdata1Pos;
  uint8_NP SrU82CCdata2Pos;
  uint8_NP SrU82CCdata3Pos;
  uint8_NP SrU82CCdata4Pos;
  uint8_NP SrU82CCdata5Pos;
} RecSg2CC_6_NP;

#  define Rte_TypeDef_RecSg2D3_NP
typedef struct
{
  uint8_NP SrU82D3data0Pos;
  uint8_NP SrU82D3data1Pos;
  uint8_NP SrU82D3data2Pos;
  uint8_NP SrU82D3data3Pos;
  uint8_NP SrU82D3data4Pos;
  uint8_NP SrU82D3data5Pos;
  uint8_NP SrU82D3data6Pos;
  uint8_NP SrU82D3data7Pos;
} RecSg2D3_NP;

#  define Rte_TypeDef_RecSg2D4_NP
typedef struct
{
  uint8_NP SrU82D4data0Pos;
  uint8_NP SrU82D4data1Pos;
  uint8_NP SrU82D4data2Pos;
  uint8_NP SrU82D4data3Pos;
  uint8_NP SrU82D4data4Pos;
} RecSg2D4_NP;

#  define Rte_TypeDef_RecSg2D9_NP
typedef struct
{
  uint8_NP SrU82D9data0Pos;
  uint8_NP SrU82D9data1Pos;
  uint8_NP SrU82D9data2Pos;
  uint8_NP SrU82D9data3Pos;
  uint8_NP SrU82D9data4Pos;
  uint8_NP SrU82D9data5Pos;
  uint8_NP SrU82D9data6Pos;
  uint8_NP SrU82D9data7Pos;
} RecSg2D9_NP;

#  define Rte_TypeDef_RecSg2DA_NP
typedef struct
{
  uint8_NP SrU82DAdata0Pos;
  uint8_NP SrU82DAdata1Pos;
  uint8_NP SrU82DAdata2Pos;
  uint8_NP SrU82DAdata3Pos;
  uint8_NP SrU82DAdata4Pos;
  uint8_NP SrU82DAdata5Pos;
  uint8_NP SrU82DAdata6Pos;
  uint8_NP SrU82DAdata7Pos;
} RecSg2DA_NP;

#  define Rte_TypeDef_RecSg2DB_NP
typedef struct
{
  uint8_NP SrU82DBdata0Pos;
  uint8_NP SrU82DBdata1Pos;
  uint8_NP SrU82DBdata2Pos;
  uint8_NP SrU82DBdata3Pos;
  uint8_NP SrU82DBdata4Pos;
  uint8_NP SrU82DBdata5Pos;
  uint8_NP SrU82DBdata6Pos;
  uint8_NP SrU82DBdata7Pos;
} RecSg2DB_NP;

#  define Rte_TypeDef_RecSg2DF_NP
typedef struct
{
  uint8_NP SrU82DFdata0Pos;
  uint8_NP SrU82DFdata1Pos;
  uint8_NP SrU82DFdata2Pos;
  uint8_NP SrU82DFdata3Pos;
  uint8_NP SrU82DFdata4Pos;
  uint8_NP SrU82DFdata5Pos;
  uint8_NP SrU82DFdata6Pos;
  uint8_NP SrU82DFdata7Pos;
} RecSg2DF_NP;

#  define Rte_TypeDef_RecSg2E2_NP
typedef struct
{
  uint8_NP SrU82E2data0Pos;
  uint8_NP SrU82E2data1Pos;
  uint8_NP SrU82E2data2Pos;
  uint8_NP SrU82E2data3Pos;
  uint8_NP SrU82E2data4Pos;
  uint8_NP SrU82E2data5Pos;
  uint8_NP SrU82E2data6Pos;
  uint8_NP SrU82E2data7Pos;
} RecSg2E2_NP;

#  define Rte_TypeDef_RecSg2E3_NP
typedef struct
{
  uint8_NP SrU82E3data0Pos;
  uint8_NP SrU82E3data1Pos;
  uint8_NP SrU82E3data2Pos;
  uint8_NP SrU82E3data3Pos;
  uint8_NP SrU82E3data4Pos;
  uint8_NP SrU82E3data5Pos;
  uint8_NP SrU82E3data6Pos;
  uint8_NP SrU82E3data7Pos;
} RecSg2E3_NP;

#  define Rte_TypeDef_RecSg2E4_NP
typedef struct
{
  uint8_NP SrU82E4data0Pos;
  uint8_NP SrU82E4data1Pos;
  uint8_NP SrU82E4data2Pos;
  uint8_NP SrU82E4data3Pos;
  uint8_NP SrU82E4data4Pos;
  uint8_NP SrU82E4data5Pos;
  uint8_NP SrU82E4data6Pos;
  uint8_NP SrU82E4data7Pos;
} RecSg2E4_NP;

#  define Rte_TypeDef_RecSg2E5_NP
typedef struct
{
  uint8_NP SrU82E5data0Pos;
  uint8_NP SrU82E5data1Pos;
  uint8_NP SrU82E5data2Pos;
  uint8_NP SrU82E5data3Pos;
  uint8_NP SrU82E5data4Pos;
  uint8_NP SrU82E5data5Pos;
  uint8_NP SrU82E5data6Pos;
  uint8_NP SrU82E5data7Pos;
} RecSg2E5_NP;

#  define Rte_TypeDef_RecSg2E6_NP
typedef struct
{
  uint8_NP SrU82E6data0Pos;
  uint8_NP SrU82E6data1Pos;
  uint8_NP SrU82E6data2Pos;
  uint8_NP SrU82E6data3Pos;
  uint8_NP SrU82E6data4Pos;
  uint8_NP SrU82E6data5Pos;
  uint8_NP SrU82E6data6Pos;
  uint8_NP SrU82E6data7Pos;
} RecSg2E6_NP;

#  define Rte_TypeDef_RecSg2E7_NP
typedef struct
{
  uint8_NP SrU82E7data0Pos;
  uint8_NP SrU82E7data1Pos;
  uint8_NP SrU82E7data2Pos;
  uint8_NP SrU82E7data3Pos;
  uint8_NP SrU82E7data4Pos;
  uint8_NP SrU82E7data5Pos;
  uint8_NP SrU82E7data6Pos;
  uint8_NP SrU82E7data7Pos;
} RecSg2E7_NP;

#  define Rte_TypeDef_RecSg2E8_NP
typedef struct
{
  uint8_NP SrU82E8data0Pos;
  uint8_NP SrU82E8data1Pos;
  uint8_NP SrU82E8data2Pos;
  uint8_NP SrU82E8data3Pos;
  uint8_NP SrU82E8data4Pos;
  uint8_NP SrU82E8data5Pos;
  uint8_NP SrU82E8data6Pos;
  uint8_NP SrU82E8data7Pos;
} RecSg2E8_NP;

#  define Rte_TypeDef_RecSg2E9_NP
typedef struct
{
  uint8_NP SrU82E9data0Pos;
  uint8_NP SrU82E9data1Pos;
  uint8_NP SrU82E9data2Pos;
  uint8_NP SrU82E9data3Pos;
  uint8_NP SrU82E9data4Pos;
  uint8_NP SrU82E9data5Pos;
  uint8_NP SrU82E9data6Pos;
  uint8_NP SrU82E9data7Pos;
} RecSg2E9_NP;

#  define Rte_TypeDef_RecSg2EA_NP
typedef struct
{
  uint8_NP SrU82EAdata0Pos;
  uint8_NP SrU82EAdata1Pos;
  uint8_NP SrU82EAdata2Pos;
  uint8_NP SrU82EAdata3Pos;
  uint8_NP SrU82EAdata4Pos;
  uint8_NP SrU82EAdata5Pos;
  uint8_NP SrU82EAdata6Pos;
  uint8_NP SrU82EAdata7Pos;
} RecSg2EA_NP;

#  define Rte_TypeDef_RecSg2EB_NP
typedef struct
{
  uint8_NP SrU82EBdata0Pos;
  uint8_NP SrU82EBdata1Pos;
  uint8_NP SrU82EBdata2Pos;
  uint8_NP SrU82EBdata3Pos;
  uint8_NP SrU82EBdata4Pos;
  uint8_NP SrU82EBdata5Pos;
  uint8_NP SrU82EBdata6Pos;
  uint8_NP SrU82EBdata7Pos;
} RecSg2EB_NP;

#  define Rte_TypeDef_RecSg2ED_NP
typedef struct
{
  uint8_NP SrU82EDdata0Pos;
  uint8_NP SrU82EDdata1Pos;
  uint8_NP SrU82EDdata2Pos;
  uint8_NP SrU82EDdata3Pos;
  uint8_NP SrU82EDdata4Pos;
  uint8_NP SrU82EDdata5Pos;
} RecSg2ED_NP;

#  define Rte_TypeDef_RecSg2F6_NP
typedef struct
{
  uint8_NP SrU82F6data0Pos;
  uint8_NP SrU82F6data1Pos;
  uint8_NP SrU82F6data2Pos;
} RecSg2F6_NP;

#  define Rte_TypeDef_RecSg300_NP
typedef struct
{
  uint8_NP SrU8300data0Pos;
  uint8_NP SrU8300data1Pos;
  uint8_NP SrU8300data2Pos;
  uint8_NP SrU8300data3Pos;
  uint8_NP SrU8300data4Pos;
  uint8_NP SrU8300data5Pos;
} RecSg300_NP;

#  define Rte_TypeDef_RecSg30B_NP
typedef struct
{
  uint8_NP SrU830Bdata0Pos;
  uint8_NP SrU830Bdata1Pos;
  uint8_NP SrU830Bdata2Pos;
  uint8_NP SrU830Bdata3Pos;
  uint8_NP SrU830Bdata4Pos;
  uint8_NP SrU830Bdata5Pos;
  uint8_NP SrU830Bdata6Pos;
} RecSg30B_NP;

#  define Rte_TypeDef_RecSg30C_NP
typedef struct
{
  uint8_NP SrU830Cdata0Pos;
  uint8_NP SrU830Cdata1Pos;
  uint8_NP SrU830Cdata2Pos;
  uint8_NP SrU830Cdata3Pos;
  uint8_NP SrU830Cdata4Pos;
  uint8_NP SrU830Cdata5Pos;
  uint8_NP SrU830Cdata6Pos;
  uint8_NP SrU830Cdata7Pos;
} RecSg30C_NP;

#  define Rte_TypeDef_RecSg30D_NP
typedef struct
{
  uint8_NP SrU830Ddata0Pos;
  uint8_NP SrU830Ddata1Pos;
  uint8_NP SrU830Ddata2Pos;
  uint8_NP SrU830Ddata3Pos;
  uint8_NP SrU830Ddata4Pos;
  uint8_NP SrU830Ddata5Pos;
  uint8_NP SrU830Ddata6Pos;
} RecSg30D_NP;

#  define Rte_TypeDef_RecSg30E_NP
typedef struct
{
  uint8_NP SrU830Edata0Pos;
  uint8_NP SrU830Edata1Pos;
  uint8_NP SrU830Edata2Pos;
  uint8_NP SrU830Edata3Pos;
  uint8_NP SrU830Edata4Pos;
  uint8_NP SrU830Edata5Pos;
  uint8_NP SrU830Edata6Pos;
} RecSg30E_NP;

#  define Rte_TypeDef_RecSg30F_NP
typedef struct
{
  uint8_NP SrU830Fdata0Pos;
  uint8_NP SrU830Fdata1Pos;
  uint8_NP SrU830Fdata2Pos;
} RecSg30F_NP;

#  define Rte_TypeDef_RecSg341_NP
typedef struct
{
  uint8_NP SrU8341data0Pos;
  uint8_NP SrU8341data1Pos;
  uint8_NP SrU8341data2Pos;
  uint8_NP SrU8341data3Pos;
  uint8_NP SrU8341data4Pos;
  uint8_NP SrU8341data5Pos;
  uint8_NP SrU8341data6Pos;
} RecSg341_NP;

#  define Rte_TypeDef_RecSg342_NP
typedef struct
{
  uint8_NP SrU8342data0Pos;
  uint8_NP SrU8342data1Pos;
  uint8_NP SrU8342data2Pos;
  uint8_NP SrU8342data3Pos;
  uint8_NP SrU8342data4Pos;
  uint8_NP SrU8342data5Pos;
  uint8_NP SrU8342data6Pos;
} RecSg342_NP;

#  define Rte_TypeDef_RecSg350_NP
typedef struct
{
  uint8_NP SrU8350data0Pos;
  uint8_NP SrU8350data1Pos;
  uint8_NP SrU8350data2Pos;
  uint8_NP SrU8350data3Pos;
  uint8_NP SrU8350data4Pos;
  uint8_NP SrU8350data5Pos;
  uint8_NP SrU8350data6Pos;
} RecSg350_NP;

#  define Rte_TypeDef_RecSg351_NP
typedef struct
{
  uint8_NP SrU8351data0Pos;
  uint8_NP SrU8351data1Pos;
  uint8_NP SrU8351data2Pos;
  uint8_NP SrU8351data3Pos;
  uint8_NP SrU8351data4Pos;
  uint8_NP SrU8351data5Pos;
  uint8_NP SrU8351data6Pos;
} RecSg351_NP;

#  define Rte_TypeDef_RecSg353_NP
typedef struct
{
  uint8_NP SrU8353data0Pos;
  uint8_NP SrU8353data1Pos;
  uint8_NP SrU8353data2Pos;
  uint8_NP SrU8353data3Pos;
  uint8_NP SrU8353data4Pos;
  uint8_NP SrU8353data5Pos;
  uint8_NP SrU8353data6Pos;
  uint8_NP SrU8353data7Pos;
} RecSg353_NP;

#  define Rte_TypeDef_RecSg355_NP
typedef struct
{
  uint8_NP SrU8355data0Pos;
  uint8_NP SrU8355data1Pos;
  uint8_NP SrU8355data2Pos;
  uint8_NP SrU8355data3Pos;
  uint8_NP SrU8355data4Pos;
  uint8_NP SrU8355data5Pos;
  uint8_NP SrU8355data6Pos;
} RecSg355_NP;

#  define Rte_TypeDef_RecSg357_NP
typedef struct
{
  uint8_NP SrU8357data0Pos;
  uint8_NP SrU8357data1Pos;
  uint8_NP SrU8357data2Pos;
  uint8_NP SrU8357data3Pos;
  uint8_NP SrU8357data4Pos;
  uint8_NP SrU8357data5Pos;
  uint8_NP SrU8357data6Pos;
  uint8_NP SrU8357data7Pos;
} RecSg357_NP;

#  define Rte_TypeDef_RecSg358_NP
typedef struct
{
  uint8_NP SrU8358data0Pos;
  uint8_NP SrU8358data1Pos;
  uint8_NP SrU8358data2Pos;
  uint8_NP SrU8358data3Pos;
  uint8_NP SrU8358data4Pos;
  uint8_NP SrU8358data5Pos;
  uint8_NP SrU8358data6Pos;
} RecSg358_NP;

#  define Rte_TypeDef_RecSg35E_NP
typedef struct
{
  uint8_NP SrU835Edata0Pos;
  uint8_NP SrU835Edata1Pos;
  uint8_NP SrU835Edata2Pos;
  uint8_NP SrU835Edata3Pos;
  uint8_NP SrU835Edata4Pos;
  uint8_NP SrU835Edata5Pos;
  uint8_NP SrU835Edata6Pos;
} RecSg35E_NP;

#  define Rte_TypeDef_RecSg35F_NP
typedef struct
{
  uint8_NP SrU835Fdata0Pos;
  uint8_NP SrU835Fdata1Pos;
  uint8_NP SrU835Fdata2Pos;
  uint8_NP SrU835Fdata3Pos;
  uint8_NP SrU835Fdata4Pos;
  uint8_NP SrU835Fdata5Pos;
  uint8_NP SrU835Fdata6Pos;
} RecSg35F_NP;

#  define Rte_TypeDef_RecSg36D_NP
typedef struct
{
  uint8_NP SrU836Ddata0Pos;
  uint8_NP SrU836Ddata1Pos;
  uint8_NP SrU836Ddata2Pos;
  uint8_NP SrU836Ddata3Pos;
  uint8_NP SrU836Ddata4Pos;
  uint8_NP SrU836Ddata5Pos;
  uint8_NP SrU836Ddata6Pos;
} RecSg36D_NP;

#  define Rte_TypeDef_RecSg370_NP
typedef struct
{
  uint8_NP SrU8370data0Pos;
  uint8_NP SrU8370data1Pos;
  uint8_NP SrU8370data2Pos;
  uint8_NP SrU8370data3Pos;
  uint8_NP SrU8370data4Pos;
  uint8_NP SrU8370data5Pos;
  uint8_NP SrU8370data6Pos;
} RecSg370_NP;

#  define Rte_TypeDef_RecSg380_NP
typedef struct
{
  uint8_NP SrU8380data0Pos;
  uint8_NP SrU8380data1Pos;
  uint8_NP SrU8380data2Pos;
  uint8_NP SrU8380data3Pos;
  uint8_NP SrU8380data4Pos;
  uint8_NP SrU8380data5Pos;
  uint8_NP SrU8380data6Pos;
} RecSg380_NP;

#  define Rte_TypeDef_RecSg38A_NP
typedef struct
{
  uint8_NP SrU838Adata0Pos;
  uint8_NP SrU838Adata1Pos;
  uint8_NP SrU838Adata2Pos;
  uint8_NP SrU838Adata3Pos;
  uint8_NP SrU838Adata4Pos;
  uint8_NP SrU838Adata5Pos;
  uint8_NP SrU838Adata6Pos;
} RecSg38A_NP;

#  define Rte_TypeDef_RecSg3D0_NP
typedef struct
{
  uint8_NP SrU83D0data0Pos;
  uint8_NP SrU83D0data1Pos;
  uint8_NP SrU83D0data2Pos;
  uint8_NP SrU83D0data3Pos;
  uint8_NP SrU83D0data4Pos;
  uint8_NP SrU83D0data5Pos;
} RecSg3D0_NP;

#  define Rte_TypeDef_RecSg3D3_NP
typedef struct
{
  uint8_NP SrU83D3data0Pos;
  uint8_NP SrU83D3data1Pos;
  uint8_NP SrU83D3data2Pos;
} RecSg3D3_NP;

#  define Rte_TypeDef_RecSg3F0_NP
typedef struct
{
  uint8_NP SrU83F0data0Pos;
  uint8_NP SrU83F0data1Pos;
  uint8_NP SrU83F0data2Pos;
  uint8_NP SrU83F0data3Pos;
  uint8_NP SrU83F0data4Pos;
  uint8_NP SrU83F0data5Pos;
  uint8_NP SrU83F0data6Pos;
} RecSg3F0_NP;

#  define Rte_TypeDef_RecSg3F1_NP
typedef struct
{
  uint8_NP SrU83F1data0Pos;
  uint8_NP SrU83F1data1Pos;
  uint8_NP SrU83F1data2Pos;
  uint8_NP SrU83F1data3Pos;
  uint8_NP SrU83F1data4Pos;
  uint8_NP SrU83F1data5Pos;
  uint8_NP SrU83F1data6Pos;
  uint8_NP SrU83F1data7Pos;
} RecSg3F1_NP;

#  define Rte_TypeDef_RecSg3F2_NP
typedef struct
{
  uint8_NP SrU83F2data0Pos;
  uint8_NP SrU83F2data1Pos;
  uint8_NP SrU83F2data2Pos;
  uint8_NP SrU83F2data3Pos;
  uint8_NP SrU83F2data4Pos;
  uint8_NP SrU83F2data5Pos;
  uint8_NP SrU83F2data6Pos;
  uint8_NP SrU83F2data7Pos;
} RecSg3F2_NP;

#  define Rte_TypeDef_RecSg3F3_NP
typedef struct
{
  uint8_NP SrU83F3data0Pos;
  uint8_NP SrU83F3data1Pos;
  uint8_NP SrU83F3data2Pos;
  uint8_NP SrU83F3data3Pos;
  uint8_NP SrU83F3data4Pos;
  uint8_NP SrU83F3data5Pos;
  uint8_NP SrU83F3data6Pos;
} RecSg3F3_NP;

#  define Rte_TypeDef_RecSg3F4_NP
typedef struct
{
  uint8_NP SrU83F4data0Pos;
  uint8_NP SrU83F4data1Pos;
  uint8_NP SrU83F4data2Pos;
  uint8_NP SrU83F4data3Pos;
  uint8_NP SrU83F4data4Pos;
  uint8_NP SrU83F4data5Pos;
  uint8_NP SrU83F4data6Pos;
  uint8_NP SrU83F4data7Pos;
} RecSg3F4_NP;

#  define Rte_TypeDef_RecSg3F5_NP
typedef struct
{
  uint8_NP SrU83F5data0Pos;
  uint8_NP SrU83F5data1Pos;
  uint8_NP SrU83F5data2Pos;
  uint8_NP SrU83F5data3Pos;
  uint8_NP SrU83F5data4Pos;
  uint8_NP SrU83F5data5Pos;
  uint8_NP SrU83F5data6Pos;
  uint8_NP SrU83F5data7Pos;
} RecSg3F5_NP;

#  define Rte_TypeDef_RecSg3FB_NP
typedef struct
{
  uint8_NP SrU83FBdata0Pos;
  uint8_NP SrU83FBdata1Pos;
  uint8_NP SrU83FBdata2Pos;
  uint8_NP SrU83FBdata3Pos;
  uint8_NP SrU83FBdata4Pos;
  uint8_NP SrU83FBdata5Pos;
  uint8_NP SrU83FBdata6Pos;
  uint8_NP SrU83FBdata7Pos;
} RecSg3FB_NP;

#  define Rte_TypeDef_RecSg3FC_NP
typedef struct
{
  uint8_NP SrU83FCdata0Pos;
  uint8_NP SrU83FCdata1Pos;
  uint8_NP SrU83FCdata2Pos;
  uint8_NP SrU83FCdata3Pos;
  uint8_NP SrU83FCdata4Pos;
  uint8_NP SrU83FCdata5Pos;
  uint8_NP SrU83FCdata6Pos;
  uint8_NP SrU83FCdata7Pos;
} RecSg3FC_NP;

#  define Rte_TypeDef_RecSg3FD_NP
typedef struct
{
  uint8_NP SrU83FDdata0Pos;
  uint8_NP SrU83FDdata1Pos;
  uint8_NP SrU83FDdata2Pos;
  uint8_NP SrU83FDdata3Pos;
  uint8_NP SrU83FDdata4Pos;
  uint8_NP SrU83FDdata5Pos;
  uint8_NP SrU83FDdata6Pos;
  uint8_NP SrU83FDdata7Pos;
} RecSg3FD_NP;

#  define Rte_TypeDef_RecSg3FE_NP
typedef struct
{
  uint8_NP SrU83FEdata0Pos;
  uint8_NP SrU83FEdata1Pos;
  uint8_NP SrU83FEdata2Pos;
  uint8_NP SrU83FEdata3Pos;
  uint8_NP SrU83FEdata4Pos;
  uint8_NP SrU83FEdata5Pos;
  uint8_NP SrU83FEdata6Pos;
  uint8_NP SrU83FEdata7Pos;
} RecSg3FE_NP;

#  define Rte_TypeDef_RecSg412_NP
typedef struct
{
  uint8_NP SrU8412data0Pos;
  uint8_NP SrU8412data1Pos;
  uint8_NP SrU8412data2Pos;
  uint8_NP SrU8412data3Pos;
  uint8_NP SrU8412data4Pos;
  uint8_NP SrU8412data5Pos;
  uint8_NP SrU8412data6Pos;
  uint8_NP SrU8412data7Pos;
} RecSg412_NP;

#  define Rte_TypeDef_RecSg41F_NP
typedef struct
{
  uint8_NP SrU841Fdata0Pos;
  uint8_NP SrU841Fdata1Pos;
} RecSg41F_NP;

#  define Rte_TypeDef_RecSg421_NP
typedef struct
{
  uint8_NP SrU8421data0Pos;
  uint8_NP SrU8421data1Pos;
  uint8_NP SrU8421data2Pos;
  uint8_NP SrU8421data3Pos;
  uint8_NP SrU8421data4Pos;
  uint8_NP SrU8421data5Pos;
  uint8_NP SrU8421data6Pos;
  uint8_NP SrU8421data7Pos;
} RecSg421_NP;

#  define Rte_TypeDef_RecSg43D_NP
typedef struct
{
  uint8_NP SrU843Ddata0Pos;
  uint8_NP SrU843Ddata1Pos;
  uint8_NP SrU843Ddata2Pos;
  uint8_NP SrU843Ddata3Pos;
  uint8_NP SrU843Ddata4Pos;
  uint8_NP SrU843Ddata5Pos;
  uint8_NP SrU843Ddata6Pos;
  uint8_NP SrU843Ddata7Pos;
} RecSg43D_NP;

#  define Rte_TypeDef_RecSg450_NP
typedef struct
{
  uint8_NP SrU8450data0Pos;
  uint8_NP SrU8450data1Pos;
  uint8_NP SrU8450data2Pos;
  uint8_NP SrU8450data3Pos;
} RecSg450_NP;

#  define Rte_TypeDef_RecSg453_NP
typedef struct
{
  uint8_NP SrU8453data0Pos;
  uint8_NP SrU8453data1Pos;
  uint8_NP SrU8453data2Pos;
  uint8_NP SrU8453data3Pos;
} RecSg453_NP;

#  define Rte_TypeDef_RecSg454_NP
typedef struct
{
  uint8_NP SrU8454data0_1Pos;
  uint8_NP SrU8454data0_2Pos;
  uint8_NP SrU8454data1Pos;
  uint8_NP SrU8454data2Pos;
  uint8_NP SrU8454data3Pos;
  uint8_NP SrU8454data4Pos;
  uint8_NP SrU8454data5Pos;
  uint8_NP SrU8454data6Pos;
  uint8_NP SrU8454data7Pos;
} RecSg454_NP;

#  define Rte_TypeDef_RecSg456_NP
typedef struct
{
  uint8_NP SrU8456data0Pos;
  uint8_NP SrU8456data1Pos;
  uint8_NP SrU8456data2Pos;
} RecSg456_NP;

#  define Rte_TypeDef_RecSg457_NP
typedef struct
{
  uint8_NP SrU8457data0Pos;
  uint8_NP SrU8457data1Pos;
  uint8_NP SrU8457data2Pos;
  uint8_NP SrU8457data3Pos;
  uint8_NP SrU8457data4Pos;
  uint8_NP SrU8457data5Pos;
  uint8_NP SrU8457data6Pos;
} RecSg457_NP;

#  define Rte_TypeDef_RecSg4CB_NP
typedef struct
{
  uint8_NP SrU84CBdata0Pos;
  uint8_NP SrU84CBdata1Pos;
  uint8_NP SrU84CBdata2Pos;
  uint8_NP SrU84CBdata3Pos;
  uint8_NP SrU84CBdata4Pos;
  uint8_NP SrU84CBdata5Pos;
  uint8_NP SrU84CBdata6Pos;
  uint8_NP SrU84CBdata7Pos;
} RecSg4CB_NP;

#  define Rte_TypeDef_RecSg4CC_NP
typedef struct
{
  uint8_NP SrU84CCdata0Pos;
  uint8_NP SrU84CCdata1Pos;
  uint8_NP SrU84CCdata2Pos;
  uint8_NP SrU84CCdata3Pos;
  uint8_NP SrU84CCdata4Pos;
  uint8_NP SrU84CCdata5Pos;
  uint8_NP SrU84CCdata6Pos;
  uint8_NP SrU84CCdata7Pos;
} RecSg4CC_NP;

#  define Rte_TypeDef_RecSg4DF_NP
typedef struct
{
  uint8_NP SrU84DFdata0Pos;
  uint8_NP SrU84DFdata1Pos;
  uint8_NP SrU84DFdata2Pos;
  uint8_NP SrU84DFdata3Pos;
} RecSg4DF_NP;

#  define Rte_TypeDef_RecSg4EA_NP
typedef struct
{
  uint8_NP SrU84EAdata0Pos;
  uint8_NP SrU84EAdata1Pos;
  uint8_NP SrU84EAdata2Pos;
  uint8_NP SrU84EAdata3Pos;
  uint8_NP SrU84EAdata4Pos;
  uint8_NP SrU84EAdata5Pos;
  uint8_NP SrU84EAdata6Pos;
  uint8_NP SrU84EAdata7Pos;
} RecSg4EA_NP;

#  define Rte_TypeDef_RecSg4EB_NP
typedef struct
{
  uint8_NP SrU84EBdata0Pos;
  uint8_NP SrU84EBdata1Pos;
  uint8_NP SrU84EBdata2Pos;
  uint8_NP SrU84EBdata3Pos;
  uint8_NP SrU84EBdata4Pos;
  uint8_NP SrU84EBdata5Pos;
  uint8_NP SrU84EBdata6Pos;
  uint8_NP SrU84EBdata7Pos;
} RecSg4EB_NP;

#  define Rte_TypeDef_RecSg4EC_NP
typedef struct
{
  uint8_NP SrU84ECdata0Pos;
  uint8_NP SrU84ECdata1Pos;
  uint8_NP SrU84ECdata2Pos;
  uint8_NP SrU84ECdata3Pos;
  uint8_NP SrU84ECdata4Pos;
  uint8_NP SrU84ECdata5Pos;
  uint8_NP SrU84ECdata6Pos;
  uint8_NP SrU84ECdata7Pos;
} RecSg4EC_NP;

#  define Rte_TypeDef_RecSg4ED_NP
typedef struct
{
  uint8_NP SrU84EDdata0Pos;
  uint8_NP SrU84EDdata1Pos;
  uint8_NP SrU84EDdata2Pos;
  uint8_NP SrU84EDdata3Pos;
  uint8_NP SrU84EDdata4Pos;
} RecSg4ED_NP;

#  define Rte_TypeDef_RecSg4F2_NP
typedef struct
{
  uint8_NP SrU84F2data0Pos;
  uint8_NP SrU84F2data1Pos;
  uint8_NP SrU84F2data2Pos;
  uint8_NP SrU84F2data3Pos;
  uint8_NP SrU84F2data4Pos;
  uint8_NP SrU84F2data5Pos;
  uint8_NP SrU84F2data6Pos;
  uint8_NP SrU84F2data7Pos;
} RecSg4F2_NP;

#  define Rte_TypeDef_RecSg4F9_NP
typedef struct
{
  uint8_NP SrU84F9data0Pos;
  uint8_NP SrU84F9data1Pos;
  uint8_NP SrU84F9data2Pos;
  uint8_NP SrU84F9data3Pos;
  uint8_NP SrU84F9data4Pos;
  uint8_NP SrU84F9data5Pos;
  uint8_NP SrU84F9data6Pos;
} RecSg4F9_NP;

#  define Rte_TypeDef_RecSg502_NP
typedef struct
{
  uint8_NP SrU8502data0Pos;
  uint8_NP SrU8502data1Pos;
  uint8_NP SrU8502data2Pos;
  uint8_NP SrU8502data3Pos;
  uint8_NP SrU8502data4Pos;
} RecSg502_NP;

#  define Rte_TypeDef_RecSg560_NP
typedef struct
{
  uint8_NP SrU8560data0Pos;
  uint8_NP SrU8560data1Pos;
  uint8_NP SrU8560data2Pos;
  uint8_NP SrU8560data3Pos;
  uint8_NP SrU8560data4Pos;
  uint8_NP SrU8560data5Pos;
} RecSg560_NP;

#  define Rte_TypeDef_RecSg5C0_NP
typedef struct
{
  uint8_NP SrU85C0data0Pos;
  uint8_NP SrU85C0data1Pos;
  uint8_NP SrU85C0data2Pos;
  uint8_NP SrU85C0data3Pos;
  uint8_NP SrU85C0data4Pos;
  uint8_NP SrU85C0data5Pos;
  uint8_NP SrU85C0data6Pos;
  uint8_NP SrU85C0data7Pos;
} RecSg5C0_NP;

#  define Rte_TypeDef_RecSg5C6_NP
typedef struct
{
  uint8_NP SrU85C6data0Pos;
  uint8_NP SrU85C6data1Pos;
  uint8_NP SrU85C6data2Pos;
  uint8_NP SrU85C6data3Pos;
  uint8_NP SrU85C6data4Pos;
  uint8_NP SrU85C6data5Pos;
} RecSg5C6_NP;

#  define Rte_TypeDef_RecSg5D9_NP
typedef struct
{
  uint8_NP SrU85D9data0Pos;
  uint8_NP SrU85D9data1Pos;
  uint8_NP SrU85D9data2Pos;
} RecSg5D9_NP;

#  define Rte_TypeDef_RecSg5F4_NP
typedef struct
{
  uint8_NP SrU85F4data0Pos;
  uint8_NP SrU85F4data1Pos;
  uint8_NP SrU85F4data2Pos;
  uint8_NP SrU85F4data3Pos;
} RecSg5F4_NP;

# endif


/**********************************************************************************************************************
 * Calibration Parameter Types
 *********************************************************************************************************************/
typedef P2CONST(void, TYPEDEF, RTE_CONST) Rte_ParameterRefType;
typedef Rte_ParameterRefType Rte_ParameterRefTabType[542];
typedef P2CONST(Rte_ParameterRefType, TYPEDEF, RTE_CONST) Rte_ParameterBaseType;

# define RTE_START_SEC_VAR_NOINIT_UNSPECIFIED
//# include "MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */

extern VAR(Rte_ParameterBaseType, RTE_VAR_NOINIT) RteParameterBase;

# define RTE_STOP_SEC_VAR_NOINIT_UNSPECIFIED
//# include "MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */

# define RTE_START_SEC_CONST_UNSPECIFIED
//# include "MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */
extern CONST(Rte_ParameterRefTabType, RTE_CONST) RteParameterRefTab;
# define RTE_STOP_SEC_CONST_UNSPECIFIED
//# include "MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */

# define Rte_CalprmElementGroup_ADAS2_SOUND1_REQ_BSW_CSWC_DEFAULT_RTE_CALPRM_GROUP (0)
typedef struct
{
  UInt8 ADAS2_SOUND1_REQ_BSW_ADAS2_SOUND1_REQ_BSW;
} Rte_Calprm_ADAS2_SOUND1_REQ_BSW_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_ADAS2_SOUND1_REQ_CANCEL_CSWC_DEFAULT_RTE_CALPRM_GROUP (1)
typedef struct
{
  UInt8 ADAS2_SOUND1_REQ_CANCEL_ADAS2_SOUND1_REQ_CANCEL;
} Rte_Calprm_ADAS2_SOUND1_REQ_CANCEL_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_ADAS2_SOUND1_REQ_LDW_CSWC_DEFAULT_RTE_CALPRM_GROUP (2)
typedef struct
{
  UInt8 ADAS2_SOUND1_REQ_LDW_ADAS2_SOUND1_REQ_LDW;
} Rte_Calprm_ADAS2_SOUND1_REQ_LDW_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_ADAS2_SOUND2_REQ_CANCEL_CSWC_DEFAULT_RTE_CALPRM_GROUP (3)
typedef struct
{
  UInt8 ADAS2_SOUND2_REQ_CANCEL_ADAS2_SOUND2_REQ_CANCEL;
} Rte_Calprm_ADAS2_SOUND2_REQ_CANCEL_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_ADAS2_SOUND2_REQ_FCW_CSWC_DEFAULT_RTE_CALPRM_GROUP (4)
typedef struct
{
  UInt8 ADAS2_SOUND2_REQ_FCW_ADAS2_SOUND2_REQ_FCW;
} Rte_Calprm_ADAS2_SOUND2_REQ_FCW_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_ADAS2_SOUND3_REQ_FEB_CSWC_DEFAULT_RTE_CALPRM_GROUP (5)
typedef struct
{
  UInt8 ADAS2_SOUND3_REQ_FEB_ADAS2_SOUND3_REQ_FEB;
} Rte_Calprm_ADAS2_SOUND3_REQ_FEB_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_ADAS2_STS_D_LN_ADAS_FAIL_CSWC_DEFAULT_RTE_CALPRM_GROUP (6)
typedef struct
{
  UInt8 ADAS2_STS_D_LN_ADAS_FAIL_ADAS2_STS_D_LN_ADAS_FAIL;
} Rte_Calprm_ADAS2_STS_D_LN_ADAS_FAIL_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_ADAS2_STS_D_LN_ADAS_ON_CSWC_DEFAULT_RTE_CALPRM_GROUP (7)
typedef struct
{
  UInt8 ADAS2_STS_D_LN_ADAS_ON_ADAS2_STS_D_LN_ADAS_ON;
} Rte_Calprm_ADAS2_STS_D_LN_ADAS_ON_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_ADAS2_STS_W_LN_ADAS_FAIL_CSWC_DEFAULT_RTE_CALPRM_GROUP (8)
typedef struct
{
  UInt8 ADAS2_STS_W_LN_ADAS_FAIL_ADAS2_STS_W_LN_ADAS_FAIL;
} Rte_Calprm_ADAS2_STS_W_LN_ADAS_FAIL_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_ADAS2_STS_W_LN_ADAS_ON_CSWC_DEFAULT_RTE_CALPRM_GROUP (9)
typedef struct
{
  UInt8 ADAS2_STS_W_LN_ADAS_ON_ADAS2_STS_W_LN_ADAS_ON;
} Rte_Calprm_ADAS2_STS_W_LN_ADAS_ON_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_INT32_0_CSWC_DEFAULT_RTE_CALPRM_GROUP (10)
typedef struct
{
  SInt32 INT32_0_INT32_0;
} Rte_Calprm_INT32_0_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_bar_tng_BRK_OFF_TH_CSWC_DEFAULT_RTE_CALPRM_GROUP (11)
typedef struct
{
  SInt32 P_bar_tng_BRK_OFF_TH_P_bar_tng_BRK_OFF_TH;
} Rte_Calprm_P_bar_tng_BRK_OFF_TH_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_fix_BrkLampOn_FT_CSWC_DEFAULT_RTE_CALPRM_GROUP (12)
typedef struct
{
  Float P_fix_BrkLampOn_FT_P_fix_BrkLampOn_FT;
} Rte_Calprm_P_fix_BrkLampOn_FT_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_fix_CtrlDoorOpenExCocpit_FT_CSWC_DEFAULT_RTE_CALPRM_GROUP (13)
typedef struct
{
  Float P_fix_CtrlDoorOpenExCocpit_FT_P_fix_CtrlDoorOpenExCocpit_FT;
} Rte_Calprm_P_fix_CtrlDoorOpenExCocpit_FT_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_fix_CtrlDoorOpenExCocpit_RT_CSWC_DEFAULT_RTE_CALPRM_GROUP (14)
typedef struct
{
  Float P_fix_CtrlDoorOpenExCocpit_RT_P_fix_CtrlDoorOpenExCocpit_RT;
} Rte_Calprm_P_fix_CtrlDoorOpenExCocpit_RT_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_fix_CvtFail_FT_CSWC_DEFAULT_RTE_CALPRM_GROUP (15)
typedef struct
{
  Float P_fix_CvtFail_FT_P_fix_CvtFail_FT;
} Rte_Calprm_P_fix_CvtFail_FT_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_fix_CvtMisMatch_FT_CSWC_DEFAULT_RTE_CALPRM_GROUP (16)
typedef struct
{
  Float P_fix_CvtMisMatch_FT_P_fix_CvtMisMatch_FT;
} Rte_Calprm_P_fix_CvtMisMatch_FT_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_fix_EcmAccF_FT_CSWC_DEFAULT_RTE_CALPRM_GROUP (17)
typedef struct
{
  Float P_fix_EcmAccF_FT_P_fix_EcmAccF_FT;
} Rte_Calprm_P_fix_EcmAccF_FT_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_fix_EcmAccInh_FT_CSWC_DEFAULT_RTE_CALPRM_GROUP (18)
typedef struct
{
  Float P_fix_EcmAccInh_FT_P_fix_EcmAccInh_FT;
} Rte_Calprm_P_fix_EcmAccInh_FT_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_fix_EcmAccInh_RT_CSWC_DEFAULT_RTE_CALPRM_GROUP (19)
typedef struct
{
  Float P_fix_EcmAccInh_RT_P_fix_EcmAccInh_RT;
} Rte_Calprm_P_fix_EcmAccInh_RT_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_fix_EcmAscdF_A_FT_CSWC_DEFAULT_RTE_CALPRM_GROUP (20)
typedef struct
{
  Float P_fix_EcmAscdF_A_FT_P_fix_EcmAscdF_A_FT;
} Rte_Calprm_P_fix_EcmAscdF_A_FT_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_fix_EcmAscd_C_FT_CSWC_DEFAULT_RTE_CALPRM_GROUP (21)
typedef struct
{
  Float P_fix_EcmAscd_C_FT_P_fix_EcmAscd_C_FT;
} Rte_Calprm_P_fix_EcmAscd_C_FT_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_fix_EcmEng_FT_CSWC_DEFAULT_RTE_CALPRM_GROUP (22)
typedef struct
{
  Float P_fix_EcmEng_FT_P_fix_EcmEng_FT;
} Rte_Calprm_P_fix_EcmEng_FT_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_fix_EcmEng_RT_CSWC_DEFAULT_RTE_CALPRM_GROUP (23)
typedef struct
{
  Float P_fix_EcmEng_RT_P_fix_EcmEng_RT;
} Rte_Calprm_P_fix_EcmEng_RT_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_fix_FS_SwFix_FT_CSWC_DEFAULT_RTE_CALPRM_GROUP (24)
typedef struct
{
  Float P_fix_FS_SwFix_FT_P_fix_FS_SwFix_FT;
} Rte_Calprm_P_fix_FS_SwFix_FT_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_fix_HevSys_FT_CSWC_DEFAULT_RTE_CALPRM_GROUP (25)
typedef struct
{
  Float P_fix_HevSys_FT_P_fix_HevSys_FT;
} Rte_Calprm_P_fix_HevSys_FT_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_fix_SWLogic_Cancel_FT_CSWC_DEFAULT_RTE_CALPRM_GROUP (26)
typedef struct
{
  Float P_fix_SWLogic_Cancel_FT_P_fix_SWLogic_Cancel_FT;
} Rte_Calprm_P_fix_SWLogic_Cancel_FT_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_fix_SWLogic_Cancel_RT_CSWC_DEFAULT_RTE_CALPRM_GROUP (27)
typedef struct
{
  Float P_fix_SWLogic_Cancel_RT_P_fix_SWLogic_Cancel_RT;
} Rte_Calprm_P_fix_SWLogic_Cancel_RT_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_fix_SWLogic_FT_CSWC_DEFAULT_RTE_CALPRM_GROUP (28)
typedef struct
{
  Float P_fix_SWLogic_FT_P_fix_SWLogic_FT;
} Rte_Calprm_P_fix_SWLogic_FT_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_fix_SenPulseL_FT_CSWC_DEFAULT_RTE_CALPRM_GROUP (29)
typedef struct
{
  Float P_fix_SenPulseL_FT_P_fix_SenPulseL_FT;
} Rte_Calprm_P_fix_SenPulseL_FT_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_fix_SenPulseR_FT_CSWC_DEFAULT_RTE_CALPRM_GROUP (30)
typedef struct
{
  Float P_fix_SenPulseR_FT_P_fix_SenPulseR_FT;
} Rte_Calprm_P_fix_SenPulseR_FT_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_fix_SenSpd_A_FT_CSWC_DEFAULT_RTE_CALPRM_GROUP (31)
typedef struct
{
  Float P_fix_SenSpd_A_FT_P_fix_SenSpd_A_FT;
} Rte_Calprm_P_fix_SenSpd_A_FT_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_fix_SenSpd_A_RT_CSWC_DEFAULT_RTE_CALPRM_GROUP (32)
typedef struct
{
  Float P_fix_SenSpd_A_RT_P_fix_SenSpd_A_RT;
} Rte_Calprm_P_fix_SenSpd_A_RT_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_fix_SenSpd_C_FT_CSWC_DEFAULT_RTE_CALPRM_GROUP (33)
typedef struct
{
  Float P_fix_SenSpd_C_FT_P_fix_SenSpd_C_FT;
} Rte_Calprm_P_fix_SenSpd_C_FT_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_fix_StbAbsLamp_ACC_FT_CSWC_DEFAULT_RTE_CALPRM_GROUP (34)
typedef struct
{
  UInt32 P_fix_StbAbsLamp_ACC_FT_P_fix_StbAbsLamp_ACC_FT;
} Rte_Calprm_P_fix_StbAbsLamp_ACC_FT_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_fix_StbAbsLamp_ACC_RT_CSWC_DEFAULT_RTE_CALPRM_GROUP (35)
typedef struct
{
  UInt32 P_fix_StbAbsLamp_ACC_RT_P_fix_StbAbsLamp_ACC_RT;
} Rte_Calprm_P_fix_StbAbsLamp_ACC_RT_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_fix_StbIdmFail_FT_CSWC_DEFAULT_RTE_CALPRM_GROUP (36)
typedef struct
{
  Float P_fix_StbIdmFail_FT_P_fix_StbIdmFail_FT;
} Rte_Calprm_P_fix_StbIdmFail_FT_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_fix_SwFixAcc_FT_CSWC_DEFAULT_RTE_CALPRM_GROUP (37)
typedef struct
{
  Float P_fix_SwFixAcc_FT_P_fix_SwFixAcc_FT;
} Rte_Calprm_P_fix_SwFixAcc_FT_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_fix_VDCFunc_A_wACC_FT_CSWC_DEFAULT_RTE_CALPRM_GROUP (38)
typedef struct
{
  Float P_fix_VDCFunc_A_wACC_FT_P_fix_VDCFunc_A_wACC_FT;
} Rte_Calprm_P_fix_VDCFunc_A_wACC_FT_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_fix_VDCFunc_A_wACC_RT_CSWC_DEFAULT_RTE_CALPRM_GROUP (39)
typedef struct
{
  Float P_fix_VDCFunc_A_wACC_RT_P_fix_VDCFunc_A_wACC_RT;
} Rte_Calprm_P_fix_VDCFunc_A_wACC_RT_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_fix_VDCFunc_C_wACC_FT_CSWC_DEFAULT_RTE_CALPRM_GROUP (40)
typedef struct
{
  Float P_fix_VDCFunc_C_wACC_FT_P_fix_VDCFunc_C_wACC_FT;
} Rte_Calprm_P_fix_VDCFunc_C_wACC_FT_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_fix_VDCVolt_A_wACC_FT_CSWC_DEFAULT_RTE_CALPRM_GROUP (41)
typedef struct
{
  Float P_fix_VDCVolt_A_wACC_FT_P_fix_VDCVolt_A_wACC_FT;
} Rte_Calprm_P_fix_VDCVolt_A_wACC_FT_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_fix_VDCVolt_A_wACC_RT_CSWC_DEFAULT_RTE_CALPRM_GROUP (42)
typedef struct
{
  Float P_fix_VDCVolt_A_wACC_RT_P_fix_VDCVolt_A_wACC_RT;
} Rte_Calprm_P_fix_VDCVolt_A_wACC_RT_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_fix_VDCVolt_C_wACC_FT_CSWC_DEFAULT_RTE_CALPRM_GROUP (43)
typedef struct
{
  Float P_fix_VDCVolt_C_wACC_FT_P_fix_VDCVolt_C_wACC_FT;
} Rte_Calprm_P_fix_VDCVolt_C_wACC_FT_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_fix_ePkbErr_FT_CSWC_DEFAULT_RTE_CALPRM_GROUP (44)
typedef struct
{
  Float P_fix_ePkbErr_FT_P_fix_ePkbErr_FT;
} Rte_Calprm_P_fix_ePkbErr_FT_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_fix_timestep_CSWC_DEFAULT_RTE_CALPRM_GROUP (45)
typedef struct
{
  Float P_fix_timestep_P_fix_timestep;
} Rte_Calprm_P_fix_timestep_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_fix_x_BrakeCancel_CSWC_DEFAULT_RTE_CALPRM_GROUP (46)
typedef struct
{
  UInt8 P_fix_x_BrakeCancel_P_fix_x_BrakeCancel;
} Rte_Calprm_P_fix_x_BrakeCancel_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_fix_x_BrakeFFEnd_CSWC_DEFAULT_RTE_CALPRM_GROUP (47)
typedef struct
{
  UInt8 P_fix_x_BrakeFFEnd_P_fix_x_BrakeFFEnd;
} Rte_Calprm_P_fix_x_BrakeFFEnd_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_fix_x_BrakeFFStart_CSWC_DEFAULT_RTE_CALPRM_GROUP (48)
typedef struct
{
  UInt8 P_fix_x_BrakeFFStart_P_fix_x_BrakeFFStart;
} Rte_Calprm_P_fix_x_BrakeFFStart_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_fix_x_BrakeFail_CSWC_DEFAULT_RTE_CALPRM_GROUP (49)
typedef struct
{
  UInt8 P_fix_x_BrakeFail_P_fix_x_BrakeFail;
} Rte_Calprm_P_fix_x_BrakeFail_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_fix_x_CancelStatus_CSWC_DEFAULT_RTE_CALPRM_GROUP (50)
typedef struct
{
  UInt8 P_fix_x_CancelStatus_P_fix_x_CancelStatus;
} Rte_Calprm_P_fix_x_CancelStatus_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_fix_x_FailStatus_CSWC_DEFAULT_RTE_CALPRM_GROUP (51)
typedef struct
{
  UInt8 P_fix_x_FailStatus_P_fix_x_FailStatus;
} Rte_Calprm_P_fix_x_FailStatus_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_fix_x_GearShiftStatus_CSWC_DEFAULT_RTE_CALPRM_GROUP (52)
typedef struct
{
  UInt8 P_fix_x_GearShiftStatus_P_fix_x_GearShiftStatus;
} Rte_Calprm_P_fix_x_GearShiftStatus_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_fix_x_NormalStatus_CSWC_DEFAULT_RTE_CALPRM_GROUP (53)
typedef struct
{
  UInt8 P_fix_x_NormalStatus_P_fix_x_NormalStatus;
} Rte_Calprm_P_fix_x_NormalStatus_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_fix_x_OFFStatus_CSWC_DEFAULT_RTE_CALPRM_GROUP (54)
typedef struct
{
  UInt8 P_fix_x_OFFStatus_P_fix_x_OFFStatus;
} Rte_Calprm_P_fix_x_OFFStatus_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_fix_x_OverrideStatus_CSWC_DEFAULT_RTE_CALPRM_GROUP (55)
typedef struct
{
  UInt8 P_fix_x_OverrideStatus_P_fix_x_OverrideStatus;
} Rte_Calprm_P_fix_x_OverrideStatus_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_fix_x_OvertakingStatus_CSWC_DEFAULT_RTE_CALPRM_GROUP (56)
typedef struct
{
  UInt8 P_fix_x_OvertakingStatus_P_fix_x_OvertakingStatus;
} Rte_Calprm_P_fix_x_OvertakingStatus_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_fix_x_ResetStatus_CSWC_DEFAULT_RTE_CALPRM_GROUP (57)
typedef struct
{
  UInt8 P_fix_x_ResetStatus_P_fix_x_ResetStatus;
} Rte_Calprm_P_fix_x_ResetStatus_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_fix_x_StopStatus_CSWC_DEFAULT_RTE_CALPRM_GROUP (58)
typedef struct
{
  UInt8 P_fix_x_StopStatus_P_fix_x_StopStatus;
} Rte_Calprm_P_fix_x_StopStatus_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_fix_x_WaitStatus_CSWC_DEFAULT_RTE_CALPRM_GROUP (59)
typedef struct
{
  UInt8 P_fix_x_WaitStatus_P_fix_x_WaitStatus;
} Rte_Calprm_P_fix_x_WaitStatus_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_m_fix_ICC_SunRay_TargetDist_CSWC_DEFAULT_RTE_CALPRM_GROUP (60)
typedef struct
{
  Float P_m_fix_ICC_SunRay_TargetDist_P_m_fix_ICC_SunRay_TargetDist;
} Rte_Calprm_P_m_fix_ICC_SunRay_TargetDist_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_mps_fix_VSP_40KM_CSWC_DEFAULT_RTE_CALPRM_GROUP (61)
typedef struct
{
  SInt32 P_mps_fix_VSP_40KM_P_mps_fix_VSP_40KM;
} Rte_Calprm_P_mps_fix_VSP_40KM_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_5KMPH_4W_CSWC_DEFAULT_RTE_CALPRM_GROUP (62)
typedef struct
{
  UInt16 P_x_fix_5KMPH_4W_P_x_fix_5KMPH_4W;
} Rte_Calprm_P_x_fix_5KMPH_4W_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_ABSActCancel_ACC_FT_CSWC_DEFAULT_RTE_CALPRM_GROUP (63)
typedef struct
{
  UInt32 P_x_fix_ABSActCancel_ACC_FT_P_x_fix_ABSActCancel_ACC_FT;
} Rte_Calprm_P_x_fix_ABSActCancel_ACC_FT_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_ABSActCancel_ACC_RT_CSWC_DEFAULT_RTE_CALPRM_GROUP (64)
typedef struct
{
  UInt32 P_x_fix_ABSActCancel_ACC_RT_P_x_fix_ABSActCancel_ACC_RT;
} Rte_Calprm_P_x_fix_ABSActCancel_ACC_RT_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_ACC_OFF_CSWC_DEFAULT_RTE_CALPRM_GROUP (65)
typedef struct
{
  UInt8 P_x_fix_ACC_OFF_P_x_fix_ACC_OFF;
} Rte_Calprm_P_x_fix_ACC_OFF_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_ADAS_PWTwheelTorque_Max_CSWC_DEFAULT_RTE_CALPRM_GROUP (66)
typedef struct
{
  SInt16 P_x_fix_ADAS_PWTwheelTorque_Max_P_x_fix_ADAS_PWTwheelTorque_Max;
} Rte_Calprm_P_x_fix_ADAS_PWTwheelTorque_Max_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_BrkCmdPressFail_FT_CSWC_DEFAULT_RTE_CALPRM_GROUP (67)
typedef struct
{
  UInt32 P_x_fix_BrkCmdPressFail_FT_P_x_fix_BrkCmdPressFail_FT;
} Rte_Calprm_P_x_fix_BrkCmdPressFail_FT_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_BrkCmdPressFail_RT_CSWC_DEFAULT_RTE_CALPRM_GROUP (68)
typedef struct
{
  UInt32 P_x_fix_BrkCmdPressFail_RT_P_x_fix_BrkCmdPressFail_RT;
} Rte_Calprm_P_x_fix_BrkCmdPressFail_RT_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_BrkSwHdc_On_FT_CSWC_DEFAULT_RTE_CALPRM_GROUP (69)
typedef struct
{
  UInt32 P_x_fix_BrkSwHdc_On_FT_P_x_fix_BrkSwHdc_On_FT;
} Rte_Calprm_P_x_fix_BrkSwHdc_On_FT_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_BrkSwHdc_On_RT_CSWC_DEFAULT_RTE_CALPRM_GROUP (70)
typedef struct
{
  UInt32 P_x_fix_BrkSwHdc_On_RT_P_x_fix_BrkSwHdc_On_RT;
} Rte_Calprm_P_x_fix_BrkSwHdc_On_RT_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_CRUISE_CSWC_DEFAULT_RTE_CALPRM_GROUP (71)
typedef struct
{
  UInt8 P_x_fix_CRUISE_P_x_fix_CRUISE;
} Rte_Calprm_P_x_fix_CRUISE_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_ClutchMisMatch_FT_CSWC_DEFAULT_RTE_CALPRM_GROUP (72)
typedef struct
{
  UInt32 P_x_fix_ClutchMisMatch_FT_P_x_fix_ClutchMisMatch_FT;
} Rte_Calprm_P_x_fix_ClutchMisMatch_FT_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_ClutchMisMatch_RT_CSWC_DEFAULT_RTE_CALPRM_GROUP (73)
typedef struct
{
  UInt32 P_x_fix_ClutchMisMatch_RT_P_x_fix_ClutchMisMatch_RT;
} Rte_Calprm_P_x_fix_ClutchMisMatch_RT_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_CtrlDBABrake_FT_CSWC_DEFAULT_RTE_CALPRM_GROUP (74)
typedef struct
{
  UInt32 P_x_fix_CtrlDBABrake_FT_P_x_fix_CtrlDBABrake_FT;
} Rte_Calprm_P_x_fix_CtrlDBABrake_FT_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_CtrlDBABrake_RT_CSWC_DEFAULT_RTE_CALPRM_GROUP (75)
typedef struct
{
  UInt32 P_x_fix_CtrlDBABrake_RT_P_x_fix_CtrlDBABrake_RT;
} Rte_Calprm_P_x_fix_CtrlDBABrake_RT_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_CtrlSlip_FT_CSWC_DEFAULT_RTE_CALPRM_GROUP (76)
typedef struct
{
  UInt32 P_x_fix_CtrlSlip_FT_P_x_fix_CtrlSlip_FT;
} Rte_Calprm_P_x_fix_CtrlSlip_FT_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_CtrlSlip_RT_CSWC_DEFAULT_RTE_CALPRM_GROUP (77)
typedef struct
{
  UInt32 P_x_fix_CtrlSlip_RT_P_x_fix_CtrlSlip_RT;
} Rte_Calprm_P_x_fix_CtrlSlip_RT_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_CtrlSteepSlope_FT_CSWC_DEFAULT_RTE_CALPRM_GROUP (78)
typedef struct
{
  UInt32 P_x_fix_CtrlSteepSlope_FT_P_x_fix_CtrlSteepSlope_FT;
} Rte_Calprm_P_x_fix_CtrlSteepSlope_FT_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_CtrlSteepSlope_RT_CSWC_DEFAULT_RTE_CALPRM_GROUP (79)
typedef struct
{
  UInt32 P_x_fix_CtrlSteepSlope_RT_P_x_fix_CtrlSteepSlope_RT;
} Rte_Calprm_P_x_fix_CtrlSteepSlope_RT_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_DASOFF_CSWC_DEFAULT_RTE_CALPRM_GROUP (80)
typedef struct
{
  UInt8 P_x_fix_DASOFF_P_x_fix_DASOFF;
} Rte_Calprm_P_x_fix_DASOFF_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_DASON_CSWC_DEFAULT_RTE_CALPRM_GROUP (81)
typedef struct
{
  UInt8 P_x_fix_DASON_P_x_fix_DASON;
} Rte_Calprm_P_x_fix_DASON_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_Driver_door_closed_CSWC_DEFAULT_RTE_CALPRM_GROUP (82)
typedef struct
{
  UInt8 P_x_fix_Driver_door_closed_P_x_fix_Driver_door_closed;
} Rte_Calprm_P_x_fix_Driver_door_closed_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_ETS_4Lo_mode_CSWC_DEFAULT_RTE_CALPRM_GROUP (83)
typedef struct
{
  UInt8 P_x_fix_ETS_4Lo_mode_P_x_fix_ETS_4Lo_mode;
} Rte_Calprm_P_x_fix_ETS_4Lo_mode_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_ETS_fixed_4WD_mode_CSWC_DEFAULT_RTE_CALPRM_GROUP (84)
typedef struct
{
  UInt8 P_x_fix_ETS_fixed_4WD_mode_P_x_fix_ETS_fixed_4WD_mode;
} Rte_Calprm_P_x_fix_ETS_fixed_4WD_mode_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_EcmAccC_FT_CSWC_DEFAULT_RTE_CALPRM_GROUP (85)
typedef struct
{
  UInt32 P_x_fix_EcmAccC_FT_P_x_fix_EcmAccC_FT;
} Rte_Calprm_P_x_fix_EcmAccC_FT_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_EcmAccC_RT_CSWC_DEFAULT_RTE_CALPRM_GROUP (86)
typedef struct
{
  UInt32 P_x_fix_EcmAccC_RT_P_x_fix_EcmAccC_RT;
} Rte_Calprm_P_x_fix_EcmAccC_RT_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_EightBit_CSWC_DEFAULT_RTE_CALPRM_GROUP (87)
typedef struct
{
  UInt16 P_x_fix_EightBit_P_x_fix_EightBit;
} Rte_Calprm_P_x_fix_EightBit_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_ElevenBit_CSWC_DEFAULT_RTE_CALPRM_GROUP (88)
typedef struct
{
  UInt16 P_x_fix_ElevenBit_P_x_fix_ElevenBit;
} Rte_Calprm_P_x_fix_ElevenBit_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_Error_CSWC_DEFAULT_RTE_CALPRM_GROUP (89)
typedef struct
{
  UInt8 P_x_fix_Error_P_x_fix_Error;
} Rte_Calprm_P_x_fix_Error_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_FactoryResetRequest_CSWC_DEFAULT_RTE_CALPRM_GROUP (90)
typedef struct
{
  UInt8 P_x_fix_FactoryResetRequest_P_x_fix_FactoryResetRequest;
} Rte_Calprm_P_x_fix_FactoryResetRequest_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_FifteenBit_CSWC_DEFAULT_RTE_CALPRM_GROUP (91)
typedef struct
{
  UInt16 P_x_fix_FifteenBit_P_x_fix_FifteenBit;
} Rte_Calprm_P_x_fix_FifteenBit_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_FiveBit_CSWC_DEFAULT_RTE_CALPRM_GROUP (92)
typedef struct
{
  UInt16 P_x_fix_FiveBit_P_x_fix_FiveBit;
} Rte_Calprm_P_x_fix_FiveBit_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_FourBit_CSWC_DEFAULT_RTE_CALPRM_GROUP (93)
typedef struct
{
  UInt16 P_x_fix_FourBit_P_x_fix_FourBit;
} Rte_Calprm_P_x_fix_FourBit_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_FourteenBit_CSWC_DEFAULT_RTE_CALPRM_GROUP (94)
typedef struct
{
  UInt16 P_x_fix_FourteenBit_P_x_fix_FourteenBit;
} Rte_Calprm_P_x_fix_FourteenBit_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_I32_ZERO_CSWC_DEFAULT_RTE_CALPRM_GROUP (95)
typedef struct
{
  SInt32 P_x_fix_I32_ZERO_P_x_fix_I32_ZERO;
} Rte_Calprm_P_x_fix_I32_ZERO_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_Ice_OR_Mud_Detected_CSWC_DEFAULT_RTE_CALPRM_GROUP (96)
typedef struct
{
  UInt8 P_x_fix_Ice_OR_Mud_Detected_P_x_fix_Ice_OR_Mud_Detected;
} Rte_Calprm_P_x_fix_Ice_OR_Mud_Detected_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_LOST_FOLLOW_AVE_VSP_CSWC_DEFAULT_RTE_CALPRM_GROUP (97)
typedef struct
{
  SInt32 P_x_fix_LOST_FOLLOW_AVE_VSP_P_x_fix_LOST_FOLLOW_AVE_VSP;
} Rte_Calprm_P_x_fix_LOST_FOLLOW_AVE_VSP_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_LsCameraFusion_FT_CSWC_DEFAULT_RTE_CALPRM_GROUP (98)
typedef struct
{
  UInt32 P_x_fix_LsCameraFusion_FT_P_x_fix_LsCameraFusion_FT;
} Rte_Calprm_P_x_fix_LsCameraFusion_FT_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_LsCameraFusion_RT_CSWC_DEFAULT_RTE_CALPRM_GROUP (99)
typedef struct
{
  UInt32 P_x_fix_LsCameraFusion_RT_P_x_fix_LsCameraFusion_RT;
} Rte_Calprm_P_x_fix_LsCameraFusion_RT_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_Major_FPA_default_CSWC_DEFAULT_RTE_CALPRM_GROUP (100)
typedef struct
{
  UInt8 P_x_fix_Major_FPA_default_P_x_fix_Major_FPA_default;
} Rte_Calprm_P_x_fix_Major_FPA_default_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_Minor_FPA_default_CSWC_DEFAULT_RTE_CALPRM_GROUP (101)
typedef struct
{
  UInt8 P_x_fix_Minor_FPA_default_P_x_fix_Minor_FPA_default;
} Rte_Calprm_P_x_fix_Minor_FPA_default_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_NAP_OFF_CSWC_DEFAULT_RTE_CALPRM_GROUP (102)
typedef struct
{
  SInt32 P_x_fix_NAP_OFF_P_x_fix_NAP_OFF;
} Rte_Calprm_P_x_fix_NAP_OFF_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_NineBit_CSWC_DEFAULT_RTE_CALPRM_GROUP (103)
typedef struct
{
  UInt16 P_x_fix_NineBit_P_x_fix_NineBit;
} Rte_Calprm_P_x_fix_NineBit_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_NoSettingChangeReq_CSWC_DEFAULT_RTE_CALPRM_GROUP (104)
typedef struct
{
  UInt8 P_x_fix_NoSettingChangeReq_P_x_fix_NoSettingChangeReq;
} Rte_Calprm_P_x_fix_NoSettingChangeReq_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_NoWDARequest_CSWC_DEFAULT_RTE_CALPRM_GROUP (105)
typedef struct
{
  UInt8 P_x_fix_NoWDARequest_P_x_fix_NoWDARequest;
} Rte_Calprm_P_x_fix_NoWDARequest_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_OFF_CSWC_DEFAULT_RTE_CALPRM_GROUP (106)
typedef struct
{
  Boolean P_x_fix_OFF_P_x_fix_OFF;
} Rte_Calprm_P_x_fix_OFF_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_ON_CSWC_DEFAULT_RTE_CALPRM_GROUP (107)
typedef struct
{
  Boolean P_x_fix_ON_P_x_fix_ON;
} Rte_Calprm_P_x_fix_ON_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_OffRoad_Rock_CSWC_DEFAULT_RTE_CALPRM_GROUP (108)
typedef struct
{
  UInt8 P_x_fix_OffRoad_Rock_P_x_fix_OffRoad_Rock;
} Rte_Calprm_P_x_fix_OffRoad_Rock_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_OffRoad_Sand_CSWC_DEFAULT_RTE_CALPRM_GROUP (109)
typedef struct
{
  UInt8 P_x_fix_OffRoad_Sand_P_x_fix_OffRoad_Sand;
} Rte_Calprm_P_x_fix_OffRoad_Sand_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_OneBit_CSWC_DEFAULT_RTE_CALPRM_GROUP (110)
typedef struct
{
  UInt16 P_x_fix_OneBit_P_x_fix_OneBit;
} Rte_Calprm_P_x_fix_OneBit_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_PA_INH_VSP_TH_CSWC_DEFAULT_RTE_CALPRM_GROUP (111)
typedef struct
{
  SInt32 P_x_fix_PA_INH_VSP_TH_P_x_fix_PA_INH_VSP_TH;
} Rte_Calprm_P_x_fix_PA_INH_VSP_TH_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_PBRK_CALLBK_COMFAIL_CSWC_DEFAULT_RTE_CALPRM_GROUP (112)
typedef struct
{
  SInt32 P_x_fix_PBRK_CALLBK_COMFAIL_P_x_fix_PBRK_CALLBK_COMFAIL;
} Rte_Calprm_P_x_fix_PBRK_CALLBK_COMFAIL_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_Ready_CSWC_DEFAULT_RTE_CALPRM_GROUP (113)
typedef struct
{
  UInt8 P_x_fix_Ready_P_x_fix_Ready;
} Rte_Calprm_P_x_fix_Ready_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_S16_One_CSWC_DEFAULT_RTE_CALPRM_GROUP (114)
typedef struct
{
  SInt16 P_x_fix_S16_One_P_x_fix_S16_One;
} Rte_Calprm_P_x_fix_S16_One_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_S32_One_CSWC_DEFAULT_RTE_CALPRM_GROUP (115)
typedef struct
{
  SInt32 P_x_fix_S32_One_P_x_fix_S32_One;
} Rte_Calprm_P_x_fix_S32_One_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_SCAM2_FullBlk_FT_CSWC_DEFAULT_RTE_CALPRM_GROUP (116)
typedef struct
{
  UInt32 P_x_fix_SCAM2_FullBlk_FT_P_x_fix_SCAM2_FullBlk_FT;
} Rte_Calprm_P_x_fix_SCAM2_FullBlk_FT_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_SCAM2_FullBlk_RT_CSWC_DEFAULT_RTE_CALPRM_GROUP (117)
typedef struct
{
  UInt32 P_x_fix_SCAM2_FullBlk_RT_P_x_fix_SCAM2_FullBlk_RT;
} Rte_Calprm_P_x_fix_SCAM2_FullBlk_RT_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_SCAM2_PartialBlk_FT_CSWC_DEFAULT_RTE_CALPRM_GROUP (118)
typedef struct
{
  UInt32 P_x_fix_SCAM2_PartialBlk_FT_P_x_fix_SCAM2_PartialBlk_FT;
} Rte_Calprm_P_x_fix_SCAM2_PartialBlk_FT_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_SCAM2_PartialBlk_RT_CSWC_DEFAULT_RTE_CALPRM_GROUP (119)
typedef struct
{
  UInt32 P_x_fix_SCAM2_PartialBlk_RT_P_x_fix_SCAM2_PartialBlk_RT;
} Rte_Calprm_P_x_fix_SCAM2_PartialBlk_RT_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_SCAM2_SmearImg_FT_CSWC_DEFAULT_RTE_CALPRM_GROUP (120)
typedef struct
{
  UInt32 P_x_fix_SCAM2_SmearImg_FT_P_x_fix_SCAM2_SmearImg_FT;
} Rte_Calprm_P_x_fix_SCAM2_SmearImg_FT_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_SCAM2_SmearImg_RT_CSWC_DEFAULT_RTE_CALPRM_GROUP (121)
typedef struct
{
  UInt32 P_x_fix_SCAM2_SmearImg_RT_P_x_fix_SCAM2_SmearImg_RT;
} Rte_Calprm_P_x_fix_SCAM2_SmearImg_RT_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_SINT32MAX_CSWC_DEFAULT_RTE_CALPRM_GROUP (122)
typedef struct
{
  SInt32 P_x_fix_SINT32MAX_P_x_fix_SINT32MAX;
} Rte_Calprm_P_x_fix_SINT32MAX_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_SINT32MIN_CSWC_DEFAULT_RTE_CALPRM_GROUP (123)
typedef struct
{
  SInt32 P_x_fix_SINT32MIN_P_x_fix_SINT32MIN;
} Rte_Calprm_P_x_fix_SINT32MIN_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_SOWSensorFail2_L_FT_CSWC_DEFAULT_RTE_CALPRM_GROUP (124)
typedef struct
{
  UInt32 P_x_fix_SOWSensorFail2_L_FT_P_x_fix_SOWSensorFail2_L_FT;
} Rte_Calprm_P_x_fix_SOWSensorFail2_L_FT_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_SOWSensorFail2_R_FT_CSWC_DEFAULT_RTE_CALPRM_GROUP (125)
typedef struct
{
  UInt32 P_x_fix_SOWSensorFail2_R_FT_P_x_fix_SOWSensorFail2_R_FT;
} Rte_Calprm_P_x_fix_SOWSensorFail2_R_FT_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_SWLogic_Cancel_FT_CSWC_DEFAULT_RTE_CALPRM_GROUP (126)
typedef struct
{
  UInt32 P_x_fix_SWLogic_Cancel_FT_P_x_fix_SWLogic_Cancel_FT;
} Rte_Calprm_P_x_fix_SWLogic_Cancel_FT_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_SWLogic_Cancel_RT_CSWC_DEFAULT_RTE_CALPRM_GROUP (127)
typedef struct
{
  UInt32 P_x_fix_SWLogic_Cancel_RT_P_x_fix_SWLogic_Cancel_RT;
} Rte_Calprm_P_x_fix_SWLogic_Cancel_RT_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_SWLogic_FT_CSWC_DEFAULT_RTE_CALPRM_GROUP (128)
typedef struct
{
  UInt32 P_x_fix_SWLogic_FT_P_x_fix_SWLogic_FT;
} Rte_Calprm_P_x_fix_SWLogic_FT_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_SenGUnavail_FT_CSWC_DEFAULT_RTE_CALPRM_GROUP (129)
typedef struct
{
  UInt32 P_x_fix_SenGUnavail_FT_P_x_fix_SenGUnavail_FT;
} Rte_Calprm_P_x_fix_SenGUnavail_FT_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_SenGUnavail_RT_CSWC_DEFAULT_RTE_CALPRM_GROUP (130)
typedef struct
{
  UInt32 P_x_fix_SenGUnavail_RT_P_x_fix_SenGUnavail_RT;
} Rte_Calprm_P_x_fix_SenGUnavail_RT_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_SenWheelC_FT_CSWC_DEFAULT_RTE_CALPRM_GROUP (131)
typedef struct
{
  UInt32 P_x_fix_SenWheelC_FT_P_x_fix_SenWheelC_FT;
} Rte_Calprm_P_x_fix_SenWheelC_FT_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_SenWheelC_RT_CSWC_DEFAULT_RTE_CALPRM_GROUP (132)
typedef struct
{
  UInt32 P_x_fix_SenWheelC_RT_P_x_fix_SenWheelC_RT;
} Rte_Calprm_P_x_fix_SenWheelC_RT_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_SevenBit_CSWC_DEFAULT_RTE_CALPRM_GROUP (133)
typedef struct
{
  UInt16 P_x_fix_SevenBit_P_x_fix_SevenBit;
} Rte_Calprm_P_x_fix_SevenBit_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_SixBit_CSWC_DEFAULT_RTE_CALPRM_GROUP (134)
typedef struct
{
  UInt16 P_x_fix_SixBit_P_x_fix_SixBit;
} Rte_Calprm_P_x_fix_SixBit_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_SwCancel_FT_CSWC_DEFAULT_RTE_CALPRM_GROUP (135)
typedef struct
{
  UInt32 P_x_fix_SwCancel_FT_P_x_fix_SwCancel_FT;
} Rte_Calprm_P_x_fix_SwCancel_FT_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_SwCancel_RT_CSWC_DEFAULT_RTE_CALPRM_GROUP (136)
typedef struct
{
  UInt32 P_x_fix_SwCancel_RT_P_x_fix_SwCancel_RT;
} Rte_Calprm_P_x_fix_SwCancel_RT_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_SwDouble_FT_CSWC_DEFAULT_RTE_CALPRM_GROUP (137)
typedef struct
{
  UInt32 P_x_fix_SwDouble_FT_P_x_fix_SwDouble_FT;
} Rte_Calprm_P_x_fix_SwDouble_FT_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_SwDouble_RT_CSWC_DEFAULT_RTE_CALPRM_GROUP (138)
typedef struct
{
  UInt32 P_x_fix_SwDouble_RT_P_x_fix_SwDouble_RT;
} Rte_Calprm_P_x_fix_SwDouble_RT_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_SwMainOff_FT_CSWC_DEFAULT_RTE_CALPRM_GROUP (139)
typedef struct
{
  UInt32 P_x_fix_SwMainOff_FT_P_x_fix_SwMainOff_FT;
} Rte_Calprm_P_x_fix_SwMainOff_FT_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_SwMainOff_RT_CSWC_DEFAULT_RTE_CALPRM_GROUP (140)
typedef struct
{
  UInt32 P_x_fix_SwMainOff_RT_P_x_fix_SwMainOff_RT;
} Rte_Calprm_P_x_fix_SwMainOff_RT_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_SwTcsOffACC_FT_CSWC_DEFAULT_RTE_CALPRM_GROUP (141)
typedef struct
{
  UInt32 P_x_fix_SwTcsOffACC_FT_P_x_fix_SwTcsOffACC_FT;
} Rte_Calprm_P_x_fix_SwTcsOffACC_FT_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_SwTcsOffACC_RT_CSWC_DEFAULT_RTE_CALPRM_GROUP (142)
typedef struct
{
  UInt32 P_x_fix_SwTcsOffACC_RT_P_x_fix_SwTcsOffACC_RT;
} Rte_Calprm_P_x_fix_SwTcsOffACC_RT_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_TCSActCancel_ACC_FT_CSWC_DEFAULT_RTE_CALPRM_GROUP (143)
typedef struct
{
  UInt32 P_x_fix_TCSActCancel_ACC_FT_P_x_fix_TCSActCancel_ACC_FT;
} Rte_Calprm_P_x_fix_TCSActCancel_ACC_FT_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_TCSActCancel_ACC_RT_CSWC_DEFAULT_RTE_CALPRM_GROUP (144)
typedef struct
{
  UInt32 P_x_fix_TCSActCancel_ACC_RT_P_x_fix_TCSActCancel_ACC_RT;
} Rte_Calprm_P_x_fix_TCSActCancel_ACC_RT_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_THRE_CVT_G_HI_CSWC_DEFAULT_RTE_CALPRM_GROUP (145)
typedef struct
{
  SInt16 P_x_fix_THRE_CVT_G_HI_P_x_fix_THRE_CVT_G_HI;
} Rte_Calprm_P_x_fix_THRE_CVT_G_HI_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_THRE_CVT_G_LOW_CSWC_DEFAULT_RTE_CALPRM_GROUP (146)
typedef struct
{
  SInt16 P_x_fix_THRE_CVT_G_LOW_P_x_fix_THRE_CVT_G_LOW;
} Rte_Calprm_P_x_fix_THRE_CVT_G_LOW_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_TJP_CANCEL_APO_ANGL_CSWC_DEFAULT_RTE_CALPRM_GROUP (147)
typedef struct
{
  UInt32 P_x_fix_TJP_CANCEL_APO_ANGL_P_x_fix_TJP_CANCEL_APO_ANGL;
} Rte_Calprm_P_x_fix_TJP_CANCEL_APO_ANGL_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_TRQ_BRKCOMFAIL_CSWC_DEFAULT_RTE_CALPRM_GROUP (148)
typedef struct
{
  SInt32 P_x_fix_TRQ_BRKCOMFAIL_P_x_fix_TRQ_BRKCOMFAIL;
} Rte_Calprm_P_x_fix_TRQ_BRKCOMFAIL_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_Temporary_Error_CSWC_DEFAULT_RTE_CALPRM_GROUP (149)
typedef struct
{
  UInt8 P_x_fix_Temporary_Error_P_x_fix_Temporary_Error;
} Rte_Calprm_P_x_fix_Temporary_Error_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_TenBit_CSWC_DEFAULT_RTE_CALPRM_GROUP (150)
typedef struct
{
  UInt16 P_x_fix_TenBit_P_x_fix_TenBit;
} Rte_Calprm_P_x_fix_TenBit_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_ThirteenBit_CSWC_DEFAULT_RTE_CALPRM_GROUP (151)
typedef struct
{
  UInt16 P_x_fix_ThirteenBit_P_x_fix_ThirteenBit;
} Rte_Calprm_P_x_fix_ThirteenBit_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_ThreeBit_CSWC_DEFAULT_RTE_CALPRM_GROUP (152)
typedef struct
{
  UInt16 P_x_fix_ThreeBit_P_x_fix_ThreeBit;
} Rte_Calprm_P_x_fix_ThreeBit_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_TwelveBit_CSWC_DEFAULT_RTE_CALPRM_GROUP (153)
typedef struct
{
  UInt16 P_x_fix_TwelveBit_P_x_fix_TwelveBit;
} Rte_Calprm_P_x_fix_TwelveBit_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_TwoBit_CSWC_DEFAULT_RTE_CALPRM_GROUP (154)
typedef struct
{
  UInt16 P_x_fix_TwoBit_P_x_fix_TwoBit;
} Rte_Calprm_P_x_fix_TwoBit_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_U16_One_CSWC_DEFAULT_RTE_CALPRM_GROUP (155)
typedef struct
{
  UInt16 P_x_fix_U16_One_P_x_fix_U16_One;
} Rte_Calprm_P_x_fix_U16_One_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_U32_AtMisMatch_FT_CSWC_DEFAULT_RTE_CALPRM_GROUP (156)
typedef struct
{
  UInt32 P_x_fix_U32_AtMisMatch_FT_P_x_fix_U32_AtMisMatch_FT;
} Rte_Calprm_P_x_fix_U32_AtMisMatch_FT_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_U32_AtNoDrange_FT_CSWC_DEFAULT_RTE_CALPRM_GROUP (157)
typedef struct
{
  UInt32 P_x_fix_U32_AtNoDrange_FT_P_x_fix_U32_AtNoDrange_FT;
} Rte_Calprm_P_x_fix_U32_AtNoDrange_FT_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_U32_AtNoDrange_RT_CSWC_DEFAULT_RTE_CALPRM_GROUP (158)
typedef struct
{
  UInt32 P_x_fix_U32_AtNoDrange_RT_P_x_fix_U32_AtNoDrange_RT;
} Rte_Calprm_P_x_fix_U32_AtNoDrange_RT_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_U32_AtRPrange_FT_CSWC_DEFAULT_RTE_CALPRM_GROUP (159)
typedef struct
{
  UInt32 P_x_fix_U32_AtRPrange_FT_P_x_fix_U32_AtRPrange_FT;
} Rte_Calprm_P_x_fix_U32_AtRPrange_FT_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_U32_AtRPrange_RT_CSWC_DEFAULT_RTE_CALPRM_GROUP (160)
typedef struct
{
  UInt32 P_x_fix_U32_AtRPrange_RT_P_x_fix_U32_AtRPrange_RT;
} Rte_Calprm_P_x_fix_U32_AtRPrange_RT_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_U32_BrkDriverACC_FT_CSWC_DEFAULT_RTE_CALPRM_GROUP (161)
typedef struct
{
  UInt32 P_x_fix_U32_BrkDriverACC_FT_P_x_fix_U32_BrkDriverACC_FT;
} Rte_Calprm_P_x_fix_U32_BrkDriverACC_FT_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_U32_BrkDriverACC_RT_CSWC_DEFAULT_RTE_CALPRM_GROUP (162)
typedef struct
{
  UInt32 P_x_fix_U32_BrkDriverACC_RT_P_x_fix_U32_BrkDriverACC_RT;
} Rte_Calprm_P_x_fix_U32_BrkDriverACC_RT_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_U32_BrkDriverTJP_FT_CSWC_DEFAULT_RTE_CALPRM_GROUP (163)
typedef struct
{
  UInt32 P_x_fix_U32_BrkDriverTJP_FT_P_x_fix_U32_BrkDriverTJP_FT;
} Rte_Calprm_P_x_fix_U32_BrkDriverTJP_FT_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_U32_BrkDriverTJP_RT_CSWC_DEFAULT_RTE_CALPRM_GROUP (164)
typedef struct
{
  UInt32 P_x_fix_U32_BrkDriverTJP_RT_P_x_fix_U32_BrkDriverTJP_RT;
} Rte_Calprm_P_x_fix_U32_BrkDriverTJP_RT_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_U32_CtrlASCD_FT_CSWC_DEFAULT_RTE_CALPRM_GROUP (165)
typedef struct
{
  UInt32 P_x_fix_U32_CtrlASCD_FT_P_x_fix_U32_CtrlASCD_FT;
} Rte_Calprm_P_x_fix_U32_CtrlASCD_FT_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_U32_CtrlASCD_RT_CSWC_DEFAULT_RTE_CALPRM_GROUP (166)
typedef struct
{
  UInt32 P_x_fix_U32_CtrlASCD_RT_P_x_fix_U32_CtrlASCD_RT;
} Rte_Calprm_P_x_fix_U32_CtrlASCD_RT_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_U32_CtrlCBA_FT_CSWC_DEFAULT_RTE_CALPRM_GROUP (167)
typedef struct
{
  UInt32 P_x_fix_U32_CtrlCBA_FT_P_x_fix_U32_CtrlCBA_FT;
} Rte_Calprm_P_x_fix_U32_CtrlCBA_FT_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_U32_CtrlCBA_RT_CSWC_DEFAULT_RTE_CALPRM_GROUP (168)
typedef struct
{
  UInt32 P_x_fix_U32_CtrlCBA_RT_P_x_fix_U32_CtrlCBA_RT;
} Rte_Calprm_P_x_fix_U32_CtrlCBA_RT_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_U32_CtrlDpbActErr_FT_CSWC_DEFAULT_RTE_CALPRM_GROUP (169)
typedef struct
{
  UInt32 P_x_fix_U32_CtrlDpbActErr_FT_P_x_fix_U32_CtrlDpbActErr_FT;
} Rte_Calprm_P_x_fix_U32_CtrlDpbActErr_FT_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_U32_CtrlDpbActErr_RT_CSWC_DEFAULT_RTE_CALPRM_GROUP (170)
typedef struct
{
  UInt32 P_x_fix_U32_CtrlDpbActErr_RT_P_x_fix_U32_CtrlDpbActErr_RT;
} Rte_Calprm_P_x_fix_U32_CtrlDpbActErr_RT_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_U32_CtrlDropTJP_FT_CSWC_DEFAULT_RTE_CALPRM_GROUP (171)
typedef struct
{
  UInt32 P_x_fix_U32_CtrlDropTJP_FT_P_x_fix_U32_CtrlDropTJP_FT;
} Rte_Calprm_P_x_fix_U32_CtrlDropTJP_FT_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_U32_CtrlDropTJP_RT_CSWC_DEFAULT_RTE_CALPRM_GROUP (172)
typedef struct
{
  UInt32 P_x_fix_U32_CtrlDropTJP_RT_P_x_fix_U32_CtrlDropTJP_RT;
} Rte_Calprm_P_x_fix_U32_CtrlDropTJP_RT_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_U32_CtrlDrop_FT_CSWC_DEFAULT_RTE_CALPRM_GROUP (173)
typedef struct
{
  UInt32 P_x_fix_U32_CtrlDrop_FT_P_x_fix_U32_CtrlDrop_FT;
} Rte_Calprm_P_x_fix_U32_CtrlDrop_FT_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_U32_CtrlDrop_RT_CSWC_DEFAULT_RTE_CALPRM_GROUP (174)
typedef struct
{
  UInt32 P_x_fix_U32_CtrlDrop_RT_P_x_fix_U32_CtrlDrop_RT;
} Rte_Calprm_P_x_fix_U32_CtrlDrop_RT_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_U32_CtrlEmergeBrake_FT_CSWC_DEFAULT_RTE_CALPRM_GROUP (175)
typedef struct
{
  UInt32 P_x_fix_U32_CtrlEmergeBrake_FT_P_x_fix_U32_CtrlEmergeBrake_FT;
} Rte_Calprm_P_x_fix_U32_CtrlEmergeBrake_FT_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_U32_CtrlEmergeBrake_RT_CSWC_DEFAULT_RTE_CALPRM_GROUP (176)
typedef struct
{
  UInt32 P_x_fix_U32_CtrlEmergeBrake_RT_P_x_fix_U32_CtrlEmergeBrake_RT;
} Rte_Calprm_P_x_fix_U32_CtrlEmergeBrake_RT_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_U32_CtrlIpa_FT_CSWC_DEFAULT_RTE_CALPRM_GROUP (177)
typedef struct
{
  UInt32 P_x_fix_U32_CtrlIpa_FT_P_x_fix_U32_CtrlIpa_FT;
} Rte_Calprm_P_x_fix_U32_CtrlIpa_FT_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_U32_CtrlIpa_RT_CSWC_DEFAULT_RTE_CALPRM_GROUP (178)
typedef struct
{
  UInt32 P_x_fix_U32_CtrlIpa_RT_P_x_fix_U32_CtrlIpa_RT;
} Rte_Calprm_P_x_fix_U32_CtrlIpa_RT_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_U32_CtrlLostFollow_FT_CSWC_DEFAULT_RTE_CALPRM_GROUP (179)
typedef struct
{
  UInt32 P_x_fix_U32_CtrlLostFollow_FT_P_x_fix_U32_CtrlLostFollow_FT;
} Rte_Calprm_P_x_fix_U32_CtrlLostFollow_FT_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_U32_CtrlLostFollow_RT_CSWC_DEFAULT_RTE_CALPRM_GROUP (180)
typedef struct
{
  UInt32 P_x_fix_U32_CtrlLostFollow_RT_P_x_fix_U32_CtrlLostFollow_RT;
} Rte_Calprm_P_x_fix_U32_CtrlLostFollow_RT_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_U32_CtrlLostInch_FT_CSWC_DEFAULT_RTE_CALPRM_GROUP (181)
typedef struct
{
  UInt32 P_x_fix_U32_CtrlLostInch_FT_P_x_fix_U32_CtrlLostInch_FT;
} Rte_Calprm_P_x_fix_U32_CtrlLostInch_FT_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_U32_CtrlLostInch_RT_CSWC_DEFAULT_RTE_CALPRM_GROUP (182)
typedef struct
{
  UInt32 P_x_fix_U32_CtrlLostInch_RT_P_x_fix_U32_CtrlLostInch_RT;
} Rte_Calprm_P_x_fix_U32_CtrlLostInch_RT_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_U32_CtrlLowSPD_FT_CSWC_DEFAULT_RTE_CALPRM_GROUP (183)
typedef struct
{
  UInt32 P_x_fix_U32_CtrlLowSPD_FT_P_x_fix_U32_CtrlLowSPD_FT;
} Rte_Calprm_P_x_fix_U32_CtrlLowSPD_FT_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_U32_CtrlLowSPD_RT_CSWC_DEFAULT_RTE_CALPRM_GROUP (184)
typedef struct
{
  UInt32 P_x_fix_U32_CtrlLowSPD_RT_P_x_fix_U32_CtrlLowSPD_RT;
} Rte_Calprm_P_x_fix_U32_CtrlLowSPD_RT_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_U32_CtrlPreBrake_FT_CSWC_DEFAULT_RTE_CALPRM_GROUP (185)
typedef struct
{
  UInt32 P_x_fix_U32_CtrlPreBrake_FT_P_x_fix_U32_CtrlPreBrake_FT;
} Rte_Calprm_P_x_fix_U32_CtrlPreBrake_FT_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_U32_CtrlPreBrake_RT_CSWC_DEFAULT_RTE_CALPRM_GROUP (186)
typedef struct
{
  UInt32 P_x_fix_U32_CtrlPreBrake_RT_P_x_fix_U32_CtrlPreBrake_RT;
} Rte_Calprm_P_x_fix_U32_CtrlPreBrake_RT_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_U32_CtrlStpAutoACC_FT_CSWC_DEFAULT_RTE_CALPRM_GROUP (187)
typedef struct
{
  UInt32 P_x_fix_U32_CtrlStpAutoACC_FT_P_x_fix_U32_CtrlStpAutoACC_FT;
} Rte_Calprm_P_x_fix_U32_CtrlStpAutoACC_FT_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_U32_CtrlStpAutoACC_RT_CSWC_DEFAULT_RTE_CALPRM_GROUP (188)
typedef struct
{
  UInt32 P_x_fix_U32_CtrlStpAutoACC_RT_P_x_fix_U32_CtrlStpAutoACC_RT;
} Rte_Calprm_P_x_fix_U32_CtrlStpAutoACC_RT_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_U32_CtrlStpAutoTJP_FT_CSWC_DEFAULT_RTE_CALPRM_GROUP (189)
typedef struct
{
  UInt32 P_x_fix_U32_CtrlStpAutoTJP_FT_P_x_fix_U32_CtrlStpAutoTJP_FT;
} Rte_Calprm_P_x_fix_U32_CtrlStpAutoTJP_FT_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_U32_CtrlStpAutoTJP_RT_CSWC_DEFAULT_RTE_CALPRM_GROUP (190)
typedef struct
{
  UInt32 P_x_fix_U32_CtrlStpAutoTJP_RT_P_x_fix_U32_CtrlStpAutoTJP_RT;
} Rte_Calprm_P_x_fix_U32_CtrlStpAutoTJP_RT_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_U32_CtrlStpBrkAndAccele_FT_CSWC_DEFAULT_RTE_CALPRM_GROUP (191)
typedef struct
{
  UInt32 P_x_fix_U32_CtrlStpBrkAndAccele_FT_P_x_fix_U32_CtrlStpBrkAndAccele_FT;
} Rte_Calprm_P_x_fix_U32_CtrlStpBrkAndAccele_FT_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_U32_CtrlStpBrkAndAccele_RT_CSWC_DEFAULT_RTE_CALPRM_GROUP (192)
typedef struct
{
  UInt32 P_x_fix_U32_CtrlStpBrkAndAccele_RT_P_x_fix_U32_CtrlStpBrkAndAccele_RT;
} Rte_Calprm_P_x_fix_U32_CtrlStpBrkAndAccele_RT_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_U32_CtrlStpFfpACC_FT_CSWC_DEFAULT_RTE_CALPRM_GROUP (193)
typedef struct
{
  UInt32 P_x_fix_U32_CtrlStpFfpACC_FT_P_x_fix_U32_CtrlStpFfpACC_FT;
} Rte_Calprm_P_x_fix_U32_CtrlStpFfpACC_FT_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_U32_CtrlStpFfpACC_RT_CSWC_DEFAULT_RTE_CALPRM_GROUP (194)
typedef struct
{
  UInt32 P_x_fix_U32_CtrlStpFfpACC_RT_P_x_fix_U32_CtrlStpFfpACC_RT;
} Rte_Calprm_P_x_fix_U32_CtrlStpFfpACC_RT_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_U32_CtrlStpLostACC_FT_CSWC_DEFAULT_RTE_CALPRM_GROUP (195)
typedef struct
{
  UInt32 P_x_fix_U32_CtrlStpLostACC_FT_P_x_fix_U32_CtrlStpLostACC_FT;
} Rte_Calprm_P_x_fix_U32_CtrlStpLostACC_FT_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_U32_CtrlStpLostACC_RT_CSWC_DEFAULT_RTE_CALPRM_GROUP (196)
typedef struct
{
  UInt32 P_x_fix_U32_CtrlStpLostACC_RT_P_x_fix_U32_CtrlStpLostACC_RT;
} Rte_Calprm_P_x_fix_U32_CtrlStpLostACC_RT_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_U32_CvtGSens_FT_CSWC_DEFAULT_RTE_CALPRM_GROUP (197)
typedef struct
{
  UInt32 P_x_fix_U32_CvtGSens_FT_P_x_fix_U32_CvtGSens_FT;
} Rte_Calprm_P_x_fix_U32_CvtGSens_FT_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_U32_EapCancel_FT_CSWC_DEFAULT_RTE_CALPRM_GROUP (198)
typedef struct
{
  UInt32 P_x_fix_U32_EapCancel_FT_P_x_fix_U32_EapCancel_FT;
} Rte_Calprm_P_x_fix_U32_EapCancel_FT_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_U32_EapCancel_RT_CSWC_DEFAULT_RTE_CALPRM_GROUP (199)
typedef struct
{
  UInt32 P_x_fix_U32_EapCancel_RT_P_x_fix_U32_EapCancel_RT;
} Rte_Calprm_P_x_fix_U32_EapCancel_RT_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_U32_EpsSystemCancel_FT_CSWC_DEFAULT_RTE_CALPRM_GROUP (200)
typedef struct
{
  UInt32 P_x_fix_U32_EpsSystemCancel_FT_P_x_fix_U32_EpsSystemCancel_FT;
} Rte_Calprm_P_x_fix_U32_EpsSystemCancel_FT_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_U32_EpsSystemCancel_RT_CSWC_DEFAULT_RTE_CALPRM_GROUP (201)
typedef struct
{
  UInt32 P_x_fix_U32_EpsSystemCancel_RT_P_x_fix_U32_EpsSystemCancel_RT;
} Rte_Calprm_P_x_fix_U32_EpsSystemCancel_RT_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_U32_EpsSystemErr_FT_CSWC_DEFAULT_RTE_CALPRM_GROUP (202)
typedef struct
{
  UInt32 P_x_fix_U32_EpsSystemErr_FT_P_x_fix_U32_EpsSystemErr_FT;
} Rte_Calprm_P_x_fix_U32_EpsSystemErr_FT_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_U32_HevRdy_FT_CSWC_DEFAULT_RTE_CALPRM_GROUP (203)
typedef struct
{
  UInt32 P_x_fix_U32_HevRdy_FT_P_x_fix_U32_HevRdy_FT;
} Rte_Calprm_P_x_fix_U32_HevRdy_FT_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_U32_HevRdy_RT_CSWC_DEFAULT_RTE_CALPRM_GROUP (204)
typedef struct
{
  UInt32 P_x_fix_U32_HevRdy_RT_P_x_fix_U32_HevRdy_RT;
} Rte_Calprm_P_x_fix_U32_HevRdy_RT_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_U32_ICC_BlurImg_FT_CSWC_DEFAULT_RTE_CALPRM_GROUP (205)
typedef struct
{
  UInt32 P_x_fix_U32_ICC_BlurImg_FT_P_x_fix_U32_ICC_BlurImg_FT;
} Rte_Calprm_P_x_fix_U32_ICC_BlurImg_FT_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_U32_ICC_BlurImg_RT_CSWC_DEFAULT_RTE_CALPRM_GROUP (206)
typedef struct
{
  UInt32 P_x_fix_U32_ICC_BlurImg_RT_P_x_fix_U32_ICC_BlurImg_RT;
} Rte_Calprm_P_x_fix_U32_ICC_BlurImg_RT_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_U32_ICC_Foggy_FT_CSWC_DEFAULT_RTE_CALPRM_GROUP (207)
typedef struct
{
  UInt32 P_x_fix_U32_ICC_Foggy_FT_P_x_fix_U32_ICC_Foggy_FT;
} Rte_Calprm_P_x_fix_U32_ICC_Foggy_FT_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_U32_ICC_Foggy_RT_CSWC_DEFAULT_RTE_CALPRM_GROUP (208)
typedef struct
{
  UInt32 P_x_fix_U32_ICC_Foggy_RT_P_x_fix_U32_ICC_Foggy_RT;
} Rte_Calprm_P_x_fix_U32_ICC_Foggy_RT_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_U32_ICC_SmearImg_FT_CSWC_DEFAULT_RTE_CALPRM_GROUP (209)
typedef struct
{
  UInt32 P_x_fix_U32_ICC_SmearImg_FT_P_x_fix_U32_ICC_SmearImg_FT;
} Rte_Calprm_P_x_fix_U32_ICC_SmearImg_FT_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_U32_ICC_SmearImg_RT_CSWC_DEFAULT_RTE_CALPRM_GROUP (210)
typedef struct
{
  UInt32 P_x_fix_U32_ICC_SmearImg_RT_P_x_fix_U32_ICC_SmearImg_RT;
} Rte_Calprm_P_x_fix_U32_ICC_SmearImg_RT_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_U32_ICC_Splashes_FT_CSWC_DEFAULT_RTE_CALPRM_GROUP (211)
typedef struct
{
  UInt32 P_x_fix_U32_ICC_Splashes_FT_P_x_fix_U32_ICC_Splashes_FT;
} Rte_Calprm_P_x_fix_U32_ICC_Splashes_FT_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_U32_ICC_Splashes_RT_CSWC_DEFAULT_RTE_CALPRM_GROUP (212)
typedef struct
{
  UInt32 P_x_fix_U32_ICC_Splashes_RT_P_x_fix_U32_ICC_Splashes_RT;
} Rte_Calprm_P_x_fix_U32_ICC_Splashes_RT_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_U32_ICC_SunRay_FT_DayMax_CSWC_DEFAULT_RTE_CALPRM_GROUP (213)
typedef struct
{
  UInt32 P_x_fix_U32_ICC_SunRay_FT_DayMax_P_x_fix_U32_ICC_SunRay_FT_DayMax;
} Rte_Calprm_P_x_fix_U32_ICC_SunRay_FT_DayMax_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_U32_ICC_SunRay_FT_DayMin_CSWC_DEFAULT_RTE_CALPRM_GROUP (214)
typedef struct
{
  UInt32 P_x_fix_U32_ICC_SunRay_FT_DayMin_P_x_fix_U32_ICC_SunRay_FT_DayMin;
} Rte_Calprm_P_x_fix_U32_ICC_SunRay_FT_DayMin_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_U32_ICC_SunRay_FT_Night_CSWC_DEFAULT_RTE_CALPRM_GROUP (215)
typedef struct
{
  UInt32 P_x_fix_U32_ICC_SunRay_FT_Night_P_x_fix_U32_ICC_SunRay_FT_Night;
} Rte_Calprm_P_x_fix_U32_ICC_SunRay_FT_Night_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_U32_ICC_SunRay_RT_CSWC_DEFAULT_RTE_CALPRM_GROUP (216)
typedef struct
{
  UInt32 P_x_fix_U32_ICC_SunRay_RT_P_x_fix_U32_ICC_SunRay_RT;
} Rte_Calprm_P_x_fix_U32_ICC_SunRay_RT_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_U32_One_CSWC_DEFAULT_RTE_CALPRM_GROUP (217)
typedef struct
{
  UInt32 P_x_fix_U32_One_P_x_fix_U32_One;
} Rte_Calprm_P_x_fix_U32_One_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_U32_PA_DELAY_CSWC_DEFAULT_RTE_CALPRM_GROUP (218)
typedef struct
{
  UInt32 P_x_fix_U32_PA_DELAY_P_x_fix_U32_PA_DELAY;
} Rte_Calprm_P_x_fix_U32_PA_DELAY_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_U32_SCAM2_BlurImg_FT_CSWC_DEFAULT_RTE_CALPRM_GROUP (219)
typedef struct
{
  UInt32 P_x_fix_U32_SCAM2_BlurImg_FT_P_x_fix_U32_SCAM2_BlurImg_FT;
} Rte_Calprm_P_x_fix_U32_SCAM2_BlurImg_FT_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_U32_SCAM2_BlurImg_RT_CSWC_DEFAULT_RTE_CALPRM_GROUP (220)
typedef struct
{
  UInt32 P_x_fix_U32_SCAM2_BlurImg_RT_P_x_fix_U32_SCAM2_BlurImg_RT;
} Rte_Calprm_P_x_fix_U32_SCAM2_BlurImg_RT_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_U32_SCAM2_Foggy_FT_CSWC_DEFAULT_RTE_CALPRM_GROUP (221)
typedef struct
{
  UInt32 P_x_fix_U32_SCAM2_Foggy_FT_P_x_fix_U32_SCAM2_Foggy_FT;
} Rte_Calprm_P_x_fix_U32_SCAM2_Foggy_FT_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_U32_SCAM2_Foggy_RT_CSWC_DEFAULT_RTE_CALPRM_GROUP (222)
typedef struct
{
  UInt32 P_x_fix_U32_SCAM2_Foggy_RT_P_x_fix_U32_SCAM2_Foggy_RT;
} Rte_Calprm_P_x_fix_U32_SCAM2_Foggy_RT_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_U32_SCAM2_Halos_FT_CSWC_DEFAULT_RTE_CALPRM_GROUP (223)
typedef struct
{
  UInt32 P_x_fix_U32_SCAM2_Halos_FT_P_x_fix_U32_SCAM2_Halos_FT;
} Rte_Calprm_P_x_fix_U32_SCAM2_Halos_FT_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_U32_SCAM2_Halos_RT_CSWC_DEFAULT_RTE_CALPRM_GROUP (224)
typedef struct
{
  UInt32 P_x_fix_U32_SCAM2_Halos_RT_P_x_fix_U32_SCAM2_Halos_RT;
} Rte_Calprm_P_x_fix_U32_SCAM2_Halos_RT_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_U32_SCAM2_LowSun_FT_CSWC_DEFAULT_RTE_CALPRM_GROUP (225)
typedef struct
{
  UInt32 P_x_fix_U32_SCAM2_LowSun_FT_P_x_fix_U32_SCAM2_LowSun_FT;
} Rte_Calprm_P_x_fix_U32_SCAM2_LowSun_FT_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_U32_SCAM2_LowSun_RT_CSWC_DEFAULT_RTE_CALPRM_GROUP (226)
typedef struct
{
  UInt32 P_x_fix_U32_SCAM2_LowSun_RT_P_x_fix_U32_SCAM2_LowSun_RT;
} Rte_Calprm_P_x_fix_U32_SCAM2_LowSun_RT_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_U32_SCAM2_SmearSpot_FT_CSWC_DEFAULT_RTE_CALPRM_GROUP (227)
typedef struct
{
  UInt32 P_x_fix_U32_SCAM2_SmearSpot_FT_P_x_fix_U32_SCAM2_SmearSpot_FT;
} Rte_Calprm_P_x_fix_U32_SCAM2_SmearSpot_FT_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_U32_SCAM2_SmearSpot_RT_CSWC_DEFAULT_RTE_CALPRM_GROUP (228)
typedef struct
{
  UInt32 P_x_fix_U32_SCAM2_SmearSpot_RT_P_x_fix_U32_SCAM2_SmearSpot_RT;
} Rte_Calprm_P_x_fix_U32_SCAM2_SmearSpot_RT_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_U32_SCAM2_Splashes_FT_CSWC_DEFAULT_RTE_CALPRM_GROUP (229)
typedef struct
{
  UInt32 P_x_fix_U32_SCAM2_Splashes_FT_P_x_fix_U32_SCAM2_Splashes_FT;
} Rte_Calprm_P_x_fix_U32_SCAM2_Splashes_FT_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_U32_SCAM2_Splashes_RT_CSWC_DEFAULT_RTE_CALPRM_GROUP (230)
typedef struct
{
  UInt32 P_x_fix_U32_SCAM2_Splashes_RT_P_x_fix_U32_SCAM2_Splashes_RT;
} Rte_Calprm_P_x_fix_U32_SCAM2_Splashes_RT_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_U32_SCAM2_SunRay_FT_CSWC_DEFAULT_RTE_CALPRM_GROUP (231)
typedef struct
{
  UInt32 P_x_fix_U32_SCAM2_SunRay_FT_P_x_fix_U32_SCAM2_SunRay_FT;
} Rte_Calprm_P_x_fix_U32_SCAM2_SunRay_FT_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_U32_SCAM2_SunRay_RT_CSWC_DEFAULT_RTE_CALPRM_GROUP (232)
typedef struct
{
  UInt32 P_x_fix_U32_SCAM2_SunRay_RT_P_x_fix_U32_SCAM2_SunRay_RT;
} Rte_Calprm_P_x_fix_U32_SCAM2_SunRay_RT_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_U32_SenNoise_FT_CSWC_DEFAULT_RTE_CALPRM_GROUP (233)
typedef struct
{
  UInt32 P_x_fix_U32_SenNoise_FT_P_x_fix_U32_SenNoise_FT;
} Rte_Calprm_P_x_fix_U32_SenNoise_FT_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_U32_SenNoise_RT_CSWC_DEFAULT_RTE_CALPRM_GROUP (234)
typedef struct
{
  UInt32 P_x_fix_U32_SenNoise_RT_P_x_fix_U32_SenNoise_RT;
} Rte_Calprm_P_x_fix_U32_SenNoise_RT_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_U32_SenSonar_B_FT_CSWC_DEFAULT_RTE_CALPRM_GROUP (235)
typedef struct
{
  UInt32 P_x_fix_U32_SenSonar_B_FT_P_x_fix_U32_SenSonar_B_FT;
} Rte_Calprm_P_x_fix_U32_SenSonar_B_FT_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_U32_SwClutch_FT_CSWC_DEFAULT_RTE_CALPRM_GROUP (236)
typedef struct
{
  UInt32 P_x_fix_U32_SwClutch_FT_P_x_fix_U32_SwClutch_FT;
} Rte_Calprm_P_x_fix_U32_SwClutch_FT_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_U32_SwClutch_RT_CSWC_DEFAULT_RTE_CALPRM_GROUP (237)
typedef struct
{
  UInt32 P_x_fix_U32_SwClutch_RT_P_x_fix_U32_SwClutch_RT;
} Rte_Calprm_P_x_fix_U32_SwClutch_RT_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_U32_SwEtsMod_FT_CSWC_DEFAULT_RTE_CALPRM_GROUP (238)
typedef struct
{
  UInt32 P_x_fix_U32_SwEtsMod_FT_P_x_fix_U32_SwEtsMod_FT;
} Rte_Calprm_P_x_fix_U32_SwEtsMod_FT_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_U32_SwEtsMod_RT_CSWC_DEFAULT_RTE_CALPRM_GROUP (239)
typedef struct
{
  UInt32 P_x_fix_U32_SwEtsMod_RT_P_x_fix_U32_SwEtsMod_RT;
} Rte_Calprm_P_x_fix_U32_SwEtsMod_RT_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_U32_SwFixAsl_FT_CSWC_DEFAULT_RTE_CALPRM_GROUP (240)
typedef struct
{
  UInt32 P_x_fix_U32_SwFixAsl_FT_P_x_fix_U32_SwFixAsl_FT;
} Rte_Calprm_P_x_fix_U32_SwFixAsl_FT_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_U32_SwFix_forRN_FT_CSWC_DEFAULT_RTE_CALPRM_GROUP (241)
typedef struct
{
  UInt32 P_x_fix_U32_SwFix_forRN_FT_P_x_fix_U32_SwFix_forRN_FT;
} Rte_Calprm_P_x_fix_U32_SwFix_forRN_FT_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_U32_SwOffRoad_FT_CSWC_DEFAULT_RTE_CALPRM_GROUP (242)
typedef struct
{
  UInt32 P_x_fix_U32_SwOffRoad_FT_P_x_fix_U32_SwOffRoad_FT;
} Rte_Calprm_P_x_fix_U32_SwOffRoad_FT_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_U32_SwOffRoad_RT_CSWC_DEFAULT_RTE_CALPRM_GROUP (243)
typedef struct
{
  UInt32 P_x_fix_U32_SwOffRoad_RT_P_x_fix_U32_SwOffRoad_RT;
} Rte_Calprm_P_x_fix_U32_SwOffRoad_RT_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_U32_SwPark_FT_CSWC_DEFAULT_RTE_CALPRM_GROUP (244)
typedef struct
{
  UInt32 P_x_fix_U32_SwPark_FT_P_x_fix_U32_SwPark_FT;
} Rte_Calprm_P_x_fix_U32_SwPark_FT_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_U32_SwPark_RT_CSWC_DEFAULT_RTE_CALPRM_GROUP (245)
typedef struct
{
  UInt32 P_x_fix_U32_SwPark_RT_P_x_fix_U32_SwPark_RT;
} Rte_Calprm_P_x_fix_U32_SwPark_RT_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_U32_SwSame_FT_CSWC_DEFAULT_RTE_CALPRM_GROUP (246)
typedef struct
{
  UInt32 P_x_fix_U32_SwSame_FT_P_x_fix_U32_SwSame_FT;
} Rte_Calprm_P_x_fix_U32_SwSame_FT_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_U32_SwSame_RT_CSWC_DEFAULT_RTE_CALPRM_GROUP (247)
typedef struct
{
  UInt32 P_x_fix_U32_SwSame_RT_P_x_fix_U32_SwSame_RT;
} Rte_Calprm_P_x_fix_U32_SwSame_RT_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_U32_SwWiper_FT_CSWC_DEFAULT_RTE_CALPRM_GROUP (248)
typedef struct
{
  UInt32 P_x_fix_U32_SwWiper_FT_P_x_fix_U32_SwWiper_FT;
} Rte_Calprm_P_x_fix_U32_SwWiper_FT_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_U32_SwWiper_RT_CSWC_DEFAULT_RTE_CALPRM_GROUP (249)
typedef struct
{
  UInt32 P_x_fix_U32_SwWiper_RT_P_x_fix_U32_SwWiper_RT;
} Rte_Calprm_P_x_fix_U32_SwWiper_RT_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_U32_ePkbActReqErr_FT_CSWC_DEFAULT_RTE_CALPRM_GROUP (250)
typedef struct
{
  UInt32 P_x_fix_U32_ePkbActReqErr_FT_P_x_fix_U32_ePkbActReqErr_FT;
} Rte_Calprm_P_x_fix_U32_ePkbActReqErr_FT_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_U32_ePkbActReqErr_RT_CSWC_DEFAULT_RTE_CALPRM_GROUP (251)
typedef struct
{
  UInt32 P_x_fix_U32_ePkbActReqErr_RT_P_x_fix_U32_ePkbActReqErr_RT;
} Rte_Calprm_P_x_fix_U32_ePkbActReqErr_RT_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_U32_ePkbBreaking_FT_CSWC_DEFAULT_RTE_CALPRM_GROUP (252)
typedef struct
{
  UInt32 P_x_fix_U32_ePkbBreaking_FT_P_x_fix_U32_ePkbBreaking_FT;
} Rte_Calprm_P_x_fix_U32_ePkbBreaking_FT_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_U32_ePkbBreaking_RT_CSWC_DEFAULT_RTE_CALPRM_GROUP (253)
typedef struct
{
  UInt32 P_x_fix_U32_ePkbBreaking_RT_P_x_fix_U32_ePkbBreaking_RT;
} Rte_Calprm_P_x_fix_U32_ePkbBreaking_RT_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_U32_ePkbCancel_FT_CSWC_DEFAULT_RTE_CALPRM_GROUP (254)
typedef struct
{
  UInt32 P_x_fix_U32_ePkbCancel_FT_P_x_fix_U32_ePkbCancel_FT;
} Rte_Calprm_P_x_fix_U32_ePkbCancel_FT_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_U32_ePkbCancel_RT_CSWC_DEFAULT_RTE_CALPRM_GROUP (255)
typedef struct
{
  UInt32 P_x_fix_U32_ePkbCancel_RT_P_x_fix_U32_ePkbCancel_RT;
} Rte_Calprm_P_x_fix_U32_ePkbCancel_RT_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_U32_ePkbSsaUnavail_FT_CSWC_DEFAULT_RTE_CALPRM_GROUP (256)
typedef struct
{
  UInt32 P_x_fix_U32_ePkbSsaUnavail_FT_P_x_fix_U32_ePkbSsaUnavail_FT;
} Rte_Calprm_P_x_fix_U32_ePkbSsaUnavail_FT_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_U32_ePkbSsaUnavail_RT_CSWC_DEFAULT_RTE_CALPRM_GROUP (257)
typedef struct
{
  UInt32 P_x_fix_U32_ePkbSsaUnavail_RT_P_x_fix_U32_ePkbSsaUnavail_RT;
} Rte_Calprm_P_x_fix_U32_ePkbSsaUnavail_RT_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_U32_ePkbSystemErr_FT_CSWC_DEFAULT_RTE_CALPRM_GROUP (258)
typedef struct
{
  UInt32 P_x_fix_U32_ePkbSystemErr_FT_P_x_fix_U32_ePkbSystemErr_FT;
} Rte_Calprm_P_x_fix_U32_ePkbSystemErr_FT_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_U32_timestep_CSWC_DEFAULT_RTE_CALPRM_GROUP (259)
typedef struct
{
  UInt32 P_x_fix_U32_timestep_P_x_fix_U32_timestep;
} Rte_Calprm_P_x_fix_U32_timestep_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_U8_Five_CSWC_DEFAULT_RTE_CALPRM_GROUP (260)
typedef struct
{
  UInt8 P_x_fix_U8_Five_P_x_fix_U8_Five;
} Rte_Calprm_P_x_fix_U8_Five_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_U8_Four_CSWC_DEFAULT_RTE_CALPRM_GROUP (261)
typedef struct
{
  UInt8 P_x_fix_U8_Four_P_x_fix_U8_Four;
} Rte_Calprm_P_x_fix_U8_Four_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_U8_One_CSWC_DEFAULT_RTE_CALPRM_GROUP (262)
typedef struct
{
  UInt8 P_x_fix_U8_One_P_x_fix_U8_One;
} Rte_Calprm_P_x_fix_U8_One_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_U8_Three_CSWC_DEFAULT_RTE_CALPRM_GROUP (263)
typedef struct
{
  UInt8 P_x_fix_U8_Three_P_x_fix_U8_Three;
} Rte_Calprm_P_x_fix_U8_Three_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_U8_Two_CSWC_DEFAULT_RTE_CALPRM_GROUP (264)
typedef struct
{
  UInt8 P_x_fix_U8_Two_P_x_fix_U8_Two;
} Rte_Calprm_P_x_fix_U8_Two_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_U8_ZERO_CSWC_DEFAULT_RTE_CALPRM_GROUP (265)
typedef struct
{
  UInt8 P_x_fix_U8_ZERO_P_x_fix_U8_ZERO;
} Rte_Calprm_P_x_fix_U8_ZERO_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_UDCUTVSP_CSWC_DEFAULT_RTE_CALPRM_GROUP (266)
typedef struct
{
  SInt32 P_x_fix_UDCUTVSP_P_x_fix_UDCUTVSP;
} Rte_Calprm_P_x_fix_UDCUTVSP_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_UDCUTVSP_ADAS_CSWC_DEFAULT_RTE_CALPRM_GROUP (267)
typedef struct
{
  SInt32 P_x_fix_UDCUTVSP_ADAS_P_x_fix_UDCUTVSP_ADAS;
} Rte_Calprm_P_x_fix_UDCUTVSP_ADAS_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_UINT16MAX_CSWC_DEFAULT_RTE_CALPRM_GROUP (268)
typedef struct
{
  UInt16 P_x_fix_UINT16MAX_P_x_fix_UINT16MAX;
} Rte_Calprm_P_x_fix_UINT16MAX_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_VDCActCancel_ACC_FT_CSWC_DEFAULT_RTE_CALPRM_GROUP (269)
typedef struct
{
  UInt32 P_x_fix_VDCActCancel_ACC_FT_P_x_fix_VDCActCancel_ACC_FT;
} Rte_Calprm_P_x_fix_VDCActCancel_ACC_FT_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_VDCActCancel_ACC_RT_CSWC_DEFAULT_RTE_CALPRM_GROUP (270)
typedef struct
{
  UInt32 P_x_fix_VDCActCancel_ACC_RT_P_x_fix_VDCActCancel_ACC_RT;
} Rte_Calprm_P_x_fix_VDCActCancel_ACC_RT_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_VW_VAT_ERR_FAIL_CSWC_DEFAULT_RTE_CALPRM_GROUP (271)
typedef struct
{
  SInt32 P_x_fix_VW_VAT_ERR_FAIL_P_x_fix_VW_VAT_ERR_FAIL;
} Rte_Calprm_P_x_fix_VW_VAT_ERR_FAIL_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_WDADeactivationRequest_CSWC_DEFAULT_RTE_CALPRM_GROUP (272)
typedef struct
{
  UInt8 P_x_fix_WDADeactivationRequest_P_x_fix_WDADeactivationRequest;
} Rte_Calprm_P_x_fix_WDADeactivationRequest_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_WDAResetRequest_CSWC_DEFAULT_RTE_CALPRM_GROUP (273)
typedef struct
{
  UInt8 P_x_fix_WDAResetRequest_P_x_fix_WDAResetRequest;
} Rte_Calprm_P_x_fix_WDAResetRequest_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_ZERO_CSWC_DEFAULT_RTE_CALPRM_GROUP (274)
typedef struct
{
  UInt16 P_x_fix_ZERO_P_x_fix_ZERO;
} Rte_Calprm_P_x_fix_ZERO_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_ZeroBit_CSWC_DEFAULT_RTE_CALPRM_GROUP (275)
typedef struct
{
  UInt16 P_x_fix_ZeroBit_P_x_fix_ZeroBit;
} Rte_Calprm_P_x_fix_ZeroBit_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_ePkbSystemCancel_FT_CSWC_DEFAULT_RTE_CALPRM_GROUP (276)
typedef struct
{
  UInt32 P_x_fix_ePkbSystemCancel_FT_P_x_fix_ePkbSystemCancel_FT;
} Rte_Calprm_P_x_fix_ePkbSystemCancel_FT_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_ePkbSystemCancel_RT_CSWC_DEFAULT_RTE_CALPRM_GROUP (277)
typedef struct
{
  UInt32 P_x_fix_ePkbSystemCancel_RT_P_x_fix_ePkbSystemCancel_RT;
} Rte_Calprm_P_x_fix_ePkbSystemCancel_RT_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_i1ST_to_NOT1ST_CSWC_DEFAULT_RTE_CALPRM_GROUP (278)
typedef struct
{
  UInt32 P_x_fix_i1ST_to_NOT1ST_P_x_fix_i1ST_to_NOT1ST;
} Rte_Calprm_P_x_fix_i1ST_to_NOT1ST_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_iCAN_WIPER_HI_CSWC_DEFAULT_RTE_CALPRM_GROUP (279)
typedef struct
{
  UInt32 P_x_fix_iCAN_WIPER_HI_P_x_fix_iCAN_WIPER_HI;
} Rte_Calprm_P_x_fix_iCAN_WIPER_HI_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_iCAN_WIPER_LO_CSWC_DEFAULT_RTE_CALPRM_GROUP (280)
typedef struct
{
  UInt32 P_x_fix_iCAN_WIPER_LO_P_x_fix_iCAN_WIPER_LO;
} Rte_Calprm_P_x_fix_iCAN_WIPER_LO_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_iDBA_NORMALBRK_CSWC_DEFAULT_RTE_CALPRM_GROUP (281)
typedef struct
{
  UInt8 P_x_fix_iDBA_NORMALBRK_P_x_fix_iDBA_NORMALBRK;
} Rte_Calprm_P_x_fix_iDBA_NORMALBRK_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_iEPB_STAT_BRAKING_CSWC_DEFAULT_RTE_CALPRM_GROUP (282)
typedef struct
{
  UInt8 P_x_fix_iEPB_STAT_BRAKING_P_x_fix_iEPB_STAT_BRAKING;
} Rte_Calprm_P_x_fix_iEPB_STAT_BRAKING_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_iEPB_STAT_RELEASE_CSWC_DEFAULT_RTE_CALPRM_GROUP (283)
typedef struct
{
  UInt8 P_x_fix_iEPB_STAT_RELEASE_P_x_fix_iEPB_STAT_RELEASE;
} Rte_Calprm_P_x_fix_iEPB_STAT_RELEASE_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_iETS_mode_4L_CSWC_DEFAULT_RTE_CALPRM_GROUP (284)
typedef struct
{
  UInt8 P_x_fix_iETS_mode_4L_P_x_fix_iETS_mode_4L;
} Rte_Calprm_P_x_fix_iETS_mode_4L_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_iFCA_1ST_BRK_CSWC_DEFAULT_RTE_CALPRM_GROUP (285)
typedef struct
{
  UInt8 P_x_fix_iFCA_1ST_BRK_P_x_fix_iFCA_1ST_BRK;
} Rte_Calprm_P_x_fix_iFCA_1ST_BRK_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_iFCA_2ND_BRK_CSWC_DEFAULT_RTE_CALPRM_GROUP (286)
typedef struct
{
  UInt8 P_x_fix_iFCA_2ND_BRK_P_x_fix_iFCA_2ND_BRK;
} Rte_Calprm_P_x_fix_iFCA_2ND_BRK_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_iLONG_ACC_02_UNAVAILABLE_CSWC_DEFAULT_RTE_CALPRM_GROUP (287)
typedef struct
{
  SInt16 P_x_fix_iLONG_ACC_02_UNAVAILABLE_P_x_fix_iLONG_ACC_02_UNAVAILABLE;
} Rte_Calprm_P_x_fix_iLONG_ACC_02_UNAVAILABLE_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_iM_MODE_AT_TYPE_CSWC_DEFAULT_RTE_CALPRM_GROUP (288)
typedef struct
{
  UInt8 P_x_fix_iM_MODE_AT_TYPE_P_x_fix_iM_MODE_AT_TYPE;
} Rte_Calprm_P_x_fix_iM_MODE_AT_TYPE_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_iSINT32_MAX_LSB2_16_CSWC_DEFAULT_RTE_CALPRM_GROUP (289)
typedef struct
{
  SInt32 P_x_fix_iSINT32_MAX_LSB2_16_P_x_fix_iSINT32_MAX_LSB2_16;
} Rte_Calprm_P_x_fix_iSINT32_MAX_LSB2_16_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_iSWFIX_NG_CSWC_DEFAULT_RTE_CALPRM_GROUP (290)
typedef struct
{
  UInt16 P_x_fix_iSWFIX_NG_P_x_fix_iSWFIX_NG;
} Rte_Calprm_P_x_fix_iSWFIX_NG_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_iVEHICLE_HOLD_EPKB_REQUEST_CSWC_DEFAULT_RTE_CALPRM_GROUP (291)
typedef struct
{
  UInt8 P_x_fix_iVEHICLE_HOLD_EPKB_REQUEST_P_x_fix_iVEHICLE_HOLD_EPKB_REQUEST;
} Rte_Calprm_P_x_fix_iVEHICLE_HOLD_EPKB_REQUEST_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_iWIPER_HIGH_SPEED_REQ_CSWC_DEFAULT_RTE_CALPRM_GROUP (292)
typedef struct
{
  UInt8 P_x_fix_iWIPER_HIGH_SPEED_REQ_P_x_fix_iWIPER_HIGH_SPEED_REQ;
} Rte_Calprm_P_x_fix_iWIPER_HIGH_SPEED_REQ_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_iWIPER_LOW_SPEED_REQ_CSWC_DEFAULT_RTE_CALPRM_GROUP (293)
typedef struct
{
  UInt8 P_x_fix_iWIPER_LOW_SPEED_REQ_P_x_fix_iWIPER_LOW_SPEED_REQ;
} Rte_Calprm_P_x_fix_iWIPER_LOW_SPEED_REQ_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_iWIPER_ONE_LOW_SPEED_REQ_CSWC_DEFAULT_RTE_CALPRM_GROUP (294)
typedef struct
{
  UInt8 P_x_fix_iWIPER_ONE_LOW_SPEED_REQ_P_x_fix_iWIPER_ONE_LOW_SPEED_REQ;
} Rte_Calprm_P_x_fix_iWIPER_ONE_LOW_SPEED_REQ_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_iWIPER_STOP_ON_CSWC_DEFAULT_RTE_CALPRM_GROUP (295)
typedef struct
{
  UInt32 P_x_fix_iWIPER_STOP_ON_P_x_fix_iWIPER_STOP_ON;
} Rte_Calprm_P_x_fix_iWIPER_STOP_ON_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_iWIPER_STOP_POS_CSWC_DEFAULT_RTE_CALPRM_GROUP (296)
typedef struct
{
  UInt8 P_x_fix_iWIPER_STOP_POS_P_x_fix_iWIPER_STOP_POS;
} Rte_Calprm_P_x_fix_iWIPER_STOP_POS_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_ilow_spd_CSWC_DEFAULT_RTE_CALPRM_GROUP (297)
typedef struct
{
  UInt8 P_x_fix_ilow_spd_P_x_fix_ilow_spd;
} Rte_Calprm_P_x_fix_ilow_spd_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_im_mode_CSWC_DEFAULT_RTE_CALPRM_GROUP (298)
typedef struct
{
  UInt8 P_x_fix_im_mode_P_x_fix_im_mode;
} Rte_Calprm_P_x_fix_im_mode_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_inormal_CSWC_DEFAULT_RTE_CALPRM_GROUP (299)
typedef struct
{
  UInt8 P_x_fix_inormal_P_x_fix_inormal;
} Rte_Calprm_P_x_fix_inormal_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_mAPO_ONCEACC_UAL_CSWC_DEFAULT_RTE_CALPRM_GROUP (300)
typedef struct
{
  UInt32 P_x_fix_mAPO_ONCEACC_UAL_P_x_fix_mAPO_ONCEACC_UAL;
} Rte_Calprm_P_x_fix_mAPO_ONCEACC_UAL_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_mASCD_CRUISE_UAL_CSWC_DEFAULT_RTE_CALPRM_GROUP (301)
typedef struct
{
  UInt32 P_x_fix_mASCD_CRUISE_UAL_P_x_fix_mASCD_CRUISE_UAL;
} Rte_Calprm_P_x_fix_mASCD_CRUISE_UAL_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_mAT_SHIFT1_CSWC_DEFAULT_RTE_CALPRM_GROUP (302)
typedef struct
{
  UInt8 P_x_fix_mAT_SHIFT1_P_x_fix_mAT_SHIFT1;
} Rte_Calprm_P_x_fix_mAT_SHIFT1_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_mDEV_W_SPEED_CSWC_DEFAULT_RTE_CALPRM_GROUP (303)
typedef struct
{
  SInt32 P_x_fix_mDEV_W_SPEED_P_x_fix_mDEV_W_SPEED;
} Rte_Calprm_P_x_fix_mDEV_W_SPEED_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_mDVSP0_CSWC_DEFAULT_RTE_CALPRM_GROUP (304)
typedef struct
{
  SInt16 P_x_fix_mDVSP0_P_x_fix_mDVSP0;
} Rte_Calprm_P_x_fix_mDVSP0_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_mDVSP1_CSWC_DEFAULT_RTE_CALPRM_GROUP (305)
typedef struct
{
  SInt16 P_x_fix_mDVSP1_P_x_fix_mDVSP1;
} Rte_Calprm_P_x_fix_mDVSP1_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_mDVSP2_CSWC_DEFAULT_RTE_CALPRM_GROUP (306)
typedef struct
{
  SInt16 P_x_fix_mDVSP2_P_x_fix_mDVSP2;
} Rte_Calprm_P_x_fix_mDVSP2_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_mDVSP_LMT_FR_CSWC_DEFAULT_RTE_CALPRM_GROUP (307)
typedef struct
{
  SInt32 P_x_fix_mDVSP_LMT_FR_P_x_fix_mDVSP_LMT_FR;
} Rte_Calprm_P_x_fix_mDVSP_LMT_FR_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_mDVSP_LMT_RR_CSWC_DEFAULT_RTE_CALPRM_GROUP (308)
typedef struct
{
  SInt32 P_x_fix_mDVSP_LMT_RR_P_x_fix_mDVSP_LMT_RR;
} Rte_Calprm_P_x_fix_mDVSP_LMT_RR_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_mDVSP_OVER_THRE2_CSWC_DEFAULT_RTE_CALPRM_GROUP (309)
typedef struct
{
  rt_Array_SInt32_6 P_x_fix_mDVSP_OVER_THRE2_P_x_fix_mDVSP_OVER_THRE2;
} Rte_Calprm_P_x_fix_mDVSP_OVER_THRE2_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_mDVSP_OVER_THRE_CSWC_DEFAULT_RTE_CALPRM_GROUP (310)
typedef struct
{
  rt_Array_SInt32_6 P_x_fix_mDVSP_OVER_THRE_P_x_fix_mDVSP_OVER_THRE;
} Rte_Calprm_P_x_fix_mDVSP_OVER_THRE_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_mSPEC_5_20_2_CSWC_DEFAULT_RTE_CALPRM_GROUP (311)
typedef struct
{
  UInt8 P_x_fix_mSPEC_5_20_2_P_x_fix_mSPEC_5_20_2;
} Rte_Calprm_P_x_fix_mSPEC_5_20_2_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_mSPEC_AXLE_TYPE_CSWC_DEFAULT_RTE_CALPRM_GROUP (312)
typedef struct
{
  UInt8 P_x_fix_mSPEC_AXLE_TYPE_P_x_fix_mSPEC_AXLE_TYPE;
} Rte_Calprm_P_x_fix_mSPEC_AXLE_TYPE_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_mSPEC_DAIMLER_CSWC_DEFAULT_RTE_CALPRM_GROUP (313)
typedef struct
{
  UInt8 P_x_fix_mSPEC_DAIMLER_P_x_fix_mSPEC_DAIMLER;
} Rte_Calprm_P_x_fix_mSPEC_DAIMLER_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_mVSP_DVSP_CSWC_DEFAULT_RTE_CALPRM_GROUP (314)
typedef struct
{
  SInt32 P_x_fix_mVSP_DVSP_P_x_fix_mVSP_DVSP;
} Rte_Calprm_P_x_fix_mVSP_DVSP_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_mWIPER_INACTIVE_CSWC_DEFAULT_RTE_CALPRM_GROUP (315)
typedef struct
{
  UInt16 P_x_fix_mWIPER_INACTIVE_P_x_fix_mWIPER_INACTIVE;
} Rte_Calprm_P_x_fix_mWIPER_INACTIVE_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_fix_parking_brake_applied_CSWC_DEFAULT_RTE_CALPRM_GROUP (316)
typedef struct
{
  UInt8 P_x_fix_parking_brake_applied_P_x_fix_parking_brake_applied;
} Rte_Calprm_P_x_fix_parking_brake_applied_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_tng_SPEC_STP_LMP_DRV_CSWC_DEFAULT_RTE_CALPRM_GROUP (317)
typedef struct
{
  Boolean P_x_tng_SPEC_STP_LMP_DRV_P_x_tng_SPEC_STP_LMP_DRV;
} Rte_Calprm_P_x_tng_SPEC_STP_LMP_DRV_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_P_x_tng_VSP_VW_CSWC_DEFAULT_RTE_CALPRM_GROUP (318)
typedef struct
{
  UInt16 P_x_tng_VSP_VW_P_x_tng_VSP_VW;
} Rte_Calprm_P_x_tng_VSP_VW_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_UINT16_0_CSWC_DEFAULT_RTE_CALPRM_GROUP (319)
typedef struct
{
  UInt16 UINT16_0_UINT16_0;
} Rte_Calprm_UINT16_0_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_UINT16_1_CSWC_DEFAULT_RTE_CALPRM_GROUP (320)
typedef struct
{
  UInt16 UINT16_1_UINT16_1;
} Rte_Calprm_UINT16_1_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_UINT8_0_CSWC_DEFAULT_RTE_CALPRM_GROUP (321)
typedef struct
{
  UInt8 UINT8_0_UINT8_0;
} Rte_Calprm_UINT8_0_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_dTRS_CAN_GEAR_N_OR_P_CSWC_DEFAULT_RTE_CALPRM_GROUP (322)
typedef struct
{
  UInt8 dTRS_CAN_GEAR_N_OR_P_dTRS_CAN_GEAR_N_OR_P;
} Rte_Calprm_dTRS_CAN_GEAR_N_OR_P_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_dTRS_CAN_GEAR_R_CSWC_DEFAULT_RTE_CALPRM_GROUP (323)
typedef struct
{
  UInt8 dTRS_CAN_GEAR_R_dTRS_CAN_GEAR_R;
} Rte_Calprm_dTRS_CAN_GEAR_R_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_dTRS_CAN_INDRNG_1st_CSWC_DEFAULT_RTE_CALPRM_GROUP (324)
typedef struct
{
  UInt8 dTRS_CAN_INDRNG_1st_dTRS_CAN_INDRNG_1st;
} Rte_Calprm_dTRS_CAN_INDRNG_1st_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_dTRS_CAN_INDRNG_2nd_CSWC_DEFAULT_RTE_CALPRM_GROUP (325)
typedef struct
{
  UInt8 dTRS_CAN_INDRNG_2nd_dTRS_CAN_INDRNG_2nd;
} Rte_Calprm_dTRS_CAN_INDRNG_2nd_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_dTRS_CAN_INDRNG_3rd_CSWC_DEFAULT_RTE_CALPRM_GROUP (326)
typedef struct
{
  UInt8 dTRS_CAN_INDRNG_3rd_dTRS_CAN_INDRNG_3rd;
} Rte_Calprm_dTRS_CAN_INDRNG_3rd_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_dTRS_CAN_INDRNG_4th_CSWC_DEFAULT_RTE_CALPRM_GROUP (327)
typedef struct
{
  UInt8 dTRS_CAN_INDRNG_4th_dTRS_CAN_INDRNG_4th;
} Rte_Calprm_dTRS_CAN_INDRNG_4th_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_dTRS_CAN_INDRNG_5th_CSWC_DEFAULT_RTE_CALPRM_GROUP (328)
typedef struct
{
  UInt8 dTRS_CAN_INDRNG_5th_dTRS_CAN_INDRNG_5th;
} Rte_Calprm_dTRS_CAN_INDRNG_5th_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_dTRS_CAN_INDRNG_6th_CSWC_DEFAULT_RTE_CALPRM_GROUP (329)
typedef struct
{
  UInt8 dTRS_CAN_INDRNG_6th_dTRS_CAN_INDRNG_6th;
} Rte_Calprm_dTRS_CAN_INDRNG_6th_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_dTRS_CAN_INDRNG_Auto_1st_CSWC_DEFAULT_RTE_CALPRM_GROUP (330)
typedef struct
{
  UInt8 dTRS_CAN_INDRNG_Auto_1st_dTRS_CAN_INDRNG_Auto_1st;
} Rte_Calprm_dTRS_CAN_INDRNG_Auto_1st_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_dTRS_CAN_INDRNG_Auto_2nd_CSWC_DEFAULT_RTE_CALPRM_GROUP (331)
typedef struct
{
  UInt8 dTRS_CAN_INDRNG_Auto_2nd_dTRS_CAN_INDRNG_Auto_2nd;
} Rte_Calprm_dTRS_CAN_INDRNG_Auto_2nd_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_dTRS_CAN_INDRNG_Auto_3rd_CSWC_DEFAULT_RTE_CALPRM_GROUP (332)
typedef struct
{
  UInt8 dTRS_CAN_INDRNG_Auto_3rd_dTRS_CAN_INDRNG_Auto_3rd;
} Rte_Calprm_dTRS_CAN_INDRNG_Auto_3rd_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_dTRS_CAN_INDRNG_Auto_4th_CSWC_DEFAULT_RTE_CALPRM_GROUP (333)
typedef struct
{
  UInt8 dTRS_CAN_INDRNG_Auto_4th_dTRS_CAN_INDRNG_Auto_4th;
} Rte_Calprm_dTRS_CAN_INDRNG_Auto_4th_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_dTRS_CAN_INDRNG_Auto_5th_CSWC_DEFAULT_RTE_CALPRM_GROUP (334)
typedef struct
{
  UInt8 dTRS_CAN_INDRNG_Auto_5th_dTRS_CAN_INDRNG_Auto_5th;
} Rte_Calprm_dTRS_CAN_INDRNG_Auto_5th_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_dTRS_CAN_INDRNG_Auto_6th_CSWC_DEFAULT_RTE_CALPRM_GROUP (335)
typedef struct
{
  UInt8 dTRS_CAN_INDRNG_Auto_6th_dTRS_CAN_INDRNG_Auto_6th;
} Rte_Calprm_dTRS_CAN_INDRNG_Auto_6th_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_dTRS_CAN_INDRNG_B_CSWC_DEFAULT_RTE_CALPRM_GROUP (336)
typedef struct
{
  UInt8 dTRS_CAN_INDRNG_B_dTRS_CAN_INDRNG_B;
} Rte_Calprm_dTRS_CAN_INDRNG_B_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_dTRS_CAN_INDRNG_D_CSWC_DEFAULT_RTE_CALPRM_GROUP (337)
typedef struct
{
  UInt8 dTRS_CAN_INDRNG_D_dTRS_CAN_INDRNG_D;
} Rte_Calprm_dTRS_CAN_INDRNG_D_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_dTRS_CAN_INDRNG_L_CSWC_DEFAULT_RTE_CALPRM_GROUP (338)
typedef struct
{
  UInt8 dTRS_CAN_INDRNG_L_dTRS_CAN_INDRNG_L;
} Rte_Calprm_dTRS_CAN_INDRNG_L_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_dTRS_CAN_INDRNG_Manual_1st_CSWC_DEFAULT_RTE_CALPRM_GROUP (339)
typedef struct
{
  UInt8 dTRS_CAN_INDRNG_Manual_1st_dTRS_CAN_INDRNG_Manual_1st;
} Rte_Calprm_dTRS_CAN_INDRNG_Manual_1st_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_dTRS_CAN_INDRNG_Manual_2nd_CSWC_DEFAULT_RTE_CALPRM_GROUP (340)
typedef struct
{
  UInt8 dTRS_CAN_INDRNG_Manual_2nd_dTRS_CAN_INDRNG_Manual_2nd;
} Rte_Calprm_dTRS_CAN_INDRNG_Manual_2nd_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_dTRS_CAN_INDRNG_Manual_3rd_CSWC_DEFAULT_RTE_CALPRM_GROUP (341)
typedef struct
{
  UInt8 dTRS_CAN_INDRNG_Manual_3rd_dTRS_CAN_INDRNG_Manual_3rd;
} Rte_Calprm_dTRS_CAN_INDRNG_Manual_3rd_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_dTRS_CAN_INDRNG_Manual_4th_CSWC_DEFAULT_RTE_CALPRM_GROUP (342)
typedef struct
{
  UInt8 dTRS_CAN_INDRNG_Manual_4th_dTRS_CAN_INDRNG_Manual_4th;
} Rte_Calprm_dTRS_CAN_INDRNG_Manual_4th_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_dTRS_CAN_INDRNG_Manual_5th_CSWC_DEFAULT_RTE_CALPRM_GROUP (343)
typedef struct
{
  UInt8 dTRS_CAN_INDRNG_Manual_5th_dTRS_CAN_INDRNG_Manual_5th;
} Rte_Calprm_dTRS_CAN_INDRNG_Manual_5th_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_dTRS_CAN_INDRNG_Manual_6th_CSWC_DEFAULT_RTE_CALPRM_GROUP (344)
typedef struct
{
  UInt8 dTRS_CAN_INDRNG_Manual_6th_dTRS_CAN_INDRNG_Manual_6th;
} Rte_Calprm_dTRS_CAN_INDRNG_Manual_6th_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_dTRS_CAN_INDRNG_Manual_7th_CSWC_DEFAULT_RTE_CALPRM_GROUP (345)
typedef struct
{
  UInt8 dTRS_CAN_INDRNG_Manual_7th_dTRS_CAN_INDRNG_Manual_7th;
} Rte_Calprm_dTRS_CAN_INDRNG_Manual_7th_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_dTRS_CAN_INDRNG_Manual_8th_CSWC_DEFAULT_RTE_CALPRM_GROUP (346)
typedef struct
{
  UInt8 dTRS_CAN_INDRNG_Manual_8th_dTRS_CAN_INDRNG_Manual_8th;
} Rte_Calprm_dTRS_CAN_INDRNG_Manual_8th_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_dTRS_CAN_INDRNG_N_CSWC_DEFAULT_RTE_CALPRM_GROUP (347)
typedef struct
{
  UInt8 dTRS_CAN_INDRNG_N_dTRS_CAN_INDRNG_N;
} Rte_Calprm_dTRS_CAN_INDRNG_N_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_dTRS_CAN_INDRNG_P_CSWC_DEFAULT_RTE_CALPRM_GROUP (348)
typedef struct
{
  UInt8 dTRS_CAN_INDRNG_P_dTRS_CAN_INDRNG_P;
} Rte_Calprm_dTRS_CAN_INDRNG_P_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_dTRS_CAN_INDRNG_R_CSWC_DEFAULT_RTE_CALPRM_GROUP (349)
typedef struct
{
  UInt8 dTRS_CAN_INDRNG_R_dTRS_CAN_INDRNG_R;
} Rte_Calprm_dTRS_CAN_INDRNG_R_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_dTRS_CAN_INDRNG_S_CSWC_DEFAULT_RTE_CALPRM_GROUP (350)
typedef struct
{
  UInt8 dTRS_CAN_INDRNG_S_dTRS_CAN_INDRNG_S;
} Rte_Calprm_dTRS_CAN_INDRNG_S_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_iACT_JUDGE_IS_CSWC_DEFAULT_RTE_CALPRM_GROUP (351)
typedef struct
{
  UInt32 iACT_JUDGE_IS_iACT_JUDGE_IS;
} Rte_Calprm_iACT_JUDGE_IS_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_iACT_JUDGE_NO_IS_CSWC_DEFAULT_RTE_CALPRM_GROUP (352)
typedef struct
{
  UInt32 iACT_JUDGE_NO_IS_iACT_JUDGE_NO_IS;
} Rte_Calprm_iACT_JUDGE_NO_IS_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_iAT_DRIVE_RNG_CSWC_DEFAULT_RTE_CALPRM_GROUP (353)
typedef struct
{
  UInt16 iAT_DRIVE_RNG_iAT_DRIVE_RNG;
} Rte_Calprm_iAT_DRIVE_RNG_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_iFF_TYPE_CSWC_DEFAULT_RTE_CALPRM_GROUP (354)
typedef struct
{
  UInt8 iFF_TYPE_iFF_TYPE;
} Rte_Calprm_iFF_TYPE_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_iMAX_gear_num_CSWC_DEFAULT_RTE_CALPRM_GROUP (355)
typedef struct
{
  UInt8 iMAX_gear_num_iMAX_gear_num;
} Rte_Calprm_iMAX_gear_num_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_iSTOP_AUTO_PHASE_NO_IN_AUTO_PHASE_CSWC_DEFAULT_RTE_CALPRM_GROUP (356)
typedef struct
{
  UInt8 iSTOP_AUTO_PHASE_NO_IN_AUTO_PHASE_iSTOP_AUTO_PHASE_NO_IN_AUTO_PHASE;
} Rte_Calprm_iSTOP_AUTO_PHASE_NO_IN_AUTO_PHASE_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_iSW_LONG_CSWC_DEFAULT_RTE_CALPRM_GROUP (357)
typedef struct
{
  UInt16 iSW_LONG_iSW_LONG;
} Rte_Calprm_iSW_LONG_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_iSW_SHORT_CSWC_DEFAULT_RTE_CALPRM_GROUP (358)
typedef struct
{
  UInt8 iSW_SHORT_iSW_SHORT;
} Rte_Calprm_iSW_SHORT_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_iVSP_MAX_CSWC_DEFAULT_RTE_CALPRM_GROUP (359)
typedef struct
{
  UInt8 iVSP_MAX_iVSP_MAX;
} Rte_Calprm_iVSP_MAX_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_mABS_ACT_FCA_OFF2ON_CSWC_DEFAULT_RTE_CALPRM_GROUP (360)
typedef struct
{
  UInt16 mABS_ACT_FCA_OFF2ON_mABS_ACT_FCA_OFF2ON;
} Rte_Calprm_mABS_ACT_FCA_OFF2ON_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_mABS_ACT_FCA_ON2OFF_CSWC_DEFAULT_RTE_CALPRM_GROUP (361)
typedef struct
{
  UInt16 mABS_ACT_FCA_ON2OFF_mABS_ACT_FCA_ON2OFF;
} Rte_Calprm_mABS_ACT_FCA_ON2OFF_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_mACT_TEST_METER_BZR_CSWC_DEFAULT_RTE_CALPRM_GROUP (362)
typedef struct
{
  UInt8 mACT_TEST_METER_BZR_mACT_TEST_METER_BZR;
} Rte_Calprm_mACT_TEST_METER_BZR_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_mARMYU_CONST_CSWC_DEFAULT_RTE_CALPRM_GROUP (363)
typedef struct
{
  Float mARMYU_CONST_mARMYU_CONST;
} Rte_Calprm_mARMYU_CONST_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_mARMYU_TBL_CSWC_DEFAULT_RTE_CALPRM_GROUP (364)
typedef struct
{
  rt_Array_SInt32_46 mARMYU_TBL_mARMYU_TBL;
} Rte_Calprm_mARMYU_TBL_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_mARMYU_VSP_CSWC_DEFAULT_RTE_CALPRM_GROUP (365)
typedef struct
{
  rt_Array_SInt32_46 mARMYU_VSP_mARMYU_VSP;
} Rte_Calprm_mARMYU_VSP_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_mAT_SHIFT1_CSWC_DEFAULT_RTE_CALPRM_GROUP (366)
typedef struct
{
  UInt8 mAT_SHIFT1_mAT_SHIFT1;
} Rte_Calprm_mAT_SHIFT1_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_mAT_SHIFT2_CSWC_DEFAULT_RTE_CALPRM_GROUP (367)
typedef struct
{
  UInt8 mAT_SHIFT2_mAT_SHIFT2;
} Rte_Calprm_mAT_SHIFT2_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_mAT_SHIFT3_CSWC_DEFAULT_RTE_CALPRM_GROUP (368)
typedef struct
{
  UInt8 mAT_SHIFT3_mAT_SHIFT3;
} Rte_Calprm_mAT_SHIFT3_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_mAT_SHIFT4_CSWC_DEFAULT_RTE_CALPRM_GROUP (369)
typedef struct
{
  UInt8 mAT_SHIFT4_mAT_SHIFT4;
} Rte_Calprm_mAT_SHIFT4_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_mAT_SHIFT5_CSWC_DEFAULT_RTE_CALPRM_GROUP (370)
typedef struct
{
  UInt8 mAT_SHIFT5_mAT_SHIFT5;
} Rte_Calprm_mAT_SHIFT5_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_mAT_SHIFT6_CSWC_DEFAULT_RTE_CALPRM_GROUP (371)
typedef struct
{
  UInt8 mAT_SHIFT6_mAT_SHIFT6;
} Rte_Calprm_mAT_SHIFT6_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_mAT_SHIFT7_CSWC_DEFAULT_RTE_CALPRM_GROUP (372)
typedef struct
{
  UInt8 mAT_SHIFT7_mAT_SHIFT7;
} Rte_Calprm_mAT_SHIFT7_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_mAT_SHIFT8_CSWC_DEFAULT_RTE_CALPRM_GROUP (373)
typedef struct
{
  UInt8 mAT_SHIFT8_mAT_SHIFT8;
} Rte_Calprm_mAT_SHIFT8_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_mAT_SHIFT_CVT_CSWC_DEFAULT_RTE_CALPRM_GROUP (374)
typedef struct
{
  UInt8 mAT_SHIFT_CVT_mAT_SHIFT_CVT;
} Rte_Calprm_mAT_SHIFT_CVT_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_mAT_SHIFT_NP_CSWC_DEFAULT_RTE_CALPRM_GROUP (375)
typedef struct
{
  UInt8 mAT_SHIFT_NP_mAT_SHIFT_NP;
} Rte_Calprm_mAT_SHIFT_NP_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_mAT_SHIFT_R_CSWC_DEFAULT_RTE_CALPRM_GROUP (376)
typedef struct
{
  UInt8 mAT_SHIFT_R_mAT_SHIFT_R;
} Rte_Calprm_mAT_SHIFT_R_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_mBACKWARD_JUDGE_TIME_CSWC_DEFAULT_RTE_CALPRM_GROUP (377)
typedef struct
{
  Float mBACKWARD_JUDGE_TIME_mBACKWARD_JUDGE_TIME;
} Rte_Calprm_mBACKWARD_JUDGE_TIME_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_mBLSOFFJDTIM_CSWC_DEFAULT_RTE_CALPRM_GROUP (378)
typedef struct
{
  UInt16 mBLSOFFJDTIM_mBLSOFFJDTIM;
} Rte_Calprm_mBLSOFFJDTIM_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_mBLS_OFF_TIME_CSWC_DEFAULT_RTE_CALPRM_GROUP (379)
typedef struct
{
  Float mBLS_OFF_TIME_mBLS_OFF_TIME;
} Rte_Calprm_mBLS_OFF_TIME_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_mBLS_OFF_VSP_CSWC_DEFAULT_RTE_CALPRM_GROUP (380)
typedef struct
{
  UInt32 mBLS_OFF_VSP_mBLS_OFF_VSP;
} Rte_Calprm_mBLS_OFF_VSP_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_mBLS_OFF_VSP_BPF_CSWC_DEFAULT_RTE_CALPRM_GROUP (381)
typedef struct
{
  SInt32 mBLS_OFF_VSP_BPF_mBLS_OFF_VSP_BPF;
} Rte_Calprm_mBLS_OFF_VSP_BPF_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_mBLS_ON_TIME_CSWC_DEFAULT_RTE_CALPRM_GROUP (382)
typedef struct
{
  Float mBLS_ON_TIME_mBLS_ON_TIME;
} Rte_Calprm_mBLS_ON_TIME_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_mBLS_ON_VSP_CSWC_DEFAULT_RTE_CALPRM_GROUP (383)
typedef struct
{
  UInt32 mBLS_ON_VSP_mBLS_ON_VSP;
} Rte_Calprm_mBLS_ON_VSP_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_mBLS_ON_VSP_BPF_CSWC_DEFAULT_RTE_CALPRM_GROUP (384)
typedef struct
{
  SInt32 mBLS_ON_VSP_BPF_mBLS_ON_VSP_BPF;
} Rte_Calprm_mBLS_ON_VSP_BPF_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_mBODY_STYLE_CSWC_DEFAULT_RTE_CALPRM_GROUP (385)
typedef struct
{
  UInt8 mBODY_STYLE_mBODY_STYLE;
} Rte_Calprm_mBODY_STYLE_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_mBOTTOM_CSWC_DEFAULT_RTE_CALPRM_GROUP (386)
typedef struct
{
  UInt8 mBOTTOM_mBOTTOM;
} Rte_Calprm_mBOTTOM_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_mBRKJDTIM_CSWC_DEFAULT_RTE_CALPRM_GROUP (387)
typedef struct
{
  UInt16 mBRKJDTIM_mBRKJDTIM;
} Rte_Calprm_mBRKJDTIM_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_mBRK_MAX_TIME_CSWC_DEFAULT_RTE_CALPRM_GROUP (388)
typedef struct
{
  rt_Array_UInt16_4 mBRK_MAX_TIME_mBRK_MAX_TIME;
} Rte_Calprm_mBRK_MAX_TIME_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_mBarNmConvert_CSWC_DEFAULT_RTE_CALPRM_GROUP (389)
typedef struct
{
  Float mBarNmConvert_mBarNmConvert;
} Rte_Calprm_mBarNmConvert_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_mCAMERA_PICH_ANGLE_CSWC_DEFAULT_RTE_CALPRM_GROUP (390)
typedef struct
{
  SInt16 mCAMERA_PICH_ANGLE_mCAMERA_PICH_ANGLE;
} Rte_Calprm_mCAMERA_PICH_ANGLE_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_mCAMERA_X_DIST_CSWC_DEFAULT_RTE_CALPRM_GROUP (391)
typedef struct
{
  SInt16 mCAMERA_X_DIST_mCAMERA_X_DIST;
} Rte_Calprm_mCAMERA_X_DIST_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_mCAMERA_Y_DIST_CSWC_DEFAULT_RTE_CALPRM_GROUP (392)
typedef struct
{
  UInt16 mCAMERA_Y_DIST_mCAMERA_Y_DIST;
} Rte_Calprm_mCAMERA_Y_DIST_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_mCAMERA_Y_POS_CSWC_DEFAULT_RTE_CALPRM_GROUP (393)
typedef struct
{
  UInt16 mCAMERA_Y_POS_mCAMERA_Y_POS;
} Rte_Calprm_mCAMERA_Y_POS_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_mCAMERA_Z_DIST_CSWC_DEFAULT_RTE_CALPRM_GROUP (394)
typedef struct
{
  UInt16 mCAMERA_Z_DIST_mCAMERA_Z_DIST;
} Rte_Calprm_mCAMERA_Z_DIST_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_mCANCEL_BZR_TIME_CSWC_DEFAULT_RTE_CALPRM_GROUP (395)
typedef struct
{
  Float mCANCEL_BZR_TIME_mCANCEL_BZR_TIME;
} Rte_Calprm_mCANCEL_BZR_TIME_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_mCANCEL_FEB_BZR_WAIT_TIME_CSWC_DEFAULT_RTE_CALPRM_GROUP (396)
typedef struct
{
  Float mCANCEL_FEB_BZR_WAIT_TIME_mCANCEL_FEB_BZR_WAIT_TIME;
} Rte_Calprm_mCANCEL_FEB_BZR_WAIT_TIME_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_mCANCEL_LDP_BZR_WAIT_TIME_CSWC_DEFAULT_RTE_CALPRM_GROUP (397)
typedef struct
{
  Float mCANCEL_LDP_BZR_WAIT_TIME_mCANCEL_LDP_BZR_WAIT_TIME;
} Rte_Calprm_mCANCEL_LDP_BZR_WAIT_TIME_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_mCURGP_CAL_CSWC_DEFAULT_RTE_CALPRM_GROUP (398)
typedef struct
{
  SInt32 mCURGP_CAL_mCURGP_CAL;
} Rte_Calprm_mCURGP_CAL_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_mCVT_GEAR_CSWC_DEFAULT_RTE_CALPRM_GROUP (399)
typedef struct
{
  SInt32 mCVT_GEAR_mCVT_GEAR;
} Rte_Calprm_mCVT_GEAR_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_mC_BETA_CSWC_DEFAULT_RTE_CALPRM_GROUP (400)
typedef struct
{
  UInt8 mC_BETA_mC_BETA;
} Rte_Calprm_mC_BETA_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_mDRIVE_PROGRAM_CSWC_DEFAULT_RTE_CALPRM_GROUP (401)
typedef struct
{
  UInt8 mDRIVE_PROGRAM_mDRIVE_PROGRAM;
} Rte_Calprm_mDRIVE_PROGRAM_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_mDVSP_EST_LMT_CSWC_DEFAULT_RTE_CALPRM_GROUP (402)
typedef struct
{
  SInt32 mDVSP_EST_LMT_mDVSP_EST_LMT;
} Rte_Calprm_mDVSP_EST_LMT_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_mD_OFFSET_REAR_AXLE_CSWC_DEFAULT_RTE_CALPRM_GROUP (403)
typedef struct
{
  UInt8 mD_OFFSET_REAR_AXLE_mD_OFFSET_REAR_AXLE;
} Rte_Calprm_mD_OFFSET_REAR_AXLE_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_mDisplayVehicleSize_CSWC_DEFAULT_RTE_CALPRM_GROUP (404)
typedef struct
{
  UInt8 mDisplayVehicleSize_mDisplayVehicleSize;
} Rte_Calprm_mDisplayVehicleSize_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_mECMMAIN_SW_NUM_CSWC_DEFAULT_RTE_CALPRM_GROUP (405)
typedef struct
{
  Float mECMMAIN_SW_NUM_mECMMAIN_SW_NUM;
} Rte_Calprm_mECMMAIN_SW_NUM_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_mENGINE_STOP_RPM_CSWC_DEFAULT_RTE_CALPRM_GROUP (406)
typedef struct
{
  SInt32 mENGINE_STOP_RPM_mENGINE_STOP_RPM;
} Rte_Calprm_mENGINE_STOP_RPM_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_mENGINE_STOP_TARBIN_CSWC_DEFAULT_RTE_CALPRM_GROUP (407)
typedef struct
{
  SInt32 mENGINE_STOP_TARBIN_mENGINE_STOP_TARBIN;
} Rte_Calprm_mENGINE_STOP_TARBIN_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_mERR_GRPOSI_CSWC_DEFAULT_RTE_CALPRM_GROUP (408)
typedef struct
{
  SInt32 mERR_GRPOSI_mERR_GRPOSI;
} Rte_Calprm_mERR_GRPOSI_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_mERR_VSP_AR2_CSWC_DEFAULT_RTE_CALPRM_GROUP (409)
typedef struct
{
  UInt32 mERR_VSP_AR2_mERR_VSP_AR2;
} Rte_Calprm_mERR_VSP_AR2_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_mERR_VSP_AR_CSWC_DEFAULT_RTE_CALPRM_GROUP (410)
typedef struct
{
  UInt32 mERR_VSP_AR_mERR_VSP_AR;
} Rte_Calprm_mERR_VSP_AR_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_mEapJudgeVsp_CSWC_DEFAULT_RTE_CALPRM_GROUP (411)
typedef struct
{
  SInt32 mEapJudgeVsp_mEapJudgeVsp;
} Rte_Calprm_mEapJudgeVsp_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_mFCA_APO_ANGLE_THRE_1ST_CSWC_DEFAULT_RTE_CALPRM_GROUP (412)
typedef struct
{
  UInt32 mFCA_APO_ANGLE_THRE_1ST_mFCA_APO_ANGLE_THRE_1ST;
} Rte_Calprm_mFCA_APO_ANGLE_THRE_1ST_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_mFCA_APO_ANGLE_THRE_2ND_CSWC_DEFAULT_RTE_CALPRM_GROUP (413)
typedef struct
{
  UInt32 mFCA_APO_ANGLE_THRE_2ND_mFCA_APO_ANGLE_THRE_2ND;
} Rte_Calprm_mFCA_APO_ANGLE_THRE_2ND_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_mFEB_STOP_CLR_BZR_TIME_CSWC_DEFAULT_RTE_CALPRM_GROUP (414)
typedef struct
{
  Float mFEB_STOP_CLR_BZR_TIME_mFEB_STOP_CLR_BZR_TIME;
} Rte_Calprm_mFEB_STOP_CLR_BZR_TIME_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_mFEB_YAWRATE_FAIL_TH_CSWC_DEFAULT_RTE_CALPRM_GROUP (415)
typedef struct
{
  UInt32 mFEB_YAWRATE_FAIL_TH_mFEB_YAWRATE_FAIL_TH;
} Rte_Calprm_mFEB_YAWRATE_FAIL_TH_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_mFEB_YAWRATE_REC_TH_CSWC_DEFAULT_RTE_CALPRM_GROUP (416)
typedef struct
{
  UInt32 mFEB_YAWRATE_REC_TH_mFEB_YAWRATE_REC_TH;
} Rte_Calprm_mFEB_YAWRATE_REC_TH_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_mFS_FEB_DRVER_BRKOVER_CSWC_DEFAULT_RTE_CALPRM_GROUP (417)
typedef struct
{
  UInt16 mFS_FEB_DRVER_BRKOVER_mFS_FEB_DRVER_BRKOVER;
} Rte_Calprm_mFS_FEB_DRVER_BRKOVER_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_mFS_FEB_YAWRATE_FAIL_TIME_CSWC_DEFAULT_RTE_CALPRM_GROUP (418)
typedef struct
{
  Float mFS_FEB_YAWRATE_FAIL_TIME_mFS_FEB_YAWRATE_FAIL_TIME;
} Rte_Calprm_mFS_FEB_YAWRATE_FAIL_TIME_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_mFS_FEB_YAWRATE_REC_TIME_CSWC_DEFAULT_RTE_CALPRM_GROUP (419)
typedef struct
{
  Float mFS_FEB_YAWRATE_REC_TIME_mFS_FEB_YAWRATE_REC_TIME;
} Rte_Calprm_mFS_FEB_YAWRATE_REC_TIME_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_mGEAR_EFFEICIENCY_MB_CSWC_DEFAULT_RTE_CALPRM_GROUP (420)
typedef struct
{
  SInt32 mGEAR_EFFEICIENCY_MB_mGEAR_EFFEICIENCY_MB;
} Rte_Calprm_mGEAR_EFFEICIENCY_MB_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_mGEAR_FINAL2_CSWC_DEFAULT_RTE_CALPRM_GROUP (421)
typedef struct
{
  SInt32 mGEAR_FINAL2_mGEAR_FINAL2;
} Rte_Calprm_mGEAR_FINAL2_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_mGEAR_FINAL_CSWC_DEFAULT_RTE_CALPRM_GROUP (422)
typedef struct
{
  SInt32 mGEAR_FINAL_mGEAR_FINAL;
} Rte_Calprm_mGEAR_FINAL_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_mGEAR_FINAL_MUL_GEAR_EFFI_CSWC_DEFAULT_RTE_CALPRM_GROUP (423)
typedef struct
{
  SInt32 mGEAR_FINAL_MUL_GEAR_EFFI_mGEAR_FINAL_MUL_GEAR_EFFI;
} Rte_Calprm_mGEAR_FINAL_MUL_GEAR_EFFI_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_mGEAR_HOLD_CSWC_DEFAULT_RTE_CALPRM_GROUP (424)
typedef struct
{
  SInt32 mGEAR_HOLD_mGEAR_HOLD;
} Rte_Calprm_mGEAR_HOLD_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_mGPCAL_CVT_MAX_CSWC_DEFAULT_RTE_CALPRM_GROUP (425)
typedef struct
{
  SInt32 mGPCAL_CVT_MAX_mGPCAL_CVT_MAX;
} Rte_Calprm_mGPCAL_CVT_MAX_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_mGPCAL_CVT_MIN_CSWC_DEFAULT_RTE_CALPRM_GROUP (426)
typedef struct
{
  SInt32 mGPCAL_CVT_MIN_mGPCAL_CVT_MIN;
} Rte_Calprm_mGPCAL_CVT_MIN_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_mG_HEIGHT_CSWC_DEFAULT_RTE_CALPRM_GROUP (427)
typedef struct
{
  UInt8 mG_HEIGHT_mG_HEIGHT;
} Rte_Calprm_mG_HEIGHT_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_mLDPSTPRSTTIM_CSWC_DEFAULT_RTE_CALPRM_GROUP (428)
typedef struct
{
  UInt16 mLDPSTPRSTTIM_mLDPSTPRSTTIM;
} Rte_Calprm_mLDPSTPRSTTIM_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_mLDWMotDuty_CSWC_DEFAULT_RTE_CALPRM_GROUP (429)
typedef struct
{
  UInt8 mLDWMotDuty_mLDWMotDuty;
} Rte_Calprm_mLDWMotDuty_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_mLOAD_DISTRIBUTION_CSWC_DEFAULT_RTE_CALPRM_GROUP (430)
typedef struct
{
  UInt8 mLOAD_DISTRIBUTION_mLOAD_DISTRIBUTION;
} Rte_Calprm_mLOAD_DISTRIBUTION_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_mLS_HEIGHT_CSWC_DEFAULT_RTE_CALPRM_GROUP (431)
typedef struct
{
  UInt8 mLS_HEIGHT_mLS_HEIGHT;
} Rte_Calprm_mLS_HEIGHT_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_mLS_OFFSET_CSWC_DEFAULT_RTE_CALPRM_GROUP (432)
typedef struct
{
  SInt8 mLS_OFFSET_mLS_OFFSET;
} Rte_Calprm_mLS_OFFSET_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_mLdwBuzVibCycle_CSWC_DEFAULT_RTE_CALPRM_GROUP (433)
typedef struct
{
  UInt8 mLdwBuzVibCycle_mLdwBuzVibCycle;
} Rte_Calprm_mLdwBuzVibCycle_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_mLdwMotorOFFtime_CSWC_DEFAULT_RTE_CALPRM_GROUP (434)
typedef struct
{
  uint16_NP mLdwMotorOFFtime_mLdwMotorOFFtime;
} Rte_Calprm_mLdwMotorOFFtime_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_mLdwMotorONtime_CSWC_DEFAULT_RTE_CALPRM_GROUP (435)
typedef struct
{
  uint16_NP mLdwMotorONtime_mLdwMotorONtime;
} Rte_Calprm_mLdwMotorONtime_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_mMAIN_SW_IGNON_TIME_CSWC_DEFAULT_RTE_CALPRM_GROUP (436)
typedef struct
{
  UInt16 mMAIN_SW_IGNON_TIME_mMAIN_SW_IGNON_TIME;
} Rte_Calprm_mMAIN_SW_IGNON_TIME_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_mMARKET_CSWC_DEFAULT_RTE_CALPRM_GROUP (437)
typedef struct
{
  UInt8 mMARKET_mMARKET;
} Rte_Calprm_mMARKET_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_mMAX_ABS_ACT_CSWC_DEFAULT_RTE_CALPRM_GROUP (438)
typedef struct
{
  UInt8 mMAX_ABS_ACT_mMAX_ABS_ACT;
} Rte_Calprm_mMAX_ABS_ACT_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_mMAX_TCS_ON_CSWC_DEFAULT_RTE_CALPRM_GROUP (439)
typedef struct
{
  UInt16 mMAX_TCS_ON_mMAX_TCS_ON;
} Rte_Calprm_mMAX_TCS_ON_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_mMAX_VDC_ON_CSWC_DEFAULT_RTE_CALPRM_GROUP (440)
typedef struct
{
  UInt16 mMAX_VDC_ON_mMAX_VDC_ON;
} Rte_Calprm_mMAX_VDC_ON_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_mMODCHG_CSWC_DEFAULT_RTE_CALPRM_GROUP (441)
typedef struct
{
  Float mMODCHG_mMODCHG;
} Rte_Calprm_mMODCHG_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_mMODEL_IDEN_CSWC_DEFAULT_RTE_CALPRM_GROUP (442)
typedef struct
{
  UInt16 mMODEL_IDEN_mMODEL_IDEN;
} Rte_Calprm_mMODEL_IDEN_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_mORIENTATION_CSWC_DEFAULT_RTE_CALPRM_GROUP (443)
typedef struct
{
  Boolean mORIENTATION_mORIENTATION;
} Rte_Calprm_mORIENTATION_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_mPBRK_IDM_MOM_CSWC_DEFAULT_RTE_CALPRM_GROUP (444)
typedef struct
{
  SInt32 mPBRK_IDM_MOM_mPBRK_IDM_MOM;
} Rte_Calprm_mPBRK_IDM_MOM_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_mRATIO_CHANGE_CSWC_DEFAULT_RTE_CALPRM_GROUP (445)
typedef struct
{
  rt_Array_SInt32_2 mRATIO_CHANGE_mRATIO_CHANGE;
} Rte_Calprm_mRATIO_CHANGE_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_mREV_ENG_CSWC_DEFAULT_RTE_CALPRM_GROUP (446)
typedef struct
{
  rt_Array_SInt32_19 mREV_ENG_mREV_ENG;
} Rte_Calprm_mREV_ENG_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_mREV_OUT_AT_CSWC_DEFAULT_RTE_CALPRM_GROUP (447)
typedef struct
{
  SInt32 mREV_OUT_AT_mREV_OUT_AT;
} Rte_Calprm_mREV_OUT_AT_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_mREV_OUT_AT_LMT_CSWC_DEFAULT_RTE_CALPRM_GROUP (448)
typedef struct
{
  SInt32 mREV_OUT_AT_LMT_mREV_OUT_AT_LMT;
} Rte_Calprm_mREV_OUT_AT_LMT_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_mRMINHR_ADAS_CSWC_DEFAULT_RTE_CALPRM_GROUP (449)
typedef struct
{
  UInt32 mRMINHR_ADAS_mRMINHR_ADAS;
} Rte_Calprm_mRMINHR_ADAS_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_mRMINHV_ADAS_CSWC_DEFAULT_RTE_CALPRM_GROUP (450)
typedef struct
{
  UInt32 mRMINHV_ADAS_mRMINHV_ADAS;
} Rte_Calprm_mRMINHV_ADAS_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_mR_GEAR_1_CSWC_DEFAULT_RTE_CALPRM_GROUP (451)
typedef struct
{
  SInt32 mR_GEAR_1_mR_GEAR_1;
} Rte_Calprm_mR_GEAR_1_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_mR_GEAR_2_CSWC_DEFAULT_RTE_CALPRM_GROUP (452)
typedef struct
{
  SInt32 mR_GEAR_2_mR_GEAR_2;
} Rte_Calprm_mR_GEAR_2_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_mR_GEAR_3_CSWC_DEFAULT_RTE_CALPRM_GROUP (453)
typedef struct
{
  SInt32 mR_GEAR_3_mR_GEAR_3;
} Rte_Calprm_mR_GEAR_3_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_mR_GEAR_4_CSWC_DEFAULT_RTE_CALPRM_GROUP (454)
typedef struct
{
  SInt32 mR_GEAR_4_mR_GEAR_4;
} Rte_Calprm_mR_GEAR_4_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_mR_GEAR_5_CSWC_DEFAULT_RTE_CALPRM_GROUP (455)
typedef struct
{
  SInt32 mR_GEAR_5_mR_GEAR_5;
} Rte_Calprm_mR_GEAR_5_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_mR_GEAR_6_CSWC_DEFAULT_RTE_CALPRM_GROUP (456)
typedef struct
{
  SInt32 mR_GEAR_6_mR_GEAR_6;
} Rte_Calprm_mR_GEAR_6_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_mR_GEAR_7_CSWC_DEFAULT_RTE_CALPRM_GROUP (457)
typedef struct
{
  SInt32 mR_GEAR_7_mR_GEAR_7;
} Rte_Calprm_mR_GEAR_7_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_mR_GEAR_8_CSWC_DEFAULT_RTE_CALPRM_GROUP (458)
typedef struct
{
  SInt32 mR_GEAR_8_mR_GEAR_8;
} Rte_Calprm_mR_GEAR_8_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_mR_GEAR_R_CSWC_DEFAULT_RTE_CALPRM_GROUP (459)
typedef struct
{
  SInt32 mR_GEAR_R_mR_GEAR_R;
} Rte_Calprm_mR_GEAR_R_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_mSEN_DGNOK_VSP_CSWC_DEFAULT_RTE_CALPRM_GROUP (460)
typedef struct
{
  SInt32 mSEN_DGNOK_VSP_mSEN_DGNOK_VSP;
} Rte_Calprm_mSEN_DGNOK_VSP_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_mSND1_BSW_SPKVOL_CSWC_DEFAULT_RTE_CALPRM_GROUP (461)
typedef struct
{
  UInt8 mSND1_BSW_SPKVOL_mSND1_BSW_SPKVOL;
} Rte_Calprm_mSND1_BSW_SPKVOL_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_mSND1_CANCELBUZ_SPKVOL_CSWC_DEFAULT_RTE_CALPRM_GROUP (462)
typedef struct
{
  UInt8 mSND1_CANCELBUZ_SPKVOL_mSND1_CANCELBUZ_SPKVOL;
} Rte_Calprm_mSND1_CANCELBUZ_SPKVOL_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_mSND1_CTAMOD_SPKVOL_CSWC_DEFAULT_RTE_CALPRM_GROUP (463)
typedef struct
{
  UInt8 mSND1_CTAMOD_SPKVOL_mSND1_CTAMOD_SPKVOL;
} Rte_Calprm_mSND1_CTAMOD_SPKVOL_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_mSND1_LDW_SPKVOL_CSWC_DEFAULT_RTE_CALPRM_GROUP (464)
typedef struct
{
  UInt8 mSND1_LDW_SPKVOL_mSND1_LDW_SPKVOL;
} Rte_Calprm_mSND1_LDW_SPKVOL_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_mSND1_OPER_SPKVOL_CSWC_DEFAULT_RTE_CALPRM_GROUP (465)
typedef struct
{
  UInt8 mSND1_OPER_SPKVOL_mSND1_OPER_SPKVOL;
} Rte_Calprm_mSND1_OPER_SPKVOL_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_mSND2_CANCELBUZ_SPKVOL_CSWC_DEFAULT_RTE_CALPRM_GROUP (466)
typedef struct
{
  UInt8 mSND2_CANCELBUZ_SPKVOL_mSND2_CANCELBUZ_SPKVOL;
} Rte_Calprm_mSND2_CANCELBUZ_SPKVOL_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_mSND2_DIST_WARN_SPKVOL_CSWC_DEFAULT_RTE_CALPRM_GROUP (467)
typedef struct
{
  UInt8 mSND2_DIST_WARN_SPKVOL_mSND2_DIST_WARN_SPKVOL;
} Rte_Calprm_mSND2_DIST_WARN_SPKVOL_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_mSND2_FCW_SPKVOL_CSWC_DEFAULT_RTE_CALPRM_GROUP (468)
typedef struct
{
  UInt8 mSND2_FCW_SPKVOL_mSND2_FCW_SPKVOL;
} Rte_Calprm_mSND2_FCW_SPKVOL_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_mSND3_FEB_SPKVOL_CSWC_DEFAULT_RTE_CALPRM_GROUP (469)
typedef struct
{
  UInt8 mSND3_FEB_SPKVOL_mSND3_FEB_SPKVOL;
} Rte_Calprm_mSND3_FEB_SPKVOL_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_mSND4_HANDS_OFF_NEW1_SPKVOL_CSWC_DEFAULT_RTE_CALPRM_GROUP (470)
typedef struct
{
  UInt8 mSND4_HANDS_OFF_NEW1_SPKVOL_mSND4_HANDS_OFF_NEW1_SPKVOL;
} Rte_Calprm_mSND4_HANDS_OFF_NEW1_SPKVOL_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_mSND4_HANDS_OFF_NEW2_SPKVOL_CSWC_DEFAULT_RTE_CALPRM_GROUP (471)
typedef struct
{
  UInt8 mSND4_HANDS_OFF_NEW2_SPKVOL_mSND4_HANDS_OFF_NEW2_SPKVOL;
} Rte_Calprm_mSND4_HANDS_OFF_NEW2_SPKVOL_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_mSND4_HANDS_OFF_NEW3_SPKVOL_CSWC_DEFAULT_RTE_CALPRM_GROUP (472)
typedef struct
{
  UInt8 mSND4_HANDS_OFF_NEW3_SPKVOL_mSND4_HANDS_OFF_NEW3_SPKVOL;
} Rte_Calprm_mSND4_HANDS_OFF_NEW3_SPKVOL_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_mSND4_HANDS_OFF_SPKVOL_CSWC_DEFAULT_RTE_CALPRM_GROUP (473)
typedef struct
{
  UInt8 mSND4_HANDS_OFF_SPKVOL_mSND4_HANDS_OFF_SPKVOL;
} Rte_Calprm_mSND4_HANDS_OFF_SPKVOL_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_mSND4_LANE_DETECT_SPKVOL_CSWC_DEFAULT_RTE_CALPRM_GROUP (474)
typedef struct
{
  UInt8 mSND4_LANE_DETECT_SPKVOL_mSND4_LANE_DETECT_SPKVOL;
} Rte_Calprm_mSND4_LANE_DETECT_SPKVOL_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_mSND4_LANE_LOST_SPKVOL_CSWC_DEFAULT_RTE_CALPRM_GROUP (475)
typedef struct
{
  UInt8 mSND4_LANE_LOST_SPKVOL_mSND4_LANE_LOST_SPKVOL;
} Rte_Calprm_mSND4_LANE_LOST_SPKVOL_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_mSND4_PFCW_SPKVOL_CSWC_DEFAULT_RTE_CALPRM_GROUP (476)
typedef struct
{
  UInt8 mSND4_PFCW_SPKVOL_mSND4_PFCW_SPKVOL;
} Rte_Calprm_mSND4_PFCW_SPKVOL_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_mSPECDIAG_CSWC_DEFAULT_RTE_CALPRM_GROUP (477)
typedef struct
{
  rt_Array_UInt8_40 mSPECDIAG_mSPECDIAG;
} Rte_Calprm_mSPECDIAG_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_mSPECINFO_CSWC_DEFAULT_RTE_CALPRM_GROUP (478)
typedef struct
{
  rt_Array_UInt8_16 mSPECINFO_mSPECINFO;
} Rte_Calprm_mSPECINFO_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_mSPEC_ASL_CSWC_DEFAULT_RTE_CALPRM_GROUP (479)
typedef struct
{
  Boolean mSPEC_ASL_mSPEC_ASL;
} Rte_Calprm_mSPEC_ASL_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_mSPEC_ASL_APP_CSWC_DEFAULT_RTE_CALPRM_GROUP (480)
typedef struct
{
  Boolean mSPEC_ASL_APP_mSPEC_ASL_APP;
} Rte_Calprm_mSPEC_ASL_APP_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_mSPEC_AXLE_TYPE_CSWC_DEFAULT_RTE_CALPRM_GROUP (481)
typedef struct
{
  UInt8 mSPEC_AXLE_TYPE_mSPEC_AXLE_TYPE;
} Rte_Calprm_mSPEC_AXLE_TYPE_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_mSPEC_CAN_GEN_CSWC_DEFAULT_RTE_CALPRM_GROUP (482)
typedef struct
{
  UInt8 mSPEC_CAN_GEN_mSPEC_CAN_GEN;
} Rte_Calprm_mSPEC_CAN_GEN_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_mSTABILITY_FACTOR_CSWC_DEFAULT_RTE_CALPRM_GROUP (483)
typedef struct
{
  UInt16 mSTABILITY_FACTOR_mSTABILITY_FACTOR;
} Rte_Calprm_mSTABILITY_FACTOR_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_mSTANDING_JUDGE_TIME_CSWC_DEFAULT_RTE_CALPRM_GROUP (484)
typedef struct
{
  Float mSTANDING_JUDGE_TIME_mSTANDING_JUDGE_TIME;
} Rte_Calprm_mSTANDING_JUDGE_TIME_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_mSTANDING_PRESSURE_CSWC_DEFAULT_RTE_CALPRM_GROUP (485)
typedef struct
{
  SInt16 mSTANDING_PRESSURE_mSTANDING_PRESSURE;
} Rte_Calprm_mSTANDING_PRESSURE_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_mSTAT_CHG_NUM_CSWC_DEFAULT_RTE_CALPRM_GROUP (486)
typedef struct
{
  Float mSTAT_CHG_NUM_mSTAT_CHG_NUM;
} Rte_Calprm_mSTAT_CHG_NUM_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_mSTPRTO_ADAS_CSWC_DEFAULT_RTE_CALPRM_GROUP (487)
typedef struct
{
  SInt32 mSTPRTO_ADAS_mSTPRTO_ADAS;
} Rte_Calprm_mSTPRTO_ADAS_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_mSTRCNTRLGAIN3_CSWC_DEFAULT_RTE_CALPRM_GROUP (488)
typedef struct
{
  SInt32 mSTRCNTRLGAIN3_mSTRCNTRLGAIN3;
} Rte_Calprm_mSTRCNTRLGAIN3_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_mSTR_GEAR_RATIO_xaxis_CSWC_DEFAULT_RTE_CALPRM_GROUP (489)
typedef struct
{
  rt_Array_SInt16_10 mSTR_GEAR_RATIO_xaxis_mSTR_GEAR_RATIO_xaxis;
} Rte_Calprm_mSTR_GEAR_RATIO_xaxis_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_mSTR_GEAR_RATIO_yaxis_CSWC_DEFAULT_RTE_CALPRM_GROUP (490)
typedef struct
{
  rt_Array_SInt16_11 mSTR_GEAR_RATIO_yaxis_mSTR_GEAR_RATIO_yaxis;
} Rte_Calprm_mSTR_GEAR_RATIO_yaxis_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_mSTR_GEAR_RATIO_zaxis_CSWC_DEFAULT_RTE_CALPRM_GROUP (491)
typedef struct
{
  rt_Array_UInt8_110 mSTR_GEAR_RATIO_zaxis_mSTR_GEAR_RATIO_zaxis;
} Rte_Calprm_mSTR_GEAR_RATIO_zaxis_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_mSTR_WHL_RL_MAX_MAP_xaxis_CSWC_DEFAULT_RTE_CALPRM_GROUP (492)
typedef struct
{
  rt_Array_SInt16_28 mSTR_WHL_RL_MAX_MAP_xaxis_mSTR_WHL_RL_MAX_MAP_xaxis;
} Rte_Calprm_mSTR_WHL_RL_MAX_MAP_xaxis_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_mSTR_WHL_RL_MAX_MAP_yaxis_CSWC_DEFAULT_RTE_CALPRM_GROUP (493)
typedef struct
{
  rt_Array_SInt16_28 mSTR_WHL_RL_MAX_MAP_yaxis_mSTR_WHL_RL_MAX_MAP_yaxis;
} Rte_Calprm_mSTR_WHL_RL_MAX_MAP_yaxis_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_mSW_ENGON_TIME_CSWC_DEFAULT_RTE_CALPRM_GROUP (494)
typedef struct
{
  UInt16 mSW_ENGON_TIME_mSW_ENGON_TIME;
} Rte_Calprm_mSW_ENGON_TIME_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_mS_TEIKOU_MAP_XAXIS_CSWC_DEFAULT_RTE_CALPRM_GROUP (495)
typedef struct
{
  rt_Array_SInt32_16 mS_TEIKOU_MAP_XAXIS_mS_TEIKOU_MAP_XAXIS;
} Rte_Calprm_mS_TEIKOU_MAP_XAXIS_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_mS_TEIKOU_MAP_YAXIS_CSWC_DEFAULT_RTE_CALPRM_GROUP (496)
typedef struct
{
  rt_Array_SInt32_16 mS_TEIKOU_MAP_YAXIS_mS_TEIKOU_MAP_YAXIS;
} Rte_Calprm_mS_TEIKOU_MAP_YAXIS_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_mTARGET_TORQUE_UPLMT_CSWC_DEFAULT_RTE_CALPRM_GROUP (497)
typedef struct
{
  UInt16 mTARGET_TORQUE_UPLMT_mTARGET_TORQUE_UPLMT;
} Rte_Calprm_mTARGET_TORQUE_UPLMT_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_mTAR_RATIO_LMT_DEC_CSWC_DEFAULT_RTE_CALPRM_GROUP (498)
typedef struct
{
  SInt32 mTAR_RATIO_LMT_DEC_mTAR_RATIO_LMT_DEC;
} Rte_Calprm_mTAR_RATIO_LMT_DEC_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_mTAR_RATIO_LMT_INC_CSWC_DEFAULT_RTE_CALPRM_GROUP (499)
typedef struct
{
  SInt32 mTAR_RATIO_LMT_INC_mTAR_RATIO_LMT_INC;
} Rte_Calprm_mTAR_RATIO_LMT_INC_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_mTENG_LPF_Param_A_CSWC_DEFAULT_RTE_CALPRM_GROUP (500)
typedef struct
{
  SInt32 mTENG_LPF_Param_A_mTENG_LPF_Param_A;
} Rte_Calprm_mTENG_LPF_Param_A_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_mTENG_LPF_Param_B_CSWC_DEFAULT_RTE_CALPRM_GROUP (501)
typedef struct
{
  SInt32 mTENG_LPF_Param_B_mTENG_LPF_Param_B;
} Rte_Calprm_mTENG_LPF_Param_B_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_mTENG_T0_MAP_XAXIS_CSWC_DEFAULT_RTE_CALPRM_GROUP (502)
typedef struct
{
  rt_Array_SInt32_20 mTENG_T0_MAP_XAXIS_mTENG_T0_MAP_XAXIS;
} Rte_Calprm_mTENG_T0_MAP_XAXIS_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_mTENG_T0_MAP_YAXIS_CSWC_DEFAULT_RTE_CALPRM_GROUP (503)
typedef struct
{
  rt_Array_SInt32_20 mTENG_T0_MAP_YAXIS_mTENG_T0_MAP_YAXIS;
} Rte_Calprm_mTENG_T0_MAP_YAXIS_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_mTHILMT_CSWC_DEFAULT_RTE_CALPRM_GROUP (504)
typedef struct
{
  rt_Array_SInt16_19 mTHILMT_mTHILMT;
} Rte_Calprm_mTHILMT_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_mTJP_CANCEL_APO_ANGL_CSWC_DEFAULT_RTE_CALPRM_GROUP (505)
typedef struct
{
  UInt16 mTJP_CANCEL_APO_ANGL_mTJP_CANCEL_APO_ANGL;
} Rte_Calprm_mTJP_CANCEL_APO_ANGL_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_mTJP_TESTMODE_JUDGETIME_CSWC_DEFAULT_RTE_CALPRM_GROUP (506)
typedef struct
{
  UInt16 mTJP_TESTMODE_JUDGETIME_mTJP_TESTMODE_JUDGETIME;
} Rte_Calprm_mTJP_TESTMODE_JUDGETIME_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_mTMREV_NOIS_CSWC_DEFAULT_RTE_CALPRM_GROUP (507)
typedef struct
{
  SInt16 mTMREV_NOIS_mTMREV_NOIS;
} Rte_Calprm_mTMREV_NOIS_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_mTORUQE_RATIO_HOSEI_MAP_XAXIS_CSWC_DEFAULT_RTE_CALPRM_GROUP (508)
typedef struct
{
  rt_Array_SInt32_18 mTORUQE_RATIO_HOSEI_MAP_XAXIS_mTORUQE_RATIO_HOSEI_MAP_XAXIS;
} Rte_Calprm_mTORUQE_RATIO_HOSEI_MAP_XAXIS_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_mTORUQE_RATIO_HOSEI_MAP_YAXIS_CSWC_DEFAULT_RTE_CALPRM_GROUP (509)
typedef struct
{
  rt_Array_SInt32_18 mTORUQE_RATIO_HOSEI_MAP_YAXIS_mTORUQE_RATIO_HOSEI_MAP_YAXIS;
} Rte_Calprm_mTORUQE_RATIO_HOSEI_MAP_YAXIS_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_mTORUQE_RATIO_MAP_XAXIS_CSWC_DEFAULT_RTE_CALPRM_GROUP (510)
typedef struct
{
  rt_Array_SInt32_18 mTORUQE_RATIO_MAP_XAXIS_mTORUQE_RATIO_MAP_XAXIS;
} Rte_Calprm_mTORUQE_RATIO_MAP_XAXIS_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_mTORUQE_RATIO_MAP_YAXIS_CSWC_DEFAULT_RTE_CALPRM_GROUP (511)
typedef struct
{
  rt_Array_SInt32_18 mTORUQE_RATIO_MAP_YAXIS_mTORUQE_RATIO_MAP_YAXIS;
} Rte_Calprm_mTORUQE_RATIO_MAP_YAXIS_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_mTRQ_RATIO_MAX_CSWC_DEFAULT_RTE_CALPRM_GROUP (512)
typedef struct
{
  SInt32 mTRQ_RATIO_MAX_mTRQ_RATIO_MAX;
} Rte_Calprm_mTRQ_RATIO_MAX_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_mTRQ_RATIO_MIN_CSWC_DEFAULT_RTE_CALPRM_GROUP (513)
typedef struct
{
  SInt32 mTRQ_RATIO_MIN_mTRQ_RATIO_MIN;
} Rte_Calprm_mTRQ_RATIO_MIN_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_mTachoLPF_Param_A_CSWC_DEFAULT_RTE_CALPRM_GROUP (514)
typedef struct
{
  SInt32 mTachoLPF_Param_A_mTachoLPF_Param_A;
} Rte_Calprm_mTachoLPF_Param_A_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_mTachoLPF_Param_B_CSWC_DEFAULT_RTE_CALPRM_GROUP (515)
typedef struct
{
  SInt32 mTachoLPF_Param_B_mTachoLPF_Param_B;
} Rte_Calprm_mTachoLPF_Param_B_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_mVEHICLE_WIDTH_CSWC_DEFAULT_RTE_CALPRM_GROUP (516)
typedef struct
{
  UInt16 mVEHICLE_WIDTH_mVEHICLE_WIDTH;
} Rte_Calprm_mVEHICLE_WIDTH_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_mVSP_AT_CSWC_DEFAULT_RTE_CALPRM_GROUP (517)
typedef struct
{
  SInt32 mVSP_AT_mVSP_AT;
} Rte_Calprm_mVSP_AT_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_mVSP_BPS_LPF1_CSWC_DEFAULT_RTE_CALPRM_GROUP (518)
typedef struct
{
  SInt32 mVSP_BPS_LPF1_mVSP_BPS_LPF1;
} Rte_Calprm_mVSP_BPS_LPF1_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_mVSP_BPS_LPF2_CSWC_DEFAULT_RTE_CALPRM_GROUP (519)
typedef struct
{
  SInt32 mVSP_BPS_LPF2_mVSP_BPS_LPF2;
} Rte_Calprm_mVSP_BPS_LPF2_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_mVSP_BPS_LPF3_CSWC_DEFAULT_RTE_CALPRM_GROUP (520)
typedef struct
{
  SInt32 mVSP_BPS_LPF3_mVSP_BPS_LPF3;
} Rte_Calprm_mVSP_BPS_LPF3_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_mVSP_BPS_LPF4_CSWC_DEFAULT_RTE_CALPRM_GROUP (521)
typedef struct
{
  SInt32 mVSP_BPS_LPF4_mVSP_BPS_LPF4;
} Rte_Calprm_mVSP_BPS_LPF4_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_mVSP_BPS_LPF5_CSWC_DEFAULT_RTE_CALPRM_GROUP (522)
typedef struct
{
  SInt32 mVSP_BPS_LPF5_mVSP_BPS_LPF5;
} Rte_Calprm_mVSP_BPS_LPF5_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_mVSP_CHANGE_CSWC_DEFAULT_RTE_CALPRM_GROUP (523)
typedef struct
{
  rt_Array_SInt32_2 mVSP_CHANGE_mVSP_CHANGE;
} Rte_Calprm_mVSP_CHANGE_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_mVSP_CHG_RPM_to_MPS_CSWC_DEFAULT_RTE_CALPRM_GROUP (524)
typedef struct
{
  UInt16 mVSP_CHG_RPM_to_MPS_mVSP_CHG_RPM_to_MPS;
} Rte_Calprm_mVSP_CHG_RPM_to_MPS_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_mVSP_EST_LMT_CSWC_DEFAULT_RTE_CALPRM_GROUP (525)
typedef struct
{
  SInt32 mVSP_EST_LMT_mVSP_EST_LMT;
} Rte_Calprm_mVSP_EST_LMT_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_mVSP_FCA_MAX_CSWC_DEFAULT_RTE_CALPRM_GROUP (526)
typedef struct
{
  SInt32 mVSP_FCA_MAX_mVSP_FCA_MAX;
} Rte_Calprm_mVSP_FCA_MAX_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_mVSP_FCA_MIN_CSWC_DEFAULT_RTE_CALPRM_GROUP (527)
typedef struct
{
  SInt32 mVSP_FCA_MIN_mVSP_FCA_MIN;
} Rte_Calprm_mVSP_FCA_MIN_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_mVSP_FCA_PED_MAX_CSWC_DEFAULT_RTE_CALPRM_GROUP (528)
typedef struct
{
  SInt32 mVSP_FCA_PED_MAX_mVSP_FCA_PED_MAX;
} Rte_Calprm_mVSP_FCA_PED_MAX_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_mVSP_FCA_STOP_MAX_CSWC_DEFAULT_RTE_CALPRM_GROUP (529)
typedef struct
{
  SInt32 mVSP_FCA_STOP_MAX_mVSP_FCA_STOP_MAX;
} Rte_Calprm_mVSP_FCA_STOP_MAX_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_mVSP_LPF_PARAM_B_XAXIS_CSWC_DEFAULT_RTE_CALPRM_GROUP (530)
typedef struct
{
  rt_Array_SInt32_4 mVSP_LPF_PARAM_B_XAXIS_mVSP_LPF_PARAM_B_XAXIS;
} Rte_Calprm_mVSP_LPF_PARAM_B_XAXIS_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_mVSP_LPF_PARAM_B_YAXIS_CSWC_DEFAULT_RTE_CALPRM_GROUP (531)
typedef struct
{
  rt_Array_SInt32_4 mVSP_LPF_PARAM_B_YAXIS_mVSP_LPF_PARAM_B_YAXIS;
} Rte_Calprm_mVSP_LPF_PARAM_B_YAXIS_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_mVSP_NOIS_CSWC_DEFAULT_RTE_CALPRM_GROUP (532)
typedef struct
{
  SInt16 mVSP_NOIS_mVSP_NOIS;
} Rte_Calprm_mVSP_NOIS_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_mVSP_SPEED_TH_CSWC_DEFAULT_RTE_CALPRM_GROUP (533)
typedef struct
{
  UInt32 mVSP_SPEED_TH_mVSP_SPEED_TH;
} Rte_Calprm_mVSP_SPEED_TH_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_mV_WEIGHT_CSWC_DEFAULT_RTE_CALPRM_GROUP (534)
typedef struct
{
  UInt8 mV_WEIGHT_mV_WEIGHT;
} Rte_Calprm_mV_WEIGHT_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_mWHEEL_BASE_MILLI_CSWC_DEFAULT_RTE_CALPRM_GROUP (535)
typedef struct
{
  UInt16 mWHEEL_BASE_MILLI_mWHEEL_BASE_MILLI;
} Rte_Calprm_mWHEEL_BASE_MILLI_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_mWHEEL_RADIUS_CSWC_DEFAULT_RTE_CALPRM_GROUP (536)
typedef struct
{
  UInt16 mWHEEL_RADIUS_mWHEEL_RADIUS;
} Rte_Calprm_mWHEEL_RADIUS_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_mWHEEL_TRACK_CSWC_DEFAULT_RTE_CALPRM_GROUP (537)
typedef struct
{
  UInt8 mWHEEL_TRACK_mWHEEL_TRACK;
} Rte_Calprm_mWHEEL_TRACK_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_tTRS_INPREV_LPF_PARAM_a_CSWC_DEFAULT_RTE_CALPRM_GROUP (538)
typedef struct
{
  SInt32 tTRS_INPREV_LPF_PARAM_a_tTRS_INPREV_LPF_PARAM_a;
} Rte_Calprm_tTRS_INPREV_LPF_PARAM_a_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_tTRS_INPREV_LPF_PARAM_b_CSWC_DEFAULT_RTE_CALPRM_GROUP (539)
typedef struct
{
  SInt32 tTRS_INPREV_LPF_PARAM_b_tTRS_INPREV_LPF_PARAM_b;
} Rte_Calprm_tTRS_INPREV_LPF_PARAM_b_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_tTRS_OUTREV_LPF_PARAM_a_CSWC_DEFAULT_RTE_CALPRM_GROUP (540)
typedef struct
{
  SInt32 tTRS_OUTREV_LPF_PARAM_a_tTRS_OUTREV_LPF_PARAM_a;
} Rte_Calprm_tTRS_OUTREV_LPF_PARAM_a_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;

# define Rte_CalprmElementGroup_tTRS_OUTREV_LPF_PARAM_b_CSWC_DEFAULT_RTE_CALPRM_GROUP (541)
typedef struct
{
  SInt32 tTRS_OUTREV_LPF_PARAM_b_tTRS_OUTREV_LPF_PARAM_b;
} Rte_Calprm_tTRS_OUTREV_LPF_PARAM_b_CSWC_DEFAULT_RTE_CALPRM_GROUP_Type;


/**********************************************************************************************************************
 * Per-Instance Memory User Types
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * Constant value definitions
 *********************************************************************************************************************/

# define RTE_START_SEC_CONST_UNSPECIFIED
//# include "MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */

extern CONST(UDSCP_SigmaVSsdType, RTE_CONST) Rte_SigmaVSsdInitArray; /* PRQA S 0850 */ /* MD_MSR_19.8 */

extern CONST(UDSCP_SigmaVTddType, RTE_CONST) Rte_SigmaVTddInitArray; /* PRQA S 0850 */ /* MD_MSR_19.8 */

extern CONST(UDSCP_VinType, RTE_CONST) Rte_VinInitArray; /* PRQA S 0850 */ /* MD_MSR_19.8 */

extern CONST(rt_Array_UInt8_10, RTE_CONST) Rte_C_rt_Array_UInt8_10_0; /* PRQA S 0850 */ /* MD_MSR_19.8 */

extern CONST(rt_Array_UInt8_16, RTE_CONST) Rte_C_rt_Array_UInt8_16_0; /* PRQA S 0850 */ /* MD_MSR_19.8 */

extern CONST(rt_Array_UInt8_2, RTE_CONST) Rte_C_rt_Array_UInt8_2_0; /* PRQA S 0850 */ /* MD_MSR_19.8 */

extern CONST(rt_Array_UInt8_44, RTE_CONST) Rte_C_rt_Array_UInt8_44_0; /* PRQA S 0850 */ /* MD_MSR_19.8 */

extern CONST(rt_Array_UInt8_5, RTE_CONST) Rte_C_rt_Array_UInt8_5_0; /* PRQA S 0850 */ /* MD_MSR_19.8 */

extern CONST(rt_Array_UInt8_516, RTE_CONST) Rte_C_rt_Array_UInt8_516_0; /* PRQA S 0850 */ /* MD_MSR_19.8 */

extern CONST(rt_Array_UInt8_60, RTE_CONST) Rte_C_rt_Array_UInt8_60_0; /* PRQA S 0850 */ /* MD_MSR_19.8 */

extern CONST(rt_Array_UInt8_64, RTE_CONST) Rte_C_rt_Array_UInt8_64_0; /* PRQA S 0850 */ /* MD_MSR_19.8 */

extern CONST(rt_Array_float32_2, RTE_CONST) Rte_C_rt_Array_float32_2_0; /* PRQA S 0850 */ /* MD_MSR_19.8 */

extern CONST(RecSg020_NP, RTE_CONST) Rte_C_RecSg020_NP_0; /* PRQA S 0850 */ /* MD_MSR_19.8 */

extern CONST(RecSg09F_NP, RTE_CONST) Rte_C_RecSg09F_NP_0; /* PRQA S 0850 */ /* MD_MSR_19.8 */

extern CONST(RecSg0A0_NP, RTE_CONST) Rte_C_RecSg0A0_NP_0; /* PRQA S 0850 */ /* MD_MSR_19.8 */

extern CONST(RecSg0A4_NP, RTE_CONST) Rte_C_RecSg0A4_NP_0; /* PRQA S 0850 */ /* MD_MSR_19.8 */

extern CONST(RecSg0A6_NP, RTE_CONST) Rte_C_RecSg0A6_NP_0; /* PRQA S 0850 */ /* MD_MSR_19.8 */

extern CONST(RecSg0A7_NP, RTE_CONST) Rte_C_RecSg0A7_NP_0; /* PRQA S 0850 */ /* MD_MSR_19.8 */

extern CONST(RecSg0A8_NP, RTE_CONST) Rte_C_RecSg0A8_NP_0; /* PRQA S 0850 */ /* MD_MSR_19.8 */

extern CONST(RecSg0AA_NP, RTE_CONST) Rte_C_RecSg0AA_NP_0; /* PRQA S 0850 */ /* MD_MSR_19.8 */

extern CONST(RecSg0AB_NP, RTE_CONST) Rte_C_RecSg0AB_NP_0; /* PRQA S 0850 */ /* MD_MSR_19.8 */

extern CONST(RecSg0AC_NP, RTE_CONST) Rte_C_RecSg0AC_NP_0; /* PRQA S 0850 */ /* MD_MSR_19.8 */

extern CONST(RecSg0B1_NP, RTE_CONST) Rte_C_RecSg0B1_NP_0; /* PRQA S 0850 */ /* MD_MSR_19.8 */

extern CONST(RecSg0B2_NP, RTE_CONST) Rte_C_RecSg0B2_NP_0; /* PRQA S 0850 */ /* MD_MSR_19.8 */

extern CONST(RecSg0B4_NP, RTE_CONST) Rte_C_RecSg0B4_NP_0; /* PRQA S 0850 */ /* MD_MSR_19.8 */

extern CONST(RecSg0B6_NP, RTE_CONST) Rte_C_RecSg0B6_NP_0; /* PRQA S 0850 */ /* MD_MSR_19.8 */

extern CONST(RecSg0B7_NP, RTE_CONST) Rte_C_RecSg0B7_NP_0; /* PRQA S 0850 */ /* MD_MSR_19.8 */

extern CONST(RecSg0FF_NP, RTE_CONST) Rte_C_RecSg0FF_NP_0; /* PRQA S 0850 */ /* MD_MSR_19.8 */

extern CONST(RecSg202_NP, RTE_CONST) Rte_C_RecSg202_NP_0; /* PRQA S 0850 */ /* MD_MSR_19.8 */

extern CONST(RecSg205_NP, RTE_CONST) Rte_C_RecSg205_NP_0; /* PRQA S 0850 */ /* MD_MSR_19.8 */

extern CONST(RecSg207_NP, RTE_CONST) Rte_C_RecSg207_NP_0; /* PRQA S 0850 */ /* MD_MSR_19.8 */

extern CONST(RecSg21D_NP, RTE_CONST) Rte_C_RecSg21D_NP_0; /* PRQA S 0850 */ /* MD_MSR_19.8 */

extern CONST(RecSg21E_NP, RTE_CONST) Rte_C_RecSg21E_NP_0; /* PRQA S 0850 */ /* MD_MSR_19.8 */

extern CONST(RecSg21F_NP, RTE_CONST) Rte_C_RecSg21F_NP_0; /* PRQA S 0850 */ /* MD_MSR_19.8 */

extern CONST(RecSg220_NP, RTE_CONST) Rte_C_RecSg220_NP_0; /* PRQA S 0850 */ /* MD_MSR_19.8 */

extern CONST(RecSg222_NP, RTE_CONST) Rte_C_RecSg222_NP_0; /* PRQA S 0850 */ /* MD_MSR_19.8 */

extern CONST(RecSg223_NP, RTE_CONST) Rte_C_RecSg223_NP_0; /* PRQA S 0850 */ /* MD_MSR_19.8 */

extern CONST(RecSg240_NP, RTE_CONST) Rte_C_RecSg240_NP_0; /* PRQA S 0850 */ /* MD_MSR_19.8 */

extern CONST(RecSg241_NP, RTE_CONST) Rte_C_RecSg241_NP_0; /* PRQA S 0850 */ /* MD_MSR_19.8 */

extern CONST(RecSg246_NP, RTE_CONST) Rte_C_RecSg246_NP_0; /* PRQA S 0850 */ /* MD_MSR_19.8 */

extern CONST(RecSg247_NP, RTE_CONST) Rte_C_RecSg247_NP_0; /* PRQA S 0850 */ /* MD_MSR_19.8 */

extern CONST(RecSg248_NP, RTE_CONST) Rte_C_RecSg248_NP_0; /* PRQA S 0850 */ /* MD_MSR_19.8 */

extern CONST(RecSg24A_NP, RTE_CONST) Rte_C_RecSg24A_NP_0; /* PRQA S 0850 */ /* MD_MSR_19.8 */

extern CONST(RecSg24B_NP, RTE_CONST) Rte_C_RecSg24B_NP_0; /* PRQA S 0850 */ /* MD_MSR_19.8 */

extern CONST(RecSg24C_NP, RTE_CONST) Rte_C_RecSg24C_NP_0; /* PRQA S 0850 */ /* MD_MSR_19.8 */

extern CONST(RecSg24D_NP, RTE_CONST) Rte_C_RecSg24D_NP_0; /* PRQA S 0850 */ /* MD_MSR_19.8 */

extern CONST(RecSg24E_NP, RTE_CONST) Rte_C_RecSg24E_NP_0; /* PRQA S 0850 */ /* MD_MSR_19.8 */

extern CONST(RecSg24F_NP, RTE_CONST) Rte_C_RecSg24F_NP_0; /* PRQA S 0850 */ /* MD_MSR_19.8 */

extern CONST(RecSg250_NP, RTE_CONST) Rte_C_RecSg250_NP_0; /* PRQA S 0850 */ /* MD_MSR_19.8 */

extern CONST(RecSg25B_NP, RTE_CONST) Rte_C_RecSg25B_NP_0; /* PRQA S 0850 */ /* MD_MSR_19.8 */

extern CONST(RecSg25C_NP, RTE_CONST) Rte_C_RecSg25C_NP_0; /* PRQA S 0850 */ /* MD_MSR_19.8 */

extern CONST(RecSg25E_NP, RTE_CONST) Rte_C_RecSg25E_NP_0; /* PRQA S 0850 */ /* MD_MSR_19.8 */

extern CONST(RecSg262_NP, RTE_CONST) Rte_C_RecSg262_NP_0; /* PRQA S 0850 */ /* MD_MSR_19.8 */

extern CONST(RecSg263_NP, RTE_CONST) Rte_C_RecSg263_NP_0; /* PRQA S 0850 */ /* MD_MSR_19.8 */

extern CONST(RecSg264_NP, RTE_CONST) Rte_C_RecSg264_NP_0; /* PRQA S 0850 */ /* MD_MSR_19.8 */

extern CONST(RecSg266_NP, RTE_CONST) Rte_C_RecSg266_NP_0; /* PRQA S 0850 */ /* MD_MSR_19.8 */

extern CONST(RecSg267_NP, RTE_CONST) Rte_C_RecSg267_NP_0; /* PRQA S 0850 */ /* MD_MSR_19.8 */

extern CONST(RecSg268_NP, RTE_CONST) Rte_C_RecSg268_NP_0; /* PRQA S 0850 */ /* MD_MSR_19.8 */

extern CONST(RecSg269_NP, RTE_CONST) Rte_C_RecSg269_NP_0; /* PRQA S 0850 */ /* MD_MSR_19.8 */

extern CONST(RecSg26E_NP, RTE_CONST) Rte_C_RecSg26E_NP_0; /* PRQA S 0850 */ /* MD_MSR_19.8 */

extern CONST(RecSg26F_NP, RTE_CONST) Rte_C_RecSg26F_NP_0; /* PRQA S 0850 */ /* MD_MSR_19.8 */

extern CONST(RecSg289_NP, RTE_CONST) Rte_C_RecSg289_NP_0; /* PRQA S 0850 */ /* MD_MSR_19.8 */

extern CONST(RecSg28A_NP, RTE_CONST) Rte_C_RecSg28A_NP_0; /* PRQA S 0850 */ /* MD_MSR_19.8 */

extern CONST(RecSg293_NP, RTE_CONST) Rte_C_RecSg293_NP_0; /* PRQA S 0850 */ /* MD_MSR_19.8 */

extern CONST(RecSg294_NP, RTE_CONST) Rte_C_RecSg294_NP_0; /* PRQA S 0850 */ /* MD_MSR_19.8 */

extern CONST(RecSg295_NP, RTE_CONST) Rte_C_RecSg295_NP_0; /* PRQA S 0850 */ /* MD_MSR_19.8 */

extern CONST(RecSg2A3_NP, RTE_CONST) Rte_C_RecSg2A3_NP_0; /* PRQA S 0850 */ /* MD_MSR_19.8 */

extern CONST(RecSg2A4_NP, RTE_CONST) Rte_C_RecSg2A4_NP_0; /* PRQA S 0850 */ /* MD_MSR_19.8 */

extern CONST(RecSg2AC_NP, RTE_CONST) Rte_C_RecSg2AC_NP_0; /* PRQA S 0850 */ /* MD_MSR_19.8 */

extern CONST(RecSg2AD_NP, RTE_CONST) Rte_C_RecSg2AD_NP_0; /* PRQA S 0850 */ /* MD_MSR_19.8 */

extern CONST(RecSg2AE_NP, RTE_CONST) Rte_C_RecSg2AE_NP_0; /* PRQA S 0850 */ /* MD_MSR_19.8 */

extern CONST(RecSg2AF_NP, RTE_CONST) Rte_C_RecSg2AF_NP_0; /* PRQA S 0850 */ /* MD_MSR_19.8 */

extern CONST(RecSg2C4_NP, RTE_CONST) Rte_C_RecSg2C4_NP_0; /* PRQA S 0850 */ /* MD_MSR_19.8 */

extern CONST(RecSg2C5_NP, RTE_CONST) Rte_C_RecSg2C5_NP_0; /* PRQA S 0850 */ /* MD_MSR_19.8 */

extern CONST(RecSg2C7_NP, RTE_CONST) Rte_C_RecSg2C7_NP_0; /* PRQA S 0850 */ /* MD_MSR_19.8 */

extern CONST(RecSg2C8_NP, RTE_CONST) Rte_C_RecSg2C8_NP_0; /* PRQA S 0850 */ /* MD_MSR_19.8 */

extern CONST(RecSg2C9_NP, RTE_CONST) Rte_C_RecSg2C9_NP_0; /* PRQA S 0850 */ /* MD_MSR_19.8 */

extern CONST(RecSg2CA_NP, RTE_CONST) Rte_C_RecSg2CA_NP_0; /* PRQA S 0850 */ /* MD_MSR_19.8 */

extern CONST(RecSg2CB_NP, RTE_CONST) Rte_C_RecSg2CB_NP_0; /* PRQA S 0850 */ /* MD_MSR_19.8 */

extern CONST(RecSg2CC_NP, RTE_CONST) Rte_C_RecSg2CC_NP_0; /* PRQA S 0850 */ /* MD_MSR_19.8 */

extern CONST(RecSg2CD_NP, RTE_CONST) Rte_C_RecSg2CD_NP_0; /* PRQA S 0850 */ /* MD_MSR_19.8 */

extern CONST(RecSg2CE_NP, RTE_CONST) Rte_C_RecSg2CE_NP_0; /* PRQA S 0850 */ /* MD_MSR_19.8 */

extern CONST(RecSg2CF_NP, RTE_CONST) Rte_C_RecSg2CF_NP_0; /* PRQA S 0850 */ /* MD_MSR_19.8 */

extern CONST(RecSg2D0_NP, RTE_CONST) Rte_C_RecSg2D0_NP_0; /* PRQA S 0850 */ /* MD_MSR_19.8 */

extern CONST(RecSg2D2_NP, RTE_CONST) Rte_C_RecSg2D2_NP_0; /* PRQA S 0850 */ /* MD_MSR_19.8 */

extern CONST(RecSg2D6_NP, RTE_CONST) Rte_C_RecSg2D6_NP_0; /* PRQA S 0850 */ /* MD_MSR_19.8 */

extern CONST(RecSg2D7_NP, RTE_CONST) Rte_C_RecSg2D7_NP_0; /* PRQA S 0850 */ /* MD_MSR_19.8 */

extern CONST(RecSg2D8_NP, RTE_CONST) Rte_C_RecSg2D8_NP_0; /* PRQA S 0850 */ /* MD_MSR_19.8 */

extern CONST(RecSg2EC_NP, RTE_CONST) Rte_C_RecSg2EC_NP_0; /* PRQA S 0850 */ /* MD_MSR_19.8 */

extern CONST(RecSg2EE_NP, RTE_CONST) Rte_C_RecSg2EE_NP_0; /* PRQA S 0850 */ /* MD_MSR_19.8 */

extern CONST(RecSg302_NP, RTE_CONST) Rte_C_RecSg302_NP_0; /* PRQA S 0850 */ /* MD_MSR_19.8 */

extern CONST(RecSg311_NP, RTE_CONST) Rte_C_RecSg311_NP_0; /* PRQA S 0850 */ /* MD_MSR_19.8 */

extern CONST(RecSg315_NP, RTE_CONST) Rte_C_RecSg315_NP_0; /* PRQA S 0850 */ /* MD_MSR_19.8 */

extern CONST(RecSg322_NP, RTE_CONST) Rte_C_RecSg322_NP_0; /* PRQA S 0850 */ /* MD_MSR_19.8 */

extern CONST(RecSg323_NP, RTE_CONST) Rte_C_RecSg323_NP_0; /* PRQA S 0850 */ /* MD_MSR_19.8 */

extern CONST(RecSg324_NP, RTE_CONST) Rte_C_RecSg324_NP_0; /* PRQA S 0850 */ /* MD_MSR_19.8 */

extern CONST(RecSg325_NP, RTE_CONST) Rte_C_RecSg325_NP_0; /* PRQA S 0850 */ /* MD_MSR_19.8 */

extern CONST(RecSg32A_NP, RTE_CONST) Rte_C_RecSg32A_NP_0; /* PRQA S 0850 */ /* MD_MSR_19.8 */

extern CONST(RecSg32C_NP, RTE_CONST) Rte_C_RecSg32C_NP_0; /* PRQA S 0850 */ /* MD_MSR_19.8 */

extern CONST(RecSg32D_NP, RTE_CONST) Rte_C_RecSg32D_NP_0; /* PRQA S 0850 */ /* MD_MSR_19.8 */

extern CONST(RecSg32E_NP, RTE_CONST) Rte_C_RecSg32E_NP_0; /* PRQA S 0850 */ /* MD_MSR_19.8 */

extern CONST(RecSg32F_NP, RTE_CONST) Rte_C_RecSg32F_NP_0; /* PRQA S 0850 */ /* MD_MSR_19.8 */

extern CONST(RecSg331_NP, RTE_CONST) Rte_C_RecSg331_NP_0; /* PRQA S 0850 */ /* MD_MSR_19.8 */

extern CONST(RecSg332_NP, RTE_CONST) Rte_C_RecSg332_NP_0; /* PRQA S 0850 */ /* MD_MSR_19.8 */

extern CONST(RecSg333_NP, RTE_CONST) Rte_C_RecSg333_NP_0; /* PRQA S 0850 */ /* MD_MSR_19.8 */

extern CONST(RecSg334_NP, RTE_CONST) Rte_C_RecSg334_NP_0; /* PRQA S 0850 */ /* MD_MSR_19.8 */

extern CONST(RecSg336_NP, RTE_CONST) Rte_C_RecSg336_NP_0; /* PRQA S 0850 */ /* MD_MSR_19.8 */

extern CONST(RecSg340_NP, RTE_CONST) Rte_C_RecSg340_NP_0; /* PRQA S 0850 */ /* MD_MSR_19.8 */

extern CONST(RecSg34B_NP, RTE_CONST) Rte_C_RecSg34B_NP_0; /* PRQA S 0850 */ /* MD_MSR_19.8 */

extern CONST(RecSg35C_NP, RTE_CONST) Rte_C_RecSg35C_NP_0; /* PRQA S 0850 */ /* MD_MSR_19.8 */

extern CONST(RecSg35D_NP, RTE_CONST) Rte_C_RecSg35D_NP_0; /* PRQA S 0850 */ /* MD_MSR_19.8 */

extern CONST(RecSg361_NP, RTE_CONST) Rte_C_RecSg361_NP_0; /* PRQA S 0850 */ /* MD_MSR_19.8 */

extern CONST(RecSg362_NP, RTE_CONST) Rte_C_RecSg362_NP_0; /* PRQA S 0850 */ /* MD_MSR_19.8 */

extern CONST(RecSg363_NP, RTE_CONST) Rte_C_RecSg363_NP_0; /* PRQA S 0850 */ /* MD_MSR_19.8 */

extern CONST(RecSg366_NP, RTE_CONST) Rte_C_RecSg366_NP_0; /* PRQA S 0850 */ /* MD_MSR_19.8 */

extern CONST(RecSg36A_NP, RTE_CONST) Rte_C_RecSg36A_NP_0; /* PRQA S 0850 */ /* MD_MSR_19.8 */

extern CONST(RecSg390_NP, RTE_CONST) Rte_C_RecSg390_NP_0; /* PRQA S 0850 */ /* MD_MSR_19.8 */

extern CONST(RecSg393_NP, RTE_CONST) Rte_C_RecSg393_NP_0; /* PRQA S 0850 */ /* MD_MSR_19.8 */

extern CONST(RecSg394_NP, RTE_CONST) Rte_C_RecSg394_NP_0; /* PRQA S 0850 */ /* MD_MSR_19.8 */

extern CONST(RecSg39E_NP, RTE_CONST) Rte_C_RecSg39E_NP_0; /* PRQA S 0850 */ /* MD_MSR_19.8 */

extern CONST(RecSg39F_NP, RTE_CONST) Rte_C_RecSg39F_NP_0; /* PRQA S 0850 */ /* MD_MSR_19.8 */

extern CONST(RecSg3A9_NP, RTE_CONST) Rte_C_RecSg3A9_NP_0; /* PRQA S 0850 */ /* MD_MSR_19.8 */

extern CONST(RecSg3AE_NP, RTE_CONST) Rte_C_RecSg3AE_NP_0; /* PRQA S 0850 */ /* MD_MSR_19.8 */

extern CONST(RecSg3AF_NP, RTE_CONST) Rte_C_RecSg3AF_NP_0; /* PRQA S 0850 */ /* MD_MSR_19.8 */

extern CONST(RecSg3B8_NP, RTE_CONST) Rte_C_RecSg3B8_NP_0; /* PRQA S 0850 */ /* MD_MSR_19.8 */

extern CONST(RecSg3B9_NP, RTE_CONST) Rte_C_RecSg3B9_NP_0; /* PRQA S 0850 */ /* MD_MSR_19.8 */

extern CONST(RecSg3BB_NP, RTE_CONST) Rte_C_RecSg3BB_NP_0; /* PRQA S 0850 */ /* MD_MSR_19.8 */

extern CONST(RecSg3BC_NP, RTE_CONST) Rte_C_RecSg3BC_NP_0; /* PRQA S 0850 */ /* MD_MSR_19.8 */

extern CONST(RecSg3BD_NP, RTE_CONST) Rte_C_RecSg3BD_NP_0; /* PRQA S 0850 */ /* MD_MSR_19.8 */

extern CONST(RecSg3C2_NP, RTE_CONST) Rte_C_RecSg3C2_NP_0; /* PRQA S 0850 */ /* MD_MSR_19.8 */

extern CONST(RecSg3C4_NP, RTE_CONST) Rte_C_RecSg3C4_NP_0; /* PRQA S 0850 */ /* MD_MSR_19.8 */

extern CONST(RecSg3C6_NP, RTE_CONST) Rte_C_RecSg3C6_NP_0; /* PRQA S 0850 */ /* MD_MSR_19.8 */

extern CONST(RecSg3CF_NP, RTE_CONST) Rte_C_RecSg3CF_NP_0; /* PRQA S 0850 */ /* MD_MSR_19.8 */

extern CONST(RecSg3DF_NP, RTE_CONST) Rte_C_RecSg3DF_NP_0; /* PRQA S 0850 */ /* MD_MSR_19.8 */

extern CONST(RecSg3FF_NP, RTE_CONST) Rte_C_RecSg3FF_NP_0; /* PRQA S 0850 */ /* MD_MSR_19.8 */

extern CONST(RecSg40A_NP, RTE_CONST) Rte_C_RecSg40A_NP_0; /* PRQA S 0850 */ /* MD_MSR_19.8 */

extern CONST(RecSg417_NP, RTE_CONST) Rte_C_RecSg417_NP_0; /* PRQA S 0850 */ /* MD_MSR_19.8 */

extern CONST(RecSg418_NP, RTE_CONST) Rte_C_RecSg418_NP_0; /* PRQA S 0850 */ /* MD_MSR_19.8 */

extern CONST(RecSg41B_NP, RTE_CONST) Rte_C_RecSg41B_NP_0; /* PRQA S 0850 */ /* MD_MSR_19.8 */

extern CONST(RecSg41E_NP, RTE_CONST) Rte_C_RecSg41E_NP_0; /* PRQA S 0850 */ /* MD_MSR_19.8 */

extern CONST(RecSg420_NP, RTE_CONST) Rte_C_RecSg420_NP_0; /* PRQA S 0850 */ /* MD_MSR_19.8 */

extern CONST(RecSg438_NP, RTE_CONST) Rte_C_RecSg438_NP_0; /* PRQA S 0850 */ /* MD_MSR_19.8 */

extern CONST(RecSg46C_NP, RTE_CONST) Rte_C_RecSg46C_NP_0; /* PRQA S 0850 */ /* MD_MSR_19.8 */

extern CONST(RecSg46E_NP, RTE_CONST) Rte_C_RecSg46E_NP_0; /* PRQA S 0850 */ /* MD_MSR_19.8 */

extern CONST(RecSg470_NP, RTE_CONST) Rte_C_RecSg470_NP_0; /* PRQA S 0850 */ /* MD_MSR_19.8 */

extern CONST(RecSg471_NP, RTE_CONST) Rte_C_RecSg471_NP_0; /* PRQA S 0850 */ /* MD_MSR_19.8 */

extern CONST(RecSg472_NP, RTE_CONST) Rte_C_RecSg472_NP_0; /* PRQA S 0850 */ /* MD_MSR_19.8 */

extern CONST(RecSg473_NP, RTE_CONST) Rte_C_RecSg473_NP_0; /* PRQA S 0850 */ /* MD_MSR_19.8 */

extern CONST(RecSg474_NP, RTE_CONST) Rte_C_RecSg474_NP_0; /* PRQA S 0850 */ /* MD_MSR_19.8 */

extern CONST(RecSg475_NP, RTE_CONST) Rte_C_RecSg475_NP_0; /* PRQA S 0850 */ /* MD_MSR_19.8 */

extern CONST(RecSg476_NP, RTE_CONST) Rte_C_RecSg476_NP_0; /* PRQA S 0850 */ /* MD_MSR_19.8 */

extern CONST(RecSg477_NP, RTE_CONST) Rte_C_RecSg477_NP_0; /* PRQA S 0850 */ /* MD_MSR_19.8 */

extern CONST(RecSg478_NP, RTE_CONST) Rte_C_RecSg478_NP_0; /* PRQA S 0850 */ /* MD_MSR_19.8 */

extern CONST(RecSg479_NP, RTE_CONST) Rte_C_RecSg479_NP_0; /* PRQA S 0850 */ /* MD_MSR_19.8 */

extern CONST(RecSg47C_NP, RTE_CONST) Rte_C_RecSg47C_NP_0; /* PRQA S 0850 */ /* MD_MSR_19.8 */

extern CONST(RecSg47D_NP, RTE_CONST) Rte_C_RecSg47D_NP_0; /* PRQA S 0850 */ /* MD_MSR_19.8 */

extern CONST(RecSg47F_NP, RTE_CONST) Rte_C_RecSg47F_NP_0; /* PRQA S 0850 */ /* MD_MSR_19.8 */

extern CONST(RecSg4C3_NP, RTE_CONST) Rte_C_RecSg4C3_NP_0; /* PRQA S 0850 */ /* MD_MSR_19.8 */

extern CONST(RecSg4FC_NP, RTE_CONST) Rte_C_RecSg4FC_NP_0; /* PRQA S 0850 */ /* MD_MSR_19.8 */

extern CONST(RecSg517_NP, RTE_CONST) Rte_C_RecSg517_NP_0; /* PRQA S 0850 */ /* MD_MSR_19.8 */

extern CONST(RecSg522_NP, RTE_CONST) Rte_C_RecSg522_NP_0; /* PRQA S 0850 */ /* MD_MSR_19.8 */

extern CONST(RecSg52B_NP, RTE_CONST) Rte_C_RecSg52B_NP_0; /* PRQA S 0850 */ /* MD_MSR_19.8 */

extern CONST(RecSg52C_NP, RTE_CONST) Rte_C_RecSg52C_NP_0; /* PRQA S 0850 */ /* MD_MSR_19.8 */

extern CONST(RecSg52D_NP, RTE_CONST) Rte_C_RecSg52D_NP_0; /* PRQA S 0850 */ /* MD_MSR_19.8 */

extern CONST(RecSg52E_NP, RTE_CONST) Rte_C_RecSg52E_NP_0; /* PRQA S 0850 */ /* MD_MSR_19.8 */

extern CONST(RecSg538_NP, RTE_CONST) Rte_C_RecSg538_NP_0; /* PRQA S 0850 */ /* MD_MSR_19.8 */

extern CONST(RecSg57B_NP, RTE_CONST) Rte_C_RecSg57B_NP_0; /* PRQA S 0850 */ /* MD_MSR_19.8 */

extern CONST(RecSg57C_NP, RTE_CONST) Rte_C_RecSg57C_NP_0; /* PRQA S 0850 */ /* MD_MSR_19.8 */

extern CONST(RecSg57D_NP, RTE_CONST) Rte_C_RecSg57D_NP_0; /* PRQA S 0850 */ /* MD_MSR_19.8 */

extern CONST(RecSg57E_NP, RTE_CONST) Rte_C_RecSg57E_NP_0; /* PRQA S 0850 */ /* MD_MSR_19.8 */

extern CONST(RecSg5AB_NP, RTE_CONST) Rte_C_RecSg5AB_NP_0; /* PRQA S 0850 */ /* MD_MSR_19.8 */

extern CONST(RecSg5AC_NP, RTE_CONST) Rte_C_RecSg5AC_NP_0; /* PRQA S 0850 */ /* MD_MSR_19.8 */

extern CONST(RecSg5AD_NP, RTE_CONST) Rte_C_RecSg5AD_NP_0; /* PRQA S 0850 */ /* MD_MSR_19.8 */

extern CONST(RecSg5AE_NP, RTE_CONST) Rte_C_RecSg5AE_NP_0; /* PRQA S 0850 */ /* MD_MSR_19.8 */

extern CONST(RecSg5C7_NP, RTE_CONST) Rte_C_RecSg5C7_NP_0; /* PRQA S 0850 */ /* MD_MSR_19.8 */

extern CONST(RecSg5D3_NP, RTE_CONST) Rte_C_RecSg5D3_NP_0; /* PRQA S 0850 */ /* MD_MSR_19.8 */

extern CONST(RecSg5EC_NP, RTE_CONST) Rte_C_RecSg5EC_NP_0; /* PRQA S 0850 */ /* MD_MSR_19.8 */

extern CONST(RecSg5FA_NP, RTE_CONST) Rte_C_RecSg5FA_NP_0; /* PRQA S 0850 */ /* MD_MSR_19.8 */

extern CONST(RecSg60D_NP, RTE_CONST) Rte_C_RecSg60D_NP_0; /* PRQA S 0850 */ /* MD_MSR_19.8 */

extern CONST(RecSg611_NP, RTE_CONST) Rte_C_RecSg611_NP_0; /* PRQA S 0850 */ /* MD_MSR_19.8 */

extern CONST(RecSg623_NP, RTE_CONST) Rte_C_RecSg623_NP_0; /* PRQA S 0850 */ /* MD_MSR_19.8 */

extern CONST(RecSg643_NP, RTE_CONST) Rte_C_RecSg643_NP_0; /* PRQA S 0850 */ /* MD_MSR_19.8 */

extern CONST(RecSg6CB_NP, RTE_CONST) Rte_C_RecSg6CB_NP_0; /* PRQA S 0850 */ /* MD_MSR_19.8 */

extern CONST(RecSg6FF_SP_NP, RTE_CONST) Rte_C_RecSg6FF_SP_NP_0; /* PRQA S 0850 */ /* MD_MSR_19.8 */

# define RTE_STOP_SEC_CONST_UNSPECIFIED
//# include "MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */
//# include "Rte_DataHandleType.h"

# ifdef RTE_MICROSAR_PIM_EXPORT


/**********************************************************************************************************************
 * Calibration component and SW-C local calibration parameters
 *********************************************************************************************************************/

#  define RTE_START_SEC_CONST_DEFAULT_RTE_CDATA_GROUP_UNSPECIFIED
//#  include "MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */

extern CONST(uint32_NP, RTE_CONST_DEFAULT_RTE_CDATA_GROUP) Rte_EEIF_CalibTTMDisTotal; /* PRQA S 0850 */ /* MD_MSR_19.8 */
extern CONST(float32_NP, RTE_CONST_DEFAULT_RTE_CDATA_GROUP) Rte_EEIF_CalibSWAOffset; /* PRQA S 0850 */ /* MD_MSR_19.8 */
extern CONST(uint16_NP, RTE_CONST_DEFAULT_RTE_CDATA_GROUP) Rte_EEIF_CalibAplOnOffStatus; /* PRQA S 0850 */ /* MD_MSR_19.8 */
extern CONST(uint16, RTE_CONST_DEFAULT_RTE_CDATA_GROUP) Rte_EEIF_CalibEepromInfo; /* PRQA S 0850 */ /* MD_MSR_19.8 */
extern CONST(uint16_NP, RTE_CONST_DEFAULT_RTE_CDATA_GROUP) Rte_EEIF_CalibGsensorOffset; /* PRQA S 0850 */ /* MD_MSR_19.8 */
extern CONST(uint16, RTE_CONST_DEFAULT_RTE_CDATA_GROUP) Rte_EEIF_CalibSlopeForEAP; /* PRQA S 0850 */ /* MD_MSR_19.8 */
extern CONST(uint8_NP, RTE_CONST_DEFAULT_RTE_CDATA_GROUP) Rte_EEIF_CalibAplSettingStatus; /* PRQA S 0850 */ /* MD_MSR_19.8 */
extern CONST(uint8, RTE_CONST_DEFAULT_RTE_CDATA_GROUP) Rte_EEIF_CalibSigmaNoV; /* PRQA S 0850 */ /* MD_MSR_19.8 */
extern CONST(uint8, RTE_CONST_DEFAULT_RTE_CDATA_GROUP) Rte_EEIF_CalibSigmaVSsdFrameIndex; /* PRQA S 0850 */ /* MD_MSR_19.8 */
extern CONST(uint8, RTE_CONST_DEFAULT_RTE_CDATA_GROUP) Rte_EEIF_CalibSigmaVTddFrameIndex; /* PRQA S 0850 */ /* MD_MSR_19.8 */
extern CONST(uint8_NP, RTE_CONST_DEFAULT_RTE_CDATA_GROUP) Rte_EEIF_CalibTTMIGNTimes; /* PRQA S 0850 */ /* MD_MSR_19.8 */
extern CONST(uint8_NP, RTE_CONST_DEFAULT_RTE_CDATA_GROUP) Rte_EEIF_CalibVariantCode; /* PRQA S 0850 */ /* MD_MSR_19.8 */
extern CONST(rt_Array_UInt8_11, RTE_CONST_DEFAULT_RTE_CDATA_GROUP) Rte_EEIF_CalibEAPCancelReason; /* PRQA S 0850 */ /* MD_MSR_19.8 */
extern CONST(rt_Array_UInt8_300, RTE_CONST_DEFAULT_RTE_CDATA_GROUP) Rte_EEIF_CalibEAPExecution; /* PRQA S 0850 */ /* MD_MSR_19.8 */
extern CONST(rt_Array_UInt8_11, RTE_CONST_DEFAULT_RTE_CDATA_GROUP) Rte_EEIF_CalibFEBCancelReason; /* PRQA S 0850 */ /* MD_MSR_19.8 */
extern CONST(rt_Array_UInt8_320, RTE_CONST_DEFAULT_RTE_CDATA_GROUP) Rte_EEIF_CalibFEBExecution; /* PRQA S 0850 */ /* MD_MSR_19.8 */
extern CONST(rt_Array_UInt8_11, RTE_CONST_DEFAULT_RTE_CDATA_GROUP) Rte_EEIF_CalibLDPCancelReason; /* PRQA S 0850 */ /* MD_MSR_19.8 */
extern CONST(rt_Array_UInt8_276, RTE_CONST_DEFAULT_RTE_CDATA_GROUP) Rte_EEIF_CalibSectorDataBlock0; /* PRQA S 0850 */ /* MD_MSR_19.8 */
extern CONST(rt_Array_UInt8_48, RTE_CONST_DEFAULT_RTE_CDATA_GROUP) Rte_EEIF_CalibSectorDataBlock1_5; /* PRQA S 0850 */ /* MD_MSR_19.8 */
extern CONST(UDSCP_SigmaVSsdType, RTE_CONST_DEFAULT_RTE_CDATA_GROUP) Rte_EEIF_CalibSigmaVSsd; /* PRQA S 0850 */ /* MD_MSR_19.8 */
extern CONST(UDSCP_SigmaVTddType, RTE_CONST_DEFAULT_RTE_CDATA_GROUP) Rte_EEIF_CalibSigmaVTdd; /* PRQA S 0850 */ /* MD_MSR_19.8 */
extern CONST(rt_Array_UInt8_5, RTE_CONST_DEFAULT_RTE_CDATA_GROUP) Rte_EEIF_CalibSonarDectInfo; /* PRQA S 0850 */ /* MD_MSR_19.8 */
extern CONST(rt_Array_UInt8_6, RTE_CONST_DEFAULT_RTE_CDATA_GROUP) Rte_EEIF_CalibTrqDiff; /* PRQA S 0850 */ /* MD_MSR_19.8 */
extern CONST(UDSCP_VinType, RTE_CONST_DEFAULT_RTE_CDATA_GROUP) Rte_EEIF_Vin_DefaultValue; /* PRQA S 0850 */ /* MD_MSR_19.8 */

#  define RTE_STOP_SEC_CONST_DEFAULT_RTE_CDATA_GROUP_UNSPECIFIED
//#  include "MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */

/**********************************************************************************************************************
 * Rte_Pim (Per-Instance Memory)
 *********************************************************************************************************************/

#  define RTE_START_SEC_VAR_DEFAULT_RTE_PIM_GROUP_UNSPECIFIED
//#  include "MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */

extern VAR(uint32_NP, RTE_VAR_DEFAULT_RTE_PIM_GROUP) Rte_EEIF_PimTTMDisTotal; /* PRQA S 0850 */ /* MD_MSR_19.8 */
extern VAR(float32_NP, RTE_VAR_DEFAULT_RTE_PIM_GROUP) Rte_EEIF_PimSWAOffset; /* PRQA S 0850 */ /* MD_MSR_19.8 */
extern VAR(uint16_NP, RTE_VAR_DEFAULT_RTE_PIM_GROUP) Rte_EEIF_PimAplOnOffStatus; /* PRQA S 0850 */ /* MD_MSR_19.8 */
extern VAR(uint16, RTE_VAR_DEFAULT_RTE_PIM_GROUP) Rte_EEIF_PimEepromInfo; /* PRQA S 0850 */ /* MD_MSR_19.8 */
extern VAR(uint16_NP, RTE_VAR_DEFAULT_RTE_PIM_GROUP) Rte_EEIF_PimGsensorOffset; /* PRQA S 0850 */ /* MD_MSR_19.8 */
extern VAR(uint16, RTE_VAR_DEFAULT_RTE_PIM_GROUP) Rte_EEIF_PimSlopeForEAP; /* PRQA S 0850 */ /* MD_MSR_19.8 */
extern VAR(uint8_NP, RTE_VAR_DEFAULT_RTE_PIM_GROUP) Rte_EEIF_PimAplSettingStatus; /* PRQA S 0850 */ /* MD_MSR_19.8 */
extern VAR(uint8, RTE_VAR_DEFAULT_RTE_PIM_GROUP) Rte_EEIF_PimSigmaNoV; /* PRQA S 0850 */ /* MD_MSR_19.8 */
extern VAR(uint8, RTE_VAR_DEFAULT_RTE_PIM_GROUP) Rte_EEIF_PimSigmaVSsdFrameIndex; /* PRQA S 0850 */ /* MD_MSR_19.8 */
extern VAR(uint8, RTE_VAR_DEFAULT_RTE_PIM_GROUP) Rte_EEIF_PimSigmaVTddFrameIndex; /* PRQA S 0850 */ /* MD_MSR_19.8 */
extern VAR(uint8_NP, RTE_VAR_DEFAULT_RTE_PIM_GROUP) Rte_EEIF_PimTTMIGNTimes; /* PRQA S 0850 */ /* MD_MSR_19.8 */
extern VAR(uint8_NP, RTE_VAR_DEFAULT_RTE_PIM_GROUP) Rte_EEIF_PimVariantCode; /* PRQA S 0850 */ /* MD_MSR_19.8 */
extern VAR(rt_Array_UInt8_11, RTE_VAR_DEFAULT_RTE_PIM_GROUP) Rte_EEIF_PimEAPCancelReason; /* PRQA S 0850 */ /* MD_MSR_19.8 */
extern VAR(rt_Array_UInt8_300, RTE_VAR_DEFAULT_RTE_PIM_GROUP) Rte_EEIF_PimEAPExecution; /* PRQA S 0850 */ /* MD_MSR_19.8 */
extern VAR(rt_Array_UInt8_11, RTE_VAR_DEFAULT_RTE_PIM_GROUP) Rte_EEIF_PimFEBCancelReason; /* PRQA S 0850 */ /* MD_MSR_19.8 */
extern VAR(rt_Array_UInt8_320, RTE_VAR_DEFAULT_RTE_PIM_GROUP) Rte_EEIF_PimFEBExecution; /* PRQA S 0850 */ /* MD_MSR_19.8 */
extern VAR(rt_Array_UInt8_11, RTE_VAR_DEFAULT_RTE_PIM_GROUP) Rte_EEIF_PimLDPCancelReason; /* PRQA S 0850 */ /* MD_MSR_19.8 */
extern VAR(rt_Array_UInt8_276, RTE_VAR_DEFAULT_RTE_PIM_GROUP) Rte_EEIF_PimSector1DataBlock0; /* PRQA S 0850 */ /* MD_MSR_19.8 */
extern VAR(rt_Array_UInt8_48, RTE_VAR_DEFAULT_RTE_PIM_GROUP) Rte_EEIF_PimSector1DataBlock1; /* PRQA S 0850 */ /* MD_MSR_19.8 */
extern VAR(rt_Array_UInt8_48, RTE_VAR_DEFAULT_RTE_PIM_GROUP) Rte_EEIF_PimSector1DataBlock2; /* PRQA S 0850 */ /* MD_MSR_19.8 */
extern VAR(rt_Array_UInt8_48, RTE_VAR_DEFAULT_RTE_PIM_GROUP) Rte_EEIF_PimSector1DataBlock3; /* PRQA S 0850 */ /* MD_MSR_19.8 */
extern VAR(rt_Array_UInt8_48, RTE_VAR_DEFAULT_RTE_PIM_GROUP) Rte_EEIF_PimSector1DataBlock4; /* PRQA S 0850 */ /* MD_MSR_19.8 */
extern VAR(rt_Array_UInt8_48, RTE_VAR_DEFAULT_RTE_PIM_GROUP) Rte_EEIF_PimSector1DataBlock5; /* PRQA S 0850 */ /* MD_MSR_19.8 */
extern VAR(rt_Array_UInt8_276, RTE_VAR_DEFAULT_RTE_PIM_GROUP) Rte_EEIF_PimSector2DataBlock0; /* PRQA S 0850 */ /* MD_MSR_19.8 */
extern VAR(rt_Array_UInt8_48, RTE_VAR_DEFAULT_RTE_PIM_GROUP) Rte_EEIF_PimSector2DataBlock1; /* PRQA S 0850 */ /* MD_MSR_19.8 */
extern VAR(rt_Array_UInt8_48, RTE_VAR_DEFAULT_RTE_PIM_GROUP) Rte_EEIF_PimSector2DataBlock2; /* PRQA S 0850 */ /* MD_MSR_19.8 */
extern VAR(rt_Array_UInt8_48, RTE_VAR_DEFAULT_RTE_PIM_GROUP) Rte_EEIF_PimSector2DataBlock3; /* PRQA S 0850 */ /* MD_MSR_19.8 */
extern VAR(rt_Array_UInt8_48, RTE_VAR_DEFAULT_RTE_PIM_GROUP) Rte_EEIF_PimSector2DataBlock4; /* PRQA S 0850 */ /* MD_MSR_19.8 */
extern VAR(rt_Array_UInt8_48, RTE_VAR_DEFAULT_RTE_PIM_GROUP) Rte_EEIF_PimSector2DataBlock5; /* PRQA S 0850 */ /* MD_MSR_19.8 */
extern VAR(rt_Array_UInt8_276, RTE_VAR_DEFAULT_RTE_PIM_GROUP) Rte_EEIF_PimSector3DataBlock0; /* PRQA S 0850 */ /* MD_MSR_19.8 */
extern VAR(rt_Array_UInt8_48, RTE_VAR_DEFAULT_RTE_PIM_GROUP) Rte_EEIF_PimSector3DataBlock1; /* PRQA S 0850 */ /* MD_MSR_19.8 */
extern VAR(rt_Array_UInt8_48, RTE_VAR_DEFAULT_RTE_PIM_GROUP) Rte_EEIF_PimSector3DataBlock2; /* PRQA S 0850 */ /* MD_MSR_19.8 */
extern VAR(rt_Array_UInt8_48, RTE_VAR_DEFAULT_RTE_PIM_GROUP) Rte_EEIF_PimSector3DataBlock3; /* PRQA S 0850 */ /* MD_MSR_19.8 */
extern VAR(rt_Array_UInt8_48, RTE_VAR_DEFAULT_RTE_PIM_GROUP) Rte_EEIF_PimSector3DataBlock4; /* PRQA S 0850 */ /* MD_MSR_19.8 */
extern VAR(rt_Array_UInt8_48, RTE_VAR_DEFAULT_RTE_PIM_GROUP) Rte_EEIF_PimSector3DataBlock5; /* PRQA S 0850 */ /* MD_MSR_19.8 */
extern VAR(UDSCP_SigmaVSsdType, RTE_VAR_DEFAULT_RTE_PIM_GROUP) Rte_EEIF_PimSigmaVSsd0; /* PRQA S 0850 */ /* MD_MSR_19.8 */
extern VAR(UDSCP_SigmaVSsdType, RTE_VAR_DEFAULT_RTE_PIM_GROUP) Rte_EEIF_PimSigmaVSsd1; /* PRQA S 0850 */ /* MD_MSR_19.8 */
extern VAR(UDSCP_SigmaVSsdType, RTE_VAR_DEFAULT_RTE_PIM_GROUP) Rte_EEIF_PimSigmaVSsd2; /* PRQA S 0850 */ /* MD_MSR_19.8 */
extern VAR(UDSCP_SigmaVSsdType, RTE_VAR_DEFAULT_RTE_PIM_GROUP) Rte_EEIF_PimSigmaVSsd3; /* PRQA S 0850 */ /* MD_MSR_19.8 */
extern VAR(UDSCP_SigmaVSsdType, RTE_VAR_DEFAULT_RTE_PIM_GROUP) Rte_EEIF_PimSigmaVSsd4; /* PRQA S 0850 */ /* MD_MSR_19.8 */
extern VAR(UDSCP_SigmaVTddType, RTE_VAR_DEFAULT_RTE_PIM_GROUP) Rte_EEIF_PimSigmaVTdd0; /* PRQA S 0850 */ /* MD_MSR_19.8 */
extern VAR(UDSCP_SigmaVTddType, RTE_VAR_DEFAULT_RTE_PIM_GROUP) Rte_EEIF_PimSigmaVTdd1; /* PRQA S 0850 */ /* MD_MSR_19.8 */
extern VAR(UDSCP_SigmaVTddType, RTE_VAR_DEFAULT_RTE_PIM_GROUP) Rte_EEIF_PimSigmaVTdd2; /* PRQA S 0850 */ /* MD_MSR_19.8 */
extern VAR(UDSCP_SigmaVTddType, RTE_VAR_DEFAULT_RTE_PIM_GROUP) Rte_EEIF_PimSigmaVTdd3; /* PRQA S 0850 */ /* MD_MSR_19.8 */
extern VAR(UDSCP_SigmaVTddType, RTE_VAR_DEFAULT_RTE_PIM_GROUP) Rte_EEIF_PimSigmaVTdd4; /* PRQA S 0850 */ /* MD_MSR_19.8 */
extern VAR(rt_Array_UInt8_5, RTE_VAR_DEFAULT_RTE_PIM_GROUP) Rte_EEIF_PimSonarDectInfo; /* PRQA S 0850 */ /* MD_MSR_19.8 */
extern VAR(rt_Array_UInt8_6, RTE_VAR_DEFAULT_RTE_PIM_GROUP) Rte_EEIF_PimTrqDiff; /* PRQA S 0850 */ /* MD_MSR_19.8 */
extern VAR(UDSCP_VinType, RTE_VAR_DEFAULT_RTE_PIM_GROUP) Rte_EEIF_PimVin; /* PRQA S 0850 */ /* MD_MSR_19.8 */

#  define RTE_STOP_SEC_VAR_DEFAULT_RTE_PIM_GROUP_UNSPECIFIED
//#  include "MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */


# endif

/**********************************************************************************************************************
 *  LOCAL DATA TYPES AND STRUCTURES
 *********************************************************************************************************************/

typedef unsigned int Rte_BitType;
/**********************************************************************************************************************
 * type and extern declarations of RTE internal variables
 *********************************************************************************************************************/

/**********************************************************************************************************************
 * Rte Init State Variable
 *********************************************************************************************************************/

# define RTE_STATE_UNINIT    (0U)
# define RTE_STATE_SCHM_INIT (1U)
# define RTE_STATE_INIT      (2U)

# ifdef RTE_CORE

#  define RTE_START_SEC_VAR_NOINIT_UNSPECIFIED
//#  include "MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */

extern P2CONST(SchM_ConfigType, AUTOMATIC, RTE_CONST) Rte_VarCfgPtr;

#  define RTE_STOP_SEC_VAR_NOINIT_UNSPECIFIED
//#  include "MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */


/**********************************************************************************************************************
 * Calibration Parameters (SW-C local and calibration component calibration parameters)
 *********************************************************************************************************************/

#  define RTE_START_SEC_CONST_DEFAULT_RTE_CDATA_GROUP_UNSPECIFIED
//#  include "MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */

extern CONST(uint32_NP, RTE_CONST_DEFAULT_RTE_CDATA_GROUP) Rte_EEIF_CalibTTMDisTotal; /* PRQA S 0850, 3408 */ /* MD_MSR_19.8, MD_Rte_3408 */
extern CONST(float32_NP, RTE_CONST_DEFAULT_RTE_CDATA_GROUP) Rte_EEIF_CalibSWAOffset; /* PRQA S 0850, 3408 */ /* MD_MSR_19.8, MD_Rte_3408 */
extern CONST(uint16_NP, RTE_CONST_DEFAULT_RTE_CDATA_GROUP) Rte_EEIF_CalibAplOnOffStatus; /* PRQA S 0850, 3408 */ /* MD_MSR_19.8, MD_Rte_3408 */
extern CONST(uint16, RTE_CONST_DEFAULT_RTE_CDATA_GROUP) Rte_EEIF_CalibEepromInfo; /* PRQA S 0850, 3408 */ /* MD_MSR_19.8, MD_Rte_3408 */
extern CONST(uint16_NP, RTE_CONST_DEFAULT_RTE_CDATA_GROUP) Rte_EEIF_CalibGsensorOffset; /* PRQA S 0850, 3408 */ /* MD_MSR_19.8, MD_Rte_3408 */
extern CONST(uint16, RTE_CONST_DEFAULT_RTE_CDATA_GROUP) Rte_EEIF_CalibSlopeForEAP; /* PRQA S 0850, 3408 */ /* MD_MSR_19.8, MD_Rte_3408 */
extern CONST(uint8_NP, RTE_CONST_DEFAULT_RTE_CDATA_GROUP) Rte_EEIF_CalibAplSettingStatus; /* PRQA S 0850, 3408 */ /* MD_MSR_19.8, MD_Rte_3408 */
extern CONST(uint8, RTE_CONST_DEFAULT_RTE_CDATA_GROUP) Rte_EEIF_CalibSigmaNoV; /* PRQA S 0850, 3408 */ /* MD_MSR_19.8, MD_Rte_3408 */
extern CONST(uint8, RTE_CONST_DEFAULT_RTE_CDATA_GROUP) Rte_EEIF_CalibSigmaVSsdFrameIndex; /* PRQA S 0850, 3408 */ /* MD_MSR_19.8, MD_Rte_3408 */
extern CONST(uint8, RTE_CONST_DEFAULT_RTE_CDATA_GROUP) Rte_EEIF_CalibSigmaVTddFrameIndex; /* PRQA S 0850, 3408 */ /* MD_MSR_19.8, MD_Rte_3408 */
extern CONST(uint8_NP, RTE_CONST_DEFAULT_RTE_CDATA_GROUP) Rte_EEIF_CalibTTMIGNTimes; /* PRQA S 0850, 3408 */ /* MD_MSR_19.8, MD_Rte_3408 */
extern CONST(uint8_NP, RTE_CONST_DEFAULT_RTE_CDATA_GROUP) Rte_EEIF_CalibVariantCode; /* PRQA S 0850, 3408 */ /* MD_MSR_19.8, MD_Rte_3408 */
extern CONST(rt_Array_UInt8_11, RTE_CONST_DEFAULT_RTE_CDATA_GROUP) Rte_EEIF_CalibEAPCancelReason; /* PRQA S 0850, 3408 */ /* MD_MSR_19.8, MD_Rte_3408 */
extern CONST(rt_Array_UInt8_300, RTE_CONST_DEFAULT_RTE_CDATA_GROUP) Rte_EEIF_CalibEAPExecution; /* PRQA S 0850, 3408 */ /* MD_MSR_19.8, MD_Rte_3408 */
extern CONST(rt_Array_UInt8_11, RTE_CONST_DEFAULT_RTE_CDATA_GROUP) Rte_EEIF_CalibFEBCancelReason; /* PRQA S 0850, 3408 */ /* MD_MSR_19.8, MD_Rte_3408 */
extern CONST(rt_Array_UInt8_320, RTE_CONST_DEFAULT_RTE_CDATA_GROUP) Rte_EEIF_CalibFEBExecution; /* PRQA S 0850, 3408 */ /* MD_MSR_19.8, MD_Rte_3408 */
extern CONST(rt_Array_UInt8_11, RTE_CONST_DEFAULT_RTE_CDATA_GROUP) Rte_EEIF_CalibLDPCancelReason; /* PRQA S 0850, 3408 */ /* MD_MSR_19.8, MD_Rte_3408 */
extern CONST(rt_Array_UInt8_276, RTE_CONST_DEFAULT_RTE_CDATA_GROUP) Rte_EEIF_CalibSectorDataBlock0; /* PRQA S 0850, 3408 */ /* MD_MSR_19.8, MD_Rte_3408 */
extern CONST(rt_Array_UInt8_48, RTE_CONST_DEFAULT_RTE_CDATA_GROUP) Rte_EEIF_CalibSectorDataBlock1_5; /* PRQA S 0850, 3408 */ /* MD_MSR_19.8, MD_Rte_3408 */
extern CONST(UDSCP_SigmaVSsdType, RTE_CONST_DEFAULT_RTE_CDATA_GROUP) Rte_EEIF_CalibSigmaVSsd; /* PRQA S 0850, 3408 */ /* MD_MSR_19.8, MD_Rte_3408 */
extern CONST(UDSCP_SigmaVTddType, RTE_CONST_DEFAULT_RTE_CDATA_GROUP) Rte_EEIF_CalibSigmaVTdd; /* PRQA S 0850, 3408 */ /* MD_MSR_19.8, MD_Rte_3408 */
extern CONST(rt_Array_UInt8_5, RTE_CONST_DEFAULT_RTE_CDATA_GROUP) Rte_EEIF_CalibSonarDectInfo; /* PRQA S 0850, 3408 */ /* MD_MSR_19.8, MD_Rte_3408 */
extern CONST(rt_Array_UInt8_6, RTE_CONST_DEFAULT_RTE_CDATA_GROUP) Rte_EEIF_CalibTrqDiff; /* PRQA S 0850, 3408 */ /* MD_MSR_19.8, MD_Rte_3408 */
extern CONST(UDSCP_VinType, RTE_CONST_DEFAULT_RTE_CDATA_GROUP) Rte_EEIF_Vin_DefaultValue; /* PRQA S 0850, 3408 */ /* MD_MSR_19.8, MD_Rte_3408 */

#  define RTE_STOP_SEC_CONST_DEFAULT_RTE_CDATA_GROUP_UNSPECIFIED
//#  include "MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */

/**********************************************************************************************************************
 * Buffers for unqueued S/R
 *********************************************************************************************************************/

#  define RTE_START_SEC_VAR_INIT_UNSPECIFIED
//#  include "MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */

extern VAR(Boolean, RTE_VAR_INIT) Rte_ActivationManagement_F_x_ACC_MD_CONF_F_x_ACC_MD_CONF; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_ActivationManagement_F_x_ASCDMode_F_x_ASCDMode; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_ActivationManagement_F_x_BSISet_F_x_BSISet; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_ActivationManagement_F_x_BSWSet_F_x_BSWSet; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_ActivationManagement_F_x_CTASet_F_x_CTASet; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_ActivationManagement_F_x_ControlLatActivation_F_x_ControlLatActivation; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_ActivationManagement_F_x_ControlLongiActivation_F_x_ControlLongiActivation; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_ActivationManagement_F_x_DaaSet_F_x_DaaSet; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_ActivationManagement_F_x_FebSet_F_x_FebSet; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_ActivationManagement_F_x_HW_fix_F_x_HW_fix; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_ActivationManagement_F_x_LDPSet_F_x_LDPSet; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_ActivationManagement_F_x_LDWSet_F_x_LDWSet; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(boolean_NP, RTE_VAR_INIT) Rte_ActivationManagement_F_x_LKASWpushed_F_x_LKASWpushed; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_ActivationManagement_F_x_LKASet_F_x_LKASet; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(boolean_NP, RTE_VAR_INIT) Rte_ActivationManagement_F_x_RAEBSet_F_x_RAEBSet; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_ActivationManagement_F_x_SetAccCruiseEcoEeprom_F_x_SetAccCruiseEcoEeprom; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_ActivationManagement_F_x_SetBSIActEeprom_F_x_SetBSIActEeprom; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_ActivationManagement_F_x_SetBSWActEeprom_F_x_SetBSWActEeprom; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_ActivationManagement_F_x_SetCTAActEeprom_F_x_SetCTAActEeprom; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_ActivationManagement_F_x_SetDaaActEeprom_F_x_SetDaaActEeprom; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_ActivationManagement_F_x_SetFEBFCWActEeprom_F_x_SetFEBFCWActEeprom; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_ActivationManagement_F_x_SetLDPActEeprom_F_x_SetLDPActEeprom; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_ActivationManagement_F_x_SetLDWActEeprom_F_x_SetLDWActEeprom; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_ActivationManagement_F_x_SetLKAActEeprom_F_x_SetLKAActEeprom; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_ActivationManagement_V_x_AccCruiseEcoActMain_V_x_AccCruiseEcoActMain; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_ActivationManagement_V_x_BSIActMain_V_x_BSIActMain; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_ActivationManagement_V_x_BSWActMain_V_x_BSWActMain; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_ActivationManagement_V_x_BSWLedStat_V_x_BSWLedStat; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_ActivationManagement_V_x_CTAActMain_V_x_CTAActMain; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_ActivationManagement_V_x_DaaActMain_V_x_DaaActMain; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_ActivationManagement_V_x_EAPActMain_V_x_EAPActMain; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_ActivationManagement_V_x_EcoCustomizeActivation_V_x_EcoCustomizeActivation; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_ActivationManagement_V_x_FebActMain_V_x_FebActMain; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_ActivationManagement_V_x_LDPActMain_V_x_LDPActMain; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_ActivationManagement_V_x_LDWActMain_V_x_LDWActMain; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_ActivationManagement_V_x_MAXVariant_V_x_MAXVariant; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(rt_Array_UInt8_16, RTE_VAR_INIT) Rte_ActivationManagement_V_x_SPECINFO_V_x_SPECINFO; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint16_NP, RTE_VAR_INIT) Rte_AdcHwAb_PV_V_UdsImHwInIGNVOL_PV_V_UdsImHwInIGNVOL; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint16_NP, RTE_VAR_INIT) Rte_AdcHwAb_PV_x_5VReturnAdc0_PV_x_5VReturnAdc0; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint16_NP, RTE_VAR_INIT) Rte_AdcHwAb_PV_x_5VReturnAdc1_PV_x_5VReturnAdc1; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint16_NP, RTE_VAR_INIT) Rte_AdcHwAb_PV_x_AutoInspHwIn5VReturn1_PV_x_AutoInspHwIn5VReturn1; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint16_NP, RTE_VAR_INIT) Rte_AdcHwAb_PV_x_AutoInspHwIn5VReturn2_PV_x_AutoInspHwIn5VReturn2; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint16_NP, RTE_VAR_INIT) Rte_AdcHwAb_PV_x_AutoInspHwInIgnVol_PV_x_AutoInspHwInIgnVol; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint16_NP, RTE_VAR_INIT) Rte_AdcHwAb_PV_x_AutoInspHwInMotorR1_PV_x_AutoInspHwInMotorR1; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint16_NP, RTE_VAR_INIT) Rte_AdcHwAb_PV_x_AutoInspHwInSpeakerR1_PV_x_AutoInspHwInSpeakerR1; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint16_NP, RTE_VAR_INIT) Rte_AdcHwAb_PV_x_AutoInspHwInSpeakerR2_PV_x_AutoInspHwInSpeakerR2; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint16_NP, RTE_VAR_INIT) Rte_AdcHwAb_PV_x_DirectIgn_PV_x_DirectIgn; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint16_NP, RTE_VAR_INIT) Rte_AdcHwAb_PV_x_MotorReturn_PV_x_MotorReturn; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint16_NP, RTE_VAR_INIT) Rte_AdcHwAb_PV_x_PowerICIgn_PV_x_PowerICIgn; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint16_NP, RTE_VAR_INIT) Rte_AdcHwAb_V_V_IGNVOL_V_V_IGNVOL; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(boolean_NP, RTE_VAR_INIT) Rte_BRK_ENG_F_x_ACCBrakeWheelTorqueOrd_F_x_ACCBrakeWheelTorqueOrd; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_BRK_ENG_F_x_ACC_PWTWheelTorqueRequestOrder_NiSW_F_x_ACC_PWTWheelTorqueRequestOrder_NiSW; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_BRK_ENG_F_x_ACC_REQUEST_F_x_ACC_REQUEST; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_BRK_ENG_F_x_ADAS_PWTwheelTorqueOrder_F_x_ADAS_PWTwheelTorqueOrder; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_BRK_ENG_F_x_Accbkact_F_x_Accbkact; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_BRK_ENG_F_x_BlsOn_F_x_BlsOn; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_BRK_ENG_F_x_DriverBrake_F_x_DriverBrake; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_BRK_ENG_F_x_DriverBrake_TJP_F_x_DriverBrake_TJP; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_BRK_ENG_F_x_FcaAct_F_x_FcaAct; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_BRK_ENG_F_x_FcaasRequest_F_x_FcaasRequest; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_BRK_ENG_F_x_ISSINH_F_x_ISSINH; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_BRK_ENG_F_x_PBS2_ACT_MAINBRK_F_x_PBS2_ACT_MAINBRK; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_BRK_ENG_F_x_Pbs2ActMainbrk_F_x_Pbs2ActMainbrk; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt32, RTE_VAR_INIT) Rte_BRK_ENG_V_Mpa_ItsTrgtPrssr_V_Mpa_ItsTrgtPrssr; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt32, RTE_VAR_INIT) Rte_BRK_ENG_V_bar_ACC_BRK_CMD_V_bar_ACC_BRK_CMD; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt32, RTE_VAR_INIT) Rte_BRK_ENG_V_bar_BrkComSel_V_bar_BrkComSel; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt32, RTE_VAR_INIT) Rte_BRK_ENG_V_mpa_vVC_PBRK_COM_ICC_V_mpa_vVC_PBRK_COM_ICC; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(float32_NP, RTE_VAR_INIT) Rte_BRK_ENG_V_nm_PWTWheelTorqueCmd_Request_V_nm_PWTWheelTorqueCmd_Request; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_BRK_ENG_V_nm_TECMD_M_V_nm_TECMD_M; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt32, RTE_VAR_INIT) Rte_BRK_ENG_V_nm_VC_TP_HEV_CMD_V_nm_VC_TP_HEV_CMD; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_BRK_ENG_V_pct_ApoVal_V_pct_ApoVal; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_BRK_ENG_V_x_ACC_StandStillRequest_V_x_ACC_StandStillRequest; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_BRK_ENG_V_x_HighGearInhibitRequest_V_x_HighGearInhibitRequest; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_BSW_F_x_AlertSOWJudgeL_F_x_AlertSOWJudgeL; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_BSW_F_x_AlertSOWJudgeR_F_x_AlertSOWJudgeR; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_BSW_F_x_BSIBuzReq_F_x_BSIBuzReq; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_BSW_F_x_BSICnclBuzReq_F_x_BSICnclBuzReq; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(boolean_NP, RTE_VAR_INIT) Rte_BSW_F_x_BSI_SideDisplayInfo_F_x_BSI_SideDisplayInfo; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(boolean_NP, RTE_VAR_INIT) Rte_BSW_F_x_BSI_StatusInfo_F_x_BSI_StatusInfo; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_BSW_F_x_BSWBuzOut_F_x_BSWBuzOut; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_BSW_F_x_CTABuzOut_F_x_CTABuzOut; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_BSW_F_x_CTAChgReq_F_x_CTAChgReq; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_BSW_F_x_LDPReadyMask_F_x_LDPReadyMask; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_BSW_F_x_LSOUT2dir_SCP_LDP_F_x_LSOUT2dir_SCP_LDP; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_BSW_F_x_SCP_ACTIVE2_F_x_SCP_ACTIVE2; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_BSW_F_x_SCP_ACTIVE3_F_x_SCP_ACTIVE3; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_BSW_F_x_SCP_LSOUT2_F_x_SCP_LSOUT2; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(boolean_NP, RTE_VAR_INIT) Rte_BSW_F_x_VS_LSOWBlockCondiDetected_F_x_VS_LSOWBlockCondiDetected; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(boolean_NP, RTE_VAR_INIT) Rte_BSW_F_x_VS_RSOWBlockCondiDetected_F_x_VS_RSOWBlockCondiDetected; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_BSW_F_x_fBSI_CancelReq_F_x_fBSI_CancelReq; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_BSW_F_x_fBSI_SW_MAIN_OFF_F_x_fBSI_SW_MAIN_OFF; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt32, RTE_VAR_INIT) Rte_BSW_V_Nm_LSMOMBOUND_SCP_V_Nm_LSMOMBOUND_SCP; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt32, RTE_VAR_INIT) Rte_BSW_V_Nm_SCP_mom_ls_V_Nm_SCP_mom_ls; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt32, RTE_VAR_INIT) Rte_BSW_V_Nm_SCP_mom_ls0prepm_V_Nm_SCP_mom_ls0prepm; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt32, RTE_VAR_INIT) Rte_BSW_V_degps_yawrate_SLB_V_degps_yawrate_SLB; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_BSW_V_x_BSICnclReason_V_x_BSICnclReason; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_BSW_V_x_BSI_AlertLeft_v2_V_x_BSI_AlertLeft_v2; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_BSW_V_x_BSI_AlertRight_v2_V_x_BSI_AlertRight_v2; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_BSW_V_x_BSI_CancelInfo_V_x_BSI_CancelInfo; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_BSW_V_x_BSI_CancelReason_V_x_BSI_CancelReason; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_BSW_V_x_BSI_FailureDisplay_V_x_BSI_FailureDisplay; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_BSW_V_x_HMIState_L_V_x_HMIState_L; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_BSW_V_x_HMIState_R_V_x_HMIState_R; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(rt_Array_UInt8_10, RTE_VAR_INIT) Rte_BSW_V_x_vBSI_CancelEepWriteReq_V_x_vBSI_CancelEepWriteReq; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_BSW_V_x_vMSS_CTA_V_x_vMSS_CTA; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_BSW_V_x_vMssBsSCP_V_x_vMssBsSCP; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_BSW_V_x_vMssBsSOW_V_x_vMssBsSOW; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_BSW_V_x_vMssCMNSCP_V_x_vMssCMNSCP; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_BSW_V_x_vSTS_CTA_V_x_vSTS_CTA; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_BSW_V_x_vStsDBs_V_x_vStsDBs; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_BSW_V_x_vStsWBs_V_x_vStsWBs; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CAM_RAD_F_x_AlertWrnIndReqB_F_x_AlertWrnIndReqB; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CAM_RAD_F_x_AlertWrnIndReqC_F_x_AlertWrnIndReqC; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CAM_RAD_F_x_AlertWrnIndReqD_F_x_AlertWrnIndReqD; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CAM_RAD_F_x_AlertWrnIndReqE_F_x_AlertWrnIndReqE; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CAM_RAD_F_x_AlertWrnIndReqF_F_x_AlertWrnIndReqF; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(boolean_NP, RTE_VAR_INIT) Rte_CAM_RAD_F_x_AutoHorOoc_F_x_AutoHorOoc; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(boolean_NP, RTE_VAR_INIT) Rte_CAM_RAD_F_x_AutoYawOoc_F_x_AutoYawOoc; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CAM_RAD_F_x_CAMV_BlindStretchL_F_x_CAMV_BlindStretchL; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CAM_RAD_F_x_CAMV_BlindStretchR_F_x_CAMV_BlindStretchR; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CAM_RAD_F_x_CAMV_ClutterLeft_F_x_CAMV_ClutterLeft; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CAM_RAD_F_x_CAMV_ClutterRight_F_x_CAMV_ClutterRight; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CAM_RAD_F_x_CAMV_NightRain_F_x_CAMV_NightRain; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CAM_RAD_F_x_CAMV_ValidCurvature_F_x_CAMV_ValidCurvature; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CAM_RAD_F_x_CAMV_ValidDistLLan_F_x_CAMV_ValidDistLLan; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CAM_RAD_F_x_CAMV_ValidDistRLane_F_x_CAMV_ValidDistRLane; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CAM_RAD_F_x_CAMV_ValidExposure1_F_x_CAMV_ValidExposure1; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CAM_RAD_F_x_CAMV_ValidExposure2_F_x_CAMV_ValidExposure2; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CAM_RAD_F_x_CAMV_ValidYawAngle_F_x_CAMV_ValidYawAngle; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CAM_RAD_F_x_CAMV_fBRIDGE_DET_F_x_CAMV_fBRIDGE_DET; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CAM_RAD_F_x_CAMV_fCONF_L_LV_L1_F_x_CAMV_fCONF_L_LV_L1; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CAM_RAD_F_x_CAMV_fCONF_L_LV_L2_F_x_CAMV_fCONF_L_LV_L2; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CAM_RAD_F_x_CAMV_fCONF_L_LV_R1_F_x_CAMV_fCONF_L_LV_R1; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CAM_RAD_F_x_CAMV_fCONF_L_LV_R2_F_x_CAMV_fCONF_L_LV_R2; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CAM_RAD_F_x_CAMV_fCURVATURE_L_HL_F_x_CAMV_fCURVATURE_L_HL; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CAM_RAD_F_x_CAMV_fCURVATURE_L_VALID_F_x_CAMV_fCURVATURE_L_VALID; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CAM_RAD_F_x_CAMV_fCURVATURE_R_HL_F_x_CAMV_fCURVATURE_R_HL; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CAM_RAD_F_x_CAMV_fCURVATURE_R_VALID_F_x_CAMV_fCURVATURE_R_VALID; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CAM_RAD_F_x_CAMV_fSuspicious_lane_L_F_x_CAMV_fSuspicious_lane_L; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CAM_RAD_F_x_CAMV_fSuspicious_lane_R_F_x_CAMV_fSuspicious_lane_R; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CAM_RAD_F_x_CAMV_fWARN_INH_L_F_x_CAMV_fWARN_INH_L; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CAM_RAD_F_x_CAMV_fWARN_INH_R_F_x_CAMV_fWARN_INH_R; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CAM_RAD_F_x_CAMV_fWFR_LANE_CHANGE_L_F_x_CAMV_fWFR_LANE_CHANGE_L; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CAM_RAD_F_x_CAMV_fWFR_LANE_CHANGE_R_F_x_CAMV_fWFR_LANE_CHANGE_R; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CAM_RAD_F_x_CAMV_fWFR_SEC_SWITCH_L_F_x_CAMV_fWFR_SEC_SWITCH_L; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CAM_RAD_F_x_CAMV_fWFR_SEC_SWITCH_R_F_x_CAMV_fWFR_SEC_SWITCH_R; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CAM_RAD_F_x_CIPVCam0_F_x_CIPVCam0; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CAM_RAD_F_x_CIPVCam1_F_x_CIPVCam1; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CAM_RAD_F_x_CIPVCam10_F_x_CIPVCam10; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CAM_RAD_F_x_CIPVCam11_F_x_CIPVCam11; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CAM_RAD_F_x_CIPVCam2_F_x_CIPVCam2; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CAM_RAD_F_x_CIPVCam3_F_x_CIPVCam3; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CAM_RAD_F_x_CIPVCam4_F_x_CIPVCam4; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CAM_RAD_F_x_CIPVCam5_F_x_CIPVCam5; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CAM_RAD_F_x_CIPVCam6_F_x_CIPVCam6; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CAM_RAD_F_x_CIPVCam7_F_x_CIPVCam7; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CAM_RAD_F_x_CIPVCam8_F_x_CIPVCam8; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CAM_RAD_F_x_CIPVCam9_F_x_CIPVCam9; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CAM_RAD_F_x_CIPVCamObj0_F_x_CIPVCamObj0; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CAM_RAD_F_x_CIPVCamObj1_F_x_CIPVCamObj1; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CAM_RAD_F_x_CIPVCamObj10_F_x_CIPVCamObj10; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CAM_RAD_F_x_CIPVCamObj11_F_x_CIPVCamObj11; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CAM_RAD_F_x_CIPVCamObj2_F_x_CIPVCamObj2; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CAM_RAD_F_x_CIPVCamObj3_F_x_CIPVCamObj3; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CAM_RAD_F_x_CIPVCamObj4_F_x_CIPVCamObj4; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CAM_RAD_F_x_CIPVCamObj5_F_x_CIPVCamObj5; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CAM_RAD_F_x_CIPVCamObj6_F_x_CIPVCamObj6; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CAM_RAD_F_x_CIPVCamObj7_F_x_CIPVCamObj7; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CAM_RAD_F_x_CIPVCamObj8_F_x_CIPVCamObj8; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CAM_RAD_F_x_CIPVCamObj9_F_x_CIPVCamObj9; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CAM_RAD_F_x_CamInitialised_F_x_CamInitialised; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CAM_RAD_F_x_CameraCalibStatus_F_x_CameraCalibStatus; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CAM_RAD_F_x_CameraHiTempStatus_F_x_CameraHiTempStatus; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(boolean_NP, RTE_VAR_INIT) Rte_CAM_RAD_F_x_CameraSnowOnRoadDetected_F_x_CameraSnowOnRoadDetected; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CAM_RAD_F_x_Confidence_HWE_Left_F_x_Confidence_HWE_Left; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CAM_RAD_F_x_Confidence_HWE_Right_F_x_Confidence_HWE_Right; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(boolean_NP, RTE_VAR_INIT) Rte_CAM_RAD_F_x_FREE_SPACE_OUT_SEL_RIR_F_x_FREE_SPACE_OUT_SEL_RIR; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CAM_RAD_F_x_FcwStop_fStationary_F_x_FcwStop_fStationary; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(boolean_NP, RTE_VAR_INIT) Rte_CAM_RAD_F_x_HighWayExitLeftConfidence_CamRad_F_x_HighWayExitLeftConfidence_CamRad; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(boolean_NP, RTE_VAR_INIT) Rte_CAM_RAD_F_x_HighWayExitRightConfidence_CamRad_F_x_HighWayExitRightConfidence_CamRad; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CAM_RAD_F_x_IbaMove_fObjectChange_F_x_IbaMove_fObjectChange; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CAM_RAD_F_x_IbaMove_fStationary_F_x_IbaMove_fStationary; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CAM_RAD_F_x_IbaStop_fObjectChange_F_x_IbaStop_fObjectChange; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CAM_RAD_F_x_IbaStop_fStationary_F_x_IbaStop_fStationary; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CAM_RAD_F_x_LDWWarningLeft_F_x_LDWWarningLeft; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CAM_RAD_F_x_LDWWarningRight_F_x_LDWWarningRight; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(boolean_NP, RTE_VAR_INIT) Rte_CAM_RAD_F_x_LDW_WarningLeft_CamRad_F_x_LDW_WarningLeft_CamRad; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(boolean_NP, RTE_VAR_INIT) Rte_CAM_RAD_F_x_LDW_WarningRight_CamRad_F_x_LDW_WarningRight_CamRad; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CAM_RAD_F_x_LaneCrosLeft_F_x_LaneCrosLeft; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CAM_RAD_F_x_LaneCrosRight_F_x_LaneCrosRight; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(boolean_NP, RTE_VAR_INIT) Rte_CAM_RAD_F_x_LaneCrossingLeft_CamRad_F_x_LaneCrossingLeft_CamRad; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(boolean_NP, RTE_VAR_INIT) Rte_CAM_RAD_F_x_LaneCrossingRight_CamRad_F_x_LaneCrossingRight_CamRad; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CAM_RAD_F_x_LdwFailure_F_x_LdwFailure; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CAM_RAD_F_x_LeftClsRngCutIn_ACC_F_x_LeftClsRngCutIn_ACC; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(boolean_NP, RTE_VAR_INIT) Rte_CAM_RAD_F_x_LeftTripleLaneMark_Confidence_F_x_LeftTripleLaneMark_Confidence; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(boolean_NP, RTE_VAR_INIT) Rte_CAM_RAD_F_x_ObjectStationary_RIR_F_x_ObjectStationary_RIR; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CAM_RAD_F_x_RAD_RcvMain_Update_F_x_RAD_RcvMain_Update; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CAM_RAD_F_x_RIR_fEnblF1_r_F_x_RIR_fEnblF1_r; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CAM_RAD_F_x_RIR_fEnblF3_r_F_x_RIR_fEnblF3_r; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CAM_RAD_F_x_RIR_fEnblF4_r_F_x_RIR_fEnblF4_r; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CAM_RAD_F_x_RIR_fPermitBrake_F_x_RIR_fPermitBrake; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CAM_RAD_F_x_RIR_fPermitPreBrake_F_x_RIR_fPermitPreBrake; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CAM_RAD_F_x_RIR_fRadarChkInh_F_x_RIR_fRadarChkInh; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CAM_RAD_F_x_RIR_fRdrCanUpdate_F_x_RIR_fRdrCanUpdate; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CAM_RAD_F_x_RIR_fSupF2_r_F_x_RIR_fSupF2_r; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CAM_RAD_F_x_RIR_fSupHGr_r_F_x_RIR_fSupHGr_r; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CAM_RAD_F_x_RIR_fSupHHypo_r_F_x_RIR_fSupHHypo_r; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CAM_RAD_F_x_RIR_fSupHProb_r_F_x_RIR_fSupHProb_r; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CAM_RAD_F_x_RIR_fSupM_r_F_x_RIR_fSupM_r; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CAM_RAD_F_x_RightClsRngCutIn_ACC_F_x_RightClsRngCutIn_ACC; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(boolean_NP, RTE_VAR_INIT) Rte_CAM_RAD_F_x_RightTripleLaneMark_Confidence_F_x_RightTripleLaneMark_Confidence; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(boolean_NP, RTE_VAR_INIT) Rte_CAM_RAD_F_x_Selected20ObjMeasured_F_x_Selected20ObjMeasured; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CAM_RAD_F_x_SetTTMDisTotalTrgEeprom_F_x_SetTTMDisTotalTrgEeprom; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(boolean_NP, RTE_VAR_INIT) Rte_CAM_RAD_F_x_SeverePitchAxMis_F_x_SeverePitchAxMis; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(boolean_NP, RTE_VAR_INIT) Rte_CAM_RAD_F_x_SevereYawAxMis_F_x_SevereYawAxMis; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(boolean_NP, RTE_VAR_INIT) Rte_CAM_RAD_F_x_TSR_VisionSupSignTypeObject00_F_x_TSR_VisionSupSignTypeObject00; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(boolean_NP, RTE_VAR_INIT) Rte_CAM_RAD_F_x_TSR_VisionSupSignTypeObject01_F_x_TSR_VisionSupSignTypeObject01; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(boolean_NP, RTE_VAR_INIT) Rte_CAM_RAD_F_x_Target_RIR_F_x_Target_RIR; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CAM_RAD_F_x_VCLhasCutLnMrkLeft_F_x_VCLhasCutLnMrkLeft; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CAM_RAD_F_x_VCLhasCutLnMrkRight_F_x_VCLhasCutLnMrkRight; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CAM_RAD_F_x_f100ms_F_x_f100ms; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CAM_RAD_F_x_fCIR_TO_EAP_BRAKE_Permit_F_x_fCIR_TO_EAP_BRAKE_Permit; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CAM_RAD_F_x_fCIR_TO_EAP_BRAKE_Permit_2_F_x_fCIR_TO_EAP_BRAKE_Permit_2; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CAM_RAD_F_x_fCIR_TO_EAP_CAR_INFO_F_x_fCIR_TO_EAP_CAR_INFO; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CAM_RAD_F_x_fCamAlwCoBrake_F_x_fCamAlwCoBrake; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CAM_RAD_F_x_fCamAlwCoPreBrake_F_x_fCamAlwCoPreBrake; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CAM_RAD_F_x_fCamBa_F_x_fCamBa; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CAM_RAD_F_x_fCamPed2ndWarn_F_x_fCamPed2ndWarn; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CAM_RAD_F_x_fCamPedBrake_F_x_fCamPedBrake; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CAM_RAD_F_x_fCamPedCrossBrake_F_x_fCamPedCrossBrake; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CAM_RAD_F_x_fCamPedPreBrake_F_x_fCamPedPreBrake; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CAM_RAD_F_x_fCamPedPreFill_F_x_fCamPedPreFill; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CAM_RAD_F_x_fCamPedWarn_F_x_fCamPedWarn; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CAM_RAD_F_x_fCamVehicle2ndWarn_F_x_fCamVehicle2ndWarn; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CAM_RAD_F_x_fCamVehicleBrake_F_x_fCamVehicleBrake; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CAM_RAD_F_x_fCamVehiclePreBrake_F_x_fCamVehiclePreBrake; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CAM_RAD_F_x_fCamVehiclePreFill_F_x_fCamVehiclePreFill; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CAM_RAD_F_x_fCamVehicleWarn_F_x_fCamVehicleWarn; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CAM_RAD_F_x_fNJB_MidSupp_F_x_fNJB_MidSupp; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CAM_RAD_F_x_fOSR_Hypothesis_Brake_F_x_fOSR_Hypothesis_Brake; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CAM_RAD_F_x_fOSR_NJB_HiSuppGR_F_x_fOSR_NJB_HiSuppGR; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CAM_RAD_F_x_fOSR_NJB_HiSuppPROB_F_x_fOSR_NJB_HiSuppPROB; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CAM_RAD_F_x_fOSR_NJB_MidSuppression_F_x_fOSR_NJB_MidSuppression; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CAM_RAD_F_x_fOSR_Relevant_Obj_F_x_fOSR_Relevant_Obj; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CAM_RAD_F_x_fObjChange_F_x_fObjChange; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CAM_RAD_F_x_fRelevant_Obj_GR_F_x_fRelevant_Obj_GR; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_dB_RCSObj1_V_dB_RCSObj1; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt8, RTE_VAR_INIT) Rte_CAM_RAD_V_dB_RCSObj2_V_dB_RCSObj2; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_dB_RCSObj3_V_dB_RCSObj3; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_deg_AngleCamObj0_V_deg_AngleCamObj0; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_deg_AngleCamObj1_V_deg_AngleCamObj1; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_deg_AngleCamObj10_V_deg_AngleCamObj10; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_deg_AngleCamObj11_V_deg_AngleCamObj11; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_deg_AngleCamObj2_V_deg_AngleCamObj2; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_deg_AngleCamObj3_V_deg_AngleCamObj3; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_deg_AngleCamObj4_V_deg_AngleCamObj4; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_deg_AngleCamObj5_V_deg_AngleCamObj5; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_deg_AngleCamObj6_V_deg_AngleCamObj6; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_deg_AngleCamObj7_V_deg_AngleCamObj7; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_deg_AngleCamObj8_V_deg_AngleCamObj8; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_deg_AngleCamObj9_V_deg_AngleCamObj9; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_deg_CAMV_YawAngle_V_deg_CAMV_YawAngle; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_deg_CAMV_YawAngleL_V_deg_CAMV_YawAngleL; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_deg_CAMV_YawAngleR_V_deg_CAMV_YawAngleR; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Float, RTE_VAR_INIT) Rte_CAM_RAD_V_degp500ms_RIR_Pre_StrAngVel_V_degp500ms_RIR_Pre_StrAngVel; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Float, RTE_VAR_INIT) Rte_CAM_RAD_V_degps_CIR_Yawrate_V_degps_CIR_Yawrate; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_degps_vCamYawrate_V_degps_vCamYawrate; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_m_CAMV_DistL_V_m_CAMV_DistL; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_m_CAMV_DistR_V_m_CAMV_DistR; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt32, RTE_VAR_INIT) Rte_CAM_RAD_V_m_CIR_vCAMERA_LDCA_V_m_CIR_vCAMERA_LDCA; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt8, RTE_VAR_INIT) Rte_CAM_RAD_V_m_CIR_vRelObj_Lateral_Distance_V_m_CIR_vRelObj_Lateral_Distance; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt8, RTE_VAR_INIT) Rte_CAM_RAD_V_m_CIR_vRelObj_Trajectory_V_m_CIR_vRelObj_Trajectory; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CAM_RAD_V_m_CIR_vRelObj_Width_V_m_CIR_vRelObj_Width; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(sint16_NP, RTE_VAR_INIT) Rte_CAM_RAD_V_m_CamLatDistCipv_V_m_CamLatDistCipv; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint16_NP, RTE_VAR_INIT) Rte_CAM_RAD_V_m_CamLongiDistCipv_V_m_CamLongiDistCipv; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt32, RTE_VAR_INIT) Rte_CAM_RAD_V_m_Dca_vDistance_Warn_V_m_Dca_vDistance_Warn; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(float32_NP, RTE_VAR_INIT) Rte_CAM_RAD_V_m_Distance_RIR_V_m_Distance_RIR; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt32, RTE_VAR_INIT) Rte_CAM_RAD_V_m_FcwMove_vDistance_V_m_FcwMove_vDistance; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt32, RTE_VAR_INIT) Rte_CAM_RAD_V_m_FcwMove_vDistance_Warn_V_m_FcwMove_vDistance_Warn; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt32, RTE_VAR_INIT) Rte_CAM_RAD_V_m_FcwStop_vDistance_V_m_FcwStop_vDistance; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt32, RTE_VAR_INIT) Rte_CAM_RAD_V_m_FcwStop_vDistance_Warn_V_m_FcwStop_vDistance_Warn; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt32, RTE_VAR_INIT) Rte_CAM_RAD_V_m_IbaMove_vDistance_V_m_IbaMove_vDistance; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt32, RTE_VAR_INIT) Rte_CAM_RAD_V_m_IbaMove_vDistance_Warn_V_m_IbaMove_vDistance_Warn; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt32, RTE_VAR_INIT) Rte_CAM_RAD_V_m_IbaStop_vDistance_V_m_IbaStop_vDistance; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt32, RTE_VAR_INIT) Rte_CAM_RAD_V_m_IbaStop_vDistance_Warn_V_m_IbaStop_vDistance_Warn; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_m_LatDistCamObj0_V_m_LatDistCamObj0; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_m_LatDistCamObj1_V_m_LatDistCamObj1; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_m_LatDistCamObj10_V_m_LatDistCamObj10; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_m_LatDistCamObj11_V_m_LatDistCamObj11; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_m_LatDistCamObj2_V_m_LatDistCamObj2; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_m_LatDistCamObj3_V_m_LatDistCamObj3; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_m_LatDistCamObj4_V_m_LatDistCamObj4; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_m_LatDistCamObj5_V_m_LatDistCamObj5; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_m_LatDistCamObj6_V_m_LatDistCamObj6; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_m_LatDistCamObj7_V_m_LatDistCamObj7; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_m_LatDistCamObj8_V_m_LatDistCamObj8; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_m_LatDistCamObj9_V_m_LatDistCamObj9; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_m_LatDistObj0_V_m_LatDistObj0; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_m_LatDistObj1_V_m_LatDistObj1; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_m_LatDistObj2_V_m_LatDistObj2; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_m_LatDistObj3_V_m_LatDistObj3; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint16_NP, RTE_VAR_INIT) Rte_CAM_RAD_V_m_LatDistObj6_V_m_LatDistObj6; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_m_LatDist_ACC_V_m_LatDist_ACC; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_CAM_RAD_V_m_LeftLaneMarkWidth_CamRad_V_m_LeftLaneMarkWidth_CamRad; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Float, RTE_VAR_INIT) Rte_CAM_RAD_V_m_LeftLineOffset_V_m_LeftLineOffset; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(sint16_NP, RTE_VAR_INIT) Rte_CAM_RAD_V_m_LeftLineOffset_CamRad_V_m_LeftLineOffset_CamRad; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Float, RTE_VAR_INIT) Rte_CAM_RAD_V_m_LeftLineViewRange_V_m_LeftLineViewRange; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_CAM_RAD_V_m_LeftLineViewRange_CamRad_V_m_LeftLineViewRange_CamRad; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_CAM_RAD_V_m_LeftTrippleLaneMark_Width_V_m_LeftTrippleLaneMark_Width; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_m_LengthObj0_V_m_LengthObj0; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_m_LengthObj1_V_m_LengthObj1; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_m_LengthObj2_V_m_LengthObj2; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_m_LengthObj3_V_m_LengthObj3; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_m_LongiDistCamObj0_V_m_LongiDistCamObj0; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_m_LongiDistCamObj1_V_m_LongiDistCamObj1; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_m_LongiDistCamObj10_V_m_LongiDistCamObj10; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_m_LongiDistCamObj11_V_m_LongiDistCamObj11; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_m_LongiDistCamObj2_V_m_LongiDistCamObj2; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_m_LongiDistCamObj3_V_m_LongiDistCamObj3; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_m_LongiDistCamObj4_V_m_LongiDistCamObj4; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_m_LongiDistCamObj5_V_m_LongiDistCamObj5; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_m_LongiDistCamObj6_V_m_LongiDistCamObj6; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_m_LongiDistCamObj7_V_m_LongiDistCamObj7; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_m_LongiDistCamObj8_V_m_LongiDistCamObj8; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_m_LongiDistCamObj9_V_m_LongiDistCamObj9; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_m_LongiDistObj0_V_m_LongiDistObj0; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_m_LongiDistObj1_V_m_LongiDistObj1; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_m_LongiDistObj2_V_m_LongiDistObj2; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_m_LongiDistObj3_V_m_LongiDistObj3; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint16_NP, RTE_VAR_INIT) Rte_CAM_RAD_V_m_LongiDistObj4_V_m_LongiDistObj4; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint16_NP, RTE_VAR_INIT) Rte_CAM_RAD_V_m_LongiDistObj5_V_m_LongiDistObj5; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint16_NP, RTE_VAR_INIT) Rte_CAM_RAD_V_m_LongiDistObj6_V_m_LongiDistObj6; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_m_LongiDist_ACC_V_m_LongiDist_ACC; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Float, RTE_VAR_INIT) Rte_CAM_RAD_V_m_RIR_Pre_Radius_V_m_RIR_Pre_Radius; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt32, RTE_VAR_INIT) Rte_CAM_RAD_V_m_RIR_vDist_r_V_m_RIR_vDist_r; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt32, RTE_VAR_INIT) Rte_CAM_RAD_V_m_RIR_vLat_r_V_m_RIR_vLat_r; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt32, RTE_VAR_INIT) Rte_CAM_RAD_V_m_RIR_vR_lane_N_V_m_RIR_vR_lane_N; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Float, RTE_VAR_INIT) Rte_CAM_RAD_V_m_RadarOrgDistObj0_V_m_RadarOrgDistObj0; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Float, RTE_VAR_INIT) Rte_CAM_RAD_V_m_RadarOrgDistObj1_V_m_RadarOrgDistObj1; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Float, RTE_VAR_INIT) Rte_CAM_RAD_V_m_RadarOrgLateralDistObj0_V_m_RadarOrgLateralDistObj0; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Float, RTE_VAR_INIT) Rte_CAM_RAD_V_m_RadarOrgLateralDistObj1_V_m_RadarOrgLateralDistObj1; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Float, RTE_VAR_INIT) Rte_CAM_RAD_V_m_RadarOrgLengthObj0_V_m_RadarOrgLengthObj0; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Float, RTE_VAR_INIT) Rte_CAM_RAD_V_m_RadarOrgLengthObj1_V_m_RadarOrgLengthObj1; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Float, RTE_VAR_INIT) Rte_CAM_RAD_V_m_RadarOrgRelSpdObj0_V_m_RadarOrgRelSpdObj0; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Float, RTE_VAR_INIT) Rte_CAM_RAD_V_m_RadarOrgRelSpdObj1_V_m_RadarOrgRelSpdObj1; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Float, RTE_VAR_INIT) Rte_CAM_RAD_V_m_RadarOrgTrajctryObj0_V_m_RadarOrgTrajctryObj0; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Float, RTE_VAR_INIT) Rte_CAM_RAD_V_m_RadarOrgTrajctryObj1_V_m_RadarOrgTrajctryObj1; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Float, RTE_VAR_INIT) Rte_CAM_RAD_V_m_RadarOrgWidthObj0_V_m_RadarOrgWidthObj0; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Float, RTE_VAR_INIT) Rte_CAM_RAD_V_m_RadarOrgWidthObj1_V_m_RadarOrgWidthObj1; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_CAM_RAD_V_m_RightLaneMarkWidth_CamRad_V_m_RightLaneMarkWidth_CamRad; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Float, RTE_VAR_INIT) Rte_CAM_RAD_V_m_RightLineOffset_V_m_RightLineOffset; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(sint16_NP, RTE_VAR_INIT) Rte_CAM_RAD_V_m_RightLineOffset_CamRad_V_m_RightLineOffset_CamRad; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Float, RTE_VAR_INIT) Rte_CAM_RAD_V_m_RightLineViewRange_V_m_RightLineViewRange; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_CAM_RAD_V_m_RightLineViewRange_CamRad_V_m_RightLineViewRange_CamRad; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_CAM_RAD_V_m_RightTrippleLaneMark_Width_V_m_RightTrippleLaneMark_Width; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(float32_NP, RTE_VAR_INIT) Rte_CAM_RAD_V_m_Selected20ObjLatDist_V_m_Selected20ObjLatDist; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(float32_NP, RTE_VAR_INIT) Rte_CAM_RAD_V_m_Selected20ObjLength_V_m_Selected20ObjLength; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(float32_NP, RTE_VAR_INIT) Rte_CAM_RAD_V_m_Selected20ObjLongDist_V_m_Selected20ObjLongDist; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(float32_NP, RTE_VAR_INIT) Rte_CAM_RAD_V_m_Selected20ObjWdth_V_m_Selected20ObjWdth; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(rt_Array_float32_2, RTE_VAR_INIT) Rte_CAM_RAD_V_m_SignLatDistance_V_m_SignLatDistance; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(rt_Array_float32_2, RTE_VAR_INIT) Rte_CAM_RAD_V_m_SignLongiDistance_V_m_SignLongiDistance; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(float32_NP, RTE_VAR_INIT) Rte_CAM_RAD_V_m_SuppDistLimit_RIR_V_m_SuppDistLimit_RIR; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(rt_Array_float32_2, RTE_VAR_INIT) Rte_CAM_RAD_V_m_TSRSignHeight_V_m_TSRSignHeight; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_CAM_RAD_V_m_TSR_SignDistanceObject00_V_m_TSR_SignDistanceObject00; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_CAM_RAD_V_m_TSR_SignDistanceObject01_V_m_TSR_SignDistanceObject01; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(sint16_NP, RTE_VAR_INIT) Rte_CAM_RAD_V_m_TSR_SignLateralDistanceObject00_V_m_TSR_SignLateralDistanceObject00; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(sint16_NP, RTE_VAR_INIT) Rte_CAM_RAD_V_m_TSR_SignLateralDistanceObject01_V_m_TSR_SignLateralDistanceObject01; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_m_TrajectoryObj0_V_m_TrajectoryObj0; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_m_TrajectoryObj1_V_m_TrajectoryObj1; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_m_TrajectoryObj2_V_m_TrajectoryObj2; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_m_TrajectoryObj3_V_m_TrajectoryObj3; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint16_NP, RTE_VAR_INIT) Rte_CAM_RAD_V_m_TrajectoryObj6_V_m_TrajectoryObj6; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_m_VCLCutBackXLeft_V_m_VCLCutBackXLeft; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_m_VCLCutBackXRight_V_m_VCLCutBackXRight; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_m_VCLCutBackZLeft_V_m_VCLCutBackZLeft; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_m_VCLCutBackZRight_V_m_VCLCutBackZRight; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_m_VCLCutFrontXLeft_V_m_VCLCutFrontXLeft; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_m_VCLCutFrontXRight_V_m_VCLCutFrontXRight; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_m_VCLCutFrontZLeft_V_m_VCLCutFrontZLeft; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_m_VCLCutFrontZRight_V_m_VCLCutFrontZRight; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_m_WidthCamObj0_V_m_WidthCamObj0; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_m_WidthCamObj1_V_m_WidthCamObj1; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_m_WidthCamObj10_V_m_WidthCamObj10; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_m_WidthCamObj11_V_m_WidthCamObj11; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_m_WidthCamObj2_V_m_WidthCamObj2; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_m_WidthCamObj3_V_m_WidthCamObj3; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_m_WidthCamObj4_V_m_WidthCamObj4; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_m_WidthCamObj5_V_m_WidthCamObj5; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_m_WidthCamObj6_V_m_WidthCamObj6; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_m_WidthCamObj7_V_m_WidthCamObj7; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_m_WidthCamObj8_V_m_WidthCamObj8; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_m_WidthCamObj9_V_m_WidthCamObj9; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_m_WidthObj0_V_m_WidthObj0; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_m_WidthObj1_V_m_WidthObj1; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_m_WidthObj2_V_m_WidthObj2; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_m_WidthObj3_V_m_WidthObj3; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_m_vGstMskMove_vLAT_DIST_V_m_vGstMskMove_vLAT_DIST; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_m_vGstMskMove_vLENGTH_V_m_vGstMskMove_vLENGTH; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_m_vGstMskMove_vRELE_TRAJ_V_m_vGstMskMove_vRELE_TRAJ; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_m_vGstMskMove_vWIDTH_V_m_vGstMskMove_vWIDTH; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt32, RTE_VAR_INIT) Rte_CAM_RAD_V_m_vObj0_Trajectory_V_m_vObj0_Trajectory; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt32, RTE_VAR_INIT) Rte_CAM_RAD_V_m_vObj0_Width_V_m_vObj0_Width; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt32, RTE_VAR_INIT) Rte_CAM_RAD_V_mpa_CamBrkPressCmdMinInput_V_mpa_CamBrkPressCmdMinInput; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt32, RTE_VAR_INIT) Rte_CAM_RAD_V_mpa_CamBrkPressCmdMinPrefillInput_V_mpa_CamBrkPressCmdMinPrefillInput; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt32, RTE_VAR_INIT) Rte_CAM_RAD_V_mpa_CamFcaTargetPbrkInput_V_mpa_CamFcaTargetPbrkInput; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt32, RTE_VAR_INIT) Rte_CAM_RAD_V_mpaps_CamBpUpFca1stInput_V_mpaps_CamBpUpFca1stInput; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_mps2_AccelAbs_ACC_V_mps2_AccelAbs_ACC; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_mps2_AccelCamObj0_V_mps2_AccelCamObj0; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_mps2_AccelCamObj1_V_mps2_AccelCamObj1; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_mps2_AccelCamObj10_V_mps2_AccelCamObj10; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_mps2_AccelCamObj11_V_mps2_AccelCamObj11; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_mps2_AccelCamObj2_V_mps2_AccelCamObj2; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_mps2_AccelCamObj3_V_mps2_AccelCamObj3; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_mps2_AccelCamObj4_V_mps2_AccelCamObj4; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_mps2_AccelCamObj5_V_mps2_AccelCamObj5; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_mps2_AccelCamObj6_V_mps2_AccelCamObj6; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_mps2_AccelCamObj7_V_mps2_AccelCamObj7; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_mps2_AccelCamObj8_V_mps2_AccelCamObj8; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_mps2_AccelCamObj9_V_mps2_AccelCamObj9; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt32, RTE_VAR_INIT) Rte_CAM_RAD_V_mps2_IbaMove_vAcceleration_V_mps2_IbaMove_vAcceleration; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt32, RTE_VAR_INIT) Rte_CAM_RAD_V_mps2_IbaStop_vAcceleration_V_mps2_IbaStop_vAcceleration; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(float32_NP, RTE_VAR_INIT) Rte_CAM_RAD_V_mps2_PrecVehicleAcc_Est_RIR_V_mps2_PrecVehicleAcc_Est_RIR; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_mps2_RelativeAccelObj0_V_mps2_RelativeAccelObj0; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_mps2_RelativeAccelObj1_V_mps2_RelativeAccelObj1; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_mps2_RelativeAccelObj2_V_mps2_RelativeAccelObj2; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_mps2_RelativeAccelObj3_V_mps2_RelativeAccelObj3; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint16_NP, RTE_VAR_INIT) Rte_CAM_RAD_V_mps2_RelativeAccelObj6_V_mps2_RelativeAccelObj6; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_mps2_vGstMskMove_vRELE_ACCEL_V_mps2_vGstMskMove_vRELE_ACCEL; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt32, RTE_VAR_INIT) Rte_CAM_RAD_V_mps_Acc_vVelocity_Warn_V_mps_Acc_vVelocity_Warn; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt32, RTE_VAR_INIT) Rte_CAM_RAD_V_mps_Dca_vVelocity_Warn_V_mps_Dca_vVelocity_Warn; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt32, RTE_VAR_INIT) Rte_CAM_RAD_V_mps_FcwMove_vVelocity_V_mps_FcwMove_vVelocity; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt32, RTE_VAR_INIT) Rte_CAM_RAD_V_mps_FcwStop_vVelocity_V_mps_FcwStop_vVelocity; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt32, RTE_VAR_INIT) Rte_CAM_RAD_V_mps_IbaMove_vVelocity_V_mps_IbaMove_vVelocity; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt32, RTE_VAR_INIT) Rte_CAM_RAD_V_mps_IbaMove_vVelocity_Warn_V_mps_IbaMove_vVelocity_Warn; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt32, RTE_VAR_INIT) Rte_CAM_RAD_V_mps_IbaMove_vVsp_A_V_mps_IbaMove_vVsp_A; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt32, RTE_VAR_INIT) Rte_CAM_RAD_V_mps_IbaStop_vVelocity_V_mps_IbaStop_vVelocity; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt32, RTE_VAR_INIT) Rte_CAM_RAD_V_mps_IbaStop_vVelocity_Warn_V_mps_IbaStop_vVelocity_Warn; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt32, RTE_VAR_INIT) Rte_CAM_RAD_V_mps_IbaStop_vVsp_A_V_mps_IbaStop_vVsp_A; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_mps_LatVelocity_ACC_V_mps_LatVelocity_ACC; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_mps_LateralVelocityCam0_V_mps_LateralVelocityCam0; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_mps_LateralVelocityCam1_V_mps_LateralVelocityCam1; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_mps_LateralVelocityCam10_V_mps_LateralVelocityCam10; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_mps_LateralVelocityCam11_V_mps_LateralVelocityCam11; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_mps_LateralVelocityCam2_V_mps_LateralVelocityCam2; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_mps_LateralVelocityCam3_V_mps_LateralVelocityCam3; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_mps_LateralVelocityCam4_V_mps_LateralVelocityCam4; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_mps_LateralVelocityCam5_V_mps_LateralVelocityCam5; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_mps_LateralVelocityCam6_V_mps_LateralVelocityCam6; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_mps_LateralVelocityCam7_V_mps_LateralVelocityCam7; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_mps_LateralVelocityCam8_V_mps_LateralVelocityCam8; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_mps_LateralVelocityCam9_V_mps_LateralVelocityCam9; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(float32_NP, RTE_VAR_INIT) Rte_CAM_RAD_V_mps_PVR_ACC_VSP_A_SEL_RIR_V_mps_PVR_ACC_VSP_A_SEL_RIR; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Float, RTE_VAR_INIT) Rte_CAM_RAD_V_mps_RadarOrgRelAccObj0_V_mps_RadarOrgRelAccObj0; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Float, RTE_VAR_INIT) Rte_CAM_RAD_V_mps_RadarOrgRelAccObj1_V_mps_RadarOrgRelAccObj1; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_mps_RelSpeedCamObj0_V_mps_RelSpeedCamObj0; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_mps_RelSpeedCamObj1_V_mps_RelSpeedCamObj1; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_mps_RelSpeedCamObj10_V_mps_RelSpeedCamObj10; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_mps_RelSpeedCamObj11_V_mps_RelSpeedCamObj11; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_mps_RelSpeedCamObj2_V_mps_RelSpeedCamObj2; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_mps_RelSpeedCamObj3_V_mps_RelSpeedCamObj3; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_mps_RelSpeedCamObj4_V_mps_RelSpeedCamObj4; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_mps_RelSpeedCamObj5_V_mps_RelSpeedCamObj5; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_mps_RelSpeedCamObj6_V_mps_RelSpeedCamObj6; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_mps_RelSpeedCamObj7_V_mps_RelSpeedCamObj7; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_mps_RelSpeedCamObj8_V_mps_RelSpeedCamObj8; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_mps_RelSpeedCamObj9_V_mps_RelSpeedCamObj9; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_mps_RelatVelocity_ACC_V_mps_RelatVelocity_ACC; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(float32_NP, RTE_VAR_INIT) Rte_CAM_RAD_V_mps_RelativeSpeed_RIR_V_mps_RelativeSpeed_RIR; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_mps_RelativeVelocityCam0_V_mps_RelativeVelocityCam0; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_mps_RelativeVelocityCam1_V_mps_RelativeVelocityCam1; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_mps_RelativeVelocityCam10_V_mps_RelativeVelocityCam10; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_mps_RelativeVelocityCam11_V_mps_RelativeVelocityCam11; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_mps_RelativeVelocityCam2_V_mps_RelativeVelocityCam2; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_mps_RelativeVelocityCam3_V_mps_RelativeVelocityCam3; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_mps_RelativeVelocityCam4_V_mps_RelativeVelocityCam4; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_mps_RelativeVelocityCam5_V_mps_RelativeVelocityCam5; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_mps_RelativeVelocityCam6_V_mps_RelativeVelocityCam6; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_mps_RelativeVelocityCam7_V_mps_RelativeVelocityCam7; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_mps_RelativeVelocityCam8_V_mps_RelativeVelocityCam8; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_mps_RelativeVelocityCam9_V_mps_RelativeVelocityCam9; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(float32_NP, RTE_VAR_INIT) Rte_CAM_RAD_V_mps_Selected20ObjRelatSpeed_V_mps_Selected20ObjRelatSpeed; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(float32_NP, RTE_VAR_INIT) Rte_CAM_RAD_V_mps_TargetSpeed_RIR_V_mps_TargetSpeed_RIR; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_mps_VCLCutRelatSpdLeft_V_mps_VCLCutRelatSpdLeft; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_mps_VCLCutRelatSpdRight_V_mps_VCLCutRelatSpdRight; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CAM_RAD_V_pct_CIR_vRelObj_Overlap_V_pct_CIR_vRelObj_Overlap; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_CAM_RAD_V_pct_HypoProbObj6_V_pct_HypoProbObj6; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_pct_ObsProbObj0_V_pct_ObsProbObj0; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_CAM_RAD_V_pct_QualGenObj6_V_pct_QualGenObj6; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Float, RTE_VAR_INIT) Rte_CAM_RAD_V_pct_RadarOrgObstProbObj0_V_pct_RadarOrgObstProbObj0; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Float, RTE_VAR_INIT) Rte_CAM_RAD_V_pct_RadarOrgObstProbObj1_V_pct_RadarOrgObstProbObj1; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_pm2_LeftLineCurvaRate_V_pm2_LeftLineCurvaRate; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(sint16_NP, RTE_VAR_INIT) Rte_CAM_RAD_V_pm2_LeftLineCurvatureRate_CamRad_V_pm2_LeftLineCurvatureRate_CamRad; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_pm2_RightLineCurvaRate_V_pm2_RightLineCurvaRate; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(sint16_NP, RTE_VAR_INIT) Rte_CAM_RAD_V_pm2_RightLineCurvatureRate_CamRad_V_pm2_RightLineCurvatureRate_CamRad; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_pm_CAMV_CURVATURE_M_V_pm_CAMV_CURVATURE_M; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_pm_CAMV_LaneCurvature_V_pm_CAMV_LaneCurvature; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Float, RTE_VAR_INIT) Rte_CAM_RAD_V_pm_LeftLineCurv_V_pm_LeftLineCurv; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(sint16_NP, RTE_VAR_INIT) Rte_CAM_RAD_V_pm_LeftLineCurvature_CamRad_V_pm_LeftLineCurvature_CamRad; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Float, RTE_VAR_INIT) Rte_CAM_RAD_V_pm_RightLineCurv_V_pm_RightLineCurv; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(sint16_NP, RTE_VAR_INIT) Rte_CAM_RAD_V_pm_RightLineCurvature_CamRad_V_pm_RightLineCurvature_CamRad; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(rt_Array_UInt8_2, RTE_VAR_INIT) Rte_CAM_RAD_V_pxl_TSRSignHorSize_V_pxl_TSRSignHorSize; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(rt_Array_UInt8_2, RTE_VAR_INIT) Rte_CAM_RAD_V_pxl_TSRSignVerSize_V_pxl_TSRSignVerSize; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_rad_LeftLineYawAng_V_rad_LeftLineYawAng; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(sint16_NP, RTE_VAR_INIT) Rte_CAM_RAD_V_rad_LeftLineYawAngle_CamRad_V_rad_LeftLineYawAngle_CamRad; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_rad_RightLineYawAng_V_rad_RightLineYawAng; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(sint16_NP, RTE_VAR_INIT) Rte_CAM_RAD_V_rad_RightLineYawAngle_CamRad_V_rad_RightLineYawAngle_CamRad; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CAM_RAD_V_s_CIR_vRelObj_Ttc_V_s_CIR_vRelObj_Ttc; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(float32_NP, RTE_VAR_INIT) Rte_CAM_RAD_V_s_SuppLockTime_RIR_V_s_SuppLockTime_RIR; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(float32_NP, RTE_VAR_INIT) Rte_CAM_RAD_V_s_TimeToCollision_Est_RIR_V_s_TimeToCollision_Est_RIR; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CAM_RAD_V_x_2EEMsgCnt_V_x_2EEMsgCnt; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_CAM_RAD_V_x_ACC_DayTimeIndicator_CamRad_V_x_ACC_DayTimeIndicator_CamRad; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CAM_RAD_V_x_BlinkCamObj0_V_x_BlinkCamObj0; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CAM_RAD_V_x_BlinkCamObj1_V_x_BlinkCamObj1; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CAM_RAD_V_x_BlinkCamObj10_V_x_BlinkCamObj10; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CAM_RAD_V_x_BlinkCamObj11_V_x_BlinkCamObj11; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CAM_RAD_V_x_BlinkCamObj2_V_x_BlinkCamObj2; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CAM_RAD_V_x_BlinkCamObj3_V_x_BlinkCamObj3; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CAM_RAD_V_x_BlinkCamObj4_V_x_BlinkCamObj4; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CAM_RAD_V_x_BlinkCamObj5_V_x_BlinkCamObj5; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CAM_RAD_V_x_BlinkCamObj6_V_x_BlinkCamObj6; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CAM_RAD_V_x_BlinkCamObj7_V_x_BlinkCamObj7; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CAM_RAD_V_x_BlinkCamObj8_V_x_BlinkCamObj8; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CAM_RAD_V_x_BlinkCamObj9_V_x_BlinkCamObj9; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CAM_RAD_V_x_BlinkerInfo_ACC_V_x_BlinkerInfo_ACC; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CAM_RAD_V_x_CAMV_MarkingTypeL_V_x_CAMV_MarkingTypeL; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CAM_RAD_V_x_CAMV_MarkingTypeR_V_x_CAMV_MarkingTypeR; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CAM_RAD_V_x_CIR_RelObj_Motion_Status_V_x_CIR_RelObj_Motion_Status; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CAM_RAD_V_x_CIR_RelObj_Object_Class_V_x_CIR_RelObj_Object_Class; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_CAM_RAD_V_x_CamDynamicsCipv_V_x_CamDynamicsCipv; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt32, RTE_VAR_INIT) Rte_CAM_RAD_V_x_CamPreBrkChangeReq_V_x_CamPreBrkChangeReq; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(sint16_NP, RTE_VAR_INIT) Rte_CAM_RAD_V_x_CamRelativeSpeedCipv_V_x_CamRelativeSpeedCipv; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_CAM_RAD_V_x_CamTypeCipv_V_x_CamTypeCipv; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CAM_RAD_V_x_CutInOut_ACC_V_x_CutInOut_ACC; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CAM_RAD_V_x_CutiInOutCam0_V_x_CutiInOutCam0; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CAM_RAD_V_x_CutiInOutCam1_V_x_CutiInOutCam1; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CAM_RAD_V_x_CutiInOutCam10_V_x_CutiInOutCam10; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CAM_RAD_V_x_CutiInOutCam11_V_x_CutiInOutCam11; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CAM_RAD_V_x_CutiInOutCam2_V_x_CutiInOutCam2; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CAM_RAD_V_x_CutiInOutCam3_V_x_CutiInOutCam3; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CAM_RAD_V_x_CutiInOutCam4_V_x_CutiInOutCam4; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CAM_RAD_V_x_CutiInOutCam5_V_x_CutiInOutCam5; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CAM_RAD_V_x_CutiInOutCam6_V_x_CutiInOutCam6; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CAM_RAD_V_x_CutiInOutCam7_V_x_CutiInOutCam7; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CAM_RAD_V_x_CutiInOutCam8_V_x_CutiInOutCam8; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CAM_RAD_V_x_CutiInOutCam9_V_x_CutiInOutCam9; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CAM_RAD_V_x_DayTimeInd_V_x_DayTimeInd; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CAM_RAD_V_x_Dca_vMode_V_x_Dca_vMode; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_x_DynamicsObj0_V_x_DynamicsObj0; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_x_DynamicsObj1_V_x_DynamicsObj1; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_x_DynamicsObj2_V_x_DynamicsObj2; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_x_DynamicsObj3_V_x_DynamicsObj3; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_CAM_RAD_V_x_DynamicsObj4_V_x_DynamicsObj4; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_CAM_RAD_V_x_DynamicsObj5_V_x_DynamicsObj5; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_x_ExisProbObj0_V_x_ExisProbObj0; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CAM_RAD_V_x_ExisProbObj1_V_x_ExisProbObj1; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CAM_RAD_V_x_ExisProbObj2_V_x_ExisProbObj2; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_x_ExisProbObj3_V_x_ExisProbObj3; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_CAM_RAD_V_x_FS_BlurImgLevel_V_x_FS_BlurImgLevel; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_CAM_RAD_V_x_FS_FogSpotLevel_V_x_FS_FogSpotLevel; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_CAM_RAD_V_x_FS_FullBlockLevel_V_x_FS_FullBlockLevel; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_CAM_RAD_V_x_FS_LowSunLevel_V_x_FS_LowSunLevel; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_CAM_RAD_V_x_FS_PartialBlockLevel_V_x_FS_PartialBlockLevel; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_CAM_RAD_V_x_FS_RoadSplayLevel_V_x_FS_RoadSplayLevel; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_CAM_RAD_V_x_FS_SunRayLevel_V_x_FS_SunRayLevel; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CAM_RAD_V_x_FcwMove_vMode_V_x_FcwMove_vMode; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CAM_RAD_V_x_FcwStop_vMode_V_x_FcwStop_vMode; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CAM_RAD_V_x_FreeSpace_ACC_V_x_FreeSpace_ACC; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_CAM_RAD_V_x_FusedLane_Confidence_V_x_FusedLane_Confidence; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint16_NP, RTE_VAR_INIT) Rte_CAM_RAD_V_x_FusedLane_CurvatureCoef_V_x_FusedLane_CurvatureCoef; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint16_NP, RTE_VAR_INIT) Rte_CAM_RAD_V_x_FusedLane_DerivativCurvatureCoef_V_x_FusedLane_DerivativCurvatureCoef; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint16_NP, RTE_VAR_INIT) Rte_CAM_RAD_V_x_FusedLane_OffsetCoef_V_x_FusedLane_OffsetCoef; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint16_NP, RTE_VAR_INIT) Rte_CAM_RAD_V_x_FusedLane_YawAngleCoef_V_x_FusedLane_YawAngleCoef; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CAM_RAD_V_x_HWE_V_x_HWE; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_CAM_RAD_V_x_HighWayExitDetected_CamRad_V_x_HighWayExitDetected_CamRad; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_CAM_RAD_V_x_HypoTypeObj6_V_x_HypoTypeObj6; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CAM_RAD_V_x_IDCIPV_V_x_IDCIPV; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_x_IDCamObj0_V_x_IDCamObj0; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_x_IDCamObj1_V_x_IDCamObj1; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_x_IDCamObj10_V_x_IDCamObj10; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_x_IDCamObj11_V_x_IDCamObj11; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_x_IDCamObj2_V_x_IDCamObj2; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_x_IDCamObj3_V_x_IDCamObj3; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_x_IDCamObj4_V_x_IDCamObj4; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_x_IDCamObj5_V_x_IDCamObj5; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_x_IDCamObj6_V_x_IDCamObj6; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_x_IDCamObj7_V_x_IDCamObj7; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_x_IDCamObj8_V_x_IDCamObj8; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_x_IDCamObj9_V_x_IDCamObj9; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_x_IDObj0_V_x_IDObj0; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_x_IDObj1_V_x_IDObj1; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CAM_RAD_V_x_IDObj2_V_x_IDObj2; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_x_IDObj3_V_x_IDObj3; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_CAM_RAD_V_x_IDObj6_V_x_IDObj6; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CAM_RAD_V_x_IbaMove_vMode_V_x_IbaMove_vMode; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CAM_RAD_V_x_IbaStop_vMode_V_x_IbaStop_vMode; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CAM_RAD_V_x_LeftBoundType_V_x_LeftBoundType; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_CAM_RAD_V_x_LeftBoundaryType_CamRad_V_x_LeftBoundaryType_CamRad; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_CAM_RAD_V_x_LeftLineColor_V_x_LeftLineColor; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CAM_RAD_V_x_LeftLineConfidence_V_x_LeftLineConfidence; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_CAM_RAD_V_x_LeftLineConfidence_CamRad_V_x_LeftLineConfidence_CamRad; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CAM_RAD_V_x_LostReasonObj0_V_x_LostReasonObj0; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CAM_RAD_V_x_LostReasonObj1_V_x_LostReasonObj1; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CAM_RAD_V_x_LostReasonObj2_V_x_LostReasonObj2; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CAM_RAD_V_x_LostReasonObj3_V_x_LostReasonObj3; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CAM_RAD_V_x_MotionSts_ACC_V_x_MotionSts_ACC; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_CAM_RAD_V_x_NextLeftBoundaryType_V_x_NextLeftBoundaryType; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_CAM_RAD_V_x_NextLeftLineConfidence_V_x_NextLeftLineConfidence; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_CAM_RAD_V_x_NextLeftLineMarkWidth_V_x_NextLeftLineMarkWidth; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(sint16_NP, RTE_VAR_INIT) Rte_CAM_RAD_V_x_NextLeftLineOffset_V_x_NextLeftLineOffset; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(sint16_NP, RTE_VAR_INIT) Rte_CAM_RAD_V_x_NextRighLineOffset_V_x_NextRighLineOffset; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_CAM_RAD_V_x_NextRightBoundaryType_V_x_NextRightBoundaryType; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_CAM_RAD_V_x_NextRightLineConfidence_V_x_NextRightLineConfidence; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_CAM_RAD_V_x_NextRightLineMarkWidth_V_x_NextRightLineMarkWidth; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CAM_RAD_V_x_ObjClass_ACC_V_x_ObjClass_ACC; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_x_ObsProbObj1_V_x_ObsProbObj1; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CAM_RAD_V_x_ObsProbObj2_V_x_ObsProbObj2; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_x_ObsProbObj3_V_x_ObsProbObj3; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_CAM_RAD_V_x_PVR_ACC_STATE_MODE_SEL_RIR_V_x_PVR_ACC_STATE_MODE_SEL_RIR; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_x_RCSObj0_V_x_RCSObj0; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CAM_RAD_V_x_RIR_vID_r_V_x_RIR_vID_r; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CAM_RAD_V_x_RadarOrgDynamicObj0_V_x_RadarOrgDynamicObj0; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CAM_RAD_V_x_RadarOrgDynamicObj1_V_x_RadarOrgDynamicObj1; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CAM_RAD_V_x_RadarOrgIdObj0_V_x_RadarOrgIdObj0; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CAM_RAD_V_x_RadarOrgIdObj1_V_x_RadarOrgIdObj1; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Float, RTE_VAR_INIT) Rte_CAM_RAD_V_x_RadarOrgRcsObj0_V_x_RadarOrgRcsObj0; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Float, RTE_VAR_INIT) Rte_CAM_RAD_V_x_RadarOrgRcsObj1_V_x_RadarOrgRcsObj1; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CAM_RAD_V_x_RadarOrgStatusObj0_V_x_RadarOrgStatusObj0; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CAM_RAD_V_x_RadarOrgStatusObj1_V_x_RadarOrgStatusObj1; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CAM_RAD_V_x_RadarOrgTypeObj0_V_x_RadarOrgTypeObj0; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CAM_RAD_V_x_RadarOrgTypeObj1_V_x_RadarOrgTypeObj1; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_x_RelativeSpeedObj0_V_x_RelativeSpeedObj0; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_x_RelativeSpeedObj1_V_x_RelativeSpeedObj1; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_x_RelativeSpeedObj2_V_x_RelativeSpeedObj2; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_x_RelativeSpeedObj3_V_x_RelativeSpeedObj3; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint16_NP, RTE_VAR_INIT) Rte_CAM_RAD_V_x_RelativeSpeedObj6_V_x_RelativeSpeedObj6; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CAM_RAD_V_x_RightBoundType_V_x_RightBoundType; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_CAM_RAD_V_x_RightBoundaryType_CamRad_V_x_RightBoundaryType_CamRad; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_CAM_RAD_V_x_RightLineColor_V_x_RightLineColor; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CAM_RAD_V_x_RightLineConfidence_V_x_RightLineConfidence; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_CAM_RAD_V_x_RightLineConfidence_CamRad_V_x_RightLineConfidence_CamRad; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_CAM_RAD_V_x_Selected20ObjDynProp_V_x_Selected20ObjDynProp; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_CAM_RAD_V_x_Selected20ObjID_V_x_Selected20ObjID; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CAM_RAD_V_x_SetTTMIGNTimesEeprom_V_x_SetTTMIGNTimesEeprom; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_x_StatusCamObj0_V_x_StatusCamObj0; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_x_StatusCamObj1_V_x_StatusCamObj1; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_x_StatusCamObj10_V_x_StatusCamObj10; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_x_StatusCamObj11_V_x_StatusCamObj11; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_x_StatusCamObj2_V_x_StatusCamObj2; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_x_StatusCamObj3_V_x_StatusCamObj3; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_x_StatusCamObj4_V_x_StatusCamObj4; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_x_StatusCamObj5_V_x_StatusCamObj5; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_x_StatusCamObj6_V_x_StatusCamObj6; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_x_StatusCamObj7_V_x_StatusCamObj7; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_x_StatusCamObj8_V_x_StatusCamObj8; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_x_StatusCamObj9_V_x_StatusCamObj9; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_x_StatusObj0_V_x_StatusObj0; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_x_StatusObj1_V_x_StatusObj1; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CAM_RAD_V_x_StatusObj2_V_x_StatusObj2; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_x_StatusObj3_V_x_StatusObj3; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_CAM_RAD_V_x_StatusObj4_V_x_StatusObj4; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_CAM_RAD_V_x_StatusObj5_V_x_StatusObj5; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_CAM_RAD_V_x_TFL_ColorObject00_V_x_TFL_ColorObject00; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_CAM_RAD_V_x_TFL_ColorObject01_V_x_TFL_ColorObject01; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_CAM_RAD_V_x_TFL_ColorObject02_V_x_TFL_ColorObject02; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint16_NP, RTE_VAR_INIT) Rte_CAM_RAD_V_x_TFL_PosZobject00_V_x_TFL_PosZobject00; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint16_NP, RTE_VAR_INIT) Rte_CAM_RAD_V_x_TFL_PosZobject01_V_x_TFL_PosZobject01; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint16_NP, RTE_VAR_INIT) Rte_CAM_RAD_V_x_TFL_PosZobject02_V_x_TFL_PosZobject02; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(rt_Array_UInt8_2, RTE_VAR_INIT) Rte_CAM_RAD_V_x_TSRFilterType_V_x_TSRFilterType; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(rt_Array_UInt8_2, RTE_VAR_INIT) Rte_CAM_RAD_V_x_TSRSignType_V_x_TSRSignType; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(rt_Array_UInt8_2, RTE_VAR_INIT) Rte_CAM_RAD_V_x_TSRSuppSign_V_x_TSRSuppSign; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_CAM_RAD_V_x_TSR_FilterTypeObject00_V_x_TSR_FilterTypeObject00; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_CAM_RAD_V_x_TSR_FilterTypeObject01_V_x_TSR_FilterTypeObject01; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_CAM_RAD_V_x_TSR_VisionOnlySignTypeObject00_V_x_TSR_VisionOnlySignTypeObject00; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_CAM_RAD_V_x_TSR_VisionOnlySignTypeObject01_V_x_TSR_VisionOnlySignTypeObject01; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_CAM_RAD_V_x_TimeToLeftLaneCrossing_V_x_TimeToLeftLaneCrossing; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_CAM_RAD_V_x_TimeToRightLaneCrossing_V_x_TimeToRightLaneCrossing; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_x_TypeCamObj0_V_x_TypeCamObj0; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_x_TypeCamObj1_V_x_TypeCamObj1; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_x_TypeCamObj10_V_x_TypeCamObj10; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_x_TypeCamObj11_V_x_TypeCamObj11; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_x_TypeCamObj2_V_x_TypeCamObj2; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_x_TypeCamObj3_V_x_TypeCamObj3; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_x_TypeCamObj4_V_x_TypeCamObj4; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_x_TypeCamObj5_V_x_TypeCamObj5; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_x_TypeCamObj6_V_x_TypeCamObj6; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_x_TypeCamObj7_V_x_TypeCamObj7; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_x_TypeCamObj8_V_x_TypeCamObj8; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_x_TypeCamObj9_V_x_TypeCamObj9; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_x_TypeObj0_V_x_TypeObj0; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_x_TypeObj1_V_x_TypeObj1; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_x_TypeObj2_V_x_TypeObj2; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_x_TypeObj3_V_x_TypeObj3; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_CAM_RAD_V_x_TypeObj4_V_x_TypeObj4; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_CAM_RAD_V_x_TypeObj5_V_x_TypeObj5; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CAM_RAD_V_x_vDYN_V_x_vDYN; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CAM_RAD_V_x_vGstMskMove_vRCS_V_x_vGstMskMove_vRCS; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CAM_RAD_V_x_vObj0_ID_V_x_vObj0_ID; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(BswM_ESH_RunRequest, RTE_VAR_INIT) Rte_CANIF_BswM_SRI_BswM_MSI_ESH_RunRequest_BswM_MDGP_ESH_RunRequest_requestedMode; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_ABSMalfunction_BasicSW_F_x_ABSMalfunction_BasicSW; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_ABSinRegulation_BasicSW_F_x_ABSinRegulation_BasicSW; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_ACCBrakeLeadtimeControl_BasicSW_F_x_ACCBrakeLeadtimeControl_BasicSW; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_ACCForceLeadtimeControl_BasicSW_F_x_ACCForceLeadtimeControl_BasicSW; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_ACC_LeftCloseRangeCutIn_0x2EE_F_x_ACC_LeftCloseRangeCutIn_0x2EE; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_ACC_LimitRequest_0x315_F_x_ACC_LimitRequest_0x315; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_ACC_RightCloseRangeCutIn_0x2EE_F_x_ACC_RightCloseRangeCutIn_0x2EE; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_ACC_StandStillStatus_BasicSW_F_x_ACC_StandStillStatus_BasicSW; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_ACCompClutchDefault_0x25B_F_x_ACCompClutchDefault_0x25B; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_ACCompClutchStatus_0x25B_F_x_ACCompClutchStatus_0x25B; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_ACCompValveDefault_0x25B_F_x_ACCompValveDefault_0x25B; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_ADAS_EDRflashingStatus_0x3C2_F_x_ADAS_EDRflashingStatus_0x3C2; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_ADA_AuthorizationStatus_0x46E_F_x_ADA_AuthorizationStatus_0x46E; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_APK_GearShiftPerformanceStatus_0x0A4_F_x_APK_GearShiftPerformanceStatus_0x0A4; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_ASRMalfunction_BasicSW_F_x_ASRMalfunction_BasicSW; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_ASRinRegulation_BasicSW_F_x_ASRinRegulation_BasicSW; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_ATCVTFail_BasicSW_F_x_ATCVTFail_BasicSW; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_ATDowngradedMode_BasicSW_F_x_ATDowngradedMode_BasicSW; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_AT_TorqueAcknowledgement_0x3C6_F_x_AT_TorqueAcknowledgement_0x3C6; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_AVM_EAPinhibitionRequest_0x43D_F_x_AVM_EAPinhibitionRequest_0x43D; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_AVM_FailureStatus_0x43D_F_x_AVM_FailureStatus_0x43D; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_AVM_StainDetectionStatus_0x43D_F_x_AVM_StainDetectionStatus_0x43D; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_AYCMalfunction_0x202_F_x_AYCMalfunction_0x202; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_AYCinRegulation_BasicSW_F_x_AYCinRegulation_BasicSW; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_AbnormalVolt_0x522_F_x_AbnormalVolt_0x522; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_AbortAlertWarnIndReqE_0x21E_F_x_AbortAlertWarnIndReqE_0x21E; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_AbortPedsCmbTtcWarnL4_0x21E_F_x_AbortPedsCmbTtcWarnL4_0x21E; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_ActBrakeFlag_0x522_F_x_ActBrakeFlag_0x522; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_AlertWarnIndReqE_0x21E_F_x_AlertWarnIndReqE_0x21E; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_AlertWarnIndReqF_0x21D_F_x_AlertWarnIndReqF_0x21D; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_AlertWrnIndReqA_0x21D_F_x_AlertWrnIndReqA_0x21D; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_AlertWrnIndReqB_0x21D_F_x_AlertWrnIndReqB_0x21D; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_AlertWrnIndReqC_0x21D_F_x_AlertWrnIndReqC_0x21D; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_AlertWrnIndReqD_0x21D_F_x_AlertWrnIndReqD_0x21D; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_AutoACCrequest_EPKB_0x3C4_F_x_AutoACCrequest_EPKB_0x3C4; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_AutoHorOoc_0x21E_F_x_AutoHorOoc_0x21E; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_AutoLightingFunctionStatus_0x418_F_x_AutoLightingFunctionStatus_0x418; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_AutoYawOoc_0x21E_F_x_AutoYawOoc_0x21E; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_BMC_Acknowledgement_0x0B6_F_x_BMC_Acknowledgement_0x0B6; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_BMC_EngineTorqueOrder_0x0B7_F_x_BMC_EngineTorqueOrder_0x0B7; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_BSI_AlertLeftStatus_0x32C_F_x_BSI_AlertLeftStatus_0x32C; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_BSI_AlertRightStatus_0x331_F_x_BSI_AlertRightStatus_0x331; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_BSI_SideDisplay_0x623_F_x_BSI_SideDisplay_0x623; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_BSI_SideRadarCancelReasonRER_0x623_F_x_BSI_SideRadarCancelReasonRER_0x623; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_BSI_SoundAlert_0x623_F_x_BSI_SoundAlert_0x623; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_BSWRad_CancelReason_0x623_F_x_BSWRad_CancelReason_0x623; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_BSWrad_ActivationState_0x623_F_x_BSWrad_ActivationState_0x623; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_BSWrad_LeftStatusForBSI_0x32C_F_x_BSWrad_LeftStatusForBSI_0x32C; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_BSWrad_RightStatusForBSI_0x331_F_x_BSWrad_RightStatusForBSI_0x331; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_BSWrad_SideDisplay_0x623_F_x_BSWrad_SideDisplay_0x623; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_BSWrad_SideRadarCancelReasonRER_0x623_F_x_BSWrad_SideRadarCancelReasonRER_0x623; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_BSWson_ActivationState_0x502_F_x_BSWson_ActivationState_0x502; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_BadgeBatteryLow_0x46F_F_x_BadgeBatteryLow_0x46F; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_BasicPitchAxMis_0x21E_F_x_BasicPitchAxMis_0x21E; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_BasicYawAxMis_0x21E_F_x_BasicYawAxMis_0x21E; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_BlurImage_0x21D_F_x_BlurImage_0x21D; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_BrakeLampCancelRequest_0x0B7_F_x_BrakeLampCancelRequest_0x0B7; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_BrakeLampStatus_0x46C_F_x_BrakeLampStatus_0x46C; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_BrakeLimitationInhibitRequest_0x0B7_F_x_BrakeLimitationInhibitRequest_0x0B7; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_BrakingSystemStateDisplayRequest_0x3BD_F_x_BrakingSystemStateDisplayRequest_0x3BD; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(boolean_NP, RTE_VAR_INIT) Rte_CANIF_F_x_CANDiagAbsent_JT2_0x3F0_F_x_CANDiagAbsent_JT2_0x3F0; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(boolean_NP, RTE_VAR_INIT) Rte_CANIF_F_x_CANDiagAbsent_JT2_0x3F3_F_x_CANDiagAbsent_JT2_0x3F3; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(boolean_NP, RTE_VAR_INIT) Rte_CANIF_F_x_CANDiagAbsent_JT2_0x454_F_x_CANDiagAbsent_JT2_0x454; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_CCSLBrakeWheelTorqueOrder_0x0A7_F_x_CCSLBrakeWheelTorqueOrder_0x0A7; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_CCSLStatusForBrakingSystem_0x0A7_F_x_CCSLStatusForBrakingSystem_0x0A7; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_CIPVCam0_0x21F_F_x_CIPVCam0_0x21F; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_CIPVCam10_0x263_F_x_CIPVCam10_0x263; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_CIPVCam11_0x264_F_x_CIPVCam11_0x264; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_CIPVCam1_0x220_F_x_CIPVCam1_0x220; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_CIPVCam2_0x222_F_x_CIPVCam2_0x222; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_CIPVCam3_0x223_F_x_CIPVCam3_0x223; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_CIPVCam4_0x240_F_x_CIPVCam4_0x240; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_CIPVCam5_0x241_F_x_CIPVCam5_0x241; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_CIPVCam6_0x246_F_x_CIPVCam6_0x246; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_CIPVCam7_0x247_F_x_CIPVCam7_0x247; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_CIPVCam8_0x248_F_x_CIPVCam8_0x248; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_CIPVCam9_0x262_F_x_CIPVCam9_0x262; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_CRBSfailureDisplayAlert_0x3BD_F_x_CRBSfailureDisplayAlert_0x3BD; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_CRBSfailureDisplayAlert_mirror_0x3BD_F_x_CRBSfailureDisplayAlert_mirror_0x3BD; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_CTA_ActivationState_0x623_F_x_CTA_ActivationState_0x623; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_CTA_CollisionRiskAlert_0x623_F_x_CTA_CollisionRiskAlert_0x623; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_CTA_MODinhibitionRequest_0x623_F_x_CTA_MODinhibitionRequest_0x623; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_CTA_SideRadarCancelReasonRER_0x623_F_x_CTA_SideRadarCancelReasonRER_0x623; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_CalibrationMisalignment_0x21D_F_x_CalibrationMisalignment_0x21D; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_CamAEBWarning_0x302_F_x_CamAEBWarning_0x302; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_CamCrossRoadDetection_0x302_F_x_CamCrossRoadDetection_0x302; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_CamCyclistOnPavementObject00_0x38A_F_x_CamCyclistOnPavementObject00_0x38A; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_CamCyclistOnPavementObject01_0x380_F_x_CamCyclistOnPavementObject01_0x380; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_CamCyclistOnPavementObject02_0x370_F_x_CamCyclistOnPavementObject02_0x370; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_CamCyclistOnPavementObject03_0x36D_F_x_CamCyclistOnPavementObject03_0x36D; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_CamCyclistOnPavementObject04_0x35F_F_x_CamCyclistOnPavementObject04_0x35F; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_CamCyclistOnPavementObject05_0x35E_F_x_CamCyclistOnPavementObject05_0x35E; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_CamCyclistOnPavementObject06_0x358_F_x_CamCyclistOnPavementObject06_0x358; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_CamCyclistOnPavementObject07_0x355_F_x_CamCyclistOnPavementObject07_0x355; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_CamCyclistOnPavementObject08_0x351_F_x_CamCyclistOnPavementObject08_0x351; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_CamCyclistOnPavementObject09_0x350_F_x_CamCyclistOnPavementObject09_0x350; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_CamCyclistOnPavementObject10_0x342_F_x_CamCyclistOnPavementObject10_0x342; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_CamCyclistOnPavementObject11_0x341_F_x_CamCyclistOnPavementObject11_0x341; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_CamFrontCollisionValidObject00_0x266_F_x_CamFrontCollisionValidObject00_0x266; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_CamFrontCollisionValidObject01_0x267_F_x_CamFrontCollisionValidObject01_0x267; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_CamFrontCollisionValidObject02_0x268_F_x_CamFrontCollisionValidObject02_0x268; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_CamFrontCollisionValidObject03_0x269_F_x_CamFrontCollisionValidObject03_0x269; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_CamFrontCollisionValidObject04_0x26E_F_x_CamFrontCollisionValidObject04_0x26E; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_CamFrontCollisionValidObject05_0x26F_F_x_CamFrontCollisionValidObject05_0x26F; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_CamFrontCollisionValidObject06_0x2A3_F_x_CamFrontCollisionValidObject06_0x2A3; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_CamFrontCollisionValidObject07_0x2A4_F_x_CamFrontCollisionValidObject07_0x2A4; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_CamFrontCollisionValidObject08_0x2AC_F_x_CamFrontCollisionValidObject08_0x2AC; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_CamFrontCollisionValidObject09_0x2AD_F_x_CamFrontCollisionValidObject09_0x2AD; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_CamFrontCollisionValidObject10_0x2AE_F_x_CamFrontCollisionValidObject10_0x2AE; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_CamFrontCollisionValidObject11_0x2AF_F_x_CamFrontCollisionValidObject11_0x2AF; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_CamInitialised_0x2CC_F_x_CamInitialised_0x2CC; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_CamObjectReferencePoint00_0x340_F_x_CamObjectReferencePoint00_0x340; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_CamObjectReferencePoint01_0x35C_F_x_CamObjectReferencePoint01_0x35C; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_CamObjectReferencePoint02_0x35D_F_x_CamObjectReferencePoint02_0x35D; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_CamObjectReferencePoint03_0x390_F_x_CamObjectReferencePoint03_0x390; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_CamObjectReferencePoint04_0x393_F_x_CamObjectReferencePoint04_0x393; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_CamObjectReferencePoint05_0x394_F_x_CamObjectReferencePoint05_0x394; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_CamObjectReferencePoint06_0x39E_F_x_CamObjectReferencePoint06_0x39E; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_CamObjectReferencePoint07_0x3B9_F_x_CamObjectReferencePoint07_0x3B9; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_CamObjectReferencePoint08_0x3A9_F_x_CamObjectReferencePoint08_0x3A9; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_CamObjectReferencePoint09_0x3AE_F_x_CamObjectReferencePoint09_0x3AE; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_CamObjectReferencePoint10_0x3B8_F_x_CamObjectReferencePoint10_0x3B8; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_CamObjectReferencePoint11_0x3BB_F_x_CamObjectReferencePoint11_0x3BB; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_CamPedestrianOnPavementObject00_0x38A_F_x_CamPedestrianOnPavementObject00_0x38A; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_CamPedestrianOnPavementObject01_0x380_F_x_CamPedestrianOnPavementObject01_0x380; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_CamPedestrianOnPavementObject02_0x370_F_x_CamPedestrianOnPavementObject02_0x370; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_CamPedestrianOnPavementObject03_0x36D_F_x_CamPedestrianOnPavementObject03_0x36D; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_CamPedestrianOnPavementObject04_0x35F_F_x_CamPedestrianOnPavementObject04_0x35F; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_CamPedestrianOnPavementObject05_0x35E_F_x_CamPedestrianOnPavementObject05_0x35E; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_CamPedestrianOnPavementObject06_0x358_F_x_CamPedestrianOnPavementObject06_0x358; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_CamPedestrianOnPavementObject07_0x355_F_x_CamPedestrianOnPavementObject07_0x355; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_CamPedestrianOnPavementObject08_0x351_F_x_CamPedestrianOnPavementObject08_0x351; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_CamPedestrianOnPavementObject09_0x350_F_x_CamPedestrianOnPavementObject09_0x350; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_CamPedestrianOnPavementObject10_0x342_F_x_CamPedestrianOnPavementObject10_0x342; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_CamPedestrianOnPavementObject11_0x341_F_x_CamPedestrianOnPavementObject11_0x341; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_CamTargetLeftTurnDetected00_0x38A_F_x_CamTargetLeftTurnDetected00_0x38A; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_CamTargetLeftTurnDetected01_0x380_F_x_CamTargetLeftTurnDetected01_0x380; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_CamTargetLeftTurnDetected02_0x370_F_x_CamTargetLeftTurnDetected02_0x370; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_CamTargetLeftTurnDetected03_0x36D_F_x_CamTargetLeftTurnDetected03_0x36D; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_CamTargetLeftTurnDetected04_0x35F_F_x_CamTargetLeftTurnDetected04_0x35F; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_CamTargetLeftTurnDetected05_0x35E_F_x_CamTargetLeftTurnDetected05_0x35E; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_CamTargetLeftTurnDetected06_0x358_F_x_CamTargetLeftTurnDetected06_0x358; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_CamTargetLeftTurnDetected07_0x355_F_x_CamTargetLeftTurnDetected07_0x355; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_CamTargetLeftTurnDetected08_0x351_F_x_CamTargetLeftTurnDetected08_0x351; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_CamTargetLeftTurnDetected09_0x350_F_x_CamTargetLeftTurnDetected09_0x350; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_CamTargetLeftTurnDetected10_0x342_F_x_CamTargetLeftTurnDetected10_0x342; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_CamTargetLeftTurnDetected11_0x341_F_x_CamTargetLeftTurnDetected11_0x341; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_CameraCalibStatus_0x2CC_F_x_CameraCalibStatus_0x2CC; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_CameraCanFailure_0x2CC_F_x_CameraCanFailure_0x2CC; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_CameraHiTempStatus_0x2CC_F_x_CameraHiTempStatus_0x2CC; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_CameraSnowOnRoadDetected_0x2CC_F_x_CameraSnowOnRoadDetected_0x2CC; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_CameraSupplyVoltage_0x2CC_F_x_CameraSupplyVoltage_0x2CC; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_ConstructionArea_0x21D_F_x_ConstructionArea_0x21D; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_CrossWalkOnPathDetection_0x302_F_x_CrossWalkOnPathDetection_0x302; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_CruiseControlStatusRER_0x417_F_x_CruiseControlStatusRER_0x417; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_CustomerApproachDetected_0x46F_F_x_CustomerApproachDetected_0x46F; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_CustomerDepartureDetected_0x46F_F_x_CustomerDepartureDetected_0x46F; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_CyclistAreaDetection_0x3AF_F_x_CyclistAreaDetection_0x3AF; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_CyclistLaneDetection_0x3AF_F_x_CyclistLaneDetection_0x3AF; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_CyclistLaneOnPathDetection_0x3AF_F_x_CyclistLaneOnPathDetection_0x3AF; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_DataSetCollisionValidity_0x020_F_x_DataSetCollisionValidity_0x020; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_DayTimeIndicator_AEB_0x21F_F_x_DayTimeIndicator_AEB_0x21F; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_DayTimeIndicator_AEB_0x220_F_x_DayTimeIndicator_AEB_0x220; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_DayTimeIndicator_AEB_0x222_F_x_DayTimeIndicator_AEB_0x222; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_DayTimeIndicator_AEB_0x223_F_x_DayTimeIndicator_AEB_0x223; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_DayTimeIndicator_AEB_0x240_F_x_DayTimeIndicator_AEB_0x240; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_DayTimeIndicator_AEB_0x241_F_x_DayTimeIndicator_AEB_0x241; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_DayTimeIndicator_AEB_0x246_F_x_DayTimeIndicator_AEB_0x246; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_DayTimeIndicator_AEB_0x247_F_x_DayTimeIndicator_AEB_0x247; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_DayTimeIndicator_AEB_0x248_F_x_DayTimeIndicator_AEB_0x248; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_DayTimeIndicator_AEB_0x262_F_x_DayTimeIndicator_AEB_0x262; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_DayTimeIndicator_AEB_0x263_F_x_DayTimeIndicator_AEB_0x263; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_DayTimeIndicator_AEB_0x264_F_x_DayTimeIndicator_AEB_0x264; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_DayTimeRunningLightRequest_0x418_F_x_DayTimeRunningLightRequest_0x418; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_DirectionFront1stCollision_0x020_F_x_DirectionFront1stCollision_0x020; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_DirectionFront2ndCollision_0x020_F_x_DirectionFront2ndCollision_0x020; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_DirectionLeft1stCollision_0x020_F_x_DirectionLeft1stCollision_0x020; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_DirectionLeft2ndCollision_0x020_F_x_DirectionLeft2ndCollision_0x020; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_DirectionRear1stCollision_0x020_F_x_DirectionRear1stCollision_0x020; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_DirectionRear2ndCollision_0x020_F_x_DirectionRear2ndCollision_0x020; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_DirectionRight1stCollision_0x020_F_x_DirectionRight1stCollision_0x020; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_DirectionRight2ndCollision_0x020_F_x_DirectionRight2ndCollision_0x020; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_DirectionRollover1stCollision_0x020_F_x_DirectionRollover1stCollision_0x020; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_DirectionRollover2ndCollision_0x020_F_x_DirectionRollover2ndCollision_0x020; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_DisplayedSpeedUnit_BasicSW_F_x_DisplayedSpeedUnit_BasicSW; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_DriverActionOnGearCommands_0x0A4_F_x_DriverActionOnGearCommands_0x0A4; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_DriverDoorLockedStatus_0x418_F_x_DriverDoorLockedStatus_0x418; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_DriverDoorStatusSupposedFailure_0x47D_F_x_DriverDoorStatusSupposedFailure_0x47D; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_DriverModeUpSwitchState_0x418_F_x_DriverModeUpSwitchState_0x418; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_DriverOverride_BasicSW_F_x_DriverOverride_BasicSW; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_DriverSidePosition_0x418_F_x_DriverSidePosition_0x418; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_DynamicBrakingDisplay_0x3C4_F_x_DynamicBrakingDisplay_0x3C4; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_EBAfailureDisplayAlert_0x3BD_F_x_EBAfailureDisplayAlert_0x3BD; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_EBAfailureDisplayAlert_mirror_0x3BD_F_x_EBAfailureDisplayAlert_mirror_0x3BD; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_EBD_Active_0x202_F_x_EBD_Active_0x202; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_EBDstateDisplayRequest_0x3BD_F_x_EBDstateDisplayRequest_0x3BD; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_EPB_NotTightenedWarning_0x3C4_F_x_EPB_NotTightenedWarning_0x3C4; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_EPB_PowerLatchRequest_0x3C4_F_x_EPB_PowerLatchRequest_0x3C4; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_EPS_ControlledByLCA_0x25E_F_x_EPS_ControlledByLCA_0x25E; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_EPS_ControlledByLKA_0x25E_F_x_EPS_ControlledByLKA_0x25E; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_ESCMalfunction_BasicSW_F_x_ESCMalfunction_BasicSW; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_ESC_VDC_Deactivated_BasicSW_F_x_ESC_VDC_Deactivated_BasicSW; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_ETAKickDetected_0x46C_F_x_ETAKickDetected_0x46C; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_ETSMalfunction_0x25F_F_x_ETSMalfunction_0x25F; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_ETS_TorqueAcknowledgment_0x0B6_F_x_ETS_TorqueAcknowledgment_0x0B6; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_ETS_TorqueReductionReqCoupProt_0x25F_F_x_ETS_TorqueReductionReqCoupProt_0x25F; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_ETS_WARN_MMD1_0x25F_F_x_ETS_WARN_MMD1_0x25F; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_ETS_WARN_MMD2_0x25F_F_x_ETS_WARN_MMD2_0x25F; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_ETS_WarningLamp_0x25F_F_x_ETS_WarningLamp_0x25F; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_EcoDriveIndicatorDisplay_0x417_F_x_EcoDriveIndicatorDisplay_0x417; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_EcoPedalMenuRequest_0x417_F_x_EcoPedalMenuRequest_0x417; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_EngineStopDriverRequestValid_0x47D_F_x_EngineStopDriverRequestValid_0x47D; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_EngineStopDriverRequested_0x47D_F_x_EngineStopDriverRequested_0x47D; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_EngineWarmUpPhase_0x3C6_F_x_EngineWarmUpPhase_0x3C6; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_FAP_ADASgearShiftOrder_0x1B2_F_x_FAP_ADASgearShiftOrder_0x1B2; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_FAP_SteeringAngleRequestOrder_0x19A_F_x_FAP_SteeringAngleRequestOrder_0x19A; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_FS_AbortionAAFail_0x21E_F_x_FS_AbortionAAFail_0x21E; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_FS_AbortionABFail_0x21E_F_x_FS_AbortionABFail_0x21E; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_FS_AbortionACFail_0x21E_F_x_FS_AbortionACFail_0x21E; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_FS_AbortionADFail_0x21E_F_x_FS_AbortionADFail_0x21E; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_FS_AbortionP1Fail_0x21E_F_x_FS_AbortionP1Fail_0x21E; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_FS_AbortionP2Fail_0x21E_F_x_FS_AbortionP2Fail_0x21E; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_FS_AbortionP3Fail_0x21E_F_x_FS_AbortionP3Fail_0x21E; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_FS_BusOff_JT1_F_x_FS_BusOff_JT1; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_FS_BusOff_JT2_F_x_FS_BusOff_JT2; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_FS_ChkSumADAS2_F_x_FS_ChkSumADAS2; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_FS_ChkSumCAM_F_x_FS_ChkSumCAM; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_FS_ChkSumEACT_F_x_FS_ChkSumEACT; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_FS_ChkSumEPS_F_x_FS_ChkSumEPS; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_FS_ChkSumHCM_F_x_FS_ChkSumHCM; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(boolean_NP, RTE_VAR_INIT) Rte_CANIF_F_x_FS_ChkSumIDM_F_x_FS_ChkSumIDM; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_FS_ChkSumRADAR_F_x_FS_ChkSumRADAR; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(boolean_NP, RTE_VAR_INIT) Rte_CANIF_F_x_FS_ChkSumSONAR_F_x_FS_ChkSumSONAR; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_FS_ChkSumSR_L_F_x_FS_ChkSumSR_L; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_FS_ChkSumSR_R_F_x_FS_ChkSumSR_R; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_FS_ChkSumSTR_F_x_FS_ChkSumSTR; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_FS_ChkSumVCM_F_x_FS_ChkSumVCM; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_FS_ChkSumVDC_F_x_FS_ChkSumVDC; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_FS_ChkSumePKB_F_x_FS_ChkSumePKB; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_FS_MsgCntADAS2_F_x_FS_MsgCntADAS2; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_FS_MsgCntATCVT_F_x_FS_MsgCntATCVT; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_FS_MsgCntCAM_F_x_FS_MsgCntCAM; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_FS_MsgCntEACT_F_x_FS_MsgCntEACT; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_FS_MsgCntECM_F_x_FS_MsgCntECM; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_FS_MsgCntEPS_F_x_FS_MsgCntEPS; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_FS_MsgCntHCM_F_x_FS_MsgCntHCM; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(boolean_NP, RTE_VAR_INIT) Rte_CANIF_F_x_FS_MsgCntIDM_F_x_FS_MsgCntIDM; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_FS_MsgCntRADAR_F_x_FS_MsgCntRADAR; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(boolean_NP, RTE_VAR_INIT) Rte_CANIF_F_x_FS_MsgCntSONAR_F_x_FS_MsgCntSONAR; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_FS_MsgCntSR_L_F_x_FS_MsgCntSR_L; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_FS_MsgCntSR_R_F_x_FS_MsgCntSR_R; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_FS_MsgCntSTR_F_x_FS_MsgCntSTR; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_FS_MsgCntVCM_F_x_FS_MsgCntVCM; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_FS_MsgCntVDC_F_x_FS_MsgCntVDC; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_FS_MsgCntePKB_F_x_FS_MsgCntePKB; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_FS_Mute_F_x_FS_Mute; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_FS_UnRcvADAS2_JT1_F_x_FS_UnRcvADAS2_JT1; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_FS_UnRcvADAS2_JT2_F_x_FS_UnRcvADAS2_JT2; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_FS_UnRcvATCVT_JT1_F_x_FS_UnRcvATCVT_JT1; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_FS_UnRcvATCVT_JT2_F_x_FS_UnRcvATCVT_JT2; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_FS_UnRcvAVM_JT1_F_x_FS_UnRcvAVM_JT1; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_FS_UnRcvAVM_JT2_F_x_FS_UnRcvAVM_JT2; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_FS_UnRcvBCM_JT1_F_x_FS_UnRcvBCM_JT1; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_FS_UnRcvBCM_JT2_F_x_FS_UnRcvBCM_JT2; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_FS_UnRcvCamera_JT1_F_x_FS_UnRcvCamera_JT1; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_FS_UnRcvCamera_JT2_F_x_FS_UnRcvCamera_JT2; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_FS_UnRcvEACT_JT1_F_x_FS_UnRcvEACT_JT1; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_FS_UnRcvEACT_JT2_F_x_FS_UnRcvEACT_JT2; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_FS_UnRcvECM_JT1_F_x_FS_UnRcvECM_JT1; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_FS_UnRcvECM_JT2_F_x_FS_UnRcvECM_JT2; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_FS_UnRcvEPS_JT1_F_x_FS_UnRcvEPS_JT1; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_FS_UnRcvEPS_JT2_F_x_FS_UnRcvEPS_JT2; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_FS_UnRcvHCM_JT1_F_x_FS_UnRcvHCM_JT1; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_FS_UnRcvHCM_JT2_F_x_FS_UnRcvHCM_JT2; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_FS_UnRcvIDM_JT1_F_x_FS_UnRcvIDM_JT1; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_FS_UnRcvIDM_JT2_F_x_FS_UnRcvIDM_JT2; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_FS_UnRcvMETER_JT1_F_x_FS_UnRcvMETER_JT1; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_FS_UnRcvMETER_JT2_F_x_FS_UnRcvMETER_JT2; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_FS_UnRcvRADAR_JT1_F_x_FS_UnRcvRADAR_JT1; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_FS_UnRcvRADAR_JT2_F_x_FS_UnRcvRADAR_JT2; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(boolean_NP, RTE_VAR_INIT) Rte_CANIF_F_x_FS_UnRcvSONAR_JT1_F_x_FS_UnRcvSONAR_JT1; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(boolean_NP, RTE_VAR_INIT) Rte_CANIF_F_x_FS_UnRcvSONAR_JT2_F_x_FS_UnRcvSONAR_JT2; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_FS_UnRcvSOWL_JT1_F_x_FS_UnRcvSOWL_JT1; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_FS_UnRcvSOWL_JT2_F_x_FS_UnRcvSOWL_JT2; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_FS_UnRcvSOWR_JT1_F_x_FS_UnRcvSOWR_JT1; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_FS_UnRcvSOWR_JT2_F_x_FS_UnRcvSOWR_JT2; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_FS_UnRcvSTRG_JT1_F_x_FS_UnRcvSTRG_JT1; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_FS_UnRcvSTRG_JT2_F_x_FS_UnRcvSTRG_JT2; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_FS_UnRcvUSM_JT1_F_x_FS_UnRcvUSM_JT1; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_FS_UnRcvUSM_JT2_F_x_FS_UnRcvUSM_JT2; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_FS_UnRcvVCM_JT1_F_x_FS_UnRcvVCM_JT1; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_FS_UnRcvVCM_JT2_F_x_FS_UnRcvVCM_JT2; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_FS_UnRcvVDC_JT1_F_x_FS_UnRcvVDC_JT1; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_FS_UnRcvVDC_JT2_F_x_FS_UnRcvVDC_JT2; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_FS_UnRcvePKB_JT1_F_x_FS_UnRcvePKB_JT1; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_FS_UnRcvePKB_JT2_F_x_FS_UnRcvePKB_JT2; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_FillerCapIndicatorResetStatus_0x47F_F_x_FillerCapIndicatorResetStatus_0x47F; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_FoggyLights_0x21D_F_x_FoggyLights_0x21D; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_FreeKmCalculationAuthorization_0x417_F_x_FreeKmCalculationAuthorization_0x417; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_FrontDefrostEngaged_0x46C_F_x_FrontDefrostEngaged_0x46C; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_FrontFogLightsDisplay_0x46C_F_x_FrontFogLightsDisplay_0x46C; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_FrontFogLightsRequest_0x46C_F_x_FrontFogLightsRequest_0x46C; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_FrontParkAssistState_0x502_F_x_FrontParkAssistState_0x502; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_FullBlockage_0x21D_F_x_FullBlockage_0x21D; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_HBAThresholdRequest_0x0A2_F_x_HBAThresholdRequest_0x0A2; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_HBBMalfunction_0x3BD_F_x_HBBMalfunction_0x3BD; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_HFMBatTempoRequest_0x46F_F_x_HFMBatTempoRequest_0x46F; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_HFPB_BrakingPerformanceStatus_0x0B7_F_x_HFPB_BrakingPerformanceStatus_0x0B7; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_HFPB_StandStillStatus_0x0B7_F_x_HFPB_StandStillStatus_0x0B7; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_HFP_TJPInhibitionRequest_BasicSW_F_x_HFP_TJPInhibitionRequest_BasicSW; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_HSAstateDisplayRequest_0x3BD_F_x_HSAstateDisplayRequest_0x3BD; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_HandFreeLockInhibition_0x46C_F_x_HandFreeLockInhibition_0x46C; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_HeadLampsWasherRequest_0x46C_F_x_HeadLampsWasherRequest_0x46C; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_HighBeamPassingRequest_0x47D_F_x_HighBeamPassingRequest_0x47D; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_HighBeamRequest_0x47D_F_x_HighBeamRequest_0x47D; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_HighWayExitLeftConfidence_0x2CC_F_x_HighWayExitLeftConfidence_0x2CC; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_HighWayExitRightConfidence_0x2CC_F_x_HighWayExitRightConfidence_0x2CC; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_HydraulicPreFillRequest_0x0A2_F_x_HydraulicPreFillRequest_0x0A2; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_IKeyAccessActivationState_0x46F_F_x_IKeyAccessActivationState_0x46F; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_IPA_Failure_0x1B2_F_x_IPA_Failure_0x1B2; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_IdleSpeedIncreaseRequest_0x46C_F_x_IdleSpeedIncreaseRequest_0x46C; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_IgnitionSupplyConfirmation_0x47C_F_x_IgnitionSupplyConfirmation_0x47C; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_IgnitionSwitchPosition_0x47D_F_x_IgnitionSwitchPosition_0x47D; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_ImspiredVDnight_0x21D_F_x_ImspiredVDnight_0x21D; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_InsideIkeyfobCountRequest_0x418_F_x_InsideIkeyfobCountRequest_0x418; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_KickDownActivated_0x3C6_F_x_KickDownActivated_0x3C6; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_LCA_DriverHandsOnWheel_0x0AC_F_x_LCA_DriverHandsOnWheel_0x0AC; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_LCA_DriverHandsOnWheel_mirror_0x0AC_F_x_LCA_DriverHandsOnWheel_mirror_0x0AC; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_LCA_SteeringOverride_0x0AC_F_x_LCA_SteeringOverride_0x0AC; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_LDWNrtaReasonsl_0x2CA_F_x_LDWNrtaReasonsl_0x2CA; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_LDWNrtaReasonsr_0x2CB_F_x_LDWNrtaReasonsr_0x2CB; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_LDWWarningLeft_0x2CA_F_x_LDWWarningLeft_0x2CA; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_LDWWarningRight_0x2CB_F_x_LDWWarningRight_0x2CB; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_LDW_HapticalActionRequest_0x3C2_F_x_LDW_HapticalActionRequest_0x3C2; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_LDW_RoadQualityEstimation_0x3C2_F_x_LDW_RoadQualityEstimation_0x3C2; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(boolean_NP, RTE_VAR_INIT) Rte_CANIF_F_x_LDW_StopAlertRequest_0x517_F_x_LDW_StopAlertRequest_0x517; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_LaneCrosLeft_0x2CC_F_x_LaneCrosLeft_0x2CC; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_LaneCrosRight_0x2CC_F_x_LaneCrosRight_0x2CC; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_LdwFailure_0x2CC_F_x_LdwFailure_0x2CC; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_LeftCloseRangeCutIn_0x21D_F_x_LeftCloseRangeCutIn_0x21D; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_LeftTripleLaneMark_Confidence_0x41E_F_x_LeftTripleLaneMark_Confidence_0x41E; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_LevellingLimitAlert_0x25B_F_x_LevellingLimitAlert_0x25B; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_LightSensorStatus_0x47D_F_x_LightSensorStatus_0x47D; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_LowBeamRequest_0x47D_F_x_LowBeamRequest_0x47D; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_LowBeamRequest_USM_0x418_F_x_LowBeamRequest_USM_0x418; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_LowPWTregenBrakeTorqueRequest_0x3BD_F_x_LowPWTregenBrakeTorqueRequest_0x3BD; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_LowSun_0x21D_F_x_LowSun_0x21D; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_MOD_SoundAlertRequest_ADAS_0x5B3_F_x_MOD_SoundAlertRequest_ADAS_0x5B3; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_MSRinRegulation_BasicSW_F_x_MSRinRegulation_BasicSW; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_MexSwitchState_0x418_F_x_MexSwitchState_0x418; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_Misalign_0x522_F_x_Misalign_0x522; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_ModelLeftLineConfidence_0x41E_F_x_ModelLeftLineConfidence_0x41E; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_ModelRightLineConfidence_0x420_F_x_ModelRightLineConfidence_0x420; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_MotorFanFailureStatus_0x25B_F_x_MotorFanFailureStatus_0x25B; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_MuteRadioOrder_0x47F_F_x_MuteRadioOrder_0x47F; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_NoiseDetectedFront_0x323_F_x_NoiseDetectedFront_0x323; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_NoiseDetectedRear_0x324_F_x_NoiseDetectedRear_0x324; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_NotImmobilizedVehicleWarning_0x3C4_F_x_NotImmobilizedVehicleWarning_0x3C4; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_OBD_Engine_On_0x3C6_F_x_OBD_Engine_On_0x3C6; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_OBD_GeneralTrip_0x3C6_F_x_OBD_GeneralTrip_0x3C6; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_OBD_MutualTempSoakCompleted_0x3C6_F_x_OBD_MutualTempSoakCompleted_0x3C6; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_OBD_WUC_0x3C6_F_x_OBD_WUC_0x3C6; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_ObjMeas_0x522_F_x_ObjMeas_0x522; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_ObjMeasured_0x24A_F_x_ObjMeasured_0x24A; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_ObjMeasured_0x24B_F_x_ObjMeasured_0x24B; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_ObjMeasured_0x24C_F_x_ObjMeasured_0x24C; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_ObjMeasured_0x24D_F_x_ObjMeasured_0x24D; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_ObjMeasured_0x24E_F_x_ObjMeasured_0x24E; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_ObjMeasured_0x24F_F_x_ObjMeasured_0x24F; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_ObjMeasured_0x250_F_x_ObjMeasured_0x250; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_ObjMeasured_0x293_F_x_ObjMeasured_0x293; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_ObjMeasured_0x294_F_x_ObjMeasured_0x294; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_ObjMeasured_0x295_F_x_ObjMeasured_0x295; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_ObjectChangeStatusLeft1_0x32C_F_x_ObjectChangeStatusLeft1_0x32C; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_ObjectChangeStatusLeft2_0x32D_F_x_ObjectChangeStatusLeft2_0x32D; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_ObjectChangeStatusLeft3_0x32E_F_x_ObjectChangeStatusLeft3_0x32E; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_ObjectChangeStatusLeft4_0x32F_F_x_ObjectChangeStatusLeft4_0x32F; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_ObjectChangeStatusRight1_0x331_F_x_ObjectChangeStatusRight1_0x331; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_ObjectChangeStatusRight2_0x332_F_x_ObjectChangeStatusRight2_0x332; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_ObjectChangeStatusRight3_0x334_F_x_ObjectChangeStatusRight3_0x334; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_ObjectChangeStatusRight4_0x336_F_x_ObjectChangeStatusRight4_0x336; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_ObscuredObjectScene_0x205_F_x_ObscuredObjectScene_0x205; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_OutOfFocusStatus_0x21D_F_x_OutOfFocusStatus_0x21D; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_OverDriveOffSwitchState_0x46C_F_x_OverDriveOffSwitchState_0x46C; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_PWTWheelTorqueLimitationStatus_0x0A7_F_x_PWTWheelTorqueLimitationStatus_0x0A7; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(boolean_NP, RTE_VAR_INIT) Rte_CANIF_F_x_ParkingBrakeMalfunctionStatus_BasicSW_F_x_ParkingBrakeMalfunctionStatus_BasicSW; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_ParkingLotCancel1_0x421_F_x_ParkingLotCancel1_0x421; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_ParkingLotCancel2_0x43D_F_x_ParkingLotCancel2_0x43D; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_ParkingMode_0x43D_F_x_ParkingMode_0x43D; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_PartialBlockage_0x21D_F_x_PartialBlockage_0x21D; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_PedestrianAreaDetection_0x3AF_F_x_PedestrianAreaDetection_0x3AF; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_PedsCmbTtcWarnL4_0x21E_F_x_PedsCmbTtcWarnL4_0x21E; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_PedsCmbTtcWrnL1_0x21D_F_x_PedsCmbTtcWrnL1_0x21D; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_PedsCmbTtcWrnL2_0x21D_F_x_PedsCmbTtcWrnL2_0x21D; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_PedsCmbTtcWrnL3_0x21D_F_x_PedsCmbTtcWrnL3_0x21D; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_PeriodicReverseBuzzerTrigger_0x47F_F_x_PeriodicReverseBuzzerTrigger_0x47F; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_PositionLightsRequest_0x46C_F_x_PositionLightsRequest_0x46C; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_PreRolloverDetection_0x020_F_x_PreRolloverDetection_0x020; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_RadarLowVisibility_0x21D_F_x_RadarLowVisibility_0x21D; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_RadarMisalignment_0x21D_F_x_RadarMisalignment_0x21D; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_RearDefrostEngaged_0x46C_F_x_RearDefrostEngaged_0x46C; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_RearFogLightStateDisplay_0x46C_F_x_RearFogLightStateDisplay_0x46C; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_RearFogLightsRequest_0x46C_F_x_RearFogLightsRequest_0x46C; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_RearParkAssistState_0x502_F_x_RearParkAssistState_0x502; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_RightCloseRangeCutIn_0x21D_F_x_RightCloseRangeCutIn_0x21D; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_RightTripleLaneMark_Confidence_0x420_F_x_RightTripleLaneMark_Confidence_0x420; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_RolloverDetection_0x020_F_x_RolloverDetection_0x020; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_RxInvalid_0x522_F_x_RxInvalid_0x522; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_SailingActive_0x417_F_x_SailingActive_0x417; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_SenBlock_0x522_F_x_SenBlock_0x522; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_SenDefect_0x522_F_x_SenDefect_0x522; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_SenExtErr_0x522_F_x_SenExtErr_0x522; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_SenHighTempErr_0x522_F_x_SenHighTempErr_0x522; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_SeverePitchAxMis_0x21E_F_x_SeverePitchAxMis_0x21E; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_SevereYawAxMis_0x21E_F_x_SevereYawAxMis_0x21E; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_ShifterFailure_0x0A4_F_x_ShifterFailure_0x0A4; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_ShifterParkButtonStatus_0x0A4_F_x_ShifterParkButtonStatus_0x0A4; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_SideRadarLeft_Blockage_0x32C_F_x_SideRadarLeft_Blockage_0x32C; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_SideRadarLeft_Failure_0x32C_F_x_SideRadarLeft_Failure_0x32C; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_SideRadarLeft_FunctionStatus_0x32C_F_x_SideRadarLeft_FunctionStatus_0x32C; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_SideRadarLeft_InitStatus_0x32C_F_x_SideRadarLeft_InitStatus_0x32C; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_SideRadarRight_Blockage_0x331_F_x_SideRadarRight_Blockage_0x331; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_SideRadarRight_Failure_0x331_F_x_SideRadarRight_Failure_0x331; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_SideRadarRight_FunctionStatus_0x331_F_x_SideRadarRight_FunctionStatus_0x331; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_SideRadarRight_InitStatus_0x331_F_x_SideRadarRight_InitStatus_0x331; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_SlotLeftSuitableForDisplay_0x502_F_x_SlotLeftSuitableForDisplay_0x502; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_SlotRightSuitableForDisplay_0x502_F_x_SlotRightSuitableForDisplay_0x502; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_SmearImageSelfGlare_0x21D_F_x_SmearImageSelfGlare_0x21D; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_SmearedSpots_0x21D_F_x_SmearedSpots_0x21D; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_SonarBlockage_0x322_F_x_SonarBlockage_0x322; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_SonarSystemPauseRequest_0x47F_F_x_SonarSystemPauseRequest_0x47F; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_SonarSystemPauseStatus_0x502_F_x_SonarSystemPauseStatus_0x502; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_SplashesRoadSpray_0x21D_F_x_SplashesRoadSpray_0x21D; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_SpotHalosFrozenWindshield_0x21D_F_x_SpotHalosFrozenWindshield_0x21D; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_StartButton_BasicSW_F_x_StartButton_BasicSW; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_SteeringSwitchesFailure_BasicSW_F_x_SteeringSwitchesFailure_BasicSW; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_StopInductiveChargingRequest_0x46F_F_x_StopInductiveChargingRequest_0x46F; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_StopLineValid_0x3FF_F_x_StopLineValid_0x3FF; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_StopSignNotification_0x3FF_F_x_StopSignNotification_0x3FF; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_StopSignWarning_0x3FF_F_x_StopSignWarning_0x3FF; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_SunRay_0x21D_F_x_SunRay_0x21D; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_SwitchOffSESDisturbers_0x46F_F_x_SwitchOffSESDisturbers_0x46F; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_TFL_Notification_0x3FF_F_x_TFL_Notification_0x3FF; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_TFL_Warning_0x3FF_F_x_TFL_Warning_0x3FF; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_TOWmodeSwitch_0x46C_F_x_TOWmodeSwitch_0x46C; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_TPMS_HornRequest_0x418_F_x_TPMS_HornRequest_0x418; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_TPW_HighSensitivityStatus_0x3BD_F_x_TPW_HighSensitivityStatus_0x3BD; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_TPW_TireCheckReminder_0x3BD_F_x_TPW_TireCheckReminder_0x3BD; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_TSFinRegulation_0x202_F_x_TSFinRegulation_0x202; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_TSR_VisionSupSignTypeObject00_0x366_F_x_TSR_VisionSupSignTypeObject00_0x366; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_TSR_VisionSupSignTypeObject01_0x36A_F_x_TSR_VisionSupSignTypeObject01_0x36A; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_TemporaryNoiseDetectedFront_0x323_F_x_TemporaryNoiseDetectedFront_0x323; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_TemporaryNoiseDetectedRear_0x324_F_x_TemporaryNoiseDetectedRear_0x324; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_TrailerPresence_0x47D_F_x_TrailerPresence_0x47D; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_TrunkCancelSwitchState_0x46F_F_x_TrunkCancelSwitchState_0x46F; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_VDC_MILlamp_0x3BD_F_x_VDC_MILlamp_0x3BD; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_VDCactivationState_0x3BD_F_x_VDCactivationState_0x3BD; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_VehCutInHasCutLaneMarkLeft_0x3DF_F_x_VehCutInHasCutLaneMarkLeft_0x3DF; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_VehCutInHasCutLaneMarkRight_0x39F_F_x_VehCutInHasCutLaneMarkRight_0x39F; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_VehCutInHasCutLeft_0x3DF_F_x_VehCutInHasCutLeft_0x3DF; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_VehCutInHasCutRight_0x39F_F_x_VehCutInHasCutRight_0x39F; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_VehicleOutsideLockedState_0x418_F_x_VehicleOutsideLockedState_0x418; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_WAC_APRUN_ActivationState_0x46F_F_x_WAC_APRUN_ActivationState_0x46F; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_WarnBrakeFlag_0x522_F_x_WarnBrakeFlag_0x522; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_WarnFlag_0x522_F_x_WarnFlag_0x522; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_WarningLightsStatus_0x418_F_x_WarningLightsStatus_0x418; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_CANIF_F_x_YMCRequestFlag_0x0B7_F_x_YMCRequestFlag_0x0B7; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(boolean_NP, RTE_VAR_INIT) Rte_CANIF_PF_x_DeliveryInf_0x454_Sigma_PF_x_DeliveryInf_0x454_Sigma; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(boolean_NP, RTE_VAR_INIT) Rte_CANIF_PF_x_MsgRcvDoneId438_PF_x_MsgRcvDoneId438; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_PV_x_BCM_A4_DeliveryModeInformation_v2_PV_x_BCM_A4_DeliveryModeInformation_v2; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_PV_x_ECM_A11_CruiseControlStatus_PV_x_ECM_A11_CruiseControlStatus; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_PV_x_EPKB_A2_EPB_SwitchState_PV_x_EPKB_A2_EPB_SwitchState; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(boolean_NP, RTE_VAR_INIT) Rte_CANIF_PV_x_IDM_A3_CruiseControlInhibitRequest_PV_x_IDM_A3_CruiseControlInhibitRequest; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt32, RTE_VAR_INIT) Rte_CANIF_PV_x_Mileage_PV_x_Mileage; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CANIF_V_G_ADA_CornerDecelEngineBrakeTarget_0x0B7_V_G_ADA_CornerDecelEngineBrakeTarget_0x0B7; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CANIF_V_G_ADA_DecelEngineBrakeTarget_0x0B7_V_G_ADA_DecelEngineBrakeTarget_0x0B7; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_G_EPB_RequestTargetDeceleration_0x25C_V_G_EPB_RequestTargetDeceleration_0x25C; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_G_LongitudinalAccelCorrected_0x0B4_V_G_LongitudinalAccelCorrected_0x0B4; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_G_LongitudinalAccelRaw_0x0B4_V_G_LongitudinalAccelRaw_0x0B4; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_G_TransversalAccelCorrected_0x0B4_V_G_TransversalAccelCorrected_0x0B4; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_G_TransversalAccelRaw_0x0B4_V_G_TransversalAccelRaw_0x0B4; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_Nm_BMC_EngineTorqueRequest_0x0B7_V_Nm_BMC_EngineTorqueRequest_0x0B7; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CANIF_V_Nm_BrakeWheelTorqueEstimation_0x206_V_Nm_BrakeWheelTorqueEstimation_0x206; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CANIF_V_Nm_CCSLBrakeWheelTorqueRequest_0x0A7_V_Nm_CCSLBrakeWheelTorqueRequest_0x0A7; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_Nm_DriverSteeringWheelTorque_0x0AC_V_Nm_DriverSteeringWheelTorque_0x0AC; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_Nm_DriverWheelTorqueRequest_0x207_V_Nm_DriverWheelTorqueRequest_0x207; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_Nm_ECM_EstimatedPWTWheelTorque_BasicSW_V_Nm_ECM_EstimatedPWTWheelTorque_BasicSW; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_Nm_ETS_SlowWheelTorqueRequest_0x25F_V_Nm_ETS_SlowWheelTorqueRequest_0x25F; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_Nm_EstimatedFinalClutchTorque_0x25F_V_Nm_EstimatedFinalClutchTorque_0x25F; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_Nm_MaxInstantPowerTrainWheelTorque_BasicSW_V_Nm_MaxInstantPowerTrainWheelTorque_BasicSW; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_Nm_MaxPowerTrainWheelTorque_BasicSW_V_Nm_MaxPowerTrainWheelTorque_BasicSW; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_Nm_MeanEffectiveTorque_0x0AA_V_Nm_MeanEffectiveTorque_0x0AA; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_Nm_MinPowerTrainWheelTorque_BasicSW_V_Nm_MinPowerTrainWheelTorque_BasicSW; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt32, RTE_VAR_INIT) Rte_CANIF_V_Nm_MinWheelTorqueForRelease_0x206_V_Nm_MinWheelTorqueForRelease_0x206; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_Nm_RequestedWheelTorqueAfterProc_0x0B6_V_Nm_RequestedWheelTorqueAfterProc_0x0B6; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CANIF_V_V_BatteryVoltage_0x47C_V_V_BatteryVoltage_0x47C; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint16_NP, RTE_VAR_INIT) Rte_CANIF_V_V_ProducerVoltageRequest_0x25B_V_V_ProducerVoltageRequest_0x25B; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_bar_BrakingPressure_BasicSW_V_bar_BrakingPressure_BasicSW; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_cm_AccurateOdometer_0x3BD_V_cm_AccurateOdometer_0x3BD; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_cm_DetectionDistanceX_0x322_V_cm_DetectionDistanceX_0x322; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt8, RTE_VAR_INIT) Rte_CANIF_V_cm_DetectionDistanceY_0x322_V_cm_DetectionDistanceY_0x322; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_cm_DetectionLengthFront_ILIR_0x323_V_cm_DetectionLengthFront_ILIR_0x323; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_cm_DetectionLengthFront_ILOL_0x323_V_cm_DetectionLengthFront_ILOL_0x323; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_cm_DetectionLengthFront_IL_0x323_V_cm_DetectionLengthFront_IL_0x323; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_cm_DetectionLengthFront_IRIL_0x325_V_cm_DetectionLengthFront_IRIL_0x325; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_cm_DetectionLengthFront_IROR_0x325_V_cm_DetectionLengthFront_IROR_0x325; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_cm_DetectionLengthFront_IR_0x325_V_cm_DetectionLengthFront_IR_0x325; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_cm_DetectionLengthFront_OLIL_0x323_V_cm_DetectionLengthFront_OLIL_0x323; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_cm_DetectionLengthFront_OL_0x323_V_cm_DetectionLengthFront_OL_0x323; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_cm_DetectionLengthFront_ORIR_0x323_V_cm_DetectionLengthFront_ORIR_0x323; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_cm_DetectionLengthFront_OR_0x325_V_cm_DetectionLengthFront_OR_0x325; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_cm_DetectionLengthRear_ILIR_0x324_V_cm_DetectionLengthRear_ILIR_0x324; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_cm_DetectionLengthRear_ILOL_0x324_V_cm_DetectionLengthRear_ILOL_0x324; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_cm_DetectionLengthRear_IL_0x324_V_cm_DetectionLengthRear_IL_0x324; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_cm_DetectionLengthRear_IRIL_0x325_V_cm_DetectionLengthRear_IRIL_0x325; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_cm_DetectionLengthRear_IROR_0x325_V_cm_DetectionLengthRear_IROR_0x325; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_cm_DetectionLengthRear_IR_0x325_V_cm_DetectionLengthRear_IR_0x325; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_cm_DetectionLengthRear_OLIL_0x324_V_cm_DetectionLengthRear_OLIL_0x324; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_cm_DetectionLengthRear_OL_0x324_V_cm_DetectionLengthRear_OL_0x324; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_cm_DetectionLengthRear_ORIR_0x324_V_cm_DetectionLengthRear_ORIR_0x324; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_cm_DetectionLengthRear_OR_0x325_V_cm_DetectionLengthRear_OR_0x325; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_cm_LineWidth1_0x421_V_cm_LineWidth1_0x421; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_cm_LineWidth2_0x43D_V_cm_LineWidth2_0x43D; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt8, RTE_VAR_INIT) Rte_CANIF_V_cm_ParkingLotPositionX1_0x421_V_cm_ParkingLotPositionX1_0x421; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt8, RTE_VAR_INIT) Rte_CANIF_V_cm_ParkingLotPositionX2_0x43D_V_cm_ParkingLotPositionX2_0x43D; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_cm_ParkingLotPositionY1_0x421_V_cm_ParkingLotPositionY1_0x421; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_cm_ParkingLotPositionY2_0x43D_V_cm_ParkingLotPositionY2_0x43D; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt8, RTE_VAR_INIT) Rte_CANIF_V_degC_EngineAirTemp_0x417_V_degC_EngineAirTemp_0x417; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(sint16_NP, RTE_VAR_INIT) Rte_CANIF_V_degC_EngineCoolantTemp_0x417_V_degC_EngineCoolantTemp_0x417; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(sint16_NP, RTE_VAR_INIT) Rte_CANIF_V_degC_GearboxOilTemperature_0x46E_V_degC_GearboxOilTemperature_0x46E; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint16_NP, RTE_VAR_INIT) Rte_CANIF_V_degC_RST_ATClutchTemperature_0x46E_V_degC_RST_ATClutchTemperature_0x46E; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt32, RTE_VAR_INIT) Rte_CANIF_V_deg_EPS_AngleSensor_0x0AC_V_deg_EPS_AngleSensor_0x0AC; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt32, RTE_VAR_INIT) Rte_CANIF_V_deg_FAP_SteeringAngleRequest_0x19A_V_deg_FAP_SteeringAngleRequest_0x19A; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_deg_ObjectAngle_0x2C4_V_deg_ObjectAngle_0x2C4; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_deg_ObjectAngle_0x2C5_V_deg_ObjectAngle_0x2C5; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_deg_ObjectAngle_0x2C7_V_deg_ObjectAngle_0x2C7; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_deg_ObjectAngle_0x2C8_V_deg_ObjectAngle_0x2C8; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_deg_ObjectAngle_0x2C9_V_deg_ObjectAngle_0x2C9; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_deg_ObjectAngle_0x2CD_V_deg_ObjectAngle_0x2CD; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_deg_ObjectAngle_0x2CE_V_deg_ObjectAngle_0x2CE; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_deg_ObjectAngle_0x2CF_V_deg_ObjectAngle_0x2CF; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_deg_ObjectAngle_0x2D0_V_deg_ObjectAngle_0x2D0; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_deg_ObjectAngle_0x2D6_V_deg_ObjectAngle_0x2D6; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_deg_ObjectAngle_0x2D7_V_deg_ObjectAngle_0x2D7; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_deg_ObjectAngle_0x2D8_V_deg_ObjectAngle_0x2D8; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt8, RTE_VAR_INIT) Rte_CANIF_V_deg_ParkingLotAngle1_0x421_V_deg_ParkingLotAngle1_0x421; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt8, RTE_VAR_INIT) Rte_CANIF_V_deg_ParkingLotAngle2_0x43D_V_deg_ParkingLotAngle2_0x43D; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt8, RTE_VAR_INIT) Rte_CANIF_V_deg_RearWheelAnglePosition_0x179_V_deg_RearWheelAnglePosition_0x179; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt8, RTE_VAR_INIT) Rte_CANIF_V_deg_SlopeEstimation_BasicSW_V_deg_SlopeEstimation_BasicSW; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_deg_SteeringWheelAngleCorrected_0x0AB_V_deg_SteeringWheelAngleCorrected_0x0AB; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_deg_SteeringWheelAngleRaw_0x0A8_V_deg_SteeringWheelAngleRaw_0x0A8; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_degps2_GradientYawRate_0x0FF_V_degps2_GradientYawRate_0x0FF; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_degps_DriverTargetYawRate_0x0FF_V_degps_DriverTargetYawRate_0x0FF; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_degps_ObjectAngleRate_0x2C4_V_degps_ObjectAngleRate_0x2C4; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_degps_ObjectAngleRate_0x2C5_V_degps_ObjectAngleRate_0x2C5; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_degps_ObjectAngleRate_0x2C7_V_degps_ObjectAngleRate_0x2C7; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_degps_ObjectAngleRate_0x2C8_V_degps_ObjectAngleRate_0x2C8; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_degps_ObjectAngleRate_0x2C9_V_degps_ObjectAngleRate_0x2C9; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_degps_ObjectAngleRate_0x2CD_V_degps_ObjectAngleRate_0x2CD; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_degps_ObjectAngleRate_0x2CE_V_degps_ObjectAngleRate_0x2CE; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_degps_ObjectAngleRate_0x2CF_V_degps_ObjectAngleRate_0x2CF; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_degps_ObjectAngleRate_0x2D0_V_degps_ObjectAngleRate_0x2D0; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_degps_ObjectAngleRate_0x2D6_V_degps_ObjectAngleRate_0x2D6; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_degps_ObjectAngleRate_0x2D7_V_degps_ObjectAngleRate_0x2D7; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_degps_ObjectAngleRate_0x2D8_V_degps_ObjectAngleRate_0x2D8; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_degps_SteeringWheelRotationSpeed_0x0A8_V_degps_SteeringWheelRotationSpeed_0x0A8; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_degps_YawRadar_0x522_V_degps_YawRadar_0x522; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_degps_YawRateCorr_BasicSW_V_degps_YawRateCorr_BasicSW; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_degps_YawRateRaw_BasicSW_V_degps_YawRateRaw_BasicSW; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CANIF_V_kph_VehicleSpeedBody_0x289_V_kph_VehicleSpeedBody_0x289; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CANIF_V_kph_VehicleSpeed_BasicSW_V_kph_VehicleSpeed_BasicSW; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CANIF_V_m_CamCrossRoadDistance_0x302_V_m_CamCrossRoadDistance_0x302; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_m_CamLatDistStdDeviation00_0x340_V_m_CamLatDistStdDeviation00_0x340; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_m_CamLatDistStdDeviation01_0x35C_V_m_CamLatDistStdDeviation01_0x35C; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_m_CamLatDistStdDeviation02_0x35D_V_m_CamLatDistStdDeviation02_0x35D; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_m_CamLatDistStdDeviation03_0x390_V_m_CamLatDistStdDeviation03_0x390; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_m_CamLatDistStdDeviation04_0x393_V_m_CamLatDistStdDeviation04_0x393; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_m_CamLatDistStdDeviation05_0x394_V_m_CamLatDistStdDeviation05_0x394; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_m_CamLatDistStdDeviation06_0x39E_V_m_CamLatDistStdDeviation06_0x39E; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_m_CamLatDistStdDeviation07_0x3B9_V_m_CamLatDistStdDeviation07_0x3B9; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_m_CamLatDistStdDeviation08_0x3A9_V_m_CamLatDistStdDeviation08_0x3A9; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_m_CamLatDistStdDeviation09_0x3AE_V_m_CamLatDistStdDeviation09_0x3AE; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_m_CamLatDistStdDeviation10_0x3B8_V_m_CamLatDistStdDeviation10_0x3B8; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_m_CamLatDistStdDeviation11_0x3BB_V_m_CamLatDistStdDeviation11_0x3BB; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_m_CamLongiDistStdDeviation00_0x340_V_m_CamLongiDistStdDeviation00_0x340; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_m_CamLongiDistStdDeviation01_0x35C_V_m_CamLongiDistStdDeviation01_0x35C; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_m_CamLongiDistStdDeviation02_0x35D_V_m_CamLongiDistStdDeviation02_0x35D; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_m_CamLongiDistStdDeviation03_0x390_V_m_CamLongiDistStdDeviation03_0x390; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_m_CamLongiDistStdDeviation04_0x393_V_m_CamLongiDistStdDeviation04_0x393; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_m_CamLongiDistStdDeviation05_0x394_V_m_CamLongiDistStdDeviation05_0x394; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_m_CamLongiDistStdDeviation06_0x39E_V_m_CamLongiDistStdDeviation06_0x39E; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_m_CamLongiDistStdDeviation07_0x3B9_V_m_CamLongiDistStdDeviation07_0x3B9; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_m_CamLongiDistStdDeviation08_0x3A9_V_m_CamLongiDistStdDeviation08_0x3A9; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_m_CamLongiDistStdDeviation09_0x3AE_V_m_CamLongiDistStdDeviation09_0x3AE; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_m_CamLongiDistStdDeviation10_0x3B8_V_m_CamLongiDistStdDeviation10_0x3B8; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_m_CamLongiDistStdDeviation11_0x3BB_V_m_CamLongiDistStdDeviation11_0x3BB; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_m_CamPredictImpactLocationObject00_0x340_V_m_CamPredictImpactLocationObject00_0x340; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_m_CamPredictImpactLocationObject01_0x35C_V_m_CamPredictImpactLocationObject01_0x35C; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_m_CamPredictImpactLocationObject02_0x35D_V_m_CamPredictImpactLocationObject02_0x35D; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_m_CamPredictImpactLocationObject03_0x390_V_m_CamPredictImpactLocationObject03_0x390; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_m_CamPredictImpactLocationObject04_0x393_V_m_CamPredictImpactLocationObject04_0x393; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_m_CamPredictImpactLocationObject05_0x394_V_m_CamPredictImpactLocationObject05_0x394; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_m_CamPredictImpactLocationObject06_0x39E_V_m_CamPredictImpactLocationObject06_0x39E; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_m_CamPredictImpactLocationObject07_0x3B9_V_m_CamPredictImpactLocationObject07_0x3B9; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_m_CamPredictImpactLocationObject08_0x3A9_V_m_CamPredictImpactLocationObject08_0x3A9; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_m_CamPredictImpactLocationObject09_0x3AE_V_m_CamPredictImpactLocationObject09_0x3AE; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_m_CamPredictImpactLocationObject10_0x3B8_V_m_CamPredictImpactLocationObject10_0x3B8; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_m_CamPredictImpactLocationObject11_0x3BB_V_m_CamPredictImpactLocationObject11_0x3BB; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CANIF_V_m_CollisionOverlap_0x2EE_V_m_CollisionOverlap_0x2EE; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CANIF_V_m_CrossWalkOnPathDistance_0x302_V_m_CrossWalkOnPathDistance_0x302; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CANIF_V_m_CyclistAreaDistance_0x3AF_V_m_CyclistAreaDistance_0x3AF; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CANIF_V_m_CyclistLaneDistance_0x3AF_V_m_CyclistLaneDistance_0x3AF; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CANIF_V_m_CyclistLaneOnPathDistance_0x3AF_V_m_CyclistLaneOnPathDistance_0x3AF; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt8, RTE_VAR_INIT) Rte_CANIF_V_m_FreeSpace_LatDistFar1_0x362_V_m_FreeSpace_LatDistFar1_0x362; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt8, RTE_VAR_INIT) Rte_CANIF_V_m_FreeSpace_LatDistFar2_0x362_V_m_FreeSpace_LatDistFar2_0x362; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt8, RTE_VAR_INIT) Rte_CANIF_V_m_FreeSpace_LatDistFar3_0x362_V_m_FreeSpace_LatDistFar3_0x362; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_m_FreeSpace_LatDistLeftNear0_0x361_V_m_FreeSpace_LatDistLeftNear0_0x361; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_m_FreeSpace_LatDistRightNear0_0x361_V_m_FreeSpace_LatDistRightNear0_0x361; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CANIF_V_m_FreeSpace_LongiDistFar1_0x362_V_m_FreeSpace_LongiDistFar1_0x362; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CANIF_V_m_FreeSpace_LongiDistFar2_0x362_V_m_FreeSpace_LongiDistFar2_0x362; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CANIF_V_m_FreeSpace_LongiDistFar3_0x362_V_m_FreeSpace_LongiDistFar3_0x362; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CANIF_V_m_FreeSpace_LongiDistFarCenter_0x362_V_m_FreeSpace_LongiDistFarCenter_0x362; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CANIF_V_m_FreeSpace_LongiDistLeftNear0_0x361_V_m_FreeSpace_LongiDistLeftNear0_0x361; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CANIF_V_m_FreeSpace_LongiDistRightNear0_0x361_V_m_FreeSpace_LongiDistRightNear0_0x361; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_m_FusedLane_OffsetCoef_0x3BC_V_m_FusedLane_OffsetCoef_0x3BC; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(sint16_NP, RTE_VAR_INIT) Rte_CANIF_V_m_JNC_Distance_0x3FF_V_m_JNC_Distance_0x3FF; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_m_LatDist_ACC_0x205_V_m_LatDist_ACC_0x205; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_m_LateralDis_0x21F_V_m_LateralDis_0x21F; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_m_LateralDis_0x220_V_m_LateralDis_0x220; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_m_LateralDis_0x222_V_m_LateralDis_0x222; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_m_LateralDis_0x223_V_m_LateralDis_0x223; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_m_LateralDis_0x240_V_m_LateralDis_0x240; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_m_LateralDis_0x241_V_m_LateralDis_0x241; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_m_LateralDis_0x246_V_m_LateralDis_0x246; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_m_LateralDis_0x247_V_m_LateralDis_0x247; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_m_LateralDis_0x248_V_m_LateralDis_0x248; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_m_LateralDis_0x262_V_m_LateralDis_0x262; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_m_LateralDis_0x263_V_m_LateralDis_0x263; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_m_LateralDis_0x264_V_m_LateralDis_0x264; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_m_LateralDistanceObject01_0x52D_V_m_LateralDistanceObject01_0x52D; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_m_LeftLineOffset_0x2CA_V_m_LeftLineOffset_0x2CA; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_m_LeftLineViewRange_0x2CC_V_m_LeftLineViewRange_0x2CC; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_m_LeftTrippleLaneMark_Width_0x41E_V_m_LeftTrippleLaneMark_Width_0x41E; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_m_Left_Lane_Mark_Width_0x2EC_V_m_Left_Lane_Mark_Width_0x2EC; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CANIF_V_m_LongiDist_ACC_0x205_V_m_LongiDist_ACC_0x205; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CANIF_V_m_LongitudinalDis_0x21F_V_m_LongitudinalDis_0x21F; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CANIF_V_m_LongitudinalDis_0x220_V_m_LongitudinalDis_0x220; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CANIF_V_m_LongitudinalDis_0x222_V_m_LongitudinalDis_0x222; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CANIF_V_m_LongitudinalDis_0x223_V_m_LongitudinalDis_0x223; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CANIF_V_m_LongitudinalDis_0x240_V_m_LongitudinalDis_0x240; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CANIF_V_m_LongitudinalDis_0x241_V_m_LongitudinalDis_0x241; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CANIF_V_m_LongitudinalDis_0x246_V_m_LongitudinalDis_0x246; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CANIF_V_m_LongitudinalDis_0x247_V_m_LongitudinalDis_0x247; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CANIF_V_m_LongitudinalDis_0x248_V_m_LongitudinalDis_0x248; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CANIF_V_m_LongitudinalDis_0x262_V_m_LongitudinalDis_0x262; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CANIF_V_m_LongitudinalDis_0x263_V_m_LongitudinalDis_0x263; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CANIF_V_m_LongitudinalDis_0x264_V_m_LongitudinalDis_0x264; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CANIF_V_m_NearestTrafficLightDistance_0x3DF_V_m_NearestTrafficLightDistance_0x3DF; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint16_NP, RTE_VAR_INIT) Rte_CANIF_V_m_NextLeftLineMarkWidth_0x40A_V_m_NextLeftLineMarkWidth_0x40A; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_m_NextLeftLineOffset_0x40A_V_m_NextLeftLineOffset_0x40A; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_m_NextLeftLineViewRange_0x40A_V_m_NextLeftLineViewRange_0x40A; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_m_NextRighLineOffset_0x41B_V_m_NextRighLineOffset_0x41B; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint16_NP, RTE_VAR_INIT) Rte_CANIF_V_m_NextRightLineMarkWidth_0x41B_V_m_NextRightLineMarkWidth_0x41B; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_m_NextRightLineViewRange_0x41B_V_m_NextRightLineViewRange_0x41B; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CANIF_V_m_Obj0Dist_0x52B_V_m_Obj0Dist_0x52B; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_m_Obj0LatDist_0x52B_V_m_Obj0LatDist_0x52B; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_m_Obj0Length_0x52C_V_m_Obj0Length_0x52C; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_m_Obj0Traject_0x52B_V_m_Obj0Traject_0x52B; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CANIF_V_m_Obj0Width_0x52C_V_m_Obj0Width_0x52C; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CANIF_V_m_Obj1Dist_0x52D_V_m_Obj1Dist_0x52D; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_m_Obj1Length_0x52E_V_m_Obj1Length_0x52E; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_m_Obj1Traject_0x52D_V_m_Obj1Traject_0x52D; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CANIF_V_m_Obj1Width_0x52E_V_m_Obj1Width_0x52E; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CANIF_V_m_Obj2Dist_0x470_V_m_Obj2Dist_0x470; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_m_Obj2LatDist_0x470_V_m_Obj2LatDist_0x470; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_m_Obj2Length_0x471_V_m_Obj2Length_0x471; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_m_Obj2Traject_0x470_V_m_Obj2Traject_0x470; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CANIF_V_m_Obj2Width_0x471_V_m_Obj2Width_0x471; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CANIF_V_m_Obj3Dist_0x472_V_m_Obj3Dist_0x472; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_m_Obj3LatDist_0x472_V_m_Obj3LatDist_0x472; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_m_Obj3Length_0x473_V_m_Obj3Length_0x473; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_m_Obj3Traject_0x472_V_m_Obj3Traject_0x472; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CANIF_V_m_Obj3Width_0x473_V_m_Obj3Width_0x473; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CANIF_V_m_Obj4Dist_0x474_V_m_Obj4Dist_0x474; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_m_Obj4LatDist_0x474_V_m_Obj4LatDist_0x474; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_m_Obj4Length_0x475_V_m_Obj4Length_0x475; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_m_Obj4Traject_0x474_V_m_Obj4Traject_0x474; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CANIF_V_m_Obj4Width_0x475_V_m_Obj4Width_0x475; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CANIF_V_m_Obj5Dist_0x476_V_m_Obj5Dist_0x476; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_m_Obj5LatDist_0x476_V_m_Obj5LatDist_0x476; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_m_Obj5Length_0x477_V_m_Obj5Length_0x477; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_m_Obj5Traject_0x476_V_m_Obj5Traject_0x476; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CANIF_V_m_Obj5Width_0x477_V_m_Obj5Width_0x477; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CANIF_V_m_Obj6Dist_0x57B_V_m_Obj6Dist_0x57B; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_m_Obj6LatDist_0x57B_V_m_Obj6LatDist_0x57B; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_m_Obj6Traject_0x57B_V_m_Obj6Traject_0x57B; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CANIF_V_m_ObjDist_0x24A_V_m_ObjDist_0x24A; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CANIF_V_m_ObjDist_0x24B_V_m_ObjDist_0x24B; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CANIF_V_m_ObjDist_0x24C_V_m_ObjDist_0x24C; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CANIF_V_m_ObjDist_0x24D_V_m_ObjDist_0x24D; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CANIF_V_m_ObjDist_0x24E_V_m_ObjDist_0x24E; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CANIF_V_m_ObjDist_0x24F_V_m_ObjDist_0x24F; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CANIF_V_m_ObjDist_0x250_V_m_ObjDist_0x250; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CANIF_V_m_ObjDist_0x293_V_m_ObjDist_0x293; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CANIF_V_m_ObjDist_0x294_V_m_ObjDist_0x294; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CANIF_V_m_ObjDist_0x295_V_m_ObjDist_0x295; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_m_ObjLatDist_0x24A_V_m_ObjLatDist_0x24A; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_m_ObjLatDist_0x24B_V_m_ObjLatDist_0x24B; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_m_ObjLatDist_0x24C_V_m_ObjLatDist_0x24C; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_m_ObjLatDist_0x24D_V_m_ObjLatDist_0x24D; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_m_ObjLatDist_0x24E_V_m_ObjLatDist_0x24E; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_m_ObjLatDist_0x24F_V_m_ObjLatDist_0x24F; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_m_ObjLatDist_0x250_V_m_ObjLatDist_0x250; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_m_ObjLatDist_0x293_V_m_ObjLatDist_0x293; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_m_ObjLatDist_0x294_V_m_ObjLatDist_0x294; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_m_ObjLatDist_0x295_V_m_ObjLatDist_0x295; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_m_ObjLength_0x24A_V_m_ObjLength_0x24A; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_m_ObjLength_0x24B_V_m_ObjLength_0x24B; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_m_ObjLength_0x24C_V_m_ObjLength_0x24C; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_m_ObjLength_0x24D_V_m_ObjLength_0x24D; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_m_ObjLength_0x24E_V_m_ObjLength_0x24E; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_m_ObjLength_0x24F_V_m_ObjLength_0x24F; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_m_ObjLength_0x250_V_m_ObjLength_0x250; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_m_ObjLength_0x293_V_m_ObjLength_0x293; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_m_ObjLength_0x294_V_m_ObjLength_0x294; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_m_ObjLength_0x295_V_m_ObjLength_0x295; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt8, RTE_VAR_INIT) Rte_CANIF_V_m_ObjRcs_0x24A_V_m_ObjRcs_0x24A; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt8, RTE_VAR_INIT) Rte_CANIF_V_m_ObjRcs_0x24B_V_m_ObjRcs_0x24B; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt8, RTE_VAR_INIT) Rte_CANIF_V_m_ObjRcs_0x24C_V_m_ObjRcs_0x24C; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt8, RTE_VAR_INIT) Rte_CANIF_V_m_ObjRcs_0x24D_V_m_ObjRcs_0x24D; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt8, RTE_VAR_INIT) Rte_CANIF_V_m_ObjRcs_0x24E_V_m_ObjRcs_0x24E; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt8, RTE_VAR_INIT) Rte_CANIF_V_m_ObjRcs_0x24F_V_m_ObjRcs_0x24F; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt8, RTE_VAR_INIT) Rte_CANIF_V_m_ObjRcs_0x250_V_m_ObjRcs_0x250; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt8, RTE_VAR_INIT) Rte_CANIF_V_m_ObjRcs_0x293_V_m_ObjRcs_0x293; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt8, RTE_VAR_INIT) Rte_CANIF_V_m_ObjRcs_0x294_V_m_ObjRcs_0x294; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt8, RTE_VAR_INIT) Rte_CANIF_V_m_ObjRcs_0x295_V_m_ObjRcs_0x295; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_m_ObjWdth_0x24A_V_m_ObjWdth_0x24A; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_m_ObjWdth_0x24B_V_m_ObjWdth_0x24B; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_m_ObjWdth_0x24C_V_m_ObjWdth_0x24C; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_m_ObjWdth_0x24D_V_m_ObjWdth_0x24D; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_m_ObjWdth_0x24E_V_m_ObjWdth_0x24E; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_m_ObjWdth_0x24F_V_m_ObjWdth_0x24F; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_m_ObjWdth_0x250_V_m_ObjWdth_0x250; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_m_ObjWdth_0x293_V_m_ObjWdth_0x293; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_m_ObjWdth_0x294_V_m_ObjWdth_0x294; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_m_ObjWdth_0x295_V_m_ObjWdth_0x295; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CANIF_V_m_PedestrianAreaDistance_0x3AF_V_m_PedestrianAreaDistance_0x3AF; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CANIF_V_m_RawLength_0x522_V_m_RawLength_0x522; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CANIF_V_m_RawWidth_0x522_V_m_RawWidth_0x522; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_m_RelativeDistanceXleft1_0x32C_V_m_RelativeDistanceXleft1_0x32C; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_m_RelativeDistanceXleft2_0x32D_V_m_RelativeDistanceXleft2_0x32D; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_m_RelativeDistanceXleft3_0x32E_V_m_RelativeDistanceXleft3_0x32E; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_m_RelativeDistanceXleft4_0x32F_V_m_RelativeDistanceXleft4_0x32F; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_m_RelativeDistanceXright1_0x331_V_m_RelativeDistanceXright1_0x331; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_m_RelativeDistanceXright2_0x332_V_m_RelativeDistanceXright2_0x332; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_m_RelativeDistanceXright3_0x334_V_m_RelativeDistanceXright3_0x334; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_m_RelativeDistanceXright4_0x336_V_m_RelativeDistanceXright4_0x336; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_m_RelativeDistanceYleft1_0x32C_V_m_RelativeDistanceYleft1_0x32C; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_m_RelativeDistanceYleft2_0x32D_V_m_RelativeDistanceYleft2_0x32D; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_m_RelativeDistanceYleft3_0x32E_V_m_RelativeDistanceYleft3_0x32E; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_m_RelativeDistanceYleft4_0x32F_V_m_RelativeDistanceYleft4_0x32F; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_m_RelativeDistanceYright1_0x331_V_m_RelativeDistanceYright1_0x331; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_m_RelativeDistanceYright2_0x332_V_m_RelativeDistanceYright2_0x332; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_m_RelativeDistanceYright3_0x334_V_m_RelativeDistanceYright3_0x334; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_m_RelativeDistanceYright4_0x336_V_m_RelativeDistanceYright4_0x336; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_m_RightLineOffset_0x2CB_V_m_RightLineOffset_0x2CB; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_m_RightLineViewRange_0x2CC_V_m_RightLineViewRange_0x2CC; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_m_RightTrippleLaneMark_Width_0x420_V_m_RightTrippleLaneMark_Width_0x420; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_m_Right_Lane_Mark_Width_0x2EC_V_m_Right_Lane_Mark_Width_0x2EC; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_m_RoadEstimYLeft_0x479_V_m_RoadEstimYLeft_0x479; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_m_RoadEstimYRight_0x479_V_m_RoadEstimYRight_0x479; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_m_StopLineDist_0x3FF_V_m_StopLineDist_0x3FF; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_m_TFL_PosXobject00_0x311_V_m_TFL_PosXobject00_0x311; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_m_TFL_PosXobject01_0x32A_V_m_TFL_PosXobject01_0x32A; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_m_TFL_PosXobject02_0x34B_V_m_TFL_PosXobject02_0x34B; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_m_TFL_PosYobject00_0x311_V_m_TFL_PosYobject00_0x311; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_m_TFL_PosYobject01_0x32A_V_m_TFL_PosYobject01_0x32A; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_m_TFL_PosYobject02_0x34B_V_m_TFL_PosYobject02_0x34B; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CANIF_V_m_TFL_PosZobject00_0x311_V_m_TFL_PosZobject00_0x311; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CANIF_V_m_TFL_PosZobject01_0x32A_V_m_TFL_PosZobject01_0x32A; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CANIF_V_m_TFL_PosZobject02_0x34B_V_m_TFL_PosZobject02_0x34B; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_m_TFL_WidthObject00_0x311_V_m_TFL_WidthObject00_0x311; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_m_TFL_WidthObject01_0x32A_V_m_TFL_WidthObject01_0x32A; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_m_TFL_WidthObject02_0x34B_V_m_TFL_WidthObject02_0x34B; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_m_TSR_SignDistanceObject00_0x366_V_m_TSR_SignDistanceObject00_0x366; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_m_TSR_SignDistanceObject01_0x36A_V_m_TSR_SignDistanceObject01_0x36A; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_m_TSR_SignHeightObject00_0x366_V_m_TSR_SignHeightObject00_0x366; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_m_TSR_SignHeightObject01_0x36A_V_m_TSR_SignHeightObject01_0x36A; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_m_TSR_SignLateralDistanceObject00_0x366_V_m_TSR_SignLateralDistanceObject00_0x366; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_m_TSR_SignLateralDistanceObject01_0x36A_V_m_TSR_SignLateralDistanceObject01_0x36A; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_m_VehCutInBackDistanceLeft_0x3CF_V_m_VehCutInBackDistanceLeft_0x3CF; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CANIF_V_m_VehCutInBackDistanceRight_0x363_V_m_VehCutInBackDistanceRight_0x363; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(sint16_NP, RTE_VAR_INIT) Rte_CANIF_V_m_VehCutInBackLateralLeft_0x3CF_V_m_VehCutInBackLateralLeft_0x3CF; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_m_VehCutInBackLateralRight_0x363_V_m_VehCutInBackLateralRight_0x363; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CANIF_V_m_VehCutInFrontDistanceLeft_0x3CF_V_m_VehCutInFrontDistanceLeft_0x3CF; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CANIF_V_m_VehCutInFrontDistanceRight_0x363_V_m_VehCutInFrontDistanceRight_0x363; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_m_VehCutInFrontLateralLeft_0x3CF_V_m_VehCutInFrontLateralLeft_0x3CF; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_m_VehCutInFrontLateralRight_0x363_V_m_VehCutInFrontLateralRight_0x363; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_m_Width_0x21F_V_m_Width_0x21F; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_m_Width_0x220_V_m_Width_0x220; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_m_Width_0x222_V_m_Width_0x222; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_m_Width_0x223_V_m_Width_0x223; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_m_Width_0x240_V_m_Width_0x240; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_m_Width_0x241_V_m_Width_0x241; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_m_Width_0x246_V_m_Width_0x246; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_m_Width_0x247_V_m_Width_0x247; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_m_Width_0x248_V_m_Width_0x248; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_m_Width_0x262_V_m_Width_0x262; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_m_Width_0x263_V_m_Width_0x263; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_m_Width_0x264_V_m_Width_0x264; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_mps2_AccelAbs_0x266_V_mps2_AccelAbs_0x266; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_mps2_AccelAbs_0x267_V_mps2_AccelAbs_0x267; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_mps2_AccelAbs_0x268_V_mps2_AccelAbs_0x268; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_mps2_AccelAbs_0x269_V_mps2_AccelAbs_0x269; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_mps2_AccelAbs_0x26E_V_mps2_AccelAbs_0x26E; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_mps2_AccelAbs_0x26F_V_mps2_AccelAbs_0x26F; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_mps2_AccelAbs_0x2A3_V_mps2_AccelAbs_0x2A3; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_mps2_AccelAbs_0x2A4_V_mps2_AccelAbs_0x2A4; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_mps2_AccelAbs_0x2AC_V_mps2_AccelAbs_0x2AC; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_mps2_AccelAbs_0x2AD_V_mps2_AccelAbs_0x2AD; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_mps2_AccelAbs_0x2AE_V_mps2_AccelAbs_0x2AE; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_mps2_AccelAbs_0x2AF_V_mps2_AccelAbs_0x2AF; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_mps2_AccelAbs_ACC_0x205_V_mps2_AccelAbs_ACC_0x205; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_mps2_Obj0RelatAccel_0x52C_V_mps2_Obj0RelatAccel_0x52C; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(sint16_NP, RTE_VAR_INIT) Rte_CANIF_V_mps2_Obj1RelatAccel_0x52E_V_mps2_Obj1RelatAccel_0x52E; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(sint16_NP, RTE_VAR_INIT) Rte_CANIF_V_mps2_Obj2RelatAccel_0x471_V_mps2_Obj2RelatAccel_0x471; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(sint16_NP, RTE_VAR_INIT) Rte_CANIF_V_mps2_Obj3RelatAccel_0x473_V_mps2_Obj3RelatAccel_0x473; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(sint16_NP, RTE_VAR_INIT) Rte_CANIF_V_mps2_Obj4RelatAccel_0x475_V_mps2_Obj4RelatAccel_0x475; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(sint16_NP, RTE_VAR_INIT) Rte_CANIF_V_mps2_Obj5RelatAccel_0x477_V_mps2_Obj5RelatAccel_0x477; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_mps2_Obj6RelatAccel_0x57C_V_mps2_Obj6RelatAccel_0x57C; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_mps_CamLatVelocityStdDeviation00_0x340_V_mps_CamLatVelocityStdDeviation00_0x340; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_mps_CamLatVelocityStdDeviation01_0x35C_V_mps_CamLatVelocityStdDeviation01_0x35C; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_mps_CamLatVelocityStdDeviation02_0x35D_V_mps_CamLatVelocityStdDeviation02_0x35D; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_mps_CamLatVelocityStdDeviation03_0x390_V_mps_CamLatVelocityStdDeviation03_0x390; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_mps_CamLatVelocityStdDeviation04_0x393_V_mps_CamLatVelocityStdDeviation04_0x393; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_mps_CamLatVelocityStdDeviation05_0x394_V_mps_CamLatVelocityStdDeviation05_0x394; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_mps_CamLatVelocityStdDeviation06_0x39E_V_mps_CamLatVelocityStdDeviation06_0x39E; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_mps_CamLatVelocityStdDeviation07_0x3B9_V_mps_CamLatVelocityStdDeviation07_0x3B9; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_mps_CamLatVelocityStdDeviation08_0x3A9_V_mps_CamLatVelocityStdDeviation08_0x3A9; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_mps_CamLatVelocityStdDeviation09_0x3AE_V_mps_CamLatVelocityStdDeviation09_0x3AE; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_mps_CamLatVelocityStdDeviation10_0x3B8_V_mps_CamLatVelocityStdDeviation10_0x3B8; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_mps_CamLatVelocityStdDeviation11_0x3BB_V_mps_CamLatVelocityStdDeviation11_0x3BB; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_mps_CamLateralVelocityObject00_0x2C4_V_mps_CamLateralVelocityObject00_0x2C4; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_mps_CamLateralVelocityObject01_0x2C5_V_mps_CamLateralVelocityObject01_0x2C5; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_mps_CamLateralVelocityObject02_0x2C7_V_mps_CamLateralVelocityObject02_0x2C7; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_mps_CamLateralVelocityObject03_0x2C8_V_mps_CamLateralVelocityObject03_0x2C8; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_mps_CamLateralVelocityObject04_0x2C9_V_mps_CamLateralVelocityObject04_0x2C9; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_mps_CamLateralVelocityObject05_0x2CD_V_mps_CamLateralVelocityObject05_0x2CD; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_mps_CamLateralVelocityObject06_0x2CE_V_mps_CamLateralVelocityObject06_0x2CE; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_mps_CamLateralVelocityObject07_0x2CF_V_mps_CamLateralVelocityObject07_0x2CF; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_mps_CamLateralVelocityObject08_0x2D0_V_mps_CamLateralVelocityObject08_0x2D0; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_mps_CamLateralVelocityObject09_0x2D6_V_mps_CamLateralVelocityObject09_0x2D6; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_mps_CamLateralVelocityObject10_0x2D7_V_mps_CamLateralVelocityObject10_0x2D7; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_mps_CamLateralVelocityObject11_0x2D8_V_mps_CamLateralVelocityObject11_0x2D8; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_mps_CamRelativVelocityStdDeviation00_0x340_V_mps_CamRelativVelocityStdDeviation00_0x340; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_mps_CamRelativVelocityStdDeviation01_0x35C_V_mps_CamRelativVelocityStdDeviation01_0x35C; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_mps_CamRelativVelocityStdDeviation02_0x35D_V_mps_CamRelativVelocityStdDeviation02_0x35D; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_mps_CamRelativVelocityStdDeviation03_0x390_V_mps_CamRelativVelocityStdDeviation03_0x390; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_mps_CamRelativVelocityStdDeviation04_0x393_V_mps_CamRelativVelocityStdDeviation04_0x393; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_mps_CamRelativVelocityStdDeviation05_0x394_V_mps_CamRelativVelocityStdDeviation05_0x394; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_mps_CamRelativVelocityStdDeviation06_0x39E_V_mps_CamRelativVelocityStdDeviation06_0x39E; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_mps_CamRelativVelocityStdDeviation07_0x3B9_V_mps_CamRelativVelocityStdDeviation07_0x3B9; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_mps_CamRelativVelocityStdDeviation08_0x3A9_V_mps_CamRelativVelocityStdDeviation08_0x3A9; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_mps_CamRelativVelocityStdDeviation09_0x3AE_V_mps_CamRelativVelocityStdDeviation09_0x3AE; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_mps_CamRelativVelocityStdDeviation10_0x3B8_V_mps_CamRelativVelocityStdDeviation10_0x3B8; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_mps_CamRelativVelocityStdDeviation11_0x3BB_V_mps_CamRelativVelocityStdDeviation11_0x3BB; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_mps_FusedLane_PathWidth_0x3BC_V_mps_FusedLane_PathWidth_0x3BC; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_mps_LatVelocity_ACC_0x2EE_V_mps_LatVelocity_ACC_0x2EE; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_mps_Obj0RelatSpeed_0x52B_V_mps_Obj0RelatSpeed_0x52B; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_mps_Obj1RelatSpeed_0x52D_V_mps_Obj1RelatSpeed_0x52D; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_mps_Obj2RelatSpeed_0x470_V_mps_Obj2RelatSpeed_0x470; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_mps_Obj3RelatSpeed_0x472_V_mps_Obj3RelatSpeed_0x472; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_mps_Obj4RelatSpeed_0x474_V_mps_Obj4RelatSpeed_0x474; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_mps_Obj5RelatSpeed_0x476_V_mps_Obj5RelatSpeed_0x476; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_mps_Obj6RelatSpeed_0x57B_V_mps_Obj6RelatSpeed_0x57B; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_mps_ObjRelatSpeed_0x24A_V_mps_ObjRelatSpeed_0x24A; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_mps_ObjRelatSpeed_0x24B_V_mps_ObjRelatSpeed_0x24B; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_mps_ObjRelatSpeed_0x24C_V_mps_ObjRelatSpeed_0x24C; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_mps_ObjRelatSpeed_0x24D_V_mps_ObjRelatSpeed_0x24D; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_mps_ObjRelatSpeed_0x24E_V_mps_ObjRelatSpeed_0x24E; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_mps_ObjRelatSpeed_0x24F_V_mps_ObjRelatSpeed_0x24F; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_mps_ObjRelatSpeed_0x250_V_mps_ObjRelatSpeed_0x250; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_mps_ObjRelatSpeed_0x293_V_mps_ObjRelatSpeed_0x293; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_mps_ObjRelatSpeed_0x294_V_mps_ObjRelatSpeed_0x294; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_mps_ObjRelatSpeed_0x295_V_mps_ObjRelatSpeed_0x295; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_mps_RelatVelocity_ACC_0x205_V_mps_RelatVelocity_ACC_0x205; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_mps_RelativeSpeedXleft1_0x32C_V_mps_RelativeSpeedXleft1_0x32C; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_mps_RelativeSpeedXleft2_0x32D_V_mps_RelativeSpeedXleft2_0x32D; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_mps_RelativeSpeedXleft3_0x32E_V_mps_RelativeSpeedXleft3_0x32E; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_mps_RelativeSpeedXleft4_0x32F_V_mps_RelativeSpeedXleft4_0x32F; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_mps_RelativeSpeedXright1_0x331_V_mps_RelativeSpeedXright1_0x331; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_mps_RelativeSpeedXright2_0x332_V_mps_RelativeSpeedXright2_0x332; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_mps_RelativeSpeedXright3_0x334_V_mps_RelativeSpeedXright3_0x334; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_mps_RelativeSpeedXright4_0x336_V_mps_RelativeSpeedXright4_0x336; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_mps_RelativeSpeedYleft1_0x32C_V_mps_RelativeSpeedYleft1_0x32C; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_mps_RelativeSpeedYleft2_0x32D_V_mps_RelativeSpeedYleft2_0x32D; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_mps_RelativeSpeedYleft3_0x32E_V_mps_RelativeSpeedYleft3_0x32E; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_mps_RelativeSpeedYleft4_0x32F_V_mps_RelativeSpeedYleft4_0x32F; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_mps_RelativeSpeedYright1_0x331_V_mps_RelativeSpeedYright1_0x331; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_mps_RelativeSpeedYright2_0x332_V_mps_RelativeSpeedYright2_0x332; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_mps_RelativeSpeedYright3_0x334_V_mps_RelativeSpeedYright3_0x334; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_mps_RelativeSpeedYright4_0x336_V_mps_RelativeSpeedYright4_0x336; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_mps_RelativeVelocity_0x21F_V_mps_RelativeVelocity_0x21F; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_mps_RelativeVelocity_0x220_V_mps_RelativeVelocity_0x220; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_mps_RelativeVelocity_0x222_V_mps_RelativeVelocity_0x222; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_mps_RelativeVelocity_0x223_V_mps_RelativeVelocity_0x223; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_mps_RelativeVelocity_0x240_V_mps_RelativeVelocity_0x240; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_mps_RelativeVelocity_0x241_V_mps_RelativeVelocity_0x241; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_mps_RelativeVelocity_0x246_V_mps_RelativeVelocity_0x246; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_mps_RelativeVelocity_0x247_V_mps_RelativeVelocity_0x247; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_mps_RelativeVelocity_0x248_V_mps_RelativeVelocity_0x248; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_mps_RelativeVelocity_0x262_V_mps_RelativeVelocity_0x262; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_mps_RelativeVelocity_0x263_V_mps_RelativeVelocity_0x263; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_mps_RelativeVelocity_0x264_V_mps_RelativeVelocity_0x264; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt8, RTE_VAR_INIT) Rte_CANIF_V_mps_VehCutInLateralSpeedLeft_0x3DF_V_mps_VehCutInLateralSpeedLeft_0x3DF; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt8, RTE_VAR_INIT) Rte_CANIF_V_mps_VehCutInLateralSpeedRight_0x39F_V_mps_VehCutInLateralSpeedRight_0x39F; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(sint16_NP, RTE_VAR_INIT) Rte_CANIF_V_mps_VehCutInRelativeSpeedLeft_0x3DF_V_mps_VehCutInRelativeSpeedLeft_0x3DF; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(sint16_NP, RTE_VAR_INIT) Rte_CANIF_V_mps_VehCutInRelativeSpeedRight_0x39F_V_mps_VehCutInRelativeSpeedRight_0x39F; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_n_EcoPedalForce_0x417_V_n_EcoPedalForce_0x417; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt8, RTE_VAR_INIT) Rte_CANIF_V_pct_AYCvehicleStabilityMargin_0x202_V_pct_AYCvehicleStabilityMargin_0x202; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_pct_CamAEBBrakingConfidenceLevel_0x302_V_pct_CamAEBBrakingConfidenceLevel_0x302; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_pct_CamAEBWarningConfidenceLevel_0x302_V_pct_CamAEBWarningConfidenceLevel_0x302; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_pct_CamIDTargetCollisionMitigation_0x302_V_pct_CamIDTargetCollisionMitigation_0x302; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_pct_CamTargetQualityObject00_0x38A_V_pct_CamTargetQualityObject00_0x38A; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_pct_CamTargetQualityObject01_0x380_V_pct_CamTargetQualityObject01_0x380; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_pct_CamTargetQualityObject02_0x370_V_pct_CamTargetQualityObject02_0x370; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_pct_CamTargetQualityObject03_0x36D_V_pct_CamTargetQualityObject03_0x36D; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_pct_CamTargetQualityObject04_0x35F_V_pct_CamTargetQualityObject04_0x35F; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_pct_CamTargetQualityObject05_0x35E_V_pct_CamTargetQualityObject05_0x35E; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_pct_CamTargetQualityObject06_0x358_V_pct_CamTargetQualityObject06_0x358; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_pct_CamTargetQualityObject07_0x355_V_pct_CamTargetQualityObject07_0x355; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_pct_CamTargetQualityObject08_0x351_V_pct_CamTargetQualityObject08_0x351; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_pct_CamTargetQualityObject09_0x350_V_pct_CamTargetQualityObject09_0x350; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_pct_CamTargetQualityObject10_0x342_V_pct_CamTargetQualityObject10_0x342; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_pct_CamTargetQualityObject11_0x341_V_pct_CamTargetQualityObject11_0x341; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_pct_ClutchPositionSensor_0x0B6_V_pct_ClutchPositionSensor_0x0B6; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_pct_HVBatteryAirFlow_0x417_V_pct_HVBatteryAirFlow_0x417; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_pct_Lane_Occupancy_Ego00_0x38A_V_pct_Lane_Occupancy_Ego00_0x38A; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_pct_Lane_Occupancy_Ego01_0x380_V_pct_Lane_Occupancy_Ego01_0x380; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_pct_Lane_Occupancy_Ego02_0x370_V_pct_Lane_Occupancy_Ego02_0x370; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_pct_Lane_Occupancy_Ego03_0x36D_V_pct_Lane_Occupancy_Ego03_0x36D; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_pct_Lane_Occupancy_Ego04_0x35F_V_pct_Lane_Occupancy_Ego04_0x35F; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_pct_Lane_Occupancy_Ego05_0x35E_V_pct_Lane_Occupancy_Ego05_0x35E; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_pct_Lane_Occupancy_Ego06_0x358_V_pct_Lane_Occupancy_Ego06_0x358; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_pct_Lane_Occupancy_Ego07_0x355_V_pct_Lane_Occupancy_Ego07_0x355; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_pct_Lane_Occupancy_Ego08_0x351_V_pct_Lane_Occupancy_Ego08_0x351; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_pct_Lane_Occupancy_Ego09_0x350_V_pct_Lane_Occupancy_Ego09_0x350; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_pct_Lane_Occupancy_Ego10_0x342_V_pct_Lane_Occupancy_Ego10_0x342; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_pct_Lane_Occupancy_Ego11_0x341_V_pct_Lane_Occupancy_Ego11_0x341; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_pct_Lane_Occupancy_Left00_0x38A_V_pct_Lane_Occupancy_Left00_0x38A; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_pct_Lane_Occupancy_Left01_0x380_V_pct_Lane_Occupancy_Left01_0x380; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_pct_Lane_Occupancy_Left02_0x370_V_pct_Lane_Occupancy_Left02_0x370; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_pct_Lane_Occupancy_Left03_0x36D_V_pct_Lane_Occupancy_Left03_0x36D; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_pct_Lane_Occupancy_Left04_0x35F_V_pct_Lane_Occupancy_Left04_0x35F; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_pct_Lane_Occupancy_Left05_0x35E_V_pct_Lane_Occupancy_Left05_0x35E; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_pct_Lane_Occupancy_Left06_0x358_V_pct_Lane_Occupancy_Left06_0x358; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_pct_Lane_Occupancy_Left07_0x355_V_pct_Lane_Occupancy_Left07_0x355; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_pct_Lane_Occupancy_Left08_0x351_V_pct_Lane_Occupancy_Left08_0x351; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_pct_Lane_Occupancy_Left09_0x350_V_pct_Lane_Occupancy_Left09_0x350; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_pct_Lane_Occupancy_Left10_0x342_V_pct_Lane_Occupancy_Left10_0x342; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_pct_Lane_Occupancy_Left11_0x341_V_pct_Lane_Occupancy_Left11_0x341; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_pct_Lane_Occupancy_Right00_0x38A_V_pct_Lane_Occupancy_Right00_0x38A; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_pct_Lane_Occupancy_Right01_0x380_V_pct_Lane_Occupancy_Right01_0x380; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_pct_Lane_Occupancy_Right02_0x370_V_pct_Lane_Occupancy_Right02_0x370; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_pct_Lane_Occupancy_Right03_0x36D_V_pct_Lane_Occupancy_Right03_0x36D; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_pct_Lane_Occupancy_Right04_0x35F_V_pct_Lane_Occupancy_Right04_0x35F; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_pct_Lane_Occupancy_Right05_0x35E_V_pct_Lane_Occupancy_Right05_0x35E; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_pct_Lane_Occupancy_Right06_0x358_V_pct_Lane_Occupancy_Right06_0x358; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_pct_Lane_Occupancy_Right07_0x355_V_pct_Lane_Occupancy_Right07_0x355; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_pct_Lane_Occupancy_Right08_0x351_V_pct_Lane_Occupancy_Right08_0x351; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_pct_Lane_Occupancy_Right09_0x350_V_pct_Lane_Occupancy_Right09_0x350; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_pct_Lane_Occupancy_Right10_0x342_V_pct_Lane_Occupancy_Right10_0x342; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_pct_Lane_Occupancy_Right11_0x341_V_pct_Lane_Occupancy_Right11_0x341; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_pct_NightRheostatedLightMaxPercent_0x47F_V_pct_NightRheostatedLightMaxPercent_0x47F; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_pct_Obj0ObstProbab_0x52B_V_pct_Obj0ObstProbab_0x52B; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_pct_Obj1ObstProbab_0x52D_V_pct_Obj1ObstProbab_0x52D; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_pct_Obj2ObstProbab_0x470_V_pct_Obj2ObstProbab_0x470; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_pct_Obj3ObstProbab_0x472_V_pct_Obj3ObstProbab_0x472; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_pct_Obj4ObstProbab_0x474_V_pct_Obj4ObstProbab_0x474; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_pct_Obj5ObstProbab_0x476_V_pct_Obj5ObstProbab_0x476; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_pct_Obj6HypoProb_0x57C_V_pct_Obj6HypoProb_0x57C; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_pct_Obj6QualGen_0x57B_V_pct_Obj6QualGen_0x57B; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_pct_Obj7HypoProb_0x57E_V_pct_Obj7HypoProb_0x57E; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_pct_Obj7QualGen_0x57D_V_pct_Obj7QualGen_0x57D; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_pct_Obj8HypoProb_0x5AC_V_pct_Obj8HypoProb_0x5AC; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_pct_Obj8QualGen_0x5AB_V_pct_Obj8QualGen_0x5AB; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_pct_Obj9HypoProb_0x5AE_V_pct_Obj9HypoProb_0x5AE; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_pct_Obj9QualGen_0x5AD_V_pct_Obj9QualGen_0x5AD; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CANIF_V_pct_PowerTrainSetPoint_BasicSW_V_pct_PowerTrainSetPoint_BasicSW; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CANIF_V_pct_RawSensor_BasicSW_V_pct_RawSensor_BasicSW; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_pct_TSR_ConfidenceLevel_0x3C2_V_pct_TSR_ConfidenceLevel_0x3C2; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_pct_TorqueDistributionRatio_0x25F_V_pct_TorqueDistributionRatio_0x25F; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_pm2_LeftLineCurvaRate_0x2CA_V_pm2_LeftLineCurvaRate_0x2CA; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_pm2_RightLineCurvaRate_0x2CB_V_pm2_RightLineCurvaRate_0x2CB; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_pm_LeftLineCurv_0x2CA_V_pm_LeftLineCurv_0x2CA; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_pm_RightLineCurv_0x2CB_V_pm_RightLineCurv_0x2CB; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_rad_LeftLineYawAng_0x2CA_V_rad_LeftLineYawAng_0x2CA; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_rad_RightLineYawAng_0x2CB_V_rad_RightLineYawAng_0x2CB; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CANIF_V_rpm_EngineRPM_BasicSW_V_rpm_EngineRPM_BasicSW; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CANIF_V_rpm_InputShaftRev_BasicSW_V_rpm_InputShaftRev_BasicSW; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_rpm_MaxEngineSpeedRequest_0x3C6_V_rpm_MaxEngineSpeedRequest_0x3C6; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CANIF_V_rpm_OutputShaftRev_BasicSW_V_rpm_OutputShaftRev_BasicSW; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CANIF_V_rpm_WheelSpeed_F_L_BasicSW_V_rpm_WheelSpeed_F_L_BasicSW; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CANIF_V_rpm_WheelSpeed_F_R_BasicSW_V_rpm_WheelSpeed_F_R_BasicSW; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CANIF_V_rpm_WheelSpeed_R_L_BasicSW_V_rpm_WheelSpeed_R_L_BasicSW; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CANIF_V_rpm_WheelSpeed_R_R_BasicSW_V_rpm_WheelSpeed_R_R_BasicSW; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CANIF_V_s_CANDelay_0x21D_V_s_CANDelay_0x21D; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CANIF_V_s_CamTimeToCollisionObject00_0x266_V_s_CamTimeToCollisionObject00_0x266; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CANIF_V_s_CamTimeToCollisionObject01_0x267_V_s_CamTimeToCollisionObject01_0x267; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CANIF_V_s_CamTimeToCollisionObject02_0x268_V_s_CamTimeToCollisionObject02_0x268; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CANIF_V_s_CamTimeToCollisionObject03_0x269_V_s_CamTimeToCollisionObject03_0x269; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CANIF_V_s_CamTimeToCollisionObject04_0x26E_V_s_CamTimeToCollisionObject04_0x26E; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CANIF_V_s_CamTimeToCollisionObject05_0x26F_V_s_CamTimeToCollisionObject05_0x26F; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CANIF_V_s_CamTimeToCollisionObject06_0x2A3_V_s_CamTimeToCollisionObject06_0x2A3; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CANIF_V_s_CamTimeToCollisionObject07_0x2A4_V_s_CamTimeToCollisionObject07_0x2A4; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CANIF_V_s_CamTimeToCollisionObject08_0x2AC_V_s_CamTimeToCollisionObject08_0x2AC; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CANIF_V_s_CamTimeToCollisionObject09_0x2AD_V_s_CamTimeToCollisionObject09_0x2AD; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CANIF_V_s_CamTimeToCollisionObject10_0x2AE_V_s_CamTimeToCollisionObject10_0x2AE; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CANIF_V_s_CamTimeToCollisionObject11_0x2AF_V_s_CamTimeToCollisionObject11_0x2AF; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_s_Left_Lane_TLC_0x2EC_V_s_Left_Lane_TLC_0x2EC; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_s_Right_Lane_TLC_0x2EC_V_s_Right_Lane_TLC_0x2EC; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_s_StopSignTimeToCollision_0x3FF_V_s_StopSignTimeToCollision_0x3FF; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_s_TFL_TimeToCollision_0x3FF_V_s_TFL_TimeToCollision_0x3FF; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_s_TimeToCollisionLeft1_0x32C_V_s_TimeToCollisionLeft1_0x32C; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_s_TimeToCollisionLeft2_0x32D_V_s_TimeToCollisionLeft2_0x32D; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_s_TimeToCollisionLeft3_0x32E_V_s_TimeToCollisionLeft3_0x32E; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_s_TimeToCollisionLeft4_0x32F_V_s_TimeToCollisionLeft4_0x32F; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_s_TimeToCollisionRight1_0x331_V_s_TimeToCollisionRight1_0x331; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_s_TimeToCollisionRight2_0x332_V_s_TimeToCollisionRight2_0x332; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_s_TimeToCollisionRight3_0x334_V_s_TimeToCollisionRight3_0x334; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_s_TimeToCollisionRight4_0x336_V_s_TimeToCollisionRight4_0x336; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_ACCBrakingPerformanceStatus_BasicSW_V_x_ACCBrakingPerformanceStatus_BasicSW; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_ACCEnginePerformanceStatus_BasicSW_V_x_ACCEnginePerformanceStatus_BasicSW; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt8, RTE_VAR_INIT) Rte_CANIF_V_x_ACC_CameraInternalTemp_0x21E_V_x_ACC_CameraInternalTemp_0x21E; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_ACCompValveCurrent_0x25B_V_x_ACCompValveCurrent_0x25B; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_ADA1ActivationRequest_0x5FA_V_x_ADA1ActivationRequest_0x5FA; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_ADAS_CameraRecordingStatus_0x3C2_V_x_ADAS_CameraRecordingStatus_0x3C2; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_ADAS_YawPerformanceStatus_0x315_V_x_ADAS_YawPerformanceStatus_0x315; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_ADB_AmbientLight_0x3C2_V_x_ADB_AmbientLight_0x3C2; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CANIF_V_x_AEB_BrakeDecelerationRequest_0x0A2_V_x_AEB_BrakeDecelerationRequest_0x0A2; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_AEB_BrakeTorqueGainOrder_0x0A2_V_x_AEB_BrakeTorqueGainOrder_0x0A2; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_AEB_BrakeTorqueGain_0x0A2_V_x_AEB_BrakeTorqueGain_0x0A2; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_AEB_BrakeWheelTorqueOrder_BasicSW_V_x_AEB_BrakeWheelTorqueOrder_BasicSW; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_AEB_BrakingPerformanceStatus_0x0FF_V_x_AEB_BrakingPerformanceStatus_0x0FF; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_AEB_CameraStatus_0x21E_V_x_AEB_CameraStatus_0x21E; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_AEB_FCWactivationRequest2_0x5CA_V_x_AEB_FCWactivationRequest2_0x5CA; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_AEB_FCWactivationRequest_0x5EC_V_x_AEB_FCWactivationRequest_0x5EC; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_AFS_ActivationRequest_0x5EC_V_x_AFS_ActivationRequest_0x5EC; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_AHL_Failure_0x3C2_V_x_AHL_Failure_0x3C2; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_AHL_FrontLightRequest_v2_0x3C2_V_x_AHL_FrontLightRequest_v2_0x3C2; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_APA_FlashingIndicatorRequest_0x3D3_V_x_APA_FlashingIndicatorRequest_0x3D3; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_APB_BrakePedalRequestDisplay_0x3C4_V_x_APB_BrakePedalRequestDisplay_0x3C4; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_APK_ECMstatus_0x0A7_V_x_APK_ECMstatus_0x0A7; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_ASAactivationRequest_0x5FA_V_x_ASAactivationRequest_0x5FA; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_ATCVT_RangeIndicationExtended_0x46E_V_x_ATCVT_RangeIndicationExtended_0x46E; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_AT_ParkPositionCommandState_0x0A4_V_x_AT_ParkPositionCommandState_0x0A4; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_AT_StartingAuthorization_0x0A6_V_x_AT_StartingAuthorization_0x0A6; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_AirbagCrashOrder_BasicSW_V_x_AirbagCrashOrder_BasicSW; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_AlertConditionLeft1_0x32C_V_x_AlertConditionLeft1_0x32C; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_AlertConditionLeft2_0x32D_V_x_AlertConditionLeft2_0x32D; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_AlertConditionLeft3_0x32E_V_x_AlertConditionLeft3_0x32E; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_AlertConditionLeft4_0x32F_V_x_AlertConditionLeft4_0x32F; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_AlertConditionRight1_0x331_V_x_AlertConditionRight1_0x331; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_AlertConditionRight2_0x332_V_x_AlertConditionRight2_0x332; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_AlertConditionRight3_0x334_V_x_AlertConditionRight3_0x334; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_AlertConditionRight4_0x336_V_x_AlertConditionRight4_0x336; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_AlignMonitQuality_0x522_V_x_AlignMonitQuality_0x522; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_AutoACC2Status_MM_0x418_V_x_AutoACC2Status_MM_0x418; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_AutoFoldingActivationState_0x418_V_x_AutoFoldingActivationState_0x418; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_BCI_ActivationRequest_0x5FA_V_x_BCI_ActivationRequest_0x5FA; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_BCI_SideRadarCancelReason_0x623_V_x_BCI_SideRadarCancelReason_0x623; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_BCI_StatusDisplay_0x623_V_x_BCI_StatusDisplay_0x623; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_BCM_WakeUpSleepCommand_0x47D_V_x_BCM_WakeUpSleepCommand_0x47D; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_BSI_ActivationRequest2_0x5CA_V_x_BSI_ActivationRequest2_0x5CA; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_BSI_ActivationRequest_0x5EC_V_x_BSI_ActivationRequest_0x5EC; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_BSI_AlertStatus_0x623_V_x_BSI_AlertStatus_0x623; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_BSI_SideRadarCancelReason_0x623_V_x_BSI_SideRadarCancelReason_0x623; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_BSI_StatusDisplay_0x623_V_x_BSI_StatusDisplay_0x623; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_BSW_LeftWarning_0x502_V_x_BSW_LeftWarning_0x502; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_BSW_RightWarning_0x502_V_x_BSW_RightWarning_0x502; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_BSWrad_ActivationRequest_0x5EC_V_x_BSWrad_ActivationRequest_0x5EC; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_BSWrad_AlertStatus_0x623_V_x_BSWrad_AlertStatus_0x623; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_BSWrad_FailureDisplay_0x623_V_x_BSWrad_FailureDisplay_0x623; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_BSWrad_SideRadarCancelReason_0x623_V_x_BSWrad_SideRadarCancelReason_0x623; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_BSWrad_SoundAlert_0x623_V_x_BSWrad_SoundAlert_0x623; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_BSWrad_StatusDisplay_0x623_V_x_BSWrad_StatusDisplay_0x623; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_BSWson_ActivationDisplay_0x502_V_x_BSWson_ActivationDisplay_0x502; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_BSWson_ActivationRequest_0x5FA_V_x_BSWson_ActivationRequest_0x5FA; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_BSWson_FailureDisplayRequest_0x502_V_x_BSWson_FailureDisplayRequest_0x502; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_BattSetPointGeneratorStatus_V2_0x25B_V_x_BattSetPointGeneratorStatus_V2_0x25B; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_x_BatteryCurrentSensorValue_0x25B_V_x_BatteryCurrentSensorValue_0x25B; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_BlinkCam0_0x266_V_x_BlinkCam0_0x266; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_BlinkCam10_0x2AE_V_x_BlinkCam10_0x2AE; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_BlinkCam1_0x267_V_x_BlinkCam1_0x267; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_BlinkCam2_0x268_V_x_BlinkCam2_0x268; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_BlinkCam4_0x26E_V_x_BlinkCam4_0x26E; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_BlinkCam5_0x26F_V_x_BlinkCam5_0x26F; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_BlinkCam6_0x2A3_V_x_BlinkCam6_0x2A3; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_BlinkCam7_0x2A4_V_x_BlinkCam7_0x2A4; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_BlinkCam8_0x2AC_V_x_BlinkCam8_0x2AC; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_BlinkCam9_0x2AD_V_x_BlinkCam9_0x2AD; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_BlinkerInfo_ACC_0x2EE_V_x_BlinkerInfo_ACC_0x2EE; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_BrakeInfoStatus_BasicSW_V_x_BrakeInfoStatus_BasicSW; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_BrakePedalPressedByDriver_BasicSW_V_x_BrakePedalPressedByDriver_BasicSW; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_BrakeSwitchFaillure_V2_0x46C_V_x_BrakeSwitchFaillure_V2_0x46C; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_BrakeVacuumDeact_BasicSW_V_x_BrakeVacuumDeact_BasicSW; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_BrakeVacuumStatus_mirror_0x3BD_V_x_BrakeVacuumStatus_mirror_0x3BD; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_Braking_ClutchRequest_0x0AB_V_x_Braking_ClutchRequest_0x0AB; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_CTA_ActivationRequest_0x5EC_V_x_CTA_ActivationRequest_0x5EC; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_CTA_AlertStatus_0x623_V_x_CTA_AlertStatus_0x623; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_CTA_FailureDisplay_0x623_V_x_CTA_FailureDisplay_0x623; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_CTA_SideRadarCancelReason_0x623_V_x_CTA_SideRadarCancelReason_0x623; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_CTA_StatusDisplay_0x623_V_x_CTA_StatusDisplay_0x623; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_CamAEBBrakingLevel_0x302_V_x_CamAEBBrakingLevel_0x302; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_CamBrakeLightObject00_0x266_V_x_CamBrakeLightObject00_0x266; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_CamBrakeLightObject01_0x267_V_x_CamBrakeLightObject01_0x267; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_CamBrakeLightObject02_0x268_V_x_CamBrakeLightObject02_0x268; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_CamBrakeLightObject03_0x269_V_x_CamBrakeLightObject03_0x269; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_CamBrakeLightObject04_0x26E_V_x_CamBrakeLightObject04_0x26E; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_CamBrakeLightObject05_0x26F_V_x_CamBrakeLightObject05_0x26F; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_CamBrakeLightObject06_0x2A3_V_x_CamBrakeLightObject06_0x2A3; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_CamBrakeLightObject07_0x2A4_V_x_CamBrakeLightObject07_0x2A4; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_CamBrakeLightObject08_0x2AC_V_x_CamBrakeLightObject08_0x2AC; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_CamBrakeLightObject09_0x2AD_V_x_CamBrakeLightObject09_0x2AD; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_CamBrakeLightObject10_0x2AE_V_x_CamBrakeLightObject10_0x2AE; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_CamBrakeLightObject11_0x2AF_V_x_CamBrakeLightObject11_0x2AF; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_CamFreeSpaceTargetPosition00_0x38A_V_x_CamFreeSpaceTargetPosition00_0x38A; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_CamFreeSpaceTargetPosition01_0x380_V_x_CamFreeSpaceTargetPosition01_0x380; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_CamFreeSpaceTargetPosition02_0x370_V_x_CamFreeSpaceTargetPosition02_0x370; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_CamFreeSpaceTargetPosition03_0x36D_V_x_CamFreeSpaceTargetPosition03_0x36D; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_CamFreeSpaceTargetPosition04_0x35F_V_x_CamFreeSpaceTargetPosition04_0x35F; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_CamFreeSpaceTargetPosition05_0x35E_V_x_CamFreeSpaceTargetPosition05_0x35E; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_CamFreeSpaceTargetPosition06_0x358_V_x_CamFreeSpaceTargetPosition06_0x358; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_CamFreeSpaceTargetPosition07_0x355_V_x_CamFreeSpaceTargetPosition07_0x355; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_CamFreeSpaceTargetPosition08_0x351_V_x_CamFreeSpaceTargetPosition08_0x351; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_CamFreeSpaceTargetPosition09_0x350_V_x_CamFreeSpaceTargetPosition09_0x350; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_CamFreeSpaceTargetPosition10_0x342_V_x_CamFreeSpaceTargetPosition10_0x342; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_CamFreeSpaceTargetPosition11_0x341_V_x_CamFreeSpaceTargetPosition11_0x341; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_CamLaneAssignmentObject00_0x266_V_x_CamLaneAssignmentObject00_0x266; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_CamLaneAssignmentObject01_0x267_V_x_CamLaneAssignmentObject01_0x267; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_CamLaneAssignmentObject02_0x268_V_x_CamLaneAssignmentObject02_0x268; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_CamLaneAssignmentObject03_0x269_V_x_CamLaneAssignmentObject03_0x269; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_CamLaneAssignmentObject04_0x26E_V_x_CamLaneAssignmentObject04_0x26E; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_CamLaneAssignmentObject05_0x26F_V_x_CamLaneAssignmentObject05_0x26F; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_CamLaneAssignmentObject06_0x2A3_V_x_CamLaneAssignmentObject06_0x2A3; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_CamLaneAssignmentObject07_0x2A4_V_x_CamLaneAssignmentObject07_0x2A4; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_CamLaneAssignmentObject08_0x2AC_V_x_CamLaneAssignmentObject08_0x2AC; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_CamLaneAssignmentObject09_0x2AD_V_x_CamLaneAssignmentObject09_0x2AD; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_CamLaneAssignmentObject10_0x2AE_V_x_CamLaneAssignmentObject10_0x2AE; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_CamLaneAssignmentObject11_0x2AF_V_x_CamLaneAssignmentObject11_0x2AF; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_CamLaneMovementTypeObject00_0x266_V_x_CamLaneMovementTypeObject00_0x266; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_CamLaneMovementTypeObject01_0x267_V_x_CamLaneMovementTypeObject01_0x267; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_CamLaneMovementTypeObject02_0x268_V_x_CamLaneMovementTypeObject02_0x268; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_CamLaneMovementTypeObject03_0x269_V_x_CamLaneMovementTypeObject03_0x269; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_CamLaneMovementTypeObject04_0x26E_V_x_CamLaneMovementTypeObject04_0x26E; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_CamLaneMovementTypeObject05_0x26F_V_x_CamLaneMovementTypeObject05_0x26F; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_CamLaneMovementTypeObject06_0x2A3_V_x_CamLaneMovementTypeObject06_0x2A3; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_CamLaneMovementTypeObject07_0x2A4_V_x_CamLaneMovementTypeObject07_0x2A4; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_CamLaneMovementTypeObject08_0x2AC_V_x_CamLaneMovementTypeObject08_0x2AC; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_CamLaneMovementTypeObject09_0x2AD_V_x_CamLaneMovementTypeObject09_0x2AD; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_CamLaneMovementTypeObject10_0x2AE_V_x_CamLaneMovementTypeObject10_0x2AE; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_CamLaneMovementTypeObject11_0x2AF_V_x_CamLaneMovementTypeObject11_0x2AF; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_CamObjectAge00_0x340_V_x_CamObjectAge00_0x340; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_CamObjectAge01_0x35C_V_x_CamObjectAge01_0x35C; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_CamObjectAge02_0x35D_V_x_CamObjectAge02_0x35D; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_CamObjectAge03_0x390_V_x_CamObjectAge03_0x390; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_CamObjectAge04_0x393_V_x_CamObjectAge04_0x393; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_CamObjectAge05_0x394_V_x_CamObjectAge05_0x394; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_CamObjectAge06_0x39E_V_x_CamObjectAge06_0x39E; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_CamObjectAge07_0x3B9_V_x_CamObjectAge07_0x3B9; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_CamObjectAge08_0x3A9_V_x_CamObjectAge08_0x3A9; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_CamObjectAge09_0x3AE_V_x_CamObjectAge09_0x3AE; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_CamObjectAge10_0x3B8_V_x_CamObjectAge10_0x3B8; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_CamObjectAge11_0x3BB_V_x_CamObjectAge11_0x3BB; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_CamSceneScoreInfoObject00_0x266_V_x_CamSceneScoreInfoObject00_0x266; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_CamSceneScoreInfoObject01_0x267_V_x_CamSceneScoreInfoObject01_0x267; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_CamSceneScoreInfoObject02_0x268_V_x_CamSceneScoreInfoObject02_0x268; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_CamSceneScoreInfoObject03_0x269_V_x_CamSceneScoreInfoObject03_0x269; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_CamSceneScoreInfoObject04_0x26E_V_x_CamSceneScoreInfoObject04_0x26E; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_CamSceneScoreInfoObject05_0x26F_V_x_CamSceneScoreInfoObject05_0x26F; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_CamSceneScoreInfoObject06_0x2A3_V_x_CamSceneScoreInfoObject06_0x2A3; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_CamSceneScoreInfoObject07_0x2A4_V_x_CamSceneScoreInfoObject07_0x2A4; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_CamSceneScoreInfoObject08_0x2AC_V_x_CamSceneScoreInfoObject08_0x2AC; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_CamSceneScoreInfoObject09_0x2AD_V_x_CamSceneScoreInfoObject09_0x2AD; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_CamSceneScoreInfoObject10_0x2AE_V_x_CamSceneScoreInfoObject10_0x2AE; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_CamSceneScoreInfoObject11_0x2AF_V_x_CamSceneScoreInfoObject11_0x2AF; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_CamStructureScoreInfoObject00_0x266_V_x_CamStructureScoreInfoObject00_0x266; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_CamStructureScoreInfoObject01_0x267_V_x_CamStructureScoreInfoObject01_0x267; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_CamStructureScoreInfoObject02_0x268_V_x_CamStructureScoreInfoObject02_0x268; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_CamStructureScoreInfoObject03_0x269_V_x_CamStructureScoreInfoObject03_0x269; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_CamStructureScoreInfoObject04_0x26E_V_x_CamStructureScoreInfoObject04_0x26E; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_CamStructureScoreInfoObject05_0x26F_V_x_CamStructureScoreInfoObject05_0x26F; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_CamStructureScoreInfoObject06_0x2A3_V_x_CamStructureScoreInfoObject06_0x2A3; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_CamStructureScoreInfoObject07_0x2A4_V_x_CamStructureScoreInfoObject07_0x2A4; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_CamStructureScoreInfoObject08_0x2AC_V_x_CamStructureScoreInfoObject08_0x2AC; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_CamStructureScoreInfoObject09_0x2AD_V_x_CamStructureScoreInfoObject09_0x2AD; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_CamStructureScoreInfoObject10_0x2AE_V_x_CamStructureScoreInfoObject10_0x2AE; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_CamStructureScoreInfoObject11_0x2AF_V_x_CamStructureScoreInfoObject11_0x2AF; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_CamTurnIndicatorObject03_0x269_V_x_CamTurnIndicatorObject03_0x269; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_CamTurnIndicatorObject11_0x2AF_V_x_CamTurnIndicatorObject11_0x2AF; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_ChildproofLockMalfunctionDisplay_0x418_V_x_ChildproofLockMalfunctionDisplay_0x418; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_ClassificationObject00_0x2C4_V_x_ClassificationObject00_0x2C4; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_ClassificationObject01_0x2C5_V_x_ClassificationObject01_0x2C5; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_ClassificationObject02_0x2C7_V_x_ClassificationObject02_0x2C7; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_ClassificationObject03_0x2C8_V_x_ClassificationObject03_0x2C8; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_ClassificationObject04_0x2C9_V_x_ClassificationObject04_0x2C9; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_ClassificationObject05_0x2CD_V_x_ClassificationObject05_0x2CD; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_ClassificationObject06_0x2CE_V_x_ClassificationObject06_0x2CE; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_ClassificationObject07_0x2CF_V_x_ClassificationObject07_0x2CF; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_ClassificationObject08_0x2D0_V_x_ClassificationObject08_0x2D0; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_ClassificationObject09_0x2D6_V_x_ClassificationObject09_0x2D6; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_ClassificationObject10_0x2D7_V_x_ClassificationObject10_0x2D7; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_ClassificationObject11_0x2D8_V_x_ClassificationObject11_0x2D8; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_CloseActiveBrakeSwitch_BCM_0x46C_V_x_CloseActiveBrakeSwitch_BCM_0x46C; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_ClusterSkinState_0x47F_V_x_ClusterSkinState_0x47F; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_ClutchSwitchMaximumTravel_0x47D_V_x_ClutchSwitchMaximumTravel_0x47D; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_ClutchSwitchMinimumTravel_BasicSW_V_x_ClutchSwitchMinimumTravel_BasicSW; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_ConstructinArea_0x2EC_V_x_ConstructinArea_0x2EC; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_CrashDetectionOutOfOrder_v2_0x538_V_x_CrashDetectionOutOfOrder_v2_0x538; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_CrashLevelType_0x020_V_x_CrashLevelType_0x020; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_CruiseControlStatus_forTM_0x0A7_V_x_CruiseControlStatus_forTM_0x0A7; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_CruiseEcoActivationRequest_0x5D3_V_x_CruiseEcoActivationRequest_0x5D3; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_CutInOut_ACC_0x205_V_x_CutInOut_ACC_0x205; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_CutiInOutCam0_0x266_V_x_CutiInOutCam0_0x266; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_CutiInOutCam10_0x2AE_V_x_CutiInOutCam10_0x2AE; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_CutiInOutCam11_0x2AF_V_x_CutiInOutCam11_0x2AF; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_CutiInOutCam1_0x267_V_x_CutiInOutCam1_0x267; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_CutiInOutCam2_0x268_V_x_CutiInOutCam2_0x268; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_CutiInOutCam3_0x269_V_x_CutiInOutCam3_0x269; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_CutiInOutCam4_0x26E_V_x_CutiInOutCam4_0x26E; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_CutiInOutCam5_0x26F_V_x_CutiInOutCam5_0x26F; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_CutiInOutCam6_0x2A3_V_x_CutiInOutCam6_0x2A3; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_CutiInOutCam7_0x2A4_V_x_CutiInOutCam7_0x2A4; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_CutiInOutCam8_0x2AC_V_x_CutiInOutCam8_0x2AC; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_CutiInOutCam9_0x2AD_V_x_CutiInOutCam9_0x2AD; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Float, RTE_VAR_INIT) Rte_CANIF_V_x_DTOOL_to_ADAS_0x7C3_V_x_DTOOL_to_ADAS_0x7C3; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_DW_ActivationRequest_0x5EC_V_x_DW_ActivationRequest_0x5EC; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_DayNightForBacklights_0x47F_V_x_DayNightForBacklights_0x47F; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_DayTimeInd_0x2EE_V_x_DayTimeInd_0x2EE; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_DetectionLevelFront_ILIR_0x322_V_x_DetectionLevelFront_ILIR_0x322; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_DetectionLevelFront_ILOL_0x322_V_x_DetectionLevelFront_ILOL_0x322; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_DetectionLevelFront_IL_0x322_V_x_DetectionLevelFront_IL_0x322; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_DetectionLevelFront_IRIL_0x322_V_x_DetectionLevelFront_IRIL_0x322; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_DetectionLevelFront_IROR_0x322_V_x_DetectionLevelFront_IROR_0x322; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_DetectionLevelFront_IR_0x322_V_x_DetectionLevelFront_IR_0x322; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_DetectionLevelFront_OLIL_0x322_V_x_DetectionLevelFront_OLIL_0x322; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_DetectionLevelFront_OL_0x322_V_x_DetectionLevelFront_OL_0x322; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_DetectionLevelFront_ORIR_0x322_V_x_DetectionLevelFront_ORIR_0x322; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_DetectionLevelFront_OR_0x322_V_x_DetectionLevelFront_OR_0x322; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_DetectionLevelRear_ILIR_0x322_V_x_DetectionLevelRear_ILIR_0x322; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_DetectionLevelRear_ILOL_0x322_V_x_DetectionLevelRear_ILOL_0x322; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_DetectionLevelRear_IL_0x322_V_x_DetectionLevelRear_IL_0x322; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_DetectionLevelRear_IRIL_0x322_V_x_DetectionLevelRear_IRIL_0x322; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_DetectionLevelRear_IROR_0x322_V_x_DetectionLevelRear_IROR_0x322; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_DetectionLevelRear_IR_0x322_V_x_DetectionLevelRear_IR_0x322; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_DetectionLevelRear_OLIL_0x322_V_x_DetectionLevelRear_OLIL_0x322; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_DetectionLevelRear_OL_0x322_V_x_DetectionLevelRear_OL_0x322; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_DetectionLevelRear_ORIR_0x322_V_x_DetectionLevelRear_ORIR_0x322; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_DetectionLevelRear_OR_0x322_V_x_DetectionLevelRear_OR_0x322; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_DisplayedOilLevel_0x47F_V_x_DisplayedOilLevel_0x47F; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_DriveModeRequest_BasicSW_V_x_DriveModeRequest_BasicSW; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_DriveModeStatusDisplay_0x418_V_x_DriveModeStatusDisplay_0x418; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_DriverDoorState_BasicSW_V_x_DriverDoorState_BasicSW; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_DriverOutsideBuzzerRequest_0x418_V_x_DriverOutsideBuzzerRequest_0x418; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_DriverSafetyBelt_BasicSW_V_x_DriverSafetyBelt_BasicSW; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_DriverSeatBeltFailureState_0x46C_V_x_DriverSeatBeltFailureState_0x46C; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_DriverStopRequestWhileBattOff_0x418_V_x_DriverStopRequestWhileBattOff_0x418; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_EAP_ActivationRequest_0x5FA_V_x_EAP_ActivationRequest_0x5FA; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_EPB_BindingStatusDisplay_0x3C4_V_x_EPB_BindingStatusDisplay_0x3C4; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_EPB_MalfunctionDisplay_0x3C4_V_x_EPB_MalfunctionDisplay_0x3C4; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_EPB_RefuseToSleep_0x3C4_V_x_EPB_RefuseToSleep_0x3C4; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_EPB_RequestBrakeControl_0x25C_V_x_EPB_RequestBrakeControl_0x25C; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_EPB_TightenRequestUnavailable_0x3C4_V_x_EPB_TightenRequestUnavailable_0x3C4; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_ESCL_Status_0x46F_V_x_ESCL_Status_0x46F; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_ESCLunlock_iKeyFobAuthent_0x46C_V_x_ESCLunlock_iKeyFobAuthent_0x46C; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_ETS_InternalOperationMode_BasicSW_V_x_ETS_InternalOperationMode_BasicSW; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_ETS_ModeLamp_0x25F_V_x_ETS_ModeLamp_0x25F; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_EcoAdviceTPMSActivationRequest_0x5EC_V_x_EcoAdviceTPMSActivationRequest_0x5EC; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_EcoCancelRequest_0x46E_V_x_EcoCancelRequest_0x46E; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_EcoPedalForceSettingStatus_0x417_V_x_EcoPedalForceSettingStatus_0x417; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_ElecPowerConsumedByAux_v2_0x25B_V_x_ElecPowerConsumedByAux_v2_0x25B; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_ElectricalPowerDrived_0x46C_V_x_ElectricalPowerDrived_0x46C; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_EmergencyEngineStop_0x46C_V_x_EmergencyEngineStop_0x46C; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_ExistanceProbabilityObject00_0x52B_V_x_ExistanceProbabilityObject00_0x52B; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_ExistanceProbabilityObject01_0x52D_V_x_ExistanceProbabilityObject01_0x52D; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_ExistanceProbabilityObject02_0x470_V_x_ExistanceProbabilityObject02_0x470; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_ExistanceProbabilityObject03_0x472_V_x_ExistanceProbabilityObject03_0x472; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_FAP_ADASgearShiftRequest_0x1B2_V_x_FAP_ADASgearShiftRequest_0x1B2; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_FAP_ControlSwitchPressed_0x3D3_V_x_FAP_ControlSwitchPressed_0x3D3; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_x_FAP_RemainingDistance_0x19A_V_x_FAP_RemainingDistance_0x19A; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_FAP_StandStillMngtRequest_0x19A_V_x_FAP_StandStillMngtRequest_0x19A; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_FAP_VelocityOrder_0x19A_V_x_FAP_VelocityOrder_0x19A; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CANIF_V_x_FAP_VelocityRequest_0x19A_V_x_FAP_VelocityRequest_0x19A; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_FKP_ActivationRequest_0x5EC_V_x_FKP_ActivationRequest_0x5EC; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_FS_BlurImgLevel_0x21E_V_x_FS_BlurImgLevel_0x21E; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_FS_FogSpotLevel_0x21E_V_x_FS_FogSpotLevel_0x21E; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_FS_FrosWinShieldLevel_0x21E_V_x_FS_FrosWinShieldLevel_0x21E; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_FS_FullBlockLevel_0x21E_V_x_FS_FullBlockLevel_0x21E; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_FS_LowSunLevel_0x21E_V_x_FS_LowSunLevel_0x21E; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_FS_MCPFail_0x21E_V_x_FS_MCPFail_0x21E; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_FS_PartialBlockLevel_0x21E_V_x_FS_PartialBlockLevel_0x21E; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_FS_RoadSplayLevel_0x21E_V_x_FS_RoadSplayLevel_0x21E; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_FS_SelfGlareLevel_0x21E_V_x_FS_SelfGlareLevel_0x21E; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_FS_SmearSpotLevel_0x21E_V_x_FS_SmearSpotLevel_0x21E; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_FS_SunRayLevel_0x21E_V_x_FS_SunRayLevel_0x21E; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Float, RTE_VAR_INIT) Rte_CANIF_V_x_FTOOLS_CGWtoADAS_0x1BDE24F2_V_x_FTOOLS_CGWtoADAS_0x1BDE24F2; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_FlashingIndicatorCommandPosition_BasicSW_V_x_FlashingIndicatorCommandPosition_BasicSW; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_FlashingIndicatorStatus_0x47D_V_x_FlashingIndicatorStatus_0x47D; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_FreeSpace_0x2EE_V_x_FreeSpace_0x2EE; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_FreeSpace_Far1Status_0x362_V_x_FreeSpace_Far1Status_0x362; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_FreeSpace_Far2Status_0x362_V_x_FreeSpace_Far2Status_0x362; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_FreeSpace_Far3Status_0x362_V_x_FreeSpace_Far3Status_0x362; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_FrontCollisionValid00_0x38A_V_x_FrontCollisionValid00_0x38A; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_FrontCollisionValid01_0x380_V_x_FrontCollisionValid01_0x380; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_FrontCollisionValid02_0x370_V_x_FrontCollisionValid02_0x370; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_FrontCollisionValid03_0x36D_V_x_FrontCollisionValid03_0x36D; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_FrontCollisionValid04_0x35F_V_x_FrontCollisionValid04_0x35F; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_FrontCollisionValid05_0x35E_V_x_FrontCollisionValid05_0x35E; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_FrontCollisionValid06_0x358_V_x_FrontCollisionValid06_0x358; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_FrontCollisionValid07_0x355_V_x_FrontCollisionValid07_0x355; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_FrontCollisionValid08_0x351_V_x_FrontCollisionValid08_0x351; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_FrontCollisionValid09_0x350_V_x_FrontCollisionValid09_0x350; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_FrontCollisionValid10_0x342_V_x_FrontCollisionValid10_0x342; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_FrontCollisionValid11_0x341_V_x_FrontCollisionValid11_0x341; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_FrontWiperStatus_BCM_0x47D_V_x_FrontWiperStatus_BCM_0x47D; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_FrontWipingRequest_0x47D_V_x_FrontWipingRequest_0x47D; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_FuelLevelDisplayed_0x47F_V_x_FuelLevelDisplayed_0x47F; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_FusedLane_Confidence_0x3BC_V_x_FusedLane_Confidence_0x3BC; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_x_FusedLane_CurvatureCoef_0x3BC_V_x_FusedLane_CurvatureCoef_0x3BC; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_x_FusedLane_DerivativCurvatureCoef_0x3BC_V_x_FusedLane_DerivativCurvatureCoef_0x3BC; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_x_FusedLane_YawAngleCoef_0x3BC_V_x_FusedLane_YawAngleCoef_0x3BC; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_GSITargettedGearDisplayRequest_0x417_V_x_GSITargettedGearDisplayRequest_0x417; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_GearLeverPositionV2_BasicSW_V_x_GearLeverPositionV2_BasicSW; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_GearShiftInProgress_BasicSW_V_x_GearShiftInProgress_BasicSW; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_GlobalVehicleWarningState_BasicSW_V_x_GlobalVehicleWarningState_BasicSW; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_HDC_StatusDisplay_0x3BD_V_x_HDC_StatusDisplay_0x3BD; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_HFM_HandFree_Request_0x46F_V_x_HFM_HandFree_Request_0x46F; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_HFM_RKE_Request_0x46F_V_x_HFM_RKE_Request_0x46F; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_HFM_Refuse_to_Sleep_0x46F_V_x_HFM_Refuse_to_Sleep_0x46F; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_HFPB_ECMStatus_0x0A7_V_x_HFPB_ECMStatus_0x0A7; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_HFP_DefaultManeuverTypeRequest_0x5EC_V_x_HFP_DefaultManeuverTypeRequest_0x5EC; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_HFP_SelectedManeuverTypeRequest_0x5EC_V_x_HFP_SelectedManeuverTypeRequest_0x5EC; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_HSA_ActivationState_0x3BD_V_x_HSA_ActivationState_0x3BD; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_HSA_StatusDisplay_0x3BD_V_x_HSA_StatusDisplay_0x3BD; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_HUD_ADASactivationRequest_0x5FA_V_x_HUD_ADASactivationRequest_0x5FA; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_HUD_DayLuminosityRequest_0x5FA_V_x_HUD_DayLuminosityRequest_0x5FA; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_HUD_ITactivationRequest_0x5FA_V_x_HUD_ITactivationRequest_0x5FA; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_HUD_NightLuminosityRequest_0x5FA_V_x_HUD_NightLuminosityRequest_0x5FA; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_HUD_TSRactivationRequest_0x5FA_V_x_HUD_TSRactivationRequest_0x5FA; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_HUD_TurnByTurnActivationRequest_0x5FA_V_x_HUD_TurnByTurnActivationRequest_0x5FA; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_HWE_0x2CC_V_x_HWE_0x2CC; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CANIF_V_x_HandFreeCode_0x46F_V_x_HandFreeCode_0x46F; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_HornRequest_0x418_V_x_HornRequest_0x418; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_IDCIPV_0x21D_V_x_IDCIPV_0x21D; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_ID_0x21F_V_x_ID_0x21F; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_ID_0x220_V_x_ID_0x220; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_ID_0x222_V_x_ID_0x222; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_ID_0x223_V_x_ID_0x223; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_ID_0x240_V_x_ID_0x240; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_ID_0x241_V_x_ID_0x241; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_ID_0x246_V_x_ID_0x246; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_ID_0x247_V_x_ID_0x247; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_ID_0x248_V_x_ID_0x248; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_ID_0x262_V_x_ID_0x262; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_ID_0x263_V_x_ID_0x263; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_ID_0x264_V_x_ID_0x264; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_IKeyCardDetectionStatus_0x46F_V_x_IKeyCardDetectionStatus_0x46F; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_IPA_ControlGain3ForSteering_0x1B2_V_x_IPA_ControlGain3ForSteering_0x1B2; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_IPA_Status_0x1B2_V_x_IPA_Status_0x1B2; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_IkeyfobInsideVehicleFound_0x46F_V_x_IkeyfobInsideVehicleFound_0x46F; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_ImageCounter_0x333_V_x_ImageCounter_0x333; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_JNC_Status_0x3FF_V_x_JNC_Status_0x3FF; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_KeyVehicle_0x46C_V_x_KeyVehicle_0x46C; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_LCA_ActivationRequest2_0x5CA_V_x_LCA_ActivationRequest2_0x5CA; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_LCA_ActivationRequest_0x5EC_V_x_LCA_ActivationRequest_0x5EC; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_LCA_SteeringStatus_0x0AC_V_x_LCA_SteeringStatus_0x0AC; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_LCA_SteeringStatus_mirror_0x0AC_V_x_LCA_SteeringStatus_mirror_0x0AC; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_LDP_ActivationRequest2_0x5CA_V_x_LDP_ActivationRequest2_0x5CA; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_LDP_ActivationRequest_0x5EC_V_x_LDP_ActivationRequest_0x5EC; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_CANIF_V_x_LDP_CameraCancelReason_0x643_V_x_LDP_CameraCancelReason_0x643; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_CANIF_V_x_LDP_StatusDisplay_0x643_V_x_LDP_StatusDisplay_0x643; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_LDW_ActivationRequest_0x5EC_V_x_LDW_ActivationRequest_0x5EC; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_CANIF_V_x_LDW_ActivationState_v3_0x517_V_x_LDW_ActivationState_v3_0x517; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_CANIF_V_x_LDW_AlertStatus_0x643_V_x_LDW_AlertStatus_0x643; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_CANIF_V_x_LDW_CameraCancelReason_0x643_V_x_LDW_CameraCancelReason_0x643; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_LDW_SensibilityRequest_0x5EC_V_x_LDW_SensibilityRequest_0x5EC; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_LDW_SoundAlert_0x3C2_V_x_LDW_SoundAlert_0x3C2; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_LDW_SoundLevelRequest_v2_0x5EC_V_x_LDW_SoundLevelRequest_v2_0x5EC; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_LDW_SoundType_0x3C2_V_x_LDW_SoundType_0x3C2; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_LDW_VibrationIntensityReq_0x5EC_V_x_LDW_VibrationIntensityReq_0x5EC; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_LKA_ActivationRequest_0x5EC_V_x_LKA_ActivationRequest_0x5EC; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_LKA_ActivationStateForLCA_0x3C2_V_x_LKA_ActivationStateForLCA_0x3C2; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_LKA_SteeringStatus_0x0AC_V_x_LKA_SteeringStatus_0x0AC; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_LeftBoundType_0x2CC_V_x_LeftBoundType_0x2CC; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_LeftLineColor_0x41E_V_x_LeftLineColor_0x41E; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_LeftLineConfidence_0x2CA_V_x_LeftLineConfidence_0x2CA; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_LeftLineMeasureConfidence_0x2CA_V_x_LeftLineMeasureConfidence_0x2CA; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_LineType1_0x421_V_x_LineType1_0x421; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_LineType2_0x43D_V_x_LineType2_0x43D; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_LostReasonObject00_0x52C_V_x_LostReasonObject00_0x52C; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_LostReasonObject01_0x52E_V_x_LostReasonObject01_0x52E; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_LostReasonObject02_0x471_V_x_LostReasonObject02_0x471; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_LostReasonObject03_0x473_V_x_LostReasonObject03_0x473; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_LowBrakeFluidLevelStatus_0x47F_V_x_LowBrakeFluidLevelStatus_0x47F; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_MOD_ActivationRequest_0x5EC_V_x_MOD_ActivationRequest_0x5EC; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_MainObjectID_0x3FF_V_x_MainObjectID_0x3FF; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_MaintenanceModeStatus_BasicSW_V_x_MaintenanceModeStatus_BasicSW; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_Maintenance_Mode_Status_VDC_0x3BD_V_x_Maintenance_Mode_Status_VDC_0x3BD; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_ManualShiftLeverPosition_0x46C_V_x_ManualShiftLeverPosition_0x46C; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_MastervacPressureSensorNG_0x0FF_V_x_MastervacPressureSensorNG_0x0FF; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_MastervacPressure_v2_0x0FF_V_x_MastervacPressure_v2_0x0FF; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt8, RTE_VAR_INIT) Rte_CANIF_V_x_MaxDeltaVLat1stCollision_0x020_V_x_MaxDeltaVLat1stCollision_0x020; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt8, RTE_VAR_INIT) Rte_CANIF_V_x_MaxDeltaVLat2ndCollision_0x020_V_x_MaxDeltaVLat2ndCollision_0x020; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt8, RTE_VAR_INIT) Rte_CANIF_V_x_MaxDeltaVLongi1stCollision_0x020_V_x_MaxDeltaVLongi1stCollision_0x020; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt8, RTE_VAR_INIT) Rte_CANIF_V_x_MaxDeltaVLongi2ndCollision_0x020_V_x_MaxDeltaVLongi2ndCollision_0x020; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_MeterVolumeState_0x47F_V_x_MeterVolumeState_0x47F; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_MexModeState_0x5C0_V_x_MexModeState_0x5C0; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_MexModeState_xEV_0x5C0_V_x_MexModeState_xEV_0x5C0; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_MotionSts_0x266_V_x_MotionSts_0x266; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_MotionSts_0x267_V_x_MotionSts_0x267; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_MotionSts_0x268_V_x_MotionSts_0x268; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_MotionSts_0x269_V_x_MotionSts_0x269; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_MotionSts_0x26E_V_x_MotionSts_0x26E; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_MotionSts_0x26F_V_x_MotionSts_0x26F; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_MotionSts_0x2A3_V_x_MotionSts_0x2A3; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_MotionSts_0x2A4_V_x_MotionSts_0x2A4; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_MotionSts_0x2AC_V_x_MotionSts_0x2AC; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_MotionSts_0x2AD_V_x_MotionSts_0x2AD; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_MotionSts_0x2AE_V_x_MotionSts_0x2AE; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_MotionSts_0x2AF_V_x_MotionSts_0x2AF; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_MotionSts_ACC_0x2EE_V_x_MotionSts_ACC_0x2EE; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_MsgCntObj0a_0x52B_V_x_MsgCntObj0a_0x52B; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_MsgCntObj0b_0x52C_V_x_MsgCntObj0b_0x52C; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_MsgCntObj1_0x24A_V_x_MsgCntObj1_0x24A; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_MsgCntObj1_0x24B_V_x_MsgCntObj1_0x24B; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_MsgCntObj1_0x24C_V_x_MsgCntObj1_0x24C; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_MsgCntObj1_0x24D_V_x_MsgCntObj1_0x24D; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_MsgCntObj1_0x24E_V_x_MsgCntObj1_0x24E; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_MsgCntObj1_0x24F_V_x_MsgCntObj1_0x24F; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_MsgCntObj1_0x250_V_x_MsgCntObj1_0x250; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_MsgCntObj1a_0x52D_V_x_MsgCntObj1a_0x52D; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_MsgCntObj1b_0x52E_V_x_MsgCntObj1b_0x52E; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_MsgCntObj2A_0x470_V_x_MsgCntObj2A_0x470; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_MsgCntObj2B_0x471_V_x_MsgCntObj2B_0x471; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_MsgCntObj3A_0x472_V_x_MsgCntObj3A_0x472; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_MsgCntObj3B_0x473_V_x_MsgCntObj3B_0x473; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_MsgCntObj4A_0x474_V_x_MsgCntObj4A_0x474; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_MsgCntObj4B_0x475_V_x_MsgCntObj4B_0x475; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_MsgCntObj5A_0x476_V_x_MsgCntObj5A_0x476; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_MsgCntObj5B_0x477_V_x_MsgCntObj5B_0x477; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_MsgCntObj6a_0x57B_V_x_MsgCntObj6a_0x57B; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_MsgCntObj6b_0x57C_V_x_MsgCntObj6b_0x57C; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_MsgCntObj7a_0x57D_V_x_MsgCntObj7a_0x57D; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_MsgCntObj7b_0x57E_V_x_MsgCntObj7b_0x57E; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_MsgCntObj8a_0x5AB_V_x_MsgCntObj8a_0x5AB; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_MsgCntObj8b_0x5AC_V_x_MsgCntObj8b_0x5AC; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_MsgCntObj9a_0x5AD_V_x_MsgCntObj9a_0x5AD; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_MsgCntObj9b_0x5AE_V_x_MsgCntObj9b_0x5AE; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_MsgCntObjlist8_0x293_V_x_MsgCntObjlist8_0x293; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_MsgCntObjlist8_0x294_V_x_MsgCntObjlist8_0x294; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_MsgCntObjlist8_0x295_V_x_MsgCntObjlist8_0x295; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_MsgCnt_0x205_V_x_MsgCnt_0x205; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_CANIF_V_x_MsgCnt_0x21D_V_x_MsgCnt_0x21D; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_CANIF_V_x_MsgCnt_0x21E_V_x_MsgCnt_0x21E; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_CANIF_V_x_MsgCnt_0x21F_V_x_MsgCnt_0x21F; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_CANIF_V_x_MsgCnt_0x220_V_x_MsgCnt_0x220; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_CANIF_V_x_MsgCnt_0x222_V_x_MsgCnt_0x222; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_CANIF_V_x_MsgCnt_0x223_V_x_MsgCnt_0x223; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_CANIF_V_x_MsgCnt_0x240_V_x_MsgCnt_0x240; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_CANIF_V_x_MsgCnt_0x241_V_x_MsgCnt_0x241; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_CANIF_V_x_MsgCnt_0x246_V_x_MsgCnt_0x246; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_CANIF_V_x_MsgCnt_0x247_V_x_MsgCnt_0x247; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_CANIF_V_x_MsgCnt_0x248_V_x_MsgCnt_0x248; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_CANIF_V_x_MsgCnt_0x262_V_x_MsgCnt_0x262; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_CANIF_V_x_MsgCnt_0x263_V_x_MsgCnt_0x263; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_CANIF_V_x_MsgCnt_0x264_V_x_MsgCnt_0x264; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_CANIF_V_x_MsgCnt_0x266_V_x_MsgCnt_0x266; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_CANIF_V_x_MsgCnt_0x267_V_x_MsgCnt_0x267; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_CANIF_V_x_MsgCnt_0x268_V_x_MsgCnt_0x268; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_CANIF_V_x_MsgCnt_0x269_V_x_MsgCnt_0x269; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_CANIF_V_x_MsgCnt_0x26E_V_x_MsgCnt_0x26E; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_CANIF_V_x_MsgCnt_0x26F_V_x_MsgCnt_0x26F; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_CANIF_V_x_MsgCnt_0x2A3_V_x_MsgCnt_0x2A3; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_CANIF_V_x_MsgCnt_0x2A4_V_x_MsgCnt_0x2A4; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_CANIF_V_x_MsgCnt_0x2AC_V_x_MsgCnt_0x2AC; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_CANIF_V_x_MsgCnt_0x2AD_V_x_MsgCnt_0x2AD; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_CANIF_V_x_MsgCnt_0x2AE_V_x_MsgCnt_0x2AE; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_CANIF_V_x_MsgCnt_0x2AF_V_x_MsgCnt_0x2AF; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_CANIF_V_x_MsgCnt_0x2C4_V_x_MsgCnt_0x2C4; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_CANIF_V_x_MsgCnt_0x2C5_V_x_MsgCnt_0x2C5; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_CANIF_V_x_MsgCnt_0x2C7_V_x_MsgCnt_0x2C7; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_CANIF_V_x_MsgCnt_0x2C8_V_x_MsgCnt_0x2C8; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_CANIF_V_x_MsgCnt_0x2C9_V_x_MsgCnt_0x2C9; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_CANIF_V_x_MsgCnt_0x2CD_V_x_MsgCnt_0x2CD; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_CANIF_V_x_MsgCnt_0x2CE_V_x_MsgCnt_0x2CE; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_CANIF_V_x_MsgCnt_0x2CF_V_x_MsgCnt_0x2CF; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_CANIF_V_x_MsgCnt_0x2D0_V_x_MsgCnt_0x2D0; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_CANIF_V_x_MsgCnt_0x2D6_V_x_MsgCnt_0x2D6; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_CANIF_V_x_MsgCnt_0x2D7_V_x_MsgCnt_0x2D7; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_CANIF_V_x_MsgCnt_0x2D8_V_x_MsgCnt_0x2D8; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_CANIF_V_x_MsgCnt_0x2EE_V_x_MsgCnt_0x2EE; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_MsgCnt_0x522_V_x_MsgCnt_0x522; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_MultiDriveModeECM_BasicSW_V_x_MultiDriveModeECM_BasicSW; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_MultiDriveMode_4WS_0x5C0_V_x_MultiDriveMode_4WS_0x5C0; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_MultiDriveMode_ADA_0x5C0_V_x_MultiDriveMode_ADA_0x5C0; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_MultiDriveMode_ADB_0x5C0_V_x_MultiDriveMode_ADB_0x5C0; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_MultiDriveMode_AT_0x5C0_V_x_MultiDriveMode_AT_0x5C0; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_MultiDriveMode_BSB_0x5C0_V_x_MultiDriveMode_BSB_0x5C0; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_MultiDriveMode_EPS_0x5C0_V_x_MultiDriveMode_EPS_0x5C0; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_MultiDriveMode_HVAC_0x5C0_V_x_MultiDriveMode_HVAC_0x5C0; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_MultiDriveMode_IDM_0x5C0_V_x_MultiDriveMode_IDM_0x5C0; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_MultiDriveMode_VADA_0x5C0_V_x_MultiDriveMode_VADA_0x5C0; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_MultiDriveMode_VDC_0x5C0_V_x_MultiDriveMode_VDC_0x5C0; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_MultiDriveMode_pHEV_0x5C0_V_x_MultiDriveMode_pHEV_0x5C0; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_MultiDriveMode_xEV_0x5C0_V_x_MultiDriveMode_xEV_0x5C0; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_NeutralContact_BasicSW_V_x_NeutralContact_BasicSW; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_NextLeftBoundaryType_0x40A_V_x_NextLeftBoundaryType_0x40A; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_NextLeftLineConfidence_0x40A_V_x_NextLeftLineConfidence_0x40A; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_x_NextLeftLineCurvatureRate_0x41E_V_x_NextLeftLineCurvatureRate_0x41E; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_x_NextLeftLineCurvature_0x41E_V_x_NextLeftLineCurvature_0x41E; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_NextLeftLineMeasureConfidence_0x40A_V_x_NextLeftLineMeasureConfidence_0x40A; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_x_NextLeftLineYawAngle_0x40A_V_x_NextLeftLineYawAngle_0x40A; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_NextRightBoundaryType_0x41B_V_x_NextRightBoundaryType_0x41B; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_NextRightLineConfidence_0x41B_V_x_NextRightLineConfidence_0x41B; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_x_NextRightLineCurvatureRate_0x420_V_x_NextRightLineCurvatureRate_0x420; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_x_NextRightLineCurvature_0x420_V_x_NextRightLineCurvature_0x420; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_NextRightLineMeasureConfidence_0x41B_V_x_NextRightLineMeasureConfidence_0x41B; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_CANIF_V_x_NextRightLineYawAngle_0x41B_V_x_NextRightLineYawAngle_0x41B; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_NoEntry_ActivationRequest_0x5FA_V_x_NoEntry_ActivationRequest_0x5FA; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_NumVideoObj_0x21D_V_x_NumVideoObj_0x21D; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_NumberOfObjects_0x333_V_x_NumberOfObjects_0x333; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_NumberOfTFLObjects_0x3FF_V_x_NumberOfTFLObjects_0x3FF; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_OBD_MARKER_0x3C6_V_x_OBD_MARKER_0x3C6; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CANIF_V_x_OBD_VALUE_0x3C6_V_x_OBD_VALUE_0x3C6; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_OSPSpeedForSL_0x3C2_V_x_OSPSpeedForSL_0x3C2; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_OSPSpeedSignal_0x3C2_V_x_OSPSpeedSignal_0x3C2; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_OSPSpeedUnit_0x3C2_V_x_OSPSpeedUnit_0x3C2; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_Obj0Dynamic_0x52C_V_x_Obj0Dynamic_0x52C; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_Obj0ID_0x52C_V_x_Obj0ID_0x52C; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt8, RTE_VAR_INIT) Rte_CANIF_V_x_Obj0Rcs_0x52C_V_x_Obj0Rcs_0x52C; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_Obj0Status_0x52C_V_x_Obj0Status_0x52C; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_Obj0Type_0x52C_V_x_Obj0Type_0x52C; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_Obj1Dynamic_0x52E_V_x_Obj1Dynamic_0x52E; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_Obj1ID_0x52E_V_x_Obj1ID_0x52E; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt8, RTE_VAR_INIT) Rte_CANIF_V_x_Obj1Rcs_0x52E_V_x_Obj1Rcs_0x52E; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_Obj1Status_0x52E_V_x_Obj1Status_0x52E; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_Obj1Type_0x52E_V_x_Obj1Type_0x52E; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_Obj2Dynamic_0x471_V_x_Obj2Dynamic_0x471; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_Obj2ID_0x471_V_x_Obj2ID_0x471; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt8, RTE_VAR_INIT) Rte_CANIF_V_x_Obj2Rcs_0x471_V_x_Obj2Rcs_0x471; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_Obj2Status_0x471_V_x_Obj2Status_0x471; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_Obj2Type_0x471_V_x_Obj2Type_0x471; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_Obj3Dynamic_0x473_V_x_Obj3Dynamic_0x473; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_Obj3ID_0x473_V_x_Obj3ID_0x473; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt8, RTE_VAR_INIT) Rte_CANIF_V_x_Obj3Rcs_0x473_V_x_Obj3Rcs_0x473; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_Obj3Status_0x473_V_x_Obj3Status_0x473; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_Obj3Type_0x473_V_x_Obj3Type_0x473; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_Obj4Dynamic_0x475_V_x_Obj4Dynamic_0x475; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_Obj4ID_0x475_V_x_Obj4ID_0x475; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt8, RTE_VAR_INIT) Rte_CANIF_V_x_Obj4Rcs_0x475_V_x_Obj4Rcs_0x475; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_Obj4Status_0x475_V_x_Obj4Status_0x475; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_Obj4Type_0x475_V_x_Obj4Type_0x475; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_Obj5Dynamic_0x477_V_x_Obj5Dynamic_0x477; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_Obj5ID_0x477_V_x_Obj5ID_0x477; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt8, RTE_VAR_INIT) Rte_CANIF_V_x_Obj5Rcs_0x477_V_x_Obj5Rcs_0x477; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_Obj5Status_0x477_V_x_Obj5Status_0x477; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_Obj5Type_0x477_V_x_Obj5Type_0x477; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_Obj6HypoType_0x57C_V_x_Obj6HypoType_0x57C; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_Obj6ID_0x57C_V_x_Obj6ID_0x57C; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_Obj7HypoType_0x57E_V_x_Obj7HypoType_0x57E; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_Obj7ID_0x57E_V_x_Obj7ID_0x57E; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_Obj8HypoType_0x5AC_V_x_Obj8HypoType_0x5AC; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_Obj8ID_0x5AC_V_x_Obj8ID_0x5AC; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_Obj9HypoType_0x5AE_V_x_Obj9HypoType_0x5AE; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_Obj9ID_0x5AE_V_x_Obj9ID_0x5AE; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_ObjClass_ACC_0x205_V_x_ObjClass_ACC_0x205; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_ObjDynProp_0x24A_V_x_ObjDynProp_0x24A; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_ObjDynProp_0x24B_V_x_ObjDynProp_0x24B; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_ObjDynProp_0x24C_V_x_ObjDynProp_0x24C; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_ObjDynProp_0x24D_V_x_ObjDynProp_0x24D; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_ObjDynProp_0x24E_V_x_ObjDynProp_0x24E; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_ObjDynProp_0x24F_V_x_ObjDynProp_0x24F; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_ObjDynProp_0x250_V_x_ObjDynProp_0x250; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_ObjDynProp_0x293_V_x_ObjDynProp_0x293; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_ObjDynProp_0x294_V_x_ObjDynProp_0x294; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_ObjDynProp_0x295_V_x_ObjDynProp_0x295; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_ObjID_0x24A_V_x_ObjID_0x24A; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_ObjID_0x24B_V_x_ObjID_0x24B; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_ObjID_0x24C_V_x_ObjID_0x24C; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_ObjID_0x24D_V_x_ObjID_0x24D; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_ObjID_0x24E_V_x_ObjID_0x24E; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_ObjID_0x24F_V_x_ObjID_0x24F; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_ObjID_0x250_V_x_ObjID_0x250; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_ObjID_0x293_V_x_ObjID_0x293; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_ObjID_0x294_V_x_ObjID_0x294; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_ObjID_0x295_V_x_ObjID_0x295; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_ObjectDelay_0x333_V_x_ObjectDelay_0x333; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_OdoCustomerAction_0x47F_V_x_OdoCustomerAction_0x47F; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_OriginOfVehOutsideLockedChange_0x46C_V_x_OriginOfVehOutsideLockedChange_0x46C; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_PSM_DisplayRequest_0x502_V_x_PSM_DisplayRequest_0x502; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_PSM_SoundRequest_0x502_V_x_PSM_SoundRequest_0x502; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_PSM_WarningDisplayRequest_0x502_V_x_PSM_WarningDisplayRequest_0x502; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_PTCNumberThermalStatus_0x46C_V_x_PTCNumberThermalStatus_0x46C; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_ParkAssistSensitivityStatus_0x502_V_x_ParkAssistSensitivityStatus_0x502; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_ParkStatus_0x0A4_V_x_ParkStatus_0x0A4; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_ParkingBrakeBindingStatus_BasicSW_V_x_ParkingBrakeBindingStatus_BasicSW; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_ParkingBrakeRequestInProgress_BasicSW_V_x_ParkingBrakeRequestInProgress_BasicSW; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_ParkingBrakeStatus_BasicSW_V_x_ParkingBrakeStatus_BasicSW; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_ParkingLotCheck1_0x421_V_x_ParkingLotCheck1_0x421; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_ParkingLotCheck2_0x43D_V_x_ParkingLotCheck2_0x43D; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_ParkingLotDefinition1_0x421_V_x_ParkingLotDefinition1_0x421; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_ParkingLotDefinition2_0x43D_V_x_ParkingLotDefinition2_0x43D; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_ParkingLotDetectionTime_0x3D3_V_x_ParkingLotDetectionTime_0x3D3; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CANIF_V_x_ParkingLotLength1_0x421_V_x_ParkingLotLength1_0x421; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CANIF_V_x_ParkingLotLength2_0x43D_V_x_ParkingLotLength2_0x43D; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_ParkingLotWidth1_0x421_V_x_ParkingLotWidth1_0x421; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_ParkingLotWidth2_0x43D_V_x_ParkingLotWidth2_0x43D; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_PassengerDoorState_BasicSW_V_x_PassengerDoorState_BasicSW; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_PedalError_BasicSW_V_x_PedalError_BasicSW; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_PowerTrainStatus_0x0AA_V_x_PowerTrainStatus_0x0AA; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_ProbablyEndLine1_0x421_V_x_ProbablyEndLine1_0x421; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_ProbablyEndLine2_0x43D_V_x_ProbablyEndLine2_0x43D; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_ProbablyFrontLine1_0x421_V_x_ProbablyFrontLine1_0x421; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_ProbablyFrontLine2_0x43D_V_x_ProbablyFrontLine2_0x43D; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_PumpActivationRequest_BCM_0x47D_V_x_PumpActivationRequest_BCM_0x47D; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_RAB_ActivationRequest_0x5FA_V_x_RAB_ActivationRequest_0x5FA; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_RAB_SideRadarCancelReason_0x623_V_x_RAB_SideRadarCancelReason_0x623; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_RESPreSoak_ImmediateReq_HFM_0x46F_V_x_RESPreSoak_ImmediateReq_HFM_0x46F; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_RESstatus_0x418_V_x_RESstatus_0x418; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_RST_DisplayedPreSelectedRange_0x46E_V_x_RST_DisplayedPreSelectedRange_0x46E; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_RST_DisplayedSelectedRange_0x46E_V_x_RST_DisplayedSelectedRange_0x46E; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_RST_LaunchControlReadyMMI_0x46E_V_x_RST_LaunchControlReadyMMI_0x46E; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_RST_LaunchControlReady_0x46E_V_x_RST_LaunchControlReady_0x46E; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_RWSStatus_0x179_V_x_RWSStatus_0x179; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_Rad_IdCamTargetUsedForFusion00_0x3C8_V_x_Rad_IdCamTargetUsedForFusion00_0x3C8; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_Rad_IdCamTargetUsedForFusion01_0x3C8_V_x_Rad_IdCamTargetUsedForFusion01_0x3C8; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_Rad_IdCamTargetUsedForFusion02_0x3C8_V_x_Rad_IdCamTargetUsedForFusion02_0x3C8; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_Rad_IdCamTargetUsedForFusion03_0x3C8_V_x_Rad_IdCamTargetUsedForFusion03_0x3C8; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_Rad_IdCamTargetUsedForFusion04_0x3C8_V_x_Rad_IdCamTargetUsedForFusion04_0x3C8; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_Rad_IdCamTargetUsedForFusion05_0x3C8_V_x_Rad_IdCamTargetUsedForFusion05_0x3C8; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_RainStatus_0x47D_V_x_RainStatus_0x47D; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_RearGearEngaged_BasicSW_V_x_RearGearEngaged_BasicSW; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_RearLeftDoorState_BasicSW_V_x_RearLeftDoorState_BasicSW; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_RearRightDoorState_BasicSW_V_x_RearRightDoorState_BasicSW; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_RequestedSpeedDisplayRequest_0x417_V_x_RequestedSpeedDisplayRequest_0x417; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_RightBoundType_0x2CC_V_x_RightBoundType_0x2CC; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_RightLineColor_0x420_V_x_RightLineColor_0x420; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_RightLineConfidence_0x2CB_V_x_RightLineConfidence_0x2CB; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_RightLineMeasureConfidence_0x2CB_V_x_RightLineMeasureConfidence_0x2CB; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_RoadMarks_0x421_V_x_RoadMarks_0x421; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_RoadStatus_0x421_V_x_RoadStatus_0x421; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt32, RTE_VAR_INIT) Rte_CANIF_V_x_SIGMA_ACU_0x18CC0772_V_x_SIGMA_ACU_0x18CC0772; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt32, RTE_VAR_INIT) Rte_CANIF_V_x_SIGMA_ATCU_0x18CC07E9_V_x_SIGMA_ATCU_0x18CC07E9; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt32, RTE_VAR_INIT) Rte_CANIF_V_x_SIGMA_AVM_0x18CC07BA_V_x_SIGMA_AVM_0x18CC07BA; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt32, RTE_VAR_INIT) Rte_CANIF_V_x_SIGMA_Amplifier_0x18CC07A2_V_x_SIGMA_Amplifier_0x18CC07A2; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt32, RTE_VAR_INIT) Rte_CANIF_V_x_SIGMA_BCM_0x18CC0765_V_x_SIGMA_BCM_0x18CC0765; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt32, RTE_VAR_INIT) Rte_CANIF_V_x_SIGMA_BSWL_0x18CC073E_V_x_SIGMA_BSWL_0x18CC073E; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt32, RTE_VAR_INIT) Rte_CANIF_V_x_SIGMA_BSWR_0x18CC07D5_V_x_SIGMA_BSWR_0x18CC07D5; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt32, RTE_VAR_INIT) Rte_CANIF_V_x_SIGMA_DTCACU_0x18CC0772_V_x_SIGMA_DTCACU_0x18CC0772; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt32, RTE_VAR_INIT) Rte_CANIF_V_x_SIGMA_DTCATCU_0x18CC07E9_V_x_SIGMA_DTCATCU_0x18CC07E9; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt32, RTE_VAR_INIT) Rte_CANIF_V_x_SIGMA_DTCAVM_0x18CC07BA_V_x_SIGMA_DTCAVM_0x18CC07BA; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt32, RTE_VAR_INIT) Rte_CANIF_V_x_SIGMA_DTCAmplifier_0x18CC07A2_V_x_SIGMA_DTCAmplifier_0x18CC07A2; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt32, RTE_VAR_INIT) Rte_CANIF_V_x_SIGMA_DTCBCM_0x18CC0765_V_x_SIGMA_DTCBCM_0x18CC0765; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt32, RTE_VAR_INIT) Rte_CANIF_V_x_SIGMA_DTCBSWL_0x18CC073E_V_x_SIGMA_DTCBSWL_0x18CC073E; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt32, RTE_VAR_INIT) Rte_CANIF_V_x_SIGMA_DTCBSWR_0x18CC07D5_V_x_SIGMA_DTCBSWR_0x18CC07D5; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt32, RTE_VAR_INIT) Rte_CANIF_V_x_SIGMA_DTCECM_0x18CC07E8_V_x_SIGMA_DTCECM_0x18CC07E8; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt32, RTE_VAR_INIT) Rte_CANIF_V_x_SIGMA_DTCEPS_0x18CC0762_V_x_SIGMA_DTCEPS_0x18CC0762; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt32, RTE_VAR_INIT) Rte_CANIF_V_x_SIGMA_DTCFrCamera_0x18CC0727_V_x_SIGMA_DTCFrCamera_0x18CC0727; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt32, RTE_VAR_INIT) Rte_CANIF_V_x_SIGMA_DTCHFM_0x18CC07B9_V_x_SIGMA_DTCHFM_0x18CC07B9; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt32, RTE_VAR_INIT) Rte_CANIF_V_x_SIGMA_DTCIDM_0x18CC0700_V_x_SIGMA_DTCIDM_0x18CC0700; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt32, RTE_VAR_INIT) Rte_CANIF_V_x_SIGMA_DTCIVI_0x18CC0767_V_x_SIGMA_DTCIVI_0x18CC0767; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt32, RTE_VAR_INIT) Rte_CANIF_V_x_SIGMA_DTCMETER_0x18CC0763_V_x_SIGMA_DTCMETER_0x18CC0763; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt32, RTE_VAR_INIT) Rte_CANIF_V_x_SIGMA_DTCRadar_0x18CC0735_V_x_SIGMA_DTCRadar_0x18CC0735; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt32, RTE_VAR_INIT) Rte_CANIF_V_x_SIGMA_DTCSonar_0x18CC076E_V_x_SIGMA_DTCSonar_0x18CC076E; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt32, RTE_VAR_INIT) Rte_CANIF_V_x_SIGMA_DTCTCU_0x18CC0783_V_x_SIGMA_DTCTCU_0x18CC0783; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt32, RTE_VAR_INIT) Rte_CANIF_V_x_SIGMA_DTCUSM_0x18CC076D_V_x_SIGMA_DTCUSM_0x18CC076D; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt32, RTE_VAR_INIT) Rte_CANIF_V_x_SIGMA_DTCVDC_0x18CC0760_V_x_SIGMA_DTCVDC_0x18CC0760; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt32, RTE_VAR_INIT) Rte_CANIF_V_x_SIGMA_ECM_0x18CC07E8_V_x_SIGMA_ECM_0x18CC07E8; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt32, RTE_VAR_INIT) Rte_CANIF_V_x_SIGMA_EPS_0x18CC0762_V_x_SIGMA_EPS_0x18CC0762; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt32, RTE_VAR_INIT) Rte_CANIF_V_x_SIGMA_FrCamera_0x18CC0727_V_x_SIGMA_FrCamera_0x18CC0727; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt32, RTE_VAR_INIT) Rte_CANIF_V_x_SIGMA_HFM_0x18CC07B9_V_x_SIGMA_HFM_0x18CC07B9; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt32, RTE_VAR_INIT) Rte_CANIF_V_x_SIGMA_IDM_0x18CC0700_V_x_SIGMA_IDM_0x18CC0700; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt32, RTE_VAR_INIT) Rte_CANIF_V_x_SIGMA_IVI_0x18CC0767_V_x_SIGMA_IVI_0x18CC0767; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt32, RTE_VAR_INIT) Rte_CANIF_V_x_SIGMA_METER_0x18CC0763_V_x_SIGMA_METER_0x18CC0763; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt32, RTE_VAR_INIT) Rte_CANIF_V_x_SIGMA_Radar_0x18CC0735_V_x_SIGMA_Radar_0x18CC0735; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt32, RTE_VAR_INIT) Rte_CANIF_V_x_SIGMA_Sonar_0x18CC076E_V_x_SIGMA_Sonar_0x18CC076E; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt32, RTE_VAR_INIT) Rte_CANIF_V_x_SIGMA_TCU_0x18CC0783_V_x_SIGMA_TCU_0x18CC0783; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt32, RTE_VAR_INIT) Rte_CANIF_V_x_SIGMA_USM_0x18CC076D_V_x_SIGMA_USM_0x18CC076D; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt32, RTE_VAR_INIT) Rte_CANIF_V_x_SIGMA_VDC_0x18CC0760_V_x_SIGMA_VDC_0x18CC0760; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_SSA_EngineStopAutoForbidden_0x3BD_V_x_SSA_EngineStopAutoForbidden_0x3BD; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_SSAactivationRequest_0x5FA_V_x_SSAactivationRequest_0x5FA; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_SafetyLineDiagState_0x46C_V_x_SafetyLineDiagState_0x46C; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_SailingIdleActivationReq_0x5EC_V_x_SailingIdleActivationReq_0x5EC; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_SailingStopActivationRequest_0x5EC_V_x_SailingStopActivationRequest_0x5EC; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_SeatBeltStatusDriver1stCollision_0x020_V_x_SeatBeltStatusDriver1stCollision_0x020; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_SeatBeltStatusDriver2ndCollision_0x020_V_x_SeatBeltStatusDriver2ndCollision_0x020; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_SeatBeltStatusPass1stCollision_0x020_V_x_SeatBeltStatusPass1stCollision_0x020; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_SeatBeltStatusPass2ndcollision_0x020_V_x_SeatBeltStatusPass2ndcollision_0x020; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_ShiftIndicator_0x417_V_x_ShiftIndicator_0x417; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_ShiftPaddleRequest_0x46C_V_x_ShiftPaddleRequest_0x46C; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_ShifterPosition_0x0A4_V_x_ShifterPosition_0x0A4; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_SideRadarLeft_AlertStatus_0x32C_V_x_SideRadarLeft_AlertStatus_0x32C; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_SideRadarRight_AlertStatus_0x331_V_x_SideRadarRight_AlertStatus_0x331; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_SlipControlRequest_0x3C6_V_x_SlipControlRequest_0x3C6; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_SlotLeftDifficultyLevel_0x502_V_x_SlotLeftDifficultyLevel_0x502; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_SlotRightDifficultyLevel_0x502_V_x_SlotRightDifficultyLevel_0x502; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_SmartKeylessInformationDisplay_0x46C_V_x_SmartKeylessInformationDisplay_0x46C; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_SonarAutoDisplayRequest_0x5EC_V_x_SonarAutoDisplayRequest_0x5EC; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_SonarAutoDisplayState_0x502_V_x_SonarAutoDisplayState_0x502; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_SonarSystemModeStatus_0x53D_V_x_SonarSystemModeStatus_0x53D; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_SonarVehicleDirection_0x322_V_x_SonarVehicleDirection_0x322; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_SoundObstacleZoneStatus_0x53D_V_x_SoundObstacleZoneStatus_0x53D; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_SpeedLimiterOSPDisplayRequest_0x3C2_V_x_SpeedLimiterOSPDisplayRequest_0x3C2; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_StartingMode_BCM_0x46C_V_x_StartingMode_BCM_0x46C; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_SteeringLockFailure_0x46F_V_x_SteeringLockFailure_0x46F; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_SteeringSwitchStatus_BasicSW_V_x_SteeringSwitchStatus_BasicSW; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_StopAutoPhase_0x0B6_V_x_StopAutoPhase_0x0B6; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_StopLampDiagnosis_BasicSW_V_x_StopLampDiagnosis_BasicSW; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_StopSignWarningSuppression_0x3FF_V_x_StopSignWarningSuppression_0x3FF; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_StopStartSwitch_0x46C_V_x_StopStartSwitch_0x46C; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_SwaSensorFailCode_0x0A8_V_x_SwaSensorFailCode_0x0A8; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_SwaSensorInternalStatus_0x0A8_V_x_SwaSensorInternalStatus_0x0A8; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_TFL_AssignmentObject00_0x311_V_x_TFL_AssignmentObject00_0x311; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_TFL_AssignmentObject01_0x32A_V_x_TFL_AssignmentObject01_0x32A; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_TFL_AssignmentObject02_0x34B_V_x_TFL_AssignmentObject02_0x34B; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_TFL_ColorObject00_0x311_V_x_TFL_ColorObject00_0x311; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_TFL_ColorObject01_0x32A_V_x_TFL_ColorObject01_0x32A; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_TFL_ColorObject02_0x34B_V_x_TFL_ColorObject02_0x34B; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_TFL_ObjectIDobject00_0x311_V_x_TFL_ObjectIDobject00_0x311; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_TFL_ObjectIDobject01_0x32A_V_x_TFL_ObjectIDobject01_0x32A; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_TFL_ObjectIDobject02_0x34B_V_x_TFL_ObjectIDobject02_0x34B; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_TFL_Supp1ArrowObject00_0x311_V_x_TFL_Supp1ArrowObject00_0x311; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_TFL_Supp1ArrowObject01_0x32A_V_x_TFL_Supp1ArrowObject01_0x32A; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_TFL_Supp1ArrowObject02_0x34B_V_x_TFL_Supp1ArrowObject02_0x34B; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_TFL_Supp2ArrowObject00_0x311_V_x_TFL_Supp2ArrowObject00_0x311; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_TFL_Supp2ArrowObject01_0x32A_V_x_TFL_Supp2ArrowObject01_0x32A; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_TFL_Supp2ArrowObject02_0x34B_V_x_TFL_Supp2ArrowObject02_0x34B; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_TFL_Supp3ArrowObject00_0x311_V_x_TFL_Supp3ArrowObject00_0x311; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_TFL_Supp3ArrowObject01_0x32A_V_x_TFL_Supp3ArrowObject01_0x32A; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_TFL_Supp3ArrowObject02_0x34B_V_x_TFL_Supp3ArrowObject02_0x34B; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_TFL_SuppressionReasonDriver_0x3FF_V_x_TFL_SuppressionReasonDriver_0x3FF; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_TFL_SuppressionReason_0x3FF_V_x_TFL_SuppressionReason_0x3FF; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_TFL_TimeToCollisionDecision_0x3FF_V_x_TFL_TimeToCollisionDecision_0x3FF; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_TFL_TypeObject00_0x311_V_x_TFL_TypeObject00_0x311; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_TFL_TypeObject01_0x32A_V_x_TFL_TypeObject01_0x32A; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_TFL_TypeObject02_0x34B_V_x_TFL_TypeObject02_0x34B; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_THPNumberThermalRequest_0x47D_V_x_THPNumberThermalRequest_0x47D; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_TPMS_PressureFrontAxleRequest_0x5EC_V_x_TPMS_PressureFrontAxleRequest_0x5EC; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_TPMS_PressureRearAxleRequest_0x5EC_V_x_TPMS_PressureRearAxleRequest_0x5EC; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_TPW_AcknowledgeResetDriver_0x3BD_V_x_TPW_AcknowledgeResetDriver_0x3BD; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_TPW_Status_0x3BD_V_x_TPW_Status_0x3BD; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_TSR_FilterTypeObject00_0x366_V_x_TSR_FilterTypeObject00_0x366; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_TSR_FilterTypeObject01_0x36A_V_x_TSR_FilterTypeObject01_0x36A; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_TSR_NoEntryVisionStatusObject00_0x366_V_x_TSR_NoEntryVisionStatusObject00_0x366; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_TSR_NoEntryVisionStatusObject01_0x36A_V_x_TSR_NoEntryVisionStatusObject01_0x36A; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_TSR_OSPActivationRequest_0x5EC_V_x_TSR_OSPActivationRequest_0x5EC; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_TSR_SignHorizontalSizeObject00_0x366_V_x_TSR_SignHorizontalSizeObject00_0x366; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_TSR_SignHorizontalSizeObject01_0x36A_V_x_TSR_SignHorizontalSizeObject01_0x36A; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_TSR_SignVerticalSizeObject00_0x366_V_x_TSR_SignVerticalSizeObject00_0x366; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_TSR_SignVerticalSizeObject01_0x36A_V_x_TSR_SignVerticalSizeObject01_0x36A; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_CANIF_V_x_TSR_VisionOnlySignTypeObject00_0x366_V_x_TSR_VisionOnlySignTypeObject00_0x366; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_CANIF_V_x_TSR_VisionOnlySignTypeObject01_0x36A_V_x_TSR_VisionOnlySignTypeObject01_0x36A; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_TailGateButtonPushed_0x46C_V_x_TailGateButtonPushed_0x46C; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_TailGateStatus_BasicSW_V_x_TailGateStatus_BasicSW; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_TakeOffInhibitionWarning_0x3C4_V_x_TakeOffInhibitionWarning_0x3C4; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt32, RTE_VAR_INIT) Rte_CANIF_V_x_TargetCVTRatioExtended_BasicSW_V_x_TargetCVTRatioExtended_BasicSW; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_TargetSource00_0x49B_V_x_TargetSource00_0x49B; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_TargetSource01_0x49B_V_x_TargetSource01_0x49B; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_TargetSource02_0x49B_V_x_TargetSource02_0x49B; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_TargetSource03_0x49B_V_x_TargetSource03_0x49B; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_TargetSource04_0x49B_V_x_TargetSource04_0x49B; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_TargetSource05_0x49B_V_x_TargetSource05_0x49B; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_TorqueConverterState_0x0A6_V_x_TorqueConverterState_0x0A6; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_TorqueRequestStatus_0x0B6_V_x_TorqueRequestStatus_0x0B6; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_TorqueVectoringIndicateReq_RL_0x25F_V_x_TorqueVectoringIndicateReq_RL_0x25F; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_TorqueVectoringIndicateReq_RR_0x25F_V_x_TorqueVectoringIndicateReq_RR_0x25F; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_TrackingIDleft1_0x32C_V_x_TrackingIDleft1_0x32C; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_TrackingIDleft2_0x32D_V_x_TrackingIDleft2_0x32D; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_TrackingIDleft3_0x32E_V_x_TrackingIDleft3_0x32E; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_TrackingIDleft4_0x32F_V_x_TrackingIDleft4_0x32F; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_TrackingIDright1_0x331_V_x_TrackingIDright1_0x331; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_TrackingIDright2_0x332_V_x_TrackingIDright2_0x332; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_TrackingIDright3_0x334_V_x_TrackingIDright3_0x334; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_TrackingIDright4_0x336_V_x_TrackingIDright4_0x336; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_TransmRangeEngaged_Current_BasicSW_V_x_TransmRangeEngaged_Current_BasicSW; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_TransmRangeEngaged_Target_BasicSW_V_x_TransmRangeEngaged_Target_BasicSW; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_UPA_Obstacle_Zone_Rear_Center_0x53D_V_x_UPA_Obstacle_Zone_Rear_Center_0x53D; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_UPA_Obstacle_Zone_Rear_Left_0x53D_V_x_UPA_Obstacle_Zone_Rear_Left_0x53D; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_UPA_Obstacle_Zone_Rear_Right_0x53D_V_x_UPA_Obstacle_Zone_Rear_Right_0x53D; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_UTA_AlertActivationRequest_0x5EC_V_x_UTA_AlertActivationRequest_0x5EC; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_UserIdent_HandFree_0x46F_V_x_UserIdent_HandFree_0x46F; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_UserIdent_RKE_0x46F_V_x_UserIdent_RKE_0x46F; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_VCR_CompressionRatio_0x417_V_x_VCR_CompressionRatio_0x417; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_VDC_FLWheelSpeedSensorResult_0x3BD_V_x_VDC_FLWheelSpeedSensorResult_0x3BD; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_VDC_FRWheelSpeedSensorResult_0x3BD_V_x_VDC_FRWheelSpeedSensorResult_0x3BD; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_VDC_RLWheelSpeedSensorResult_0x3BD_V_x_VDC_RLWheelSpeedSensorResult_0x3BD; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_VDC_RRWheelSpeedSensorResult_0x3BD_V_x_VDC_RRWheelSpeedSensorResult_0x3BD; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_VDC_ShiftMapChangeRequest_0x3BD_V_x_VDC_ShiftMapChangeRequest_0x3BD; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_VDC_StandStillStatus_0x202_V_x_VDC_StandStillStatus_0x202; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_VDCactivationRequest_0x5FA_V_x_VDCactivationRequest_0x5FA; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_CANIF_V_x_VehicleSpeedDisplayValue_0x47F_V_x_VehicleSpeedDisplayValue_0x47F; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_VehicleSpeedSign_0x3BD_V_x_VehicleSpeedSign_0x3BD; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_VehicleStates_BasicSW_V_x_VehicleStates_BasicSW; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_WDA_ActivationRequest_0x5FA_V_x_WDA_ActivationRequest_0x5FA; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_WakeUpType_0x47D_V_x_WakeUpType_0x47D; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_WelcomeSequenceStatus_0x47F_V_x_WelcomeSequenceStatus_0x47F; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_WheelDirectionRL_0x202_V_x_WheelDirectionRL_0x202; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_WheelDirectionRR_0x202_V_x_WheelDirectionRR_0x202; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_WheelTopFL_BasicSW_V_x_WheelTopFL_BasicSW; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_WheelTopFR_BasicSW_V_x_WheelTopFR_BasicSW; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_WheelTopRL_BasicSW_V_x_WheelTopRL_BasicSW; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_WheelTopRR_BasicSW_V_x_WheelTopRR_BasicSW; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_fDGNOK_BasicSW_V_x_fDGNOK_BasicSW; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_CANIF_V_x_iKeyFobAuthentStatus_0x46F_V_x_iKeyFobAuthentStatus_0x46F; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_Control_Lat_F_x_ActiveHoldedState_F_x_ActiveHoldedState; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(boolean_NP, RTE_VAR_INIT) Rte_Control_Lat_F_x_ControlActiveState_F_x_ControlActiveState; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(boolean_NP, RTE_VAR_INIT) Rte_Control_Lat_F_x_EmergencyStopAccelSupReq_F_x_EmergencyStopAccelSupReq; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_Control_Lat_F_x_EmergencyStopBrkReq_F_x_EmergencyStopBrkReq; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_Control_Lat_F_x_EmergencyStopBuz1_F_x_EmergencyStopBuz1; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_Control_Lat_F_x_EmergencyStopBuz2_F_x_EmergencyStopBuz2; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_Control_Lat_F_x_EmergencyStopBuz3_F_x_EmergencyStopBuz3; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_Control_Lat_F_x_EmergencyStopHazardLampReq_F_x_EmergencyStopHazardLampReq; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(boolean_NP, RTE_VAR_INIT) Rte_Control_Lat_F_x_EmergencyStopPreBrkReq_F_x_EmergencyStopPreBrkReq; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(boolean_NP, RTE_VAR_INIT) Rte_Control_Lat_F_x_EmergencyStopPreFillBrkReq_F_x_EmergencyStopPreFillBrkReq; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(boolean_NP, RTE_VAR_INIT) Rte_Control_Lat_F_x_HODJudgeInFricTrqCalib_F_x_HODJudgeInFricTrqCalib; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_Control_Lat_F_x_HandsOffBlinkReq_F_x_HandsOffBlinkReq; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_Control_Lat_F_x_HandsOffSysOff_F_x_HandsOffSysOff; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_Control_Lat_F_x_HandsoffBuz_F_x_HandsoffBuz; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_Control_Lat_F_x_INH_OBS_DET_F_x_INH_OBS_DET; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(boolean_NP, RTE_VAR_INIT) Rte_Control_Lat_F_x_INH_OBS_DET_CAM_BLOCK_F_x_INH_OBS_DET_CAM_BLOCK; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(boolean_NP, RTE_VAR_INIT) Rte_Control_Lat_F_x_INH_OBS_DET_WIPER_F_x_INH_OBS_DET_WIPER; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(boolean_NP, RTE_VAR_INIT) Rte_Control_Lat_F_x_LDWActiveHandsOffLeft_F_x_LDWActiveHandsOffLeft; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(boolean_NP, RTE_VAR_INIT) Rte_Control_Lat_F_x_LDWActiveHandsOffRight_F_x_LDWActiveHandsOffRight; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(boolean_NP, RTE_VAR_INIT) Rte_Control_Lat_F_x_LKALowMode_F_x_LKALowMode; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_Control_Lat_F_x_LaneDispStartBuz_F_x_LaneDispStartBuz; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_Control_Lat_F_x_LaneLostBuz_F_x_LaneLostBuz; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_Control_Lat_F_x_LineCross_F_x_LineCross; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_Control_Lat_F_x_MssHfWReq_F_x_MssHfWReq; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(boolean_NP, RTE_VAR_INIT) Rte_Control_Lat_F_x_STR_CONT_TEMP_LANE_OFF_F_x_STR_CONT_TEMP_LANE_OFF; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(boolean_NP, RTE_VAR_INIT) Rte_Control_Lat_F_x_SWAOffsetWriteToEeprom_F_x_SWAOffsetWriteToEeprom; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_Control_Lat_F_x_SteeringAngleRequestOrder_F_x_SteeringAngleRequestOrder; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_Control_Lat_F_x_SteeringAngleRequestOrderz1_F_x_SteeringAngleRequestOrderz1; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_Control_Lat_F_x_StrgCancelPouup_F_x_StrgCancelPouup; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_Control_Lat_F_x_TgtLnReq_F_x_TgtLnReq; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(boolean_NP, RTE_VAR_INIT) Rte_Control_Lat_F_x_TrafficLightsDisable_F_x_TrafficLightsDisable; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(boolean_NP, RTE_VAR_INIT) Rte_Control_Lat_F_x_WiperHighActive_F_x_WiperHighActive; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(boolean_NP, RTE_VAR_INIT) Rte_Control_Lat_F_x_WiperLowActive_F_x_WiperLowActive; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(float32_NP, RTE_VAR_INIT) Rte_Control_Lat_V_deg_SetSWAOffsetEeprom_V_deg_SetSWAOffsetEeprom; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(float32_NP, RTE_VAR_INIT) Rte_Control_Lat_V_nm_GetStrTrqDiffLatestFromLat_V_nm_GetStrTrqDiffLatestFromLat; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(float32_NP, RTE_VAR_INIT) Rte_Control_Lat_V_pm_CurvatureFlt1_V_pm_CurvatureFlt1; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Float, RTE_VAR_INIT) Rte_Control_Lat_V_rad_SteeringWheelAngle_Req_V_rad_SteeringWheelAngle_Req; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(float32_NP, RTE_VAR_INIT) Rte_Control_Lat_V_radps_YawRateCorrected_V_radps_YawRateCorrected; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Float, RTE_VAR_INIT) Rte_Control_Lat_V_x_GainEpsK1_V_x_GainEpsK1; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Float, RTE_VAR_INIT) Rte_Control_Lat_V_x_GainEpsK2_V_x_GainEpsK2; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_Control_Lat_V_x_HODJudgeTypeInFricTrqCalib_V_x_HODJudgeTypeInFricTrqCalib; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_Control_Lat_V_x_LaneState_V_x_LaneState; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_Control_Lat_V_x_StrAsstSts_V_x_StrAsstSts; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_Control_Longi_F_x_ACCBrakeWheelTorqueOrder_F_x_ACCBrakeWheelTorqueOrder; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_Control_Longi_F_x_ACCRegulationActive_F_x_ACCRegulationActive; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_Control_Longi_F_x_ACC_BusyShiftLimitRequest_F_x_ACC_BusyShiftLimitRequest; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_Control_Longi_F_x_APO_ONCE_ACC1_F_x_APO_ONCE_ACC1; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_Control_Longi_F_x_ASCD_G_HOJI_F_x_ASCD_G_HOJI; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(boolean_NP, RTE_VAR_INIT) Rte_Control_Longi_F_x_ASC_InhibitRequest_F_x_ASC_InhibitRequest; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_Control_Longi_F_x_ApproachWarningDisplay_F_x_ApproachWarningDisplay; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_Control_Longi_F_x_ApproachWarningSound_F_x_ApproachWarningSound; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_Control_Longi_F_x_BAR_FLUSH_ALLOW_F_x_BAR_FLUSH_ALLOW; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_Control_Longi_F_x_BAR_OFF_ALLOW_F_x_BAR_OFF_ALLOW; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_Control_Longi_F_x_CANCEL_READY_F_x_CANCEL_READY; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_Control_Longi_F_x_CancelSound_F_x_CancelSound; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_Control_Longi_F_x_CruiseDisplay_F_x_CruiseDisplay; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_Control_Longi_F_x_DVSP_OVER_F_x_DVSP_OVER; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_Control_Longi_F_x_DispLockBlinkCont_F_x_DispLockBlinkCont; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_Control_Longi_F_x_GOSTP_AUTO_CLR_F_x_GOSTP_AUTO_CLR; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_Control_Longi_F_x_LongStop_F_x_LongStop; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_Control_Longi_F_x_LowSpeed_F_x_LowSpeed; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_Control_Longi_F_x_MRMFebBrkAct_F_x_MRMFebBrkAct; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_Control_Longi_F_x_MinusSet_F_x_MinusSet; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_Control_Longi_F_x_PlusSet_F_x_PlusSet; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_Control_Longi_F_x_RestartReserve_F_x_RestartReserve; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_Control_Longi_F_x_SETV_ACC_ON_F_x_SETV_ACC_ON; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_Control_Longi_F_x_SIG_SETforTJP_F_x_SIG_SETforTJP; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_Control_Longi_F_x_SetResAllow_F_x_SetResAllow; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_Control_Longi_F_x_SetSpeedBlink_F_x_SetSpeedBlink; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_Control_Longi_F_x_SwitchToLowSpeed_F_x_SwitchToLowSpeed; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(boolean_NP, RTE_VAR_INIT) Rte_Control_Longi_F_x_TJPStartRequest_F_x_TJPStartRequest; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_Control_Longi_F_x_TJP_SLOPE_CANCEL_REQ_F_x_TJP_SLOPE_CANCEL_REQ; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_Control_Longi_F_x_TakeOverRequestedLevel_F_x_TakeOverRequestedLevel; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_Control_Longi_F_x_TargetDisplay_F_x_TargetDisplay; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_Control_Longi_V_bar_PRSSR_SENSR_VAL_V_bar_PRSSR_SENSR_VAL; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(float32_NP, RTE_VAR_INIT) Rte_Control_Longi_V_mps2_AccComLim_Req_V_mps2_AccComLim_Req; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Float, RTE_VAR_INIT) Rte_Control_Longi_V_mps_RequestedSpeedLim_V_mps_RequestedSpeedLim; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Float, RTE_VAR_INIT) Rte_Control_Longi_V_mps_VehicleSpeed_V_mps_VehicleSpeed; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Float, RTE_VAR_INIT) Rte_Control_Longi_V_nm_BrakeWheelTorqueCmd_Req_V_nm_BrakeWheelTorqueCmd_Req; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Float, RTE_VAR_INIT) Rte_Control_Longi_V_nm_PWTWheelTorqueCmd_Req_V_nm_PWTWheelTorqueCmd_Req; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_Control_Longi_V_x_ACC_Status_NiSW_V_x_ACC_Status_NiSW; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_Control_Longi_V_x_ControlLongiState_V_x_ControlLongiState; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_Control_Longi_V_x_DistanceLevelDisplay_V_x_DistanceLevelDisplay; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_Control_Longi_V_x_GUIDE_P_V_x_GUIDE_P; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_Control_Longi_V_x_HI_GEAR_INH_ADAS_V_x_HI_GEAR_INH_ADAS; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_Control_Longi_V_x_InternalACCStatus_V_x_InternalACCStatus; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_Control_Longi_V_x_PRSSR_SENSR_VAL_V_x_PRSSR_SENSR_VAL; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_Control_Longi_V_x_SetSpeedCfg_Req_V_x_SetSpeedCfg_Req; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_Control_Longi_V_x_StopAutoForbidden_V_x_StopAutoForbidden; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_Control_Longi_V_x_TimeGapRange_V_x_TimeGapRange; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_Control_Longi_V_x_VehicleHoldRequest_V_x_VehicleHoldRequest; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_Control_Longi_V_x_Vehicle_Hold_Request_V_x_Vehicle_Hold_Request; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_DAA_F_x_Alert_flag_F_x_Alert_flag; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_DAA_V_x_AttentionLevel_n_V_x_AttentionLevel_n; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_DiagControl_F_x_ExeCameraAimingNotDone_F_x_ExeCameraAimingNotDone; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_DiagControl_F_x_ExeRADShaftMisAlignment_F_x_ExeRADShaftMisAlignment; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_DiagControl_F_x_ExeVariantCodeErr_F_x_ExeVariantCodeErr; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_DiagControl_F_x_Exe_ABSActCancel_F_x_Exe_ABSActCancel; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_DiagControl_F_x_Exe_ABSActCancel_ACC_F_x_Exe_ABSActCancel_ACC; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_DiagControl_F_x_Exe_ABSSystem_A_F_x_Exe_ABSSystem_A; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_DiagControl_F_x_Exe_ABSSystem_C_F_x_Exe_ABSSystem_C; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_DiagControl_F_x_Exe_AccelPedal_F_x_Exe_AccelPedal; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_DiagControl_F_x_Exe_AtMisMatch_F_x_Exe_AtMisMatch; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_DiagControl_F_x_Exe_AtNoDrange_F_x_Exe_AtNoDrange; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_DiagControl_F_x_Exe_AtRPrange_F_x_Exe_AtRPrange; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_DiagControl_F_x_Exe_BrkCmdPressFail_F_x_Exe_BrkCmdPressFail; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_DiagControl_F_x_Exe_BrkDriverACC_F_x_Exe_BrkDriverACC; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_DiagControl_F_x_Exe_BrkDriverFEB_F_x_Exe_BrkDriverFEB; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_DiagControl_F_x_Exe_BrkDriverTJP_F_x_Exe_BrkDriverTJP; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_DiagControl_F_x_Exe_BrkLampOff_F_x_Exe_BrkLampOff; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_DiagControl_F_x_Exe_BrkLampOn_F_x_Exe_BrkLampOn; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_DiagControl_F_x_Exe_BrkSWFail_F_x_Exe_BrkSWFail; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_DiagControl_F_x_Exe_BrkSwHdc_On_F_x_Exe_BrkSwHdc_On; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_DiagControl_F_x_Exe_CAM_Fail_F_x_Exe_CAM_Fail; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_DiagControl_F_x_Exe_CAM_HiTemp1_F_x_Exe_CAM_HiTemp1; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_DiagControl_F_x_Exe_ClutchMisMatch_F_x_Exe_ClutchMisMatch; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_DiagControl_F_x_Exe_CtrlASCD_F_x_Exe_CtrlASCD; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_DiagControl_F_x_Exe_CtrlActSameTgt_F_x_Exe_CtrlActSameTgt; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_DiagControl_F_x_Exe_CtrlActTime_F_x_Exe_CtrlActTime; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_DiagControl_F_x_Exe_CtrlActTimeDBA_F_x_Exe_CtrlActTimeDBA; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_DiagControl_F_x_Exe_CtrlAngSpdCanc1_F_x_Exe_CtrlAngSpdCanc1; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_DiagControl_F_x_Exe_CtrlAngSpdCanc2_F_x_Exe_CtrlAngSpdCanc2; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_DiagControl_F_x_Exe_CtrlCBA_F_x_Exe_CtrlCBA; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_DiagControl_F_x_Exe_CtrlCurvature_F_x_Exe_CtrlCurvature; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_DiagControl_F_x_Exe_CtrlDBABrake_F_x_Exe_CtrlDBABrake; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_DiagControl_F_x_Exe_CtrlDoorOpenExCockpit_F_x_Exe_CtrlDoorOpenExCockpit; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_DiagControl_F_x_Exe_CtrlDpbActErr_F_x_Exe_CtrlDpbActErr; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_DiagControl_F_x_Exe_CtrlDrop_F_x_Exe_CtrlDrop; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_DiagControl_F_x_Exe_CtrlDropTJP_F_x_Exe_CtrlDropTJP; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_DiagControl_F_x_Exe_CtrlElapsedTime_F_x_Exe_CtrlElapsedTime; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_DiagControl_F_x_Exe_CtrlEmergeBrake_F_x_Exe_CtrlEmergeBrake; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_DiagControl_F_x_Exe_CtrlIpa_F_x_Exe_CtrlIpa; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_DiagControl_F_x_Exe_CtrlLostFollow_F_x_Exe_CtrlLostFollow; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_DiagControl_F_x_Exe_CtrlLostInch_F_x_Exe_CtrlLostInch; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_DiagControl_F_x_Exe_CtrlLowSPD_F_x_Exe_CtrlLowSPD; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_DiagControl_F_x_Exe_CtrlMaxVspCanc_F_x_Exe_CtrlMaxVspCanc; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_DiagControl_F_x_Exe_CtrlMinVspCanc_F_x_Exe_CtrlMinVspCanc; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_DiagControl_F_x_Exe_CtrlPreBrake_F_x_Exe_CtrlPreBrake; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_DiagControl_F_x_Exe_CtrlPulled_F_x_Exe_CtrlPulled; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_DiagControl_F_x_Exe_CtrlSideG1_Act_F_x_Exe_CtrlSideG1_Act; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_DiagControl_F_x_Exe_CtrlSideG1_NoAct_F_x_Exe_CtrlSideG1_NoAct; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_DiagControl_F_x_Exe_CtrlSideG2_Act_F_x_Exe_CtrlSideG2_Act; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_DiagControl_F_x_Exe_CtrlSideG2_NoAct_F_x_Exe_CtrlSideG2_NoAct; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_DiagControl_F_x_Exe_CtrlSlip_F_x_Exe_CtrlSlip; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_DiagControl_F_x_Exe_CtrlSteepSlope_F_x_Exe_CtrlSteepSlope; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_DiagControl_F_x_Exe_CtrlStpAutoACC_F_x_Exe_CtrlStpAutoACC; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_DiagControl_F_x_Exe_CtrlStpAutoFCA_F_x_Exe_CtrlStpAutoFCA; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_DiagControl_F_x_Exe_CtrlStpAutoTJP_F_x_Exe_CtrlStpAutoTJP; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_DiagControl_F_x_Exe_CtrlStpBrkAndAccele_F_x_Exe_CtrlStpBrkAndAccele; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_DiagControl_F_x_Exe_CtrlStpFfpACC_F_x_Exe_CtrlStpFfpACC; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_DiagControl_F_x_Exe_CtrlStpFfpFCA_F_x_Exe_CtrlStpFfpFCA; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_DiagControl_F_x_Exe_CtrlStpLostACC_F_x_Exe_CtrlStpLostACC; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_DiagControl_F_x_Exe_CtrlStrAngleCanc1_F_x_Exe_CtrlStrAngleCanc1; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_DiagControl_F_x_Exe_CtrlStrAngleCanc2_F_x_Exe_CtrlStrAngleCanc2; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_DiagControl_F_x_Exe_CtrlYawrate_F_x_Exe_CtrlYawrate; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_DiagControl_F_x_Exe_CvtFail_F_x_Exe_CvtFail; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_DiagControl_F_x_Exe_CvtGSens_F_x_Exe_CvtGSens; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_DiagControl_F_x_Exe_CvtMisMatch_F_x_Exe_CvtMisMatch; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_DiagControl_F_x_Exe_DgnOkCancel_F_x_Exe_DgnOkCancel; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_DiagControl_F_x_Exe_ETCFail_F_x_Exe_ETCFail; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_DiagControl_F_x_Exe_EapCancel_F_x_Exe_EapCancel; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_DiagControl_F_x_Exe_EcmAccC_F_x_Exe_EcmAccC; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_DiagControl_F_x_Exe_EcmAccF_F_x_Exe_EcmAccF; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_DiagControl_F_x_Exe_EcmAccInh_F_x_Exe_EcmAccInh; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_DiagControl_F_x_Exe_EcmAscd_A_F_x_Exe_EcmAscd_A; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_DiagControl_F_x_Exe_EcmAscd_C_F_x_Exe_EcmAscd_C; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_DiagControl_F_x_Exe_EcmEng_F_x_Exe_EcmEng; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_DiagControl_F_x_Exe_EngOff_F_x_Exe_EngOff; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_DiagControl_F_x_Exe_EpsSystemCancel_F_x_Exe_EpsSystemCancel; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_DiagControl_F_x_Exe_EpsSystemErr_F_x_Exe_EpsSystemErr; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_DiagControl_F_x_Exe_FEBCountFail_F_x_Exe_FEBCountFail; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_DiagControl_F_x_Exe_FEB_YawrateSafeSts_F_x_Exe_FEB_YawrateSafeSts; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_DiagControl_F_x_Exe_HevRdy_F_x_Exe_HevRdy; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_DiagControl_F_x_Exe_HevSys_F_x_Exe_HevSys; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_DiagControl_F_x_Exe_ICCCanFail_F_x_Exe_ICCCanFail; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_DiagControl_F_x_Exe_ICCCmdFail_F_x_Exe_ICCCmdFail; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_DiagControl_F_x_Exe_IDMCanFail_A_F_x_Exe_IDMCanFail_A; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_DiagControl_F_x_Exe_IDMCanFail_C_F_x_Exe_IDMCanFail_C; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_DiagControl_F_x_Exe_IGNVolt_H_F_x_Exe_IGNVolt_H; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_DiagControl_F_x_Exe_IGNVolt_L_F_x_Exe_IGNVolt_L; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_DiagControl_F_x_Exe_IdmTrqFail_F_x_Exe_IdmTrqFail; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_DiagControl_F_x_Exe_LDPFunc_A_F_x_Exe_LDPFunc_A; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_DiagControl_F_x_Exe_LDPFunc_C_F_x_Exe_LDPFunc_C; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_DiagControl_F_x_Exe_LsAlignmentMonitor_F_x_Exe_LsAlignmentMonitor; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_DiagControl_F_x_Exe_LsAllowDistMoveW1_F_x_Exe_LsAllowDistMoveW1; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_DiagControl_F_x_Exe_LsAllowDistMoveW2_F_x_Exe_LsAllowDistMoveW2; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_DiagControl_F_x_Exe_LsAllowDistStopW1_F_x_Exe_LsAllowDistStopW1; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_DiagControl_F_x_Exe_LsAllowDistStopW2_F_x_Exe_LsAllowDistStopW2; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_DiagControl_F_x_Exe_LsCameraFusion_F_x_Exe_LsCameraFusion; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_DiagControl_F_x_Exe_LsConfidence_F_x_Exe_LsConfidence; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_DiagControl_F_x_Exe_LsDbaSupF2_F_x_Exe_LsDbaSupF2; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_DiagControl_F_x_Exe_LsFcaEnblF1_F_x_Exe_LsFcaEnblF1; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_DiagControl_F_x_Exe_LsFcaEnblF3_F_x_Exe_LsFcaEnblF3; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_DiagControl_F_x_Exe_LsGuardrail_F_x_Exe_LsGuardrail; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_DiagControl_F_x_Exe_LsHypothesis_F_x_Exe_LsHypothesis; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_DiagControl_F_x_Exe_LsProbability_F_x_Exe_LsProbability; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_DiagControl_F_x_Exe_LsRadarCheckInh_F_x_Exe_LsRadarCheckInh; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_DiagControl_F_x_Exe_LsTgtLost_F_x_Exe_LsTgtLost; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_DiagControl_F_x_Exe_LsTgtLostFcw_F_x_Exe_LsTgtLostFcw; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_DiagControl_F_x_Exe_LsVrelCanc_F_x_Exe_LsVrelCanc; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_DiagControl_F_x_Exe_Ls_EmergeBrk_PMT_F_x_Exe_Ls_EmergeBrk_PMT; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_DiagControl_F_x_Exe_Ls_PreBrk_PMT_F_x_Exe_Ls_PreBrk_PMT; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_DiagControl_F_x_Exe_RadBlockage_F_x_Exe_RadBlockage; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_DiagControl_F_x_Exe_RadBlockageMsgByCam_F_x_Exe_RadBlockageMsgByCam; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_DiagControl_F_x_Exe_RadCanFail_F_x_Exe_RadCanFail; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_DiagControl_F_x_Exe_RadFail_F_x_Exe_RadFail; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_DiagControl_F_x_Exe_RadHiTemp_F_x_Exe_RadHiTemp; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_DiagControl_F_x_Exe_RadVolt_L_F_x_Exe_RadVolt_L; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_DiagControl_F_x_Exe_RadWaveInterf_F_x_Exe_RadWaveInterf; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_DiagControl_F_x_Exe_SCAM3_BlurImg_F_x_Exe_SCAM3_BlurImg; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_DiagControl_F_x_Exe_SCAM3_BlurImg_ICC_F_x_Exe_SCAM3_BlurImg_ICC; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_DiagControl_F_x_Exe_SCAM3_Foggy_F_x_Exe_SCAM3_Foggy; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_DiagControl_F_x_Exe_SCAM3_Foggy_ICC_F_x_Exe_SCAM3_Foggy_ICC; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_DiagControl_F_x_Exe_SCAM3_FullBlk_F_x_Exe_SCAM3_FullBlk; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_DiagControl_F_x_Exe_SCAM3_Halos_F_x_Exe_SCAM3_Halos; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_DiagControl_F_x_Exe_SCAM3_LowSun_F_x_Exe_SCAM3_LowSun; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_DiagControl_F_x_Exe_SCAM3_MisFocus_F_x_Exe_SCAM3_MisFocus; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_DiagControl_F_x_Exe_SCAM3_PartialBlk_F_x_Exe_SCAM3_PartialBlk; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_DiagControl_F_x_Exe_SCAM3_PitMisAlign_F_x_Exe_SCAM3_PitMisAlign; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_DiagControl_F_x_Exe_SCAM3_PitchThOut_F_x_Exe_SCAM3_PitchThOut; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_DiagControl_F_x_Exe_SCAM3_SmearImg_F_x_Exe_SCAM3_SmearImg; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_DiagControl_F_x_Exe_SCAM3_SmearImg_ICC_F_x_Exe_SCAM3_SmearImg_ICC; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_DiagControl_F_x_Exe_SCAM3_SmearSpot_F_x_Exe_SCAM3_SmearSpot; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_DiagControl_F_x_Exe_SCAM3_SmearedSptM_F_x_Exe_SCAM3_SmearedSptM; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_DiagControl_F_x_Exe_SCAM3_Splashes_F_x_Exe_SCAM3_Splashes; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_DiagControl_F_x_Exe_SCAM3_Splashes_ICC_F_x_Exe_SCAM3_Splashes_ICC; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_DiagControl_F_x_Exe_SCAM3_SunRay_F_x_Exe_SCAM3_SunRay; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_DiagControl_F_x_Exe_SCAM3_SunRay_ICC_F_x_Exe_SCAM3_SunRay_ICC; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_DiagControl_F_x_Exe_SCAM3_YawMisAlign_F_x_Exe_SCAM3_YawMisAlign; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_DiagControl_F_x_Exe_SCAM3_YawThOut_F_x_Exe_SCAM3_YawThOut; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_DiagControl_F_x_Exe_SOWSenCANUnRcv_L_F_x_Exe_SOWSenCANUnRcv_L; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_DiagControl_F_x_Exe_SOWSenCANUnRcv_R_F_x_Exe_SOWSenCANUnRcv_R; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_DiagControl_F_x_Exe_SOWSensorFail_L_F_x_Exe_SOWSensorFail_L; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_DiagControl_F_x_Exe_SOWSensorFail_R_F_x_Exe_SOWSensorFail_R; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_DiagControl_F_x_Exe_STRSensorFail_F_x_Exe_STRSensorFail; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_DiagControl_F_x_Exe_SW1_F_x_Exe_SW1; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_DiagControl_F_x_Exe_SW3_F_x_Exe_SW3; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_DiagControl_F_x_Exe_SenGUnavail_F_x_Exe_SenGUnavail; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_DiagControl_F_x_Exe_SenNoise_F_x_Exe_SenNoise; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_DiagControl_F_x_Exe_SenPulseL_F_x_Exe_SenPulseL; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_DiagControl_F_x_Exe_SenPulseR_F_x_Exe_SenPulseR; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_DiagControl_F_x_Exe_SenSonar_B_F_x_Exe_SenSonar_B; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_DiagControl_F_x_Exe_SenSow2L_F_x_Exe_SenSow2L; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_DiagControl_F_x_Exe_SenSow2R_F_x_Exe_SenSow2R; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_DiagControl_F_x_Exe_SenSpd_A_F_x_Exe_SenSpd_A; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_DiagControl_F_x_Exe_SenSpd_C_F_x_Exe_SenSpd_C; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_DiagControl_F_x_Exe_SenWheelC_F_x_Exe_SenWheelC; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_DiagControl_F_x_Exe_SenWheelUnavail_F_x_Exe_SenWheelUnavail; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_DiagControl_F_x_Exe_StbAbsLamp_ACC_F_x_Exe_StbAbsLamp_ACC; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_DiagControl_F_x_Exe_StbIdmFail_F_x_Exe_StbIdmFail; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_DiagControl_F_x_Exe_StbVdcEcu_F_x_Exe_StbVdcEcu; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_DiagControl_F_x_Exe_SwApoOvr_Kinkyu_F_x_Exe_SwApoOvr_Kinkyu; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_DiagControl_F_x_Exe_SwApoOvr_Yobi_F_x_Exe_SwApoOvr_Yobi; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_DiagControl_F_x_Exe_SwApoWorkUp_F_x_Exe_SwApoWorkUp; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_DiagControl_F_x_Exe_SwCancel_F_x_Exe_SwCancel; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_DiagControl_F_x_Exe_SwClutch_F_x_Exe_SwClutch; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_DiagControl_F_x_Exe_SwDouble_F_x_Exe_SwDouble; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_DiagControl_F_x_Exe_SwEtsMod_F_x_Exe_SwEtsMod; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_DiagControl_F_x_Exe_SwFebOff_F_x_Exe_SwFebOff; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_DiagControl_F_x_Exe_SwFix_F_x_Exe_SwFix; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_DiagControl_F_x_Exe_SwFixAcc_F_x_Exe_SwFixAcc; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_DiagControl_F_x_Exe_SwFixAcc_forRN_F_x_Exe_SwFixAcc_forRN; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_DiagControl_F_x_Exe_SwFixAsl_F_x_Exe_SwFixAsl; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_DiagControl_F_x_Exe_SwFix_forRN_F_x_Exe_SwFix_forRN; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_DiagControl_F_x_Exe_SwLogic_A_F_x_Exe_SwLogic_A; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_DiagControl_F_x_Exe_SwLogic_A_forRN_F_x_Exe_SwLogic_A_forRN; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_DiagControl_F_x_Exe_SwLogic_C_F_x_Exe_SwLogic_C; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_DiagControl_F_x_Exe_SwLogic_C_forRN_F_x_Exe_SwLogic_C_forRN; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_DiagControl_F_x_Exe_SwMainOff_F_x_Exe_SwMainOff; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_DiagControl_F_x_Exe_SwOffRoad_F_x_Exe_SwOffRoad; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_DiagControl_F_x_Exe_SwPark_F_x_Exe_SwPark; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_DiagControl_F_x_Exe_SwSame_F_x_Exe_SwSame; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(boolean_NP, RTE_VAR_INIT) Rte_DiagControl_F_x_Exe_SwSnowACC_F_x_Exe_SwSnowACC; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_DiagControl_F_x_Exe_SwTcsOff_F_x_Exe_SwTcsOff; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_DiagControl_F_x_Exe_SwTcsOffACC_F_x_Exe_SwTcsOffACC; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_DiagControl_F_x_Exe_SwWiper_F_x_Exe_SwWiper; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_DiagControl_F_x_Exe_TCSActCancel_ACC_F_x_Exe_TCSActCancel_ACC; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_DiagControl_F_x_Exe_TCSSystem_A_F_x_Exe_TCSSystem_A; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_DiagControl_F_x_Exe_TCSSystem_C_F_x_Exe_TCSSystem_C; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_DiagControl_F_x_Exe_TestDynamo_F_x_Exe_TestDynamo; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_DiagControl_F_x_Exe_VDCActCancel_F_x_Exe_VDCActCancel; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_DiagControl_F_x_Exe_VDCActCancel_ACC_F_x_Exe_VDCActCancel_ACC; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_DiagControl_F_x_Exe_VDCFunc_A_F_x_Exe_VDCFunc_A; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_DiagControl_F_x_Exe_VDCFunc_A_wACC_F_x_Exe_VDCFunc_A_wACC; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_DiagControl_F_x_Exe_VDCFunc_C_F_x_Exe_VDCFunc_C; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_DiagControl_F_x_Exe_VDCFunc_C_wACC_F_x_Exe_VDCFunc_C_wACC; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_DiagControl_F_x_Exe_VDCSystem_A_F_x_Exe_VDCSystem_A; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_DiagControl_F_x_Exe_VDCSystem_C_F_x_Exe_VDCSystem_C; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_DiagControl_F_x_Exe_VDCVolt_A_wACC_F_x_Exe_VDCVolt_A_wACC; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_DiagControl_F_x_Exe_VDCVolt_C_wACC_F_x_Exe_VDCVolt_C_wACC; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_DiagControl_F_x_Exe_VSPSignalFail_F_x_Exe_VSPSignalFail; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_DiagControl_F_x_Exe_WHSensorFail_F_F_x_Exe_WHSensorFail_F; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_DiagControl_F_x_Exe_WHSensorFail_R_F_x_Exe_WHSensorFail_R; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_DiagControl_F_x_Exe_ePkbActReqErr_F_x_Exe_ePkbActReqErr; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_DiagControl_F_x_Exe_ePkbBreaking_F_x_Exe_ePkbBreaking; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_DiagControl_F_x_Exe_ePkbCancel_F_x_Exe_ePkbCancel; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_DiagControl_F_x_Exe_ePkbErr_F_x_Exe_ePkbErr; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_DiagControl_F_x_Exe_ePkbSsaUnavail_F_x_Exe_ePkbSsaUnavail; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_DiagControl_F_x_Exe_ePkbSystemCancel_F_x_Exe_ePkbSystemCancel; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_DiagControl_F_x_Exe_ePkbSystemErr_F_x_Exe_ePkbSystemErr; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(boolean_NP, RTE_VAR_INIT) Rte_DiagControl_F_x_Exe_vFS_SOWSensorFail3_L_F_x_Exe_vFS_SOWSensorFail3_L; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(boolean_NP, RTE_VAR_INIT) Rte_DiagControl_F_x_Exe_vFS_SOWSensorFail3_R_F_x_Exe_vFS_SOWSensorFail3_R; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_DiagControl_F_x_fDGNOK_F_x_fDGNOK; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(boolean_NP, RTE_VAR_INIT) Rte_DioHwAb_F_x_HwInSw1Long_F_x_HwInSw1Long; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(boolean_NP, RTE_VAR_INIT) Rte_DioHwAb_F_x_HwInSw1Short_F_x_HwInSw1Short; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(boolean_NP, RTE_VAR_INIT) Rte_DioHwAb_F_x_HwInSw3Long_F_x_HwInSw3Long; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(boolean_NP, RTE_VAR_INIT) Rte_DioHwAb_F_x_HwInSw3Short_F_x_HwInSw3Short; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(boolean_NP, RTE_VAR_INIT) Rte_DioHwAb_PF_x_AutoInspHwInLed1internalReadback_PF_x_AutoInspHwInLed1internalReadback; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(boolean_NP, RTE_VAR_INIT) Rte_DioHwAb_PF_x_AutoInspHwInLed2internalReadback_PF_x_AutoInspHwInLed2internalReadback; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(boolean_NP, RTE_VAR_INIT) Rte_DioHwAb_PF_x_AutoInspHwInLed3internalReadback_PF_x_AutoInspHwInLed3internalReadback; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(boolean_NP, RTE_VAR_INIT) Rte_DioHwAb_PF_x_AutoInspHwInSw1_PF_x_AutoInspHwInSw1; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(boolean_NP, RTE_VAR_INIT) Rte_DioHwAb_PF_x_AutoInspHwInSw3_PF_x_AutoInspHwInSw3; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(boolean_NP, RTE_VAR_INIT) Rte_DioHwAb_PF_x_AutoInspHwInSw4_PF_x_AutoInspHwInSw4; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_DioHwAb_PV_x_UdsImHwInSw1_PV_x_UdsImHwInSw1; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_DioHwAb_PV_x_UdsImHwInSw3_PV_x_UdsImHwInSw3; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_DioHwAb_PV_x_UdsImHwInSw4_PV_x_UdsImHwInSw4; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_DioHwAb_PV_x_UdsOmHwOutSwLed1_PV_x_UdsOmHwOutSwLed1; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_DioHwAb_PV_x_UdsOmHwOutSwLed2_PV_x_UdsOmHwOutSwLed2; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_DioHwAb_PV_x_UdsOmHwOutSwLed3_PV_x_UdsOmHwOutSwLed3; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_EAP_F_x_EAP_EepWrite_F_x_EAP_EepWrite; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(boolean_NP, RTE_VAR_INIT) Rte_EAP_F_x_LMP_PmsFailLamp_F_x_LMP_PmsFailLamp; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_EAP_F_x_PMSAccelContBuzReq_F_x_PMSAccelContBuzReq; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_EAP_F_x_PMSBrakeBuzReq_F_x_PMSBrakeBuzReq; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_EAP_F_x_PmsApoAct_F_x_PmsApoAct; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_EAP_F_x_PmsBrkAct_F_x_PmsBrkAct; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_EAP_F_x_SlopeLpf_Eepwrite_F_x_SlopeLpf_Eepwrite; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_EAP_F_x_SonarDectInfo_EepWrite_F_x_SonarDectInfo_EepWrite; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_EAP_F_x_fLMP_AvmRedFrame_F_x_fLMP_AvmRedFrame; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_EAP_F_x_fLMP_IndAct1_F_x_fLMP_IndAct1; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_EAP_F_x_fLMP_PmsIndBlinking_F_x_fLMP_PmsIndBlinking; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_EAP_F_x_fpms_cancel_fail_buz_F_x_fpms_cancel_fail_buz; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt32, RTE_VAR_INIT) Rte_EAP_V_bar_PmsBrkVal_V_bar_PmsBrkVal; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt32, RTE_VAR_INIT) Rte_EAP_V_bar_fl_ARB_BrakeVal_V_bar_fl_ARB_BrakeVal; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt32, RTE_VAR_INIT) Rte_EAP_V_pct_PmsApoVal_V_pct_PmsApoVal; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_EAP_V_x_EAPCancelReason_V_x_EAPCancelReason; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(rt_Array_UInt8_60, RTE_VAR_INIT) Rte_EAP_V_x_SetEAPExecutionEeprom_V_x_SetEAPExecutionEeprom; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_EAP_V_x_SetSlopelpf_V_x_SetSlopelpf; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(rt_Array_UInt8_5, RTE_VAR_INIT) Rte_EAP_V_x_SetSonarDectInfo_V_x_SetSonarDectInfo; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(boolean_NP, RTE_VAR_INIT) Rte_EDR_F_x_EDR_Flash_Req_F_x_EDR_Flash_Req; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_EDR_F_x_EDR_RecDataReq_F_x_EDR_RecDataReq; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_EDR_V_x_EDR_Priority_V_x_EDR_Priority; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_EDR_V_x_EDR_RecDataReq_V_x_EDR_RecDataReq; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(rt_Array_UInt8_44, RTE_VAR_INIT) Rte_EDR_V_x_EDR_SmpData_V_x_EDR_SmpData; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_EDR_V_x_EDR_Trigger_V_x_EDR_Trigger; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(boolean_NP, RTE_VAR_INIT) Rte_EEIF_F_x_EE_LSOWBlockCondiDetected_F_x_EE_LSOWBlockCondiDetected; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(boolean_NP, RTE_VAR_INIT) Rte_EEIF_F_x_EE_RSOWBlockCondiDetected_F_x_EE_RSOWBlockCondiDetected; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_EEIF_F_x_GetAccCruiseEcoEeprom_F_x_GetAccCruiseEcoEeprom; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(boolean_NP, RTE_VAR_INIT) Rte_EEIF_F_x_GetBSIActEeprom_F_x_GetBSIActEeprom; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(boolean_NP, RTE_VAR_INIT) Rte_EEIF_F_x_GetBSWActEeprom_F_x_GetBSWActEeprom; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(boolean_NP, RTE_VAR_INIT) Rte_EEIF_F_x_GetCTAActEeprom_F_x_GetCTAActEeprom; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(boolean_NP, RTE_VAR_INIT) Rte_EEIF_F_x_GetDaaActEeprom_F_x_GetDaaActEeprom; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(boolean_NP, RTE_VAR_INIT) Rte_EEIF_F_x_GetFEBFCWActEeprom_F_x_GetFEBFCWActEeprom; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(boolean_NP, RTE_VAR_INIT) Rte_EEIF_F_x_GetLDPActEeprom_F_x_GetLDPActEeprom; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(boolean_NP, RTE_VAR_INIT) Rte_EEIF_F_x_GetLDWActEeprom_F_x_GetLDWActEeprom; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(boolean_NP, RTE_VAR_INIT) Rte_EEIF_F_x_GetLKAActEeprom_F_x_GetLKAActEeprom; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(boolean_NP, RTE_VAR_INIT) Rte_EEIF_PF_x_ClearEAPExecutionDone_PF_x_ClearEAPExecutionDone; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(boolean_NP, RTE_VAR_INIT) Rte_EEIF_PF_x_ClearEDRDone_PF_x_ClearEDRDone; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(boolean_NP, RTE_VAR_INIT) Rte_EEIF_PF_x_ClearFEBExecutionDone_PF_x_ClearFEBExecutionDone; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(boolean_NP, RTE_VAR_INIT) Rte_EEIF_PF_x_EepInitDone_PF_x_EepInitDone; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(boolean_NP, RTE_VAR_INIT) Rte_EEIF_PF_x_NvmWrBusy_PF_x_NvmWrBusy; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(rt_Array_UInt8_10, RTE_VAR_INIT) Rte_EEIF_PV_x_GetEAPCancelReasonDid0509_PV_x_GetEAPCancelReasonDid0509; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(rt_Array_UInt8_60, RTE_VAR_INIT) Rte_EEIF_PV_x_GetEAPExecutionDid0516_PV_x_GetEAPExecutionDid0516; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(rt_Array_UInt8_60, RTE_VAR_INIT) Rte_EEIF_PV_x_GetEAPExecutionDid0517_PV_x_GetEAPExecutionDid0517; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(rt_Array_UInt8_60, RTE_VAR_INIT) Rte_EEIF_PV_x_GetEAPExecutionDid0518_PV_x_GetEAPExecutionDid0518; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(rt_Array_UInt8_60, RTE_VAR_INIT) Rte_EEIF_PV_x_GetEAPExecutionDid0519_PV_x_GetEAPExecutionDid0519; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(rt_Array_UInt8_60, RTE_VAR_INIT) Rte_EEIF_PV_x_GetEAPExecutionDid051A_PV_x_GetEAPExecutionDid051A; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint16_NP, RTE_VAR_INIT) Rte_EEIF_PV_x_GetEepromInfoDid0A0A_PV_x_GetEepromInfoDid0A0A; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(rt_Array_UInt8_10, RTE_VAR_INIT) Rte_EEIF_PV_x_GetFEBCancelReasonDid0503_PV_x_GetFEBCancelReasonDid0503; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(rt_Array_UInt8_64, RTE_VAR_INIT) Rte_EEIF_PV_x_GetFEBExecutionDid0521_PV_x_GetFEBExecutionDid0521; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(rt_Array_UInt8_64, RTE_VAR_INIT) Rte_EEIF_PV_x_GetFEBExecutionDid0522_PV_x_GetFEBExecutionDid0522; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(rt_Array_UInt8_64, RTE_VAR_INIT) Rte_EEIF_PV_x_GetFEBExecutionDid0523_PV_x_GetFEBExecutionDid0523; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(rt_Array_UInt8_64, RTE_VAR_INIT) Rte_EEIF_PV_x_GetFEBExecutionDid0524_PV_x_GetFEBExecutionDid0524; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(rt_Array_UInt8_64, RTE_VAR_INIT) Rte_EEIF_PV_x_GetFEBExecutionDid0525_PV_x_GetFEBExecutionDid0525; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(rt_Array_UInt8_10, RTE_VAR_INIT) Rte_EEIF_PV_x_GetLDPCancelReasonDid0507_PV_x_GetLDPCancelReasonDid0507; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(rt_Array_UInt8_516, RTE_VAR_INIT) Rte_EEIF_PV_x_GetSector1Adress_PV_x_GetSector1Adress; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(rt_Array_UInt8_516, RTE_VAR_INIT) Rte_EEIF_PV_x_GetSector2Adress_PV_x_GetSector2Adress; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(rt_Array_UInt8_516, RTE_VAR_INIT) Rte_EEIF_PV_x_GetSector3Adress_PV_x_GetSector3Adress; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8, RTE_VAR_INIT) Rte_EEIF_PV_x_GetSigmaNoV_PV_x_GetSigmaNoV; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UDSCP_SigmaVSsdType, RTE_VAR_INIT) Rte_EEIF_PV_x_GetSigmaVSsd0_PV_x_GetSigmaVSsd0; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UDSCP_SigmaVSsdType, RTE_VAR_INIT) Rte_EEIF_PV_x_GetSigmaVSsd1_PV_x_GetSigmaVSsd1; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UDSCP_SigmaVSsdType, RTE_VAR_INIT) Rte_EEIF_PV_x_GetSigmaVSsd2_PV_x_GetSigmaVSsd2; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UDSCP_SigmaVSsdType, RTE_VAR_INIT) Rte_EEIF_PV_x_GetSigmaVSsd3_PV_x_GetSigmaVSsd3; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UDSCP_SigmaVSsdType, RTE_VAR_INIT) Rte_EEIF_PV_x_GetSigmaVSsd4_PV_x_GetSigmaVSsd4; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8, RTE_VAR_INIT) Rte_EEIF_PV_x_GetSigmaVSsdFrameIndex_PV_x_GetSigmaVSsdFrameIndex; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UDSCP_SigmaVTddType, RTE_VAR_INIT) Rte_EEIF_PV_x_GetSigmaVTdd0_PV_x_GetSigmaVTdd0; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UDSCP_SigmaVTddType, RTE_VAR_INIT) Rte_EEIF_PV_x_GetSigmaVTdd1_PV_x_GetSigmaVTdd1; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UDSCP_SigmaVTddType, RTE_VAR_INIT) Rte_EEIF_PV_x_GetSigmaVTdd2_PV_x_GetSigmaVTdd2; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UDSCP_SigmaVTddType, RTE_VAR_INIT) Rte_EEIF_PV_x_GetSigmaVTdd3_PV_x_GetSigmaVTdd3; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UDSCP_SigmaVTddType, RTE_VAR_INIT) Rte_EEIF_PV_x_GetSigmaVTdd4_PV_x_GetSigmaVTdd4; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8, RTE_VAR_INIT) Rte_EEIF_PV_x_GetSigmaVTddFrameIndex_PV_x_GetSigmaVTddFrameIndex; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_EEIF_PV_x_GetVARIANTEepNow_PV_x_GetVARIANTEepNow; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UDSCP_VinType, RTE_VAR_INIT) Rte_EEIF_PV_x_GetVin_PV_x_GetVin; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_EEIF_PV_x_GetVinReqNum_PV_x_GetVinReqNum; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_EEIF_PV_x_SetVARIANTEepEv1_PV_x_SetVARIANTEepEv1; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_EEIF_PV_x_SetVARIANTSts_PV_x_SetVARIANTSts; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(float32_NP, RTE_VAR_INIT) Rte_EEIF_V_deg_GetSWAOffsetEeprom_V_deg_GetSWAOffsetEeprom; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint32_NP, RTE_VAR_INIT) Rte_EEIF_V_km_GetTTMDisTotalEeprom_V_km_GetTTMDisTotalEeprom; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint16_NP, RTE_VAR_INIT) Rte_EEIF_V_nm_GetStrTrqDiffConsutEeprom_V_nm_GetStrTrqDiffConsutEeprom; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint16_NP, RTE_VAR_INIT) Rte_EEIF_V_nm_GetStrTrqDiffEolEeprom_V_nm_GetStrTrqDiffEolEeprom; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint16_NP, RTE_VAR_INIT) Rte_EEIF_V_nm_GetStrTrqDiffLatestEeprom_V_nm_GetStrTrqDiffLatestEeprom; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_EEIF_V_x_EEIF_GetEdrSector1_V_x_EEIF_GetEdrSector1; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_EEIF_V_x_EEIF_GetEdrSector2_V_x_EEIF_GetEdrSector2; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_EEIF_V_x_EEIF_GetEdrSector3_V_x_EEIF_GetEdrSector3; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_EEIF_V_x_GetBSWLedStatEeprom_V_x_GetBSWLedStatEeprom; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_EEIF_V_x_GetEAPExecutionEeprom_V_x_GetEAPExecutionEeprom; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint16_NP, RTE_VAR_INIT) Rte_EEIF_V_x_GetSlopelpf_V_x_GetSlopelpf; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(rt_Array_UInt8_5, RTE_VAR_INIT) Rte_EEIF_V_x_GetSonarDectInfo_V_x_GetSonarDectInfo; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_EEIF_V_x_GetTTMIGNTimesEeprom_V_x_GetTTMIGNTimesEeprom; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_EEIF_V_x_RecStat_Sectors_V_x_RecStat_Sectors; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_EEIF_V_x_VARIANTCODE_V_x_VARIANTCODE; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_FEBFCWDBA_F_x_AutoClrFCA_F_x_AutoClrFCA; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_FEBFCWDBA_F_x_FCA_LOCK_F_x_FCA_LOCK; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_FEBFCWDBA_F_x_FCA_STOP_MODE_F_x_FCA_STOP_MODE; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_FEBFCWDBA_F_x_FCW_STOP_OBJ_3_F_x_FCW_STOP_OBJ_3; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_FEBFCWDBA_F_x_Feb_Emg_Brk_F_x_Feb_Emg_Brk; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_FEBFCWDBA_F_x_Feb_Pre_Brk_F_x_Feb_Pre_Brk; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_FEBFCWDBA_F_x_FfpClrFCA_F_x_FfpClrFCA; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_FEBFCWDBA_F_x_PFCW_BUZ_F_x_PFCW_BUZ; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(boolean_NP, RTE_VAR_INIT) Rte_FEBFCWDBA_F_x_PFCW_WARN_DISP_F_x_PFCW_WARN_DISP; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_FEBFCWDBA_F_x_fAPO_REQ_FCA_F_x_fAPO_REQ_FCA; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_FEBFCWDBA_F_x_fDISP_BLIC_FCW_F_x_fDISP_BLIC_FCW; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt32, RTE_VAR_INIT) Rte_FEBFCWDBA_V_Mpa_vVC_PBRK_COM_DBA_V_Mpa_vVC_PBRK_COM_DBA; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt32, RTE_VAR_INIT) Rte_FEBFCWDBA_V_Mpa_vVC_PBRK_COM_FEB_V_Mpa_vVC_PBRK_COM_FEB; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt32, RTE_VAR_INIT) Rte_FEBFCWDBA_V_N_FCA_CFC_REQ_V_N_FCA_CFC_REQ; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt32, RTE_VAR_INIT) Rte_FEBFCWDBA_V_m_FCA_DIST_V_m_FCA_DIST; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt32, RTE_VAR_INIT) Rte_FEBFCWDBA_V_mps_FCA_VREL_V_mps_FCA_VREL; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt32, RTE_VAR_INIT) Rte_FEBFCWDBA_V_mps_VSP_FCA_V_mps_VSP_FCA; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt32, RTE_VAR_INIT) Rte_FEBFCWDBA_V_pct_APO_ANGL_FCA_V_pct_APO_ANGL_FCA; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_FEBFCWDBA_V_pct_vAPO_TX_FCA_V_pct_vAPO_TX_FCA; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_FEBFCWDBA_V_x_BRKState_V_x_BRKState; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_FEBFCWDBA_V_x_Buzzer_Sound_FCW_V_x_Buzzer_Sound_FCW; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_FEBFCWDBA_V_x_Buzzer_Sound_FEB_V_x_Buzzer_Sound_FEB; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_FEBFCWDBA_V_x_DBA_CTRL_MODE_V_x_DBA_CTRL_MODE; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(rt_Array_UInt8_64, RTE_VAR_INIT) Rte_FEBFCWDBA_V_x_SetFEBExecutionEeprom_V_x_SetFEBExecutionEeprom; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_FEBFCWDBA_V_x_StsBa_V_x_StsBa; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_FEBFCWDBA_V_x_StsWFw_V_x_StsWFw; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_FEBFCWDBA_V_x_vFCA_CTRL_MODE_V_x_vFCA_CTRL_MODE; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_FS_ACT_V_x_FS_ASCDState_V_x_FS_ASCDState; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_FS_ACT_V_x_FS_BSWState_V_x_FS_BSWState; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_FS_ACT_V_x_FS_DAAState_V_x_FS_DAAState; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_FS_ACT_V_x_FS_DBAState_V_x_FS_DBAState; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt32, RTE_VAR_INIT) Rte_FS_ACT_V_x_FS_EAPState_V_x_FS_EAPState; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_FS_ACT_V_x_FS_FCWState_V_x_FS_FCWState; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt32, RTE_VAR_INIT) Rte_FS_ACT_V_x_FS_FEBActState_V_x_FS_FEBActState; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_FS_ACT_V_x_FS_FEBCancelReason_V_x_FS_FEBCancelReason; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_FS_ACT_V_x_FS_FEBFlagState_V_x_FS_FEBFlagState; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt32, RTE_VAR_INIT) Rte_FS_ACT_V_x_FS_FailActDiag_V_x_FS_FailActDiag; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_FS_ACT_V_x_FS_ICCCancelReason_V_x_FS_ICCCancelReason; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint32_NP, RTE_VAR_INIT) Rte_FS_ACT_V_x_FS_ICCState_V_x_FS_ICCState; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt32, RTE_VAR_INIT) Rte_FS_ACT_V_x_FS_ICCState_TJP_V_x_FS_ICCState_TJP; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_FS_ACT_V_x_FS_LDWState_V_x_FS_LDWState; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_Fusion_F_x_CCI_Detect_F_x_CCI_Detect; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_Fusion_F_x_CameraRadarLockCancel_F_x_CameraRadarLockCancel; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_Fusion_F_x_CipvFlagT_F_x_CipvFlagT; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(boolean_NP, RTE_VAR_INIT) Rte_Fusion_F_x_FREE_SPACE_OUT_SEL_F_x_FREE_SPACE_OUT_SEL; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_Fusion_F_x_LcClosestCutInObj_F_x_LcClosestCutInObj; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_Fusion_F_x_LcCutInObj_F_x_LcCutInObj; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_Fusion_F_x_ObjACCChgReqHokan_F_x_ObjACCChgReqHokan; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_Fusion_F_x_ObjUpdateT_F_x_ObjUpdateT; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_Fusion_F_x_ObjectChanged_F_x_ObjectChanged; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_Fusion_F_x_ObjectSelChangedT_F_x_ObjectSelChangedT; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_Fusion_F_x_ObjectStationary_F_x_ObjectStationary; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_Fusion_F_x_Obstacle_F_x_Obstacle; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(boolean_NP, RTE_VAR_INIT) Rte_Fusion_F_x_RadarLockObj0_F_x_RadarLockObj0; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_Fusion_F_x_StopObjLowAccel_F_x_StopObjLowAccel; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_Fusion_F_x_Target_F_x_Target; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Float, RTE_VAR_INIT) Rte_Fusion_V_m_CenterObj_LongiDist_V_m_CenterObj_LongiDist; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Float, RTE_VAR_INIT) Rte_Fusion_V_m_CenterObj_Trajectory_V_m_CenterObj_Trajectory; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Float, RTE_VAR_INIT) Rte_Fusion_V_m_CenterObj_Width_V_m_CenterObj_Width; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Float, RTE_VAR_INIT) Rte_Fusion_V_m_Distance_V_m_Distance; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Float, RTE_VAR_INIT) Rte_Fusion_V_m_LeftObj_LatDist_V_m_LeftObj_LatDist; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Float, RTE_VAR_INIT) Rte_Fusion_V_m_LeftObj_LongiDist_V_m_LeftObj_LongiDist; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Float, RTE_VAR_INIT) Rte_Fusion_V_m_LeftObj_Trajectory_V_m_LeftObj_Trajectory; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Float, RTE_VAR_INIT) Rte_Fusion_V_m_LeftObj_Width_V_m_LeftObj_Width; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(float32_NP, RTE_VAR_INIT) Rte_Fusion_V_m_ObjPosXT_V_m_ObjPosXT; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Float, RTE_VAR_INIT) Rte_Fusion_V_m_ObjPosY2T_V_m_ObjPosY2T; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Float, RTE_VAR_INIT) Rte_Fusion_V_m_ObjPosYT_V_m_ObjPosYT; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Float, RTE_VAR_INIT) Rte_Fusion_V_m_ObjWidthT_V_m_ObjWidthT; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Float, RTE_VAR_INIT) Rte_Fusion_V_m_OncomingObj_LatDist_V_m_OncomingObj_LatDist; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Float, RTE_VAR_INIT) Rte_Fusion_V_m_OncomingObj_LongiDist_V_m_OncomingObj_LongiDist; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Float, RTE_VAR_INIT) Rte_Fusion_V_m_OncomingObj_Width_V_m_OncomingObj_Width; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Float, RTE_VAR_INIT) Rte_Fusion_V_m_RightObj_LatDist_V_m_RightObj_LatDist; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Float, RTE_VAR_INIT) Rte_Fusion_V_m_RightObj_LongiDist_V_m_RightObj_LongiDist; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Float, RTE_VAR_INIT) Rte_Fusion_V_m_RightObj_Trajectory_V_m_RightObj_Trajectory; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Float, RTE_VAR_INIT) Rte_Fusion_V_m_RightObj_Width_V_m_RightObj_Width; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(float32_NP, RTE_VAR_INIT) Rte_Fusion_V_m_SuppDistLimit_V_m_SuppDistLimit; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Float, RTE_VAR_INIT) Rte_Fusion_V_m_TargetTrajectory_V_m_TargetTrajectory; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Float, RTE_VAR_INIT) Rte_Fusion_V_m_TargetTrajectoryOffsetL_V_m_TargetTrajectoryOffsetL; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Float, RTE_VAR_INIT) Rte_Fusion_V_m_TargetTrajectoryOffsetR_V_m_TargetTrajectoryOffsetR; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Float, RTE_VAR_INIT) Rte_Fusion_V_mps2_CameraAccel_V_mps2_CameraAccel; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Float, RTE_VAR_INIT) Rte_Fusion_V_mps2_PrecVehicleAcceleration_Est_V_mps2_PrecVehicleAcceleration_Est; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Float, RTE_VAR_INIT) Rte_Fusion_V_mps_CenterObj_Relspd_V_mps_CenterObj_Relspd; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Float, RTE_VAR_INIT) Rte_Fusion_V_mps_LeftObj_Relspd_V_mps_LeftObj_Relspd; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Float, RTE_VAR_INIT) Rte_Fusion_V_mps_ObjRelVelT_V_mps_ObjRelVelT; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Float, RTE_VAR_INIT) Rte_Fusion_V_mps_OncomingObj_Relspd_V_mps_OncomingObj_Relspd; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(float32_NP, RTE_VAR_INIT) Rte_Fusion_V_mps_PVR_ACC_VSP_A_SEL_V_mps_PVR_ACC_VSP_A_SEL; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Float, RTE_VAR_INIT) Rte_Fusion_V_mps_RelativeSpeed_V_mps_RelativeSpeed; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Float, RTE_VAR_INIT) Rte_Fusion_V_mps_RightObj_Relspd_V_mps_RightObj_Relspd; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Float, RTE_VAR_INIT) Rte_Fusion_V_mps_TargetSpeed_V_mps_TargetSpeed; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Float, RTE_VAR_INIT) Rte_Fusion_V_mps_TargetSpeed_A_V_mps_TargetSpeed_A; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(float32_NP, RTE_VAR_INIT) Rte_Fusion_V_s_SuppLockTime_V_s_SuppLockTime; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Float, RTE_VAR_INIT) Rte_Fusion_V_s_TimeToCollision_Est_V_s_TimeToCollision_Est; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_Fusion_V_x_BlinkerInfoT_V_x_BlinkerInfoT; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_Fusion_V_x_CenterObj_Dynamics_V_x_CenterObj_Dynamics; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_Fusion_V_x_CenterObj_ID_V_x_CenterObj_ID; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_Fusion_V_x_CenterObj_Type_V_x_CenterObj_Type; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_Fusion_V_x_LeftObj_Dynamics_V_x_LeftObj_Dynamics; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_Fusion_V_x_LeftObj_Type_V_x_LeftObj_Type; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_Fusion_V_x_ObjIDT_V_x_ObjIDT; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_Fusion_V_x_ObjPosXT_V_x_ObjPosXT; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_Fusion_V_x_ObstacleIDSelACC_V_x_ObstacleIDSelACC; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_Fusion_V_x_OncomingObj_Dynamics_V_x_OncomingObj_Dynamics; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_Fusion_V_x_PVRACCStateMode_V_x_PVRACCStateMode; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_Fusion_V_x_PVR_ACC_STATE_MODE_SEL_V_x_PVR_ACC_STATE_MODE_SEL; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_Fusion_V_x_Requested20ObjID_V_x_Requested20ObjID; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_Fusion_V_x_RightObj_Dynamics_V_x_RightObj_Dynamics; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_Fusion_V_x_RightObj_Type_V_x_RightObj_Type; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(boolean_NP, RTE_VAR_INIT) Rte_HMI_F_x_ACC_DistanceOverrideDisplay_F_x_ACC_DistanceOverrideDisplay; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(boolean_NP, RTE_VAR_INIT) Rte_HMI_F_x_ACC_LCA_CancelReasonRER_F_x_ACC_LCA_CancelReasonRER; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(boolean_NP, RTE_VAR_INIT) Rte_HMI_F_x_ACC_LCA_CancelReasonRER_v2_F_x_ACC_LCA_CancelReasonRER_v2; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(boolean_NP, RTE_VAR_INIT) Rte_HMI_F_x_ACC_SpeedOverrideDisplay_F_x_ACC_SpeedOverrideDisplay; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(boolean_NP, RTE_VAR_INIT) Rte_HMI_F_x_ADAS_CTAinhibitionRequest_F_x_ADAS_CTAinhibitionRequest; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(boolean_NP, RTE_VAR_INIT) Rte_HMI_F_x_ADAS_LDWalertInhibitionRequest_F_x_ADAS_LDWalertInhibitionRequest; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_HMI_F_x_AEB_CyclistAlertRequest2_F_x_AEB_CyclistAlertRequest2; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_HMI_F_x_AEB_PedestrianAlertRequest2_F_x_AEB_PedestrianAlertRequest2; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(boolean_NP, RTE_VAR_INIT) Rte_HMI_F_x_AssistanceFunctionStatusDisplay_F_x_AssistanceFunctionStatusDisplay; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_HMI_F_x_EAP_AlertDisplay_F_x_EAP_AlertDisplay; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_HMI_F_x_EAP_SoundInhibitionRequest_F_x_EAP_SoundInhibitionRequest; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_HMI_F_x_HwOutSwLed2_F_x_HwOutSwLed2; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_HMI_F_x_HwOutSwLed3_F_x_HwOutSwLed3; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(boolean_NP, RTE_VAR_INIT) Rte_HMI_F_x_LDP_ActivationState_F_x_LDP_ActivationState; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(boolean_NP, RTE_VAR_INIT) Rte_HMI_F_x_LDP_CancelReasonRER_F_x_LDP_CancelReasonRER; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(boolean_NP, RTE_VAR_INIT) Rte_HMI_F_x_LDP_SoundAlertInfo_F_x_LDP_SoundAlertInfo; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(boolean_NP, RTE_VAR_INIT) Rte_HMI_F_x_LDP_StatusInfo_F_x_LDP_StatusInfo; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(boolean_NP, RTE_VAR_INIT) Rte_HMI_F_x_ModeCruiseCtrl_F_x_ModeCruiseCtrl; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(boolean_NP, RTE_VAR_INIT) Rte_HMI_F_x_RAB_ActivationState_F_x_RAB_ActivationState; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(boolean_NP, RTE_VAR_INIT) Rte_HMI_F_x_SigSetInd_F_x_SigSetInd; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(boolean_NP, RTE_VAR_INIT) Rte_HMI_F_x_SigSetSpdAct_F_x_SigSetSpdAct; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_HMI_F_x_SpeakerSnd1_Stop_F_x_SpeakerSnd1_Stop; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_HMI_F_x_SpeakerSnd2_Stop_F_x_SpeakerSnd2_Stop; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_HMI_F_x_SpeakerSnd3_Stop_F_x_SpeakerSnd3_Stop; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_HMI_F_x_SpeakerSnd4_Stop_F_x_SpeakerSnd4_Stop; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_HMI_F_x_WDA_ActivationState_F_x_WDA_ActivationState; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_HMI_F_x_WDA_WarningDriverAttention_F_x_WDA_WarningDriverAttention; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_HMI_F_x_WrnLnL_F_x_WrnLnL; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_HMI_F_x_WrnLnR_F_x_WrnLnR; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_HMI_V_pct_HwOutMotDuty_V_pct_HwOutMotDuty; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_HMI_V_x_ACC_CruiseEcoActivationState_V_x_ACC_CruiseEcoActivationState; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_HMI_V_x_ACC_DistanceSettingDisplay_V_x_ACC_DistanceSettingDisplay; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_HMI_V_x_ACC_DynTargetDistanceDisplay_V_x_ACC_DynTargetDistanceDisplay; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_HMI_V_x_ACC_FailureDisplay_V_x_ACC_FailureDisplay; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_HMI_V_x_ACC_LCA_CancelReason_V_x_ACC_LCA_CancelReason; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_HMI_V_x_ACC_LCA_CancelReason_v2_V_x_ACC_LCA_CancelReason_v2; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_HMI_V_x_ACC_LCA_DeactivationType_V_x_ACC_LCA_DeactivationType; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_HMI_V_x_ACC_LCA_TransitionStateDisplay_V_x_ACC_LCA_TransitionStateDisplay; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_HMI_V_x_ACC_RadarCancelReasonInfo_V_x_ACC_RadarCancelReasonInfo; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_HMI_V_x_ACC_SpeedSettingDisplay_V_x_ACC_SpeedSettingDisplay; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_HMI_V_x_ACC_StatusDisplay_V_x_ACC_StatusDisplay; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_HMI_V_x_ACC_TargetDistanceAlert_V_x_ACC_TargetDistanceAlert; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_HMI_V_x_ACC_TargetDistanceDisplay_V_x_ACC_TargetDistanceDisplay; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_HMI_V_x_ADAS_ModeDisplay_V_x_ADAS_ModeDisplay; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_HMI_V_x_AEB_CancelInfo_V_x_AEB_CancelInfo; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_HMI_V_x_AEB_CancelReason2_V_x_AEB_CancelReason2; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_HMI_V_x_AEB_FCWactivationState2_V_x_AEB_FCWactivationState2; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_HMI_V_x_AEB_FailureDisplay2_V_x_AEB_FailureDisplay2; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_HMI_V_x_AEB_SoundAlert_V_x_AEB_SoundAlert; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_HMI_V_x_AEB_StatusDisplay2_V_x_AEB_StatusDisplay2; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_HMI_V_x_DriverGuideDisplay_V_x_DriverGuideDisplay; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_HMI_V_x_EAP_FailureDisplay_V_x_EAP_FailureDisplay; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_HMI_V_x_EAP_SoundAlertRequest_V_x_EAP_SoundAlertRequest; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_HMI_V_x_LCA_LaneInfo_V_x_LCA_LaneInfo; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_HMI_V_x_LCA_StatusDisplay_V_x_LCA_StatusDisplay; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_HMI_V_x_LDP_AlertStatusInfo_V_x_LDP_AlertStatusInfo; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_HMI_V_x_LDP_CancelInfo_V_x_LDP_CancelInfo; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_HMI_V_x_LDP_CancelReason_V_x_LDP_CancelReason; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_HMI_V_x_LDP_FailureDisplay_V_x_LDP_FailureDisplay; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_HMI_V_x_LDP_LaneInfo_V_x_LDP_LaneInfo; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_HMI_V_x_RAB_AlertStatus_V_x_RAB_AlertStatus; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_HMI_V_x_RAB_CancelReason_V_x_RAB_CancelReason; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_HMI_V_x_RAB_FailureDisplay_V_x_RAB_FailureDisplay; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_HMI_V_x_RAB_SonarCancelReason_V_x_RAB_SonarCancelReason; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_HMI_V_x_RAB_StatusDisplay_V_x_RAB_StatusDisplay; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_HMI_V_x_SetWBs_V_x_SetWBs; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_HMI_V_x_SetWLn_V_x_SetWLn; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_HMI_V_x_SigDist_V_x_SigDist; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_HMI_V_x_SigSetSpeed_V_x_SigSetSpeed; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_HMI_V_x_SpeakerSnd1_Req_V_x_SpeakerSnd1_Req; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_HMI_V_x_SpeakerSnd1_Vol_V_x_SpeakerSnd1_Vol; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_HMI_V_x_SpeakerSnd2_Req_V_x_SpeakerSnd2_Req; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_HMI_V_x_SpeakerSnd2_Vol_V_x_SpeakerSnd2_Vol; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_HMI_V_x_SpeakerSnd3_Req_V_x_SpeakerSnd3_Req; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_HMI_V_x_SpeakerSnd3_Vol_V_x_SpeakerSnd3_Vol; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_HMI_V_x_SpeakerSnd4_Req_V_x_SpeakerSnd4_Req; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_HMI_V_x_SpeakerSnd4_Vol_V_x_SpeakerSnd4_Vol; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_HMI_V_x_StsCrsCtrl_V_x_StsCrsCtrl; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_HMI_V_x_StsWBsOut_V_x_StsWBsOut; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_HMI_V_x_StsWLnOut_V_x_StsWLnOut; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_HMI_V_x_TgtFw_V_x_TgtFw; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_HMI_V_x_TgtFwC1N_V_x_TgtFwC1N; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_HMI_V_x_WDA_DriverAttentionLevel_V_x_WDA_DriverAttentionLevel; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_LDPLDW_F_x_Camera_Left_Valid_F_x_Camera_Left_Valid; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_LDPLDW_F_x_Camera_Right_Valid_F_x_Camera_Right_Valid; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_LDPLDW_F_x_CancelBeepReq_F_x_CancelBeepReq; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_LDPLDW_F_x_GA_Give_F_x_GA_Give; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_LDPLDW_F_x_GA_Ready_F_x_GA_Ready; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_LDPLDW_F_x_LDP_CAM_HIGH_F_x_LDP_CAM_HIGH; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_LDPLDW_F_x_LDP_LSOUT_F_x_LDP_LSOUT; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_LDPLDW_F_x_LDW_CAM_HIGH_F_x_LDW_CAM_HIGH; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_LDPLDW_F_x_LdwBuzOUT_F_x_LdwBuzOUT; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_LDPLDW_F_x_THW_Low_Gra_Left_F_x_THW_Low_Gra_Left; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_LDPLDW_F_x_THW_Low_Gra_Right_F_x_THW_Low_Gra_Right; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_LDPLDW_F_x_THW_Low_Imm_Left_F_x_THW_Low_Imm_Left; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_LDPLDW_F_x_THW_Low_Imm_Right_F_x_THW_Low_Imm_Right; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_LDPLDW_F_x_Warn_Sup_Left_F_x_Warn_Sup_Left; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_LDPLDW_F_x_Warn_Sup_Right_F_x_Warn_Sup_Right; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_LDPLDW_F_x_Width_kata_Valid_F_x_Width_kata_Valid; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_LDPLDW_F_x_fCAM_Warning_L_F_x_fCAM_Warning_L; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_LDPLDW_F_x_fCAM_Warning_R_F_x_fCAM_Warning_R; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_LDPLDW_F_x_fLDP_ACTIVE2_F_x_fLDP_ACTIVE2; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_LDPLDW_F_x_fLDP_ACTIVE3_F_x_fLDP_ACTIVE3; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_LDPLDW_F_x_fLDP_SW_MAIN_OFF_F_x_fLDP_SW_MAIN_OFF; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_LDPLDW_F_x_fLDW_BUZ_FORCE_OFF_F_x_fLDW_BUZ_FORCE_OFF; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_LDPLDW_F_x_f_LSOUT2_F_x_f_LSOUT2; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_LDPLDW_F_x_kata_Lost_L_F_x_kata_Lost_L; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_LDPLDW_F_x_kata_Lost_R_F_x_kata_Lost_R; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_LDPLDW_F_x_ldp_LDW_ON_F_x_ldp_LDW_ON; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_LDPLDW_V_Nm_LSMOMBOUND_LDP_V_Nm_LSMOMBOUND_LDP; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt32, RTE_VAR_INIT) Rte_LDPLDW_V_Nm_Output_Myu_Comp_V_Nm_Output_Myu_Comp; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_LDPLDW_V_Nm_mom_ls_V_Nm_mom_ls; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt32, RTE_VAR_INIT) Rte_LDPLDW_V_Nm_mom_ls0prepm_V_Nm_mom_ls0prepm; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_LDPLDW_V_deg_LS_Roe_yaw_V_deg_LS_Roe_yaw; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt32, RTE_VAR_INIT) Rte_LDPLDW_V_deg_LS_Yaw_V_deg_LS_Yaw; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt32, RTE_VAR_INIT) Rte_LDPLDW_V_deg_yaw_Detect_L_SLB_V_deg_yaw_Detect_L_SLB; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt32, RTE_VAR_INIT) Rte_LDPLDW_V_deg_yaw_Detect_R_SLB_V_deg_yaw_Detect_R_SLB; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt32, RTE_VAR_INIT) Rte_LDPLDW_V_m_LS_Row_In_V_m_LS_Row_In; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt32, RTE_VAR_INIT) Rte_LDPLDW_V_m_LS_Row_In_Temp_V_m_LS_Row_In_Temp; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt32, RTE_VAR_INIT) Rte_LDPLDW_V_m_LS_W_LMT_pm_V_m_LS_W_LMT_pm; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_LDPLDW_V_m_LS_yyl_V_m_LS_yyl; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_LDPLDW_V_m_LS_yyr_V_m_LS_yyr; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_LDPLDW_V_m_Width_Buf_V_m_Width_Buf; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_LDPLDW_V_m_yyl_limit_SLB_V_m_yyl_limit_SLB; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_LDPLDW_V_m_yyr_limit_SLB_V_m_yyr_limit_SLB; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt32, RTE_VAR_INIT) Rte_LDPLDW_V_mps2_Accel_Filter_V_mps2_Accel_Filter; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt32, RTE_VAR_INIT) Rte_LDPLDW_V_mps_WFET_Correction_V_mps_WFET_Correction; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_LDPLDW_V_s_Cnt_Least_Mom_ff_V_s_Cnt_Least_Mom_ff; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt32, RTE_VAR_INIT) Rte_LDPLDW_V_x_Gain_Final_SCP_LDP_V_x_Gain_Final_SCP_LDP; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_LDPLDW_V_x_LS_Depart_Dir_V_x_LS_Depart_Dir; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_LDPLDW_V_x_MssCmsLDP_V_x_MssCmsLDP; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_LDPLDW_V_x_StsDLn_V_x_StsDLn; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_LDPLDW_V_x_StsWLn_V_x_StsWLn; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_LDPLDW_V_x_TgtLN_V_x_TgtLN; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_LDPLDW_V_x_vLDP_CancelEepWriteReq_V_x_vLDP_CancelEepWriteReq; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_ABSActCancel_F_x_FS_ABSActCancel; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_ABSActCancel_ACC_F_x_FS_ABSActCancel_ACC; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_ABSSystem_A_F_x_FS_ABSSystem_A; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_ABSSystem_C_F_x_FS_ABSSystem_C; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_AccelPedal_F_x_FS_AccelPedal; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_AtMisMatch_F_x_FS_AtMisMatch; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_AtNoDrange_F_x_FS_AtNoDrange; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_AtRPrange_F_x_FS_AtRPrange; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_BrkCmdPressFail_F_x_FS_BrkCmdPressFail; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_BrkDriverACC_F_x_FS_BrkDriverACC; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_BrkDriverFEB_F_x_FS_BrkDriverFEB; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_BrkDriverTJP_F_x_FS_BrkDriverTJP; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_BrkLampOff_F_x_FS_BrkLampOff; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_BrkLampOn_F_x_FS_BrkLampOn; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_BrkSWFail_F_x_FS_BrkSWFail; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_BrkSwHdc_On_F_x_FS_BrkSwHdc_On; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_CAM_Aiming_F_x_FS_CAM_Aiming; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_CAM_Fail_F_x_FS_CAM_Fail; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_CAM_HiTemp1_F_x_FS_CAM_HiTemp1; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_ClutchMisMatch_F_x_FS_ClutchMisMatch; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_CtrlASCD_F_x_FS_CtrlASCD; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_CtrlActSameTgt_F_x_FS_CtrlActSameTgt; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_CtrlActTime_F_x_FS_CtrlActTime; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_CtrlActTimeDBA_F_x_FS_CtrlActTimeDBA; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_CtrlAngSpdCanc1_F_x_FS_CtrlAngSpdCanc1; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_CtrlAngSpdCanc2_F_x_FS_CtrlAngSpdCanc2; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_CtrlCBA_F_x_FS_CtrlCBA; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_CtrlCurvature_F_x_FS_CtrlCurvature; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_CtrlDBABrake_F_x_FS_CtrlDBABrake; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_CtrlDoorOpenExCockpit_F_x_FS_CtrlDoorOpenExCockpit; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_CtrlDpbActErr_F_x_FS_CtrlDpbActErr; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_CtrlDrop_F_x_FS_CtrlDrop; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_CtrlDropTJP_F_x_FS_CtrlDropTJP; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_CtrlEapAct_F_x_FS_CtrlEapAct; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_CtrlElapsedTime_F_x_FS_CtrlElapsedTime; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_CtrlEmergeBrake_F_x_FS_CtrlEmergeBrake; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_CtrlIpa_F_x_FS_CtrlIpa; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_CtrlLostFollow_F_x_FS_CtrlLostFollow; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_CtrlLostInch_F_x_FS_CtrlLostInch; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_CtrlLowSPD_F_x_FS_CtrlLowSPD; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_CtrlMaxVspCanc_F_x_FS_CtrlMaxVspCanc; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_CtrlMinVspCanc_F_x_FS_CtrlMinVspCanc; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_CtrlPreBrake_F_x_FS_CtrlPreBrake; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_CtrlPulled_F_x_FS_CtrlPulled; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_CtrlSideG1_Act_F_x_FS_CtrlSideG1_Act; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_CtrlSideG1_NoAct_F_x_FS_CtrlSideG1_NoAct; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_CtrlSideG2_Act_F_x_FS_CtrlSideG2_Act; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_CtrlSideG2_NoAct_F_x_FS_CtrlSideG2_NoAct; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_CtrlSlip_F_x_FS_CtrlSlip; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_CtrlSteepSlope_F_x_FS_CtrlSteepSlope; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_CtrlStpAutoACC_F_x_FS_CtrlStpAutoACC; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_CtrlStpAutoFCA_F_x_FS_CtrlStpAutoFCA; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_CtrlStpAutoTJP_F_x_FS_CtrlStpAutoTJP; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_CtrlStpBrkAndAccele_F_x_FS_CtrlStpBrkAndAccele; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_CtrlStpFfpACC_F_x_FS_CtrlStpFfpACC; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_CtrlStpFfpFCA_F_x_FS_CtrlStpFfpFCA; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_CtrlStpLostACC_F_x_FS_CtrlStpLostACC; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_CtrlStrAngleCanc1_F_x_FS_CtrlStrAngleCanc1; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_CtrlStrAngleCanc2_F_x_FS_CtrlStrAngleCanc2; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_CtrlYawrate_F_x_FS_CtrlYawrate; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_CvtFail_F_x_FS_CvtFail; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_CvtGSens_F_x_FS_CvtGSens; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_CvtMisMatch_F_x_FS_CvtMisMatch; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_DgnOkCancel_F_x_FS_DgnOkCancel; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_ETCFail_F_x_FS_ETCFail; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_EapCancel_F_x_FS_EapCancel; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_EcmAccC_F_x_FS_EcmAccC; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_EcmAccF_F_x_FS_EcmAccF; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_EcmAccInh_F_x_FS_EcmAccInh; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_EcmAccInh_H_F_x_FS_EcmAccInh_H; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_EcmAscd_A_F_x_FS_EcmAscd_A; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_EcmAscd_C_F_x_FS_EcmAscd_C; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_EcmAscd_C_H_F_x_FS_EcmAscd_C_H; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_EcmEng_F_x_FS_EcmEng; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_EngOff_F_x_FS_EngOff; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_EpsSystemCancel_F_x_FS_EpsSystemCancel; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_EpsSystemErr_F_x_FS_EpsSystemErr; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_FEBCountFail_F_x_FS_FEBCountFail; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_FEB_YawrateSafeSts_F_x_FS_FEB_YawrateSafeSts; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_HevRdy_F_x_FS_HevRdy; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_HevSys_F_x_FS_HevSys; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_ICCCanFail_F_x_FS_ICCCanFail; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_ICCCmdFail_F_x_FS_ICCCmdFail; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_IDMCanFail_A_F_x_FS_IDMCanFail_A; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_IDMCanFail_C_F_x_FS_IDMCanFail_C; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_IGNVolt_H_F_x_FS_IGNVolt_H; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_IGNVolt_L_F_x_FS_IGNVolt_L; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_IdmTrqFail_F_x_FS_IdmTrqFail; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_LDPFunc_A_F_x_FS_LDPFunc_A; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_LDPFunc_C_F_x_FS_LDPFunc_C; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_LsAlignmentMonitor_F_x_FS_LsAlignmentMonitor; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_LsAllowDistMoveW1_F_x_FS_LsAllowDistMoveW1; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_LsAllowDistMoveW2_F_x_FS_LsAllowDistMoveW2; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_LsAllowDistStopW1_F_x_FS_LsAllowDistStopW1; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_LsAllowDistStopW2_F_x_FS_LsAllowDistStopW2; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_LsCameraFusion_F_x_FS_LsCameraFusion; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_LsConfidence_F_x_FS_LsConfidence; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_LsDbaSupF2_F_x_FS_LsDbaSupF2; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_LsFcaEnblF1_F_x_FS_LsFcaEnblF1; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_LsFcaEnblF3_F_x_FS_LsFcaEnblF3; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_LsGuardrail_F_x_FS_LsGuardrail; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_LsHypothesis_F_x_FS_LsHypothesis; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_LsProbability_F_x_FS_LsProbability; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_LsRadarCheckInh_F_x_FS_LsRadarCheckInh; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_LsTgtLost_F_x_FS_LsTgtLost; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_LsTgtLostFcw_F_x_FS_LsTgtLostFcw; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_LsVrelCanc_F_x_FS_LsVrelCanc; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_Ls_EmergeBrk_PMT_F_x_FS_Ls_EmergeBrk_PMT; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_Ls_PreBrk_PMT_F_x_FS_Ls_PreBrk_PMT; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_RadBlockage_F_x_FS_RadBlockage; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_RadBlockageMsgByCam_F_x_FS_RadBlockageMsgByCam; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_RadCanFail_F_x_FS_RadCanFail; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_RadFail_F_x_FS_RadFail; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_RadHiTemp_F_x_FS_RadHiTemp; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_RadMisAlignFail_F_x_FS_RadMisAlignFail; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_RadVolt_L_F_x_FS_RadVolt_L; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_RadWaveInterf_F_x_FS_RadWaveInterf; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_SCAM3_BlurImg_F_x_FS_SCAM3_BlurImg; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_SCAM3_BlurImg_ICC_F_x_FS_SCAM3_BlurImg_ICC; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_SCAM3_Foggy_F_x_FS_SCAM3_Foggy; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_SCAM3_Foggy_ICC_F_x_FS_SCAM3_Foggy_ICC; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_SCAM3_FullBlk_F_x_FS_SCAM3_FullBlk; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_SCAM3_Halos_F_x_FS_SCAM3_Halos; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_SCAM3_LowSun_F_x_FS_SCAM3_LowSun; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_SCAM3_MisFocus_F_x_FS_SCAM3_MisFocus; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_SCAM3_PartialBlk_F_x_FS_SCAM3_PartialBlk; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_SCAM3_PitMisAlign_F_x_FS_SCAM3_PitMisAlign; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_SCAM3_PitchThOut_F_x_FS_SCAM3_PitchThOut; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_SCAM3_SmearImg_F_x_FS_SCAM3_SmearImg; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_SCAM3_SmearImg_ICC_F_x_FS_SCAM3_SmearImg_ICC; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_SCAM3_SmearSpot_F_x_FS_SCAM3_SmearSpot; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_SCAM3_SmearedSptM_F_x_FS_SCAM3_SmearedSptM; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_SCAM3_Splashes_F_x_FS_SCAM3_Splashes; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_SCAM3_Splashes_ICC_F_x_FS_SCAM3_Splashes_ICC; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_SCAM3_SunRay_F_x_FS_SCAM3_SunRay; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_SCAM3_SunRay_ICC_F_x_FS_SCAM3_SunRay_ICC; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_SCAM3_YawMisAlign_F_x_FS_SCAM3_YawMisAlign; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_SCAM3_YawThOut_F_x_FS_SCAM3_YawThOut; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_SOWSenCANUnRcv_L_F_x_FS_SOWSenCANUnRcv_L; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_SOWSenCANUnRcv_R_F_x_FS_SOWSenCANUnRcv_R; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_SOWSensorFail_L_F_x_FS_SOWSensorFail_L; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_SOWSensorFail_R_F_x_FS_SOWSensorFail_R; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_STRSensorFail_F_x_FS_STRSensorFail; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_SW1_F_x_FS_SW1; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_SW3_F_x_FS_SW3; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_SenGUnavail_F_x_FS_SenGUnavail; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_SenNoise_F_x_FS_SenNoise; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_SenPulseL_F_x_FS_SenPulseL; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_SenPulseR_F_x_FS_SenPulseR; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_SenSonar_B_F_x_FS_SenSonar_B; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_SenSow2L_F_x_FS_SenSow2L; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_SenSow2R_F_x_FS_SenSow2R; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_SenSpd_A_F_x_FS_SenSpd_A; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_SenSpd_C_F_x_FS_SenSpd_C; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_SenWheelC_F_x_FS_SenWheelC; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_SenWheelUnavail_F_x_FS_SenWheelUnavail; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_StbAbsLamp_ACC_F_x_FS_StbAbsLamp_ACC; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_StbIdmFail_F_x_FS_StbIdmFail; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_StbVdcEcu_F_x_FS_StbVdcEcu; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_SwApoOvr_Kinkyu_F_x_FS_SwApoOvr_Kinkyu; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_SwApoOvr_Yobi_F_x_FS_SwApoOvr_Yobi; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_SwApoWorkUp_F_x_FS_SwApoWorkUp; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_SwCancel_F_x_FS_SwCancel; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_SwClutch_F_x_FS_SwClutch; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_SwDouble_F_x_FS_SwDouble; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_SwEtsMod_F_x_FS_SwEtsMod; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_SwFebOff_F_x_FS_SwFebOff; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_SwFix_F_x_FS_SwFix; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_SwFixAcc_F_x_FS_SwFixAcc; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(boolean_NP, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_SwFixAcc_forRN_F_x_FS_SwFixAcc_forRN; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(boolean_NP, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_SwFixAsl_F_x_FS_SwFixAsl; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_SwFix_forRN_F_x_FS_SwFix_forRN; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_SwLogic_A_F_x_FS_SwLogic_A; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_SwLogic_A_forRN_F_x_FS_SwLogic_A_forRN; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(boolean_NP, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_SwLogic_C_F_x_FS_SwLogic_C; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(boolean_NP, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_SwLogic_C_forRN_F_x_FS_SwLogic_C_forRN; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_SwMainOff_F_x_FS_SwMainOff; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_SwOffRoad_F_x_FS_SwOffRoad; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_SwPark_F_x_FS_SwPark; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_SwSame_F_x_FS_SwSame; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_SwSnowACC_F_x_FS_SwSnowACC; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_SwTcsOff_F_x_FS_SwTcsOff; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_SwTcsOffACC_F_x_FS_SwTcsOffACC; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_SwWiper_F_x_FS_SwWiper; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_TCSActCancel_ACC_F_x_FS_TCSActCancel_ACC; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_TCSSystem_A_F_x_FS_TCSSystem_A; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_TCSSystem_C_F_x_FS_TCSSystem_C; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_TestDynamo_F_x_FS_TestDynamo; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_VDCActCancel_F_x_FS_VDCActCancel; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_VDCActCancel_ACC_F_x_FS_VDCActCancel_ACC; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_VDCFunc_A_F_x_FS_VDCFunc_A; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_VDCFunc_A_wACC_F_x_FS_VDCFunc_A_wACC; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_VDCFunc_C_F_x_FS_VDCFunc_C; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(boolean_NP, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_VDCFunc_C_wACC_F_x_FS_VDCFunc_C_wACC; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_VDCSystem_A_F_x_FS_VDCSystem_A; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_VDCSystem_C_F_x_FS_VDCSystem_C; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_VDCVolt_A_wACC_F_x_FS_VDCVolt_A_wACC; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(boolean_NP, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_VDCVolt_C_wACC_F_x_FS_VDCVolt_C_wACC; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_VSPSignalFail_F_x_FS_VSPSignalFail; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_VariantCodeErrFail_F_x_FS_VariantCodeErrFail; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_WHSensorFail_FL_F_x_FS_WHSensorFail_FL; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_WHSensorFail_FR_F_x_FS_WHSensorFail_FR; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_WHSensorFail_RL_F_x_FS_WHSensorFail_RL; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_WHSensorFail_RR_F_x_FS_WHSensorFail_RR; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_ePkbActReqErr_F_x_FS_ePkbActReqErr; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_ePkbBreaking_F_x_FS_ePkbBreaking; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_ePkbCancel_F_x_FS_ePkbCancel; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(boolean_NP, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_ePkbErr_F_x_FS_ePkbErr; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_ePkbSsaUnavail_F_x_FS_ePkbSsaUnavail; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_ePkbSystemCancel_F_x_FS_ePkbSystemCancel; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(boolean_NP, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_ePkbSystemErr_F_x_FS_ePkbSystemErr; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(boolean_NP, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_vFS_SOWSensorFail3_L_F_x_FS_vFS_SOWSensorFail3_L; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(boolean_NP, RTE_VAR_INIT) Rte_OEM_DIAG_F_x_FS_vFS_SOWSensorFail3_R_F_x_FS_vFS_SOWSensorFail3_R; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_PwmHwAb_PV_x_MotorDriveInfo_PV_x_MotorDriveInfo; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_PwmHwAb_PV_x_UdsOmHwOutMotDuty_PV_x_UdsOmHwOutMotDuty; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(boolean_NP, RTE_VAR_INIT) Rte_SUP_DIAG_F_x_EEPROM_Fail_F_x_EEPROM_Fail; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(boolean_NP, RTE_VAR_INIT) Rte_SUP_DIAG_PF_x_ADCandCANVFSACT_PF_x_ADCandCANVFSACT; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(boolean_NP, RTE_VAR_INIT) Rte_SUP_DIAG_PF_x_EEPROMFSACT_PF_x_EEPROMFSACT; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(boolean_NP, RTE_VAR_INIT) Rte_SUP_DIAG_PF_x_MotorOutFsAct_PF_x_MotorOutFsAct; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(boolean_NP, RTE_VAR_INIT) Rte_UDSCOM_F_x_ACT_SteerCntrlOn_F_x_ACT_SteerCntrlOn; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(boolean_NP, RTE_VAR_INIT) Rte_UDSCOM_F_x_AT0534BRKPRS_F_x_AT0534BRKPRS; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(boolean_NP, RTE_VAR_INIT) Rte_UDSCOM_F_x_AT0535BRKPRS_F_x_AT0535BRKPRS; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(boolean_NP, RTE_VAR_INIT) Rte_UDSCOM_F_x_AT0536BRKPRS_F_x_AT0536BRKPRS; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_UDSCOM_F_x_ATDynamoMode_F_x_ATDynamoMode; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(boolean_NP, RTE_VAR_INIT) Rte_UDSCOM_F_x_ATHandfree_F_x_ATHandfree; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_UDSCOM_F_x_ATMeterBuzzer_F_x_ATMeterBuzzer; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(boolean_NP, RTE_VAR_INIT) Rte_UDSCOM_F_x_ATMeterLamp_F_x_ATMeterLamp; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(boolean_NP, RTE_VAR_INIT) Rte_UDSCOM_F_x_ATSonarSpeaker_F_x_ATSonarSpeaker; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(boolean_NP, RTE_VAR_INIT) Rte_UDSCOM_F_x_ATePKBreq_F_x_ATePKBreq; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(boolean_NP, RTE_VAR_INIT) Rte_UDSCOM_F_x_FEBdefaultOFF_F_x_FEBdefaultOFF; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(boolean_NP, RTE_VAR_INIT) Rte_UDSCOM_F_x_FEBdefaultON_F_x_FEBdefaultON; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(boolean_NP, RTE_VAR_INIT) Rte_UDSCOM_F_x_StrTrqCalibResultInit_F_x_StrTrqCalibResultInit; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(boolean_NP, RTE_VAR_INIT) Rte_UDSCOM_F_x_StrTrqCalibStartConsult_F_x_StrTrqCalibStartConsult; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(boolean_NP, RTE_VAR_INIT) Rte_UDSCOM_F_x_StrTrqCalibStartEOL_F_x_StrTrqCalibStartEOL; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(boolean_NP, RTE_VAR_INIT) Rte_UDSCOM_F_x_StrTrqCalibStopConsult_F_x_StrTrqCalibStopConsult; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(boolean_NP, RTE_VAR_INIT) Rte_UDSCOM_F_x_StrTrqCalibStopEOL_F_x_StrTrqCalibStopEOL; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(boolean_NP, RTE_VAR_INIT) Rte_UDSCOM_PF_SpCanEnable_PF_SpCanEnable; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(boolean_NP, RTE_VAR_INIT) Rte_UDSCOM_PF_x_ClearEAPExecutionReq_PF_x_ClearEAPExecutionReq; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(boolean_NP, RTE_VAR_INIT) Rte_UDSCOM_PF_x_ClearFEBExecutionReq_PF_x_ClearFEBExecutionReq; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(boolean_NP, RTE_VAR_INIT) Rte_UDSCOM_PF_x_DtcClr_PF_x_DtcClr; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(boolean_NP, RTE_VAR_INIT) Rte_UDSCOM_PF_x_EepInitReq_PF_x_EepInitReq; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(boolean_NP, RTE_VAR_INIT) Rte_UDSCOM_PF_x_Sector1ClearToEEPROM_PF_x_Sector1ClearToEEPROM; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(boolean_NP, RTE_VAR_INIT) Rte_UDSCOM_PF_x_Sector2ClearToEEPROM_PF_x_Sector2ClearToEEPROM; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(boolean_NP, RTE_VAR_INIT) Rte_UDSCOM_PF_x_Sector3ClearToEEPROM_PF_x_Sector3ClearToEEPROM; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(boolean_NP, RTE_VAR_INIT) Rte_UDSCOM_PF_x_SpeakerSnd1_Stop_PF_x_SpeakerSnd1_Stop; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(boolean_NP, RTE_VAR_INIT) Rte_UDSCOM_PF_x_SpeakerSnd2_Stop_PF_x_SpeakerSnd2_Stop; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(boolean_NP, RTE_VAR_INIT) Rte_UDSCOM_PF_x_SpeakerSnd3_Stop_PF_x_SpeakerSnd3_Stop; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(boolean_NP, RTE_VAR_INIT) Rte_UDSCOM_PF_x_SpeakerSnd4_Stop_PF_x_SpeakerSnd4_Stop; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(boolean_NP, RTE_VAR_INIT) Rte_UDSCOM_PF_x_UdsAtHwOutSwLed1_PF_x_UdsAtHwOutSwLed1; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(boolean_NP, RTE_VAR_INIT) Rte_UDSCOM_PF_x_UdsAtHwOutSwLed2_PF_x_UdsAtHwOutSwLed2; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(boolean_NP, RTE_VAR_INIT) Rte_UDSCOM_PF_x_UdsAtHwOutSwLed3_PF_x_UdsAtHwOutSwLed3; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(boolean_NP, RTE_VAR_INIT) Rte_UDSCOM_PF_x_UdsSetBSWActEeprom_PF_x_UdsSetBSWActEeprom; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(boolean_NP, RTE_VAR_INIT) Rte_UDSCOM_PF_x_UdsSetFEBFCWActEeprom_PF_x_UdsSetFEBFCWActEeprom; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(boolean_NP, RTE_VAR_INIT) Rte_UDSCOM_PF_x_UdsSetLDWActEeprom_PF_x_UdsSetLDWActEeprom; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_UDSCOM_PV_pct_UdsAtHwOutMotDuty_PV_pct_UdsAtHwOutMotDuty; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8, RTE_VAR_INIT) Rte_UDSCOM_PV_x_SetSigmaNoV_PV_x_SetSigmaNoV; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UDSCP_SigmaVSsdType, RTE_VAR_INIT) Rte_UDSCOM_PV_x_SetSigmaVSsd0_PV_x_SetSigmaVSsd0; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UDSCP_SigmaVSsdType, RTE_VAR_INIT) Rte_UDSCOM_PV_x_SetSigmaVSsd1_PV_x_SetSigmaVSsd1; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UDSCP_SigmaVSsdType, RTE_VAR_INIT) Rte_UDSCOM_PV_x_SetSigmaVSsd2_PV_x_SetSigmaVSsd2; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UDSCP_SigmaVSsdType, RTE_VAR_INIT) Rte_UDSCOM_PV_x_SetSigmaVSsd3_PV_x_SetSigmaVSsd3; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UDSCP_SigmaVSsdType, RTE_VAR_INIT) Rte_UDSCOM_PV_x_SetSigmaVSsd4_PV_x_SetSigmaVSsd4; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8, RTE_VAR_INIT) Rte_UDSCOM_PV_x_SetSigmaVSsdFrameIndex_PV_x_SetSigmaVSsdFrameIndex; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UDSCP_SigmaVTddType, RTE_VAR_INIT) Rte_UDSCOM_PV_x_SetSigmaVTdd0_PV_x_SetSigmaVTdd0; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UDSCP_SigmaVTddType, RTE_VAR_INIT) Rte_UDSCOM_PV_x_SetSigmaVTdd1_PV_x_SetSigmaVTdd1; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UDSCP_SigmaVTddType, RTE_VAR_INIT) Rte_UDSCOM_PV_x_SetSigmaVTdd2_PV_x_SetSigmaVTdd2; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UDSCP_SigmaVTddType, RTE_VAR_INIT) Rte_UDSCOM_PV_x_SetSigmaVTdd3_PV_x_SetSigmaVTdd3; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UDSCP_SigmaVTddType, RTE_VAR_INIT) Rte_UDSCOM_PV_x_SetSigmaVTdd4_PV_x_SetSigmaVTdd4; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8, RTE_VAR_INIT) Rte_UDSCOM_PV_x_SetSigmaVTddFrameIndex_PV_x_SetSigmaVTddFrameIndex; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_UDSCOM_PV_x_SetVARIANTCODE_PV_x_SetVARIANTCODE; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_UDSCOM_PV_x_SetVARIANTUdsEv1_PV_x_SetVARIANTUdsEv1; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UDSCP_VinType, RTE_VAR_INIT) Rte_UDSCOM_PV_x_SetVin_PV_x_SetVin; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_UDSCOM_PV_x_SetVinReqNum_PV_x_SetVinReqNum; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(boolean, RTE_VAR_INIT) Rte_UDSCOM_PV_x_SigmaVSsd0Req_PV_x_SigmaVSsd0Req; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(boolean, RTE_VAR_INIT) Rte_UDSCOM_PV_x_SigmaVSsd1Req_PV_x_SigmaVSsd1Req; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(boolean, RTE_VAR_INIT) Rte_UDSCOM_PV_x_SigmaVSsd2Req_PV_x_SigmaVSsd2Req; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(boolean, RTE_VAR_INIT) Rte_UDSCOM_PV_x_SigmaVSsd3Req_PV_x_SigmaVSsd3Req; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(boolean, RTE_VAR_INIT) Rte_UDSCOM_PV_x_SigmaVSsd4Req_PV_x_SigmaVSsd4Req; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(boolean, RTE_VAR_INIT) Rte_UDSCOM_PV_x_SigmaVTdd0Req_PV_x_SigmaVTdd0Req; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(boolean, RTE_VAR_INIT) Rte_UDSCOM_PV_x_SigmaVTdd1Req_PV_x_SigmaVTdd1Req; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(boolean, RTE_VAR_INIT) Rte_UDSCOM_PV_x_SigmaVTdd2Req_PV_x_SigmaVTdd2Req; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(boolean, RTE_VAR_INIT) Rte_UDSCOM_PV_x_SigmaVTdd3Req_PV_x_SigmaVTdd3Req; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(boolean, RTE_VAR_INIT) Rte_UDSCOM_PV_x_SigmaVTdd4Req_PV_x_SigmaVTdd4Req; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_UDSCOM_PV_x_SpeakerSnd1_Req_PV_x_SpeakerSnd1_Req; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_UDSCOM_PV_x_SpeakerSnd1_Vol_PV_x_SpeakerSnd1_Vol; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_UDSCOM_PV_x_SpeakerSnd2_Req_PV_x_SpeakerSnd2_Req; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_UDSCOM_PV_x_SpeakerSnd2_Vol_PV_x_SpeakerSnd2_Vol; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_UDSCOM_PV_x_SpeakerSnd3_Req_PV_x_SpeakerSnd3_Req; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_UDSCOM_PV_x_SpeakerSnd3_Vol_PV_x_SpeakerSnd3_Vol; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_UDSCOM_PV_x_SpeakerSnd4_Req_PV_x_SpeakerSnd4_Req; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_UDSCOM_PV_x_SpeakerSnd4_Vol_PV_x_SpeakerSnd4_Vol; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_UDSCOM_PV_x_UdsSetBSWLedStatEeprom_PV_x_UdsSetBSWLedStatEeprom; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint16_NP, RTE_VAR_INIT) Rte_UDSCOM_V_degC_InputTempForStrTrqCalib_V_degC_InputTempForStrTrqCalib; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_VehStatus_In_F_x_ABSMalfunction_F_x_ABSMalfunction; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_VehStatus_In_F_x_ABSinRegulation_F_x_ABSinRegulation; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_VehStatus_In_F_x_ACCINH_F_x_ACCINH; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_VehStatus_In_F_x_ACCINH_S_F_x_ACCINH_S; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_VehStatus_In_F_x_ACC_Alive_F_x_ACC_Alive; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_VehStatus_In_F_x_ACC_ENBL_F_x_ACC_ENBL; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(boolean_NP, RTE_VAR_INIT) Rte_VehStatus_In_F_x_ACC_LimitRequest_F_x_ACC_LimitRequest; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_VehStatus_In_F_x_ACC_STATUS_F_x_ACC_STATUS; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_VehStatus_In_F_x_ADAS2_LAT_CANCEL_BUZ_F_x_ADAS2_LAT_CANCEL_BUZ; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_VehStatus_In_F_x_ADAS2_LDP_FAIL_F_x_ADAS2_LDP_FAIL; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_VehStatus_In_F_x_ADAS2_LDP_SW_MAIN_F_x_ADAS2_LDP_SW_MAIN; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_VehStatus_In_F_x_ADAS2_LDW_FAIL_F_x_ADAS2_LDW_FAIL; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_VehStatus_In_F_x_ADAS2_LDW_SW_MAIN_F_x_ADAS2_LDW_SW_MAIN; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_VehStatus_In_F_x_ADAS2_LONGI_CANCEL_BUZ_F_x_ADAS2_LONGI_CANCEL_BUZ; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_VehStatus_In_F_x_ADAS2_WARN_BSW_BUZ_F_x_ADAS2_WARN_BSW_BUZ; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_VehStatus_In_F_x_ADAS2_WARN_FCW_BUZ_F_x_ADAS2_WARN_FCW_BUZ; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_VehStatus_In_F_x_ADAS2_WARN_FEB_BUZ_F_x_ADAS2_WARN_FEB_BUZ; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_VehStatus_In_F_x_ADAS2_WARN_LDW_BUZ_F_x_ADAS2_WARN_LDW_BUZ; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_VehStatus_In_F_x_AEB_ENBL_F_x_AEB_ENBL; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_VehStatus_In_F_x_APS_IDLE_F_x_APS_IDLE; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_VehStatus_In_F_x_ASCDFAIL_F_x_ASCDFAIL; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_VehStatus_In_F_x_ASRMalfunction_F_x_ASRMalfunction; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_VehStatus_In_F_x_ASRinRegulation_F_x_ASRinRegulation; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_VehStatus_In_F_x_ATCVTFail_F_x_ATCVTFail; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_VehStatus_In_F_x_AT_ONSHIFT_F_x_AT_ONSHIFT; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_VehStatus_In_F_x_AYCinRegulation_F_x_AYCinRegulation; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_VehStatus_In_F_x_AbnormalVolt_F_x_AbnormalVolt; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_VehStatus_In_F_x_AbsACT_F_x_AbsACT; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_VehStatus_In_F_x_AbsACTFCA_F_x_AbsACTFCA; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_VehStatus_In_F_x_AllButtonReleased_F_x_AllButtonReleased; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_VehStatus_In_F_x_Asl_Switch_F_x_Asl_Switch; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_VehStatus_In_F_x_Asl_Switch4_F_x_Asl_Switch4; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_VehStatus_In_F_x_AutoHorOoc_VSi_F_x_AutoHorOoc_VSi; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_VehStatus_In_F_x_AutoYawOoc_VSi_F_x_AutoYawOoc_VSi; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_VehStatus_In_F_x_BACK_DOOR_SW_TJP_F_x_BACK_DOOR_SW_TJP; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_VehStatus_In_F_x_BPFS_NC_F_x_BPFS_NC; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_VehStatus_In_F_x_BPFS_NO_F_x_BPFS_NO; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(boolean_NP, RTE_VAR_INIT) Rte_VehStatus_In_F_x_BSI_AlertLeftStatus_F_x_BSI_AlertLeftStatus; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(boolean_NP, RTE_VAR_INIT) Rte_VehStatus_In_F_x_BSI_AlertRightStatus_F_x_BSI_AlertRightStatus; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_VehStatus_In_F_x_BelSts_F_x_BelSts; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_VehStatus_In_F_x_BncSW_F_x_BncSW; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_VehStatus_In_F_x_BnoBCM_F_x_BnoBCM; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_VehStatus_In_F_x_Bnosw_F_x_Bnosw; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_VehStatus_In_F_x_BpfsNo_F_x_BpfsNo; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_VehStatus_In_F_x_BrakeLmpSta_F_x_BrakeLmpSta; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_VehStatus_In_F_x_BrkUnavailable_F_x_BrkUnavailable; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_VehStatus_In_F_x_CTA_CollisionRiskAlert_F_x_CTA_CollisionRiskAlert; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_VehStatus_In_F_x_CameraCalibStatus_VSi_F_x_CameraCalibStatus_VSi; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_VehStatus_In_F_x_CameraHiTempStatus_VSi_F_x_CameraHiTempStatus_VSi; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_VehStatus_In_F_x_CancelButton_F_x_CancelButton; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_VehStatus_In_F_x_Canmask_F_x_Canmask; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_VehStatus_In_F_x_ClutchSw_F_x_ClutchSw; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_VehStatus_In_F_x_DPB_ACT_F_x_DPB_ACT; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_VehStatus_In_F_x_DisUnit_F_x_DisUnit; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_VehStatus_In_F_x_DispUnit_F_x_DispUnit; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_VehStatus_In_F_x_DisplayedSpeedUnit_F_x_DisplayedSpeedUnit; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_VehStatus_In_F_x_DistButton_F_x_DistButton; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_VehStatus_In_F_x_EPS_ACT_FLAG_F_x_EPS_ACT_FLAG; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_VehStatus_In_F_x_ESCMalfunction_F_x_ESCMalfunction; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_VehStatus_In_F_x_ESC_VDC_Deactivated_F_x_ESC_VDC_Deactivated; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_VehStatus_In_F_x_EcmAccCANFail_F_x_EcmAccCANFail; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_VehStatus_In_F_x_EcmAccCmdFail_F_x_EcmAccCmdFail; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_VehStatus_In_F_x_EcmETCFail_F_x_EcmETCFail; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_VehStatus_In_F_x_EcmMainSw_F_x_EcmMainSw; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_VehStatus_In_F_x_EcoReq_F_x_EcoReq; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_VehStatus_In_F_x_EngineOn_F_x_EngineOn; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_VehStatus_In_F_x_FCAAS_Alive_F_x_FCAAS_Alive; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_VehStatus_In_F_x_FCAAS_Enable_F_x_FCAAS_Enable; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_VehStatus_In_F_x_FCAAS_Status_F_x_FCAAS_Status; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_VehStatus_In_F_x_FrontWiperHI_F_x_FrontWiperHI; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_VehStatus_In_F_x_FrontWiperLO_F_x_FrontWiperLO; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(boolean_NP, RTE_VAR_INIT) Rte_VehStatus_In_F_x_GearShiftInProgress_F_x_GearShiftInProgress; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_VehStatus_In_F_x_IDM_Enable_F_x_IDM_Enable; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_VehStatus_In_F_x_ITS_SSAENABLE_F_x_ITS_SSAENABLE; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_VehStatus_In_F_x_IgnitionSupplyConfirmation_F_x_IgnitionSupplyConfirmation; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_VehStatus_In_F_x_LCA_SteeringOverride_F_x_LCA_SteeringOverride; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_VehStatus_In_F_x_LDP_ALIVE_F_x_LDP_ALIVE; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_VehStatus_In_F_x_LDWWarningLeft_VSi_F_x_LDWWarningLeft_VSi; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_VehStatus_In_F_x_LDWWarningRight_VSi_F_x_LDWWarningRight_VSi; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_VehStatus_In_F_x_LDW_HapticalActionRequest_F_x_LDW_HapticalActionRequest; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(boolean_NP, RTE_VAR_INIT) Rte_VehStatus_In_F_x_LDW_StopAlertRequest_F_x_LDW_StopAlertRequest; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(boolean_NP, RTE_VAR_INIT) Rte_VehStatus_In_F_x_LaneCrosLeft_VSi_F_x_LaneCrosLeft_VSi; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(boolean_NP, RTE_VAR_INIT) Rte_VehStatus_In_F_x_LaneCrosRight_VSi_F_x_LaneCrosRight_VSi; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_VehStatus_In_F_x_LdwFailure_VSi_F_x_LdwFailure_VSi; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(boolean_NP, RTE_VAR_INIT) Rte_VehStatus_In_F_x_MMODE_F_x_MMODE; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_VehStatus_In_F_x_MainSwOn_F_x_MainSwOn; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_VehStatus_In_F_x_MainSwOn4_F_x_MainSwOn4; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_VehStatus_In_F_x_Misalign_F_x_Misalign; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_VehStatus_In_F_x_MsrACT_F_x_MsrACT; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_VehStatus_In_F_x_ObjMeas_F_x_ObjMeas; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_VehStatus_In_F_x_Override_F_x_Override; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_VehStatus_In_F_x_RIGHT_IDEN_F_x_RIGHT_IDEN; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_VehStatus_In_F_x_ResumeButton_F_x_ResumeButton; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_VehStatus_In_F_x_RxInvalid_F_x_RxInvalid; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_VehStatus_In_F_x_SSAFAIL_F_x_SSAFAIL; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_VehStatus_In_F_x_SW_Input_fail_F_x_SW_Input_fail; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_VehStatus_In_F_x_SenBlock_F_x_SenBlock; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_VehStatus_In_F_x_SenDefect_F_x_SenDefect; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_VehStatus_In_F_x_SenExtErr_F_x_SenExtErr; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_VehStatus_In_F_x_SenHighTempErr_F_x_SenHighTempErr; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_VehStatus_In_F_x_SetButton_F_x_SetButton; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_VehStatus_In_F_x_SeverePitchAxMis_VSi_F_x_SeverePitchAxMis_VSi; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_VehStatus_In_F_x_SevereYawAxMis_VSi_F_x_SevereYawAxMis_VSi; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_VehStatus_In_F_x_SideRadarLeft_Blockage_F_x_SideRadarLeft_Blockage; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_VehStatus_In_F_x_SideRadarLeft_Failure_F_x_SideRadarLeft_Failure; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_VehStatus_In_F_x_SideRadarLeft_FunctionStatus_F_x_SideRadarLeft_FunctionStatus; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_VehStatus_In_F_x_SideRadarRight_Blockage_F_x_SideRadarRight_Blockage; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_VehStatus_In_F_x_SideRadarRight_Failure_F_x_SideRadarRight_Failure; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_VehStatus_In_F_x_SideRadarRight_FunctionStatus_F_x_SideRadarRight_FunctionStatus; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(boolean_NP, RTE_VAR_INIT) Rte_VehStatus_In_F_x_SonarBlockage_F_x_SonarBlockage; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_VehStatus_In_F_x_SsaOnOff_F_x_SsaOnOff; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_VehStatus_In_F_x_StrSenFailFlag_F_x_StrSenFailFlag; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_VehStatus_In_F_x_TAIL_L_REQ_F_x_TAIL_L_REQ; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_VehStatus_In_F_x_TJP_ON_OFF_F_x_TJP_ON_OFF; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_VehStatus_In_F_x_TcsACT_F_x_TcsACT; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_VehStatus_In_F_x_VC_AT_D_RANGE_F_x_VC_AT_D_RANGE; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_VehStatus_In_F_x_VC_R_RNG_F_x_VC_R_RNG; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(boolean_NP, RTE_VAR_INIT) Rte_VehStatus_In_F_x_VDCactivationState_F_x_VDCactivationState; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_VehStatus_In_F_x_VS_HandBrake_F_x_VS_HandBrake; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_VehStatus_In_F_x_ValveCheck_F_x_ValveCheck; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_VehStatus_In_F_x_VcAtCanDrng_F_x_VcAtCanDrng; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_VehStatus_In_F_x_VcAtCanNrng_F_x_VcAtCanNrng; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_VehStatus_In_F_x_VcAtCanPrng_F_x_VcAtCanPrng; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_VehStatus_In_F_x_VcAtCanRrng_F_x_VcAtCanRrng; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_VehStatus_In_F_x_VdcACT_F_x_VdcACT; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(boolean_NP, RTE_VAR_INIT) Rte_VehStatus_In_F_x_WheelSpeedUnavailable_F_x_WheelSpeedUnavailable; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(boolean_NP, RTE_VAR_INIT) Rte_VehStatus_In_F_x_YMCRequestFlag_F_x_YMCRequestFlag; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(boolean_NP, RTE_VAR_INIT) Rte_VehStatus_In_PV_x_IDM_A3_CruiseControlInhibitRequest_NiSW_PV_x_IDM_A3_CruiseControlInhibitRequest_NiSW; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Float, RTE_VAR_INIT) Rte_VehStatus_In_V_G_GSensorValue_V_G_GSensorValue; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_VehStatus_In_V_G_LongitudinalAccelCorrected_V_G_LongitudinalAccelCorrected; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_VehStatus_In_V_G_TransAcc02_V_G_TransAcc02; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(sint32_NP, RTE_VAR_INIT) Rte_VehStatus_In_V_G_TransversalAccelCorrected_V_G_TransversalAccelCorrected; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_VehStatus_In_V_G_TransversalAccelRaw_V_G_TransversalAccelRaw; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint16_NP, RTE_VAR_INIT) Rte_VehStatus_In_V_Nm_DriverSteeringWheelTorque_V_Nm_DriverSteeringWheelTorque; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_VehStatus_In_V_Nm_DriverWheelTorqueRequest_V_Nm_DriverWheelTorqueRequest; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_VehStatus_In_V_Nm_MaxPowerTrainWheelTorque_V_Nm_MaxPowerTrainWheelTorque; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_VehStatus_In_V_Nm_MinPowerTrainWheelTorque_V_Nm_MinPowerTrainWheelTorque; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt32, RTE_VAR_INIT) Rte_VehStatus_In_V_Nm_TENG_V_Nm_TENG; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt32, RTE_VAR_INIT) Rte_VehStatus_In_V_Nm_TENG_T0_V_Nm_TENG_T0; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_VehStatus_In_V_bar_PrssrSensrSig_V_bar_PrssrSensrSig; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_VehStatus_In_V_bar_Pss02_V_bar_Pss02; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_VehStatus_In_V_cm_DetectionLengthFront_IL_V_cm_DetectionLengthFront_IL; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_VehStatus_In_V_cm_DetectionLengthFront_ILIR_V_cm_DetectionLengthFront_ILIR; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_VehStatus_In_V_cm_DetectionLengthFront_ILOL_V_cm_DetectionLengthFront_ILOL; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_VehStatus_In_V_cm_DetectionLengthFront_IR_V_cm_DetectionLengthFront_IR; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_VehStatus_In_V_cm_DetectionLengthFront_IRIL_V_cm_DetectionLengthFront_IRIL; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_VehStatus_In_V_cm_DetectionLengthFront_IROR_V_cm_DetectionLengthFront_IROR; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_VehStatus_In_V_cm_DetectionLengthFront_OL_V_cm_DetectionLengthFront_OL; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_VehStatus_In_V_cm_DetectionLengthFront_OLIL_V_cm_DetectionLengthFront_OLIL; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_VehStatus_In_V_cm_DetectionLengthFront_OR_V_cm_DetectionLengthFront_OR; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_VehStatus_In_V_cm_DetectionLengthFront_ORIR_V_cm_DetectionLengthFront_ORIR; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_VehStatus_In_V_cm_DetectionLengthRear_IL_V_cm_DetectionLengthRear_IL; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_VehStatus_In_V_cm_DetectionLengthRear_ILIR_V_cm_DetectionLengthRear_ILIR; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_VehStatus_In_V_cm_DetectionLengthRear_ILOL_V_cm_DetectionLengthRear_ILOL; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_VehStatus_In_V_cm_DetectionLengthRear_IR_V_cm_DetectionLengthRear_IR; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_VehStatus_In_V_cm_DetectionLengthRear_IRIL_V_cm_DetectionLengthRear_IRIL; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_VehStatus_In_V_cm_DetectionLengthRear_IROR_V_cm_DetectionLengthRear_IROR; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_VehStatus_In_V_cm_DetectionLengthRear_OL_V_cm_DetectionLengthRear_OL; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_VehStatus_In_V_cm_DetectionLengthRear_OLIL_V_cm_DetectionLengthRear_OLIL; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_VehStatus_In_V_cm_DetectionLengthRear_OR_V_cm_DetectionLengthRear_OR; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_VehStatus_In_V_cm_DetectionLengthRear_ORIR_V_cm_DetectionLengthRear_ORIR; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_VehStatus_In_V_degC_ExternalTemperature_V_degC_ExternalTemperature; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(sint32_NP, RTE_VAR_INIT) Rte_VehStatus_In_V_deg_AngleSens_V_deg_AngleSens; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt32, RTE_VAR_INIT) Rte_VehStatus_In_V_deg_EPS_AngleSensor_V_deg_EPS_AngleSensor; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_VehStatus_In_V_deg_SteeringWheelAngleCorrected_V_deg_SteeringWheelAngleCorrected; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_VehStatus_In_V_deg_SteeringWheelAngleRaw_V_deg_SteeringWheelAngleRaw; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_VehStatus_In_V_deg_StrAngle_V_deg_StrAngle; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_VehStatus_In_V_degps2_GradientYawRate_V_degps2_GradientYawRate; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_VehStatus_In_V_degps_DriverTargetYawRate_V_degps_DriverTargetYawRate; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt32, RTE_VAR_INIT) Rte_VehStatus_In_V_degps_StrSpeed_V_degps_StrSpeed; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_VehStatus_In_V_degps_YawRadar_V_degps_YawRadar; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_VehStatus_In_V_degps_YawRateCorr_V_degps_YawRateCorr; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_VehStatus_In_V_degps_YawRateRaw_V_degps_YawRateRaw; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt32, RTE_VAR_INIT) Rte_VehStatus_In_V_km_Milage_V_km_Milage; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint16_NP, RTE_VAR_INIT) Rte_VehStatus_In_V_kph_VehicleSpeed_V_kph_VehicleSpeed; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_VehStatus_In_V_m_LeftLineOffset_VSi_V_m_LeftLineOffset_VSi; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_VehStatus_In_V_m_LeftLineViewRange_VSi_V_m_LeftLineViewRange_VSi; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(sint16_NP, RTE_VAR_INIT) Rte_VehStatus_In_V_m_RelativeDistanceXleft1_V_m_RelativeDistanceXleft1; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(sint16_NP, RTE_VAR_INIT) Rte_VehStatus_In_V_m_RelativeDistanceXleft2_V_m_RelativeDistanceXleft2; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(sint16_NP, RTE_VAR_INIT) Rte_VehStatus_In_V_m_RelativeDistanceXleft3_V_m_RelativeDistanceXleft3; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(sint16_NP, RTE_VAR_INIT) Rte_VehStatus_In_V_m_RelativeDistanceXleft4_V_m_RelativeDistanceXleft4; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(sint16_NP, RTE_VAR_INIT) Rte_VehStatus_In_V_m_RelativeDistanceXright1_V_m_RelativeDistanceXright1; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(sint16_NP, RTE_VAR_INIT) Rte_VehStatus_In_V_m_RelativeDistanceXright2_V_m_RelativeDistanceXright2; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(sint16_NP, RTE_VAR_INIT) Rte_VehStatus_In_V_m_RelativeDistanceXright3_V_m_RelativeDistanceXright3; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(sint16_NP, RTE_VAR_INIT) Rte_VehStatus_In_V_m_RelativeDistanceXright4_V_m_RelativeDistanceXright4; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(sint16_NP, RTE_VAR_INIT) Rte_VehStatus_In_V_m_RelativeDistanceYleft1_V_m_RelativeDistanceYleft1; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(sint16_NP, RTE_VAR_INIT) Rte_VehStatus_In_V_m_RelativeDistanceYleft2_V_m_RelativeDistanceYleft2; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(sint16_NP, RTE_VAR_INIT) Rte_VehStatus_In_V_m_RelativeDistanceYleft3_V_m_RelativeDistanceYleft3; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(sint16_NP, RTE_VAR_INIT) Rte_VehStatus_In_V_m_RelativeDistanceYleft4_V_m_RelativeDistanceYleft4; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(sint16_NP, RTE_VAR_INIT) Rte_VehStatus_In_V_m_RelativeDistanceYright1_V_m_RelativeDistanceYright1; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(sint16_NP, RTE_VAR_INIT) Rte_VehStatus_In_V_m_RelativeDistanceYright2_V_m_RelativeDistanceYright2; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(sint16_NP, RTE_VAR_INIT) Rte_VehStatus_In_V_m_RelativeDistanceYright3_V_m_RelativeDistanceYright3; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(sint16_NP, RTE_VAR_INIT) Rte_VehStatus_In_V_m_RelativeDistanceYright4_V_m_RelativeDistanceYright4; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_VehStatus_In_V_m_RightLineOffset_VSi_V_m_RightLineOffset_VSi; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_VehStatus_In_V_m_RightLineViewRange_VSi_V_m_RightLineViewRange_VSi; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt32, RTE_VAR_INIT) Rte_VehStatus_In_V_mps2_BPF_VSP_V_mps2_BPF_VSP; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(float32_NP, RTE_VAR_INIT) Rte_VehStatus_In_V_mps2_GSensOffsettedVal_V_mps2_GSensOffsettedVal; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt32, RTE_VAR_INIT) Rte_VehStatus_In_V_mps2_RUN_RESIST_V_mps2_RUN_RESIST; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt32, RTE_VAR_INIT) Rte_VehStatus_In_V_mps_AVE_FVSP_V_mps_AVE_FVSP; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt32, RTE_VAR_INIT) Rte_VehStatus_In_V_mps_AVE_RVSP_V_mps_AVE_RVSP; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt32, RTE_VAR_INIT) Rte_VehStatus_In_V_mps_AVE_VSP_V_mps_AVE_VSP; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt32, RTE_VAR_INIT) Rte_VehStatus_In_V_mps_FVSP_LPF_V_mps_FVSP_LPF; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt32, RTE_VAR_INIT) Rte_VehStatus_In_V_mps_RVSP_LPF_V_mps_RVSP_LPF; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(sint16_NP, RTE_VAR_INIT) Rte_VehStatus_In_V_mps_RelativeSpeedXleft1_V_mps_RelativeSpeedXleft1; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(sint16_NP, RTE_VAR_INIT) Rte_VehStatus_In_V_mps_RelativeSpeedXleft2_V_mps_RelativeSpeedXleft2; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(sint16_NP, RTE_VAR_INIT) Rte_VehStatus_In_V_mps_RelativeSpeedXleft3_V_mps_RelativeSpeedXleft3; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(sint16_NP, RTE_VAR_INIT) Rte_VehStatus_In_V_mps_RelativeSpeedXleft4_V_mps_RelativeSpeedXleft4; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(sint16_NP, RTE_VAR_INIT) Rte_VehStatus_In_V_mps_RelativeSpeedXright1_V_mps_RelativeSpeedXright1; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(sint16_NP, RTE_VAR_INIT) Rte_VehStatus_In_V_mps_RelativeSpeedXright2_V_mps_RelativeSpeedXright2; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(sint16_NP, RTE_VAR_INIT) Rte_VehStatus_In_V_mps_RelativeSpeedXright3_V_mps_RelativeSpeedXright3; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(sint16_NP, RTE_VAR_INIT) Rte_VehStatus_In_V_mps_RelativeSpeedXright4_V_mps_RelativeSpeedXright4; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(sint16_NP, RTE_VAR_INIT) Rte_VehStatus_In_V_mps_RelativeSpeedYleft1_V_mps_RelativeSpeedYleft1; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(sint16_NP, RTE_VAR_INIT) Rte_VehStatus_In_V_mps_RelativeSpeedYleft2_V_mps_RelativeSpeedYleft2; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(sint16_NP, RTE_VAR_INIT) Rte_VehStatus_In_V_mps_RelativeSpeedYleft3_V_mps_RelativeSpeedYleft3; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(sint16_NP, RTE_VAR_INIT) Rte_VehStatus_In_V_mps_RelativeSpeedYleft4_V_mps_RelativeSpeedYleft4; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(sint16_NP, RTE_VAR_INIT) Rte_VehStatus_In_V_mps_RelativeSpeedYright1_V_mps_RelativeSpeedYright1; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(sint16_NP, RTE_VAR_INIT) Rte_VehStatus_In_V_mps_RelativeSpeedYright2_V_mps_RelativeSpeedYright2; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(sint16_NP, RTE_VAR_INIT) Rte_VehStatus_In_V_mps_RelativeSpeedYright3_V_mps_RelativeSpeedYright3; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(sint16_NP, RTE_VAR_INIT) Rte_VehStatus_In_V_mps_RelativeSpeedYright4_V_mps_RelativeSpeedYright4; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt32, RTE_VAR_INIT) Rte_VehStatus_In_V_mps_VC_VSP_AT_V_mps_VC_VSP_AT; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt32, RTE_VAR_INIT) Rte_VehStatus_In_V_mps_VSP_4WHI_V_mps_VSP_4WHI; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(sint32_NP, RTE_VAR_INIT) Rte_VehStatus_In_V_mps_VSP_LPF_V_mps_VSP_LPF; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_VehStatus_In_V_nm_ENGTorque_LIM_MAX_V_nm_ENGTorque_LIM_MAX; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Float, RTE_VAR_INIT) Rte_VehStatus_In_V_nm_EstimatedPWTWheelTorque_Est_V_nm_EstimatedPWTWheelTorque_Est; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Float, RTE_VAR_INIT) Rte_VehStatus_In_V_nm_PWTWheelTorqueMaxCurrent_Est_V_nm_PWTWheelTorqueMaxCurrent_Est; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Float, RTE_VAR_INIT) Rte_VehStatus_In_V_nm_PWTWheelTorqueMaxGlobal_Est_V_nm_PWTWheelTorqueMaxGlobal_Est; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Float, RTE_VAR_INIT) Rte_VehStatus_In_V_nm_PWTWheelTorqueMin_Est_V_nm_PWTWheelTorqueMin_Est; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt32, RTE_VAR_INIT) Rte_VehStatus_In_V_pct_APO_RAW_V_pct_APO_RAW; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_VehStatus_In_V_pct_APS_ANGL_V_pct_APS_ANGL; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt32, RTE_VAR_INIT) Rte_VehStatus_In_V_pct_MB_GEAR_RATIO_V_pct_MB_GEAR_RATIO; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_VehStatus_In_V_pct_PowerTrainSetPoint_V_pct_PowerTrainSetPoint; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_VehStatus_In_V_pct_RawSensor_V_pct_RawSensor; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_VehStatus_In_V_pm_LeftLineCurv_VSi_V_pm_LeftLineCurv_VSi; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_VehStatus_In_V_pm_RightLineCurv_VSi_V_pm_RightLineCurv_VSi; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_VehStatus_In_V_rpm_EngineRPM_V_rpm_EngineRPM; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_VehStatus_In_V_rpm_InputShaftRev_V_rpm_InputShaftRev; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_VehStatus_In_V_rpm_OutputShaftRev_V_rpm_OutputShaftRev; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_VehStatus_In_V_rpm_REV_TRN_V_rpm_REV_TRN; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt32, RTE_VAR_INIT) Rte_VehStatus_In_V_rpm_TACHO_LPF_V_rpm_TACHO_LPF; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_VehStatus_In_V_rpm_WheelSpeed_F_L_V_rpm_WheelSpeed_F_L; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_VehStatus_In_V_rpm_WheelSpeed_F_R_V_rpm_WheelSpeed_F_R; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_VehStatus_In_V_rpm_WheelSpeed_R_L_V_rpm_WheelSpeed_R_L; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_VehStatus_In_V_rpm_WheelSpeed_R_R_V_rpm_WheelSpeed_R_R; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_VehStatus_In_V_rpm_WrFl_V_rpm_WrFl; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_VehStatus_In_V_rpm_WrFr_V_rpm_WrFr; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_VehStatus_In_V_rpm_WrRl_V_rpm_WrRl; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_VehStatus_In_V_rpm_WrRr_V_rpm_WrRr; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_VehStatus_In_V_x_ABS_LAMP_V_x_ABS_LAMP; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_VehStatus_In_V_x_ADAS_CameraRecordingStatus_V_x_ADAS_CameraRecordingStatus; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_VehStatus_In_V_x_ADAS_VehicleDrivingStatus_V_x_ADAS_VehicleDrivingStatus; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_VehStatus_In_V_x_ADAS_YawPerformanceStatus_V_x_ADAS_YawPerformanceStatus; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_VehStatus_In_V_x_AccEngPfmcSts_V_x_AccEngPfmcSts; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_VehStatus_In_V_x_Airbag_CrshOrd_V_x_Airbag_CrshOrd; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_VehStatus_In_V_x_AlertConditionLeft1_V_x_AlertConditionLeft1; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_VehStatus_In_V_x_AlertConditionLeft2_V_x_AlertConditionLeft2; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_VehStatus_In_V_x_AlertConditionLeft3_V_x_AlertConditionLeft3; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_VehStatus_In_V_x_AlertConditionLeft4_V_x_AlertConditionLeft4; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_VehStatus_In_V_x_AlertConditionRight1_V_x_AlertConditionRight1; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_VehStatus_In_V_x_AlertConditionRight2_V_x_AlertConditionRight2; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_VehStatus_In_V_x_AlertConditionRight3_V_x_AlertConditionRight3; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_VehStatus_In_V_x_AlertConditionRight4_V_x_AlertConditionRight4; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_VehStatus_In_V_x_BSWrad_SoundAlert_V_x_BSWrad_SoundAlert; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_VehStatus_In_V_x_BrakeInfoSta_V_x_BrakeInfoSta; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_VehStatus_In_V_x_BrakeInfoStatus_V_x_BrakeInfoStatus; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt32, RTE_VAR_INIT) Rte_VehStatus_In_V_x_CURGP_CAL_V_x_CURGP_CAL; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_VehStatus_In_V_x_CamFailsafe_V_x_CamFailsafe; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_VehStatus_In_V_x_ClutchSwMaxTrvl_V_x_ClutchSwMaxTrvl; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_VehStatus_In_V_x_CountryCodeFromNAVI_V_x_CountryCodeFromNAVI; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_VehStatus_In_V_x_CrsCtrlStsDisp_V_x_CrsCtrlStsDisp; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_VehStatus_In_V_x_CruiseEcoActivationRequest_V_x_CruiseEcoActivationRequest; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_VehStatus_In_V_x_CurEffSpdLmt_V_x_CurEffSpdLmt; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_VehStatus_In_V_x_CurrentGearSHIFT_V_x_CurrentGearSHIFT; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt32, RTE_VAR_INIT) Rte_VehStatus_In_V_x_CurrentGear_GP_FIX_V_x_CurrentGear_GP_FIX; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_VehStatus_In_V_x_DayNightForBacklights_V_x_DayNightForBacklights; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_VehStatus_In_V_x_DayTimeInd_VSi_V_x_DayTimeInd_VSi; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_VehStatus_In_V_x_DrDoorSta_V_x_DrDoorSta; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_VehStatus_In_V_x_DriveModeRequest_V_x_DriveModeRequest; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_VehStatus_In_V_x_DriverDoorState_V_x_DriverDoorState; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_VehStatus_In_V_x_EPB_MalfunctionDisplay_V_x_EPB_MalfunctionDisplay; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_VehStatus_In_V_x_EPB_STAT_V_x_EPB_STAT; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_VehStatus_In_V_x_EPS_Controlled_by_HFP_V_x_EPS_Controlled_by_HFP; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_VehStatus_In_V_x_EPS_ReadyForHFP_V_x_EPS_ReadyForHFP; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_VehStatus_In_V_x_EPS_Status_V_x_EPS_Status; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_VehStatus_In_V_x_ExistanceProbabilityObject00_V_x_ExistanceProbabilityObject00; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_VehStatus_In_V_x_ExistanceProbabilityObject01_V_x_ExistanceProbabilityObject01; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_VehStatus_In_V_x_ExistanceProbabilityObject02_V_x_ExistanceProbabilityObject02; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_VehStatus_In_V_x_ExistanceProbabilityObject03_V_x_ExistanceProbabilityObject03; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_VehStatus_In_V_x_FS_BlurImgLevel_VSi_V_x_FS_BlurImgLevel_VSi; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_VehStatus_In_V_x_FS_FogSpotLevel_VSi_V_x_FS_FogSpotLevel_VSi; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_VehStatus_In_V_x_FS_FrosWinShieldLevel_VSi_V_x_FS_FrosWinShieldLevel_VSi; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_VehStatus_In_V_x_FS_FullBlockLevel_VSi_V_x_FS_FullBlockLevel_VSi; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_VehStatus_In_V_x_FS_LowSunLevel_VSi_V_x_FS_LowSunLevel_VSi; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_VehStatus_In_V_x_FS_PartialBlockLevel_VSi_V_x_FS_PartialBlockLevel_VSi; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_VehStatus_In_V_x_FS_RoadSplayLevel_VSi_V_x_FS_RoadSplayLevel_VSi; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_VehStatus_In_V_x_FS_SelfGlareLevel_VSi_V_x_FS_SelfGlareLevel_VSi; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_VehStatus_In_V_x_FS_SmearSpotLevel_VSi_V_x_FS_SmearSpotLevel_VSi; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_VehStatus_In_V_x_FS_SunRayLevel_VSi_V_x_FS_SunRayLevel_VSi; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_VehStatus_In_V_x_FlashingIndicatorCommandPosition_V_x_FlashingIndicatorCommandPosition; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_VehStatus_In_V_x_FrWipReq_V_x_FrWipReq; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_VehStatus_In_V_x_HFP_AngleRequestValid_V_x_HFP_AngleRequestValid; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_VehStatus_In_V_x_HFP_DriverHandsOnWheel2_V_x_HFP_DriverHandsOnWheel2; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_VehStatus_In_V_x_InhiNSw_V_x_InhiNSw; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_VehStatus_In_V_x_LDP_ActivationRequest_V_x_LDP_ActivationRequest; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_VehStatus_In_V_x_LDP_CameraCancelReason_V_x_LDP_CameraCancelReason; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_VehStatus_In_V_x_LDP_StatusDisplay_V_x_LDP_StatusDisplay; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_VehStatus_In_V_x_LDW_ActivationRequest_V_x_LDW_ActivationRequest; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_VehStatus_In_V_x_LDW_ActivationState_v3_V_x_LDW_ActivationState_v3; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_VehStatus_In_V_x_LDW_AlertStatus_V_x_LDW_AlertStatus; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_VehStatus_In_V_x_LDW_CameraCancelReason_V_x_LDW_CameraCancelReason; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_VehStatus_In_V_x_LDW_SoundAlert_V_x_LDW_SoundAlert; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_VehStatus_In_V_x_LDW_SoundType_V_x_LDW_SoundType; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_VehStatus_In_V_x_LeftBoundType_VSi_V_x_LeftBoundType_VSi; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_VehStatus_In_V_x_LeftLineConfidence_VSi_V_x_LeftLineConfidence_VSi; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_VehStatus_In_V_x_LostReasonObject00_V_x_LostReasonObject00; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_VehStatus_In_V_x_LostReasonObject01_V_x_LostReasonObject01; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_VehStatus_In_V_x_LostReasonObject02_V_x_LostReasonObject02; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_VehStatus_In_V_x_LostReasonObject03_V_x_LostReasonObject03; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_VehStatus_In_V_x_NOISE_FR_V_x_NOISE_FR; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_VehStatus_In_V_x_NOISE_RE_V_x_NOISE_RE; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_VehStatus_In_V_x_ParkingBrakeStatus_V_x_ParkingBrakeStatus; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_VehStatus_In_V_x_PassengerDoorState_V_x_PassengerDoorState; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_VehStatus_In_V_x_PedalError_V_x_PedalError; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_VehStatus_In_V_x_RAB_ActivationRequest_V_x_RAB_ActivationRequest; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt32, RTE_VAR_INIT) Rte_VehStatus_In_V_x_RATIO0_V_x_RATIO0; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_VehStatus_In_V_x_RangeIndication_V_x_RangeIndication; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_VehStatus_In_V_x_RearGearEngaged_V_x_RearGearEngaged; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_VehStatus_In_V_x_RearLeftDoorState_V_x_RearLeftDoorState; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_VehStatus_In_V_x_RearRightDoorState_V_x_RearRightDoorState; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_VehStatus_In_V_x_RevSW_V_x_RevSW; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_VehStatus_In_V_x_RightBoundType_VSi_V_x_RightBoundType_VSi; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_VehStatus_In_V_x_RightLineConfidence_VSi_V_x_RightLineConfidence_VSi; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_VehStatus_In_V_x_SIZE_FIL_V_x_SIZE_FIL; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_VehStatus_In_V_x_SIZE_FILIR_V_x_SIZE_FILIR; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_VehStatus_In_V_x_SIZE_FIR_V_x_SIZE_FIR; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_VehStatus_In_V_x_SIZE_FIRIL_V_x_SIZE_FIRIL; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_VehStatus_In_V_x_SIZE_FIROR_V_x_SIZE_FIROR; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_VehStatus_In_V_x_SIZE_FMLOL_V_x_SIZE_FMLOL; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_VehStatus_In_V_x_SIZE_FOL_V_x_SIZE_FOL; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_VehStatus_In_V_x_SIZE_FOLIL_V_x_SIZE_FOLIL; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_VehStatus_In_V_x_SIZE_FOR_V_x_SIZE_FOR; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_VehStatus_In_V_x_SIZE_FORIR_V_x_SIZE_FORIR; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_VehStatus_In_V_x_SIZE_RML_V_x_SIZE_RML; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_VehStatus_In_V_x_SIZE_RMLMR_V_x_SIZE_RMLMR; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_VehStatus_In_V_x_SIZE_RMLOL_V_x_SIZE_RMLOL; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_VehStatus_In_V_x_SIZE_RMR_V_x_SIZE_RMR; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_VehStatus_In_V_x_SIZE_RMRML_V_x_SIZE_RMRML; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_VehStatus_In_V_x_SIZE_RMROR_V_x_SIZE_RMROR; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_VehStatus_In_V_x_SIZE_ROL_V_x_SIZE_ROL; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_VehStatus_In_V_x_SIZE_ROLML_V_x_SIZE_ROLML; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_VehStatus_In_V_x_SIZE_ROR_V_x_SIZE_ROR; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_VehStatus_In_V_x_SIZE_RORMR_V_x_SIZE_RORMR; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_VehStatus_In_V_x_SSA_HOLDSTAT_V_x_SSA_HOLDSTAT; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_VehStatus_In_V_x_SideRadarLeft_AlertStatus_V_x_SideRadarLeft_AlertStatus; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_VehStatus_In_V_x_SideRadarRight_AlertStatus_V_x_SideRadarRight_AlertStatus; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_VehStatus_In_V_x_StatChgReq_V_x_StatChgReq; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_VehStatus_In_V_x_StpAutPhs_V_x_StpAutPhs; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_VehStatus_In_V_x_TEMP_NOISE_FR_V_x_TEMP_NOISE_FR; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_VehStatus_In_V_x_TEMP_NOISE_RE_V_x_TEMP_NOISE_RE; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_VehStatus_In_V_x_TransmRangeEngaged_Current_V_x_TransmRangeEngaged_Current; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_VehStatus_In_V_x_TransmRangeEngaged_Target_V_x_TransmRangeEngaged_Target; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_VehStatus_In_V_x_TurnInd_V_x_TurnInd; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_VehStatus_In_V_x_WDA_ActivationRequest_V_x_WDA_ActivationRequest; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_VehStatus_In_V_x_WheelTopRL_V_x_WheelTopRL; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_VehStatus_In_V_x_WheelTopRR_V_x_WheelTopRR; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_VehStatus_Out_F_x_ACC_BrakeWheelTorqueOrder_F_x_ACC_BrakeWheelTorqueOrder; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_VehStatus_Out_F_x_ACC_BrakeWheelTorqueOrder_NiSW_F_x_ACC_BrakeWheelTorqueOrder_NiSW; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_VehStatus_Out_F_x_ACC_BusyShiftLimitRequest_0x4FC_F_x_ACC_BusyShiftLimitRequest_0x4FC; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_VehStatus_Out_F_x_ACC_DistanceOverrideDisplay_TJP_F_x_ACC_DistanceOverrideDisplay_TJP; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_VehStatus_Out_F_x_ACC_LCA_CancelReasonRER_0x60D_F_x_ACC_LCA_CancelReasonRER_0x60D; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_VehStatus_Out_F_x_ACC_LCA_CancelReasonRER_v2_0x4FC_F_x_ACC_LCA_CancelReasonRER_v2_0x4FC; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_VehStatus_Out_F_x_ACC_PWTWheelTorqueRequestOrder_F_x_ACC_PWTWheelTorqueRequestOrder; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_VehStatus_Out_F_x_ACC_SpeedOverrideDisplay_TJP_F_x_ACC_SpeedOverrideDisplay_TJP; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(boolean_NP, RTE_VAR_INIT) Rte_VehStatus_Out_F_x_ACC_StandStillRequest_0x0B2_F_x_ACC_StandStillRequest_0x0B2; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_VehStatus_Out_F_x_ADAS_BSWalertInhibitionRequest_0x4C3_F_x_ADAS_BSWalertInhibitionRequest_0x4C3; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_VehStatus_Out_F_x_ADAS_CTAinhibitionRequest_0x4C3_F_x_ADAS_CTAinhibitionRequest_0x4C3; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_VehStatus_Out_F_x_ADAS_EDRflashingOrder_0x5C7_F_x_ADAS_EDRflashingOrder_0x5C7; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_VehStatus_Out_F_x_ADAS_Failure_0x2D2_F_x_ADAS_Failure_0x2D2; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_VehStatus_Out_F_x_ADAS_LDWalertInhibitionRequest_0x4FC_F_x_ADAS_LDWalertInhibitionRequest_0x4FC; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_VehStatus_Out_F_x_ADAS_YawMomentOrder_0x0B2_F_x_ADAS_YawMomentOrder_0x0B2; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_VehStatus_Out_F_x_AEB_CyclistAlertRequest2_0x5C7_F_x_AEB_CyclistAlertRequest2_0x5C7; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_VehStatus_Out_F_x_AEB_InhibitionRequest2_0x5C7_F_x_AEB_InhibitionRequest2_0x5C7; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_VehStatus_Out_F_x_AEB_PWTwheelTorqueOrder_0x0B2_F_x_AEB_PWTwheelTorqueOrder_0x0B2; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_VehStatus_Out_F_x_AEB_PedestrianAlertRequest2_0x5C7_F_x_AEB_PedestrianAlertRequest2_0x5C7; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_VehStatus_Out_F_x_AEB_PermanentFailureDisplayReq2_0x5C7_F_x_AEB_PermanentFailureDisplayReq2_0x5C7; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_VehStatus_Out_F_x_ASC_InhibitRequest_0x4FC_F_x_ASC_InhibitRequest_0x4FC; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_VehStatus_Out_F_x_AssistanceFunctionStatusDisplay_0x60D_F_x_AssistanceFunctionStatusDisplay_0x60D; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_VehStatus_Out_F_x_BCI_ActivationState_0x4FC_F_x_BCI_ActivationState_0x4FC; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_VehStatus_Out_F_x_BCI_AlertStatus_v2_0x611_F_x_BCI_AlertStatus_v2_0x611; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_VehStatus_Out_F_x_BCI_OffdisplayRequest_0x611_F_x_BCI_OffdisplayRequest_0x611; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_VehStatus_Out_F_x_BCI_PWTwheelTorqueOrder_0x0B2_F_x_BCI_PWTwheelTorqueOrder_0x0B2; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_VehStatus_Out_F_x_BCI_SoundAlert_0x611_F_x_BCI_SoundAlert_0x611; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_VehStatus_Out_F_x_BSI_ActivationState_0x4FC_F_x_BSI_ActivationState_0x4FC; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_VehStatus_Out_F_x_BSI_CancelReasonRER_0x611_F_x_BSI_CancelReasonRER_0x611; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_VehStatus_Out_F_x_BSI_SideDisplayInfo_0x4C3_F_x_BSI_SideDisplayInfo_0x4C3; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_VehStatus_Out_F_x_BSI_StatusInfo_0x4C3_F_x_BSI_StatusInfo_0x4C3; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_VehStatus_Out_F_x_ControlModeChangeRequest_0x0B1_F_x_ControlModeChangeRequest_0x0B1; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_VehStatus_Out_F_x_EAP_ActivationState_0x4FC_F_x_EAP_ActivationState_0x4FC; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_VehStatus_Out_F_x_EAP_AlertDisplay_0x611_F_x_EAP_AlertDisplay_0x611; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_VehStatus_Out_F_x_EAP_PWTWheelTorqueOrder_0x0B2_F_x_EAP_PWTWheelTorqueOrder_0x0B2; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_VehStatus_Out_F_x_EAP_SoundInhibitionRequest_0x4FC_F_x_EAP_SoundInhibitionRequest_0x4FC; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_VehStatus_Out_F_x_FixedObjectDetection_0x4FC_F_x_FixedObjectDetection_0x4FC; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_VehStatus_Out_F_x_HBAThresholdRequest2_0x09F_F_x_HBAThresholdRequest2_0x09F; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_VehStatus_Out_F_x_HFPB_BrakeWheelTorqueOrder2_0x2D1_F_x_HFPB_BrakeWheelTorqueOrder2_0x2D1; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_VehStatus_Out_F_x_HFPB_StandStillRequest2_0x2D1_F_x_HFPB_StandStillRequest2_0x2D1; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_VehStatus_Out_F_x_HydraulicPreFillRequest2_0x09F_F_x_HydraulicPreFillRequest2_0x09F; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_VehStatus_Out_F_x_LCA_ActivationState_TJP_F_x_LCA_ActivationState_TJP; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_VehStatus_Out_F_x_LCA_LineCrossingAlertInfo_0x611_F_x_LCA_LineCrossingAlertInfo_0x611; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_VehStatus_Out_F_x_LCA_OverrideDisplay_TJP_F_x_LCA_OverrideDisplay_TJP; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_VehStatus_Out_F_x_LCA_SoundAlert_TJP_F_x_LCA_SoundAlert_TJP; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_VehStatus_Out_F_x_LCA_SteeringAngleOrder_0x0B1_F_x_LCA_SteeringAngleOrder_0x0B1; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_VehStatus_Out_F_x_LDP_ActivationState_0x4FC_F_x_LDP_ActivationState_0x4FC; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_VehStatus_Out_F_x_LDP_CancelReasonRER_0x611_F_x_LDP_CancelReasonRER_0x611; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_VehStatus_Out_F_x_LDP_SoundAlertInfo_0x611_F_x_LDP_SoundAlertInfo_0x611; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_VehStatus_Out_F_x_LDP_StatusInfo_0x4FC_F_x_LDP_StatusInfo_0x4FC; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_VehStatus_Out_F_x_LKA_InhibitionRequestedbyLCA_0x4FC_F_x_LKA_InhibitionRequestedbyLCA_0x4FC; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_VehStatus_Out_F_x_NoEntry_ActivationState_0x60D_F_x_NoEntry_ActivationState_0x60D; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_VehStatus_Out_F_x_NoEntry_AlertDisplay_0x60D_F_x_NoEntry_AlertDisplay_0x60D; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_VehStatus_Out_F_x_NoEntry_SoundAlert_0x60D_F_x_NoEntry_SoundAlert_0x60D; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_VehStatus_Out_F_x_ObjectDetectionFailure_0x4FC_F_x_ObjectDetectionFailure_0x4FC; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_VehStatus_Out_F_x_PrecedingVehicleDetection_0x4FC_F_x_PrecedingVehicleDetection_0x4FC; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_VehStatus_Out_F_x_ProPILOTtransitionRequest_0x60D_F_x_ProPILOTtransitionRequest_0x60D; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_VehStatus_Out_F_x_RAB_ActivationState_0x611_F_x_RAB_ActivationState_0x611; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_VehStatus_Out_F_x_SideRadarModeRequest_0x2D2_F_x_SideRadarModeRequest_0x2D2; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_VehStatus_Out_F_x_WDA_ActivationState_0x611_F_x_WDA_ActivationState_0x611; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_VehStatus_Out_F_x_WDA_WarningDriverAttention_0x611_F_x_WDA_WarningDriverAttention_0x611; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_VehStatus_Out_V_Nm_ACC_BrakeWheelTorqueRequestRaw_V_Nm_ACC_BrakeWheelTorqueRequestRaw; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_VehStatus_Out_V_Nm_ADAS_PWTwheelTorqueRequest_0x0B2_V_Nm_ADAS_PWTwheelTorqueRequest_0x0B2; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_VehStatus_Out_V_Nm_ADAS_YawMomentRequest_0x0B2_V_Nm_ADAS_YawMomentRequest_0x0B2; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_VehStatus_Out_V_Nm_AEB_BrakeWheelTorqueRequest2_0x09F_V_Nm_AEB_BrakeWheelTorqueRequest2_0x09F; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_VehStatus_Out_V_Nm_HFPB_BrakeWheelTorqueRequest2_0x2D1_V_Nm_HFPB_BrakeWheelTorqueRequest2_0x2D1; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_VehStatus_Out_V_Nm_HFPB_BrakeWheelTorqueRequestRaw2_0x2D1_V_Nm_HFPB_BrakeWheelTorqueRequestRaw2_0x2D1; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_VehStatus_Out_V_Nm_VelocityServoDisturbance_0x2D2_V_Nm_VelocityServoDisturbance_0x2D2; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_VehStatus_Out_V_Nm_WheelTorqueLimitationRequest2_0x2D1_V_Nm_WheelTorqueLimitationRequest2_0x2D1; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_VehStatus_Out_V_deg_HFP_SWA_Request2_v2_0x2DD_V_deg_HFP_SWA_Request2_v2_0x2DD; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt32, RTE_VAR_INIT) Rte_VehStatus_Out_V_deg_LCA_SteeringAngleRequest_0x0B1_V_deg_LCA_SteeringAngleRequest_0x0B1; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_VehStatus_Out_V_m_DistanceToPrecedingVehicle_0x4FC_V_m_DistanceToPrecedingVehicle_0x4FC; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt16, RTE_VAR_INIT) Rte_VehStatus_Out_V_nm_ACC_BrakeWheelTorqueRequest_V_nm_ACC_BrakeWheelTorqueRequest; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_VehStatus_Out_V_nm_ACC_PWTWheelTorqueRequest_V_nm_ACC_PWTWheelTorqueRequest; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_VehStatus_Out_V_pct_PowerTrainSetPointLimitation_0x0B2_V_pct_PowerTrainSetPointLimitation_0x0B2; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_VehStatus_Out_V_x_ACC_CruiseEcoActivationState_0x4FC_V_x_ACC_CruiseEcoActivationState_0x4FC; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_VehStatus_Out_V_x_ACC_DistanceSettingDisplay_TJP_V_x_ACC_DistanceSettingDisplay_TJP; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_VehStatus_Out_V_x_ACC_DynTargetDistanceDisplay_TJP_V_x_ACC_DynTargetDistanceDisplay_TJP; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_VehStatus_Out_V_x_ACC_EngineStopAutoOrder_V_x_ACC_EngineStopAutoOrder; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_VehStatus_Out_V_x_ACC_FailureDisplay_TJP_V_x_ACC_FailureDisplay_TJP; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_VehStatus_Out_V_x_ACC_LCA_CancelReason_0x60D_V_x_ACC_LCA_CancelReason_0x60D; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_VehStatus_Out_V_x_ACC_LCA_CancelReason_TJP_V_x_ACC_LCA_CancelReason_TJP; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_VehStatus_Out_V_x_ACC_LCA_DeactivationType_TJP_V_x_ACC_LCA_DeactivationType_TJP; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_VehStatus_Out_V_x_ACC_LCA_TransitionStateDisplay_TJP_V_x_ACC_LCA_TransitionStateDisplay_TJP; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_VehStatus_Out_V_x_ACC_RadarCancelReasonInfo_0x611_V_x_ACC_RadarCancelReasonInfo_0x611; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_VehStatus_Out_V_x_ACC_SpeedSettingDisplay_TJP_V_x_ACC_SpeedSettingDisplay_TJP; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_VehStatus_Out_V_x_ACC_Status_V_x_ACC_Status; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_VehStatus_Out_V_x_ACC_StatusDisplay_TJP_V_x_ACC_StatusDisplay_TJP; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_VehStatus_Out_V_x_ACC_Status_Slow_V_x_ACC_Status_Slow; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_VehStatus_Out_V_x_ACC_TargetDistanceAlert_TJP_V_x_ACC_TargetDistanceAlert_TJP; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_VehStatus_Out_V_x_ACC_TargetDistanceDisplay_TJP_V_x_ACC_TargetDistanceDisplay_TJP; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_VehStatus_Out_V_x_ADAS_EDRtriggerFlag_0x5C7_V_x_ADAS_EDRtriggerFlag_0x5C7; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_VehStatus_Out_V_x_ADAS_ModeDisplay_TJP_V_x_ADAS_ModeDisplay_TJP; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_VehStatus_Out_V_x_ADAS_VehicleDrivingStatus_0x4FC_V_x_ADAS_VehicleDrivingStatus_0x4FC; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Float, RTE_VAR_INIT) Rte_VehStatus_Out_V_x_ADAS_to_DTOOL_0x7C9_V_x_ADAS_to_DTOOL_0x7C9; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_VehStatus_Out_V_x_AEB_BrakeTorqueGain2_0x09F_V_x_AEB_BrakeTorqueGain2_0x09F; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_VehStatus_Out_V_x_AEB_BrakeTorqueGainOrder2_0x09F_V_x_AEB_BrakeTorqueGainOrder2_0x09F; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_VehStatus_Out_V_x_AEB_BrakeWheelTorqueOrder2_V_x_AEB_BrakeWheelTorqueOrder2; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_VehStatus_Out_V_x_AEB_BrakeWheelTorqueOrder2_0x09F_V_x_AEB_BrakeWheelTorqueOrder2_0x09F; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_VehStatus_Out_V_x_AEB_BrakeWheelTorqueOrder2_EDR_0x5C7_V_x_AEB_BrakeWheelTorqueOrder2_EDR_0x5C7; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_VehStatus_Out_V_x_AEB_CancelInfo_0x611_V_x_AEB_CancelInfo_0x611; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_VehStatus_Out_V_x_AEB_CancelReason2_0x611_V_x_AEB_CancelReason2_0x611; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_VehStatus_Out_V_x_AEB_FCWactivationState2_0x5C7_V_x_AEB_FCWactivationState2_0x5C7; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_VehStatus_Out_V_x_AEB_FailureDisplay2_0x5C7_V_x_AEB_FailureDisplay2_0x5C7; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_VehStatus_Out_V_x_AEB_SoundAlert_0x611_V_x_AEB_SoundAlert_0x611; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_VehStatus_Out_V_x_AEB_StatusDisplay2_0x5C7_V_x_AEB_StatusDisplay2_0x5C7; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_VehStatus_Out_V_x_AEB_TemporaryFailureDisplayReq2_0x5C7_V_x_AEB_TemporaryFailureDisplayReq2_0x5C7; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_VehStatus_Out_V_x_AEB_VehicleAlertRequest2_0x5C7_V_x_AEB_VehicleAlertRequest2_0x5C7; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_VehStatus_Out_V_x_BCI_CancelInfo_0x611_V_x_BCI_CancelInfo_0x611; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_VehStatus_Out_V_x_BCI_CancelReason_0x611_V_x_BCI_CancelReason_0x611; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_VehStatus_Out_V_x_BCI_FailureDisplay_0x611_V_x_BCI_FailureDisplay_0x611; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_VehStatus_Out_V_x_BSI_AlertLeft_v2_0x4C3_V_x_BSI_AlertLeft_v2_0x4C3; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_VehStatus_Out_V_x_BSI_AlertRight_v2_0x4C3_V_x_BSI_AlertRight_v2_0x4C3; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_VehStatus_Out_V_x_BSI_CancelInfo_0x4C3_V_x_BSI_CancelInfo_0x4C3; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_VehStatus_Out_V_x_BSI_CancelReason_0x611_V_x_BSI_CancelReason_0x611; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_VehStatus_Out_V_x_BSI_FailureDisplay_0x611_V_x_BSI_FailureDisplay_0x611; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_VehStatus_Out_V_x_DriverGuideDisplay_TJP_V_x_DriverGuideDisplay_TJP; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_VehStatus_Out_V_x_EAP_FailureDisplay_0x611_V_x_EAP_FailureDisplay_0x611; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_VehStatus_Out_V_x_EAP_SoundAlertRequest_0x4FC_V_x_EAP_SoundAlertRequest_0x4FC; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_VehStatus_Out_V_x_FAP_ControlStatus_0x2D2_V_x_FAP_ControlStatus_0x2D2; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_VehStatus_Out_V_x_FAP_GearShiftRequest_0x0B2_V_x_FAP_GearShiftRequest_0x0B2; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Float, RTE_VAR_INIT) Rte_VehStatus_Out_V_x_FTOOLS_ADAStoCGW_0x1BDEF224_V_x_FTOOLS_ADAStoCGW_0x1BDEF224; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_VehStatus_Out_V_x_HFPB_Status2_0x2D1_V_x_HFPB_Status2_0x2D1; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_VehStatus_Out_V_x_HFP_SteeringControlRequest2_0x2DD_V_x_HFP_SteeringControlRequest2_0x2DD; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_VehStatus_Out_V_x_HFP_StopAutoForbidden2_0x2DD_V_x_HFP_StopAutoForbidden2_0x2DD; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_VehStatus_Out_V_x_HighGearInhibitRequest_0x0A0_V_x_HighGearInhibitRequest_0x0A0; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_VehStatus_Out_V_x_LCA_ActivationStateForLKA_0x4FC_V_x_LCA_ActivationStateForLKA_0x4FC; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_VehStatus_Out_V_x_LCA_CameraCancelReasonInfo_0x611_V_x_LCA_CameraCancelReasonInfo_0x611; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_VehStatus_Out_V_x_LCA_FailureDisplay_TJP_V_x_LCA_FailureDisplay_TJP; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_VehStatus_Out_V_x_LCA_LaneInfo_TJP_V_x_LCA_LaneInfo_TJP; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_VehStatus_Out_V_x_LCA_LineCrossingAlert_0x611_V_x_LCA_LineCrossingAlert_0x611; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_VehStatus_Out_V_x_LCA_StatusDisplay_TJP_V_x_LCA_StatusDisplay_TJP; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_VehStatus_Out_V_x_LCA_SteeringGain_k1_0x0B1_V_x_LCA_SteeringGain_k1_0x0B1; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_VehStatus_Out_V_x_LCA_SteeringGain_k2_0x0B1_V_x_LCA_SteeringGain_k2_0x0B1; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_VehStatus_Out_V_x_LCA_SteeringWheelDisplay_TJP_V_x_LCA_SteeringWheelDisplay_TJP; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_VehStatus_Out_V_x_LCA_SteeringWheelTakeOverAlert_mirror_0x6CB_V_x_LCA_SteeringWheelTakeOverAlert_mirror_0x6CB; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_VehStatus_Out_V_x_LCA_SwheelTakeOverAlert_TJP_V_x_LCA_SwheelTakeOverAlert_TJP; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_VehStatus_Out_V_x_LDP_AlertStatusInfo_0x4FC_V_x_LDP_AlertStatusInfo_0x4FC; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_VehStatus_Out_V_x_LDP_CancelInfo_0x611_V_x_LDP_CancelInfo_0x611; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_VehStatus_Out_V_x_LDP_CancelReason_0x611_V_x_LDP_CancelReason_0x611; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_VehStatus_Out_V_x_LDP_FailureDisplay_0x611_V_x_LDP_FailureDisplay_0x611; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_VehStatus_Out_V_x_LDP_LaneInfo_0x4FC_V_x_LDP_LaneInfo_0x4FC; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_VehStatus_Out_V_x_PrecedingVehicleChangeCounter_0x4FC_V_x_PrecedingVehicleChangeCounter_0x4FC; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_VehStatus_Out_V_x_RAB_AlertStatus_0x611_V_x_RAB_AlertStatus_0x611; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_VehStatus_Out_V_x_RAB_CancelReason_0x611_V_x_RAB_CancelReason_0x611; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_VehStatus_Out_V_x_RAB_FailureDisplay_0x611_V_x_RAB_FailureDisplay_0x611; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_VehStatus_Out_V_x_RAB_SonarCancelReason_0x611_V_x_RAB_SonarCancelReason_0x611; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_VehStatus_Out_V_x_RAB_StatusDisplay_0x611_V_x_RAB_StatusDisplay_0x611; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt32, RTE_VAR_INIT) Rte_VehStatus_Out_V_x_SIGMA_ADAS_0x18CC077D_V_x_SIGMA_ADAS_0x18CC077D; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt32, RTE_VAR_INIT) Rte_VehStatus_Out_V_x_SIGMA_DTCADAS_0x18CC077D_V_x_SIGMA_DTCADAS_0x18CC077D; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_VehStatus_Out_V_x_WDA_DriverAttentionLevel_0x611_V_x_WDA_DriverAttentionLevel_0x611; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_VehStatus_Out_V_x_WheelTorqueLimitationOrder2_0x2D1_V_x_WheelTorqueLimitationOrder2_0x2D1; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(boolean_NP, RTE_VAR_INIT) Rte_YAW_F_x_FS_Hndsoff_Thrsh_Incmp_F_x_FS_Hndsoff_Thrsh_Incmp; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(boolean_NP, RTE_VAR_INIT) Rte_YAW_F_x_HODJudgeActiveFricCalib_F_x_HODJudgeActiveFricCalib; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(Boolean, RTE_VAR_INIT) Rte_YAW_F_x_LCA_SteeringAngleOrder_F_x_LCA_SteeringAngleOrder; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(boolean_NP, RTE_VAR_INIT) Rte_YAW_F_x_SigSetActTst_F_x_SigSetActTst; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(boolean_NP, RTE_VAR_INIT) Rte_YAW_F_x_StrTrqCalibDispActive_F_x_StrTrqCalibDispActive; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(boolean_NP, RTE_VAR_INIT) Rte_YAW_F_x_WriteTrqDiffLatestToLat_F_x_WriteTrqDiffLatestToLat; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(boolean_NP, RTE_VAR_INIT) Rte_YAW_F_x_YmcReq_F_x_YmcReq; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt16, RTE_VAR_INIT) Rte_YAW_V_Nm_ItsTrgtYaw_V_Nm_ItsTrgtYaw; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt32, RTE_VAR_INIT) Rte_YAW_V_Nm_mom_ls0prepm_SCP_LDP_V_Nm_mom_ls0prepm_SCP_LDP; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(SInt32, RTE_VAR_INIT) Rte_YAW_V_deg_LCA_SteeringAngleRequest_V_deg_LCA_SteeringAngleRequest; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_YAW_V_nm_DiffStrTrqMaxDispActTst_V_nm_DiffStrTrqMaxDispActTst; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint16_NP, RTE_VAR_INIT) Rte_YAW_V_nm_SetStrTrqDiffLatestEeprom_V_nm_SetStrTrqDiffLatestEeprom; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(float32_NP, RTE_VAR_INIT) Rte_YAW_V_nm_SetStrTrqDiffLatestToLat_V_nm_SetStrTrqDiffLatestToLat; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(UInt8, RTE_VAR_INIT) Rte_YAW_V_x_LCA_SteeringGain_k1_V_x_LCA_SteeringGain_k1; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_YAW_V_x_StrAsstStsActTst_V_x_StrAsstStsActTst; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_YAW_V_x_StrTrqCalibNGReason_V_x_StrTrqCalibNGReason; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_YAW_V_x_StrTrqCalibResult_V_x_StrTrqCalibResult; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */
extern VAR(uint8_NP, RTE_VAR_INIT) Rte_YAW_V_x_StrTrqCalibType_V_x_StrTrqCalibType; /* PRQA S 0850, 3408, 1504 */ /* MD_MSR_19.8, MD_Rte_3408, MD_MSR_8.10 */

#  define RTE_STOP_SEC_VAR_INIT_UNSPECIFIED
//#  include "MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */

typedef struct
{
  Rte_BitType Rte_ModeSwitchAck_Dcm_DcmEcuReset_DcmEcuReset_Ack : 1;
} Rte_OsApplication_AckFlagsType;

#  define RTE_START_SEC_VAR_INIT_UNSPECIFIED
//#  include "MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */

extern VAR(Rte_OsApplication_AckFlagsType, RTE_VAR_INIT) Rte_OsApplication_AckFlags; /* PRQA S 0850 */ /* MD_MSR_19.8 */

#  define RTE_STOP_SEC_VAR_INIT_UNSPECIFIED
//#  include "MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */


/**********************************************************************************************************************
 * Internal C/S connections
 *********************************************************************************************************************/

/* Queue element type definitions for internal C/S connections */

typedef struct
{
  uint8 InstanceId; /* PRQA S 0850 */ /* MD_MSR_19.8 */
  uint8 ApiId; /* PRQA S 0850 */ /* MD_MSR_19.8 */
  uint8 ErrorId; /* PRQA S 0850 */ /* MD_MSR_19.8 */
  boolean Rte_ServerCompleted;
  TaskType Rte_TaskID;
  Std_ReturnType Rte_Result;
} Rte_CS_ServerQueueType_Det_DetServicePort_ReportError;

typedef struct
{
  uint8 Rte_Free;
  uint8 Rte_Active;
} Rte_CS_ServerQueueInfoType_Det_DetServicePort_ReportError;


typedef struct
{
  P2VAR(EcuM_BootTargetType, AUTOMATIC, RTE_ECUM_APPL_VAR) BootTarget; /* PRQA S 0850 */ /* MD_MSR_19.8 */
  boolean Rte_ServerCompleted;
  TaskType Rte_TaskID;
  Std_ReturnType Rte_Result;
} Rte_CS_ServerQueueType_EcuM_EcuM_BootTarget_GetBootTarget;

typedef struct
{
  uint8 Rte_Free;
  uint8 Rte_Active;
} Rte_CS_ServerQueueInfoType_EcuM_EcuM_BootTarget_GetBootTarget;

#  define RTE_START_SEC_VAR_NOINIT_UNSPECIFIED
//#  include "MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */

extern VAR(Rte_CS_ServerQueueType_Det_DetServicePort_ReportError, RTE_VAR_NOINIT) Rte_CS_ServerQueue_Det_DetServicePort_ReportError; /* PRQA S 0850, 3229 */ /* MD_MSR_19.8, MD_Rte_Qac */
extern VAR(Rte_CS_ServerQueueInfoType_Det_DetServicePort_ReportError, RTE_VAR_NOINIT) Rte_CS_ServerQueueInfo_Det_DetServicePort_ReportError; /* PRQA S 0850 */ /* MD_MSR_19.8 */

#  define RTE_STOP_SEC_VAR_NOINIT_UNSPECIFIED
//#  include "MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */

#  define RTE_START_SEC_VAR_NOINIT_UNSPECIFIED
//#  include "MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */

extern VAR(Rte_CS_ServerQueueType_EcuM_EcuM_BootTarget_GetBootTarget, RTE_VAR_NOINIT) Rte_CS_ServerQueue_EcuM_EcuM_BootTarget_GetBootTarget; /* PRQA S 0850, 3229 */ /* MD_MSR_19.8, MD_Rte_Qac */
extern VAR(Rte_CS_ServerQueueInfoType_EcuM_EcuM_BootTarget_GetBootTarget, RTE_VAR_NOINIT) Rte_CS_ServerQueueInfo_EcuM_EcuM_BootTarget_GetBootTarget; /* PRQA S 0850 */ /* MD_MSR_19.8 */

#  define RTE_STOP_SEC_VAR_NOINIT_UNSPECIFIED
//#  include "MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */



#  define RTE_START_SEC_CONST_UNSPECIFIED
//#  include "MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */

extern CONST(EventMaskType, RTE_CONST) Rte_ModeEntryEventMask_Dcm_DcmEcuReset_DcmEcuReset[7];

#  define RTE_STOP_SEC_CONST_UNSPECIFIED
//#  include "MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */

/**********************************************************************************************************************
 * Data structures for mode management
 *********************************************************************************************************************/


#  define RTE_START_SEC_VAR_INIT_UNSPECIFIED
//#  include "MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */

extern VAR(BswM_BswM_NvmErrorStatus, RTE_VAR_INIT) Rte_ModeMachine_BswM_Switch_BswMSwitchPort_NvM_ErrorStatus_BswM_MDGP_BswM_NvmErrorStatus; /* PRQA S 3408 */ /* MD_Rte_3408 */

#  define RTE_STOP_SEC_VAR_INIT_UNSPECIFIED
//#  include "MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */


#  define RTE_START_SEC_VAR_INIT_UNSPECIFIED
//#  include "MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */

extern VAR(BswM_MD_Service22OnOff, RTE_VAR_INIT) Rte_ModeMachine_BswM_Switch_BswMSwitchPort_Service22OnOff_BswM_MDGP_MD_Service22OnOff; /* PRQA S 3408 */ /* MD_Rte_3408 */

#  define RTE_STOP_SEC_VAR_INIT_UNSPECIFIED
//#  include "MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */


#  define RTE_START_SEC_VAR_INIT_UNSPECIFIED
//#  include "MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */

extern VAR(BswM_ESH_Mode, RTE_VAR_INIT) Rte_ModeMachine_BswM_Switch_ESH_ModeSwitch_BswM_MDGP_ESH_Mode; /* PRQA S 3408 */ /* MD_Rte_3408 */

#  define RTE_STOP_SEC_VAR_INIT_UNSPECIFIED
//#  include "MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */

typedef struct
{
  uint8 Rte_ModeQueue[1U];
} Rte_ModeInfoType_Dcm_DcmEcuReset_DcmEcuReset;

#  define RTE_START_SEC_VAR_INIT_UNSPECIFIED
//#  include "MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */

extern VAR(Rte_ModeInfoType_Dcm_DcmEcuReset_DcmEcuReset, RTE_VAR_INIT) Rte_ModeInfo_Dcm_DcmEcuReset_DcmEcuReset;
extern VAR(uint8, RTE_VAR_INIT) Rte_ModeMachine_Dcm_DcmEcuReset_DcmEcuReset; /* PRQA S 3408 */ /* MD_Rte_3408 */

#  define RTE_STOP_SEC_VAR_INIT_UNSPECIFIED
//#  include "MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */


#  define RTE_START_SEC_VAR_INIT_UNSPECIFIED
//#  include "MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */

extern VAR(uint8, RTE_VAR_INIT) Rte_ModeMachine_UDSCOM_Dcm_Read_BswM_MDGP_Mode_ProgrammingSession_Dcm_Read_BswM_MDGP_Mode_ProgrammingSession; /* PRQA S 3408 */ /* MD_Rte_3408 */

#  define RTE_STOP_SEC_VAR_INIT_UNSPECIFIED
//#  include "MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */


# endif /* defined(RTE_CORE) */

/**********************************************************************************************************************
 * extern declaration of RTE Update Flags for optimized macro implementation
 *********************************************************************************************************************/
typedef struct
{
  Rte_BitType Rte_RxUpdate_CANIF_SrSg2EE_SrSg2EE : 1;
  Rte_BitType Rte_RxUpdate_CANIF_SrSg2EE_SrSg2EE_Sender : 1;
} Rte_OsApplication_RxUpdateFlagsType;

# define RTE_START_SEC_VAR_ZERO_INIT_UNSPECIFIED
//# include "MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */

extern VAR(Rte_OsApplication_RxUpdateFlagsType, RTE_VAR_ZERO_INIT) Rte_OsApplication_RxUpdateFlags;

# define RTE_STOP_SEC_VAR_ZERO_INIT_UNSPECIFIED
//# include "MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */

#include "Rte_Type_Structured.h"
#include "Rte_Type_SignalDB.h"

/* Added manually for FSIL SafetyModule */
# define Rte_TypeDef_BrakeInfoStatus_ITS4_IDT
typedef uint8 BrakeInfoStatus_ITS4_IDT;
# define Rte_TypeDef_SG_BCM_A113_ITS4_IDT
typedef struct
{
  BrakeInfoStatus_ITS4_IDT BrakeInfoStatus_ITS4;
} SG_BCM_A113_ITS4_IDT;

#endif /* _RTE_TYPE_H */

/**********************************************************************************************************************
 MISRA 2004 violations and justifications
 *********************************************************************************************************************/

/* module specific MISRA deviations:
   MD_Rte_3408:  MISRA rule: 8.8
     Reason:     For the purpose of monitoring during calibration or debugging it is necessary to use non-static declarations.
                 This is covered in the MISRA C compliance section of the Rte specification.
     Risk:       No functional risk.
     Prevention: Not required.

   MD_Rte_Qac:
     Reason:     This justification is used as summary justification for all deviations caused by wrong analysis tool results.
                 The used analysis tool QAC 7.0 sometimes creates wrong messages. Those deviations are no issues in the RTE code.
     Risk:       No functional risk.
     Prevention: Not required.

*/
