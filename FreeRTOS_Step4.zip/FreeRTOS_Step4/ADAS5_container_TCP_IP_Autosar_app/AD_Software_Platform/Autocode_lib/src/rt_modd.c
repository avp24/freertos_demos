/*
 * File: rt_modd.c
 *
 * Code generated for Simulink model 'Control_Lat'.
 *
 * Model version                  : V15_00_00_00_1.4366
 * Simulink Coder version         : 8.11 (R2016b) 25-Aug-2016
 * C/C++ source code generated on : Fri Dec 06 19:13:17 2019
 */

#include "rtwtypes.h"
#include <float.h>
#include <math.h>
#include "rt_roundd.h"
#include "rt_modd.h"

real_T rt_modd(real_T u0, real_T u1)
{
  real_T y;
  real_T tmp;
  if (u1 == 0.0) {
    y = u0;
  } else {
    tmp = u0 / u1;
    if (u1 <= floor(u1)) {
      y = u0 - (floor(tmp) * u1);
    } else if (fabs(tmp - rt_roundd(tmp)) <= (DBL_EPSILON * fabs(tmp))) {
      y = 0.0;
    } else {
      y = (tmp - floor(tmp)) * u1;
    }
  }

  return y;
}

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
