/*
 * File: mul_u32_hiSR.c
 *
 * Code generated for Simulink model 'Fusion'.
 *
 * Model version                  : 1.15032
 * Simulink Coder version         : 8.11 (R2016b) 25-Aug-2016
 * C/C++ source code generated on : Wed Mar 13 13:30:07 2019
 */

#include "rtwtypes.h"
#include "mul_wide_u32.h"
#include "mul_u32_hiSR.h"

uint32_T mul_u32_hiSR(uint32_T a, uint32_T b, uint32_T aShift)
{
  uint32_T u32_chi;
  uint32_T u32_clo;
  mul_wide_u32(a, b, &u32_chi, &u32_clo);
  return u32_chi >> aShift;
}

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
