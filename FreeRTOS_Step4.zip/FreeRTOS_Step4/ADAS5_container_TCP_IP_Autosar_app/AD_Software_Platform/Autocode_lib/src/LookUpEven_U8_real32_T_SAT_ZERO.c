/*
 * File: LookUpEven_U8_real32_T_SAT_ZERO.c
 *
 * Code generated for Simulink model 'CASP'.
 *
 * Model version                  : V15_00_00_00_1.607
 * Simulink Coder version         : 8.11 (R2016b) 25-Aug-2016
 * C/C++ source code generated on : Fri Dec 06 18:56:25 2019
 */

#include "rtwtypes.h"
#include "LookUpEven_U8_real32_T_SAT_ZERO.h"

/* Lookup 1D UtilityLookUpEven_U8_real32_T_SAT_ZERO */
void LookUpEven_U8_real32_T_SAT_ZERO(uint8_T *pY, const uint8_T *pYData,
  real32_T u, real32_T valueLo, uint32_T iHi, real32_T uSpacing)
{
  if (u <= valueLo ) {
    (*pY) = (*pYData);
  } else {
    real32_T uAdjusted = u - valueLo;
    real32_T tmpIdxLeft = uAdjusted / uSpacing;
    uint32_T iLeft = (uint32_T)tmpIdxLeft;
    if ((tmpIdxLeft >= 4294967296.0f) || (iLeft >= iHi) ) {
      (*pY) = pYData[iHi];
    } else {
      {
        real_T lambda;

        {
          real32_T num = (real32_T)uAdjusted - ( iLeft * uSpacing );
          lambda = ((real_T)num) / ((real_T)uSpacing);
        }

        {
          real_T yLeftCast;
          real_T yRghtCast;
          yLeftCast = (real_T)pYData[iLeft];
          yRghtCast = (real_T)pYData[((iLeft)+1)];
          yLeftCast += lambda * ( yRghtCast - yLeftCast );

          {
            uint8_T rtb_u8_tmp;
            real_T rtb_dbl_tmp;
            rtb_dbl_tmp = yLeftCast;
            if (rtb_dbl_tmp < 256.0) {
              if (rtb_dbl_tmp >= 0.0) {
                rtb_u8_tmp = (uint8_T)rtb_dbl_tmp;
              } else {
                rtb_u8_tmp = 0U;
              }
            } else {
              rtb_u8_tmp = MAX_uint8_T;
            }

            (*pY) = rtb_u8_tmp;
          }
        }
      }
    }
  }
}

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
