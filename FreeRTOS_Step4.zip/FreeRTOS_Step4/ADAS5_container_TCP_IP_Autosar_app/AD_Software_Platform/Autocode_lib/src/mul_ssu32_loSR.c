/*
 * File: mul_ssu32_loSR.c
 *
 * Code generated for Simulink model 'swcVehStatus_Out'.
 *
 * Model version                  : VehSTSOut002R_P33A
 * Simulink Coder version         : 8.11 (R2016b) 25-Aug-2016
 * C/C++ source code generated on : Tue Dec 10 20:13:09 2019
 */

#include "rtwtypes.h"
#include "mul_wide_su32.h"
#include "mul_ssu32_loSR.h"

int32_T mul_ssu32_loSR(int32_T a, uint32_T b, uint32_T aShift)
{
  uint32_T u32_chi;
  uint32_T u32_clo;
  mul_wide_su32(a, b, &u32_chi, &u32_clo);
  u32_clo = (u32_chi << /*MW:OvBitwiseOk*/ (32U - aShift)) | (u32_clo >> aShift);
  return (int32_T)u32_clo;
}

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
