/*
 * File: look1_is16lu32n32Ds32_pbinlca.c
 *
 * Code generated for Simulink model 'YAW'.
 *
 * Model version                  : YAW002C_P33A
 * Simulink Coder version         : 8.11 (R2016b) 25-Aug-2016
 * C/C++ source code generated on : Tue Sep 20 10:03:57 2022
 */

#include "rtwtypes.h"
#include "div_nzp_repeat_u32.h"
#include "mul_ssu32_sr32_zero.h"
#include "look1_is16lu32n32Ds32_pbinlca.h"

int16_T look1_is16lu32n32Ds32_pbinlca(int16_T u0, const int16_T bp0[], const
  int16_T table[], uint32_T prevIndex[], uint32_T maxIndex)
{
  int16_T y;
  uint32_T frac;
  uint32_T iRght;
  uint32_T bpIdx;
  uint32_T found;

  /* Lookup 1-D
     Search method: 'binary'
     Use previous index: 'on'
     Interpolation method: 'Linear'
     Extrapolation method: 'Clip'
     Use last breakpoint for index at or above upper limit: 'on'
     Remove protection against out-of-range input in generated code: 'off'
     Rounding mode: 'zero'
   */
  /* Prelookup - Index and Fraction
     Index Search method: 'binary'
     Extrapolation method: 'Clip'
     Use previous index: 'on'
     Use last breakpoint for index at or above upper limit: 'on'
     Remove protection against out-of-range input in generated code: 'off'
     Rounding mode: 'zero'
   */
  if (u0 <= bp0[0U]) {
    bpIdx = 0U;
    frac = 0U;
  } else if (u0 < bp0[maxIndex]) {
    /* Binary Search using Previous Index */
    bpIdx = prevIndex[0U];
    frac = 0U;
    iRght = maxIndex;
    found = 0U;
    while (found == 0U) {
      if (u0 < bp0[bpIdx]) {
        iRght = bpIdx - 1U;
        bpIdx = ((iRght + frac) >> 1U);
      } else if (u0 < bp0[bpIdx + 1U]) {
        found = 1U;
      } else {
        frac = bpIdx + 1U;
        bpIdx = ((iRght + frac) >> 1U);
      }
    }

    frac = div_nzp_repeat_u32(((uint32_T)((uint16_T)((int32_T)(((int32_T)u0) -
      ((int32_T)bp0[bpIdx]))))) << 16, (uint32_T)((uint16_T)((int32_T)(((int32_T)
      bp0[bpIdx + 1U]) - ((int32_T)bp0[bpIdx])))), 16U);
  } else {
    bpIdx = maxIndex;
    frac = 0U;
  }

  prevIndex[0U] = bpIdx;

  /* Interpolation 1-D
     Interpolation method: 'Linear'
     Use last breakpoint for index at or above upper limit: 'on'
     Rounding mode: 'zero'
     Overflow mode: 'wrapping'
   */
  if (bpIdx == maxIndex) {
    y = table[bpIdx];
  } else {
    y = (int16_T)(((int16_T)mul_ssu32_sr32_zero(((int32_T)table[bpIdx + 1U]) -
      ((int32_T)table[bpIdx]), frac)) + table[bpIdx]);
  }

  return y;
}

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
