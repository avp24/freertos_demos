/*
 * File: div_uus32.c
 *
 * Code generated for Simulink model 'VehStatus_In'.
 *
 * Model version                  : 1.232
 * Simulink Coder version         : 8.11 (R2016b) 25-Aug-2016
 * C/C++ source code generated on : Tue Sep 20 09:55:39 2022
 */

#include "rtwtypes.h"
#include "div_uus32.h"

uint32_T div_uus32(uint32_T numerator, int32_T denominator)
{
  uint32_T quotient;
  uint32_T tempAbsQuotient;
  if (denominator == 0) {
    quotient = MAX_uint32_T;

    /* Divide by zero handler */
  } else {
    tempAbsQuotient = numerator / ((denominator < 0) ? ((~((uint32_T)denominator))
      + 1U) : ((uint32_T)denominator));
    quotient = (denominator < 0) ? ((uint32_T)((int32_T)(-((int32_T)
      tempAbsQuotient)))) : tempAbsQuotient;
  }

  return quotient;
}

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
