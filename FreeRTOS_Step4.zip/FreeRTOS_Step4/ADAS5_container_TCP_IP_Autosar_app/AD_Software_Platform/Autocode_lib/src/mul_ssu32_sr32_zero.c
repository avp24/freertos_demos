/*
 * File: mul_ssu32_sr32_zero.c
 *
 * Code generated for Simulink model 'VehStatus_In'.
 *
 * Model version                  : 1.232
 * Simulink Coder version         : 8.11 (R2016b) 25-Aug-2016
 * C/C++ source code generated on : Tue Sep 20 09:55:39 2022
 */

#include "rtwtypes.h"
#include "mul_wide_su32.h"
#include "mul_ssu32_sr32_zero.h"

int32_T mul_ssu32_sr32_zero(int32_T a, uint32_T b)
{
  uint32_T u32_chi;
  uint32_T u32_clo;
  mul_wide_su32(a, b, &u32_chi, &u32_clo);
  return (int32_T)((uint32_T)(((uint32_T)(((((int32_T)u32_chi) < 0) && (u32_clo
    != 0U)) ? 1 : 0)) + u32_chi));
}

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
