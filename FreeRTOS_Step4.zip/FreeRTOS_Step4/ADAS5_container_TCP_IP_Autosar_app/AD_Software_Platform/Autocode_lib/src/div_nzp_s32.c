/*
 * File: div_nzp_s32.c
 *
 * Code generated for Simulink model 'BRK_ENG'.
 *
 * Model version                  : BrkEng001D_P33A
 * Simulink Coder version         : 8.11 (R2016b) 25-Aug-2016
 * C/C++ source code generated on : Tue Sep 20 09:22:05 2022
 */

#include "rtwtypes.h"
#include "div_nzp_s32.h"

int32_T div_nzp_s32(int32_T numerator, int32_T denominator)
{
  uint32_T tempAbsQuotient;
  tempAbsQuotient = ((numerator < 0) ? ((~((uint32_T)numerator)) + 1U) :
                     ((uint32_T)numerator)) / ((denominator < 0) ? ((~((uint32_T)
    denominator)) + 1U) : ((uint32_T)denominator));
  return ((numerator < 0) != (denominator < 0)) ? (-((int32_T)tempAbsQuotient)) :
    ((int32_T)tempAbsQuotient);
}

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
