/*
 * File: mul_u32_sr32.c
 *
 * Code generated for Simulink model 'OEM_DIAG'.
 *
 * Model version                  : 1.60
 * Simulink Coder version         : 8.11 (R2016b) 25-Aug-2016
 * C/C++ source code generated on : Tue Sep 20 09:44:41 2022
 */

#include "rtwtypes.h"
#include "mul_wide_u32.h"
#include "mul_u32_sr32.h"

uint32_T mul_u32_sr32(uint32_T a, uint32_T b)
{
  uint32_T result;
  uint32_T u32_clo;
  mul_wide_u32(a, b, &result, &u32_clo);
  return result;
}

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
