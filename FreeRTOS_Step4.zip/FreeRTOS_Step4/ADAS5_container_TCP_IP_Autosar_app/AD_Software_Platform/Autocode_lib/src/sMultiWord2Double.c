/*
 * File: sMultiWord2Double.c
 *
 * Code generated for Simulink model 'CASP'.
 *
 * Model version                  : 1.68
 * Simulink Coder version         : 8.11 (R2016b) 25-Aug-2016
 * C/C++ source code generated on : Mon Jun 24 10:36:43 2019
 */

#include "rtwtypes.h"
#include <math.h>
#include "sMultiWord2Double.h"

real_T sMultiWord2Double(const uint32_T u1[], int32_T n1, int32_T e1)
{
  real_T y;
  int32_T i;
  int32_T exp_0;
  uint32_T u1i;
  uint32_T cb;
  y = 0.0;
  exp_0 = e1;
  if ((u1[n1 - 1] & 2147483648U) != 0U) {
    cb = 1U;
    for (i = 0; i < n1; i++) {
      u1i = ~u1[i];
      cb += u1i;
      y -= ldexp((real_T)cb, exp_0);
      cb = (uint32_T)((cb < u1i) ? 1 : 0);
      exp_0 += 32;
    }
  } else {
    for (i = 0; i < n1; i++) {
      y += ldexp((real_T)u1[i], exp_0);
      exp_0 += 32;
    }
  }

  return y;
}

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
