/*
 * File: rt_roundf.c
 *
 * Code generated for Simulink model 'swcCASP_Core'.
 *
 * Model version                  : V15_00_00_00_1.290
 * Simulink Coder version         : 8.11 (R2016b) 25-Aug-2016
 * C/C++ source code generated on : Wed Mar 13 13:38:46 2019
 */

#include "rtwtypes.h"
#include <math.h>
#include "rt_roundf.h"

real32_T rt_roundf(real32_T u)
{
  real32_T y;
  if (((real32_T)fabs((real_T)u)) < 8.388608E+6F) {
    if (u >= 0.5F) {
      y = (real32_T)floor((real_T)((real32_T)(u + 0.5F)));
    } else if (u > -0.5F) {
      y = 0.0F;
    } else {
      y = (real32_T)ceil((real_T)((real32_T)(u - 0.5F)));
    }
  } else {
    y = u;
  }

  return y;
}

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
