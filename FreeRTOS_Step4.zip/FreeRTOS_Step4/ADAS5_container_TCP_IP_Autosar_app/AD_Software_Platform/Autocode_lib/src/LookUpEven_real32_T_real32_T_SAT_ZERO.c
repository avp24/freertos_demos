/*
 * File: LookUpEven_real32_T_real32_T_SAT_ZERO.c
 *
 * Code generated for Simulink model 'Control_Longi'.
 *
 * Model version                  : V14_00_00_00_1.2235
 * Simulink Coder version         : 8.11 (R2016b) 25-Aug-2016
 * C/C++ source code generated on : Fri Dec 06 19:21:22 2019
 */

#include "rtwtypes.h"
#include "LookUpEven_real32_T_real32_T_SAT_ZERO.h"

/* Lookup 1D UtilityLookUpEven_real32_T_real32_T_SAT_ZERO */
void LookUpEven_real32_T_real32_T_SAT_ZERO(real32_T *pY, const real32_T *pYData,
  real32_T u, real32_T valueLo, uint32_T iHi, real32_T uSpacing)
{
  if (u <= valueLo ) {
    (*pY) = (*pYData);
  } else {
    real32_T uAdjusted = u - valueLo;
    real32_T tmpIdxLeft = uAdjusted / uSpacing;
    uint32_T iLeft = (uint32_T)tmpIdxLeft;
    if ((tmpIdxLeft >= 4294967296.0f) || (iLeft >= iHi) ) {
      (*pY) = pYData[iHi];
    } else {
      {
        real32_T lambda;

        {
          real32_T num = (real32_T)uAdjusted - ( iLeft * uSpacing );
          lambda = num / uSpacing;
        }

        {
          real32_T yLeftCast;
          real32_T yRghtCast;
          yLeftCast = pYData[iLeft];
          yRghtCast = pYData[((iLeft)+1)];
          yLeftCast += lambda * ( yRghtCast - yLeftCast );
          (*pY) = yLeftCast;
        }
      }
    }
  }
}

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
