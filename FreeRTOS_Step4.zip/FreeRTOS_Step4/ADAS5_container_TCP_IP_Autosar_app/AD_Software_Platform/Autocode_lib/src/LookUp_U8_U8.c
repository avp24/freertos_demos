/*
 * File: LookUp_U8_U8.c
 *
 * Code generated for Simulink model 'Post_Processing'.
 *
 * Model version                  : 1.410
 * Simulink Coder version         : 8.11 (R2016b) 25-Aug-2016
 * C/C++ source code generated on : Wed Aug 10 10:57:01 2022
 */

#include "rtwtypes.h"
#include "BINARYSEARCH_U8.h"
#include "INTERPOLATE_U8_U8.h"
#include "LookUp_U8_U8.h"

/* Lookup Utility LookUp_U8_U8 */
void LookUp_U8_U8(uint8_T *pY, const uint8_T *pYData, uint8_T u, const uint8_T
                  *pUData, uint32_T iHi)
{
  uint32_T iLeft;
  uint32_T iRght;
  BINARYSEARCH_U8( &(iLeft), &(iRght), u, pUData, iHi);
  INTERPOLATE_U8_U8( pY, pYData[iLeft], pYData[iRght], u, pUData[iLeft],
                    pUData[iRght]);
}

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
