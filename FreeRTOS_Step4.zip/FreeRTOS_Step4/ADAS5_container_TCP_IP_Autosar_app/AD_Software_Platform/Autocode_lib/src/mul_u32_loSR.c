/*
 * File: mul_u32_loSR.c
 *
 * Code generated for Simulink model 'VehStatus_In'.
 *
 * Model version                  : VehSTS002R_P33A
 * Simulink Coder version         : 8.11 (R2016b) 25-Aug-2016
 * C/C++ source code generated on : Wed Nov 06 18:50:41 2019
 */

#include "rtwtypes.h"
#include "mul_wide_u32.h"
#include "mul_u32_loSR.h"

uint32_T mul_u32_loSR(uint32_T a, uint32_T b, uint32_T aShift)
{
  uint32_T result;
  uint32_T u32_chi;
  mul_wide_u32(a, b, &u32_chi, &result);
  return (u32_chi << /*MW:OvBitwiseOk*/ (32U - aShift)) | (result >> aShift);
}

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
