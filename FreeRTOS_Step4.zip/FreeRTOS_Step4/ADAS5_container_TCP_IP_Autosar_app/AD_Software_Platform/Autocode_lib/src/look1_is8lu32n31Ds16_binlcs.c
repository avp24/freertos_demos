/*
 * File: look1_is8lu32n31Ds16_binlcs.c
 *
 * Code generated for Simulink model 'ActivationManagement'.
 *
 * Model version                  : 1.19
 * Simulink Coder version         : 8.11 (R2016b) 25-Aug-2016
 * C/C++ source code generated on : Wed Dec 23 15:12:15 2020
 */

#include "rtwtypes.h"
#include "div_nzp_repeat_u32.h"
#include "mul_ssu32_loSR.h"
#include "look1_is8lu32n31Ds16_binlcs.h"

int8_T look1_is8lu32n31Ds16_binlcs(int8_T u0, const int8_T bp0[], const int8_T
  table[], uint32_T maxIndex)
{
  uint32_T frac;
  uint32_T iRght;
  uint32_T iLeft;

  /* Lookup 1-D
     Search method: 'binary'
     Use previous index: 'off'
     Interpolation method: 'Linear'
     Extrapolation method: 'Clip'
     Use last breakpoint for index at or above upper limit: 'off'
     Remove protection against out-of-range input in generated code: 'off'
     Rounding mode: 'simplest'
   */
  /* Prelookup - Index and Fraction
     Index Search method: 'binary'
     Extrapolation method: 'Clip'
     Use previous index: 'off'
     Use last breakpoint for index at or above upper limit: 'off'
     Remove protection against out-of-range input in generated code: 'off'
     Rounding mode: 'simplest'
   */
  if (u0 <= bp0[0U]) {
    iLeft = 0U;
    frac = 0U;
  } else if (u0 < bp0[maxIndex]) {
    /* Binary Search */
    frac = (maxIndex >> 1U);
    iLeft = 0U;
    iRght = maxIndex;
    while ((iRght - iLeft) > 1U) {
      if (u0 < bp0[frac]) {
        iRght = frac;
      } else {
        iLeft = frac;
      }

      frac = ((iRght + iLeft) >> 1U);
    }

    frac = div_nzp_repeat_u32(((uint32_T)((uint8_T)((int32_T)(((int32_T)u0) -
      ((int32_T)bp0[iLeft]))))) << 24, (uint32_T)((uint8_T)((int32_T)(((int32_T)
      bp0[iLeft + 1U]) - ((int32_T)bp0[iLeft])))), 7U);
  } else {
    iLeft = maxIndex - 1U;
    frac = 2147483648U;
  }

  /* Interpolation 1-D
     Interpolation method: 'Linear'
     Use last breakpoint for index at or above upper limit: 'off'
     Rounding mode: 'simplest'
     Overflow mode: 'wrapping'
   */
  return (int8_T)(((int8_T)mul_ssu32_loSR((int32_T)((int16_T)((int32_T)
    (((int32_T)table[iLeft + 1U]) - ((int32_T)table[iLeft])))), frac, 31U)) +
                  table[iLeft]);
}

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
