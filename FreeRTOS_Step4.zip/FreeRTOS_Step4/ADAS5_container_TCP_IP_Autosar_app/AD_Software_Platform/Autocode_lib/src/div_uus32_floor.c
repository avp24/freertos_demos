/*
 * File: div_uus32_floor.c
 *
 * Code generated for Simulink model 'VehStatus_In'.
 *
 * Model version                  : VehSTS002R_P33A
 * Simulink Coder version         : 8.11 (R2016b) 25-Aug-2016
 * C/C++ source code generated on : Wed Nov 06 18:50:41 2019
 */

#include "rtwtypes.h"
#include "div_uus32_floor.h"

uint32_T div_uus32_floor(uint32_T numerator, int32_T denominator)
{
  uint32_T quotient;
  uint32_T absDenominator;
  uint32_T tempAbsQuotient;
  boolean_T quotientNeedsNegation;
  if (denominator == 0) {
    quotient = MAX_uint32_T;

    /* Divide by zero handler */
  } else {
    absDenominator = (denominator < 0) ? ((~((uint32_T)denominator)) + 1U) :
      ((uint32_T)denominator);
    quotientNeedsNegation = (denominator < 0);
    tempAbsQuotient = numerator / absDenominator;
    if (quotientNeedsNegation) {
      numerator %= absDenominator;
      if (numerator > 0U) {
        tempAbsQuotient++;
      }
    }

    quotient = quotientNeedsNegation ? ((uint32_T)((int32_T)(-((int32_T)
      tempAbsQuotient)))) : tempAbsQuotient;
  }

  return quotient;
}

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
