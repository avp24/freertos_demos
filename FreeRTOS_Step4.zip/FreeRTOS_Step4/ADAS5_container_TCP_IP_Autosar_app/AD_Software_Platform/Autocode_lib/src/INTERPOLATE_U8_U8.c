/*
 * File: INTERPOLATE_U8_U8.c
 *
 * Code generated for Simulink model 'Post_Processing'.
 *
 * Model version                  : 1.410
 * Simulink Coder version         : 8.11 (R2016b) 25-Aug-2016
 * C/C++ source code generated on : Wed Aug 10 10:57:01 2022
 */

#include "rtwtypes.h"
#include "INTERPOLATE_U8_U8.h"

/* Lookup Interpolation INTERPOLATE_U8_U8 */
void INTERPOLATE_U8_U8(uint8_T *pY, uint8_T yL, uint8_T yR, uint8_T x, uint8_T
  xL, uint8_T xR)
{
  uint32_T bigProd;
  uint8_T yDiff;
  uint8_T xNum;
  uint8_T xDen;
  *pY = yL;

  /* If x is not strictly between xR and xL
   * then an interpolation calculation is not necessary x == xL
   * or not valid.  The invalid situation is expected when the input
   * is beyond the left or right end of the table.  The design is
   * that yL holds the correct value for *pY
   * in invalid situations.
   */
  if ((xR > xL) && (x > xL) ) {
    xDen = xR;
    xDen = (uint8_T)(((uint32_T)xDen) - ((uint32_T)xL));
    xNum = x;
    xNum = (uint8_T)(((uint32_T)xNum) - ((uint32_T)xL));
    if (yR >= yL ) {
      yDiff = yR;
      yDiff = (uint8_T)(((uint32_T)yDiff) - ((uint32_T)yL));
    } else {
      yDiff = yL;
      yDiff = (uint8_T)(((uint32_T)yDiff) - ((uint32_T)yR));
    }

    bigProd = ((uint32_T)yDiff) * ((uint32_T)xNum);

    {
      uint32_T rtb_u32_tmp;
      rtb_u32_tmp = (uint32_T)xDen;
      yDiff = (uint8_T)((rtb_u32_tmp == 0U) ? MAX_uint32_T : (bigProd /
        rtb_u32_tmp));
    }

    if (yR >= yL ) {
      *pY = (uint8_T)(((uint32_T)*pY) + ((uint32_T)yDiff));
    } else {
      *pY = (uint8_T)(((uint32_T)*pY) - ((uint32_T)yDiff));
    }
  }
}

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
