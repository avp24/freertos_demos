/*
 * File: MultiWord2sLong.c
 *
 * Code generated for Simulink model 'DAA'.
 *
 * Model version                  : 1.1038
 * Simulink Coder version         : 8.11 (R2016b) 25-Aug-2016
 * C/C++ source code generated on : Wed Dec 11 14:22:09 2019
 */

#include "rtwtypes.h"
#include "MultiWord2sLong.h"

int32_T MultiWord2sLong(const uint32_T u[])
{
  return (int32_T)u[0];
}

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
