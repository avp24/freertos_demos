/*
 * File: look1_is32lu32n31Du32_binlcse.c
 *
 * Code generated for Simulink model 'VehStatus_In'.
 *
 * Model version                  : VehSTS002R_P33A
 * Simulink Coder version         : 8.11 (R2016b) 25-Aug-2016
 * C/C++ source code generated on : Wed Nov 06 18:50:41 2019
 */

#include "rtwtypes.h"
#include "div_nzp_repeat_u32.h"
#include "mul_u32_loSR.h"
#include "look1_is32lu32n31Du32_binlcse.h"

int32_T look1_is32lu32n31Du32_binlcse(int32_T u0, const int32_T bp0[], const
  int32_T table[], uint32_T maxIndex)
{
  int32_T y;
  uint32_T frac;
  uint32_T iRght;
  uint32_T iLeft;

  /* Lookup 1-D
     Search method: 'binary'
     Use previous index: 'off'
     Interpolation method: 'Linear'
     Extrapolation method: 'Clip'
     Use last breakpoint for index at or above upper limit: 'off'
     Remove protection against out-of-range input in generated code: 'off'
     Rounding mode: 'simplest'
   */
  /* Prelookup - Index and Fraction
     Index Search method: 'binary'
     Extrapolation method: 'Clip'
     Use previous index: 'off'
     Use last breakpoint for index at or above upper limit: 'off'
     Remove protection against out-of-range input in generated code: 'off'
     Rounding mode: 'simplest'
   */
  if (u0 <= bp0[0U]) {
    iLeft = 0U;
    frac = 0U;
  } else if (u0 < bp0[maxIndex]) {
    /* Binary Search */
    frac = (maxIndex >> 1U);
    iLeft = 0U;
    iRght = maxIndex;
    while ((iRght - iLeft) > 1U) {
      if (u0 < bp0[frac]) {
        iRght = frac;
      } else {
        iLeft = frac;
      }

      frac = ((iRght + iLeft) >> 1U);
    }

    frac = div_nzp_repeat_u32(((uint32_T)u0) - ((uint32_T)bp0[iLeft]),
      ((uint32_T)bp0[iLeft + 1U]) - ((uint32_T)bp0[iLeft]), 31U);
  } else {
    iLeft = maxIndex - 1U;
    frac = 2147483648U;
  }

  /* Interpolation 1-D
     Interpolation method: 'Linear'
     Use last breakpoint for index at or above upper limit: 'off'
     Rounding mode: 'simplest'
     Overflow mode: 'wrapping'
   */
  if (table[iLeft + 1U] >= table[iLeft]) {
    y = ((int32_T)mul_u32_loSR(frac, ((uint32_T)table[iLeft + 1U]) - ((uint32_T)
           table[iLeft]), 31U)) + table[iLeft];
  } else {
    y = table[iLeft] - ((int32_T)mul_u32_loSR(frac, ((uint32_T)table[iLeft]) -
      ((uint32_T)table[iLeft + 1U]), 31U));
  }

  return y;
}

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
