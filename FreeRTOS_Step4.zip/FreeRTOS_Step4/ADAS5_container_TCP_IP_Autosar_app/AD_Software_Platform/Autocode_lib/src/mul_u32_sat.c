/*
 * File: mul_u32_sat.c
 *
 * Code generated for Simulink model 'Fusion'.
 *
 * Model version                  : 1.15995
 * Simulink Coder version         : 8.11 (R2016b) 25-Aug-2016
 * C/C++ source code generated on : Wed Nov 20 12:29:55 2019
 */

#include "rtwtypes.h"
#include "mul_wide_u32.h"
#include "mul_u32_sat.h"

uint32_T mul_u32_sat(uint32_T a, uint32_T b)
{
  uint32_T result;
  uint32_T u32_chi;
  mul_wide_u32(a, b, &u32_chi, &result);
  if (u32_chi != 0U) {
    result = MAX_uint32_T;
  }

  return result;
}

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
