/*
 * File: calib_EHR.h
 *
 * Code generated for Simulink model 'EHR'.
 *
 * Model version                  : V14_00_00_00_1.515
 * Simulink Coder version         : 8.11 (R2016b) 25-Aug-2016
 * C/C++ source code generated on : Fri Feb 24 10:50:59 2023
 */

#ifndef RTW_HEADER_calib_EHR_h_
#define RTW_HEADER_calib_EHR_h_
#include "rtwtypes.h"

/* Const memory section */
/* Exported data declaration */
/* Declaration for custom storage class: Const */
extern const real32_T P_tng_pct_PosProbaErrTh[9];
extern const real32_T P_tng_pct_PosProbaImOkTh[9];
extern const real32_T P_tng_pct_PosProbaOkTh[9];
extern const real32_T P_tng_s_AgeLimit;
extern const boolean_T P_tng_x_AdasisCurveSel[9];
extern const boolean_T P_tng_x_AdasisInterpWithPosAge[9];
extern const boolean_T P_tng_x_AdasisMaxHorizonExt[9];
extern const boolean_T P_tng_x_AdasisReroutingClear[9];
extern const boolean_T P_tng_x_AdasisUsePfsCurvature[9];
extern const uint8_T P_tng_x_BufClearTrailLen2_EHR;
extern const uint8_T P_tng_x_BufMngClearEnable_EHR;
extern const uint8_T P_tng_x_PosConfdErrTh[9];
extern const uint8_T P_tng_x_SubpathUpdate_EHR;

#endif                                 /* RTW_HEADER_calib_EHR_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
