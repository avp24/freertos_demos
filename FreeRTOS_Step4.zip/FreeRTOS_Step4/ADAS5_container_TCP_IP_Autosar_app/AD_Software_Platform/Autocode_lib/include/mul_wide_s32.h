/*
 * File: mul_wide_s32.h
 *
 * Code generated for Simulink model 'OEM_DIAG'.
 *
 * Model version                  : OEMD007_P33A
 * Simulink Coder version         : 8.11 (R2016b) 25-Aug-2016
 * C/C++ source code generated on : Fri Nov 15 10:31:59 2019
 */

#ifndef SHARE_mul_wide_s32
#define SHARE_mul_wide_s32
#include "rtwtypes.h"

extern void mul_wide_s32(int32_T in0, int32_T in1, uint32_T *ptrOutBitsHi,
  uint32_T *ptrOutBitsLo);

#endif

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
