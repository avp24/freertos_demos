/*
 * File: div_nzp_s32.h
 *
 * Code generated for Simulink model 'BRK_ENG'.
 *
 * Model version                  : BrkEng001D_P33A
 * Simulink Coder version         : 8.11 (R2016b) 25-Aug-2016
 * C/C++ source code generated on : Tue Sep 20 09:22:05 2022
 */

#ifndef SHARE_div_nzp_s32
#define SHARE_div_nzp_s32
#include "rtwtypes.h"

extern int32_T div_nzp_s32(int32_T numerator, int32_T denominator);

#endif

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
