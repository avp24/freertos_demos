/*
 * File: mul_u32_hiSR.h
 *
 * Code generated for Simulink model 'Fusion'.
 *
 * Model version                  : 1.15032
 * Simulink Coder version         : 8.11 (R2016b) 25-Aug-2016
 * C/C++ source code generated on : Wed Mar 13 13:30:07 2019
 */

#ifndef SHARE_mul_u32_hiSR
#define SHARE_mul_u32_hiSR
#include "rtwtypes.h"

extern uint32_T mul_u32_hiSR(uint32_T a, uint32_T b, uint32_T aShift);

#endif

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
