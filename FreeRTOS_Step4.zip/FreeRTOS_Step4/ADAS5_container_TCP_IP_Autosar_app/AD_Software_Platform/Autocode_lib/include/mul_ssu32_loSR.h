/*
 * File: mul_ssu32_loSR.h
 *
 * Code generated for Simulink model 'swcVehStatus_Out'.
 *
 * Model version                  : VehSTSOut002R_P33A
 * Simulink Coder version         : 8.11 (R2016b) 25-Aug-2016
 * C/C++ source code generated on : Tue Dec 10 20:13:09 2019
 */

#ifndef SHARE_mul_ssu32_loSR
#define SHARE_mul_ssu32_loSR
#include "rtwtypes.h"

extern int32_T mul_ssu32_loSR(int32_T a, uint32_T b, uint32_T aShift);

#endif

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
