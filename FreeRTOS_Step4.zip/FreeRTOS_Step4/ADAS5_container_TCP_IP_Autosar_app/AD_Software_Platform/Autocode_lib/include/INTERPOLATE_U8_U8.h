/*
 * File: INTERPOLATE_U8_U8.h
 *
 * Code generated for Simulink model 'Post_Processing'.
 *
 * Model version                  : 1.410
 * Simulink Coder version         : 8.11 (R2016b) 25-Aug-2016
 * C/C++ source code generated on : Wed Aug 10 10:57:01 2022
 */

#ifndef SHARE_INTERPOLATE_U8_U8
#define SHARE_INTERPOLATE_U8_U8
#include "rtwtypes.h"

void INTERPOLATE_U8_U8(uint8_T *pY, uint8_T yL, uint8_T yR, uint8_T x, uint8_T
  xL, uint8_T xR);

#endif

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
