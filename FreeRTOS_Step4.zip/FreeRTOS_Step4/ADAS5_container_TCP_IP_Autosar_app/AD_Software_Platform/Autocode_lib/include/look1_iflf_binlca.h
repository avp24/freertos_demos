/*
 * File: look1_iflf_binlca.h
 *
 * Code generated for Simulink model 'swcAPA_StatusIn'.
 *
 * Model version                  : 35
 * Simulink Coder version         : 8.11 (R2016b) 25-Aug-2016
 * C/C++ source code generated on : Wed Nov 06 18:51:39 2019
 */

#ifndef SHARE_look1_iflf_binlca
#define SHARE_look1_iflf_binlca
#include "rtwtypes.h"

extern real32_T look1_iflf_binlca(real32_T u0, const real32_T bp0[], const
  real32_T table[], uint32_T maxIndex);

#endif

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
