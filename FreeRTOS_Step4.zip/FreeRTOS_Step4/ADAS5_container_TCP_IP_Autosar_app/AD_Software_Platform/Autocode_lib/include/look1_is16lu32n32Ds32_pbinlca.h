/*
 * File: look1_is16lu32n32Ds32_pbinlca.h
 *
 * Code generated for Simulink model 'YAW'.
 *
 * Model version                  : YAW002C_P33A
 * Simulink Coder version         : 8.11 (R2016b) 25-Aug-2016
 * C/C++ source code generated on : Tue Sep 20 10:03:57 2022
 */

#ifndef SHARE_look1_is16lu32n32Ds32_pbinlca
#define SHARE_look1_is16lu32n32Ds32_pbinlca
#include "rtwtypes.h"

extern int16_T look1_is16lu32n32Ds32_pbinlca(int16_T u0, const int16_T bp0[],
  const int16_T table[], uint32_T prevIndex[], uint32_T maxIndex);

#endif

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
