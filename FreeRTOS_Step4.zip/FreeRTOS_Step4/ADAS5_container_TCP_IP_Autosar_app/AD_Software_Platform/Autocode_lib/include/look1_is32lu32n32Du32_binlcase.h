/*
 * File: look1_is32lu32n32Du32_binlcase.h
 *
 * Code generated for Simulink model 'OEM_DIAG'.
 *
 * Model version                  : 1.60
 * Simulink Coder version         : 8.11 (R2016b) 25-Aug-2016
 * C/C++ source code generated on : Tue Sep 20 09:44:41 2022
 */

#ifndef SHARE_look1_is32lu32n32Du32_binlcase
#define SHARE_look1_is32lu32n32Du32_binlcase
#include "rtwtypes.h"

extern int32_T look1_is32lu32n32Du32_binlcase(int32_T u0, const int32_T bp0[],
  const int32_T table[], uint32_T maxIndex);

#endif

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
