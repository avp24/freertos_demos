/*
 * File: rt_roundd.h
 *
 * Code generated for Simulink model 'Control_Lat'.
 *
 * Model version                  : V15_00_00_00_1.4366
 * Simulink Coder version         : 8.11 (R2016b) 25-Aug-2016
 * C/C++ source code generated on : Fri Dec 06 19:13:17 2019
 */

#ifndef SHARE_rt_roundd
#define SHARE_rt_roundd
#include "rtwtypes.h"

extern real_T rt_roundd(real_T u);

#endif

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
