/*
 * File: mul_u32_sat.h
 *
 * Code generated for Simulink model 'Fusion'.
 *
 * Model version                  : 1.15995
 * Simulink Coder version         : 8.11 (R2016b) 25-Aug-2016
 * C/C++ source code generated on : Wed Nov 20 12:29:55 2019
 */

#ifndef SHARE_mul_u32_sat
#define SHARE_mul_u32_sat
#include "rtwtypes.h"

extern uint32_T mul_u32_sat(uint32_T a, uint32_T b);

#endif

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
