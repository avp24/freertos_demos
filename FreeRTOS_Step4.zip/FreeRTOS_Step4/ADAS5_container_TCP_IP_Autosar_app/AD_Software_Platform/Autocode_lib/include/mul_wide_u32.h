/*
 * File: mul_wide_u32.h
 *
 * Code generated for Simulink model 'Fusion'.
 *
 * Model version                  : 1.15995
 * Simulink Coder version         : 8.11 (R2016b) 25-Aug-2016
 * C/C++ source code generated on : Wed Nov 20 12:29:55 2019
 */

#ifndef SHARE_mul_wide_u32
#define SHARE_mul_wide_u32
#include "rtwtypes.h"

extern void mul_wide_u32(uint32_T in0, uint32_T in1, uint32_T *ptrOutBitsHi,
  uint32_T *ptrOutBitsLo);

#endif

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
