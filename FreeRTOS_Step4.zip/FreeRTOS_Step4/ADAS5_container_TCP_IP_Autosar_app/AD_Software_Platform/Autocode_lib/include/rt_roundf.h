/*
 * File: rt_roundf.h
 *
 * Code generated for Simulink model 'swcCASP_Core'.
 *
 * Model version                  : V15_00_00_00_1.290
 * Simulink Coder version         : 8.11 (R2016b) 25-Aug-2016
 * C/C++ source code generated on : Wed Mar 13 13:38:46 2019
 */

#ifndef SHARE_rt_roundf
#define SHARE_rt_roundf
#include "rtwtypes.h"

extern real32_T rt_roundf(real32_T u);

#endif

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
