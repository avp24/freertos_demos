/*
 * File: div_uus32.h
 *
 * Code generated for Simulink model 'VehStatus_In'.
 *
 * Model version                  : 1.232
 * Simulink Coder version         : 8.11 (R2016b) 25-Aug-2016
 * C/C++ source code generated on : Tue Sep 20 09:55:39 2022
 */

#ifndef SHARE_div_uus32
#define SHARE_div_uus32
#include "rtwtypes.h"

extern uint32_T div_uus32(uint32_T numerator, int32_T denominator);

#endif

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
