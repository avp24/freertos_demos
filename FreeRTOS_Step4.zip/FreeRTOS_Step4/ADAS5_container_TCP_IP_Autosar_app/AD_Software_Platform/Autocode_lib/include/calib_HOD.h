/*
 * File: calib_HOD.h
 *
 * Code generated for Simulink model 'HOD'.
 *
 * Model version                  : Master_v536
 * Simulink Coder version         : 8.11 (R2016b) 25-Aug-2016
 * C/C++ source code generated on : Tue Feb 21 23:18:00 2023
 */

#ifndef RTW_HEADER_calib_HOD_h_
#define RTW_HEADER_calib_HOD_h_
#include "rtwtypes.h"

/* Const memory section */
/* Exported data declaration */
/* Declaration for custom storage class: Const */
extern const boolean_T P_fix_x_LatActiveStrategy;
extern const real32_T P_sys_m_DistHandsOffJudge;
extern const real32_T P_sys_m_DistHandsOffJudgeTh;
extern const real32_T P_sys_s_HandsOffPreActTimeOfst2;
extern const real32_T P_sys_x_HandsOffSub3rdTh1LowLmt;
extern const real32_T P_sys_x_HandsOffSub3rdTh1UpLmt;
extern const real32_T P_sys_x_HandsOffTest3Jdge;
extern const real32_T P_sys_x_HandsOffTestJdge;
extern const real32_T P_tng_degC_TrqClbTrqGainByTemp[7];
extern const real32_T P_tng_deg_DStrComOutGainY[21];
extern const real32_T P_tng_deg_MaxStrAngHODCheck;
extern const real32_T P_tng_deg_ModeOffJudge;
extern const real32_T P_tng_deg_ModeOnJudge;
extern const real32_T P_tng_deg_StrAngComMaxActTst;
extern const real32_T P_tng_degps_StrAngComSpdActTst;
extern const real32_T P_tng_m_HOWDispnn2DistanceTh2;
extern const real32_T P_tng_m_HOWSubDistThWithTouch;
extern const real32_T P_tng_mps_VehSpdTHWithTouch;
extern const real32_T P_tng_mps_VehicleSpeedTh3;
extern const real32_T P_tng_nm_AveOffsetTrqTh;
extern const real32_T P_tng_nm_AveOffsetTrqTh1;
extern const real32_T P_tng_nm_AveOffsetTrqThWTouch;
extern const real32_T P_tng_nm_AverageOffsetTrqTh;
extern const real32_T P_tng_nm_DiffStrTrqCalibTh;
extern const real32_T P_tng_nm_FRICtoHOD_th2X[10];
extern const real32_T P_tng_nm_FRICtoHOD_th2Y[10];
extern const real32_T P_tng_nm_HODThAddX[10];
extern const real32_T P_tng_nm_HODThAddY[7];
extern const real32_T P_tng_nm_HODThAddZ[70];
extern const real32_T P_tng_nm_HOD_SUB_ABS_th2X[10];
extern const real32_T P_tng_nm_HOD_SUB_ABS_th2Y[10];
extern const real32_T P_tng_nm_HOD_SUB_DifferencethX[10];
extern const real32_T P_tng_nm_HOD_SUB_DifferencethY[10];
extern const real32_T P_tng_nm_HandsOffJdg3rdTrqOfst;
extern const real32_T P_tng_nm_HandsOffJdgTrigOffTrq;
extern const real32_T P_tng_nm_HandsOffJudge3rdTrqMax;
extern const real32_T P_tng_nm_MaxTrqThWTouch;
extern const real32_T P_tng_nm_StrDeviation;
extern const real32_T P_tng_nm_StrTrqDiffThMapX[10];
extern const real32_T P_tng_nm_StrTrqDiffThMapY[10];
extern const real32_T P_tng_nm_StrTrqHODThMap1X[21];
extern const real32_T P_tng_nm_StrTrqHODThMap1Y[21];
extern const real32_T P_tng_nm_TRQ_to_HOD_TH_OnlineX[10];
extern const real32_T P_tng_nm_TRQ_to_HOD_TH_OnlineY[10];
extern const real32_T P_tng_nm_TorqueManualValue;
extern const real32_T P_tng_nm_TrqtoHODThX[5];
extern const real32_T P_tng_nm_TrqtoHODThY[5];
extern const real32_T P_tng_s_HOWDispHysterisOffset;
extern const real32_T P_tng_s_HandsOffPreActTime;
extern const real32_T P_tng_s_HandsOffPreActTimeOflin;
extern const real32_T P_tng_s_NoTouchOnSteerJudgeTime;
extern const real32_T P_tng_s_TimeThBeforeWarning;
extern const real32_T P_tng_s_TimeThBeforeWarningLC;
extern const real32_T P_tng_s_TouchSensorCalibErrTime;
extern const real32_T P_tng_s_TouchSensorErrHoldTime;
extern const real32_T P_tng_x_HODHoldTorqueThGain1;
extern const real32_T P_tng_x_HODHoldTorqueThGain2;
extern const real32_T P_tng_x_HODTimeHoldTorqueThGain;
extern const uint16_T P_tng_x_HOWDispBackupOnlyTime;
extern const real32_T P_tng_x_HOWDispHysterisUpTh;
extern const uint16_T P_tng_x_HOWDispNonBackupTime;
extern const real32_T P_tng_x_HOWDispPreHysterisUpTh;
extern const real32_T P_tng_x_HOWSubTimeThWithTouch;
extern const real32_T P_tng_x_HandsOffJudgeCount;
extern const real32_T P_tng_x_HandsOffnn2JudgeTh1;
extern const real32_T P_tng_x_HandsOnJdgDTFth;
extern const real32_T P_tng_x_HandsOnJdgeDTFY[8];
extern const real32_T P_tng_x_HandsOnJdgeTh;
extern const real32_T P_tng_x_HandsOnjdgMinTh;
extern const real32_T P_tng_x_HandsoffJdgTh;
extern const real32_T P_tng_x_StrTrqDiffLatGain1;
extern const real32_T P_tng_x_TorqueMaxMinTh;
extern const real32_T P_tng_x_TrqAverageGainWTouch;
extern const real32_T P_tng_x_TrqClbTrqGainByTemp[7];
extern const real32_T P_tng_x_TrqHandsOffBackupOnly;
extern const real32_T P_tng_x_TrqMaxMinFraction;
extern const real32_T P_tng_x_VehicleSpeedY[7];
extern const real32_T P_tng_x_offlineStrTrqResolution;

#endif                                 /* RTW_HEADER_calib_HOD_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
