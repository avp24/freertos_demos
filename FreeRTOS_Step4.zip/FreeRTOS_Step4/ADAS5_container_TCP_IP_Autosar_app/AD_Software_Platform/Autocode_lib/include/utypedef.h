/******************************************************************************
 *
 *     Copyright (c) 2018 Nissan, Japan
 *
 ******************************************************************************
 *
 * Project			:ADAS5
 * Module			:
 * Version			:
 * Author			:Ono
 * Date				:
 * Description		:
 * Revision History	:
 *
******************************************************************************/
#ifndef	__UTYPEDEF_H__
#define	__UTYPEDEF_H__

#include	"Platform_Types.h"
#include	"rtwtypes.h"

typedef signed int  	SINT;
typedef unsigned int    UINT;
typedef float           FLOAT;
typedef double          DOUBLE;
typedef	unsigned char	uchar8;
typedef	signed char		schar8;


#define UINT16MAX	MAX_uint16_T
#define UINT16MIN	(0)
#define SINT16MIN	MIN_int16_T
#define SINT16MAX	MAX_int16_T
#define UINT8MIN	(0)
#define UINT8MAX	MAX_uint8_T
#define SINT8MIN	MIN_int8_T
#define SINT8MAX	MAX_int8_T
#define SINT32MIN	MIN_int32_T
#define SINT32MAX	MAX_int32_T
#define UINT32MAX	MAX_uint32_T
#define UCHAR8MIN	(0)
#define UCHAR8MAX	MAX_uint8_T
#define SCHAR8MIN	MIN_int8_T
#define SCHAR8MAX	MAX_int8_T

#endif	/* __UTYPEDEF_H__ */
