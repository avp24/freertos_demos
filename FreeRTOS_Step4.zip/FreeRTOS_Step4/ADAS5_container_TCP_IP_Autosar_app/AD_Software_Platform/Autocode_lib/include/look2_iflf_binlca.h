/*
 * File: look2_iflf_binlca.h
 *
 * Code generated for Simulink model 'Control_Lat'.
 *
 * Model version                  : V15_00_00_00_1.4366
 * Simulink Coder version         : 8.11 (R2016b) 25-Aug-2016
 * C/C++ source code generated on : Fri Dec 06 19:13:17 2019
 */

#ifndef SHARE_look2_iflf_binlca
#define SHARE_look2_iflf_binlca
#include "rtwtypes.h"

extern real32_T look2_iflf_binlca(real32_T u0, real32_T u1, const real32_T bp0[],
  const real32_T bp1[], const real32_T table[], const uint32_T maxIndex[],
  uint32_T stride);

#endif

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
