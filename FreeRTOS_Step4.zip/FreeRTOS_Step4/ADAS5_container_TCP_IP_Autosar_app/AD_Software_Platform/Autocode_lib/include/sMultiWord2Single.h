/*
 * File: sMultiWord2Single.h
 *
 * Code generated for Simulink model 'CASP'.
 *
 * Model version                  : 1.39
 * Simulink Coder version         : 8.11 (R2016b) 25-Aug-2016
 * C/C++ source code generated on : Tue May 07 09:55:44 2019
 */

#ifndef SHARE_sMultiWord2Single
#define SHARE_sMultiWord2Single
#include "rtwtypes.h"

extern real32_T sMultiWord2Single(const uint32_T u1[], int32_T n1, int32_T e1);

#endif

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
