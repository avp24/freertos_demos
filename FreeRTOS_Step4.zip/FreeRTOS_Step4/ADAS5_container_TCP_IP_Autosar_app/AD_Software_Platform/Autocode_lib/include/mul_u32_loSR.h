/*
 * File: mul_u32_loSR.h
 *
 * Code generated for Simulink model 'VehStatus_In'.
 *
 * Model version                  : VehSTS002R_P33A
 * Simulink Coder version         : 8.11 (R2016b) 25-Aug-2016
 * C/C++ source code generated on : Wed Nov 06 18:50:41 2019
 */

#ifndef SHARE_mul_u32_loSR
#define SHARE_mul_u32_loSR
#include "rtwtypes.h"

extern uint32_T mul_u32_loSR(uint32_T a, uint32_T b, uint32_T aShift);

#endif

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
