/*
 * File: calib_HMI.h
 *
 * Code generated for Simulink model 'calc_message'.
 *
 * Model version                  : 1.969
 * Simulink Coder version         : 8.11 (R2016b) 25-Aug-2016
 * C/C++ source code generated on : Fri Feb 24 10:29:28 2023
 */

#ifndef RTW_HEADER_calib_HMI_h_
#define RTW_HEADER_calib_HMI_h_
#include "rtwtypes.h"

/* Const memory section */
/* Exported data declaration */
/* Declaration for custom storage class: Const */
extern const uint8_T P_fix_x_Meter_AttentionMergingTraffic;
extern const uint8_T P_fix_x_Meter_HdsOnWhl_LaneStenosis;
extern const uint8_T P_fix_x_Meter_HdsOnWhl_Merging;
extern const uint8_T P_fix_x_Meter_HdsOnWhl_NotDetectLane;
extern const uint8_T P_fix_x_Meter_HdsOnWhl_SharpCurve;
extern const uint8_T P_fix_x_Meter_PressToExitLeft;
extern const uint8_T P_fix_x_Meter_PressToExitRight;
extern const uint8_T P_fix_x_Meter_PressToProceedLeftRoute;
extern const uint8_T P_fix_x_Meter_PressToProceedRightRoute;
extern const uint8_T P_fix_x_Meter_StrAsstPartUnavl_LaneStenosis;
extern const uint8_T P_fix_x_Meter_StrAsstPartUnavl_Merging;
extern const uint8_T P_fix_x_Meter_StrAsstPartUnavl_SharpCurve;
extern const real32_T P_tng_s_DMW_HoldTime;

#endif                                 /* RTW_HEADER_calib_HMI_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
