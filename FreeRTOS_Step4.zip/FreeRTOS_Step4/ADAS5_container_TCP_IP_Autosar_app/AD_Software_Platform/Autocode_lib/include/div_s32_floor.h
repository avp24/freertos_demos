/*
 * File: div_s32_floor.h
 *
 * Code generated for Simulink model 'OEM_DIAG'.
 *
 * Model version                  : OEMD007_P33A
 * Simulink Coder version         : 8.11 (R2016b) 25-Aug-2016
 * C/C++ source code generated on : Fri Nov 15 10:31:59 2019
 */

#ifndef SHARE_div_s32_floor
#define SHARE_div_s32_floor
#include "rtwtypes.h"

extern int32_T div_s32_floor(int32_T numerator, int32_T denominator);

#endif

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
