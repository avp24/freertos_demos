/*
 * File: sMultiWord2Double.h
 *
 * Code generated for Simulink model 'CASP'.
 *
 * Model version                  : 1.68
 * Simulink Coder version         : 8.11 (R2016b) 25-Aug-2016
 * C/C++ source code generated on : Mon Jun 24 10:36:43 2019
 */

#ifndef SHARE_sMultiWord2Double
#define SHARE_sMultiWord2Double
#include "rtwtypes.h"

extern real_T sMultiWord2Double(const uint32_T u1[], int32_T n1, int32_T e1);

#endif

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
