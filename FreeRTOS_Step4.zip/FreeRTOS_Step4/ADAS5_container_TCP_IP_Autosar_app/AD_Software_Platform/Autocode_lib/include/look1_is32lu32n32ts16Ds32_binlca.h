/*
 * File: look1_is32lu32n32ts16Ds32_binlca.h
 *
 * Code generated for Simulink model 'VehStatus_In'.
 *
 * Model version                  : 1.232
 * Simulink Coder version         : 8.11 (R2016b) 25-Aug-2016
 * C/C++ source code generated on : Tue Sep 20 09:55:39 2022
 */

#ifndef SHARE_look1_is32lu32n32ts16Ds32_binlca
#define SHARE_look1_is32lu32n32ts16Ds32_binlca
#include "rtwtypes.h"

extern int16_T look1_is32lu32n32ts16Ds32_binlca(int32_T u0, const int32_T bp0[],
  const int16_T table[], uint32_T maxIndex);

#endif

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
