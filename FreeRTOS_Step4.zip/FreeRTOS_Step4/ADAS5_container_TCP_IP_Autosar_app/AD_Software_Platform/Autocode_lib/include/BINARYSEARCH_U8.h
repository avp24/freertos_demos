/*
 * File: BINARYSEARCH_U8.h
 *
 * Code generated for Simulink model 'Post_Processing'.
 *
 * Model version                  : 1.410
 * Simulink Coder version         : 8.11 (R2016b) 25-Aug-2016
 * C/C++ source code generated on : Wed Aug 10 10:57:01 2022
 */

#ifndef SHARE_BINARYSEARCH_U8
#define SHARE_BINARYSEARCH_U8
#include "rtwtypes.h"

void BINARYSEARCH_U8(uint32_T *piLeft, uint32_T *piRght, uint8_T u, const
                     uint8_T *pData, uint32_T iHi);

#endif

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
