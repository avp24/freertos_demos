/*
 * File: look1_iflftu8Df_binlca.h
 *
 * Code generated for Simulink model 'Control_Lat'.
 *
 * Model version                  : V15_00_00_00_1.4606
 * Simulink Coder version         : 8.11 (R2016b) 25-Aug-2016
 * C/C++ source code generated on : Mon Mar 09 17:23:48 2020
 */

#ifndef SHARE_look1_iflftu8Df_binlca
#define SHARE_look1_iflftu8Df_binlca
#include "rtwtypes.h"

extern uint8_T look1_iflftu8Df_binlca(real32_T u0, const real32_T bp0[], const
  uint8_T table[], uint32_T maxIndex);

#endif

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
