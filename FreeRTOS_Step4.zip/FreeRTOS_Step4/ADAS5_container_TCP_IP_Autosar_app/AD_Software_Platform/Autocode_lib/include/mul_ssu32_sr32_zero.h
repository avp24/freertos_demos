/*
 * File: mul_ssu32_sr32_zero.h
 *
 * Code generated for Simulink model 'VehStatus_In'.
 *
 * Model version                  : 1.232
 * Simulink Coder version         : 8.11 (R2016b) 25-Aug-2016
 * C/C++ source code generated on : Tue Sep 20 09:55:39 2022
 */

#ifndef SHARE_mul_ssu32_sr32_zero
#define SHARE_mul_ssu32_sr32_zero
#include "rtwtypes.h"

extern int32_T mul_ssu32_sr32_zero(int32_T a, uint32_T b);

#endif

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
