/*
 * File: mul_u32_sr32.h
 *
 * Code generated for Simulink model 'OEM_DIAG'.
 *
 * Model version                  : 1.60
 * Simulink Coder version         : 8.11 (R2016b) 25-Aug-2016
 * C/C++ source code generated on : Tue Sep 20 09:44:41 2022
 */

#ifndef SHARE_mul_u32_sr32
#define SHARE_mul_u32_sr32
#include "rtwtypes.h"

extern uint32_T mul_u32_sr32(uint32_T a, uint32_T b);

#endif

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
