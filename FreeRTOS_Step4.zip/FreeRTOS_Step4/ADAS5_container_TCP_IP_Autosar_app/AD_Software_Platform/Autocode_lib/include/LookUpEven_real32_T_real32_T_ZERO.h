/*
 * File: LookUpEven_real32_T_real32_T_ZERO.h
 *
 * Code generated for Simulink model 'Control_Lat'.
 *
 * Model version                  : V15_00_00_00_1.4366
 * Simulink Coder version         : 8.11 (R2016b) 25-Aug-2016
 * C/C++ source code generated on : Fri Dec 06 19:13:17 2019
 */

#ifndef SHARE_LookUpEven_real32_T_real32_T_ZERO
#define SHARE_LookUpEven_real32_T_real32_T_ZERO
#include "rtwtypes.h"

void LookUpEven_real32_T_real32_T_ZERO(real32_T *pY, const real32_T *pYData,
  real32_T u, real32_T valueLo, uint32_T iHi, real32_T uSpacing);

#endif

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
