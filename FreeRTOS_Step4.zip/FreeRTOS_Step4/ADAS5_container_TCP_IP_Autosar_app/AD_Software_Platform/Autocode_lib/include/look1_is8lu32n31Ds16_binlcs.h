/*
 * File: look1_is8lu32n31Ds16_binlcs.h
 *
 * Code generated for Simulink model 'ActivationManagement'.
 *
 * Model version                  : 1.19
 * Simulink Coder version         : 8.11 (R2016b) 25-Aug-2016
 * C/C++ source code generated on : Wed Dec 23 15:12:15 2020
 */

#ifndef SHARE_look1_is8lu32n31Ds16_binlcs
#define SHARE_look1_is8lu32n31Ds16_binlcs
#include "rtwtypes.h"

extern int8_T look1_is8lu32n31Ds16_binlcs(int8_T u0, const int8_T bp0[], const
  int8_T table[], uint32_T maxIndex);

#endif

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
