/*
 * File: look1_iflftu8Df_binlc.h
 *
 * Code generated for Simulink model 'Control_Lat'.
 *
 * Model version                  : V15_00_00_00_1.4366
 * Simulink Coder version         : 8.11 (R2016b) 25-Aug-2016
 * C/C++ source code generated on : Fri Dec 06 19:13:17 2019
 */

#ifndef SHARE_look1_iflftu8Df_binlc
#define SHARE_look1_iflftu8Df_binlc
#include "rtwtypes.h"

extern uint8_T look1_iflftu8Df_binlc(real32_T u0, const real32_T bp0[], const
  uint8_T table[], uint32_T maxIndex);

#endif

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
