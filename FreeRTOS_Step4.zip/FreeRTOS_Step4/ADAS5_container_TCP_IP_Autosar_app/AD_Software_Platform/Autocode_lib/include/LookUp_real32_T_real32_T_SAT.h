/*
 * File: LookUp_real32_T_real32_T_SAT.h
 *
 * Code generated for Simulink model 'Control_Lat'.
 *
 * Model version                  : V15_00_00_00_1.4366
 * Simulink Coder version         : 8.11 (R2016b) 25-Aug-2016
 * C/C++ source code generated on : Fri Dec 06 19:13:17 2019
 */

#ifndef SHARE_LookUp_real32_T_real32_T_SAT
#define SHARE_LookUp_real32_T_real32_T_SAT
#include "rtwtypes.h"

void LookUp_real32_T_real32_T_SAT(real32_T *pY, const real32_T *pYData, real32_T
  u, const real32_T *pUData, uint32_T iHi);

#endif

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
