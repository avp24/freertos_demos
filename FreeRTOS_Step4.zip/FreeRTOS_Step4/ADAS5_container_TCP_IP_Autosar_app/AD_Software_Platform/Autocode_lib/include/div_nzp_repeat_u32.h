/*
 * File: div_nzp_repeat_u32.h
 *
 * Code generated for Simulink model 'swcVehStatus_Out'.
 *
 * Model version                  : VehSTSOut002R_P33A
 * Simulink Coder version         : 8.11 (R2016b) 25-Aug-2016
 * C/C++ source code generated on : Tue Dec 10 20:13:09 2019
 */

#ifndef SHARE_div_nzp_repeat_u32
#define SHARE_div_nzp_repeat_u32
#include "rtwtypes.h"

extern uint32_T div_nzp_repeat_u32(uint32_T numerator, uint32_T denominator,
  uint32_T nRepeatSub);

#endif

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
