/*
 * File: MultiWord2sLong.h
 *
 * Code generated for Simulink model 'DAA'.
 *
 * Model version                  : 1.1038
 * Simulink Coder version         : 8.11 (R2016b) 25-Aug-2016
 * C/C++ source code generated on : Wed Dec 11 14:22:09 2019
 */

#ifndef SHARE_MultiWord2sLong
#define SHARE_MultiWord2sLong
#include "rtwtypes.h"

extern int32_T MultiWord2sLong(const uint32_T u[]);

#endif

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
