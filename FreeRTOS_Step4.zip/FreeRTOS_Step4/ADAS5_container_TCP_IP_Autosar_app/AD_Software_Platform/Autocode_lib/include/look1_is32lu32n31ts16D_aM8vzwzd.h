/*
 * File: look1_is32lu32n31ts16D_aM8vzwzd.h
 *
 * Code generated for Simulink model 'VehStatus_In'.
 *
 * Model version                  : VehSTS002K_P33A
 * Simulink Coder version         : 8.11 (R2016b) 25-Aug-2016
 * C/C++ source code generated on : Wed Mar 13 12:53:16 2019
 */

#ifndef SHARE_look1_is32lu32n31ts16D_aM8vzwzd
#define SHARE_look1_is32lu32n31ts16D_aM8vzwzd
#include "rtwtypes.h"

extern int16_T look1_is32lu32n31ts16D_aM8vzwzd(int32_T u0, const int32_T bp0[],
  const int16_T table[], uint32_T maxIndex);

#endif

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
