/*
 * File: look1_binlca.h
 *
 * Code generated for Simulink model 'CASP'.
 *
 * Model version                  : 1.68
 * Simulink Coder version         : 8.11 (R2016b) 25-Aug-2016
 * C/C++ source code generated on : Mon Jun 24 10:36:43 2019
 */

#ifndef SHARE_look1_binlca
#define SHARE_look1_binlca
#include "rtwtypes.h"

extern real_T look1_binlca(real_T u0, const real_T bp0[], const real_T table[],
  uint32_T maxIndex);

#endif

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
