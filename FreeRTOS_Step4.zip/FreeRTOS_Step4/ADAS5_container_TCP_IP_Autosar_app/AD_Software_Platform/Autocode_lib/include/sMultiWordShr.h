/*
 * File: sMultiWordShr.h
 *
 * Code generated for Simulink model 'CASP'.
 *
 * Model version                  : 1.39
 * Simulink Coder version         : 8.11 (R2016b) 25-Aug-2016
 * C/C++ source code generated on : Tue May 07 09:55:44 2019
 */

#ifndef SHARE_sMultiWordShr
#define SHARE_sMultiWordShr
#include "rtwtypes.h"

extern void sMultiWordShr(const uint32_T u1[], int32_T n1, uint32_T n2, uint32_T
  y[], int32_T n);

#endif

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
