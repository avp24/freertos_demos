/*
 * File: LookUpEven_real32_T_re_Yveszbl1.h
 *
 * Code generated for Simulink model 'Control_Longi'.
 *
 * Model version                  : V15_00_00_00_1.1695
 * Simulink Coder version         : 8.11 (R2016b) 25-Aug-2016
 * C/C++ source code generated on : Wed Mar 13 13:18:02 2019
 */

#ifndef SHARE_LookUpEven_real32_T_re_Yveszbl1
#define SHARE_LookUpEven_real32_T_re_Yveszbl1
#include "rtwtypes.h"

void LookUpEven_real32_T_re_Yveszbl1(real32_T *pY, const real32_T *pYData,
  real32_T u, real32_T valueLo, uint32_T iHi, real32_T uSpacing);

#endif

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
