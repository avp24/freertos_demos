/*
 * File: sMultiWordMul.h
 *
 * Code generated for Simulink model 'DAA'.
 *
 * Model version                  : 1.1038
 * Simulink Coder version         : 8.11 (R2016b) 25-Aug-2016
 * C/C++ source code generated on : Wed Dec 11 14:22:09 2019
 */

#ifndef SHARE_sMultiWordMul
#define SHARE_sMultiWordMul
#include "rtwtypes.h"

extern void sMultiWordMul(const uint32_T u1[], int32_T n1, const uint32_T u2[],
  int32_T n2, uint32_T y[], int32_T n);

#endif

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
