/*
 * File: look1_iflftu16Df_binlca.h
 *
 * Code generated for Simulink model 'Fusion'.
 *
 * Model version                  : 1.15995
 * Simulink Coder version         : 8.11 (R2016b) 25-Aug-2016
 * C/C++ source code generated on : Wed Nov 20 12:29:55 2019
 */

#ifndef SHARE_look1_iflftu16Df_binlca
#define SHARE_look1_iflftu16Df_binlca
#include "rtwtypes.h"

extern uint16_T look1_iflftu16Df_binlca(real32_T u0, const real32_T bp0[], const
  uint16_T table[], uint32_T maxIndex);

#endif

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
