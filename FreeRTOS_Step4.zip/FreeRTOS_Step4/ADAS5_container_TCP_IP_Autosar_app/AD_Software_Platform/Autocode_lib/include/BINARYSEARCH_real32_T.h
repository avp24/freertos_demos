/*
 * File: BINARYSEARCH_real32_T.h
 *
 * Code generated for Simulink model 'HOD'.
 *
 * Model version                  : V15_00_00_00_1.224
 * Simulink Coder version         : 8.11 (R2016b) 25-Aug-2016
 * C/C++ source code generated on : Fri Dec 06 19:02:44 2019
 */

#ifndef SHARE_BINARYSEARCH_real32_T
#define SHARE_BINARYSEARCH_real32_T
#include "rtwtypes.h"

void BINARYSEARCH_real32_T(uint32_T *piLeft, uint32_T *piRght, real32_T u, const
  real32_T *pData, uint32_T iHi);

#endif

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
