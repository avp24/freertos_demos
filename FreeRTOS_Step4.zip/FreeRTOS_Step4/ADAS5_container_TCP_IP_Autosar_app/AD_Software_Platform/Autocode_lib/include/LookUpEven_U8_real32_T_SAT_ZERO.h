/*
 * File: LookUpEven_U8_real32_T_SAT_ZERO.h
 *
 * Code generated for Simulink model 'CASP'.
 *
 * Model version                  : V15_00_00_00_1.607
 * Simulink Coder version         : 8.11 (R2016b) 25-Aug-2016
 * C/C++ source code generated on : Fri Dec 06 18:56:25 2019
 */

#ifndef SHARE_LookUpEven_U8_real32_T_SAT_ZERO
#define SHARE_LookUpEven_U8_real32_T_SAT_ZERO
#include "rtwtypes.h"

void LookUpEven_U8_real32_T_SAT_ZERO(uint8_T *pY, const uint8_T *pYData,
  real32_T u, real32_T valueLo, uint32_T iHi, real32_T uSpacing);

#endif

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
