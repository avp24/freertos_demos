/*
 * File: div_nde_s32_floor.h
 *
 * Code generated for Simulink model 'VehStatus_In'.
 *
 * Model version                  : VehSTS002Y_P33A
 * Simulink Coder version         : 8.11 (R2016b) 25-Aug-2016
 * C/C++ source code generated on : Fri Mar 06 20:50:07 2020
 */

#ifndef SHARE_div_nde_s32_floor
#define SHARE_div_nde_s32_floor
#include "rtwtypes.h"

extern int32_T div_nde_s32_floor(int32_T numerator, int32_T denominator);

#endif

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
