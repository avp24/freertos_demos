/*
 * File: look1_is32lu32n31Du32_binlcse.h
 *
 * Code generated for Simulink model 'VehStatus_In'.
 *
 * Model version                  : VehSTS002R_P33A
 * Simulink Coder version         : 8.11 (R2016b) 25-Aug-2016
 * C/C++ source code generated on : Wed Nov 06 18:50:41 2019
 */

#ifndef SHARE_look1_is32lu32n31Du32_binlcse
#define SHARE_look1_is32lu32n31Du32_binlcse
#include "rtwtypes.h"

extern int32_T look1_is32lu32n31Du32_binlcse(int32_T u0, const int32_T bp0[],
  const int32_T table[], uint32_T maxIndex);

#endif

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
