/*
 * File: look1_is32lu32n31ts16Ds32_binlcs.h
 *
 * Code generated for Simulink model 'swcVehStatus_Out'.
 *
 * Model version                  : VehSTSOut002R_P33A
 * Simulink Coder version         : 8.11 (R2016b) 25-Aug-2016
 * C/C++ source code generated on : Tue Dec 10 20:13:09 2019
 */

#ifndef SHARE_look1_is32lu32n31ts16Ds32_binlcs
#define SHARE_look1_is32lu32n31ts16Ds32_binlcs
#include "rtwtypes.h"

extern int16_T look1_is32lu32n31ts16Ds32_binlcs(int32_T u0, const int32_T bp0[],
  const int16_T table[], uint32_T maxIndex);

#endif

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
