/*
 * File: look1_binlc.h
 *
 * Code generated for Simulink model 'Control_Lat'.
 *
 * Model version                  : V15_00_00_00_1.4036
 * Simulink Coder version         : 8.11 (R2016b) 25-Aug-2016
 * C/C++ source code generated on : Fri Apr 26 09:34:02 2019
 */

#ifndef SHARE_look1_binlc
#define SHARE_look1_binlc
#include "rtwtypes.h"

extern real_T look1_binlc(real_T u0, const real_T bp0[], const real_T table[],
  uint32_T maxIndex);

#endif

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
