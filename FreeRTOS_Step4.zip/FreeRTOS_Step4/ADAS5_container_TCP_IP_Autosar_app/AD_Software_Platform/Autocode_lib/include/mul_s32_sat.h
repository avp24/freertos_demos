/*
 * File: mul_s32_sat.h
 *
 * Code generated for Simulink model 'OEM_DIAG'.
 *
 * Model version                  : OEMD007_P33A
 * Simulink Coder version         : 8.11 (R2016b) 25-Aug-2016
 * C/C++ source code generated on : Fri Nov 15 10:31:59 2019
 */

#ifndef SHARE_mul_s32_sat
#define SHARE_mul_s32_sat
#include "rtwtypes.h"

extern int32_T mul_s32_sat(int32_T a, int32_T b);

#endif

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
