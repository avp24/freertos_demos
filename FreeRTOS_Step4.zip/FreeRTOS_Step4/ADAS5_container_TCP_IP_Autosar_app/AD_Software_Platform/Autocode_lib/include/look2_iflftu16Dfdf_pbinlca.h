/*
 * File: look2_iflftu16Dfdf_pbinlca.h
 *
 * Code generated for Simulink model 'Fusion'.
 *
 * Model version                  : 1.15995
 * Simulink Coder version         : 8.11 (R2016b) 25-Aug-2016
 * C/C++ source code generated on : Wed Nov 20 12:29:55 2019
 */

#ifndef SHARE_look2_iflftu16Dfdf_pbinlca
#define SHARE_look2_iflftu16Dfdf_pbinlca
#include "rtwtypes.h"

extern uint16_T look2_iflftu16Dfdf_pbinlca(real32_T u0, real32_T u1, const
  real32_T bp0[], const real32_T bp1[], const uint16_T table[], uint32_T
  prevIndex[], const uint32_T maxIndex[], uint32_T stride);

#endif

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
