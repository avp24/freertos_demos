/*
 * File: look1_is16lu32n31Ds32_binlcs.h
 *
 * Code generated for Simulink model 'swcYAW'.
 *
 * Model version                  : YAW002D_P33A
 * Simulink Coder version         : 8.11 (R2016b) 25-Aug-2016
 * C/C++ source code generated on : Tue Dec 10 20:31:26 2019
 */

#ifndef SHARE_look1_is16lu32n31Ds32_binlcs
#define SHARE_look1_is16lu32n31Ds32_binlcs
#include "rtwtypes.h"

extern int16_T look1_is16lu32n31Ds32_binlcs(int16_T u0, const int16_T bp0[],
  const int16_T table[], uint32_T maxIndex);

#endif

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
