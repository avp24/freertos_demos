/*
 * File: MultiWord2uLong.h
 *
 * Code generated for Simulink model 'DAA'.
 *
 * Model version                  : 1.1038
 * Simulink Coder version         : 8.11 (R2016b) 25-Aug-2016
 * C/C++ source code generated on : Wed Dec 11 14:22:09 2019
 */

#ifndef SHARE_MultiWord2uLong
#define SHARE_MultiWord2uLong
#include "rtwtypes.h"

extern uint32_T MultiWord2uLong(const uint32_T u[]);

#endif

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
