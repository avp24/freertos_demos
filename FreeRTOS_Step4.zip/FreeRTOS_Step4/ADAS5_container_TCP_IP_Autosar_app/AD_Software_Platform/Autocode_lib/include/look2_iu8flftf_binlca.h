/*
 * File: look2_iu8flftf_binlca.h
 *
 * Code generated for Simulink model 'Control_Longi'.
 *
 * Model version                  : V14_00_00_00_1.2235
 * Simulink Coder version         : 8.11 (R2016b) 25-Aug-2016
 * C/C++ source code generated on : Fri Dec 06 19:21:22 2019
 */

#ifndef SHARE_look2_iu8flftf_binlca
#define SHARE_look2_iu8flftf_binlca
#include "rtwtypes.h"

extern real32_T look2_iu8flftf_binlca(uint8_T u0, real32_T u1, const uint8_T
  bp0[], const real32_T bp1[], const real32_T table[], const uint32_T maxIndex[],
  uint32_T stride);

#endif

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
