# [SDV_EPIC_V_CONTAINER_001] Step1 : Single Container Creation

## RTE Wrapper Shared Object Creation
