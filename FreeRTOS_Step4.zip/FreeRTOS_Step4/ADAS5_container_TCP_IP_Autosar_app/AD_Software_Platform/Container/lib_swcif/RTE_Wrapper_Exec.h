#ifndef RTE_WRAPPER_EXEC_H
#define RTE_WRAPPER_EXEC_H

#include "Rte_Special_Replacement.h"
#include "Rte_Union.h"
#include "Rte_OEM_SWC_C1_1.h"


extern void OEM_SWC_C1_1_Input_Run_Step(void);
extern void OEM_SWC_C1_1_input_From_OEM(void);
extern void OEM_SWC_C1_1_output(void);



extern void OEM_SWC_C0_SM_input_From_SUP(void);
extern void OEM_SWC_C0_SM_input_From_OEM(void);
extern void OEM_SWC_C0_SM_output(void);



#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */


extern void RTE_Wrapper_Init(void);
extern void RTE_Wrapper_Exec_C1_Input(void);
extern void RTE_Wrapper_Exec_C1_Output(void);
extern void RTE_Wrapper_Exec_C0_Input(void);
extern void RTE_Wrapper_Exec_C0_Output(void);

#ifdef __cplusplus
}
#endif /* __cplusplus */


#endif /* RTE_WRAPPER_EXEC_H*/