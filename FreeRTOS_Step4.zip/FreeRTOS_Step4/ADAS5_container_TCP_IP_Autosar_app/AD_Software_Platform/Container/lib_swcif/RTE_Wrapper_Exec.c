#include "RTE_Wrapper_Exec.h"

void RTE_Wrapper_Init()
{
	printf("RTE_Wrapper_Exec :: RTE_Wrapper_Init\n");

	#ifndef OEMRAMCLEAR_C1_DISABLE
	OEMRAMClear_C1_Run_PowerOn_Init();
	#endif

}



void RTE_Wrapper_Exec_C1_Input()
{
    /* input */
	
	OEM_SWC_C1_1_Input_Run_Step();
	
	OEM_SWC_C1_1_input_From_OEM();
	
}

	
	
	
	
	
void RTE_Wrapper_Exec_C1_Output()
{
	/* output */

	OEM_SWC_C1_1_output();
	
}




void RTE_Wrapper_Exec_C0_Input()
{
	/* input */
	
	OEM_SWC_C0_SM_input_From_SUP();
	
	OEM_SWC_C0_SM_input_From_OEM();

}


void RTE_Wrapper_Exec_C0_Output()
{
	/* output */
	OEM_SWC_C0_SM_output();
}
