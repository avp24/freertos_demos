# [SDV_EPIC_V_CONTAINER_001] Step1 : Single Container Creation

Scope of the Activity is to check the feasibility of creating the ADAS5 Application Container  and get the Know how and list the Challenges.

In the step 1 we are going to create the one Container of the ADAS5 Application by Integrating the Transversal Components and Core logic of the FEBFCWDBA Component, and also create the container of the Test Environment for the validation of ADAS5 Application (FEBBCWDBA).
Here we are are also going to create gRPC layer for the Communication of the application Container and Test environment Container.


# Step to Build the FEB Application

##### Step 1 - Building all Static Libraries	
-> Go to the Path  "project_sq_v_suv_b1/AD_Software_Platform/Container/integ_app/lib"<br>
-> For cleaning all Common  and SWC's static libraries Run the Command "make clean -f Makefile_lib"<br>
-> For Building all Common and SWC's static libraries Run the Command "make -f Makefile_lib"<br>
-> All Static libraries will be generated inside "integ_app/lib"
##### Step 2 - Adding Path to Environmnet Varibale	
-> Go to the Path  "project_sq_v_suv_b1/AD_Software_Platform/Container/"<br>
-> Run the Command "export LD_LIBRARY_PATH=./"
##### Step 3 - Building libRTEWrapper .so 
-> goto the path "lib_swcif"<br>
-> run "make" Command<br> 
-> target libRTEWrapper .so will be generated inside Container/integ_app/dist folder
##### Step 4 - Building libswc_Transversal.so 
-> goto the path "lib_transversal"<br>
-> run "make" Command<br> 
-> target libswc_Transversal.so will be generated inside Container/integ_app/dist folder
##### Step 5 - Building libswc_FEBFCWDBA.so 
-> goto the path "lib_febfcwdba"<br>
-> run "make" Command <br>
-> target libswc_FEBFCWDBA.so will be generated inside Container/integ_app/dist folder
##### Step 6 - Building libswc_FEBFCWDBA_Integ.so
-> goto the path "integ_app\src"<br>
-> run "make clean -f Makefile_so" Command to clean.<br>
-> run "make -f Makefile_so" Command for building the libswc_FEBFCWDBA_Integ.so
##### Step 7 - Creating gRPC and ProtoBuffers Source and header files
-> goto the path "proto"<br>
-> run "make clean" Command to clean.<br>
-> run "make" to generate the .cc and .h files.
##### Step 8 - Building final swc_FEBFCWDBA_Exec.out file 
-> goto the path "integ_app\src"<br>
-> run "make clean -f Makefile_out" Command to clean.<br>
-> run "make -f Makefile_out" Command for building the final Main application .out file


# Step to Run the FEB Application

##### Step 1 - Adding Path to Environmnet Varibale	
-> Go to the Path  "project_sq_v_suv_b1/AD_Software_Platform/Container/"<br>
-> Run the Command "export LD_LIBRARY_PATH=./"

##### Step 2 - Running Main Application .out file 
-> goto the path "integ_app\dist"<br>
-> Configure the Server Address address in the address_config.txt file <br>
    e.g. <br>
	[ADDRESS_SETTING]<br>
	Server_Address=127.0.0.1<br>
	Port=50051<br>
	address_config.txt - address_config.txt file path needs to be pass from the argument for execution of the Application.<br>
-> run "./swc_FEBFCWDBA_Exec.out address_config.txt" Command running Main application .out file

# Step to Build the Test Environmnet 

-> Go to the Path  "Container/test_env/src"<br>
-> Run the Command "make clean" to clean the source file.<br>
-> Run the Command "make" to create TestApplicationMain.out

# Step to Run the Test Environmnet 
 
-> Go to the Path  "Container/test_env/dist"<br>
-> Run the Command "./TestApplicationMain.out ../integ_config.txt"<br>
integ_config.txt -> It is the file which container the path of the input and output csv files and the Configuraion of the Address and port of the Server.