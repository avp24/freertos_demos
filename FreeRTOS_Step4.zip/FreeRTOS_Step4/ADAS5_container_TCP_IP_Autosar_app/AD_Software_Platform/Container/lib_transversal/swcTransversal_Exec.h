#ifndef SWC_TRANSVERSAL_EXEC_H
#define SWC_TRANSVERSAL_EXEC_H

#include "Rte_Union.h"

extern void VehStatus_In_Run_Init();
extern void CAM_RAD_Run_Init();
extern void DiagControl_Run_Init();
extern void ActivationManagement_Run_Init();
extern void OEM_DIAG_Run_Init();
extern void FS_ACT_Run_Init();
extern void YAW_Run_Init();
extern void BRK_ENG_Run_Init();
extern void HMI_Run_Init();
extern void VehStatus_Out_Run_Init();
extern void EDR_Run_Init();


extern void SafetyModule_Run_Init();
extern void VehStatus_In_Run_Step();
extern void CAM_RAD_Run_Step();
extern void DiagControl_Run_Step();
extern void ActivationManagement_Run_Step();
extern void OEM_DIAG_Run_Step();
extern void FS_ACT_Run_Step();
extern void YAW_Run_Step();
extern void BRK_ENG_Run_Step();
extern void HMI_Run_Step();
extern void VehStatus_Out_Run_Step();
extern void EDR_Run_Step();
extern void SafetyModule_Run_Step();

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

void swcTransversal_Init(void);
void swcFEBFCWDBA_Input_Run_Step(void);
void swcFEBFCWDBA_Output_Run_Step(void);
void swcTransversal_SafetyModule_Run_Init(void);
void swcTransversal_SafetyModule_Run_Step(void);


#ifdef __cplusplus
}
#endif /* __cplusplus */



#endif /* SWC_TRANSVERSAL_EXEC_H*/