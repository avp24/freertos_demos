#include "swcTransversal_Exec.h"

void swcTransversal_Init()
{
	printf("swcTransversal_Exec :: Inside swcTransversal_Init\n");
	
    VehStatus_In_Run_Init();
	CAM_RAD_Run_Init();
	DiagControl_Run_Init();
	ActivationManagement_Run_Init();
	OEM_DIAG_Run_Init();
	FS_ACT_Run_Init();
	YAW_Run_Init();
	BRK_ENG_Run_Init();
	HMI_Run_Init();
	VehStatus_Out_Run_Init();
	EDR_Run_Init();
}

void swcTransversal_SafetyModule_Run_Init()
{
	SafetyModule_Run_Init();
}



void swcFEBFCWDBA_Input_Run_Step()
{
	VehStatus_In_Run_Step();
	CAM_RAD_Run_Step();
	DiagControl_Run_Step();
	ActivationManagement_Run_Step();
	OEM_DIAG_Run_Step();
	FS_ACT_Run_Step();
}


void swcTransversal_SafetyModule_Run_Step()
{
	SafetyModule_Run_Step();
}




void swcFEBFCWDBA_Output_Run_Step()
{
    YAW_Run_Step();
	BRK_ENG_Run_Step();
	HMI_Run_Step();
	VehStatus_Out_Run_Step();
	EDR_Run_Step();
}
