#include "Address_Config.hpp"
#include <stdio.h>
#include <cstring>

std::string address;
std::string port;

std::string Address_Config::InitializeExpected_add_conf(const std::string settingFileName_i)
{
	const std::string TEST_SETTING_SECTION = "[ADDRESS_SETTING]";
	address = getKeyValueString_Tx_add_conf(settingFileName_i, TEST_SETTING_SECTION, "Server_Address");
	port = getKeyValueString_Tx_add_conf(settingFileName_i, TEST_SETTING_SECTION, "Port");
	cout<<"Server_Address : "<<address<<endl;
	cout<<"Port : "<<port<<endl;
	std::string temp_address = address + ":" + port;
    return temp_address;
}


std::string Address_Config::getKeyValueString_Tx_add_conf(const std::string fileName_i, const std::string section_i, const std::string key_i)
{
	std::ifstream fileStream;
	fileStream.open(fileName_i, std::ios::in);
	if (!fileStream.is_open())
	{
		std::cout << "[ERROR] : Cannot open file : " << fileName_i << " !! " << std::endl;
		return "";
	}
	std::string line;
	while (std::getline(fileStream, line))
	{
		if (line.find(section_i) == 0)
		{
			break;
		}
	}

	while (std::getline(fileStream, line))
	{
		std::stringstream ss(line);
		std::string bufferString;
		std::queue<std::string> tempStrQueue;
		while (std::getline(ss, bufferString, '='))
		{
			tempStrQueue.push(bufferString);
		}

		if (tempStrQueue.front() == key_i)
		{
			tempStrQueue.pop();
			fileStream.close();
			return removeNewLineChar_Tx_add_conf(tempStrQueue.front());
		}
	}
	std::cout << " Not found ! " << key_i << std::endl;
	fileStream.close();
	return "";
}

std::string Address_Config::removeNewLineChar_Tx_add_conf(const std::string inputString)
{
	if (inputString[inputString.length() - 1] == '\r')
	{
		std::string tempBuf = inputString;
		tempBuf.erase(inputString.length() - 1);
		return tempBuf;
	}
	return inputString;
}