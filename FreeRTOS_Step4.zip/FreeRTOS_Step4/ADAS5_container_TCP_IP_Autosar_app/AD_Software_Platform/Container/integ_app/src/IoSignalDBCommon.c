#include <stdlib.h>

#include "IoSignalDBInfo.h"

#undef DEBUG

#ifdef DEBUG
#define debug(fmt, ...) fprintf(stderr, "[IoDB] %s: " fmt, __func__, ##__VA_ARGS__)
#else
#define debug(fmt, ...) (void)0
#endif

static int check_parameter_name(const char* name, void* info, EDBTYPE eType)
{
	int ret;

	if (eType == eSIGNALDB) {
		const ST_SIGNAL_INFO *pSignalInfo = (const ST_SIGNAL_INFO*)info;

		ret = strcmp(name, pSignalInfo->name);
		if (0 != ret) {
			ret = strcmp(name, pSignalInfo->rtename);
		}
	}
	else {
		const ST_SIGNAL_INFO_BUS *pBusSignalInfo = (const ST_SIGNAL_INFO_BUS*)info;
		int buffLen = strlen(pBusSignalInfo->busName);

		if (NULL == strchr(name, '.'))
		{
			char buffer[buffLen];
			strcpy(buffer, pBusSignalInfo->busName);
			ret = strcmp(name, buffer);
		}
		else
		{
			buffLen += strlen(pBusSignalInfo->busMemName) + 1;
			if (strcmp(pBusSignalInfo->busBusMemName, "None"))
			{
				buffLen += (1 + strlen(pBusSignalInfo->busBusMemName));
			}
			char buffer[buffLen];
			strcpy(buffer, pBusSignalInfo->busName);
			strcat(buffer, ".");
			strcat(buffer, pBusSignalInfo->busMemName);
			if (strcmp(pBusSignalInfo->busBusMemName, "None"))
			{
				strcat( buffer, "." );
				strcat( buffer, pBusSignalInfo->busBusMemName );
			}
			ret = strcmp(name, buffer);
		}
	}

	return ret;
}

static int get_data_type_size(EDATATYPE eDataType)
{
	int size = 0;

	switch (eDataType) {
	case eBOOL:
	case eUINT8:
		size = sizeof(unsigned char);
		break;
	case eUINT16:
		size = sizeof(unsigned short);
		break;
	case eUINT32:
		size = sizeof(unsigned int);
		break;
	case eUINT64:
		size = sizeof(unsigned long long);
		break;
	case eINT8:
		size = sizeof(char);
		break;
	case eINT16:
		size = sizeof(short);
		break;
	case eINT32:
		size = sizeof(int);
		break;
	case eINT64:
		size = sizeof(long long);
		break;
	case eFLOAT:
		size = sizeof(float);
		break;
	case eDOUBLE:
		size = sizeof(double);
		break;
	default :
		break;
	}

	return size;
}

void *io_search_info(const char* name, EDBTYPE eType)
{
	int i;
	void *info = NULL;

	if (eType == eSIGNALDB) {
		for (i = 0; i < io_signalinfo_size; i++) {
			if (check_parameter_name(name, (void *)&io_signal_info[i], eType) == 0) {
				info = (void *)&io_signal_info[i];
				break;
			}
		}
	}
	else {
		for (i = 0; i < io_businfo_size; i++) {
			if (check_parameter_name(name, (void *)&io_bus_info[i], eType) == 0) {
				info = (void *)&io_bus_info[i];
				break;
			}
		}
	}

	return info;
}

static int get_value_str(char *buf, int buf_size, EDATATYPE eDataType, void* addr)
{
	int setSize = 0;
	char tmp[128];

	switch (eDataType) {
	case eBOOL:
	case eUINT8:
		snprintf(tmp, sizeof(tmp), "%u", *((unsigned char *)addr));
		setSize = strlen(tmp);
		break;
	case eUINT16:
		snprintf(tmp, sizeof(tmp), "%u", *((unsigned short *)addr));
		setSize = strlen(tmp);
		break;
	case eUINT32:
		snprintf(tmp, sizeof(tmp), "%u", *((unsigned int *)addr));
		setSize = strlen(tmp);
		break;
	case eUINT64:
		snprintf(tmp, sizeof(tmp), "%llu", *((unsigned long long *)addr));
		setSize = strlen(tmp);
		break;
	case eINT8:
		snprintf(tmp, sizeof(tmp), "%d", *((char *)addr));
		setSize = strlen(tmp);
		break;
	case eINT16:
		snprintf(tmp, sizeof(tmp), "%d", *((short *)addr));
		setSize = strlen(tmp);
		break;
	case eINT32:
		snprintf(tmp, sizeof(tmp), "%d", *((int *)addr));
		setSize = strlen(tmp);
		break;
	case eINT64:
		snprintf(tmp, sizeof(tmp), "%lld", *((long long *)addr));
		setSize = strlen(tmp);
		break;
	case eFLOAT:
		snprintf(tmp, sizeof(tmp), "%f", *((float *)addr));
		setSize = strlen(tmp);
		break;
	case eDOUBLE:
		snprintf(tmp, sizeof(tmp), "%lf", *((double *)addr));
		setSize = strlen(tmp);
		break;
	default :
		return 0;
	}

	if (buf_size <= setSize) {
		debug("lack of buffer (%d < %d)\n", buf_size, setSize);
		return 0;
	}

	strcpy(buf, tmp);
	return setSize;
}

static int set_value_str(const char *value, EDATATYPE eDataType, void* addr)
{
	int val_int;
	long long val_llong;
	unsigned int val_uint;
	unsigned long long val_ullong;
	float val_fl;
	double val_dbl;

	int setSize = get_data_type_size(eDataType);

	switch (eDataType) {
	case eBOOL:
	case eUINT8:
		val_uint = strtoul(value, NULL, 10);
		*((unsigned char *)addr) = val_uint;
		break;
	case eUINT16:
		val_uint = strtoul(value, NULL, 10);
		*((unsigned short *)addr) = val_uint;
		break;
	case eUINT32:
		val_uint = strtoul(value, NULL, 10);
		*((unsigned int *)addr) = val_uint;
		break;
	case eUINT64:
		val_ullong = strtoull(value, NULL, 10);
		*((unsigned long long *)addr) = val_ullong;
		break;
	case eINT8:
		val_int = strtol(value, NULL, 10);
		*((char *)addr) = val_int;
		break;
	case eINT16:
		val_int = strtol(value, NULL, 10);
		*((short *)addr) = val_int;
		break;
	case eINT32:
		val_int = strtol(value, NULL, 10);
		*((int *)addr) = val_int;
		break;
	case eINT64:
		val_llong = strtoll(value, NULL, 10);
		*((int *)addr) = val_llong;
		break;
	case eFLOAT:
		val_fl = strtof(value, NULL);
		*((float *)addr) = val_fl;
		break;
	case eDOUBLE:
		val_dbl = strtod(value, NULL);
		*((double *)addr) = val_dbl;
		break;
	default :
		break;
	}

	return setSize;
}

#define SET_CHAR(p, c, e, s)					\
	do {										\
		if (p < e) {							\
			*p = c;								\
			ptr++;								\
			s--;								\
		}										\
	} while(0)

int io_get_param_value(char *buf, int buf_size, const char *name, EDBTYPE eType)
{
	int setSize, dataTypeSize;
	int i, size = buf_size;
	void *pDbInfo;
	int array;
	EDATATYPE eDataType;
	void *addr;
	char *ptr = buf, *buf_end = buf + buf_size;

	pDbInfo = io_search_info(name, eType);
	if (pDbInfo == NULL) {
		debug("Not found %s (%d)\n", name, eType == eSIGNALDB ? "SIGNAL" : "BUS");
		return 0;
	}

	if (eType == eSIGNALDB) {
		const ST_SIGNAL_INFO *pSignalInfo = (const ST_SIGNAL_INFO *)pDbInfo;

		array = pSignalInfo->array;
		eDataType = pSignalInfo->eDataType;
		addr = pSignalInfo->addr;
	}
	else {
		const ST_SIGNAL_INFO_BUS *pBusSignalInfo = pDbInfo;

		array = pBusSignalInfo->array;
		eDataType = pBusSignalInfo->eDataType;
		addr = pBusSignalInfo->addr;
	}

	for (i = 0; i < array; i++) {
		if (array > 1 && i == 0) {
			SET_CHAR(ptr, '\"', buf_end, size);
		}
		dataTypeSize = get_data_type_size(eDataType);
		setSize = get_value_str(ptr, size, eDataType, addr);
		if (setSize == 0) {
			debug("Cannot get %s value\n", name);
		}
		addr += dataTypeSize;
		ptr += setSize;
		size -= setSize;

		if (array > 1) {
			if (i < array - 1) {
				SET_CHAR(ptr, ',', buf_end, size);
			} else {
				SET_CHAR(ptr, '\"', buf_end, size);
				SET_CHAR(ptr, '\0', buf_end, size);
			}
		}
	}

	return 1;
}

int io_set_param_value(const char *name, const char *value, EDBTYPE eType)
{
	int setSize;
	int i;
	void *pDbInfo;
	int array;
	EDATATYPE eDataType;
	void *addr;
	const char *ptr = value;
	char *temp1, *temp2;

	pDbInfo = io_search_info(name, eType);
	if (pDbInfo == NULL) {
		debug("Not found %s (%d)\n", name, eType == eSIGNALDB ? "SIGNAL" : "BUS");
		return 0;
	}

	if (eType == eSIGNALDB) {
		const ST_SIGNAL_INFO *pSignalInfo = (const ST_SIGNAL_INFO *)pDbInfo;

		array = pSignalInfo->array;
		eDataType = pSignalInfo->eDataType;
		addr = pSignalInfo->addr;
	}
	else {
		const ST_SIGNAL_INFO_BUS *pBusSignalInfo = pDbInfo;

		array = pBusSignalInfo->array;
		eDataType = pBusSignalInfo->eDataType;
		addr = pBusSignalInfo->addr;
	}

	ptr = strtok_r(ptr, "}", &temp1);
	if (*ptr == ',') {
		ptr++;
	}
	if (*ptr == '{') {
		ptr++;
	}
	for (i = 0; i < array; i++) {
		char *val = strtok_r((i == 0) ? ptr : NULL, ",", &temp2);
		if (val != NULL) {
			setSize = set_value_str(val, eDataType, addr);
			addr += setSize;
		}
	}

	return 1;
}
