#ifndef _IOSIGNALDBINFO_H_
#define _IOSIGNALDBINFO_H_

#include "SignalDBInfo.h"

extern const ST_SIGNAL_INFO io_signal_info[];
extern const ST_SIGNAL_INFO_BUS io_bus_info[];
extern const int io_signalinfo_size;
extern const int io_businfo_size;

#ifdef __cplusplus
extern "C" {
#endif

void *io_search_info(const char* name, EDBTYPE eType);
int io_get_param_value(char *buf, int buf_size, const char *name, EDBTYPE eType);
int io_set_param_value(const char *name, const char *value, EDBTYPE eType);

#ifdef __cplusplus
}
#endif

#endif	/*_IOSIGNALDBINFO_H_ */
