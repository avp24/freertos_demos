#include <iostream>
#include <string>
#include <vector>
#include <cstring>
#include <arpa/inet.h>
#include <unistd.h>
#include <sstream>

// Removed Address_Config integration

#include "swcTransversal_Exec.h"
#include "swcFEBFCWDBA_Exec.h"
#include "RTE_Wrapper_Exec.h"

/* External SWC functions */
extern "C" {
    void swcInitialize(void);
    void swcExecute(void);
    bool getParameterValue(char*, int, const char*, int);
    bool setParameterValue(const char*, const char*, int);
}

/* Output signals */
std::vector<std::string> output_signal_name = {
    "Output1", "Output2" // Replace with actual SWC output signal names
};

#define BUFFER_SIZE 4096

/* =================== TCP Client Function ==================== */
int ConnectToServer(const std::string &ip, int port) {
    int sock = socket(AF_INET, SOCK_STREAM, 0);
    if (sock < 0) {
        perror("[ERROR] Socket creation failed");
        exit(EXIT_FAILURE);
    }

    struct sockaddr_in server_addr;
    memset(&server_addr, 0, sizeof(server_addr));
    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(port);

    if (inet_pton(AF_INET, ip.c_str(), &server_addr.sin_addr) <= 0) {
        perror("[ERROR] Invalid IP address");
        close(sock);
        exit(EXIT_FAILURE);
    }

    if (connect(sock, (struct sockaddr *)&server_addr, sizeof(server_addr)) < 0) {
        perror("[ERROR] Connection to server failed");
        close(sock);
        exit(EXIT_FAILURE);
    }

    std::cout << "[INFO] Connected to TCP Server at " << ip << ":" << port << "\n";
    return sock;
}

int main(int argc, char* argv[]) {
    if (argc != 3) {
        std::cerr << "[ERROR] Usage: " << argv[0] << " <IP_Address> <Port>\n";
        return -1;
    }

    std::string ip = argv[1];
    int port = std::stoi(argv[2]);

    std::cout << "#######################################################################\n";
    std::cout << "###        AUTOSAR Application - TCP Client (FreeRTOS Server)     ###\n";
    std::cout << "#######################################################################\n";

    // Initialize SWC
    std::cout << "[INFO] Initializing SWC...\n";
    swcInitialize();

    // Connect to TCP Server
    int sock = ConnectToServer(ip, port);

    // ✅ Initial handshake logic
    std::cout << "[INFO] Connection established successfully!\n";
    std::string initial_msg = "HELLO_FROM_CLIENT_INIT";
    send(sock, initial_msg.c_str(), initial_msg.size(), 0);
    std::cout << "[INFO] Sent initial handshake message: " << initial_msg << "\n";

    char buffer[BUFFER_SIZE];
    memset(buffer, 0, BUFFER_SIZE);
    int valread = recv(sock, buffer, BUFFER_SIZE, 0);
    if (valread > 0) {
        std::cout << "[INFO] Server response: " << buffer << "\n";
    } else {
        std::cout << "[WARNING] No response from server on initial handshake.\n";
    }

    // Main Execution Loop
    std::cout << "[INFO] Starting main execution loop...\n";

    while (true) {
        memset(buffer, 0, BUFFER_SIZE);
        int valread = recv(sock, buffer, BUFFER_SIZE, 0);
        if (valread <= 0) {
            std::cout << "[INFO] Server disconnected or no more data. Exiting...\n";
            break;
        }

        std::string input_str(buffer);
        std::cout << "[INFO] Received input signals: " << input_str << "\n";

        // Split received data
        std::vector<std::string> inputs;
        std::istringstream iss(input_str);
        std::string token;
        while (std::getline(iss, token, ',')) {
            inputs.push_back(token);
        }

        if (inputs.empty()) {
            std::cout << "[INFO] No input signals. Exiting loop.\n";
            break;
        }

        // Write inputs to RTE
        for (size_t i = 0; i < inputs.size(); ++i) {
            std::string paramName = "InputSignal" + std::to_string(i);
            setParameterValue(paramName.c_str(), inputs[i].c_str(), 0);
        }

        // Execute SWC logic
        std::cout << "[INFO] Executing SWC...\n";
        swcExecute();

        // Collect outputs
        std::vector<std::string> outputs;
        char out_buffer[50];
        for (const auto& name : output_signal_name) {
            if (getParameterValue(out_buffer, sizeof(out_buffer), name.c_str(), 0)) {
                outputs.push_back(out_buffer);
            } else {
                outputs.push_back("NA");
            }
        }

        // Add verification string
        outputs.push_back("HELLO_FROM_CLIENT");

        // Prepare output string
        std::string output_str;
        for (size_t i = 0; i < outputs.size(); ++i) {
            output_str += outputs[i];
            if (i != outputs.size() - 1) output_str += ",";
        }

        // Send outputs back to server
        send(sock, output_str.c_str(), output_str.size(), 0);
        std::cout << "[INFO] Sent outputs: " << output_str << "\n";
    }

    close(sock);
    std::cout << "[INFO] Execution completed successfully.\n";
    return 0;
}

