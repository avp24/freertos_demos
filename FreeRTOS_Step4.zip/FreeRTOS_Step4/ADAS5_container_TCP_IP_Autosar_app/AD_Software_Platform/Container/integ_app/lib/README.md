# [SDV_EPIC_V_CONTAINER_001] Step1 : Single Container Creation

## lib folder - all static libraries generated from swc present here

# Static Libraries generation process :

### 1. For cleaning the all SWC's and Common Libraries static libraries use <br>' make clean -f Makefile_lib'

### 2. For Building the all SWC's and Common Libraries static libraries use <br>' make -f Makefile_lib'