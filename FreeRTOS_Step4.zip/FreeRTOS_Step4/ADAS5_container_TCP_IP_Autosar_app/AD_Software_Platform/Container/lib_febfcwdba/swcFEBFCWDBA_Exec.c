#include "swcFEBFCWDBA_Exec.h"

void swcFEBFCWDBA_Init()
{
	printf("swcFEBFCWDBA_Exec :: Inside swcFEBFCWDBA_Init\n");
	FEBFCWDBA_Run_Init();
}


void swcFEBFCWDBA_Run_Step()
{
	FEBFCWDBA_Run_Step();
}

