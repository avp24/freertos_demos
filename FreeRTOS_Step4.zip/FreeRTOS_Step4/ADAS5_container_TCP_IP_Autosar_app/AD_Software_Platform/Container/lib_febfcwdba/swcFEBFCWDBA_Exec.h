#ifndef SWC_FEBFCWDBA_EXEC_H
#define SWC_FEBFCWDBA_EXEC_H


#include "Rte_Special_Replacement.h"
#include "Rte_Union.h"
#include "Rte_OEM_SWC_C1_1.h"


extern void FEBFCWDBA_Run_Init(void);
extern void FEBFCWDBA_Run_Step(void);


#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */


void swcFEBFCWDBA_Init(void);
void swcFEBFCWDBA_Run_Step(void);

#ifdef __cplusplus
}
#endif /* __cplusplus */



#endif /* SWC_FEBFCWDBA_EXEC_H*/