# [SDV_EPIC_V_CONTAINER_001] Step1 : Single Container Creation

## Shared Object (.so) file creation of the Core Logic of the FEB Application.