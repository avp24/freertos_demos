#ifndef _Output
#define _Output
#include <vector>
#include <fstream>
#include <iostream>
#include <string>
#include <sstream>
#include <queue>
#include <stdlib.h>
#include <stdbool.h>
#include <stdint.h>


using namespace std;

class Output{
public:

	 std::string OutputLogFileName;
	 std::string OutputLogFileName_temp;
	 std::string OutputCsvFileName;
	 std::string OutputCsvFileName_temp;
	 std::string OutputLogFileName_Tx;
	 std::ifstream OutputLogFileStream_Tx;
	 std::string OutputCsvFileName_Tx;
	 std::ofstream OutputCsvFileStream_Tx;
	 
	 bool initialize_Rx();
	 std::vector<std::string> ReadOutputLog_ParamName_Rx();
	 
	 void InitializeExpected_Output(const std::string settingFileName_i);
	 
	 std::string removeNewLineChar_OP(const std::string inputString);
	 std::string getKeyValueString_OP(const std::string fileName_i, const std::string section_i, const std::string key_i);

     bool Write_OutputVar(std::vector<std::string> OpData_Var);
     bool Write_OutputValue_newLine();
	 bool Write_OutputValue(std::string OpData_Vec);

};
#endif	
