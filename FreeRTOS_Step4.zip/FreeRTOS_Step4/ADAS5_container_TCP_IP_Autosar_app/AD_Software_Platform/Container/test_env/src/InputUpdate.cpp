#include "InputSignal.hpp"
#include <stdio.h>
#include <cstring>

void Input::InitializeExpected(const std::string settingFileName_i)
{
	const std::string TEST_SETTING_SECTION = "[TEST_SETTING]";
	InputFileName_temp = getKeyValueString_Tx(settingFileName_i, TEST_SETTING_SECTION, "Input_Data");
	
	std::string filePath(settingFileName_i);


   size_t found = filePath.find_last_of("/\\");
   if (found != std::string::npos) 
       InputFileName = settingFileName_i.substr(0, found) + InputFileName_temp;
   else
	   InputFileName = InputFileName_temp;
	
   cout<<"InputFileName "<<InputFileName<<endl;

}

int Input::No_of_Rows(const string fileName_i)
{
    int rows = 0;
	myResultFileName_Tx = string(fileName_i) + ".csv";
	myResultFileStream_Tx.open(myResultFileName_Tx, std::ios::in);

	if (!myResultFileStream_Tx.is_open())
	{
		std::cout << " [WARNING] : Cannot open expected result File : " << myResultFileName_Tx << " !! " << std::endl;
		return -1;
	}

	string line;
    while (getline(myResultFileStream_Tx, line))
    rows++;
    myResultFileStream_Tx.close();
	return rows;
}

std::vector<std::string> Input::initialize_Tx(const string fileName_i)
{

	myResultFileName_Tx = string(fileName_i) + ".csv";
	myResultFileStream_Tx.open(myResultFileName_Tx, std::ios::in);
	if (!myResultFileStream_Tx.is_open())
	{
		std::cout << " [WARNING] : Cannot open expected result File : " << myResultFileName_Tx << " !! " << std::endl;
		return;
	}

	std::vector<std::string> temp_myParamNameVec_Tx = ReadParameterName_Tx();
	return temp_myParamNameVec_Tx;
}

std::vector<std::string> Input::ReadParameterName_Tx(void)
{
	const char CR = '\r';
	const char LF = '\n';
	std::string parameterNameLine;
	std::getline(myResultFileStream_Tx, parameterNameLine);
	myLineCnt++;
	std::string bufferString;
	std::stringstream tempString(parameterNameLine);

	while (std::getline(tempString, bufferString, ','))
	{
		std::string buff = "";
		for (const auto c : bufferString)
		{
			if ((c != CR) && (c != LF))
			{
				buff += c;
			}
		}
		if (buff != "")
		{
			bufferString = buff;
		}
		myParamNameVec_Tx.push_back(bufferString);
	}
return myParamNameVec_Tx;
}


std::vector<std::string>  Input::Update_input(void)
{
	std::string tempValueLine;
	std::getline(myResultFileStream_Tx, tempValueLine);
	myLineCnt++;
	std::string bufferString;
	std::stringstream tempString(tempValueLine);
	std::vector<std::string> valueStringVec;
	int paramCnt = 0;

	while (std::getline(tempString, bufferString, ','))
	{
		paramCnt++;
		if (bufferString == "\r")
		{
			bufferString = "0";
			printf(" [WARNING] Expected value is blank (Line %d, Nth = %d)\n", myLineCnt, paramCnt);
		}
		valueStringVec.push_back(bufferString);
	}
    return valueStringVec;
}


std::string Input::getKeyValueString_Tx(const std::string fileName_i, const std::string section_i, const std::string key_i)
{
	std::ifstream fileStream;
	fileStream.open(fileName_i, std::ios::in);
	if (!fileStream.is_open())
	{
		std::cout << "[ERROR] : Cannot open file : " << fileName_i << " !! " << std::endl;
		return "";
	}

	std::string line;

	while (std::getline(fileStream, line))
	{
		if (line.find(section_i) == 0)
		{
			break;
		}
	}

	while (std::getline(fileStream, line))
	{
		std::stringstream ss(line);
		std::string bufferString;
		std::queue<std::string> tempStrQueue;
		while (std::getline(ss, bufferString, '='))
		{
			tempStrQueue.push(bufferString);
		}

		if (tempStrQueue.front() == key_i)
		{
			tempStrQueue.pop();
			fileStream.close();
			return removeNewLineChar_Tx(tempStrQueue.front());
		}
	}

	std::cout << " Not found ! " << key_i << std::endl;
	fileStream.close();
	return "";
}

std::string Input::removeNewLineChar_Tx(const std::string inputString)
{
	if (inputString[inputString.length() - 1] == '\r')
	{
		std::string tempBuf = inputString;
		tempBuf.erase(inputString.length() - 1);
		return tempBuf;
	}
	return inputString;
}