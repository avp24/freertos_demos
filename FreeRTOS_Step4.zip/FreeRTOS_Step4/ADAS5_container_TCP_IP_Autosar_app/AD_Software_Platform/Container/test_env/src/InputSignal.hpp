#ifndef _Input
#define _Input
#include <vector>
#include <fstream>
#include <iostream>
#include <string>
#include <sstream>
#include <queue>
#include <stdlib.h>
#include <stdbool.h>
#include <stdint.h>

using namespace std;
#define PARAMETER_VALUE_BUFFER_SIZE_Tx (2048)

class Input{
public:
	 std::string InputFileName_temp;
	 std::string InputFileName;
	 std::string myResultFileName_Tx;
	 std::ifstream myResultFileStream_Tx;
	 std::ofstream myFileStream_Tx;
	 int myLineCnt;
	 std::vector<std::string> myParamNameVec_Tx;
	 std::vector<std::string> initialize_Tx(const std::string testSettingFile_i);
	 std::vector<std::string> ReadParameterName_Tx(void);
	 
	 void InitializeExpected(const std::string settingFileName_i);
	 int Input::No_of_Rows(const string fileName_i);
	 std::string removeNewLineChar_Tx(const std::string inputString);
	 std::string getKeyValueString_Tx(const std::string fileName_i, const std::string section_i, const std::string key_i);
	 std::vector<std::string> Update_input(void);
};
#endif	
