#ifndef _Address_Config
#define _Address_Config

#include <vector>
#include <fstream>
#include <iostream>
#include <string>
#include <sstream>
#include <queue>
#include <stdlib.h>
#include <stdbool.h>
#include <stdint.h>

using namespace std;

class Address_Config {
public:
    std::string InitializeExpected_add_conf(const std::string settingFileName_i);
    std::string removeNewLineChar_Tx_add_conf(const std::string inputString);
    std::string getKeyValueString_Tx_add_conf(const std::string fileName_i, const std::string section_i, const std::string key_i);

    bool Write_OutputVar(std::vector<std::string> OpData_Var);
    bool Write_OutputValue_newLine();
    bool Write_OutputValue(std::string OpData_Vec);
};

#endif

