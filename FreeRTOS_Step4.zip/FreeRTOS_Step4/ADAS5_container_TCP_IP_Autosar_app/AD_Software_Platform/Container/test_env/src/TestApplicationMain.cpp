#include <iostream>
#include <string>
#include <sstream>
#include <cstring>
#include <arpa/inet.h>
#include <unistd.h>
#include <vector>

// Buffer size for TCP communication
const int BUFFER_SIZE = 4096;

void RunTCPServer(const std::string &ip, int port) {
    int server_fd, client_socket;
    struct sockaddr_in server_addr, client_addr;
    socklen_t addr_len = sizeof(client_addr);
    char buffer[BUFFER_SIZE] = {0};

    // Create socket
    if ((server_fd = socket(AF_INET, SOCK_STREAM, 0)) < 0) {
        perror("[ERROR] Socket creation failed");
        exit(EXIT_FAILURE);
    }

    server_addr.sin_family = AF_INET;
    server_addr.sin_addr.s_addr = inet_addr(ip.c_str());
    server_addr.sin_port = htons(port);

    if (bind(server_fd, (struct sockaddr *)&server_addr, sizeof(server_addr)) < 0) {
        perror("[ERROR] Bind failed");
        close(server_fd);
        exit(EXIT_FAILURE);
    }

    if (listen(server_fd, 3) < 0) {
        perror("[ERROR] Listen failed");
        close(server_fd);
        exit(EXIT_FAILURE);
    }

    std::cout << "[INFO] TCP Server listening on " << ip << ":" << port << "\n";

    if ((client_socket = accept(server_fd, (struct sockaddr *)&client_addr, &addr_len)) < 0) {
        perror("[ERROR] Accept failed");
        close(server_fd);
        exit(EXIT_FAILURE);
    }

    std::cout << "[INFO] Client connected.\n";

    int step = 1;
    int max_steps = 5; // Number of steps to simulate

    // Main loop: send first, then receive
    while (step <= max_steps) {
        // Prepare dummy input signals
        std::vector<std::string> dummyInputs = {
            "SignalA_" + std::to_string(step),
            "SignalB_" + std::to_string(step),
            "SignalC_" + std::to_string(step)
        };

        std::string input_str;
        for (size_t i = 0; i < dummyInputs.size(); ++i) {
            input_str += dummyInputs[i];
            if (i != dummyInputs.size() - 1) input_str += ",";
        }

        // Send dummy signals to client
        send(client_socket, input_str.c_str(), input_str.size(), 0);
        std::cout << "[INFO] Sent input signals: " << input_str << "\n";

        // Wait for client response
        memset(buffer, 0, BUFFER_SIZE);
        int valread = recv(client_socket, buffer, BUFFER_SIZE, 0);
        if (valread <= 0) {
            std::cout << "[INFO] Client disconnected or no response.\n";
            break;
        }

        std::string received(buffer);
        std::cout << "[INFO] Received from client: " << received << "\n";

        // Verify expected text
        if (received.find("HELLO_FROM_CLIENT") != std::string::npos) {
            std::cout << "[SUCCESS] Verified client response includes HELLO_FROM_CLIENT.\n";
        }

        step++;
        sleep(1); // Small delay for readability
    }

    // After sending all inputs, send termination signal
    std::string terminate = "END";
    send(client_socket, terminate.c_str(), terminate.size(), 0);
    std::cout << "[INFO] Sent termination signal to client.\n";

    close(client_socket);
    close(server_fd);
}

int main(int argc, char *argv[]) {
    std::cout << "#######################################################################\n";
    std::cout << "###           Test Environment TCP Server (Dynamic Inputs)          ###\n";
    std::cout << "#######################################################################\n";

    if (argc != 3) {
        std::cerr << "[ERROR] Usage: " << argv[0] << " <IP_Address> <Port>\n";
        return -1;
    }

    std::string ip = argv[1];
    int port = std::stoi(argv[2]);

    std::cout << "IP Address: " << ip << "\n";
    std::cout << "Port: " << port << "\n";

    RunTCPServer(ip, port);

    return 0;
}

