#include "OutputSignal.hpp"
#include <stdio.h>
#include <cstring>

void Output::InitializeExpected_Output(const std::string settingFileName_i)
{
	const std::string TEST_SETTING_SECTION = "[TEST_SETTING]";
	
	OutputLogFileName_temp = getKeyValueString_OP(settingFileName_i, TEST_SETTING_SECTION, "Output_Log_Set");
	OutputCsvFileName_temp = getKeyValueString_OP(settingFileName_i, TEST_SETTING_SECTION, "Output_Data");
	
	std::string filePath_out(settingFileName_i);
	size_t found_out = filePath_out.find_last_of("/\\");

	if (found_out != std::string::npos) 
	{
       OutputLogFileName = settingFileName_i.substr(0, found_out) + OutputLogFileName_temp;
       OutputCsvFileName = settingFileName_i.substr(0, found_out) + OutputCsvFileName_temp;
	}
	else
	{
	   OutputLogFileName = OutputLogFileName_temp;
	   OutputCsvFileName = OutputCsvFileName_temp;
	}
	cout<<"OutputLogFileName "<<OutputLogFileName<<endl;	
	cout<<"OutputCsvFileName "<<OutputCsvFileName<<endl;
}

 std::vector<std::string> Output::ReadOutputLog_ParamName_Rx()
 {
	const char CR = '\r';
	const char LF = '\n';
	int rows = 0;
    std::vector<std::string> OutputLog_Var_Vec;
	std::string bufferString;
	OutputLogFileName_Tx = string(OutputLogFileName.c_str()) + ".csv";

	//Clear Previous Data in the csv file 
	OutputLogFileStream_Tx.open(OutputLogFileName_Tx, std::ios::trunc);
	OutputLogFileStream_Tx.close();

	OutputLogFileStream_Tx.open(OutputLogFileName_Tx, std::ios::in);
	

	if (!OutputLogFileStream_Tx.is_open())
	{
		std::cout << " [WARNING] : Cannot open expected OutputLog File : " << OutputLogFileName_Tx << " !! " << std::endl;
		return ;
	}

    while (getline(OutputLogFileStream_Tx, bufferString))
	{
     std::string buff = "";
	 rows++;
	 for (const auto c : bufferString)
	 	{
	 		if ((c != CR) && (c != LF))
	 		{
	 			buff += c;
	 		}
	 	}
	 	if (buff != "")
	 	{
	 		bufferString = buff;
	 	}
	OutputLog_Var_Vec.push_back(bufferString);
	}
    OutputLogFileStream_Tx.close();
	return OutputLog_Var_Vec;
	 	 
 }
 
bool Output::initialize_Rx()
{

    OutputCsvFileName_Tx = string(OutputCsvFileName.c_str()) + ".csv";
	OutputCsvFileStream_Tx.open(OutputCsvFileName_Tx, std::ios::in);
	if (!OutputCsvFileStream_Tx.is_open())
	{
		std::cout << " [WARNING] : Cannot open expected Output File : " << OutputCsvFileName_Tx << " !! " << std::endl;
		return false;
	}
	return true;
}


bool Output::Write_OutputVar(std::vector<std::string> OpData_Var)
{
    if(OpData_Var.empty() || (!OutputCsvFileStream_Tx.is_open()))
    {
        std::cout << " ERROR : Cannot open Output File :  " << std::endl;
        return false;
    }

	for(int i = 0 ; i < OpData_Var.size(); i++ )
    {
        OutputCsvFileStream_Tx << OpData_Var.at(i);
        OutputCsvFileStream_Tx << ",";
    }
    OutputCsvFileStream_Tx << std::endl;
	return true;
}


bool Output::Write_OutputValue(std::string OpData_Vec)
{
		OutputCsvFileStream_Tx.is_open();
		OutputCsvFileStream_Tx << OpData_Vec;
		OutputCsvFileStream_Tx << ",";
	  return true;
}

bool Output::Write_OutputValue_newLine()
{
		OutputCsvFileStream_Tx.is_open();
		OutputCsvFileStream_Tx << std::endl;
	  return true;
}

std::string Output::getKeyValueString_OP(const std::string fileName_i, const std::string section_i, const std::string key_i)
{
	std::ifstream fileStream;
	fileStream.open(fileName_i, std::ios::in);

	if (!fileStream.is_open())
	{
		std::cout << "[ERROR] : Cannot open file : " << fileName_i << " !! " << std::endl;
		return "";
	}

	std::string line;

	while (std::getline(fileStream, line))
	{
		if (line.find(section_i) == 0)
		{
			break;
		}
	}

	while (std::getline(fileStream, line))
	{
		std::stringstream ss(line);
		std::string bufferString;
		std::queue<std::string> tempStrQueue;

		while (std::getline(ss, bufferString, '='))
		{
			tempStrQueue.push(bufferString);
		}

		if (tempStrQueue.front() == key_i)
		{
			tempStrQueue.pop();
			fileStream.close();
			return removeNewLineChar_OP(tempStrQueue.front());
		}
	}
	std::cout << " Not found ! " << key_i << std::endl;
	fileStream.close();
	return "";
}

std::string Output::removeNewLineChar_OP(const std::string inputString)
{
	if (inputString[inputString.length() - 1] == '\r')
	{
		std::string tempBuf = inputString;
		tempBuf.erase(inputString.length() - 1);
		return tempBuf;
	}
	return inputString;
}