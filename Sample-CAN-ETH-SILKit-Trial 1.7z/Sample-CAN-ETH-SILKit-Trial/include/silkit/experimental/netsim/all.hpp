// SPDX-FileCopyrightText: 2024 Vector Informatik GmbH
//
// SPDX-License-Identifier: MIT

#include "NetworkSimulatorDatatypes.hpp"
#include "INetworkSimulator.hpp"
